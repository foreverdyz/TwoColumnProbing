NAME
ROWS
 N  OBJ
 L  c1_2
 L  c2_2
 L  c3_2
 L  c4_2
 L  c5_2
 L  c6_2
 L  c7_2
 L  c8_2
 L  c9_2
 L  c10_2
 L  c11_2
 L  c12_2
 L  c13_2
 L  c14_2
 L  c15_2
 L  c16_2
 L  c17_2
 L  c18_2
 L  c19_2
 L  c20_2
 L  c21_2
 L  c22_2
 L  c23_2
 L  c24_2
 L  c25_2
 L  c26_2
 L  c27_2
 L  c28_2
 L  c29_2
 L  c30_2
 L  c31_2
 L  c32_2
 L  c33_2
 L  c34_2
 L  c35_2
 L  c36_2
 L  c37_2
 L  c38_2
 L  c39_2
 L  c40_2
 L  c41_2
 L  c42_2
 L  c43_2
 L  c44_2
 L  c45_2
 L  c46_2
 L  c47_2
 L  c48_2
 L  c49_2
 L  c50_2
 L  c51_2
 L  c52_2
 L  c53_2
 L  c54_2
 L  c55_2
 L  c56_2
 L  c57_2
 L  c58_2
 L  c59_2
 L  c60_2
 L  c61_2
 L  c62_2
 L  c63_2
 L  c64_2
 L  c65_2
 L  c66_2
 L  c67_2
 L  c68_2
 L  c69_2
 L  c70_2
 L  c71_2
 L  c72_2
 L  c73_2
 L  c74_2
 L  c75_2
 L  c76_2
 L  c77_2
 L  c78_2
 L  c79_2
 L  c80_2
 L  c81_2
 L  c82_2
 L  c83_2
 L  c84_2
 L  c85_2
 L  c86_2
 L  c87_2
 L  c88_2
 L  c89_2
 L  c90_2
 L  c91_2
 L  c92_2
 L  c93_2
 L  c94_2
 L  c95_2
 L  c96_2
 L  c97_2
 L  c98_2
 L  c99_2
 L  c100_2
 L  c101_2
 L  c102_2
 L  c103_2
 L  c104_2
 L  c105_2
 L  c106_2
 L  c107_2
 L  c108_2
 L  c109_2
 L  c110_2
 L  c111_2
 L  c112_2
 L  c113_2
 L  c114_2
 L  c115_2
 L  c116_2
 L  c117_2
 L  c118_2
 L  c119_2
 L  c120_2
 L  c121_2
 L  c122_2
 L  c123_2
 L  c124_2
 L  c125_2
 L  c126_2
 L  c127_2
 L  c128_2
 L  c129_2
 L  c130_2
 L  c131_2
 L  c132_2
 L  c133_2
 L  c134_2
 L  c135_2
 L  c136_2
 L  c137_2
 L  c138_2
 L  c139_2
 L  c140_2
 L  c141_2
 L  c142_2
 L  c143_2
 L  c144_2
 L  c145_2
 L  c146_2
 L  c147_2
 L  c148_2
 L  c149_2
 L  c150_2
 L  c151_2
 L  c152_2
 L  c153_2
 L  c154_2
 L  c155_2
 L  c156_2
 L  c157_2
 L  c158_2
 L  c159_2
 L  c160_2
 L  c161_2
 L  c162_2
 L  c163_2
 L  c164_2
 L  c165_2
 L  c166_2
 L  c167_2
 L  c168_2
 L  c169_2
 L  c170_2
 L  c171_2
 L  c172_2
 L  c173_2
 L  c174_2
 L  c175_2
 L  c176_2
 L  c177_2
 L  c178_2
 L  c179_2
 L  c180_2
 L  c181_2
 L  c182_2
 L  c183_2
 L  c184_2
 L  c185_2
 L  c186_2
 L  c187_2
 L  c188_2
 L  c189_2
 L  c190_2
 L  c191_2
 L  c192_2
 L  c193_2
 L  c194_2
 L  c195_2
 L  c196_2
 L  c197_2
 L  c198_2
 L  c199_2
 L  c200_2
 L  c201_2
 L  c202_2
 L  c203_2
 L  c204_2
 L  c205_2
 L  c206_2
 L  c207_2
 L  c208_2
 L  c209_2
 L  c210_2
 L  c211_2
 L  c212_2
 L  c213_2
 L  c214_2
 L  c215_2
 L  c216_2
 L  c217_2
 L  c218_2
 L  c219_2
 L  c220_2
 L  c221_2
 L  c222_2
 L  c223_2
 L  c224_2
 L  c225_2
 L  c226_2
 L  c227_2
 L  c228_2
 L  c229_2
 L  c230_2
 L  c231_2
 L  c232_2
 L  c233_2
 L  c234_2
 L  c235_2
 L  c236_2
 L  c237_2
 L  c238_2
 L  c239_2
 L  c240_2
 L  c241_2
 L  c242_2
 L  c243_2
 L  c244_1
 L  c245_1
 L  c246_1
 L  c247_1
 L  c248_1
 L  c249_1
 L  c250_1
 L  c251_1
 L  c252_1
 L  c253_1
 L  c254_1
 L  c255_1
 L  c256_1
 L  c257_1
 L  c258_1
 L  c259_1
 L  c260_1
 L  c261_1
 L  c262_1
 L  c263_1
 L  c264_1
 L  c265_1
 L  c266_1
 L  c267_1
 L  c268_1
 L  c269_1
 L  c270_1
 L  c271_1
 L  c272_1
 L  c273_1
 L  c274_1
 L  c275_1
 L  c276_1
 L  c277_1
 L  c278_1
 L  c279_1
 L  c280_1
 L  c281_1
 L  c282_1
 L  c283_1
 L  c284_1
 L  c285_1
 L  c286_1
 L  c287_1
 L  c288_1
 L  c289_1
 L  c290_1
 L  c291_1
 L  c292_1
 L  c293_1
 L  c294_1
 L  c295_1
 L  c296_1
 L  c297_1
 L  c298_1
 L  c299_1
 L  c300_1
 L  c301_1
 L  c302_1
 L  c303_1
 L  c304_1
 L  c305_1
 L  c306_1
 L  c307_1
 L  c308_1
 L  c309_1
 L  c310_1
 L  c311_1
 L  c312_1
 L  c313_1
 L  c314_1
 L  c315_1
 L  c316_1
 L  c317_1
 L  c318_1
 L  c319_1
 L  c320_1
 L  c321_1
 L  c322_1
 L  c323_1
 L  c324_1
 L  c325_1
 L  c326_1
 L  c327_1
 L  c328_1
 L  c329_1
 L  c330_1
 L  c331_1
 L  c332_1
 L  c333_1
 L  c334_1
 L  c335_1
 L  c336_1
 L  c337_1
 L  c338_1
 L  c339_1
 L  c340_1
 L  c341_1
 L  c342_1
 L  c343_1
 L  c344_1
 L  c345_1
 L  c346_1
 L  c347_1
 L  c348_1
 L  c349_1
 L  c350_1
 L  c351_1
 L  c352_1
 L  c353_1
 L  c354_1
 L  c355_1
 L  c356_1
 L  c357_1
 L  c358_1
 L  c359_1
 L  c360_1
 L  c361_1
 L  c362_1
 L  c363_1
 L  c364_1
 L  c365_1
 L  c366_1
 L  c367_1
 L  c368_1
 L  c369_1
 L  c370_1
 L  c371_1
 L  c372_1
 L  c373_1
 L  c374_1
 L  c375_1
 L  c376_1
 L  c377_1
 L  c378_1
 L  c379_1
 L  c380_1
 L  c381_1
 L  c382_1
 L  c383_1
 L  c384_1
 L  c385_1
 L  c386_1
 L  c387_1
 L  c388_1
 L  c389_1
 L  c390_1
 L  c391_1
 L  c392_1
 L  c393_1
 L  c394_1
 L  c395_1
 L  c396_1
 L  c397_1
 L  c398_1
 L  c399_1
 L  c400_1
 L  c401_1
 L  c402_1
 L  c403_1
 L  c404_1
 L  c405_1
 L  c406_1
 L  c407_1
 L  c408_1
 L  c409_1
 L  c410_1
 L  c411_1
 L  c412_1
 L  c413_1
 L  c414_1
 L  c415_1
 L  c416_1
 L  c417_1
 L  c418_1
 L  c419_1
 L  c420_1
 L  c421_1
 L  c422_1
 L  c423_1
 L  c424_1
 L  c425_1
 L  c426_1
 L  c427_1
 L  c428_1
 L  c429_1
 L  c430_1
 L  c431_1
 L  c432_1
 L  c433_1
 L  c434_1
 L  c435_1
 L  c436_1
 L  c437_1
 L  c438_1
 L  c439_1
 L  c440_1
 L  c441_1
 L  c442_1
 L  c443_1
 L  c444_1
 L  c445_1
 L  c446_1
 L  c447_1
 L  c448_1
 L  c449_1
 L  c450_1
 L  c451_1
 L  c452_1
 L  c453_1
 L  c454_1
 L  c455_1
 L  c456_1
 L  c457_1
 L  c458_1
 L  c459_1
 L  c460_1
 L  c461_1
 L  c462_1
 L  c463_1
 L  c464_1
 L  c465_1
 L  c466_1
 L  c467_1
 L  c468_1
 L  c469_1
 L  c470_1
 L  c471_1
 L  c472_1
 L  c473_1
 L  c474_1
 L  c475_1
 L  c476_1
 L  c477_1
 L  c478_1
 L  c479_1
 L  c480_1
 L  c481_1
 L  c482_1
 L  c483_1
 L  c484_1
 L  c485_1
 L  c486_1
 L  c487_1
 L  c488_1
 L  c489_1
 L  c490_1
 L  c491_1
 L  c492_1
 L  c493_1
 L  c494_1
 L  c495_1
 L  c496_1
 L  c497_1
 L  c498_1
 L  c499_1
 L  c500_1
 L  c501_1
 L  c502_1
 L  c503_1
 L  c504_1
 L  c505_1
 L  c506_1
 L  c507_1
 L  c508_1
 L  c509_1
 L  c510_1
 L  c511_1
 L  c512_1
 L  c513_1
 L  c514_1
 L  c515_1
 L  c516_1
 L  c517_1
 L  c518_1
 L  c519_1
 L  c520_1
 L  c521_1
 L  c522_1
 L  c523_1
 L  c524_1
 L  c525_1
 L  c526_1
 L  c527_1
 L  c528_1
 L  c529_1
 L  c530_1
 L  c531_1
 L  c532_1
 L  c533_1
 L  c534_1
 L  c535_1
 L  c536_1
 L  c537_1
 L  c538_1
 L  c539_1
 L  c540_1
 L  c541_1
 L  c542_1
 L  c543_1
 L  c544_1
 L  c545_1
 L  c546_1
 L  c547_1
 L  c548_1
 L  c549_1
 L  c550_1
 L  c551_1
 L  c552_1
 L  c553_1
 L  c554_1
 L  c555_1
 L  c556_1
 L  c557_1
 L  c558_1
 L  c559_1
 L  c560_1
 L  c561_1
 L  c562_1
 L  c563_1
 L  c564_1
 L  c565_1
 L  c566_1
 L  c567_1
 L  c568_1
 L  c569_1
 L  c570_1
 L  c571_1
 L  c572_1
 L  c573_1
 L  c574_1
 L  c575_1
 L  c576_1
 L  c577_1
 L  c578_1
 L  c579_1
 L  c580_1
 L  c581_1
 L  c582_1
 L  c583_1
 L  c584_1
 L  c585_1
 L  c586_1
 L  c587_1
 L  c588_1
 L  c589_1
 L  c590_1
 L  c591_1
 L  c592_1
 L  c593_1
 L  c594_1
 L  c595_1
 L  c596_1
 L  c597_1
 L  c598_1
 L  c599_1
 L  c600_1
 L  c601_1
 L  c602_1
 L  c603_1
 L  c604_1
 L  c605_1
 L  c606_1
 L  c607_1
 L  c608_1
 L  c609_1
 L  c610_1
 L  c611_1
 L  c612_1
 L  c613_1
 L  c614_1
 L  c615_1
 L  c616_1
 L  c617_1
 L  c618_1
 L  c619_1
 L  c620_1
 L  c621_1
 L  c622_1
 L  c623_1
 L  c624_1
 L  c625_1
 L  c626_1
 L  c627_1
 L  c628_1
 L  c629_1
 L  c630_1
 L  c631_1
 L  c632_1
 L  c633_1
 L  c634_1
 L  c635_1
 L  c636_1
 L  c637_1
 L  c638_1
 L  c639_1
 L  c640_1
 L  c641_1
 L  c642_1
 L  c643_1
 L  c644_1
 L  c645_1
 L  c646_1
 L  c647_1
 L  c648_1
 L  c649_1
 L  c650_1
 L  c651_1
 L  c652_1
 L  c653_1
 L  c654_1
 L  c655_1
 L  c656_1
 L  c657_1
 L  c658_1
 L  c659_1
 L  c660_1
 L  c661_1
 L  c662_1
 L  c663_1
 L  c664_1
 L  c665_1
 L  c666_1
 L  c667_1
 L  c668_1
 L  c669_1
 L  c670_1
 L  c671_1
 L  c672_1
 L  c673_1
 L  c674_1
 L  c675_1
 L  c676_1
 L  c677_1
 L  c678_1
 L  c679_1
 L  c680_1
 L  c681_1
 L  c682_1
 L  c683_1
 L  c684_1
 L  c685_1
 L  c686_1
 L  c687_1
 L  c688_1
 L  c689_1
 L  c690_1
 L  c691_1
 L  c692_1
 L  c693_1
 L  c694_1
 L  c695_1
 L  c696_1
 L  c697_1
 L  c698_1
 L  c699_1
 L  c700_1
 L  c701_1
 L  c702_1
 L  c703_1
 L  c704_1
 L  c705_1
 L  c706_1
 L  c707_1
 L  c708_1
 L  c709_1
 L  c710_1
 L  c711_1
 L  c712_1
 L  c713_1
 L  c714_1
 L  c715_1
 L  c716_1
 L  c717_1
 L  c718_1
 L  c719_1
 L  c720_1
 L  c721_1
 L  c722_1
 L  c723_1
 L  c724_1
 L  c725_1
 L  c726_1
 L  c727_1
 L  c728_1
 L  c729_1
 L  c730_1
 L  c731_1
 L  c732_1
 L  c733_1
 L  c734_1
 L  c735_1
 L  c736_1
 L  c737_1
 L  c738_1
 L  c739_1
 L  c740_1
 L  c741_1
 L  c742_1
 L  c743_1
 L  c744_1
 L  c745_1
 L  c746_1
 L  c747_1
 L  c748_1
 L  c749_1
 L  c750_1
 L  c751_1
 L  c752_1
 L  c753_1
 L  c754_1
 L  c755_1
 L  c756_1
 L  c757_1
 L  c758_1
 L  c759_1
 L  c760_1
 L  c761_1
 L  c762_1
 L  c763_1
 L  c764_1
 L  c765_1
 L  c766_1
 L  c767_1
 L  c768_1
 L  c769_1
 L  c770_1
 L  c771_1
 L  c772_1
 L  c773_1
 L  c774_1
 L  c775_1
 L  c776_1
 L  c777_1
 L  c778_1
 L  c779_1
 L  c780_1
 L  c781_1
 L  c782_1
 L  c783_1
 L  c784_1
 L  c785_1
 L  c786_1
 L  c787_1
 L  c788_1
 L  c789_1
 L  c790_1
 L  c791_1
 L  c792_1
 L  c793_1
 L  c794_1
 L  c795_1
 L  c796_1
 L  c797_1
 L  c798_1
 L  c799_1
 L  c800_1
 L  c801_1
 L  c802_1
 L  c803_1
 L  c804_1
 L  c805_1
 L  c806_1
 L  c807_1
 L  c808_1
 L  c809_1
 L  c810_1
 L  c811_1
 L  c812_1
 L  c813_1
 L  c814_1
 L  c815_1
 L  c816_1
 L  c817_1
 L  c818_1
 L  c819_1
 L  c820_1
 L  c821_1
 L  c822_1
 L  c823_1
 L  c824_1
 L  c825_1
 L  c826_1
 L  c827_1
 L  c828_1
 L  c829_1
 L  c830_1
 L  c831_1
 L  c832_1
 L  c833_1
 L  c834_1
 L  c835_1
 L  c836_1
 L  c837_1
 L  c838_1
 L  c839_1
 L  c840_1
 L  c841_1
 L  c842_1
 L  c843_1
 L  c844_1
 L  c845_1
 L  c846_1
 L  c847_1
 L  c848_1
 L  c849_1
 L  c850_1
 L  c851_1
 L  c852_1
 L  c853_1
 L  c854_1
 L  c855_1
 L  c856_1
 L  c857_1
 L  c858_1
 L  c859_1
 L  c860_1
 L  c861_1
 L  c862_1
 L  c863_1
 L  c864_1
 L  c865_1
 L  c866_1
 L  c867_1
 L  c868_1
 L  c869_1
 L  c870_1
 L  c871_1
 L  c872_1
 L  c873_1
 L  c874_1
 L  c875_1
 L  c876_1
 L  c877_1
 L  c878_1
 L  c879_1
 L  c880_1
 L  c881_1
 L  c882_1
 L  c883_1
 L  c884_1
 L  c885_1
 L  c886_1
 L  c887_1
 L  c888_1
 L  c889_1
 L  c890_1
 L  c891_1
 L  c892_1
 L  c893_1
 L  c894_1
 L  c895_1
 L  c896_1
 L  c897_1
 L  c898_1
 L  c899_1
 L  c900_1
 L  c901_1
 L  c902_1
 L  c903_1
 L  c904_1
 L  c905_1
 L  c906_1
 L  c907_1
 L  c908_1
 L  c909_1
 L  c910_1
 L  c911_1
 L  c912_1
 L  c913_1
 L  c914_1
 L  c915_1
 L  c916_1
 L  c917_1
 L  c918_1
 L  c919_1
 L  c920_1
 L  c921_1
 L  c922_1
 L  c923_1
 L  c924_1
 L  c925_1
 L  c926_1
 L  c927_1
 L  c928_1
 L  c929_1
 L  c930_1
 L  c931_1
 L  c932_1
 L  c933_1
 L  c934_1
 L  c935_1
 L  c936_1
 L  c937_1
 L  c938_1
 L  c939_1
 L  c940_1
 L  c941_1
 L  c942_1
 L  c943_1
 L  c944_1
 L  c945_1
 L  c946_1
 L  c947_1
 L  c948_1
 L  c949_1
 L  c950_1
 L  c951_1
 L  c952_1
 L  c953_1
 L  c954_1
 L  c955_1
 L  c956_1
 L  c957_1
 L  c958_1
 L  c959_1
 L  c960_1
 L  c961_1
 L  c962_1
 L  c963_1
 L  c964_1
 L  c965_1
 L  c966_1
 L  c967_1
 L  c968_1
 L  c969_1
 L  c970_1
 L  c971_1
 L  c972_1
 L  c973_1
 L  c974_1
 L  c975_1
 L  c976_1
 L  c977_1
 L  c978_1
 L  c979_1
 L  c980_1
 L  c981_1
 L  c982_1
 L  c983_1
 L  c984_1
 L  c985_1
 G  c1_1
 G  c2_1
 G  c3_1
 G  c4_1
 G  c5_1
 G  c6_1
 G  c7_1
 G  c8_1
 G  c9_1
 G  c10_1
 G  c11_1
 G  c12_1
 G  c13_1
 G  c14_1
 G  c15_1
 G  c16_1
 G  c17_1
 G  c18_1
 G  c19_1
 G  c20_1
 G  c21_1
 G  c22_1
 G  c23_1
 G  c24_1
 G  c25_1
 G  c26_1
 G  c27_1
 G  c28_1
 G  c29_1
 G  c30_1
 G  c31_1
 G  c32_1
 G  c33_1
 G  c34_1
 G  c35_1
 G  c36_1
 G  c37_1
 G  c38_1
 G  c39_1
 G  c40_1
 G  c41_1
 G  c42_1
 G  c43_1
 G  c44_1
 G  c45_1
 G  c46_1
 G  c47_1
 G  c48_1
 G  c49_1
 G  c50_1
 G  c51_1
 G  c52_1
 G  c53_1
 G  c54_1
 G  c55_1
 G  c56_1
 G  c57_1
 G  c58_1
 G  c59_1
 G  c60_1
 G  c61_1
 G  c62_1
 G  c63_1
 G  c64_1
 G  c65_1
 G  c66_1
 G  c67_1
 G  c68_1
 G  c69_1
 G  c70_1
 G  c71_1
 G  c72_1
 G  c73_1
 G  c74_1
 G  c75_1
 G  c76_1
 G  c77_1
 G  c78_1
 G  c79_1
 G  c80_1
 G  c81_1
 G  c82_1
 G  c83_1
 G  c84_1
 G  c85_1
 G  c86_1
 G  c87_1
 G  c88_1
 G  c89_1
 G  c90_1
 G  c91_1
 G  c92_1
 G  c93_1
 G  c94_1
 G  c95_1
 G  c96_1
 G  c97_1
 G  c98_1
 G  c99_1
 G  c100_1
 G  c101_1
 G  c102_1
 G  c103_1
 G  c104_1
 G  c105_1
 G  c106_1
 G  c107_1
 G  c108_1
 G  c109_1
 G  c110_1
 G  c111_1
 G  c112_1
 G  c113_1
 G  c114_1
 G  c115_1
 G  c116_1
 G  c117_1
 G  c118_1
 G  c119_1
 G  c120_1
 G  c121_1
 G  c122_1
 G  c123_1
 G  c124_1
 G  c125_1
 G  c126_1
 G  c127_1
 G  c128_1
 G  c129_1
 G  c130_1
 G  c131_1
 G  c132_1
 G  c133_1
 G  c134_1
 G  c135_1
 G  c136_1
 G  c137_1
 G  c138_1
 G  c139_1
 G  c140_1
 G  c141_1
 G  c142_1
 G  c143_1
 G  c144_1
 G  c145_1
 G  c146_1
 G  c147_1
 G  c148_1
 G  c149_1
 G  c150_1
 G  c151_1
 G  c152_1
 G  c153_1
 G  c154_1
 G  c155_1
 G  c156_1
 G  c157_1
 G  c158_1
 G  c159_1
 G  c160_1
 G  c161_1
 G  c162_1
 G  c163_1
 G  c164_1
 G  c165_1
 G  c166_1
 G  c167_1
 G  c168_1
 G  c169_1
 G  c170_1
 G  c171_1
 G  c172_1
 G  c173_1
 G  c174_1
 G  c175_1
 G  c176_1
 G  c177_1
 G  c178_1
 G  c179_1
 G  c180_1
 G  c181_1
 G  c182_1
 G  c183_1
 G  c184_1
 G  c185_1
 G  c186_1
 G  c187_1
 G  c188_1
 G  c189_1
 G  c190_1
 G  c191_1
 G  c192_1
 G  c193_1
 G  c194_1
 G  c195_1
 G  c196_1
 G  c197_1
 G  c198_1
 G  c199_1
 G  c200_1
 G  c201_1
 G  c202_1
 G  c203_1
 G  c204_1
 G  c205_1
 G  c206_1
 G  c207_1
 G  c208_1
 G  c209_1
 G  c210_1
 G  c211_1
 G  c212_1
 G  c213_1
 G  c214_1
 G  c215_1
 G  c216_1
 G  c217_1
 G  c218_1
 G  c219_1
 G  c220_1
 G  c221_1
 G  c222_1
 G  c223_1
 G  c224_1
 G  c225_1
 G  c226_1
 G  c227_1
 G  c228_1
 G  c229_1
 G  c230_1
 G  c231_1
 G  c232_1
 G  c233_1
 G  c234_1
 G  c235_1
 G  c236_1
 G  c237_1
 G  c238_1
 G  c239_1
 G  c240_1
 G  c241_1
 G  c242_1
 G  c243_1
 G  c244
 G  c245
 G  c246
 G  c247
 G  c248
 G  c249
 G  c250
 G  c251
 G  c252
 G  c253
 G  c254
 G  c255
 G  c256
 G  c257
 G  c258
 G  c259
 G  c260
 G  c261
 G  c262
 G  c263
 G  c264
 G  c265
 G  c266
 G  c267
 G  c268
 G  c269
 G  c270
 G  c271
 G  c272
 G  c273
 G  c274
 G  c275
 G  c276
 G  c277
 G  c278
 G  c279
 G  c280
 G  c281
 G  c282
 G  c283
 G  c284
 G  c285
 G  c286
 G  c287
 G  c288
 G  c289
 G  c290
 G  c291
 G  c292
 G  c293
 G  c294
 G  c295
 G  c296
 G  c297
 G  c298
 G  c299
 G  c300
 G  c301
 G  c302
 G  c303
 G  c304
 G  c305
 G  c306
 G  c307
 G  c308
 G  c309
 G  c310
 G  c311
 G  c312
 G  c313
 G  c314
 G  c315
 G  c316
 G  c317
 G  c318
 G  c319
 G  c320
 G  c321
 G  c322
 G  c323
 G  c324
 G  c325
 G  c326
 G  c327
 G  c328
 G  c329
 G  c330
 G  c331
 G  c332
 G  c333
 G  c334
 G  c335
 G  c336
 G  c337
 G  c338
 G  c339
 G  c340
 G  c341
 G  c342
 G  c343
 G  c344
 G  c345
 G  c346
 G  c347
 G  c348
 G  c349
 G  c350
 G  c351
 G  c352
 G  c353
 G  c354
 G  c355
 G  c356
 G  c357
 G  c358
 G  c359
 G  c360
 G  c361
 G  c362
 G  c363
 G  c364
 G  c365
 G  c366
 G  c367
 G  c368
 G  c369
 G  c370
 G  c371
 G  c372
 G  c373
 G  c374
 G  c375
 G  c376
 G  c377
 G  c378
 G  c379
 G  c380
 G  c381
 G  c382
 G  c383
 G  c384
 G  c385
 G  c386
 G  c387
 G  c388
 G  c389
 G  c390
 G  c391
 G  c392
 G  c393
 G  c394
 G  c395
 G  c396
 G  c397
 G  c398
 G  c399
 G  c400
 G  c401
 G  c402
 G  c403
 G  c404
 G  c405
 G  c406
 G  c407
 G  c408
 G  c409
 G  c410
 G  c411
 G  c412
 G  c413
 G  c414
 G  c415
 G  c416
 G  c417
 G  c418
 G  c419
 G  c420
 G  c421
 G  c422
 G  c423
 G  c424
 G  c425
 G  c426
 G  c427
 G  c428
 G  c429
 G  c430
 G  c431
 G  c432
 G  c433
 G  c434
 G  c435
 G  c436
 G  c437
 G  c438
 G  c439
 G  c440
 G  c441
 G  c442
 G  c443
 G  c444
 G  c445
 G  c446
 G  c447
 G  c448
 G  c449
 G  c450
 G  c451
 G  c452
 G  c453
 G  c454
 G  c455
 G  c456
 G  c457
 G  c458
 G  c459
 G  c460
 G  c461
 G  c462
 G  c463
 G  c464
 G  c465
 G  c466
 G  c467
 G  c468
 G  c469
 G  c470
 G  c471
 G  c472
 G  c473
 G  c474
 G  c475
 G  c476
 G  c477
 G  c478
 G  c479
 G  c480
 G  c481
 G  c482
 G  c483
 G  c484
 G  c485
 G  c486
 G  c487
 G  c488
 G  c489
 G  c490
 G  c491
 G  c492
 G  c493
 G  c494
 G  c495
 G  c496
 G  c497
 G  c498
 G  c499
 G  c500
 G  c501
 G  c502
 G  c503
 G  c504
 G  c505
 G  c506
 G  c507
 G  c508
 G  c509
 G  c510
 G  c511
 G  c512
 G  c513
 G  c514
 G  c515
 G  c516
 G  c517
 G  c518
 G  c519
 G  c520
 G  c521
 G  c522
 G  c523
 G  c524
 G  c525
 G  c526
 G  c527
 G  c528
 G  c529
 G  c530
 G  c531
 G  c532
 G  c533
 G  c534
 G  c535
 G  c536
 G  c537
 G  c538
 G  c539
 G  c540
 G  c541
 G  c542
 G  c543
 G  c544
 G  c545
 G  c546
 G  c547
 G  c548
 G  c549
 G  c550
 G  c551
 G  c552
 G  c553
 G  c554
 G  c555
 G  c556
 G  c557
 G  c558
 G  c559
 G  c560
 G  c561
 G  c562
 G  c563
 G  c564
 G  c565
 G  c566
 G  c567
 G  c568
 G  c569
 G  c570
 G  c571
 G  c572
 G  c573
 G  c574
 G  c575
 G  c576
 G  c577
 G  c578
 G  c579
 G  c580
 G  c581
 G  c582
 G  c583
 G  c584
 G  c585
 G  c586
 G  c587
 G  c588
 G  c589
 G  c590
 G  c591
 G  c592
 G  c593
 G  c594
 G  c595
 G  c596
 G  c597
 G  c598
 G  c599
 G  c600
 G  c601
 G  c602
 G  c603
 G  c604
 G  c605
 G  c606
 G  c607
 G  c608
 G  c609
 G  c610
 G  c611
 G  c612
 G  c613
 G  c614
 G  c615
 G  c616
 G  c617
 G  c618
 G  c619
 G  c620
 G  c621
 G  c622
 G  c623
 G  c624
 G  c625
 G  c626
 G  c627
 G  c628
 G  c629
 G  c630
 G  c631
 G  c632
 G  c633
 G  c634
 G  c635
 G  c636
 G  c637
 G  c638
 G  c639
 G  c640
 G  c641
 G  c642
 G  c643
 G  c644
 G  c645
 G  c646
 G  c647
 G  c648
 G  c649
 G  c650
 G  c651
 G  c652
 G  c653
 G  c654
 G  c655
 G  c656
 G  c657
 G  c658
 G  c659
 G  c660
 G  c661
 G  c662
 G  c663
 G  c664
 G  c665
 G  c666
 G  c667
 G  c668
 G  c669
 G  c670
 G  c671
 G  c672
 G  c673
 G  c674
 G  c675
 G  c676
 G  c677
 G  c678
 G  c679
 G  c680
 G  c681
 G  c682
 G  c683
 G  c684
 G  c685
 G  c686
 G  c687
 G  c688
 G  c689
 G  c690
 G  c691
 G  c692
 G  c693
 G  c694
 G  c695
 G  c696
 G  c697
 G  c698
 G  c699
 G  c700
 G  c701
 G  c702
 G  c703
 G  c704
 G  c705
 G  c706
 G  c707
 G  c708
 G  c709
 G  c710
 G  c711
 G  c712
 G  c713
 G  c714
 G  c715
 G  c716
 G  c717
 G  c718
 G  c719
 G  c720
 G  c721
 G  c722
 G  c723
 G  c724
 G  c725
 G  c726
 G  c727
 G  c728
 G  c729
 G  c730
 G  c731
 G  c732
 G  c733
 G  c734
 G  c735
 G  c736
 G  c737
 G  c738
 G  c739
 G  c740
 G  c741
 G  c742
 G  c743
 G  c744
 G  c745
 G  c746
 G  c747
 G  c748
 G  c749
 G  c750
 G  c751
 G  c752
 G  c753
 G  c754
 G  c755
 G  c756
 G  c757
 G  c758
 G  c759
 G  c760
 G  c761
 G  c762
 G  c763
 G  c764
 G  c765
 G  c766
 G  c767
 G  c768
 G  c769
 G  c770
 G  c771
 G  c772
 G  c773
 G  c774
 G  c775
 G  c776
 G  c777
 G  c778
 G  c779
 G  c780
 G  c781
 G  c782
 G  c783
 G  c784
 G  c785
 G  c786
 G  c787
 G  c788
 G  c789
 G  c790
 G  c791
 G  c792
 G  c793
 G  c794
 G  c795
 G  c796
 G  c797
 G  c798
 G  c799
 G  c800
 G  c801
 G  c802
 G  c803
 G  c804
 G  c805
 G  c806
 G  c807
 G  c808
 G  c809
 G  c810
 G  c811
 G  c812
 G  c813
 G  c814
 G  c815
 G  c816
 G  c817
 G  c818
 G  c819
 G  c820
 G  c821
 G  c822
 G  c823
 G  c824
 G  c825
 G  c826
 G  c827
 G  c828
 G  c829
 G  c830
 G  c831
 G  c832
 G  c833
 G  c834
 G  c835
 G  c836
 G  c837
 G  c838
 G  c839
 G  c840
 G  c841
 G  c842
 G  c843
 G  c844
 G  c845
 G  c846
 G  c847
 G  c848
 G  c849
 G  c850
 G  c851
 G  c852
 G  c853
 G  c854
 G  c855
 G  c856
 G  c857
 G  c858
 G  c859
 G  c860
 G  c861
 G  c862
 G  c863
 G  c864
 G  c865
 G  c866
 G  c867
 G  c868
 G  c869
 G  c870
 G  c871
 G  c872
 G  c873
 G  c874
 G  c875
 G  c876
 G  c877
 G  c878
 G  c879
 G  c880
 G  c881
 G  c882
 G  c883
 G  c884
 G  c885
 G  c886
 G  c887
 G  c888
 G  c889
 G  c890
 G  c891
 G  c892
 G  c893
 G  c894
 G  c895
 G  c896
 G  c897
 G  c898
 G  c899
 G  c900
 G  c901
 G  c902
 G  c903
 G  c904
 G  c905
 G  c906
 G  c907
 G  c908
 G  c909
 G  c910
 G  c911
 G  c912
 G  c913
 G  c914
 G  c915
 G  c916
 G  c917
 G  c918
 G  c919
 G  c920
 G  c921
 G  c922
 G  c923
 G  c924
 G  c925
 G  c926
 G  c927
 G  c928
 G  c929
 G  c930
 G  c931
 G  c932
 G  c933
 G  c934
 G  c935
 G  c936
 G  c937
 G  c938
 G  c939
 G  c940
 G  c941
 G  c942
 G  c943
 G  c944
 G  c945
 G  c946
 G  c947
 G  c948
 G  c949
 G  c950
 G  c951
 G  c952
 G  c953
 G  c954
 G  c955
 G  c956
 G  c957
 G  c958
 G  c959
 G  c960
 G  c961
 G  c962
 G  c963
 G  c964
 G  c965
 G  c966
 G  c967
 G  c968
 G  c969
 G  c970
 G  c971
 G  c972
 G  c973
 G  c974
 G  c975
 G  c976
 G  c977
 G  c978
 G  c979
 G  c980
 G  c981
 G  c982
 G  c983
 G  c984
 G  c985
 G  c986
 G  c987
 G  c988
 G  c989
 G  c990
 G  c991
 G  c992
 G  c993
 G  c994
 G  c995
 G  c996
 G  c997
 G  c998
 G  c999
 G  c1000
 G  c1001
 G  c1002
 G  c1003
 G  c1004
 G  c1005
 G  c1006
 G  c1007
 G  c1008
 G  c1009
 G  c1010
 G  c1011
 G  c1012
 G  c1013
 G  c1014
 G  c1015
 G  c1016
 G  c1017
 G  c1018
 G  c1019
 G  c1020
 G  c1021
 G  c1022
 G  c1023
 G  c1024
 G  c1025
 G  c1026
 G  c1027
 G  c1028
 G  c1029
 G  c1030
 G  c1031
 G  c1032
 G  c1033
 G  c1034
 G  c1035
 G  c1036
 G  c1037
 G  c1038
 G  c1039
 G  c1040
 G  c1041
 G  c1042
 G  c1043
 G  c1044
 G  c1045
 G  c1046
 G  c1047
 G  c1048
 G  c1049
 G  c1050
 G  c1051
 G  c1052
 G  c1053
 G  c1054
 G  c1055
 G  c1056
 G  c1057
 G  c1058
 G  c1059
 G  c1060
 G  c1061
 G  c1062
 G  c1063
 G  c1064
 G  c1065
 G  c1066
 G  c1067
 G  c1068
 G  c1069
 G  c1070
 G  c1071
 G  c1072
 G  c1073
 G  c1074
 G  c1075
 G  c1076
 G  c1077
 G  c1078
 G  c1079
 G  c1080
 G  c1081
 G  c1082
 G  c1083
 G  c1084
 G  c1085
 G  c1086
 G  c1087
 G  c1088
 G  c1089
 G  c1090
 G  c1091
 G  c1092
 G  c1093
 G  c1094
 G  c1095
 G  c1096
 G  c1097
 G  c1098
 G  c1099
 G  c1100
 G  c1101
 G  c1102
 G  c1103
 G  c1104
 G  c1105
 G  c1106
 G  c1107
 G  c1108
 G  c1109
 G  c1110
 G  c1111
 G  c1112
 G  c1113
 G  c1114
 G  c1115
 G  c1116
 G  c1117
 G  c1118
 G  c1119
 G  c1120
 G  c1121
 G  c1122
 G  c1123
 G  c1124
 G  c1125
 G  c1126
 G  c1127
 G  c1128
 G  c1129
 G  c1130
 G  c1131
 G  c1132
 G  c1133
 G  c1134
 G  c1135
 G  c1136
 G  c1137
 G  c1138
 G  c1139
 G  c1140
 G  c1141
 G  c1142
 G  c1143
 G  c1144
 G  c1145
 G  c1146
 G  c1147
 G  c1148
 G  c1149
 G  c1150
 G  c1151
 G  c1152
 G  c1153
 G  c1154
 G  c1155
 G  c1156
 G  c1157
 G  c1158
 G  c1159
 G  c1160
 G  c1161
 G  c1162
 G  c1163
 G  c1164
 G  c1165
 G  c1166
 G  c1167
 G  c1168
 G  c1169
 G  c1170
 G  c1171
 G  c1172
 G  c1173
 G  c1174
 G  c1175
 G  c1176
 G  c1177
 G  c1178
 G  c1179
 G  c1180
 G  c1181
 G  c1182
 G  c1183
 G  c1184
 G  c1185
 G  c1186
 G  c1187
 G  c1188
 G  c1189
 G  c1190
 G  c1191
 G  c1192
 G  c1193
 G  c1194
 G  c1195
 G  c1196
 G  c1197
 G  c1198
 G  c1199
 G  c1200
 G  c1201
 G  c1202
 G  c1203
 G  c1204
 G  c1205
 G  c1206
 G  c1207
 G  c1208
 G  c1209
 G  c1210
 G  c1211
 G  c1212
 G  c1213
 G  c1214
 G  c1215
 G  c1216
 G  c1217
 G  c1218
 G  c1219
 G  c1220
 G  c1221
 G  c1222
 G  c1223
 G  c1224
 G  c1225
 G  c1226
 G  c1227
 G  c1228
 G  c1229
 G  c1230
 G  c1231
 G  c1232
 G  c1233
 G  c1234
 G  c1235
 G  c1236
 G  c1237
 G  c1238
 G  c1239
 G  c1240
 G  c1241
 G  c1242
 G  c1243
 G  c1244
 G  c1245
 G  c1246
 G  c1247
 G  c1248
 G  c1249
 G  c1250
 G  c1251
 G  c1252
 G  c1253
 G  c1254
 G  c1255
 G  c1256
 G  c1257
 G  c1258
 G  c1259
 G  c1260
 G  c1261
 G  c1262
 G  c1263
 G  c1264
 G  c1265
 G  c1266
 G  c1267
 G  c1268
 G  c1269
 G  c1270
 G  c1271
 G  c1272
 G  c1273
 G  c1274
 G  c1275
 G  c1276
 G  c1277
 G  c1278
 G  c1279
 G  c1280
 G  c1281
 G  c1282
 G  c1283
 G  c1284
 G  c1285
 G  c1286
 G  c1287
 G  c1288
 G  c1289
 G  c1290
 G  c1291
 G  c1292
 G  c1293
 G  c1294
 G  c1295
 G  c1296
 G  c1297
 G  c1298
 G  c1299
 G  c1300
 G  c1301
 G  c1302
 G  c1303
 G  c1304
 G  c1305
 G  c1306
 G  c1307
 G  c1308
 G  c1309
 G  c1310
 G  c1311
 G  c1312
 G  c1313
 G  c1314
 G  c1315
 G  c1316
 G  c1317
 G  c1318
 G  c1319
 G  c1320
 G  c1321
 G  c1322
 G  c1323
 G  c1324
 G  c1325
 G  c1326
 G  c1327
 G  c1328
 G  c1329
 G  c1330
 G  c1331
 G  c1332
 G  c1333
 G  c1334
 G  c1335
 G  c1336
 G  c1337
 G  c1338
 G  c1339
 G  c1340
 G  c1341
 G  c1342
 G  c1343
 G  c1344
 G  c1345
 G  c1346
 G  c1347
 G  c1348
 G  c1349
 G  c1350
 G  c1351
 G  c1352
 G  c1353
 G  c1354
 G  c1355
 G  c1356
 G  c1357
 G  c1358
 G  c1359
 G  c1360
 G  c1361
 G  c1362
 G  c1363
 G  c1364
 G  c1365
 G  c1366
 G  c1367
 G  c1368
 G  c1369
 G  c1370
 G  c1371
 G  c1372
 G  c1373
 G  c1374
 G  c1375
 G  c1376
 G  c1377
 G  c1378
 G  c1379
 G  c1380
 G  c1381
 G  c1382
 G  c1383
 G  c1384
 G  c1385
 G  c1386
 G  c1387
 G  c1388
 G  c1389
 G  c1390
 G  c1391
 G  c1392
 G  c1393
 G  c1394
 G  c1395
 G  c1396
 G  c1397
 G  c1398
 G  c1399
 G  c1400
 G  c1401
 G  c1402
 G  c1403
 G  c1404
 G  c1405
 G  c1406
 G  c1407
 G  c1408
 G  c1409
 G  c1410
 G  c1411
 G  c1412
 G  c1413
 G  c1414
 G  c1415
 G  c1416
 G  c1417
 G  c1418
 G  c1419
 G  c1420
 G  c1421
 G  c1422
 G  c1423
 G  c1424
 G  c1425
 G  c1426
 G  c1427
 G  c1428
 G  c1429
 G  c1430
 G  c1431
 G  c1432
 G  c1433
 G  c1434
 G  c1435
 G  c1436
 G  c1437
 G  c1438
 G  c1439
 G  c1440
 G  c1441
 G  c1442
 G  c1443
 G  c1444
 G  c1445
 G  c1446
 G  c1447
 G  c1448
 G  c1449
 G  c1450
 G  c1451
 G  c1452
 G  c1453
 G  c1454
 G  c1455
 G  c1456
 G  c1457
 G  c1458
 G  c1459
 G  c1460
 G  c1461
 G  c1462
 G  c1463
 G  c1464
 G  c1465
 G  c1466
 G  c1467
 G  c1468
 G  c1469
 G  c1470
 G  c1471
 G  c1472
 G  c1473
 G  c1474
 G  c1475
 G  c1476
 G  c1477
 G  c1478
 G  c1479
 G  c1480
 G  c1481
 G  c1482
 G  c1483
 G  c1484
 G  c1485
 G  c1486
 G  c1487
 G  c1488
 G  c1489
 G  c1490
 G  c1491
 G  c1492
 G  c1493
 G  c1494
 G  c1495
 G  c1496
 G  c1497
 G  c1498
 G  c1499
 G  c1500
 G  c1501
 G  c1502
 G  c1503
 G  c1504
 G  c1505
 G  c1506
 G  c1507
 G  c1508
 G  c1509
 G  c1510
 G  c1511
 G  c1512
 G  c1513
 G  c1514
 G  c1515
 G  c1516
 G  c1517
 G  c1518
 G  c1519
 G  c1520
 G  c1521
 G  c1522
 G  c1523
 G  c1524
 G  c1525
 G  c1526
 G  c1527
 G  c1528
 G  c1529
 G  c1530
 G  c1531
 G  c1532
 G  c1533
 G  c1534
 G  c1535
 G  c1536
 G  c1537
 G  c1538
 G  c1539
 G  c1540
 G  c1541
 G  c1542
 G  c1543
 G  c1544
 G  c1545
 G  c1546
 G  c1547
 G  c1548
 G  c1549
 G  c1550
 G  c1551
 G  c1552
 G  c1553
 G  c1554
 G  c1555
 G  c1556
 G  c1557
 G  c1558
 G  c1559
 G  c1560
 G  c1561
 G  c1562
 G  c1563
 G  c1564
 G  c1565
 G  c1566
 G  c1567
 G  c1568
 G  c1569
 G  c1570
 G  c1571
 G  c1572
 G  c1573
 G  c1574
 G  c1575
 G  c1576
 G  c1577
 G  c1578
 G  c1579
 G  c1580
 G  c1581
 G  c1582
 G  c1583
 G  c1584
 G  c1585
 G  c1586
 G  c1587
 G  c1588
 G  c1589
 G  c1590
 G  c1591
 G  c1592
 G  c1593
 G  c1594
 G  c1595
 G  c1596
 G  c1597
 G  c1598
 G  c1599
 G  c1600
 G  c1601
 G  c1602
 G  c1603
 G  c1604
 G  c1605
 G  c1606
 G  c1607
 G  c1608
 G  c1609
 G  c1610
 G  c1611
 G  c1612
 G  c1613
 G  c1614
 G  c1615
 G  c1616
 G  c1617
 G  c1618
 G  c1619
 G  c1620
 G  c1621
 G  c1622
 G  c1623
 G  c1624
 G  c1625
 G  c1626
 G  c1627
 G  c1628
 G  c1629
 G  c1630
 G  c1631
 G  c1632
 G  c1633
 G  c1634
 G  c1635
 G  c1636
 G  c1637
 G  c1638
 G  c1639
 G  c1640
 G  c1641
 G  c1642
 G  c1643
 G  c1644
 G  c1645
 G  c1646
 G  c1647
 G  c1648
 G  c1649
 G  c1650
 G  c1651
 G  c1652
 G  c1653
 G  c1654
 G  c1655
 G  c1656
 G  c1657
 G  c1658
 G  c1659
 G  c1660
 G  c1661
 G  c1662
 G  c1663
 G  c1664
 G  c1665
 G  c1666
 G  c1667
 G  c1668
 G  c1669
 G  c1670
 G  c1671
 G  c1672
 G  c1673
 G  c1674
 G  c1675
 G  c1676
 G  c1677
 G  c1678
 G  c1679
 G  c1680
 G  c1681
 G  c1682
 G  c1683
 G  c1684
 G  c1685
 G  c1686
 G  c1687
 G  c1688
 G  c1689
 G  c1690
 G  c1691
 G  c1692
 G  c1693
 G  c1694
 G  c1695
 G  c1696
 G  c1697
 G  c1698
 G  c1699
 G  c1700
 G  c1701
 G  c1702
 G  c1703
 G  c1704
 G  c1705
 G  c1706
 G  c1707
 G  c1708
 G  c1709
 G  c1710
 G  c1711
 G  c1712
 G  c1713
 G  c1714
 G  c1715
 G  c1716
 G  c1717
 G  c1718
 G  c1719
 G  c1720
 G  c1721
 G  c1722
 G  c1723
 G  c1724
 G  c1725
 G  c1726
 G  c1727
 G  c1728
 G  c1729
 G  c1730
 G  c1731
 G  c1732
 G  c1733
 G  c1734
 G  c1735
 G  c1736
 G  c1737
 G  c1738
 G  c1739
 G  c1740
 G  c1741
 G  c1742
 G  c1743
 G  c1744
 G  c1745
 G  c1746
 G  c1747
 G  c1748
 G  c1749
 G  c1750
 G  c1751
 G  c1752
 G  c1753
 G  c1754
 G  c1755
 G  c1756
 G  c1757
 G  c1758
 G  c1759
 G  c1760
 G  c1761
 G  c1762
 G  c1763
 G  c1764
 G  c1765
 G  c1766
 G  c1767
 G  c1768
 G  c1769
 G  c1770
 G  c1771
 G  c1772
 G  c1773
 G  c1774
 G  c1775
 G  c1776
 G  c1777
 G  c1778
 G  c1779
 G  c1780
 G  c1781
 G  c1782
 G  c1783
 G  c1784
 G  c1785
 G  c1786
 G  c1787
 G  c1788
 G  c1789
 G  c1790
 G  c1791
 G  c1792
 G  c1793
 G  c1794
 G  c1795
 G  c1796
 G  c1797
 G  c1798
 G  c1799
 G  c1800
 G  c1801
 G  c1802
 G  c1803
 G  c1804
 G  c1805
 G  c1806
 G  c1807
 G  c1808
 G  c1809
 G  c1810
 G  c1811
 G  c1812
 G  c1813
 G  c1814
 G  c1815
 G  c1816
 G  c1817
 G  c1818
 G  c1819
 G  c1820
 G  c1821
 G  c1822
 G  c1823
 G  c1824
 G  c1825
 G  c1826
 G  c1827
 G  c1828
 G  c1829
 G  c1830
 G  c1831
 G  c1832
 G  c1833
 G  c1834
 G  c1835
 G  c1836
 G  c1837
 G  c1838
 G  c1839
 G  c1840
 G  c1841
 G  c1842
 G  c1843
 G  c1844
 G  c1845
 G  c1846
 G  c1847
 G  c1848
 G  c1849
 G  c1850
 G  c1851
 G  c1852
 G  c1853
 G  c1854
 G  c1855
 G  c1856
 G  c1857
 G  c1858
 G  c1859
 G  c1860
 G  c1861
 G  c1862
 G  c1863
 G  c1864
 G  c1865
 G  c1866
 G  c1867
 G  c1868
 G  c1869
 G  c1870
 G  c1871
 G  c1872
 G  c1873
 G  c1874
 G  c1875
 G  c1876
 G  c1877
 G  c1878
 G  c1879
 G  c1880
 G  c1881
 G  c1882
 G  c1883
 G  c1884
 G  c1885
 G  c1886
 G  c1887
 G  c1888
 G  c1889
 G  c1890
 G  c1891
 G  c1892
 G  c1893
 G  c1894
 G  c1895
 G  c1896
 G  c1897
 G  c1898
 G  c1899
 G  c1900
 G  c1901
 G  c1902
 G  c1903
 G  c1904
 G  c1905
 G  c1906
 G  c1907
 G  c1908
 G  c1909
 G  c1910
 G  c1911
 G  c1912
 G  c1913
 G  c1914
 G  c1915
 G  c1916
 G  c1917
 G  c1918
 G  c1919
 G  c1920
 G  c1921
 G  c1922
 G  c1923
 G  c1924
 G  c1925
 G  c1926
 G  c1927
 G  c1928
 G  c1929
 G  c1930
 G  c1931
 G  c1932
 G  c1933
 G  c1934
 G  c1935
 G  c1936
 G  c1937
 G  c1938
 G  c1939
 G  c1940
 G  c1941
 G  c1942
 G  c1943
 G  c1944
 G  c1945
 G  c1946
 G  c1947
 G  c1948
 G  c1949
 G  c1950
 G  c1951
 G  c1952
 G  c1953
 G  c1954
 G  c1955
 G  c1956
 G  c1957
 G  c1958
 G  c1959
 G  c1960
 G  c1961
 G  c1962
 G  c1963
 G  c1964
 G  c1965
 G  c1966
 G  c1967
 G  c1968
 G  c1969
 G  c1970
 G  c1971
 G  c1972
 G  c1973
 G  c1974
 G  c1975
 G  c1976
 G  c1977
 G  c1978
 G  c1979
 G  c1980
 G  c1981
 G  c1982
 G  c1983
 G  c1984
 G  c1985
 G  c1986
 G  c1987
 G  c1988
 G  c1989
 G  c1990
 G  c1991
 G  c1992
 G  c1993
 G  c1994
 G  c1995
 G  c1996
 G  c1997
 G  c1998
 G  c1999
 G  c2000
 G  c2001
 G  c2002
 G  c2003
 G  c2004
 G  c2005
 G  c2006
 G  c2007
 G  c2008
 G  c2009
 G  c2010
 G  c2011
 G  c2012
 G  c2013
 G  c2014
 G  c2015
 G  c2016
 G  c2017
 G  c2018
 G  c2019
 G  c2020
 G  c2021
 G  c2022
 G  c2023
 G  c2024
 G  c2025
 G  c2026
 G  c2027
 G  c2028
 G  c2029
 G  c2030
 G  c2031
 G  c2032
 G  c2033
 G  c2034
 G  c2035
 G  c2036
 G  c2037
 G  c2038
 G  c2039
 G  c2040
 G  c2041
 G  c2042
 G  c2043
 G  c2044
 G  c2045
 G  c2046
 G  c2047
 G  c2048
 G  c2049
 G  c2050
 G  c2051
 G  c2052
 G  c2053
 G  c2054
 G  c2055
 G  c2056
 G  c2057
 G  c2058
 G  c2059
 G  c2060
 G  c2061
 G  c2062
 G  c2063
 G  c2064
 G  c2065
 G  c2066
 G  c2067
 G  c2068
 G  c2069
 G  c2070
 G  c2071
 G  c2072
 G  c2073
 G  c2074
 G  c2075
 G  c2076
 G  c2077
 G  c2078
 G  c2079
 G  c2080
 G  c2081
 G  c2082
 G  c2083
 G  c2084
 G  c2085
 G  c2086
 G  c2087
 G  c2088
 G  c2089
 G  c2090
 G  c2091
 G  c2092
 G  c2093
 G  c2094
 G  c2095
 G  c2096
 G  c2097
 G  c2098
 G  c2099
 G  c2100
 G  c2101
 G  c2102
 G  c2103
 G  c2104
 G  c2105
 G  c2106
 G  c2107
 G  c2108
 G  c2109
 G  c2110
 G  c2111
 G  c2112
 G  c2113
 G  c2114
 G  c2115
 G  c2116
 G  c2117
 G  c2118
 G  c2119
 G  c2120
 G  c2121
 G  c2122
 G  c2123
 G  c2124
 G  c2125
 G  c2126
 G  c2127
 G  c2128
 G  c2129
 G  c2130
 G  c2131
 G  c2132
 G  c2133
 G  c2134
 G  c2135
 G  c2136
 G  c2137
 G  c2138
 G  c2139
 G  c2140
 G  c2141
 G  c2142
 G  c2143
 G  c2144
 G  c2145
 G  c2146
 G  c2147
 G  c2148
 G  c2149
 G  c2150
 G  c2151
 G  c2152
 G  c2153
 G  c2154
 G  c2155
 G  c2156
 G  c2157
 G  c2158
 G  c2159
 G  c2160
 G  c2161
 G  c2162
 G  c2163
 G  c2164
 G  c2165
 G  c2166
 G  c2167
 G  c2168
 G  c2169
 G  c2170
 G  c2171
 G  c2172
 G  c2173
 G  c2174
 G  c2175
 G  c2176
 G  c2177
 G  c2178
 G  c2179
 G  c2180
 G  c2181
 G  c2182
 G  c2183
 G  c2184
 G  c2185
 G  c2186
 G  c2187
 G  c2188
 G  c2189
 G  c2190
 G  c2191
 G  c2192
 G  c2193
 G  c2194
 G  c2195
 G  c2196
 G  c2197
 G  c2198
 G  c2199
 G  c2200
 G  c2201
 G  c2202
 G  c2203
 G  c2204
 G  c2205
 G  c2206
 G  c2207
 G  c2208
 G  c2209
 G  c2210
 G  c2211
 G  c2212
 G  c2213
 G  c2214
 G  c2215
 G  c2216
 G  c2217
 G  c2218
 G  c2219
 G  c2220
 G  c2221
 G  c2222
 G  c2223
 G  c2224
 G  c2225
 G  c2226
 G  c2227
 G  c2228
 G  c2229
 G  c2230
 G  c2231
 G  c2232
 G  c2233
 G  c2234
 G  c2235
 G  c2236
 G  c2237
 G  c2238
 G  c2239
 G  c2240
 G  c2241
 G  c2242
 G  c2243
 G  c2244
 G  c2245
 G  c2246
 G  c2247
 G  c2248
 G  c2249
 G  c2250
 G  c2251
 G  c2252
 G  c2253
 G  c2254
 G  c2255
 G  c2256
 G  c2257
 G  c2258
 G  c2259
 G  c2260
 G  c2261
 G  c2262
 G  c2263
 G  c2264
 G  c2265
 G  c2266
 G  c2267
 G  c2268
 G  c2269
 G  c2270
 G  c2271
 G  c2272
 G  c2273
 G  c2274
 G  c2275
 G  c2276
 G  c2277
 G  c2278
 G  c2279
 G  c2280
 G  c2281
 G  c2282
 G  c2283
 G  c2284
 G  c2285
 G  c2286
 G  c2287
 G  c2288
 G  c2289
 G  c2290
 G  c2291
 G  c2292
 G  c2293
 G  c2294
 G  c2295
 G  c2296
 G  c2297
 G  c2298
 G  c2299
 G  c2300
 G  c2301
 G  c2302
 G  c2303
 G  c2304
 G  c2305
 G  c2306
 G  c2307
 G  c2308
 G  c2309
 G  c2310
 G  c2311
 G  c2312
 G  c2313
 G  c2314
 G  c2315
 G  c2316
 G  c2317
 G  c2318
 G  c2319
 G  c2320
 G  c2321
 G  c2322
 G  c2323
 G  c2324
 G  c2325
 G  c2326
 G  c2327
 G  c2328
 G  c2329
 G  c2330
 G  c2331
 G  c2332
 G  c2333
 G  c2334
 G  c2335
 G  c2336
 G  c2337
 G  c2338
 G  c2339
 G  c2340
 G  c2341
 G  c2342
 G  c2343
 G  c2344
 G  c2345
 G  c2346
 G  c2347
 G  c2348
 G  c2349
 G  c2350
 G  c2351
 G  c2352
 G  c2353
 G  c2354
 G  c2355
 G  c2356
 G  c2357
 G  c2358
 G  c2359
 G  c2360
 G  c2361
 G  c2362
 G  c2363
 G  c2364
 G  c2365
 G  c2366
 G  c2367
 G  c2368
 G  c2369
 G  c2370
 G  c2371
 G  c2372
 G  c2373
 G  c2374
 G  c2375
 G  c2376
 G  c2377
 G  c2378
 G  c2379
 G  c2380
 G  c2381
 G  c2382
 G  c2383
 G  c2384
 G  c2385
 G  c2386
 G  c2387
 G  c2388
 G  c2389
 G  c2390
 G  c2391
 G  c2392
 G  c2393
 G  c2394
 G  c2395
 G  c2396
 G  c2397
 G  c2398
 G  c2399
 G  c2400
 G  c2401
 G  c2402
 G  c2403
 G  c2404
 G  c2405
 G  c2406
 G  c2407
 G  c2408
 G  c2409
 G  c2410
 G  c2411
 G  c2412
 G  c2413
 G  c2414
 G  c2415
 G  c2416
 G  c2417
 G  c2418
 G  c2419
 G  c2420
 G  c2421
 G  c2422
 G  c2423
 G  c2424
 G  c2425
 G  c2426
 G  c2427
 G  c2428
 G  c2429
 G  c2430
 G  c2431
 G  c2432
 G  c2433
 G  c2434
 G  c2435
 G  c2436
 G  c2437
 G  c2438
 G  c2439
 G  c2440
 G  c2441
 G  c2442
 G  c2443
 G  c2444
 G  c2445
 G  c2446
 G  c2447
 G  c2448
 G  c2449
 G  c2450
 G  c2451
 G  c2452
 G  c2453
 G  c2454
 G  c2455
 G  c2456
 G  c2457
 G  c2458
 G  c2459
 G  c2460
 G  c2461
 G  c2462
 G  c2463
 G  c2464
 G  c2465
 G  c2466
 G  c2467
 G  c2468
 G  c2469
 G  c2470
 G  c2471
 G  c2472
 G  c2473
 G  c2474
 G  c2475
 G  c2476
 G  c2477
 G  c2478
 G  c2479
 G  c2480
 G  c2481
 G  c2482
 G  c2483
 G  c2484
 G  c2485
 G  c2486
 G  c2487
 G  c2488
 G  c2489
 G  c2490
 G  c2491
 G  c2492
 G  c2493
 G  c2494
 G  c2495
 G  c2496
 G  c2497
 G  c2498
 G  c2499
 G  c2500
 G  c2501
 G  c2502
 G  c2503
 G  c2504
 G  c2505
 G  c2506
 G  c2507
 G  c2508
 G  c2509
 G  c2510
 G  c2511
 G  c2512
 G  c2513
 G  c2514
 G  c2515
 G  c2516
 G  c2517
 G  c2518
 G  c2519
 G  c2520
 G  c2521
 G  c2522
 G  c2523
 G  c2524
 G  c2525
 G  c2526
 G  c2527
 G  c2528
 G  c2529
 G  c2530
 G  c2531
 G  c2532
 G  c2533
 G  c2534
 G  c2535
 G  c2536
 G  c2537
 G  c2538
 G  c2539
 G  c2540
 G  c2541
 G  c2542
 G  c2543
 G  c2544
 G  c2545
 G  c2546
 G  c2547
 G  c2548
 G  c2549
 G  c2550
 G  c2551
 G  c2552
 G  c2553
 G  c2554
 G  c2555
 G  c2556
 G  c2557
 G  c2558
 G  c2559
 G  c2560
 G  c2561
 G  c2562
 G  c2563
 G  c2564
 G  c2565
 G  c2566
 G  c2567
 G  c2568
 G  c2569
 G  c2570
 G  c2571
 G  c2572
 G  c2573
 G  c2574
 G  c2575
 G  c2576
 G  c2577
 G  c2578
 G  c2579
 G  c2580
 G  c2581
 G  c2582
 G  c2583
 G  c2584
 G  c2585
 G  c2586
 G  c2587
 G  c2588
 G  c2589
 G  c2590
 G  c2591
 G  c2592
 G  c2593
 G  c2594
 G  c2595
 G  c2596
 G  c2597
 G  c2598
 G  c2599
 G  c2600
 G  c2601
 G  c2602
 G  c2603
 G  c2604
 G  c2605
 G  c2606
 G  c2607
 G  c2608
 G  c2609
 G  c2610
 G  c2611
 G  c2612
 G  c2613
 G  c2614
 G  c2615
 G  c2616
 G  c2617
 G  c2618
 G  c2619
 G  c2620
 G  c2621
 G  c2622
 G  c2623
 G  c2624
 G  c2625
 G  c2626
 G  c2627
 G  c2628
 G  c2629
 G  c2630
 G  c2631
 G  c2632
 G  c2633
 G  c2634
 G  c2635
 G  c2636
 G  c2637
 G  c2638
 G  c2639
 G  c2640
 G  c2641
 G  c2642
 G  c2643
 G  c2644
 G  c2645
 G  c2646
 G  c2647
 G  c2648
 G  c2649
 G  c2650
 G  c2651
 G  c2652
 G  c2653
 G  c2654
 G  c2655
 G  c2656
 G  c2657
 G  c2658
 G  c2659
 G  c2660
 G  c2661
 G  c2662
 G  c2663
 G  c2664
 G  c2665
 G  c2666
 G  c2667
 G  c2668
 G  c2669
 G  c2670
 G  c2671
 G  c2672
 G  c2673
 G  c2674
 G  c2675
 G  c2676
 G  c2677
 G  c2678
 G  c2679
 G  c2680
 G  c2681
 G  c2682
 G  c2683
 G  c2684
 G  c2685
 G  c2686
 G  c2687
 G  c2688
 G  c2689
 G  c2690
 G  c2691
 G  c2692
 G  c2693
 G  c2694
 G  c2695
 G  c2696
 G  c2697
 G  c2698
 G  c2699
 G  c2700
 G  c2701
 G  c2702
 G  c2703
 G  c2704
 G  c2705
 G  c2706
 G  c2707
 G  c2708
 G  c2709
 G  c2710
 G  c2711
 G  c2712
 G  c2713
 G  c2714
 G  c2715
 G  c2716
 G  c2717
 G  c2718
 G  c2719
 G  c2720
 G  c2721
 G  c2722
 G  c2723
 G  c2724
 G  c2725
 G  c2726
 G  c2727
 G  c2728
 G  c2729
 G  c2730
 G  c2731
 G  c2732
 G  c2733
 G  c2734
 G  c2735
 G  c2736
 G  c2737
 G  c2738
 G  c2739
 G  c2740
 G  c2741
 G  c2742
 G  c2743
 G  c2744
 G  c2745
 G  c2746
 G  c2747
 G  c2748
 G  c2749
 G  c2750
 G  c2751
 G  c2752
 G  c2753
 G  c2754
 G  c2755
 G  c2756
 G  c2757
 G  c2758
 G  c2759
 G  c2760
 G  c2761
 G  c2762
 G  c2763
 G  c2764
 G  c2765
 G  c2766
 G  c2767
 G  c2768
 G  c2769
 G  c2770
 G  c2771
 G  c2772
 G  c2773
 G  c2774
 G  c2775
 G  c2776
 G  c2777
 G  c2778
 G  c2779
 G  c2780
 G  c2781
 G  c2782
 G  c2783
 G  c2784
 G  c2785
 G  c2786
 G  c2787
 G  c2788
 G  c2789
 G  c2790
 G  c2791
 G  c2792
 G  c2793
 G  c2794
 G  c2795
 G  c2796
 G  c2797
 G  c2798
 G  c2799
 G  c2800
 G  c2801
 G  c2802
 G  c2803
 G  c2804
 G  c2805
 G  c2806
 G  c2807
 G  c2808
 G  c2809
 G  c2810
 G  c2811
 G  c2812
 G  c2813
 G  c2814
 G  c2815
 G  c2816
 G  c2817
 G  c2818
 G  c2819
 G  c2820
 G  c2821
 G  c2822
 G  c2823
 G  c2824
 G  c2825
 G  c2826
 G  c2827
 G  c2828
 G  c2829
 G  c2830
 G  c2831
 G  c2832
 G  c2833
 G  c2834
 G  c2835
 G  c2836
 G  c2837
 G  c2838
 G  c2839
 G  c2840
 G  c2841
 G  c2842
 G  c2843
 G  c2844
 G  c2845
 G  c2846
 G  c2847
 G  c2848
 G  c2849
 G  c2850
 G  c2851
 G  c2852
 G  c2853
 G  c2854
 G  c2855
 G  c2856
 G  c2857
 G  c2858
 G  c2859
 G  c2860
 G  c2861
 G  c2862
 G  c2863
 G  c2864
 G  c2865
 G  c2866
 G  c2867
 G  c2868
 G  c2869
 G  c2870
 G  c2871
 G  c2872
 G  c2873
 G  c2874
 G  c2875
 G  c2876
 G  c2877
 G  c2878
 G  c2879
 G  c2880
 G  c2881
 G  c2882
 G  c2883
 G  c2884
 G  c2885
 G  c2886
 G  c2887
 G  c2888
 G  c2889
 G  c2890
 G  c2891
 G  c2892
 G  c2893
 G  c2894
 G  c2895
 G  c2896
 G  c2897
 G  c2898
 G  c2899
 G  c2900
 G  c2901
 G  c2902
 G  c2903
 G  c2904
 G  c2905
 G  c2906
 G  c2907
 G  c2908
 G  c2909
 G  c2910
 G  c2911
 G  c2912
 G  c2913
 G  c2914
 G  c2915
 G  c2916
 G  c2917
 G  c2918
 G  c2919
 G  c2920
 G  c2921
 G  c2922
 G  c2923
 G  c2924
 G  c2925
 G  c2926
 G  c2927
 G  c2928
 G  c2929
 G  c2930
 G  c2931
 G  c2932
 G  c2933
 G  c2934
 G  c2935
 G  c2936
 G  c2937
 G  c2938
 G  c2939
 G  c2940
 G  c2941
 G  c2942
 G  c2943
 G  c2944
 G  c2945
 G  c2946
 G  c2947
 G  c2948
 G  c2949
 G  c2950
 G  c2951
 G  c2952
 G  c2953
 G  c2954
 G  c2955
 G  c2956
 G  c2957
 G  c2958
 G  c2959
 G  c2960
 G  c2961
 G  c2962
 G  c2963
 G  c2964
 G  c2965
 G  c2966
 G  c2967
 G  c2968
 G  c2969
 G  c2970
 G  c2971
 G  c2972
 G  c2973
 G  c2974
 G  c2975
 G  c2976
 G  c2977
 G  c2978
 G  c2979
 G  c2980
 G  c2981
 G  c2982
 G  c2983
 G  c2984
 G  c2985
 G  c2986
 G  c2987
 G  c2988
 G  c2989
 G  c2990
 G  c2991
 G  c2992
 G  c2993
 G  c2994
 G  c2995
 G  c2996
 G  c2997
 G  c2998
 G  c2999
 G  c3000
 G  c3001
 G  c3002
 G  c3003
 G  c3004
 G  c3005
 G  c3006
 G  c3007
 G  c3008
 G  c3009
 G  c3010
 G  c3011
 G  c3012
 G  c3013
 G  c3014
 G  c3015
 G  c3016
 G  c3017
 G  c3018
 G  c3019
 G  c3020
 G  c3021
 G  c3022
 G  c3023
 G  c3024
 G  c3025
 G  c3026
 G  c3027
 G  c3028
 G  c3029
 G  c3030
 G  c3031
 G  c3032
 G  c3033
 G  c3034
 G  c3035
 G  c3036
 G  c3037
 G  c3038
 G  c3039
 G  c3040
 G  c3041
 G  c3042
 G  c3043
 G  c3044
 G  c3045
 G  c3046
 G  c3047
 G  c3048
 G  c3049
 G  c3050
 G  c3051
 G  c3052
 G  c3053
 G  c3054
 G  c3055
 G  c3056
 G  c3057
 G  c3058
 G  c3059
 G  c3060
 G  c3061
 G  c3062
 G  c3063
 G  c3064
 G  c3065
 G  c3066
 G  c3067
 G  c3068
 G  c3069
 G  c3070
 G  c3071
 G  c3072
 G  c3073
 G  c3074
 G  c3075
 G  c3076
 G  c3077
 G  c3078
 G  c3079
 G  c3080
 G  c3081
 G  c3082
 G  c3083
 G  c3084
 G  c3085
 G  c3086
 G  c3087
 G  c3088
 G  c3089
 G  c3090
 G  c3091
 G  c3092
 G  c3093
 G  c3094
 G  c3095
 G  c3096
 G  c3097
 G  c3098
 G  c3099
 G  c3100
 G  c3101
 G  c3102
 G  c3103
 G  c3104
 G  c3105
 G  c3106
 G  c3107
 G  c3108
 G  c3109
 G  c3110
 G  c3111
 G  c3112
 G  c3113
 G  c3114
 G  c3115
 G  c3116
 G  c3117
 G  c3118
 G  c3119
 G  c3120
 G  c3121
 G  c3122
 G  c3123
 G  c3124
 G  c3125
 G  c3126
 G  c3127
 G  c3128
 G  c3129
 G  c3130
 G  c3131
 G  c3132
 G  c3133
 G  c3134
 G  c3135
 G  c3136
 G  c3137
 G  c3138
 G  c3139
 G  c3140
 G  c3141
 G  c3142
 G  c3143
 G  c3144
 G  c3145
 G  c3146
 G  c3147
 G  c3148
 G  c3149
 G  c3150
 G  c3151
 G  c3152
 G  c3153
 G  c3154
 G  c3155
 G  c3156
 G  c3157
 G  c3158
 G  c3159
 G  c3160
 G  c3161
 G  c3162
 G  c3163
 G  c3164
 G  c3165
 G  c3166
 G  c3167
 G  c3168
 G  c3169
 G  c3170
 G  c3171
 G  c3172
 G  c3173
 G  c3174
 G  c3175
 G  c3176
 G  c3177
 G  c3178
 G  c3179
 G  c3180
 G  c3181
 G  c3182
 G  c3183
 G  c3184
 G  c3185
 G  c3186
 G  c3187
 G  c3188
 G  c3189
 G  c3190
 G  c3191
 G  c3192
 G  c3193
 G  c3194
 G  c3195
 G  c3196
 G  c3197
 G  c3198
 G  c3199
 G  c3200
 G  c3201
 G  c3202
 G  c3203
 G  c3204
 G  c3205
 G  c3206
 G  c3207
 G  c3208
 G  c3209
 G  c3210
 G  c3211
 G  c3212
 G  c3213
 G  c3214
 G  c3215
 G  c3216
 G  c3217
 G  c3218
 G  c3219
 G  c3220
 G  c3221
 G  c3222
 G  c3223
 G  c3224
 G  c3225
 G  c3226
 G  c3227
 G  c3228
 G  c3229
 G  c3230
 G  c3231
 G  c3232
 G  c3233
 G  c3234
 G  c3235
 G  c3236
 G  c3237
 G  c3238
 G  c3239
 G  c3240
 G  c3241
 G  c3242
 G  c3243
 G  c3244
 G  c3245
 G  c3246
 G  c3247
 G  c3248
 G  c3249
 G  c3250
 G  c3251
 G  c3252
 G  c3253
 G  c3254
 G  c3255
 G  c3256
 G  c3257
 G  c3258
 G  c3259
 G  c3260
 G  c3261
 G  c3262
 G  c3263
 G  c3264
 G  c3265
 G  c3266
 G  c3267
 G  c3268
 G  c3269
 G  c3270
 G  c3271
 G  c3272
 G  c3273
 G  c3274
 G  c3275
 G  c3276
 G  c3277
 G  c3278
 G  c3279
 G  c3280
 G  c3281
 G  c3282
 G  c3283
 G  c3284
 G  c3285
 G  c3286
 G  c3287
 G  c3288
 G  c3289
 G  c3290
 G  c3291
 G  c3292
 G  c3293
 G  c3294
 G  c3295
 G  c3296
 G  c3297
 G  c3298
 G  c3299
 G  c3300
 G  c3301
 G  c3302
 G  c3303
 G  c3304
 G  c3305
 G  c3306
 G  c3307
 G  c3308
 G  c3309
 G  c3310
 G  c3311
 G  c3312
 G  c3313
 G  c3314
 G  c3315
 G  c3316
 G  c3317
 G  c3318
 G  c3319
 G  c3320
 G  c3321
 G  c3322
 G  c3323
 G  c3324
 G  c3325
 G  c3326
 G  c3327
 G  c3328
 G  c3329
 G  c3330
 G  c3331
 G  c3332
 G  c3333
 G  c3334
 G  c3335
 G  c3336
 G  c3337
 G  c3338
 G  c3339
 G  c3340
 G  c3341
 G  c3342
 G  c3343
 G  c3344
 G  c3345
 G  c3346
 G  c3347
 G  c3348
 G  c3349
 G  c3350
 G  c3351
 G  c3352
 G  c3353
 G  c3354
 G  c3355
 G  c3356
 G  c3357
 G  c3358
 G  c3359
 G  c3360
 G  c3361
 G  c3362
 G  c3363
 G  c3364
 G  c3365
 G  c3366
 G  c3367
 G  c3368
 G  c3369
 G  c3370
 G  c3371
 G  c3372
 G  c3373
 G  c3374
 G  c3375
 G  c3376
 G  c3377
 G  c3378
 G  c3379
 G  c3380
 G  c3381
 G  c3382
 G  c3383
 G  c3384
 G  c3385
 G  c3386
 G  c3387
 G  c3388
 G  c3389
 G  c3390
 G  c3391
 G  c3392
 G  c3393
 G  c3394
 G  c3395
 G  c3396
 G  c3397
 G  c3398
 G  c3399
 G  c3400
 G  c3401
 G  c3402
 G  c3403
 G  c3404
 G  c3405
 G  c3406
 G  c3407
 G  c3408
 G  c3409
 G  c3410
 G  c3411
 G  c3412
 G  c3413
 G  c3414
 G  c3415
 G  c3416
 G  c3417
 G  c3418
 G  c3419
 G  c3420
 G  c3421
 G  c3422
 G  c3423
 G  c3424
 G  c3425
 G  c3426
 G  c3427
 G  c3428
 G  c3429
 G  c3430
 G  c3431
 G  c3432
 G  c3433
 G  c3434
 G  c3435
 G  c3436
 G  c3437
 G  c3438
 G  c3439
 G  c3440
 G  c3441
 G  c3442
 G  c3443
 G  c3444
 G  c3445
 G  c3446
 G  c3447
 G  c3448
 G  c3449
 G  c3450
 G  c3451
 G  c3452
 G  c3453
 G  c3454
 G  c3455
 G  c3456
 G  c3457
 G  c3458
 G  c3459
 G  c3460
 G  c3461
 G  c3462
 G  c3463
 G  c3464
 G  c3465
 G  c3466
 G  c3467
 G  c3468
 G  c3469
 G  c3470
 G  c3471
 G  c3472
 G  c3473
 G  c3474
 G  c3475
 G  c3476
 G  c3477
 G  c3478
 G  c3479
 G  c3480
 G  c3481
 G  c3482
 G  c3483
 G  c3484
 G  c3485
 G  c3486
 G  c3487
 G  c3488
 G  c3489
 G  c3490
 G  c3491
 G  c3492
 G  c3493
 G  c3494
 G  c3495
 G  c3496
 G  c3497
 G  c3498
 G  c3499
 G  c3500
 G  c3501
 G  c3502
 G  c3503
 G  c3504
 G  c3505
 G  c3506
 G  c3507
 G  c3508
 G  c3509
 G  c3510
 G  c3511
 G  c3512
 G  c3513
 G  c3514
 G  c3515
 G  c3516
 G  c3517
 G  c3518
 G  c3519
 G  c3520
 G  c3521
 G  c3522
 G  c3523
 G  c3524
 G  c3525
 G  c3526
 G  c3527
 G  c3528
 G  c3529
 G  c3530
 G  c3531
 G  c3532
 G  c3533
 G  c3534
 G  c3535
 G  c3536
 G  c3537
 G  c3538
 G  c3539
 G  c3540
 G  c3541
 G  c3542
 G  c3543
 G  c3544
 G  c3545
 G  c3546
 G  c3547
 G  c3548
 G  c3549
 G  c3550
 G  c3551
 G  c3552
 G  c3553
 G  c3554
 G  c3555
 G  c3556
 G  c3557
 G  c3558
 G  c3559
 G  c3560
 G  c3561
 G  c3562
 G  c3563
 G  c3564
 G  c3565
 G  c3566
 G  c3567
 G  c3568
 G  c3569
 G  c3570
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c1_2      -93
    x[1]      c2_2      93
    x[1]      c72_2     1
    x[1]      c74_2     1
    x[1]      c76_2     1
    x[1]      c78_2     1
    x[1]      c936_1    -1
    x[1]      c937_1    -1
    x[1]      c938_1    -1
    x[1]      c939_1    -1
    x[1]      c940_1    -1
    x[1]      c941_1    -1
    x[1]      c942_1    -1
    x[1]      c943_1    -1
    x[1]      c944_1    -1
    x[1]      c945_1    -1
    x[1]      c946_1    -1
    x[1]      c947_1    -1
    x[1]      c948_1    -1
    x[1]      c949_1    -1
    x[1]      c950_1    -1
    x[1]      c951_1    -1
    x[1]      c952_1    -1
    x[1]      c953_1    -1
    x[1]      c954_1    -1
    x[1]      c955_1    -1
    x[1]      c956_1    -1
    x[1]      c957_1    -1
    x[1]      c958_1    -1
    x[1]      c959_1    -1
    x[1]      c1_1      93
    x[1]      c3_1      -93
    x[1]      c7_1      93
    x[1]      c9_1      -93
    x[1]      c13_1     93
    x[1]      c15_1     -93
    x[1]      c19_1     93
    x[1]      c21_1     -93
    x[1]      c25_1     93
    x[1]      c27_1     -93
    x[1]      c31_1     93
    x[1]      c33_1     -93
    x[1]      c37_1     93
    x[1]      c39_1     -93
    x[1]      c43_1     93
    x[1]      c45_1     -93
    x[1]      c49_1     93
    x[1]      c51_1     -93
    x[1]      c55_1     93
    x[1]      c57_1     -93
    x[1]      c61_1     93
    x[1]      c63_1     -93
    x[1]      c67_1     93
    x[1]      c69_1     -93
    x[1]      c73_1     93
    x[1]      c75_1     -93
    x[1]      c79_1     93
    x[1]      c81_1     -93
    x[1]      c85_1     93
    x[1]      c87_1     -93
    x[1]      c91_1     93
    x[1]      c93_1     -93
    x[1]      c97_1     93
    x[1]      c99_1     -93
    x[1]      c103_1    93
    x[1]      c105_1    -93
    x[1]      c109_1    93
    x[1]      c111_1    -93
    x[1]      c115_1    93
    x[1]      c117_1    -93
    x[1]      c121_1    93
    x[1]      c123_1    -93
    x[1]      c127_1    93
    x[1]      c129_1    -93
    x[1]      c133_1    93
    x[1]      c135_1    -93
    x[1]      c139_1    93
    x[1]      c141_1    -93
    x[1]      c145_1    93
    x[1]      c147_1    -93
    x[1]      c151_1    93
    x[1]      c153_1    -93
    x[1]      c157_1    93
    x[1]      c159_1    -93
    x[1]      c163_1    93
    x[1]      c165_1    -93
    x[1]      c169_1    93
    x[1]      c171_1    -93
    x[1]      c175_1    93
    x[1]      c177_1    -93
    x[1]      c181_1    93
    x[1]      c183_1    -93
    x[1]      c187_1    93
    x[1]      c189_1    -93
    x[1]      c193_1    93
    x[1]      c195_1    -93
    x[1]      c199_1    93
    x[1]      c201_1    -93
    x[2]      c3_2      -93
    x[2]      c4_2      93
    x[2]      c72_2     -1
    x[2]      c110_2    1
    x[2]      c112_2    1
    x[2]      c114_2    1
    x[2]      c960_1    -1
    x[2]      c961_1    -1
    x[2]      c962_1    -1
    x[2]      c963_1    -1
    x[2]      c964_1    -1
    x[2]      c965_1    -1
    x[2]      c966_1    -1
    x[2]      c967_1    -1
    x[2]      c968_1    -1
    x[2]      c969_1    -1
    x[2]      c970_1    -1
    x[2]      c971_1    -1
    x[2]      c972_1    -1
    x[2]      c973_1    -1
    x[2]      c974_1    -1
    x[2]      c975_1    -1
    x[2]      c976_1    -1
    x[2]      c977_1    -1
    x[2]      c978_1    -1
    x[2]      c979_1    -1
    x[2]      c980_1    -1
    x[2]      c981_1    -1
    x[2]      c982_1    -1
    x[2]      c983_1    -1
    x[2]      c2_1      -93
    x[2]      c6_1      93
    x[2]      c205_1    93
    x[2]      c207_1    -93
    x[2]      c211_1    93
    x[2]      c213_1    -93
    x[2]      c217_1    93
    x[2]      c219_1    -93
    x[2]      c223_1    93
    x[2]      c225_1    -93
    x[2]      c229_1    93
    x[2]      c231_1    -93
    x[2]      c235_1    93
    x[2]      c237_1    -93
    x[2]      c241_1    93
    x[2]      c243_1    -93
    x[2]      c247      93
    x[2]      c249      -93
    x[2]      c253      93
    x[2]      c255      -93
    x[2]      c259      93
    x[2]      c261      -93
    x[2]      c265      93
    x[2]      c267      -93
    x[2]      c271      93
    x[2]      c273      -93
    x[2]      c277      93
    x[2]      c279      -93
    x[2]      c283      93
    x[2]      c285      -93
    x[2]      c289      93
    x[2]      c291      -93
    x[2]      c295      93
    x[2]      c297      -93
    x[2]      c301      93
    x[2]      c303      -93
    x[2]      c307      93
    x[2]      c309      -93
    x[2]      c313      93
    x[2]      c315      -93
    x[2]      c319      93
    x[2]      c321      -93
    x[2]      c325      93
    x[2]      c327      -93
    x[2]      c331      93
    x[2]      c333      -93
    x[2]      c337      93
    x[2]      c339      -93
    x[2]      c343      93
    x[2]      c345      -93
    x[2]      c349      93
    x[2]      c351      -93
    x[2]      c355      93
    x[2]      c357      -93
    x[2]      c361      93
    x[2]      c363      -93
    x[2]      c367      93
    x[2]      c369      -93
    x[2]      c373      93
    x[2]      c375      -93
    x[2]      c379      93
    x[2]      c381      -93
    x[2]      c385      93
    x[2]      c387      -93
    x[2]      c391      93
    x[2]      c393      -93
    x[2]      c397      93
    x[2]      c399      -93
    x[3]      c5_2      -93
    x[3]      c6_2      93
    x[3]      c74_2     -1
    x[3]      c110_2    -1
    x[3]      c146_2    1
    x[3]      c148_2    1
    x[3]      c8_1      -93
    x[3]      c12_1     93
    x[3]      c206_1    -93
    x[3]      c210_1    93
    x[3]      c403      93
    x[3]      c405      -93
    x[3]      c409      93
    x[3]      c411      -93
    x[3]      c415      93
    x[3]      c417      -93
    x[3]      c421      93
    x[3]      c423      -93
    x[3]      c427      93
    x[3]      c429      -93
    x[3]      c433      93
    x[3]      c435      -93
    x[3]      c439      93
    x[3]      c441      -93
    x[3]      c445      93
    x[3]      c447      -93
    x[3]      c451      93
    x[3]      c453      -93
    x[3]      c457      93
    x[3]      c459      -93
    x[3]      c463      93
    x[3]      c465      -93
    x[3]      c469      93
    x[3]      c471      -93
    x[3]      c475      93
    x[3]      c477      -93
    x[3]      c481      93
    x[3]      c483      -93
    x[3]      c487      93
    x[3]      c489      -93
    x[3]      c493      93
    x[3]      c495      -93
    x[3]      c499      93
    x[3]      c501      -93
    x[3]      c505      93
    x[3]      c507      -93
    x[3]      c511      93
    x[3]      c513      -93
    x[3]      c517      93
    x[3]      c519      -93
    x[3]      c523      93
    x[3]      c525      -93
    x[3]      c529      93
    x[3]      c531      -93
    x[3]      c535      93
    x[3]      c537      -93
    x[3]      c541      93
    x[3]      c543      -93
    x[3]      c547      93
    x[3]      c549      -93
    x[3]      c553      93
    x[3]      c555      -93
    x[3]      c559      93
    x[3]      c561      -93
    x[3]      c565      93
    x[3]      c567      -93
    x[3]      c571      93
    x[3]      c573      -93
    x[3]      c577      93
    x[3]      c579      -93
    x[3]      c583      93
    x[3]      c585      -93
    x[3]      c589      93
    x[3]      c591      -93
    x[4]      c7_2      -93
    x[4]      c8_2      93
    x[4]      c76_2     -1
    x[4]      c112_2    -1
    x[4]      c146_2    -1
    x[4]      c180_2    1
    x[4]      c14_1     -93
    x[4]      c18_1     93
    x[4]      c212_1    -93
    x[4]      c216_1    93
    x[4]      c404      -93
    x[4]      c408      93
    x[4]      c595      93
    x[4]      c597      -93
    x[4]      c601      93
    x[4]      c603      -93
    x[4]      c607      93
    x[4]      c609      -93
    x[4]      c613      93
    x[4]      c615      -93
    x[4]      c619      93
    x[4]      c621      -93
    x[4]      c625      93
    x[4]      c627      -93
    x[4]      c631      93
    x[4]      c633      -93
    x[4]      c637      93
    x[4]      c639      -93
    x[4]      c643      93
    x[4]      c645      -93
    x[4]      c649      93
    x[4]      c651      -93
    x[4]      c655      93
    x[4]      c657      -93
    x[4]      c661      93
    x[4]      c663      -93
    x[4]      c667      93
    x[4]      c669      -93
    x[4]      c673      93
    x[4]      c675      -93
    x[4]      c679      93
    x[4]      c681      -93
    x[4]      c685      93
    x[4]      c687      -93
    x[4]      c691      93
    x[4]      c693      -93
    x[4]      c697      93
    x[4]      c699      -93
    x[4]      c703      93
    x[4]      c705      -93
    x[4]      c709      93
    x[4]      c711      -93
    x[4]      c715      93
    x[4]      c717      -93
    x[4]      c721      93
    x[4]      c723      -93
    x[4]      c727      93
    x[4]      c729      -93
    x[4]      c733      93
    x[4]      c735      -93
    x[4]      c739      93
    x[4]      c741      -93
    x[4]      c745      93
    x[4]      c747      -93
    x[4]      c751      93
    x[4]      c753      -93
    x[4]      c757      93
    x[4]      c759      -93
    x[4]      c763      93
    x[4]      c765      -93
    x[4]      c769      93
    x[4]      c771      -93
    x[4]      c775      93
    x[4]      c777      -93
    x[5]      c9_2      -93
    x[5]      c10_2     93
    x[5]      c78_2     -1
    x[5]      c114_2    -1
    x[5]      c148_2    -1
    x[5]      c180_2    -1
    x[5]      c20_1     -93
    x[5]      c24_1     93
    x[5]      c218_1    -93
    x[5]      c222_1    93
    x[5]      c410      -93
    x[5]      c414      93
    x[5]      c596      -93
    x[5]      c600      93
    x[5]      c781      93
    x[5]      c783      -93
    x[5]      c787      93
    x[5]      c789      -93
    x[5]      c793      93
    x[5]      c795      -93
    x[5]      c799      93
    x[5]      c801      -93
    x[5]      c805      93
    x[5]      c807      -93
    x[5]      c811      93
    x[5]      c813      -93
    x[5]      c817      93
    x[5]      c819      -93
    x[5]      c823      93
    x[5]      c825      -93
    x[5]      c829      93
    x[5]      c831      -93
    x[5]      c835      93
    x[5]      c837      -93
    x[5]      c841      93
    x[5]      c843      -93
    x[5]      c847      93
    x[5]      c849      -93
    x[5]      c853      93
    x[5]      c855      -93
    x[5]      c859      93
    x[5]      c861      -93
    x[5]      c865      93
    x[5]      c867      -93
    x[5]      c871      93
    x[5]      c873      -93
    x[5]      c877      93
    x[5]      c879      -93
    x[5]      c883      93
    x[5]      c885      -93
    x[5]      c889      93
    x[5]      c891      -93
    x[5]      c895      93
    x[5]      c897      -93
    x[5]      c901      93
    x[5]      c903      -93
    x[5]      c907      93
    x[5]      c909      -93
    x[5]      c913      93
    x[5]      c915      -93
    x[5]      c919      93
    x[5]      c921      -93
    x[5]      c925      93
    x[5]      c927      -93
    x[5]      c931      93
    x[5]      c933      -93
    x[5]      c937      93
    x[5]      c939      -93
    x[5]      c943      93
    x[5]      c945      -93
    x[5]      c949      93
    x[5]      c951      -93
    x[5]      c955      93
    x[5]      c957      -93
    x[6]      c11_2     -20
    x[6]      c12_2     20
    x[6]      c242_2    1
    x[6]      c244_1    1
    x[6]      c246_1    1
    x[6]      c248_1    1
    x[6]      c250_1    1
    x[6]      c252_1    1
    x[6]      c254_1    1
    x[6]      c256_1    1
    x[6]      c258_1    1
    x[6]      c260_1    1
    x[6]      c262_1    1
    x[6]      c264_1    1
    x[6]      c266_1    1
    x[6]      c268_1    1
    x[6]      c270_1    1
    x[6]      c272_1    1
    x[6]      c274_1    1
    x[6]      c276_1    1
    x[6]      c278_1    1
    x[6]      c26_1     -20
    x[6]      c30_1     20
    x[6]      c224_1    -20
    x[6]      c228_1    20
    x[6]      c416      -20
    x[6]      c420      20
    x[6]      c602      -20
    x[6]      c606      20
    x[6]      c782      -20
    x[6]      c786      20
    x[6]      c961      20
    x[6]      c963      -20
    x[6]      c967      20
    x[6]      c969      -20
    x[6]      c973      20
    x[6]      c975      -20
    x[6]      c979      20
    x[6]      c981      -20
    x[6]      c985      20
    x[6]      c987      -20
    x[6]      c991      20
    x[6]      c993      -20
    x[6]      c997      20
    x[6]      c999      -20
    x[6]      c1003     20
    x[6]      c1005     -20
    x[6]      c1009     20
    x[6]      c1011     -20
    x[6]      c1015     20
    x[6]      c1017     -20
    x[6]      c1021     20
    x[6]      c1023     -20
    x[6]      c1027     20
    x[6]      c1029     -20
    x[6]      c1033     20
    x[6]      c1035     -20
    x[6]      c1039     20
    x[6]      c1041     -20
    x[6]      c1045     20
    x[6]      c1047     -20
    x[6]      c1051     20
    x[6]      c1053     -20
    x[6]      c1057     20
    x[6]      c1059     -20
    x[6]      c1063     20
    x[6]      c1065     -20
    x[6]      c1069     20
    x[6]      c1071     -20
    x[6]      c1075     20
    x[6]      c1077     -20
    x[6]      c1081     20
    x[6]      c1083     -20
    x[6]      c1087     20
    x[6]      c1089     -20
    x[6]      c1093     20
    x[6]      c1095     -20
    x[6]      c1099     20
    x[6]      c1101     -20
    x[6]      c1105     20
    x[6]      c1107     -20
    x[6]      c1111     20
    x[6]      c1113     -20
    x[6]      c1117     20
    x[6]      c1119     -20
    x[6]      c1123     20
    x[6]      c1125     -20
    x[6]      c1129     20
    x[6]      c1131     -20
    x[7]      c13_2     -20
    x[7]      c14_2     20
    x[7]      c242_2    -1
    x[7]      c290_1    1
    x[7]      c292_1    1
    x[7]      c294_1    1
    x[7]      c296_1    1
    x[7]      c298_1    1
    x[7]      c300_1    1
    x[7]      c302_1    1
    x[7]      c304_1    1
    x[7]      c306_1    1
    x[7]      c308_1    1
    x[7]      c310_1    1
    x[7]      c312_1    1
    x[7]      c314_1    1
    x[7]      c316_1    1
    x[7]      c318_1    1
    x[7]      c320_1    1
    x[7]      c322_1    1
    x[7]      c324_1    1
    x[7]      c32_1     -20
    x[7]      c36_1     20
    x[7]      c230_1    -20
    x[7]      c234_1    20
    x[7]      c422      -20
    x[7]      c426      20
    x[7]      c608      -20
    x[7]      c612      20
    x[7]      c788      -20
    x[7]      c792      20
    x[7]      c962      -20
    x[7]      c966      20
    x[7]      c1135     20
    x[7]      c1137     -20
    x[7]      c1141     20
    x[7]      c1143     -20
    x[7]      c1147     20
    x[7]      c1149     -20
    x[7]      c1153     20
    x[7]      c1155     -20
    x[7]      c1159     20
    x[7]      c1161     -20
    x[7]      c1165     20
    x[7]      c1167     -20
    x[7]      c1171     20
    x[7]      c1173     -20
    x[7]      c1177     20
    x[7]      c1179     -20
    x[7]      c1183     20
    x[7]      c1185     -20
    x[7]      c1189     20
    x[7]      c1191     -20
    x[7]      c1195     20
    x[7]      c1197     -20
    x[7]      c1201     20
    x[7]      c1203     -20
    x[7]      c1207     20
    x[7]      c1209     -20
    x[7]      c1213     20
    x[7]      c1215     -20
    x[7]      c1219     20
    x[7]      c1221     -20
    x[7]      c1225     20
    x[7]      c1227     -20
    x[7]      c1231     20
    x[7]      c1233     -20
    x[7]      c1237     20
    x[7]      c1239     -20
    x[7]      c1243     20
    x[7]      c1245     -20
    x[7]      c1249     20
    x[7]      c1251     -20
    x[7]      c1255     20
    x[7]      c1257     -20
    x[7]      c1261     20
    x[7]      c1263     -20
    x[7]      c1267     20
    x[7]      c1269     -20
    x[7]      c1273     20
    x[7]      c1275     -20
    x[7]      c1279     20
    x[7]      c1281     -20
    x[7]      c1285     20
    x[7]      c1287     -20
    x[7]      c1291     20
    x[7]      c1293     -20
    x[7]      c1297     20
    x[7]      c1299     -20
    x[8]      c15_2     -20
    x[8]      c16_2     20
    x[8]      c244_1    -1
    x[8]      c290_1    -1
    x[8]      c336_1    1
    x[8]      c338_1    1
    x[8]      c340_1    1
    x[8]      c342_1    1
    x[8]      c344_1    1
    x[8]      c346_1    1
    x[8]      c348_1    1
    x[8]      c350_1    1
    x[8]      c352_1    1
    x[8]      c354_1    1
    x[8]      c356_1    1
    x[8]      c358_1    1
    x[8]      c360_1    1
    x[8]      c362_1    1
    x[8]      c364_1    1
    x[8]      c366_1    1
    x[8]      c368_1    1
    x[8]      c38_1     -20
    x[8]      c42_1     20
    x[8]      c236_1    -20
    x[8]      c240_1    20
    x[8]      c428      -20
    x[8]      c432      20
    x[8]      c614      -20
    x[8]      c618      20
    x[8]      c794      -20
    x[8]      c798      20
    x[8]      c968      -20
    x[8]      c972      20
    x[8]      c1136     -20
    x[8]      c1140     20
    x[8]      c1303     20
    x[8]      c1305     -20
    x[8]      c1309     20
    x[8]      c1311     -20
    x[8]      c1315     20
    x[8]      c1317     -20
    x[8]      c1321     20
    x[8]      c1323     -20
    x[8]      c1327     20
    x[8]      c1329     -20
    x[8]      c1333     20
    x[8]      c1335     -20
    x[8]      c1339     20
    x[8]      c1341     -20
    x[8]      c1345     20
    x[8]      c1347     -20
    x[8]      c1351     20
    x[8]      c1353     -20
    x[8]      c1357     20
    x[8]      c1359     -20
    x[8]      c1363     20
    x[8]      c1365     -20
    x[8]      c1369     20
    x[8]      c1371     -20
    x[8]      c1375     20
    x[8]      c1377     -20
    x[8]      c1381     20
    x[8]      c1383     -20
    x[8]      c1387     20
    x[8]      c1389     -20
    x[8]      c1393     20
    x[8]      c1395     -20
    x[8]      c1399     20
    x[8]      c1401     -20
    x[8]      c1405     20
    x[8]      c1407     -20
    x[8]      c1411     20
    x[8]      c1413     -20
    x[8]      c1417     20
    x[8]      c1419     -20
    x[8]      c1423     20
    x[8]      c1425     -20
    x[8]      c1429     20
    x[8]      c1431     -20
    x[8]      c1435     20
    x[8]      c1437     -20
    x[8]      c1441     20
    x[8]      c1443     -20
    x[8]      c1447     20
    x[8]      c1449     -20
    x[8]      c1453     20
    x[8]      c1455     -20
    x[8]      c1459     20
    x[8]      c1461     -20
    x[9]      c17_2     -20
    x[9]      c18_2     20
    x[9]      c246_1    -1
    x[9]      c292_1    -1
    x[9]      c336_1    -1
    x[9]      c380_1    1
    x[9]      c382_1    1
    x[9]      c384_1    1
    x[9]      c386_1    1
    x[9]      c388_1    1
    x[9]      c390_1    1
    x[9]      c392_1    1
    x[9]      c394_1    1
    x[9]      c396_1    1
    x[9]      c398_1    1
    x[9]      c400_1    1
    x[9]      c402_1    1
    x[9]      c404_1    1
    x[9]      c406_1    1
    x[9]      c408_1    1
    x[9]      c410_1    1
    x[9]      c44_1     -20
    x[9]      c48_1     20
    x[9]      c242_1    -20
    x[9]      c246      20
    x[9]      c434      -20
    x[9]      c438      20
    x[9]      c620      -20
    x[9]      c624      20
    x[9]      c800      -20
    x[9]      c804      20
    x[9]      c974      -20
    x[9]      c978      20
    x[9]      c1142     -20
    x[9]      c1146     20
    x[9]      c1304     -20
    x[9]      c1308     20
    x[9]      c1465     20
    x[9]      c1467     -20
    x[9]      c1471     20
    x[9]      c1473     -20
    x[9]      c1477     20
    x[9]      c1479     -20
    x[9]      c1483     20
    x[9]      c1485     -20
    x[9]      c1489     20
    x[9]      c1491     -20
    x[9]      c1495     20
    x[9]      c1497     -20
    x[9]      c1501     20
    x[9]      c1503     -20
    x[9]      c1507     20
    x[9]      c1509     -20
    x[9]      c1513     20
    x[9]      c1515     -20
    x[9]      c1519     20
    x[9]      c1521     -20
    x[9]      c1525     20
    x[9]      c1527     -20
    x[9]      c1531     20
    x[9]      c1533     -20
    x[9]      c1537     20
    x[9]      c1539     -20
    x[9]      c1543     20
    x[9]      c1545     -20
    x[9]      c1549     20
    x[9]      c1551     -20
    x[9]      c1555     20
    x[9]      c1557     -20
    x[9]      c1561     20
    x[9]      c1563     -20
    x[9]      c1567     20
    x[9]      c1569     -20
    x[9]      c1573     20
    x[9]      c1575     -20
    x[9]      c1579     20
    x[9]      c1581     -20
    x[9]      c1585     20
    x[9]      c1587     -20
    x[9]      c1591     20
    x[9]      c1593     -20
    x[9]      c1597     20
    x[9]      c1599     -20
    x[9]      c1603     20
    x[9]      c1605     -20
    x[9]      c1609     20
    x[9]      c1611     -20
    x[9]      c1615     20
    x[9]      c1617     -20
    x[10]     c19_2     -20
    x[10]     c20_2     20
    x[10]     c248_1    -1
    x[10]     c294_1    -1
    x[10]     c338_1    -1
    x[10]     c380_1    -1
    x[10]     c422_1    1
    x[10]     c424_1    1
    x[10]     c426_1    1
    x[10]     c428_1    1
    x[10]     c430_1    1
    x[10]     c432_1    1
    x[10]     c434_1    1
    x[10]     c436_1    1
    x[10]     c438_1    1
    x[10]     c440_1    1
    x[10]     c442_1    1
    x[10]     c444_1    1
    x[10]     c446_1    1
    x[10]     c448_1    1
    x[10]     c450_1    1
    x[10]     c50_1     -20
    x[10]     c54_1     20
    x[10]     c248      -20
    x[10]     c252      20
    x[10]     c440      -20
    x[10]     c444      20
    x[10]     c626      -20
    x[10]     c630      20
    x[10]     c806      -20
    x[10]     c810      20
    x[10]     c980      -20
    x[10]     c984      20
    x[10]     c1148     -20
    x[10]     c1152     20
    x[10]     c1310     -20
    x[10]     c1314     20
    x[10]     c1466     -20
    x[10]     c1470     20
    x[10]     c1621     20
    x[10]     c1623     -20
    x[10]     c1627     20
    x[10]     c1629     -20
    x[10]     c1633     20
    x[10]     c1635     -20
    x[10]     c1639     20
    x[10]     c1641     -20
    x[10]     c1645     20
    x[10]     c1647     -20
    x[10]     c1651     20
    x[10]     c1653     -20
    x[10]     c1657     20
    x[10]     c1659     -20
    x[10]     c1663     20
    x[10]     c1665     -20
    x[10]     c1669     20
    x[10]     c1671     -20
    x[10]     c1675     20
    x[10]     c1677     -20
    x[10]     c1681     20
    x[10]     c1683     -20
    x[10]     c1687     20
    x[10]     c1689     -20
    x[10]     c1693     20
    x[10]     c1695     -20
    x[10]     c1699     20
    x[10]     c1701     -20
    x[10]     c1705     20
    x[10]     c1707     -20
    x[10]     c1711     20
    x[10]     c1713     -20
    x[10]     c1717     20
    x[10]     c1719     -20
    x[10]     c1723     20
    x[10]     c1725     -20
    x[10]     c1729     20
    x[10]     c1731     -20
    x[10]     c1735     20
    x[10]     c1737     -20
    x[10]     c1741     20
    x[10]     c1743     -20
    x[10]     c1747     20
    x[10]     c1749     -20
    x[10]     c1753     20
    x[10]     c1755     -20
    x[10]     c1759     20
    x[10]     c1761     -20
    x[10]     c1765     20
    x[10]     c1767     -20
    x[11]     c21_2     -20
    x[11]     c22_2     20
    x[11]     c250_1    -1
    x[11]     c296_1    -1
    x[11]     c340_1    -1
    x[11]     c382_1    -1
    x[11]     c422_1    -1
    x[11]     c462_1    1
    x[11]     c464_1    1
    x[11]     c466_1    1
    x[11]     c468_1    1
    x[11]     c470_1    1
    x[11]     c472_1    1
    x[11]     c474_1    1
    x[11]     c476_1    1
    x[11]     c478_1    1
    x[11]     c480_1    1
    x[11]     c482_1    1
    x[11]     c484_1    1
    x[11]     c486_1    1
    x[11]     c488_1    1
    x[11]     c56_1     -20
    x[11]     c60_1     20
    x[11]     c254      -20
    x[11]     c258      20
    x[11]     c446      -20
    x[11]     c450      20
    x[11]     c632      -20
    x[11]     c636      20
    x[11]     c812      -20
    x[11]     c816      20
    x[11]     c986      -20
    x[11]     c990      20
    x[11]     c1154     -20
    x[11]     c1158     20
    x[11]     c1316     -20
    x[11]     c1320     20
    x[11]     c1472     -20
    x[11]     c1476     20
    x[11]     c1622     -20
    x[11]     c1626     20
    x[11]     c1771     20
    x[11]     c1773     -20
    x[11]     c1777     20
    x[11]     c1779     -20
    x[11]     c1783     20
    x[11]     c1785     -20
    x[11]     c1789     20
    x[11]     c1791     -20
    x[11]     c1795     20
    x[11]     c1797     -20
    x[11]     c1801     20
    x[11]     c1803     -20
    x[11]     c1807     20
    x[11]     c1809     -20
    x[11]     c1813     20
    x[11]     c1815     -20
    x[11]     c1819     20
    x[11]     c1821     -20
    x[11]     c1825     20
    x[11]     c1827     -20
    x[11]     c1831     20
    x[11]     c1833     -20
    x[11]     c1837     20
    x[11]     c1839     -20
    x[11]     c1843     20
    x[11]     c1845     -20
    x[11]     c1849     20
    x[11]     c1851     -20
    x[11]     c1855     20
    x[11]     c1857     -20
    x[11]     c1861     20
    x[11]     c1863     -20
    x[11]     c1867     20
    x[11]     c1869     -20
    x[11]     c1873     20
    x[11]     c1875     -20
    x[11]     c1879     20
    x[11]     c1881     -20
    x[11]     c1885     20
    x[11]     c1887     -20
    x[11]     c1891     20
    x[11]     c1893     -20
    x[11]     c1897     20
    x[11]     c1899     -20
    x[11]     c1903     20
    x[11]     c1905     -20
    x[11]     c1909     20
    x[11]     c1911     -20
    x[12]     c23_2     -20
    x[12]     c24_2     20
    x[12]     c252_1    -1
    x[12]     c298_1    -1
    x[12]     c342_1    -1
    x[12]     c384_1    -1
    x[12]     c424_1    -1
    x[12]     c462_1    -1
    x[12]     c500_1    1
    x[12]     c502_1    1
    x[12]     c504_1    1
    x[12]     c506_1    1
    x[12]     c508_1    1
    x[12]     c510_1    1
    x[12]     c512_1    1
    x[12]     c514_1    1
    x[12]     c516_1    1
    x[12]     c518_1    1
    x[12]     c520_1    1
    x[12]     c522_1    1
    x[12]     c524_1    1
    x[12]     c62_1     -20
    x[12]     c66_1     20
    x[12]     c260      -20
    x[12]     c264      20
    x[12]     c452      -20
    x[12]     c456      20
    x[12]     c638      -20
    x[12]     c642      20
    x[12]     c818      -20
    x[12]     c822      20
    x[12]     c992      -20
    x[12]     c996      20
    x[12]     c1160     -20
    x[12]     c1164     20
    x[12]     c1322     -20
    x[12]     c1326     20
    x[12]     c1478     -20
    x[12]     c1482     20
    x[12]     c1628     -20
    x[12]     c1632     20
    x[12]     c1772     -20
    x[12]     c1776     20
    x[12]     c1915     20
    x[12]     c1917     -20
    x[12]     c1921     20
    x[12]     c1923     -20
    x[12]     c1927     20
    x[12]     c1929     -20
    x[12]     c1933     20
    x[12]     c1935     -20
    x[12]     c1939     20
    x[12]     c1941     -20
    x[12]     c1945     20
    x[12]     c1947     -20
    x[12]     c1951     20
    x[12]     c1953     -20
    x[12]     c1957     20
    x[12]     c1959     -20
    x[12]     c1963     20
    x[12]     c1965     -20
    x[12]     c1969     20
    x[12]     c1971     -20
    x[12]     c1975     20
    x[12]     c1977     -20
    x[12]     c1981     20
    x[12]     c1983     -20
    x[12]     c1987     20
    x[12]     c1989     -20
    x[12]     c1993     20
    x[12]     c1995     -20
    x[12]     c1999     20
    x[12]     c2001     -20
    x[12]     c2005     20
    x[12]     c2007     -20
    x[12]     c2011     20
    x[12]     c2013     -20
    x[12]     c2017     20
    x[12]     c2019     -20
    x[12]     c2023     20
    x[12]     c2025     -20
    x[12]     c2029     20
    x[12]     c2031     -20
    x[12]     c2035     20
    x[12]     c2037     -20
    x[12]     c2041     20
    x[12]     c2043     -20
    x[12]     c2047     20
    x[12]     c2049     -20
    x[13]     c25_2     -20
    x[13]     c26_2     20
    x[13]     c254_1    -1
    x[13]     c300_1    -1
    x[13]     c344_1    -1
    x[13]     c386_1    -1
    x[13]     c426_1    -1
    x[13]     c464_1    -1
    x[13]     c500_1    -1
    x[13]     c536_1    1
    x[13]     c538_1    1
    x[13]     c540_1    1
    x[13]     c542_1    1
    x[13]     c544_1    1
    x[13]     c546_1    1
    x[13]     c548_1    1
    x[13]     c550_1    1
    x[13]     c552_1    1
    x[13]     c554_1    1
    x[13]     c556_1    1
    x[13]     c558_1    1
    x[13]     c68_1     -20
    x[13]     c72_1     20
    x[13]     c266      -20
    x[13]     c270      20
    x[13]     c458      -20
    x[13]     c462      20
    x[13]     c644      -20
    x[13]     c648      20
    x[13]     c824      -20
    x[13]     c828      20
    x[13]     c998      -20
    x[13]     c1002     20
    x[13]     c1166     -20
    x[13]     c1170     20
    x[13]     c1328     -20
    x[13]     c1332     20
    x[13]     c1484     -20
    x[13]     c1488     20
    x[13]     c1634     -20
    x[13]     c1638     20
    x[13]     c1778     -20
    x[13]     c1782     20
    x[13]     c1916     -20
    x[13]     c1920     20
    x[13]     c2053     20
    x[13]     c2055     -20
    x[13]     c2059     20
    x[13]     c2061     -20
    x[13]     c2065     20
    x[13]     c2067     -20
    x[13]     c2071     20
    x[13]     c2073     -20
    x[13]     c2077     20
    x[13]     c2079     -20
    x[13]     c2083     20
    x[13]     c2085     -20
    x[13]     c2089     20
    x[13]     c2091     -20
    x[13]     c2095     20
    x[13]     c2097     -20
    x[13]     c2101     20
    x[13]     c2103     -20
    x[13]     c2107     20
    x[13]     c2109     -20
    x[13]     c2113     20
    x[13]     c2115     -20
    x[13]     c2119     20
    x[13]     c2121     -20
    x[13]     c2125     20
    x[13]     c2127     -20
    x[13]     c2131     20
    x[13]     c2133     -20
    x[13]     c2137     20
    x[13]     c2139     -20
    x[13]     c2143     20
    x[13]     c2145     -20
    x[13]     c2149     20
    x[13]     c2151     -20
    x[13]     c2155     20
    x[13]     c2157     -20
    x[13]     c2161     20
    x[13]     c2163     -20
    x[13]     c2167     20
    x[13]     c2169     -20
    x[13]     c2173     20
    x[13]     c2175     -20
    x[13]     c2179     20
    x[13]     c2181     -20
    x[14]     c27_2     -20
    x[14]     c28_2     20
    x[14]     c256_1    -1
    x[14]     c302_1    -1
    x[14]     c346_1    -1
    x[14]     c388_1    -1
    x[14]     c428_1    -1
    x[14]     c466_1    -1
    x[14]     c502_1    -1
    x[14]     c536_1    -1
    x[14]     c570_1    1
    x[14]     c572_1    1
    x[14]     c574_1    1
    x[14]     c576_1    1
    x[14]     c578_1    1
    x[14]     c580_1    1
    x[14]     c582_1    1
    x[14]     c584_1    1
    x[14]     c586_1    1
    x[14]     c588_1    1
    x[14]     c590_1    1
    x[14]     c74_1     -20
    x[14]     c78_1     20
    x[14]     c272      -20
    x[14]     c276      20
    x[14]     c464      -20
    x[14]     c468      20
    x[14]     c650      -20
    x[14]     c654      20
    x[14]     c830      -20
    x[14]     c834      20
    x[14]     c1004     -20
    x[14]     c1008     20
    x[14]     c1172     -20
    x[14]     c1176     20
    x[14]     c1334     -20
    x[14]     c1338     20
    x[14]     c1490     -20
    x[14]     c1494     20
    x[14]     c1640     -20
    x[14]     c1644     20
    x[14]     c1784     -20
    x[14]     c1788     20
    x[14]     c1922     -20
    x[14]     c1926     20
    x[14]     c2054     -20
    x[14]     c2058     20
    x[14]     c2185     20
    x[14]     c2187     -20
    x[14]     c2191     20
    x[14]     c2193     -20
    x[14]     c2197     20
    x[14]     c2199     -20
    x[14]     c2203     20
    x[14]     c2205     -20
    x[14]     c2209     20
    x[14]     c2211     -20
    x[14]     c2215     20
    x[14]     c2217     -20
    x[14]     c2221     20
    x[14]     c2223     -20
    x[14]     c2227     20
    x[14]     c2229     -20
    x[14]     c2233     20
    x[14]     c2235     -20
    x[14]     c2239     20
    x[14]     c2241     -20
    x[14]     c2245     20
    x[14]     c2247     -20
    x[14]     c2251     20
    x[14]     c2253     -20
    x[14]     c2257     20
    x[14]     c2259     -20
    x[14]     c2263     20
    x[14]     c2265     -20
    x[14]     c2269     20
    x[14]     c2271     -20
    x[14]     c2275     20
    x[14]     c2277     -20
    x[14]     c2281     20
    x[14]     c2283     -20
    x[14]     c2287     20
    x[14]     c2289     -20
    x[14]     c2293     20
    x[14]     c2295     -20
    x[14]     c2299     20
    x[14]     c2301     -20
    x[14]     c2305     20
    x[14]     c2307     -20
    x[15]     c29_2     -20
    x[15]     c30_2     20
    x[15]     c258_1    -1
    x[15]     c304_1    -1
    x[15]     c348_1    -1
    x[15]     c390_1    -1
    x[15]     c430_1    -1
    x[15]     c468_1    -1
    x[15]     c504_1    -1
    x[15]     c538_1    -1
    x[15]     c570_1    -1
    x[15]     c602_1    1
    x[15]     c604_1    1
    x[15]     c606_1    1
    x[15]     c608_1    1
    x[15]     c610_1    1
    x[15]     c612_1    1
    x[15]     c614_1    1
    x[15]     c616_1    1
    x[15]     c618_1    1
    x[15]     c620_1    1
    x[15]     c80_1     -20
    x[15]     c84_1     20
    x[15]     c278      -20
    x[15]     c282      20
    x[15]     c470      -20
    x[15]     c474      20
    x[15]     c656      -20
    x[15]     c660      20
    x[15]     c836      -20
    x[15]     c840      20
    x[15]     c1010     -20
    x[15]     c1014     20
    x[15]     c1178     -20
    x[15]     c1182     20
    x[15]     c1340     -20
    x[15]     c1344     20
    x[15]     c1496     -20
    x[15]     c1500     20
    x[15]     c1646     -20
    x[15]     c1650     20
    x[15]     c1790     -20
    x[15]     c1794     20
    x[15]     c1928     -20
    x[15]     c1932     20
    x[15]     c2060     -20
    x[15]     c2064     20
    x[15]     c2186     -20
    x[15]     c2190     20
    x[15]     c2311     20
    x[15]     c2313     -20
    x[15]     c2317     20
    x[15]     c2319     -20
    x[15]     c2323     20
    x[15]     c2325     -20
    x[15]     c2329     20
    x[15]     c2331     -20
    x[15]     c2335     20
    x[15]     c2337     -20
    x[15]     c2341     20
    x[15]     c2343     -20
    x[15]     c2347     20
    x[15]     c2349     -20
    x[15]     c2353     20
    x[15]     c2355     -20
    x[15]     c2359     20
    x[15]     c2361     -20
    x[15]     c2365     20
    x[15]     c2367     -20
    x[15]     c2371     20
    x[15]     c2373     -20
    x[15]     c2377     20
    x[15]     c2379     -20
    x[15]     c2383     20
    x[15]     c2385     -20
    x[15]     c2389     20
    x[15]     c2391     -20
    x[15]     c2395     20
    x[15]     c2397     -20
    x[15]     c2401     20
    x[15]     c2403     -20
    x[15]     c2407     20
    x[15]     c2409     -20
    x[15]     c2413     20
    x[15]     c2415     -20
    x[15]     c2419     20
    x[15]     c2421     -20
    x[15]     c2425     20
    x[15]     c2427     -20
    x[16]     c31_2     -20
    x[16]     c32_2     20
    x[16]     c260_1    -1
    x[16]     c306_1    -1
    x[16]     c350_1    -1
    x[16]     c392_1    -1
    x[16]     c432_1    -1
    x[16]     c470_1    -1
    x[16]     c506_1    -1
    x[16]     c540_1    -1
    x[16]     c572_1    -1
    x[16]     c602_1    -1
    x[16]     c632_1    1
    x[16]     c634_1    1
    x[16]     c636_1    1
    x[16]     c638_1    1
    x[16]     c640_1    1
    x[16]     c642_1    1
    x[16]     c644_1    1
    x[16]     c646_1    1
    x[16]     c648_1    1
    x[16]     c86_1     -20
    x[16]     c90_1     20
    x[16]     c284      -20
    x[16]     c288      20
    x[16]     c476      -20
    x[16]     c480      20
    x[16]     c662      -20
    x[16]     c666      20
    x[16]     c842      -20
    x[16]     c846      20
    x[16]     c1016     -20
    x[16]     c1020     20
    x[16]     c1184     -20
    x[16]     c1188     20
    x[16]     c1346     -20
    x[16]     c1350     20
    x[16]     c1502     -20
    x[16]     c1506     20
    x[16]     c1652     -20
    x[16]     c1656     20
    x[16]     c1796     -20
    x[16]     c1800     20
    x[16]     c1934     -20
    x[16]     c1938     20
    x[16]     c2066     -20
    x[16]     c2070     20
    x[16]     c2192     -20
    x[16]     c2196     20
    x[16]     c2312     -20
    x[16]     c2316     20
    x[16]     c2431     20
    x[16]     c2433     -20
    x[16]     c2437     20
    x[16]     c2439     -20
    x[16]     c2443     20
    x[16]     c2445     -20
    x[16]     c2449     20
    x[16]     c2451     -20
    x[16]     c2455     20
    x[16]     c2457     -20
    x[16]     c2461     20
    x[16]     c2463     -20
    x[16]     c2467     20
    x[16]     c2469     -20
    x[16]     c2473     20
    x[16]     c2475     -20
    x[16]     c2479     20
    x[16]     c2481     -20
    x[16]     c2485     20
    x[16]     c2487     -20
    x[16]     c2491     20
    x[16]     c2493     -20
    x[16]     c2497     20
    x[16]     c2499     -20
    x[16]     c2503     20
    x[16]     c2505     -20
    x[16]     c2509     20
    x[16]     c2511     -20
    x[16]     c2515     20
    x[16]     c2517     -20
    x[16]     c2521     20
    x[16]     c2523     -20
    x[16]     c2527     20
    x[16]     c2529     -20
    x[16]     c2533     20
    x[16]     c2535     -20
    x[16]     c2539     20
    x[16]     c2541     -20
    x[17]     c33_2     -20
    x[17]     c34_2     20
    x[17]     c262_1    -1
    x[17]     c308_1    -1
    x[17]     c352_1    -1
    x[17]     c394_1    -1
    x[17]     c434_1    -1
    x[17]     c472_1    -1
    x[17]     c508_1    -1
    x[17]     c542_1    -1
    x[17]     c574_1    -1
    x[17]     c604_1    -1
    x[17]     c632_1    -1
    x[17]     c660_1    1
    x[17]     c662_1    1
    x[17]     c664_1    1
    x[17]     c666_1    1
    x[17]     c668_1    1
    x[17]     c670_1    1
    x[17]     c672_1    1
    x[17]     c674_1    1
    x[17]     c92_1     -20
    x[17]     c96_1     20
    x[17]     c290      -20
    x[17]     c294      20
    x[17]     c482      -20
    x[17]     c486      20
    x[17]     c668      -20
    x[17]     c672      20
    x[17]     c848      -20
    x[17]     c852      20
    x[17]     c1022     -20
    x[17]     c1026     20
    x[17]     c1190     -20
    x[17]     c1194     20
    x[17]     c1352     -20
    x[17]     c1356     20
    x[17]     c1508     -20
    x[17]     c1512     20
    x[17]     c1658     -20
    x[17]     c1662     20
    x[17]     c1802     -20
    x[17]     c1806     20
    x[17]     c1940     -20
    x[17]     c1944     20
    x[17]     c2072     -20
    x[17]     c2076     20
    x[17]     c2198     -20
    x[17]     c2202     20
    x[17]     c2318     -20
    x[17]     c2322     20
    x[17]     c2432     -20
    x[17]     c2436     20
    x[17]     c2545     20
    x[17]     c2547     -20
    x[17]     c2551     20
    x[17]     c2553     -20
    x[17]     c2557     20
    x[17]     c2559     -20
    x[17]     c2563     20
    x[17]     c2565     -20
    x[17]     c2569     20
    x[17]     c2571     -20
    x[17]     c2575     20
    x[17]     c2577     -20
    x[17]     c2581     20
    x[17]     c2583     -20
    x[17]     c2587     20
    x[17]     c2589     -20
    x[17]     c2593     20
    x[17]     c2595     -20
    x[17]     c2599     20
    x[17]     c2601     -20
    x[17]     c2605     20
    x[17]     c2607     -20
    x[17]     c2611     20
    x[17]     c2613     -20
    x[17]     c2617     20
    x[17]     c2619     -20
    x[17]     c2623     20
    x[17]     c2625     -20
    x[17]     c2629     20
    x[17]     c2631     -20
    x[17]     c2635     20
    x[17]     c2637     -20
    x[17]     c2641     20
    x[17]     c2643     -20
    x[17]     c2647     20
    x[17]     c2649     -20
    x[18]     c35_2     -20
    x[18]     c36_2     20
    x[18]     c264_1    -1
    x[18]     c310_1    -1
    x[18]     c354_1    -1
    x[18]     c396_1    -1
    x[18]     c436_1    -1
    x[18]     c474_1    -1
    x[18]     c510_1    -1
    x[18]     c544_1    -1
    x[18]     c576_1    -1
    x[18]     c606_1    -1
    x[18]     c634_1    -1
    x[18]     c660_1    -1
    x[18]     c686_1    1
    x[18]     c688_1    1
    x[18]     c690_1    1
    x[18]     c692_1    1
    x[18]     c694_1    1
    x[18]     c696_1    1
    x[18]     c698_1    1
    x[18]     c98_1     -20
    x[18]     c102_1    20
    x[18]     c296      -20
    x[18]     c300      20
    x[18]     c488      -20
    x[18]     c492      20
    x[18]     c674      -20
    x[18]     c678      20
    x[18]     c854      -20
    x[18]     c858      20
    x[18]     c1028     -20
    x[18]     c1032     20
    x[18]     c1196     -20
    x[18]     c1200     20
    x[18]     c1358     -20
    x[18]     c1362     20
    x[18]     c1514     -20
    x[18]     c1518     20
    x[18]     c1664     -20
    x[18]     c1668     20
    x[18]     c1808     -20
    x[18]     c1812     20
    x[18]     c1946     -20
    x[18]     c1950     20
    x[18]     c2078     -20
    x[18]     c2082     20
    x[18]     c2204     -20
    x[18]     c2208     20
    x[18]     c2324     -20
    x[18]     c2328     20
    x[18]     c2438     -20
    x[18]     c2442     20
    x[18]     c2546     -20
    x[18]     c2550     20
    x[18]     c2653     20
    x[18]     c2655     -20
    x[18]     c2659     20
    x[18]     c2661     -20
    x[18]     c2665     20
    x[18]     c2667     -20
    x[18]     c2671     20
    x[18]     c2673     -20
    x[18]     c2677     20
    x[18]     c2679     -20
    x[18]     c2683     20
    x[18]     c2685     -20
    x[18]     c2689     20
    x[18]     c2691     -20
    x[18]     c2695     20
    x[18]     c2697     -20
    x[18]     c2701     20
    x[18]     c2703     -20
    x[18]     c2707     20
    x[18]     c2709     -20
    x[18]     c2713     20
    x[18]     c2715     -20
    x[18]     c2719     20
    x[18]     c2721     -20
    x[18]     c2725     20
    x[18]     c2727     -20
    x[18]     c2731     20
    x[18]     c2733     -20
    x[18]     c2737     20
    x[18]     c2739     -20
    x[18]     c2743     20
    x[18]     c2745     -20
    x[18]     c2749     20
    x[18]     c2751     -20
    x[19]     c37_2     -20
    x[19]     c38_2     20
    x[19]     c266_1    -1
    x[19]     c312_1    -1
    x[19]     c356_1    -1
    x[19]     c398_1    -1
    x[19]     c438_1    -1
    x[19]     c476_1    -1
    x[19]     c512_1    -1
    x[19]     c546_1    -1
    x[19]     c578_1    -1
    x[19]     c608_1    -1
    x[19]     c636_1    -1
    x[19]     c662_1    -1
    x[19]     c686_1    -1
    x[19]     c710_1    1
    x[19]     c712_1    1
    x[19]     c714_1    1
    x[19]     c716_1    1
    x[19]     c718_1    1
    x[19]     c720_1    1
    x[19]     c104_1    -20
    x[19]     c108_1    20
    x[19]     c302      -20
    x[19]     c306      20
    x[19]     c494      -20
    x[19]     c498      20
    x[19]     c680      -20
    x[19]     c684      20
    x[19]     c860      -20
    x[19]     c864      20
    x[19]     c1034     -20
    x[19]     c1038     20
    x[19]     c1202     -20
    x[19]     c1206     20
    x[19]     c1364     -20
    x[19]     c1368     20
    x[19]     c1520     -20
    x[19]     c1524     20
    x[19]     c1670     -20
    x[19]     c1674     20
    x[19]     c1814     -20
    x[19]     c1818     20
    x[19]     c1952     -20
    x[19]     c1956     20
    x[19]     c2084     -20
    x[19]     c2088     20
    x[19]     c2210     -20
    x[19]     c2214     20
    x[19]     c2330     -20
    x[19]     c2334     20
    x[19]     c2444     -20
    x[19]     c2448     20
    x[19]     c2552     -20
    x[19]     c2556     20
    x[19]     c2654     -20
    x[19]     c2658     20
    x[19]     c2755     20
    x[19]     c2757     -20
    x[19]     c2761     20
    x[19]     c2763     -20
    x[19]     c2767     20
    x[19]     c2769     -20
    x[19]     c2773     20
    x[19]     c2775     -20
    x[19]     c2779     20
    x[19]     c2781     -20
    x[19]     c2785     20
    x[19]     c2787     -20
    x[19]     c2791     20
    x[19]     c2793     -20
    x[19]     c2797     20
    x[19]     c2799     -20
    x[19]     c2803     20
    x[19]     c2805     -20
    x[19]     c2809     20
    x[19]     c2811     -20
    x[19]     c2815     20
    x[19]     c2817     -20
    x[19]     c2821     20
    x[19]     c2823     -20
    x[19]     c2827     20
    x[19]     c2829     -20
    x[19]     c2833     20
    x[19]     c2835     -20
    x[19]     c2839     20
    x[19]     c2841     -20
    x[19]     c2845     20
    x[19]     c2847     -20
    x[20]     c39_2     -20
    x[20]     c40_2     20
    x[20]     c268_1    -1
    x[20]     c314_1    -1
    x[20]     c358_1    -1
    x[20]     c400_1    -1
    x[20]     c440_1    -1
    x[20]     c478_1    -1
    x[20]     c514_1    -1
    x[20]     c548_1    -1
    x[20]     c580_1    -1
    x[20]     c610_1    -1
    x[20]     c638_1    -1
    x[20]     c664_1    -1
    x[20]     c688_1    -1
    x[20]     c710_1    -1
    x[20]     c732_1    1
    x[20]     c734_1    1
    x[20]     c736_1    1
    x[20]     c738_1    1
    x[20]     c740_1    1
    x[20]     c110_1    -20
    x[20]     c114_1    20
    x[20]     c308      -20
    x[20]     c312      20
    x[20]     c500      -20
    x[20]     c504      20
    x[20]     c686      -20
    x[20]     c690      20
    x[20]     c866      -20
    x[20]     c870      20
    x[20]     c1040     -20
    x[20]     c1044     20
    x[20]     c1208     -20
    x[20]     c1212     20
    x[20]     c1370     -20
    x[20]     c1374     20
    x[20]     c1526     -20
    x[20]     c1530     20
    x[20]     c1676     -20
    x[20]     c1680     20
    x[20]     c1820     -20
    x[20]     c1824     20
    x[20]     c1958     -20
    x[20]     c1962     20
    x[20]     c2090     -20
    x[20]     c2094     20
    x[20]     c2216     -20
    x[20]     c2220     20
    x[20]     c2336     -20
    x[20]     c2340     20
    x[20]     c2450     -20
    x[20]     c2454     20
    x[20]     c2558     -20
    x[20]     c2562     20
    x[20]     c2660     -20
    x[20]     c2664     20
    x[20]     c2756     -20
    x[20]     c2760     20
    x[20]     c2851     20
    x[20]     c2853     -20
    x[20]     c2857     20
    x[20]     c2859     -20
    x[20]     c2863     20
    x[20]     c2865     -20
    x[20]     c2869     20
    x[20]     c2871     -20
    x[20]     c2875     20
    x[20]     c2877     -20
    x[20]     c2881     20
    x[20]     c2883     -20
    x[20]     c2887     20
    x[20]     c2889     -20
    x[20]     c2893     20
    x[20]     c2895     -20
    x[20]     c2899     20
    x[20]     c2901     -20
    x[20]     c2905     20
    x[20]     c2907     -20
    x[20]     c2911     20
    x[20]     c2913     -20
    x[20]     c2917     20
    x[20]     c2919     -20
    x[20]     c2923     20
    x[20]     c2925     -20
    x[20]     c2929     20
    x[20]     c2931     -20
    x[20]     c2935     20
    x[20]     c2937     -20
    x[21]     c41_2     -20
    x[21]     c42_2     20
    x[21]     c270_1    -1
    x[21]     c316_1    -1
    x[21]     c360_1    -1
    x[21]     c402_1    -1
    x[21]     c442_1    -1
    x[21]     c480_1    -1
    x[21]     c516_1    -1
    x[21]     c550_1    -1
    x[21]     c582_1    -1
    x[21]     c612_1    -1
    x[21]     c640_1    -1
    x[21]     c666_1    -1
    x[21]     c690_1    -1
    x[21]     c712_1    -1
    x[21]     c732_1    -1
    x[21]     c752_1    1
    x[21]     c754_1    1
    x[21]     c756_1    1
    x[21]     c758_1    1
    x[21]     c116_1    -20
    x[21]     c120_1    20
    x[21]     c314      -20
    x[21]     c318      20
    x[21]     c506      -20
    x[21]     c510      20
    x[21]     c692      -20
    x[21]     c696      20
    x[21]     c872      -20
    x[21]     c876      20
    x[21]     c1046     -20
    x[21]     c1050     20
    x[21]     c1214     -20
    x[21]     c1218     20
    x[21]     c1376     -20
    x[21]     c1380     20
    x[21]     c1532     -20
    x[21]     c1536     20
    x[21]     c1682     -20
    x[21]     c1686     20
    x[21]     c1826     -20
    x[21]     c1830     20
    x[21]     c1964     -20
    x[21]     c1968     20
    x[21]     c2096     -20
    x[21]     c2100     20
    x[21]     c2222     -20
    x[21]     c2226     20
    x[21]     c2342     -20
    x[21]     c2346     20
    x[21]     c2456     -20
    x[21]     c2460     20
    x[21]     c2564     -20
    x[21]     c2568     20
    x[21]     c2666     -20
    x[21]     c2670     20
    x[21]     c2762     -20
    x[21]     c2766     20
    x[21]     c2852     -20
    x[21]     c2856     20
    x[21]     c2941     20
    x[21]     c2943     -20
    x[21]     c2947     20
    x[21]     c2949     -20
    x[21]     c2953     20
    x[21]     c2955     -20
    x[21]     c2959     20
    x[21]     c2961     -20
    x[21]     c2965     20
    x[21]     c2967     -20
    x[21]     c2971     20
    x[21]     c2973     -20
    x[21]     c2977     20
    x[21]     c2979     -20
    x[21]     c2983     20
    x[21]     c2985     -20
    x[21]     c2989     20
    x[21]     c2991     -20
    x[21]     c2995     20
    x[21]     c2997     -20
    x[21]     c3001     20
    x[21]     c3003     -20
    x[21]     c3007     20
    x[21]     c3009     -20
    x[21]     c3013     20
    x[21]     c3015     -20
    x[21]     c3019     20
    x[21]     c3021     -20
    x[22]     c43_2     -20
    x[22]     c44_2     20
    x[22]     c272_1    -1
    x[22]     c318_1    -1
    x[22]     c362_1    -1
    x[22]     c404_1    -1
    x[22]     c444_1    -1
    x[22]     c482_1    -1
    x[22]     c518_1    -1
    x[22]     c552_1    -1
    x[22]     c584_1    -1
    x[22]     c614_1    -1
    x[22]     c642_1    -1
    x[22]     c668_1    -1
    x[22]     c692_1    -1
    x[22]     c714_1    -1
    x[22]     c734_1    -1
    x[22]     c752_1    -1
    x[22]     c770_1    1
    x[22]     c772_1    1
    x[22]     c774_1    1
    x[22]     c122_1    -20
    x[22]     c126_1    20
    x[22]     c320      -20
    x[22]     c324      20
    x[22]     c512      -20
    x[22]     c516      20
    x[22]     c698      -20
    x[22]     c702      20
    x[22]     c878      -20
    x[22]     c882      20
    x[22]     c1052     -20
    x[22]     c1056     20
    x[22]     c1220     -20
    x[22]     c1224     20
    x[22]     c1382     -20
    x[22]     c1386     20
    x[22]     c1538     -20
    x[22]     c1542     20
    x[22]     c1688     -20
    x[22]     c1692     20
    x[22]     c1832     -20
    x[22]     c1836     20
    x[22]     c1970     -20
    x[22]     c1974     20
    x[22]     c2102     -20
    x[22]     c2106     20
    x[22]     c2228     -20
    x[22]     c2232     20
    x[22]     c2348     -20
    x[22]     c2352     20
    x[22]     c2462     -20
    x[22]     c2466     20
    x[22]     c2570     -20
    x[22]     c2574     20
    x[22]     c2672     -20
    x[22]     c2676     20
    x[22]     c2768     -20
    x[22]     c2772     20
    x[22]     c2858     -20
    x[22]     c2862     20
    x[22]     c2942     -20
    x[22]     c2946     20
    x[22]     c3025     20
    x[22]     c3027     -20
    x[22]     c3031     20
    x[22]     c3033     -20
    x[22]     c3037     20
    x[22]     c3039     -20
    x[22]     c3043     20
    x[22]     c3045     -20
    x[22]     c3049     20
    x[22]     c3051     -20
    x[22]     c3055     20
    x[22]     c3057     -20
    x[22]     c3061     20
    x[22]     c3063     -20
    x[22]     c3067     20
    x[22]     c3069     -20
    x[22]     c3073     20
    x[22]     c3075     -20
    x[22]     c3079     20
    x[22]     c3081     -20
    x[22]     c3085     20
    x[22]     c3087     -20
    x[22]     c3091     20
    x[22]     c3093     -20
    x[22]     c3097     20
    x[22]     c3099     -20
    x[23]     c45_2     -20
    x[23]     c46_2     20
    x[23]     c274_1    -1
    x[23]     c320_1    -1
    x[23]     c364_1    -1
    x[23]     c406_1    -1
    x[23]     c446_1    -1
    x[23]     c484_1    -1
    x[23]     c520_1    -1
    x[23]     c554_1    -1
    x[23]     c586_1    -1
    x[23]     c616_1    -1
    x[23]     c644_1    -1
    x[23]     c670_1    -1
    x[23]     c694_1    -1
    x[23]     c716_1    -1
    x[23]     c736_1    -1
    x[23]     c754_1    -1
    x[23]     c770_1    -1
    x[23]     c786_1    1
    x[23]     c788_1    1
    x[23]     c128_1    -20
    x[23]     c132_1    20
    x[23]     c326      -20
    x[23]     c330      20
    x[23]     c518      -20
    x[23]     c522      20
    x[23]     c704      -20
    x[23]     c708      20
    x[23]     c884      -20
    x[23]     c888      20
    x[23]     c1058     -20
    x[23]     c1062     20
    x[23]     c1226     -20
    x[23]     c1230     20
    x[23]     c1388     -20
    x[23]     c1392     20
    x[23]     c1544     -20
    x[23]     c1548     20
    x[23]     c1694     -20
    x[23]     c1698     20
    x[23]     c1838     -20
    x[23]     c1842     20
    x[23]     c1976     -20
    x[23]     c1980     20
    x[23]     c2108     -20
    x[23]     c2112     20
    x[23]     c2234     -20
    x[23]     c2238     20
    x[23]     c2354     -20
    x[23]     c2358     20
    x[23]     c2468     -20
    x[23]     c2472     20
    x[23]     c2576     -20
    x[23]     c2580     20
    x[23]     c2678     -20
    x[23]     c2682     20
    x[23]     c2774     -20
    x[23]     c2778     20
    x[23]     c2864     -20
    x[23]     c2868     20
    x[23]     c2948     -20
    x[23]     c2952     20
    x[23]     c3026     -20
    x[23]     c3030     20
    x[23]     c3103     20
    x[23]     c3105     -20
    x[23]     c3109     20
    x[23]     c3111     -20
    x[23]     c3115     20
    x[23]     c3117     -20
    x[23]     c3121     20
    x[23]     c3123     -20
    x[23]     c3127     20
    x[23]     c3129     -20
    x[23]     c3133     20
    x[23]     c3135     -20
    x[23]     c3139     20
    x[23]     c3141     -20
    x[23]     c3145     20
    x[23]     c3147     -20
    x[23]     c3151     20
    x[23]     c3153     -20
    x[23]     c3157     20
    x[23]     c3159     -20
    x[23]     c3163     20
    x[23]     c3165     -20
    x[23]     c3169     20
    x[23]     c3171     -20
    x[24]     c47_2     -20
    x[24]     c48_2     20
    x[24]     c276_1    -1
    x[24]     c322_1    -1
    x[24]     c366_1    -1
    x[24]     c408_1    -1
    x[24]     c448_1    -1
    x[24]     c486_1    -1
    x[24]     c522_1    -1
    x[24]     c556_1    -1
    x[24]     c588_1    -1
    x[24]     c618_1    -1
    x[24]     c646_1    -1
    x[24]     c672_1    -1
    x[24]     c696_1    -1
    x[24]     c718_1    -1
    x[24]     c738_1    -1
    x[24]     c756_1    -1
    x[24]     c772_1    -1
    x[24]     c786_1    -1
    x[24]     c800_1    1
    x[24]     c134_1    -20
    x[24]     c138_1    20
    x[24]     c332      -20
    x[24]     c336      20
    x[24]     c524      -20
    x[24]     c528      20
    x[24]     c710      -20
    x[24]     c714      20
    x[24]     c890      -20
    x[24]     c894      20
    x[24]     c1064     -20
    x[24]     c1068     20
    x[24]     c1232     -20
    x[24]     c1236     20
    x[24]     c1394     -20
    x[24]     c1398     20
    x[24]     c1550     -20
    x[24]     c1554     20
    x[24]     c1700     -20
    x[24]     c1704     20
    x[24]     c1844     -20
    x[24]     c1848     20
    x[24]     c1982     -20
    x[24]     c1986     20
    x[24]     c2114     -20
    x[24]     c2118     20
    x[24]     c2240     -20
    x[24]     c2244     20
    x[24]     c2360     -20
    x[24]     c2364     20
    x[24]     c2474     -20
    x[24]     c2478     20
    x[24]     c2582     -20
    x[24]     c2586     20
    x[24]     c2684     -20
    x[24]     c2688     20
    x[24]     c2780     -20
    x[24]     c2784     20
    x[24]     c2870     -20
    x[24]     c2874     20
    x[24]     c2954     -20
    x[24]     c2958     20
    x[24]     c3032     -20
    x[24]     c3036     20
    x[24]     c3104     -20
    x[24]     c3108     20
    x[24]     c3175     20
    x[24]     c3177     -20
    x[24]     c3181     20
    x[24]     c3183     -20
    x[24]     c3187     20
    x[24]     c3189     -20
    x[24]     c3193     20
    x[24]     c3195     -20
    x[24]     c3199     20
    x[24]     c3201     -20
    x[24]     c3205     20
    x[24]     c3207     -20
    x[24]     c3211     20
    x[24]     c3213     -20
    x[24]     c3217     20
    x[24]     c3219     -20
    x[24]     c3223     20
    x[24]     c3225     -20
    x[24]     c3229     20
    x[24]     c3231     -20
    x[24]     c3235     20
    x[24]     c3237     -20
    x[25]     c49_2     -20
    x[25]     c50_2     20
    x[25]     c278_1    -1
    x[25]     c324_1    -1
    x[25]     c368_1    -1
    x[25]     c410_1    -1
    x[25]     c450_1    -1
    x[25]     c488_1    -1
    x[25]     c524_1    -1
    x[25]     c558_1    -1
    x[25]     c590_1    -1
    x[25]     c620_1    -1
    x[25]     c648_1    -1
    x[25]     c674_1    -1
    x[25]     c698_1    -1
    x[25]     c720_1    -1
    x[25]     c740_1    -1
    x[25]     c758_1    -1
    x[25]     c774_1    -1
    x[25]     c788_1    -1
    x[25]     c800_1    -1
    x[25]     c140_1    -20
    x[25]     c144_1    20
    x[25]     c338      -20
    x[25]     c342      20
    x[25]     c530      -20
    x[25]     c534      20
    x[25]     c716      -20
    x[25]     c720      20
    x[25]     c896      -20
    x[25]     c900      20
    x[25]     c1070     -20
    x[25]     c1074     20
    x[25]     c1238     -20
    x[25]     c1242     20
    x[25]     c1400     -20
    x[25]     c1404     20
    x[25]     c1556     -20
    x[25]     c1560     20
    x[25]     c1706     -20
    x[25]     c1710     20
    x[25]     c1850     -20
    x[25]     c1854     20
    x[25]     c1988     -20
    x[25]     c1992     20
    x[25]     c2120     -20
    x[25]     c2124     20
    x[25]     c2246     -20
    x[25]     c2250     20
    x[25]     c2366     -20
    x[25]     c2370     20
    x[25]     c2480     -20
    x[25]     c2484     20
    x[25]     c2588     -20
    x[25]     c2592     20
    x[25]     c2690     -20
    x[25]     c2694     20
    x[25]     c2786     -20
    x[25]     c2790     20
    x[25]     c2876     -20
    x[25]     c2880     20
    x[25]     c2960     -20
    x[25]     c2964     20
    x[25]     c3038     -20
    x[25]     c3042     20
    x[25]     c3110     -20
    x[25]     c3114     20
    x[25]     c3176     -20
    x[25]     c3180     20
    x[25]     c3241     20
    x[25]     c3243     -20
    x[25]     c3247     20
    x[25]     c3249     -20
    x[25]     c3253     20
    x[25]     c3255     -20
    x[25]     c3259     20
    x[25]     c3261     -20
    x[25]     c3265     20
    x[25]     c3267     -20
    x[25]     c3271     20
    x[25]     c3273     -20
    x[25]     c3277     20
    x[25]     c3279     -20
    x[25]     c3283     20
    x[25]     c3285     -20
    x[25]     c3289     20
    x[25]     c3291     -20
    x[25]     c3295     20
    x[25]     c3297     -20
    x[26]     c51_2     -100
    x[26]     c52_2     100
    x[26]     c822_1    1
    x[26]     c824_1    1
    x[26]     c826_1    1
    x[26]     c828_1    1
    x[26]     c830_1    1
    x[26]     c832_1    1
    x[26]     c834_1    1
    x[26]     c836_1    1
    x[26]     c838_1    1
    x[26]     c146_1    -100
    x[26]     c150_1    100
    x[26]     c344      -100
    x[26]     c348      100
    x[26]     c536      -100
    x[26]     c540      100
    x[26]     c722      -100
    x[26]     c726      100
    x[26]     c902      -100
    x[26]     c906      100
    x[26]     c1076     -100
    x[26]     c1080     100
    x[26]     c1244     -100
    x[26]     c1248     100
    x[26]     c1406     -100
    x[26]     c1410     100
    x[26]     c1562     -100
    x[26]     c1566     100
    x[26]     c1712     -100
    x[26]     c1716     100
    x[26]     c1856     -100
    x[26]     c1860     100
    x[26]     c1994     -100
    x[26]     c1998     100
    x[26]     c2126     -100
    x[26]     c2130     100
    x[26]     c2252     -100
    x[26]     c2256     100
    x[26]     c2372     -100
    x[26]     c2376     100
    x[26]     c2486     -100
    x[26]     c2490     100
    x[26]     c2594     -100
    x[26]     c2598     100
    x[26]     c2696     -100
    x[26]     c2700     100
    x[26]     c2792     -100
    x[26]     c2796     100
    x[26]     c2882     -100
    x[26]     c2886     100
    x[26]     c2966     -100
    x[26]     c2970     100
    x[26]     c3044     -100
    x[26]     c3048     100
    x[26]     c3116     -100
    x[26]     c3120     100
    x[26]     c3182     -100
    x[26]     c3186     100
    x[26]     c3242     -100
    x[26]     c3246     100
    x[26]     c3301     100
    x[26]     c3303     -100
    x[26]     c3307     100
    x[26]     c3309     -100
    x[26]     c3313     100
    x[26]     c3315     -100
    x[26]     c3319     100
    x[26]     c3321     -100
    x[26]     c3325     100
    x[26]     c3327     -100
    x[26]     c3331     100
    x[26]     c3333     -100
    x[26]     c3337     100
    x[26]     c3339     -100
    x[26]     c3343     100
    x[26]     c3345     -100
    x[26]     c3349     100
    x[26]     c3351     -100
    x[27]     c53_2     -100
    x[27]     c54_2     100
    x[27]     c822_1    -1
    x[27]     c840_1    1
    x[27]     c842_1    1
    x[27]     c844_1    1
    x[27]     c846_1    1
    x[27]     c848_1    1
    x[27]     c850_1    1
    x[27]     c852_1    1
    x[27]     c854_1    1
    x[27]     c152_1    -100
    x[27]     c156_1    100
    x[27]     c350      -100
    x[27]     c354      100
    x[27]     c542      -100
    x[27]     c546      100
    x[27]     c728      -100
    x[27]     c732      100
    x[27]     c908      -100
    x[27]     c912      100
    x[27]     c1082     -100
    x[27]     c1086     100
    x[27]     c1250     -100
    x[27]     c1254     100
    x[27]     c1412     -100
    x[27]     c1416     100
    x[27]     c1568     -100
    x[27]     c1572     100
    x[27]     c1718     -100
    x[27]     c1722     100
    x[27]     c1862     -100
    x[27]     c1866     100
    x[27]     c2000     -100
    x[27]     c2004     100
    x[27]     c2132     -100
    x[27]     c2136     100
    x[27]     c2258     -100
    x[27]     c2262     100
    x[27]     c2378     -100
    x[27]     c2382     100
    x[27]     c2492     -100
    x[27]     c2496     100
    x[27]     c2600     -100
    x[27]     c2604     100
    x[27]     c2702     -100
    x[27]     c2706     100
    x[27]     c2798     -100
    x[27]     c2802     100
    x[27]     c2888     -100
    x[27]     c2892     100
    x[27]     c2972     -100
    x[27]     c2976     100
    x[27]     c3050     -100
    x[27]     c3054     100
    x[27]     c3122     -100
    x[27]     c3126     100
    x[27]     c3188     -100
    x[27]     c3192     100
    x[27]     c3248     -100
    x[27]     c3252     100
    x[27]     c3302     -100
    x[27]     c3306     100
    x[27]     c3355     100
    x[27]     c3357     -100
    x[27]     c3361     100
    x[27]     c3363     -100
    x[27]     c3367     100
    x[27]     c3369     -100
    x[27]     c3373     100
    x[27]     c3375     -100
    x[27]     c3379     100
    x[27]     c3381     -100
    x[27]     c3385     100
    x[27]     c3387     -100
    x[27]     c3391     100
    x[27]     c3393     -100
    x[27]     c3397     100
    x[27]     c3399     -100
    x[28]     c55_2     -100
    x[28]     c56_2     100
    x[28]     c824_1    -1
    x[28]     c840_1    -1
    x[28]     c856_1    1
    x[28]     c858_1    1
    x[28]     c860_1    1
    x[28]     c862_1    1
    x[28]     c864_1    1
    x[28]     c866_1    1
    x[28]     c868_1    1
    x[28]     c158_1    -100
    x[28]     c162_1    100
    x[28]     c356      -100
    x[28]     c360      100
    x[28]     c548      -100
    x[28]     c552      100
    x[28]     c734      -100
    x[28]     c738      100
    x[28]     c914      -100
    x[28]     c918      100
    x[28]     c1088     -100
    x[28]     c1092     100
    x[28]     c1256     -100
    x[28]     c1260     100
    x[28]     c1418     -100
    x[28]     c1422     100
    x[28]     c1574     -100
    x[28]     c1578     100
    x[28]     c1724     -100
    x[28]     c1728     100
    x[28]     c1868     -100
    x[28]     c1872     100
    x[28]     c2006     -100
    x[28]     c2010     100
    x[28]     c2138     -100
    x[28]     c2142     100
    x[28]     c2264     -100
    x[28]     c2268     100
    x[28]     c2384     -100
    x[28]     c2388     100
    x[28]     c2498     -100
    x[28]     c2502     100
    x[28]     c2606     -100
    x[28]     c2610     100
    x[28]     c2708     -100
    x[28]     c2712     100
    x[28]     c2804     -100
    x[28]     c2808     100
    x[28]     c2894     -100
    x[28]     c2898     100
    x[28]     c2978     -100
    x[28]     c2982     100
    x[28]     c3056     -100
    x[28]     c3060     100
    x[28]     c3128     -100
    x[28]     c3132     100
    x[28]     c3194     -100
    x[28]     c3198     100
    x[28]     c3254     -100
    x[28]     c3258     100
    x[28]     c3308     -100
    x[28]     c3312     100
    x[28]     c3356     -100
    x[28]     c3360     100
    x[28]     c3403     100
    x[28]     c3405     -100
    x[28]     c3409     100
    x[28]     c3411     -100
    x[28]     c3415     100
    x[28]     c3417     -100
    x[28]     c3421     100
    x[28]     c3423     -100
    x[28]     c3427     100
    x[28]     c3429     -100
    x[28]     c3433     100
    x[28]     c3435     -100
    x[28]     c3439     100
    x[28]     c3441     -100
    x[29]     c57_2     -100
    x[29]     c58_2     100
    x[29]     c826_1    -1
    x[29]     c842_1    -1
    x[29]     c856_1    -1
    x[29]     c870_1    1
    x[29]     c872_1    1
    x[29]     c874_1    1
    x[29]     c876_1    1
    x[29]     c878_1    1
    x[29]     c880_1    1
    x[29]     c164_1    -100
    x[29]     c168_1    100
    x[29]     c362      -100
    x[29]     c366      100
    x[29]     c554      -100
    x[29]     c558      100
    x[29]     c740      -100
    x[29]     c744      100
    x[29]     c920      -100
    x[29]     c924      100
    x[29]     c1094     -100
    x[29]     c1098     100
    x[29]     c1262     -100
    x[29]     c1266     100
    x[29]     c1424     -100
    x[29]     c1428     100
    x[29]     c1580     -100
    x[29]     c1584     100
    x[29]     c1730     -100
    x[29]     c1734     100
    x[29]     c1874     -100
    x[29]     c1878     100
    x[29]     c2012     -100
    x[29]     c2016     100
    x[29]     c2144     -100
    x[29]     c2148     100
    x[29]     c2270     -100
    x[29]     c2274     100
    x[29]     c2390     -100
    x[29]     c2394     100
    x[29]     c2504     -100
    x[29]     c2508     100
    x[29]     c2612     -100
    x[29]     c2616     100
    x[29]     c2714     -100
    x[29]     c2718     100
    x[29]     c2810     -100
    x[29]     c2814     100
    x[29]     c2900     -100
    x[29]     c2904     100
    x[29]     c2984     -100
    x[29]     c2988     100
    x[29]     c3062     -100
    x[29]     c3066     100
    x[29]     c3134     -100
    x[29]     c3138     100
    x[29]     c3200     -100
    x[29]     c3204     100
    x[29]     c3260     -100
    x[29]     c3264     100
    x[29]     c3314     -100
    x[29]     c3318     100
    x[29]     c3362     -100
    x[29]     c3366     100
    x[29]     c3404     -100
    x[29]     c3408     100
    x[29]     c3445     100
    x[29]     c3447     -100
    x[29]     c3451     100
    x[29]     c3453     -100
    x[29]     c3457     100
    x[29]     c3459     -100
    x[29]     c3463     100
    x[29]     c3465     -100
    x[29]     c3469     100
    x[29]     c3471     -100
    x[29]     c3475     100
    x[29]     c3477     -100
    x[30]     c59_2     -100
    x[30]     c60_2     100
    x[30]     c828_1    -1
    x[30]     c844_1    -1
    x[30]     c858_1    -1
    x[30]     c870_1    -1
    x[30]     c882_1    1
    x[30]     c884_1    1
    x[30]     c886_1    1
    x[30]     c888_1    1
    x[30]     c890_1    1
    x[30]     c170_1    -100
    x[30]     c174_1    100
    x[30]     c368      -100
    x[30]     c372      100
    x[30]     c560      -100
    x[30]     c564      100
    x[30]     c746      -100
    x[30]     c750      100
    x[30]     c926      -100
    x[30]     c930      100
    x[30]     c1100     -100
    x[30]     c1104     100
    x[30]     c1268     -100
    x[30]     c1272     100
    x[30]     c1430     -100
    x[30]     c1434     100
    x[30]     c1586     -100
    x[30]     c1590     100
    x[30]     c1736     -100
    x[30]     c1740     100
    x[30]     c1880     -100
    x[30]     c1884     100
    x[30]     c2018     -100
    x[30]     c2022     100
    x[30]     c2150     -100
    x[30]     c2154     100
    x[30]     c2276     -100
    x[30]     c2280     100
    x[30]     c2396     -100
    x[30]     c2400     100
    x[30]     c2510     -100
    x[30]     c2514     100
    x[30]     c2618     -100
    x[30]     c2622     100
    x[30]     c2720     -100
    x[30]     c2724     100
    x[30]     c2816     -100
    x[30]     c2820     100
    x[30]     c2906     -100
    x[30]     c2910     100
    x[30]     c2990     -100
    x[30]     c2994     100
    x[30]     c3068     -100
    x[30]     c3072     100
    x[30]     c3140     -100
    x[30]     c3144     100
    x[30]     c3206     -100
    x[30]     c3210     100
    x[30]     c3266     -100
    x[30]     c3270     100
    x[30]     c3320     -100
    x[30]     c3324     100
    x[30]     c3368     -100
    x[30]     c3372     100
    x[30]     c3410     -100
    x[30]     c3414     100
    x[30]     c3446     -100
    x[30]     c3450     100
    x[30]     c3481     100
    x[30]     c3483     -100
    x[30]     c3487     100
    x[30]     c3489     -100
    x[30]     c3493     100
    x[30]     c3495     -100
    x[30]     c3499     100
    x[30]     c3501     -100
    x[30]     c3505     100
    x[30]     c3507     -100
    x[31]     c61_2     -100
    x[31]     c62_2     100
    x[31]     c830_1    -1
    x[31]     c846_1    -1
    x[31]     c860_1    -1
    x[31]     c872_1    -1
    x[31]     c882_1    -1
    x[31]     c892_1    1
    x[31]     c894_1    1
    x[31]     c896_1    1
    x[31]     c898_1    1
    x[31]     c176_1    -100
    x[31]     c180_1    100
    x[31]     c374      -100
    x[31]     c378      100
    x[31]     c566      -100
    x[31]     c570      100
    x[31]     c752      -100
    x[31]     c756      100
    x[31]     c932      -100
    x[31]     c936      100
    x[31]     c1106     -100
    x[31]     c1110     100
    x[31]     c1274     -100
    x[31]     c1278     100
    x[31]     c1436     -100
    x[31]     c1440     100
    x[31]     c1592     -100
    x[31]     c1596     100
    x[31]     c1742     -100
    x[31]     c1746     100
    x[31]     c1886     -100
    x[31]     c1890     100
    x[31]     c2024     -100
    x[31]     c2028     100
    x[31]     c2156     -100
    x[31]     c2160     100
    x[31]     c2282     -100
    x[31]     c2286     100
    x[31]     c2402     -100
    x[31]     c2406     100
    x[31]     c2516     -100
    x[31]     c2520     100
    x[31]     c2624     -100
    x[31]     c2628     100
    x[31]     c2726     -100
    x[31]     c2730     100
    x[31]     c2822     -100
    x[31]     c2826     100
    x[31]     c2912     -100
    x[31]     c2916     100
    x[31]     c2996     -100
    x[31]     c3000     100
    x[31]     c3074     -100
    x[31]     c3078     100
    x[31]     c3146     -100
    x[31]     c3150     100
    x[31]     c3212     -100
    x[31]     c3216     100
    x[31]     c3272     -100
    x[31]     c3276     100
    x[31]     c3326     -100
    x[31]     c3330     100
    x[31]     c3374     -100
    x[31]     c3378     100
    x[31]     c3416     -100
    x[31]     c3420     100
    x[31]     c3452     -100
    x[31]     c3456     100
    x[31]     c3482     -100
    x[31]     c3486     100
    x[31]     c3511     100
    x[31]     c3513     -100
    x[31]     c3517     100
    x[31]     c3519     -100
    x[31]     c3523     100
    x[31]     c3525     -100
    x[31]     c3529     100
    x[31]     c3531     -100
    x[32]     c63_2     -100
    x[32]     c64_2     100
    x[32]     c832_1    -1
    x[32]     c848_1    -1
    x[32]     c862_1    -1
    x[32]     c874_1    -1
    x[32]     c884_1    -1
    x[32]     c892_1    -1
    x[32]     c900_1    1
    x[32]     c902_1    1
    x[32]     c904_1    1
    x[32]     c182_1    -100
    x[32]     c186_1    100
    x[32]     c380      -100
    x[32]     c384      100
    x[32]     c572      -100
    x[32]     c576      100
    x[32]     c758      -100
    x[32]     c762      100
    x[32]     c938      -100
    x[32]     c942      100
    x[32]     c1112     -100
    x[32]     c1116     100
    x[32]     c1280     -100
    x[32]     c1284     100
    x[32]     c1442     -100
    x[32]     c1446     100
    x[32]     c1598     -100
    x[32]     c1602     100
    x[32]     c1748     -100
    x[32]     c1752     100
    x[32]     c1892     -100
    x[32]     c1896     100
    x[32]     c2030     -100
    x[32]     c2034     100
    x[32]     c2162     -100
    x[32]     c2166     100
    x[32]     c2288     -100
    x[32]     c2292     100
    x[32]     c2408     -100
    x[32]     c2412     100
    x[32]     c2522     -100
    x[32]     c2526     100
    x[32]     c2630     -100
    x[32]     c2634     100
    x[32]     c2732     -100
    x[32]     c2736     100
    x[32]     c2828     -100
    x[32]     c2832     100
    x[32]     c2918     -100
    x[32]     c2922     100
    x[32]     c3002     -100
    x[32]     c3006     100
    x[32]     c3080     -100
    x[32]     c3084     100
    x[32]     c3152     -100
    x[32]     c3156     100
    x[32]     c3218     -100
    x[32]     c3222     100
    x[32]     c3278     -100
    x[32]     c3282     100
    x[32]     c3332     -100
    x[32]     c3336     100
    x[32]     c3380     -100
    x[32]     c3384     100
    x[32]     c3422     -100
    x[32]     c3426     100
    x[32]     c3458     -100
    x[32]     c3462     100
    x[32]     c3488     -100
    x[32]     c3492     100
    x[32]     c3512     -100
    x[32]     c3516     100
    x[32]     c3535     100
    x[32]     c3537     -100
    x[32]     c3541     100
    x[32]     c3543     -100
    x[32]     c3547     100
    x[32]     c3549     -100
    x[33]     c65_2     -100
    x[33]     c66_2     100
    x[33]     c834_1    -1
    x[33]     c850_1    -1
    x[33]     c864_1    -1
    x[33]     c876_1    -1
    x[33]     c886_1    -1
    x[33]     c894_1    -1
    x[33]     c900_1    -1
    x[33]     c906_1    1
    x[33]     c908_1    1
    x[33]     c188_1    -100
    x[33]     c192_1    100
    x[33]     c386      -100
    x[33]     c390      100
    x[33]     c578      -100
    x[33]     c582      100
    x[33]     c764      -100
    x[33]     c768      100
    x[33]     c944      -100
    x[33]     c948      100
    x[33]     c1118     -100
    x[33]     c1122     100
    x[33]     c1286     -100
    x[33]     c1290     100
    x[33]     c1448     -100
    x[33]     c1452     100
    x[33]     c1604     -100
    x[33]     c1608     100
    x[33]     c1754     -100
    x[33]     c1758     100
    x[33]     c1898     -100
    x[33]     c1902     100
    x[33]     c2036     -100
    x[33]     c2040     100
    x[33]     c2168     -100
    x[33]     c2172     100
    x[33]     c2294     -100
    x[33]     c2298     100
    x[33]     c2414     -100
    x[33]     c2418     100
    x[33]     c2528     -100
    x[33]     c2532     100
    x[33]     c2636     -100
    x[33]     c2640     100
    x[33]     c2738     -100
    x[33]     c2742     100
    x[33]     c2834     -100
    x[33]     c2838     100
    x[33]     c2924     -100
    x[33]     c2928     100
    x[33]     c3008     -100
    x[33]     c3012     100
    x[33]     c3086     -100
    x[33]     c3090     100
    x[33]     c3158     -100
    x[33]     c3162     100
    x[33]     c3224     -100
    x[33]     c3228     100
    x[33]     c3284     -100
    x[33]     c3288     100
    x[33]     c3338     -100
    x[33]     c3342     100
    x[33]     c3386     -100
    x[33]     c3390     100
    x[33]     c3428     -100
    x[33]     c3432     100
    x[33]     c3464     -100
    x[33]     c3468     100
    x[33]     c3494     -100
    x[33]     c3498     100
    x[33]     c3518     -100
    x[33]     c3522     100
    x[33]     c3536     -100
    x[33]     c3540     100
    x[33]     c3553     100
    x[33]     c3555     -100
    x[33]     c3559     100
    x[33]     c3561     -100
    x[34]     c67_2     -100
    x[34]     c68_2     100
    x[34]     c836_1    -1
    x[34]     c852_1    -1
    x[34]     c866_1    -1
    x[34]     c878_1    -1
    x[34]     c888_1    -1
    x[34]     c896_1    -1
    x[34]     c902_1    -1
    x[34]     c906_1    -1
    x[34]     c910_1    1
    x[34]     c911_1    -1
    x[34]     c912_1    -1
    x[34]     c913_1    -1
    x[34]     c914_1    -1
    x[34]     c915_1    -1
    x[34]     c916_1    -1
    x[34]     c917_1    -1
    x[34]     c918_1    -1
    x[34]     c919_1    -1
    x[34]     c920_1    -1
    x[34]     c921_1    -1
    x[34]     c922_1    -1
    x[34]     c923_1    -1
    x[34]     c924_1    -1
    x[34]     c925_1    -1
    x[34]     c926_1    -1
    x[34]     c927_1    -1
    x[34]     c928_1    -1
    x[34]     c929_1    -1
    x[34]     c930_1    -1
    x[34]     c931_1    -1
    x[34]     c932_1    -1
    x[34]     c933_1    -1
    x[34]     c934_1    -1
    x[34]     c935_1    -1
    x[34]     c194_1    -100
    x[34]     c198_1    100
    x[34]     c392      -100
    x[34]     c396      100
    x[34]     c584      -100
    x[34]     c588      100
    x[34]     c770      -100
    x[34]     c774      100
    x[34]     c950      -100
    x[34]     c954      100
    x[34]     c1124     -100
    x[34]     c1128     100
    x[34]     c1292     -100
    x[34]     c1296     100
    x[34]     c1454     -100
    x[34]     c1458     100
    x[34]     c1610     -100
    x[34]     c1614     100
    x[34]     c1760     -100
    x[34]     c1764     100
    x[34]     c1904     -100
    x[34]     c1908     100
    x[34]     c2042     -100
    x[34]     c2046     100
    x[34]     c2174     -100
    x[34]     c2178     100
    x[34]     c2300     -100
    x[34]     c2304     100
    x[34]     c2420     -100
    x[34]     c2424     100
    x[34]     c2534     -100
    x[34]     c2538     100
    x[34]     c2642     -100
    x[34]     c2646     100
    x[34]     c2744     -100
    x[34]     c2748     100
    x[34]     c2840     -100
    x[34]     c2844     100
    x[34]     c2930     -100
    x[34]     c2934     100
    x[34]     c3014     -100
    x[34]     c3018     100
    x[34]     c3092     -100
    x[34]     c3096     100
    x[34]     c3164     -100
    x[34]     c3168     100
    x[34]     c3230     -100
    x[34]     c3234     100
    x[34]     c3290     -100
    x[34]     c3294     100
    x[34]     c3344     -100
    x[34]     c3348     100
    x[34]     c3392     -100
    x[34]     c3396     100
    x[34]     c3434     -100
    x[34]     c3438     100
    x[34]     c3470     -100
    x[34]     c3474     100
    x[34]     c3500     -100
    x[34]     c3504     100
    x[34]     c3524     -100
    x[34]     c3528     100
    x[34]     c3542     -100
    x[34]     c3546     100
    x[34]     c3554     -100
    x[34]     c3558     100
    x[34]     c3565     100
    x[34]     c3567     -100
    x[35]     c69_2     -100
    x[35]     c70_2     100
    x[35]     c838_1    -1
    x[35]     c854_1    -1
    x[35]     c868_1    -1
    x[35]     c880_1    -1
    x[35]     c890_1    -1
    x[35]     c898_1    -1
    x[35]     c904_1    -1
    x[35]     c908_1    -1
    x[35]     c910_1    -1
    x[35]     c200_1    -100
    x[35]     c204_1    100
    x[35]     c398      -100
    x[35]     c402      100
    x[35]     c590      -100
    x[35]     c594      100
    x[35]     c776      -100
    x[35]     c780      100
    x[35]     c956      -100
    x[35]     c960      100
    x[35]     c1130     -100
    x[35]     c1134     100
    x[35]     c1298     -100
    x[35]     c1302     100
    x[35]     c1460     -100
    x[35]     c1464     100
    x[35]     c1616     -100
    x[35]     c1620     100
    x[35]     c1766     -100
    x[35]     c1770     100
    x[35]     c1910     -100
    x[35]     c1914     100
    x[35]     c2048     -100
    x[35]     c2052     100
    x[35]     c2180     -100
    x[35]     c2184     100
    x[35]     c2306     -100
    x[35]     c2310     100
    x[35]     c2426     -100
    x[35]     c2430     100
    x[35]     c2540     -100
    x[35]     c2544     100
    x[35]     c2648     -100
    x[35]     c2652     100
    x[35]     c2750     -100
    x[35]     c2754     100
    x[35]     c2846     -100
    x[35]     c2850     100
    x[35]     c2936     -100
    x[35]     c2940     100
    x[35]     c3020     -100
    x[35]     c3024     100
    x[35]     c3098     -100
    x[35]     c3102     100
    x[35]     c3170     -100
    x[35]     c3174     100
    x[35]     c3236     -100
    x[35]     c3240     100
    x[35]     c3296     -100
    x[35]     c3300     100
    x[35]     c3350     -100
    x[35]     c3354     100
    x[35]     c3398     -100
    x[35]     c3402     100
    x[35]     c3440     -100
    x[35]     c3444     100
    x[35]     c3476     -100
    x[35]     c3480     100
    x[35]     c3506     -100
    x[35]     c3510     100
    x[35]     c3530     -100
    x[35]     c3534     100
    x[35]     c3548     -100
    x[35]     c3552     100
    x[35]     c3560     -100
    x[35]     c3564     100
    x[35]     c3566     -100
    x[35]     c3570     100
    MARKER    'MARKER'                 'INTEND'
    x[36]     c1_2      1
    x[36]     c1_1      -1
    x[36]     c6_1      1
    x[36]     c7_1      -1
    x[36]     c12_1     1
    x[36]     c13_1     -1
    x[36]     c18_1     1
    x[36]     c19_1     -1
    x[36]     c24_1     1
    x[36]     c25_1     -1
    x[36]     c30_1     1
    x[36]     c31_1     -1
    x[36]     c36_1     1
    x[36]     c37_1     -1
    x[36]     c42_1     1
    x[36]     c43_1     -1
    x[36]     c48_1     1
    x[36]     c49_1     -1
    x[36]     c54_1     1
    x[36]     c55_1     -1
    x[36]     c60_1     1
    x[36]     c61_1     -1
    x[36]     c66_1     1
    x[36]     c67_1     -1
    x[36]     c72_1     1
    x[36]     c73_1     -1
    x[36]     c78_1     1
    x[36]     c79_1     -1
    x[36]     c84_1     1
    x[36]     c85_1     -1
    x[36]     c90_1     1
    x[36]     c91_1     -1
    x[36]     c96_1     1
    x[36]     c97_1     -1
    x[36]     c102_1    1
    x[36]     c103_1    -1
    x[36]     c108_1    1
    x[36]     c109_1    -1
    x[36]     c114_1    1
    x[36]     c115_1    -1
    x[36]     c120_1    1
    x[36]     c121_1    -1
    x[36]     c126_1    1
    x[36]     c127_1    -1
    x[36]     c132_1    1
    x[36]     c133_1    -1
    x[36]     c138_1    1
    x[36]     c139_1    -1
    x[36]     c144_1    1
    x[36]     c145_1    -1
    x[36]     c150_1    1
    x[36]     c151_1    -1
    x[36]     c156_1    1
    x[36]     c157_1    -1
    x[36]     c162_1    1
    x[36]     c163_1    -1
    x[36]     c168_1    1
    x[36]     c169_1    -1
    x[36]     c174_1    1
    x[36]     c175_1    -1
    x[36]     c180_1    1
    x[36]     c181_1    -1
    x[36]     c186_1    1
    x[36]     c187_1    -1
    x[36]     c192_1    1
    x[36]     c193_1    -1
    x[36]     c198_1    1
    x[36]     c199_1    -1
    x[36]     c204_1    1
    x[37]     c3_2      1
    x[37]     c1_1      1
    x[37]     c6_1      -1
    x[37]     c205_1    -1
    x[37]     c210_1    1
    x[37]     c211_1    -1
    x[37]     c216_1    1
    x[37]     c217_1    -1
    x[37]     c222_1    1
    x[37]     c223_1    -1
    x[37]     c228_1    1
    x[37]     c229_1    -1
    x[37]     c234_1    1
    x[37]     c235_1    -1
    x[37]     c240_1    1
    x[37]     c241_1    -1
    x[37]     c246      1
    x[37]     c247      -1
    x[37]     c252      1
    x[37]     c253      -1
    x[37]     c258      1
    x[37]     c259      -1
    x[37]     c264      1
    x[37]     c265      -1
    x[37]     c270      1
    x[37]     c271      -1
    x[37]     c276      1
    x[37]     c277      -1
    x[37]     c282      1
    x[37]     c283      -1
    x[37]     c288      1
    x[37]     c289      -1
    x[37]     c294      1
    x[37]     c295      -1
    x[37]     c300      1
    x[37]     c301      -1
    x[37]     c306      1
    x[37]     c307      -1
    x[37]     c312      1
    x[37]     c313      -1
    x[37]     c318      1
    x[37]     c319      -1
    x[37]     c324      1
    x[37]     c325      -1
    x[37]     c330      1
    x[37]     c331      -1
    x[37]     c336      1
    x[37]     c337      -1
    x[37]     c342      1
    x[37]     c343      -1
    x[37]     c348      1
    x[37]     c349      -1
    x[37]     c354      1
    x[37]     c355      -1
    x[37]     c360      1
    x[37]     c361      -1
    x[37]     c366      1
    x[37]     c367      -1
    x[37]     c372      1
    x[37]     c373      -1
    x[37]     c378      1
    x[37]     c379      -1
    x[37]     c384      1
    x[37]     c385      -1
    x[37]     c390      1
    x[37]     c391      -1
    x[37]     c396      1
    x[37]     c397      -1
    x[37]     c402      1
    x[38]     c5_2      1
    x[38]     c7_1      1
    x[38]     c12_1     -1
    x[38]     c205_1    1
    x[38]     c210_1    -1
    x[38]     c403      -1
    x[38]     c408      1
    x[38]     c409      -1
    x[38]     c414      1
    x[38]     c415      -1
    x[38]     c420      1
    x[38]     c421      -1
    x[38]     c426      1
    x[38]     c427      -1
    x[38]     c432      1
    x[38]     c433      -1
    x[38]     c438      1
    x[38]     c439      -1
    x[38]     c444      1
    x[38]     c445      -1
    x[38]     c450      1
    x[38]     c451      -1
    x[38]     c456      1
    x[38]     c457      -1
    x[38]     c462      1
    x[38]     c463      -1
    x[38]     c468      1
    x[38]     c469      -1
    x[38]     c474      1
    x[38]     c475      -1
    x[38]     c480      1
    x[38]     c481      -1
    x[38]     c486      1
    x[38]     c487      -1
    x[38]     c492      1
    x[38]     c493      -1
    x[38]     c498      1
    x[38]     c499      -1
    x[38]     c504      1
    x[38]     c505      -1
    x[38]     c510      1
    x[38]     c511      -1
    x[38]     c516      1
    x[38]     c517      -1
    x[38]     c522      1
    x[38]     c523      -1
    x[38]     c528      1
    x[38]     c529      -1
    x[38]     c534      1
    x[38]     c535      -1
    x[38]     c540      1
    x[38]     c541      -1
    x[38]     c546      1
    x[38]     c547      -1
    x[38]     c552      1
    x[38]     c553      -1
    x[38]     c558      1
    x[38]     c559      -1
    x[38]     c564      1
    x[38]     c565      -1
    x[38]     c570      1
    x[38]     c571      -1
    x[38]     c576      1
    x[38]     c577      -1
    x[38]     c582      1
    x[38]     c583      -1
    x[38]     c588      1
    x[38]     c589      -1
    x[38]     c594      1
    x[39]     c7_2      1
    x[39]     c13_1     1
    x[39]     c18_1     -1
    x[39]     c211_1    1
    x[39]     c216_1    -1
    x[39]     c403      1
    x[39]     c408      -1
    x[39]     c595      -1
    x[39]     c600      1
    x[39]     c601      -1
    x[39]     c606      1
    x[39]     c607      -1
    x[39]     c612      1
    x[39]     c613      -1
    x[39]     c618      1
    x[39]     c619      -1
    x[39]     c624      1
    x[39]     c625      -1
    x[39]     c630      1
    x[39]     c631      -1
    x[39]     c636      1
    x[39]     c637      -1
    x[39]     c642      1
    x[39]     c643      -1
    x[39]     c648      1
    x[39]     c649      -1
    x[39]     c654      1
    x[39]     c655      -1
    x[39]     c660      1
    x[39]     c661      -1
    x[39]     c666      1
    x[39]     c667      -1
    x[39]     c672      1
    x[39]     c673      -1
    x[39]     c678      1
    x[39]     c679      -1
    x[39]     c684      1
    x[39]     c685      -1
    x[39]     c690      1
    x[39]     c691      -1
    x[39]     c696      1
    x[39]     c697      -1
    x[39]     c702      1
    x[39]     c703      -1
    x[39]     c708      1
    x[39]     c709      -1
    x[39]     c714      1
    x[39]     c715      -1
    x[39]     c720      1
    x[39]     c721      -1
    x[39]     c726      1
    x[39]     c727      -1
    x[39]     c732      1
    x[39]     c733      -1
    x[39]     c738      1
    x[39]     c739      -1
    x[39]     c744      1
    x[39]     c745      -1
    x[39]     c750      1
    x[39]     c751      -1
    x[39]     c756      1
    x[39]     c757      -1
    x[39]     c762      1
    x[39]     c763      -1
    x[39]     c768      1
    x[39]     c769      -1
    x[39]     c774      1
    x[39]     c775      -1
    x[39]     c780      1
    x[40]     c9_2      1
    x[40]     c19_1     1
    x[40]     c24_1     -1
    x[40]     c217_1    1
    x[40]     c222_1    -1
    x[40]     c409      1
    x[40]     c414      -1
    x[40]     c595      1
    x[40]     c600      -1
    x[40]     c781      -1
    x[40]     c786      1
    x[40]     c787      -1
    x[40]     c792      1
    x[40]     c793      -1
    x[40]     c798      1
    x[40]     c799      -1
    x[40]     c804      1
    x[40]     c805      -1
    x[40]     c810      1
    x[40]     c811      -1
    x[40]     c816      1
    x[40]     c817      -1
    x[40]     c822      1
    x[40]     c823      -1
    x[40]     c828      1
    x[40]     c829      -1
    x[40]     c834      1
    x[40]     c835      -1
    x[40]     c840      1
    x[40]     c841      -1
    x[40]     c846      1
    x[40]     c847      -1
    x[40]     c852      1
    x[40]     c853      -1
    x[40]     c858      1
    x[40]     c859      -1
    x[40]     c864      1
    x[40]     c865      -1
    x[40]     c870      1
    x[40]     c871      -1
    x[40]     c876      1
    x[40]     c877      -1
    x[40]     c882      1
    x[40]     c883      -1
    x[40]     c888      1
    x[40]     c889      -1
    x[40]     c894      1
    x[40]     c895      -1
    x[40]     c900      1
    x[40]     c901      -1
    x[40]     c906      1
    x[40]     c907      -1
    x[40]     c912      1
    x[40]     c913      -1
    x[40]     c918      1
    x[40]     c919      -1
    x[40]     c924      1
    x[40]     c925      -1
    x[40]     c930      1
    x[40]     c931      -1
    x[40]     c936      1
    x[40]     c937      -1
    x[40]     c942      1
    x[40]     c943      -1
    x[40]     c948      1
    x[40]     c949      -1
    x[40]     c954      1
    x[40]     c955      -1
    x[40]     c960      1
    x[41]     c11_2     1
    x[41]     c25_1     1
    x[41]     c30_1     -1
    x[41]     c223_1    1
    x[41]     c228_1    -1
    x[41]     c415      1
    x[41]     c420      -1
    x[41]     c601      1
    x[41]     c606      -1
    x[41]     c781      1
    x[41]     c786      -1
    x[41]     c961      -1
    x[41]     c966      1
    x[41]     c967      -1
    x[41]     c972      1
    x[41]     c973      -1
    x[41]     c978      1
    x[41]     c979      -1
    x[41]     c984      1
    x[41]     c985      -1
    x[41]     c990      1
    x[41]     c991      -1
    x[41]     c996      1
    x[41]     c997      -1
    x[41]     c1002     1
    x[41]     c1003     -1
    x[41]     c1008     1
    x[41]     c1009     -1
    x[41]     c1014     1
    x[41]     c1015     -1
    x[41]     c1020     1
    x[41]     c1021     -1
    x[41]     c1026     1
    x[41]     c1027     -1
    x[41]     c1032     1
    x[41]     c1033     -1
    x[41]     c1038     1
    x[41]     c1039     -1
    x[41]     c1044     1
    x[41]     c1045     -1
    x[41]     c1050     1
    x[41]     c1051     -1
    x[41]     c1056     1
    x[41]     c1057     -1
    x[41]     c1062     1
    x[41]     c1063     -1
    x[41]     c1068     1
    x[41]     c1069     -1
    x[41]     c1074     1
    x[41]     c1075     -1
    x[41]     c1080     1
    x[41]     c1081     -1
    x[41]     c1086     1
    x[41]     c1087     -1
    x[41]     c1092     1
    x[41]     c1093     -1
    x[41]     c1098     1
    x[41]     c1099     -1
    x[41]     c1104     1
    x[41]     c1105     -1
    x[41]     c1110     1
    x[41]     c1111     -1
    x[41]     c1116     1
    x[41]     c1117     -1
    x[41]     c1122     1
    x[41]     c1123     -1
    x[41]     c1128     1
    x[41]     c1129     -1
    x[41]     c1134     1
    x[42]     c13_2     1
    x[42]     c31_1     1
    x[42]     c36_1     -1
    x[42]     c229_1    1
    x[42]     c234_1    -1
    x[42]     c421      1
    x[42]     c426      -1
    x[42]     c607      1
    x[42]     c612      -1
    x[42]     c787      1
    x[42]     c792      -1
    x[42]     c961      1
    x[42]     c966      -1
    x[42]     c1135     -1
    x[42]     c1140     1
    x[42]     c1141     -1
    x[42]     c1146     1
    x[42]     c1147     -1
    x[42]     c1152     1
    x[42]     c1153     -1
    x[42]     c1158     1
    x[42]     c1159     -1
    x[42]     c1164     1
    x[42]     c1165     -1
    x[42]     c1170     1
    x[42]     c1171     -1
    x[42]     c1176     1
    x[42]     c1177     -1
    x[42]     c1182     1
    x[42]     c1183     -1
    x[42]     c1188     1
    x[42]     c1189     -1
    x[42]     c1194     1
    x[42]     c1195     -1
    x[42]     c1200     1
    x[42]     c1201     -1
    x[42]     c1206     1
    x[42]     c1207     -1
    x[42]     c1212     1
    x[42]     c1213     -1
    x[42]     c1218     1
    x[42]     c1219     -1
    x[42]     c1224     1
    x[42]     c1225     -1
    x[42]     c1230     1
    x[42]     c1231     -1
    x[42]     c1236     1
    x[42]     c1237     -1
    x[42]     c1242     1
    x[42]     c1243     -1
    x[42]     c1248     1
    x[42]     c1249     -1
    x[42]     c1254     1
    x[42]     c1255     -1
    x[42]     c1260     1
    x[42]     c1261     -1
    x[42]     c1266     1
    x[42]     c1267     -1
    x[42]     c1272     1
    x[42]     c1273     -1
    x[42]     c1278     1
    x[42]     c1279     -1
    x[42]     c1284     1
    x[42]     c1285     -1
    x[42]     c1290     1
    x[42]     c1291     -1
    x[42]     c1296     1
    x[42]     c1297     -1
    x[42]     c1302     1
    x[43]     c15_2     1
    x[43]     c37_1     1
    x[43]     c42_1     -1
    x[43]     c235_1    1
    x[43]     c240_1    -1
    x[43]     c427      1
    x[43]     c432      -1
    x[43]     c613      1
    x[43]     c618      -1
    x[43]     c793      1
    x[43]     c798      -1
    x[43]     c967      1
    x[43]     c972      -1
    x[43]     c1135     1
    x[43]     c1140     -1
    x[43]     c1303     -1
    x[43]     c1308     1
    x[43]     c1309     -1
    x[43]     c1314     1
    x[43]     c1315     -1
    x[43]     c1320     1
    x[43]     c1321     -1
    x[43]     c1326     1
    x[43]     c1327     -1
    x[43]     c1332     1
    x[43]     c1333     -1
    x[43]     c1338     1
    x[43]     c1339     -1
    x[43]     c1344     1
    x[43]     c1345     -1
    x[43]     c1350     1
    x[43]     c1351     -1
    x[43]     c1356     1
    x[43]     c1357     -1
    x[43]     c1362     1
    x[43]     c1363     -1
    x[43]     c1368     1
    x[43]     c1369     -1
    x[43]     c1374     1
    x[43]     c1375     -1
    x[43]     c1380     1
    x[43]     c1381     -1
    x[43]     c1386     1
    x[43]     c1387     -1
    x[43]     c1392     1
    x[43]     c1393     -1
    x[43]     c1398     1
    x[43]     c1399     -1
    x[43]     c1404     1
    x[43]     c1405     -1
    x[43]     c1410     1
    x[43]     c1411     -1
    x[43]     c1416     1
    x[43]     c1417     -1
    x[43]     c1422     1
    x[43]     c1423     -1
    x[43]     c1428     1
    x[43]     c1429     -1
    x[43]     c1434     1
    x[43]     c1435     -1
    x[43]     c1440     1
    x[43]     c1441     -1
    x[43]     c1446     1
    x[43]     c1447     -1
    x[43]     c1452     1
    x[43]     c1453     -1
    x[43]     c1458     1
    x[43]     c1459     -1
    x[43]     c1464     1
    x[44]     c17_2     1
    x[44]     c43_1     1
    x[44]     c48_1     -1
    x[44]     c241_1    1
    x[44]     c246      -1
    x[44]     c433      1
    x[44]     c438      -1
    x[44]     c619      1
    x[44]     c624      -1
    x[44]     c799      1
    x[44]     c804      -1
    x[44]     c973      1
    x[44]     c978      -1
    x[44]     c1141     1
    x[44]     c1146     -1
    x[44]     c1303     1
    x[44]     c1308     -1
    x[44]     c1465     -1
    x[44]     c1470     1
    x[44]     c1471     -1
    x[44]     c1476     1
    x[44]     c1477     -1
    x[44]     c1482     1
    x[44]     c1483     -1
    x[44]     c1488     1
    x[44]     c1489     -1
    x[44]     c1494     1
    x[44]     c1495     -1
    x[44]     c1500     1
    x[44]     c1501     -1
    x[44]     c1506     1
    x[44]     c1507     -1
    x[44]     c1512     1
    x[44]     c1513     -1
    x[44]     c1518     1
    x[44]     c1519     -1
    x[44]     c1524     1
    x[44]     c1525     -1
    x[44]     c1530     1
    x[44]     c1531     -1
    x[44]     c1536     1
    x[44]     c1537     -1
    x[44]     c1542     1
    x[44]     c1543     -1
    x[44]     c1548     1
    x[44]     c1549     -1
    x[44]     c1554     1
    x[44]     c1555     -1
    x[44]     c1560     1
    x[44]     c1561     -1
    x[44]     c1566     1
    x[44]     c1567     -1
    x[44]     c1572     1
    x[44]     c1573     -1
    x[44]     c1578     1
    x[44]     c1579     -1
    x[44]     c1584     1
    x[44]     c1585     -1
    x[44]     c1590     1
    x[44]     c1591     -1
    x[44]     c1596     1
    x[44]     c1597     -1
    x[44]     c1602     1
    x[44]     c1603     -1
    x[44]     c1608     1
    x[44]     c1609     -1
    x[44]     c1614     1
    x[44]     c1615     -1
    x[44]     c1620     1
    x[45]     c19_2     1
    x[45]     c49_1     1
    x[45]     c54_1     -1
    x[45]     c247      1
    x[45]     c252      -1
    x[45]     c439      1
    x[45]     c444      -1
    x[45]     c625      1
    x[45]     c630      -1
    x[45]     c805      1
    x[45]     c810      -1
    x[45]     c979      1
    x[45]     c984      -1
    x[45]     c1147     1
    x[45]     c1152     -1
    x[45]     c1309     1
    x[45]     c1314     -1
    x[45]     c1465     1
    x[45]     c1470     -1
    x[45]     c1621     -1
    x[45]     c1626     1
    x[45]     c1627     -1
    x[45]     c1632     1
    x[45]     c1633     -1
    x[45]     c1638     1
    x[45]     c1639     -1
    x[45]     c1644     1
    x[45]     c1645     -1
    x[45]     c1650     1
    x[45]     c1651     -1
    x[45]     c1656     1
    x[45]     c1657     -1
    x[45]     c1662     1
    x[45]     c1663     -1
    x[45]     c1668     1
    x[45]     c1669     -1
    x[45]     c1674     1
    x[45]     c1675     -1
    x[45]     c1680     1
    x[45]     c1681     -1
    x[45]     c1686     1
    x[45]     c1687     -1
    x[45]     c1692     1
    x[45]     c1693     -1
    x[45]     c1698     1
    x[45]     c1699     -1
    x[45]     c1704     1
    x[45]     c1705     -1
    x[45]     c1710     1
    x[45]     c1711     -1
    x[45]     c1716     1
    x[45]     c1717     -1
    x[45]     c1722     1
    x[45]     c1723     -1
    x[45]     c1728     1
    x[45]     c1729     -1
    x[45]     c1734     1
    x[45]     c1735     -1
    x[45]     c1740     1
    x[45]     c1741     -1
    x[45]     c1746     1
    x[45]     c1747     -1
    x[45]     c1752     1
    x[45]     c1753     -1
    x[45]     c1758     1
    x[45]     c1759     -1
    x[45]     c1764     1
    x[45]     c1765     -1
    x[45]     c1770     1
    x[46]     c21_2     1
    x[46]     c55_1     1
    x[46]     c60_1     -1
    x[46]     c253      1
    x[46]     c258      -1
    x[46]     c445      1
    x[46]     c450      -1
    x[46]     c631      1
    x[46]     c636      -1
    x[46]     c811      1
    x[46]     c816      -1
    x[46]     c985      1
    x[46]     c990      -1
    x[46]     c1153     1
    x[46]     c1158     -1
    x[46]     c1315     1
    x[46]     c1320     -1
    x[46]     c1471     1
    x[46]     c1476     -1
    x[46]     c1621     1
    x[46]     c1626     -1
    x[46]     c1771     -1
    x[46]     c1776     1
    x[46]     c1777     -1
    x[46]     c1782     1
    x[46]     c1783     -1
    x[46]     c1788     1
    x[46]     c1789     -1
    x[46]     c1794     1
    x[46]     c1795     -1
    x[46]     c1800     1
    x[46]     c1801     -1
    x[46]     c1806     1
    x[46]     c1807     -1
    x[46]     c1812     1
    x[46]     c1813     -1
    x[46]     c1818     1
    x[46]     c1819     -1
    x[46]     c1824     1
    x[46]     c1825     -1
    x[46]     c1830     1
    x[46]     c1831     -1
    x[46]     c1836     1
    x[46]     c1837     -1
    x[46]     c1842     1
    x[46]     c1843     -1
    x[46]     c1848     1
    x[46]     c1849     -1
    x[46]     c1854     1
    x[46]     c1855     -1
    x[46]     c1860     1
    x[46]     c1861     -1
    x[46]     c1866     1
    x[46]     c1867     -1
    x[46]     c1872     1
    x[46]     c1873     -1
    x[46]     c1878     1
    x[46]     c1879     -1
    x[46]     c1884     1
    x[46]     c1885     -1
    x[46]     c1890     1
    x[46]     c1891     -1
    x[46]     c1896     1
    x[46]     c1897     -1
    x[46]     c1902     1
    x[46]     c1903     -1
    x[46]     c1908     1
    x[46]     c1909     -1
    x[46]     c1914     1
    x[47]     c23_2     1
    x[47]     c61_1     1
    x[47]     c66_1     -1
    x[47]     c259      1
    x[47]     c264      -1
    x[47]     c451      1
    x[47]     c456      -1
    x[47]     c637      1
    x[47]     c642      -1
    x[47]     c817      1
    x[47]     c822      -1
    x[47]     c991      1
    x[47]     c996      -1
    x[47]     c1159     1
    x[47]     c1164     -1
    x[47]     c1321     1
    x[47]     c1326     -1
    x[47]     c1477     1
    x[47]     c1482     -1
    x[47]     c1627     1
    x[47]     c1632     -1
    x[47]     c1771     1
    x[47]     c1776     -1
    x[47]     c1915     -1
    x[47]     c1920     1
    x[47]     c1921     -1
    x[47]     c1926     1
    x[47]     c1927     -1
    x[47]     c1932     1
    x[47]     c1933     -1
    x[47]     c1938     1
    x[47]     c1939     -1
    x[47]     c1944     1
    x[47]     c1945     -1
    x[47]     c1950     1
    x[47]     c1951     -1
    x[47]     c1956     1
    x[47]     c1957     -1
    x[47]     c1962     1
    x[47]     c1963     -1
    x[47]     c1968     1
    x[47]     c1969     -1
    x[47]     c1974     1
    x[47]     c1975     -1
    x[47]     c1980     1
    x[47]     c1981     -1
    x[47]     c1986     1
    x[47]     c1987     -1
    x[47]     c1992     1
    x[47]     c1993     -1
    x[47]     c1998     1
    x[47]     c1999     -1
    x[47]     c2004     1
    x[47]     c2005     -1
    x[47]     c2010     1
    x[47]     c2011     -1
    x[47]     c2016     1
    x[47]     c2017     -1
    x[47]     c2022     1
    x[47]     c2023     -1
    x[47]     c2028     1
    x[47]     c2029     -1
    x[47]     c2034     1
    x[47]     c2035     -1
    x[47]     c2040     1
    x[47]     c2041     -1
    x[47]     c2046     1
    x[47]     c2047     -1
    x[47]     c2052     1
    x[48]     c25_2     1
    x[48]     c67_1     1
    x[48]     c72_1     -1
    x[48]     c265      1
    x[48]     c270      -1
    x[48]     c457      1
    x[48]     c462      -1
    x[48]     c643      1
    x[48]     c648      -1
    x[48]     c823      1
    x[48]     c828      -1
    x[48]     c997      1
    x[48]     c1002     -1
    x[48]     c1165     1
    x[48]     c1170     -1
    x[48]     c1327     1
    x[48]     c1332     -1
    x[48]     c1483     1
    x[48]     c1488     -1
    x[48]     c1633     1
    x[48]     c1638     -1
    x[48]     c1777     1
    x[48]     c1782     -1
    x[48]     c1915     1
    x[48]     c1920     -1
    x[48]     c2053     -1
    x[48]     c2058     1
    x[48]     c2059     -1
    x[48]     c2064     1
    x[48]     c2065     -1
    x[48]     c2070     1
    x[48]     c2071     -1
    x[48]     c2076     1
    x[48]     c2077     -1
    x[48]     c2082     1
    x[48]     c2083     -1
    x[48]     c2088     1
    x[48]     c2089     -1
    x[48]     c2094     1
    x[48]     c2095     -1
    x[48]     c2100     1
    x[48]     c2101     -1
    x[48]     c2106     1
    x[48]     c2107     -1
    x[48]     c2112     1
    x[48]     c2113     -1
    x[48]     c2118     1
    x[48]     c2119     -1
    x[48]     c2124     1
    x[48]     c2125     -1
    x[48]     c2130     1
    x[48]     c2131     -1
    x[48]     c2136     1
    x[48]     c2137     -1
    x[48]     c2142     1
    x[48]     c2143     -1
    x[48]     c2148     1
    x[48]     c2149     -1
    x[48]     c2154     1
    x[48]     c2155     -1
    x[48]     c2160     1
    x[48]     c2161     -1
    x[48]     c2166     1
    x[48]     c2167     -1
    x[48]     c2172     1
    x[48]     c2173     -1
    x[48]     c2178     1
    x[48]     c2179     -1
    x[48]     c2184     1
    x[49]     c27_2     1
    x[49]     c73_1     1
    x[49]     c78_1     -1
    x[49]     c271      1
    x[49]     c276      -1
    x[49]     c463      1
    x[49]     c468      -1
    x[49]     c649      1
    x[49]     c654      -1
    x[49]     c829      1
    x[49]     c834      -1
    x[49]     c1003     1
    x[49]     c1008     -1
    x[49]     c1171     1
    x[49]     c1176     -1
    x[49]     c1333     1
    x[49]     c1338     -1
    x[49]     c1489     1
    x[49]     c1494     -1
    x[49]     c1639     1
    x[49]     c1644     -1
    x[49]     c1783     1
    x[49]     c1788     -1
    x[49]     c1921     1
    x[49]     c1926     -1
    x[49]     c2053     1
    x[49]     c2058     -1
    x[49]     c2185     -1
    x[49]     c2190     1
    x[49]     c2191     -1
    x[49]     c2196     1
    x[49]     c2197     -1
    x[49]     c2202     1
    x[49]     c2203     -1
    x[49]     c2208     1
    x[49]     c2209     -1
    x[49]     c2214     1
    x[49]     c2215     -1
    x[49]     c2220     1
    x[49]     c2221     -1
    x[49]     c2226     1
    x[49]     c2227     -1
    x[49]     c2232     1
    x[49]     c2233     -1
    x[49]     c2238     1
    x[49]     c2239     -1
    x[49]     c2244     1
    x[49]     c2245     -1
    x[49]     c2250     1
    x[49]     c2251     -1
    x[49]     c2256     1
    x[49]     c2257     -1
    x[49]     c2262     1
    x[49]     c2263     -1
    x[49]     c2268     1
    x[49]     c2269     -1
    x[49]     c2274     1
    x[49]     c2275     -1
    x[49]     c2280     1
    x[49]     c2281     -1
    x[49]     c2286     1
    x[49]     c2287     -1
    x[49]     c2292     1
    x[49]     c2293     -1
    x[49]     c2298     1
    x[49]     c2299     -1
    x[49]     c2304     1
    x[49]     c2305     -1
    x[49]     c2310     1
    x[50]     c29_2     1
    x[50]     c79_1     1
    x[50]     c84_1     -1
    x[50]     c277      1
    x[50]     c282      -1
    x[50]     c469      1
    x[50]     c474      -1
    x[50]     c655      1
    x[50]     c660      -1
    x[50]     c835      1
    x[50]     c840      -1
    x[50]     c1009     1
    x[50]     c1014     -1
    x[50]     c1177     1
    x[50]     c1182     -1
    x[50]     c1339     1
    x[50]     c1344     -1
    x[50]     c1495     1
    x[50]     c1500     -1
    x[50]     c1645     1
    x[50]     c1650     -1
    x[50]     c1789     1
    x[50]     c1794     -1
    x[50]     c1927     1
    x[50]     c1932     -1
    x[50]     c2059     1
    x[50]     c2064     -1
    x[50]     c2185     1
    x[50]     c2190     -1
    x[50]     c2311     -1
    x[50]     c2316     1
    x[50]     c2317     -1
    x[50]     c2322     1
    x[50]     c2323     -1
    x[50]     c2328     1
    x[50]     c2329     -1
    x[50]     c2334     1
    x[50]     c2335     -1
    x[50]     c2340     1
    x[50]     c2341     -1
    x[50]     c2346     1
    x[50]     c2347     -1
    x[50]     c2352     1
    x[50]     c2353     -1
    x[50]     c2358     1
    x[50]     c2359     -1
    x[50]     c2364     1
    x[50]     c2365     -1
    x[50]     c2370     1
    x[50]     c2371     -1
    x[50]     c2376     1
    x[50]     c2377     -1
    x[50]     c2382     1
    x[50]     c2383     -1
    x[50]     c2388     1
    x[50]     c2389     -1
    x[50]     c2394     1
    x[50]     c2395     -1
    x[50]     c2400     1
    x[50]     c2401     -1
    x[50]     c2406     1
    x[50]     c2407     -1
    x[50]     c2412     1
    x[50]     c2413     -1
    x[50]     c2418     1
    x[50]     c2419     -1
    x[50]     c2424     1
    x[50]     c2425     -1
    x[50]     c2430     1
    x[51]     c31_2     1
    x[51]     c85_1     1
    x[51]     c90_1     -1
    x[51]     c283      1
    x[51]     c288      -1
    x[51]     c475      1
    x[51]     c480      -1
    x[51]     c661      1
    x[51]     c666      -1
    x[51]     c841      1
    x[51]     c846      -1
    x[51]     c1015     1
    x[51]     c1020     -1
    x[51]     c1183     1
    x[51]     c1188     -1
    x[51]     c1345     1
    x[51]     c1350     -1
    x[51]     c1501     1
    x[51]     c1506     -1
    x[51]     c1651     1
    x[51]     c1656     -1
    x[51]     c1795     1
    x[51]     c1800     -1
    x[51]     c1933     1
    x[51]     c1938     -1
    x[51]     c2065     1
    x[51]     c2070     -1
    x[51]     c2191     1
    x[51]     c2196     -1
    x[51]     c2311     1
    x[51]     c2316     -1
    x[51]     c2431     -1
    x[51]     c2436     1
    x[51]     c2437     -1
    x[51]     c2442     1
    x[51]     c2443     -1
    x[51]     c2448     1
    x[51]     c2449     -1
    x[51]     c2454     1
    x[51]     c2455     -1
    x[51]     c2460     1
    x[51]     c2461     -1
    x[51]     c2466     1
    x[51]     c2467     -1
    x[51]     c2472     1
    x[51]     c2473     -1
    x[51]     c2478     1
    x[51]     c2479     -1
    x[51]     c2484     1
    x[51]     c2485     -1
    x[51]     c2490     1
    x[51]     c2491     -1
    x[51]     c2496     1
    x[51]     c2497     -1
    x[51]     c2502     1
    x[51]     c2503     -1
    x[51]     c2508     1
    x[51]     c2509     -1
    x[51]     c2514     1
    x[51]     c2515     -1
    x[51]     c2520     1
    x[51]     c2521     -1
    x[51]     c2526     1
    x[51]     c2527     -1
    x[51]     c2532     1
    x[51]     c2533     -1
    x[51]     c2538     1
    x[51]     c2539     -1
    x[51]     c2544     1
    x[52]     c33_2     1
    x[52]     c91_1     1
    x[52]     c96_1     -1
    x[52]     c289      1
    x[52]     c294      -1
    x[52]     c481      1
    x[52]     c486      -1
    x[52]     c667      1
    x[52]     c672      -1
    x[52]     c847      1
    x[52]     c852      -1
    x[52]     c1021     1
    x[52]     c1026     -1
    x[52]     c1189     1
    x[52]     c1194     -1
    x[52]     c1351     1
    x[52]     c1356     -1
    x[52]     c1507     1
    x[52]     c1512     -1
    x[52]     c1657     1
    x[52]     c1662     -1
    x[52]     c1801     1
    x[52]     c1806     -1
    x[52]     c1939     1
    x[52]     c1944     -1
    x[52]     c2071     1
    x[52]     c2076     -1
    x[52]     c2197     1
    x[52]     c2202     -1
    x[52]     c2317     1
    x[52]     c2322     -1
    x[52]     c2431     1
    x[52]     c2436     -1
    x[52]     c2545     -1
    x[52]     c2550     1
    x[52]     c2551     -1
    x[52]     c2556     1
    x[52]     c2557     -1
    x[52]     c2562     1
    x[52]     c2563     -1
    x[52]     c2568     1
    x[52]     c2569     -1
    x[52]     c2574     1
    x[52]     c2575     -1
    x[52]     c2580     1
    x[52]     c2581     -1
    x[52]     c2586     1
    x[52]     c2587     -1
    x[52]     c2592     1
    x[52]     c2593     -1
    x[52]     c2598     1
    x[52]     c2599     -1
    x[52]     c2604     1
    x[52]     c2605     -1
    x[52]     c2610     1
    x[52]     c2611     -1
    x[52]     c2616     1
    x[52]     c2617     -1
    x[52]     c2622     1
    x[52]     c2623     -1
    x[52]     c2628     1
    x[52]     c2629     -1
    x[52]     c2634     1
    x[52]     c2635     -1
    x[52]     c2640     1
    x[52]     c2641     -1
    x[52]     c2646     1
    x[52]     c2647     -1
    x[52]     c2652     1
    x[53]     c35_2     1
    x[53]     c97_1     1
    x[53]     c102_1    -1
    x[53]     c295      1
    x[53]     c300      -1
    x[53]     c487      1
    x[53]     c492      -1
    x[53]     c673      1
    x[53]     c678      -1
    x[53]     c853      1
    x[53]     c858      -1
    x[53]     c1027     1
    x[53]     c1032     -1
    x[53]     c1195     1
    x[53]     c1200     -1
    x[53]     c1357     1
    x[53]     c1362     -1
    x[53]     c1513     1
    x[53]     c1518     -1
    x[53]     c1663     1
    x[53]     c1668     -1
    x[53]     c1807     1
    x[53]     c1812     -1
    x[53]     c1945     1
    x[53]     c1950     -1
    x[53]     c2077     1
    x[53]     c2082     -1
    x[53]     c2203     1
    x[53]     c2208     -1
    x[53]     c2323     1
    x[53]     c2328     -1
    x[53]     c2437     1
    x[53]     c2442     -1
    x[53]     c2545     1
    x[53]     c2550     -1
    x[53]     c2653     -1
    x[53]     c2658     1
    x[53]     c2659     -1
    x[53]     c2664     1
    x[53]     c2665     -1
    x[53]     c2670     1
    x[53]     c2671     -1
    x[53]     c2676     1
    x[53]     c2677     -1
    x[53]     c2682     1
    x[53]     c2683     -1
    x[53]     c2688     1
    x[53]     c2689     -1
    x[53]     c2694     1
    x[53]     c2695     -1
    x[53]     c2700     1
    x[53]     c2701     -1
    x[53]     c2706     1
    x[53]     c2707     -1
    x[53]     c2712     1
    x[53]     c2713     -1
    x[53]     c2718     1
    x[53]     c2719     -1
    x[53]     c2724     1
    x[53]     c2725     -1
    x[53]     c2730     1
    x[53]     c2731     -1
    x[53]     c2736     1
    x[53]     c2737     -1
    x[53]     c2742     1
    x[53]     c2743     -1
    x[53]     c2748     1
    x[53]     c2749     -1
    x[53]     c2754     1
    x[54]     c37_2     1
    x[54]     c103_1    1
    x[54]     c108_1    -1
    x[54]     c301      1
    x[54]     c306      -1
    x[54]     c493      1
    x[54]     c498      -1
    x[54]     c679      1
    x[54]     c684      -1
    x[54]     c859      1
    x[54]     c864      -1
    x[54]     c1033     1
    x[54]     c1038     -1
    x[54]     c1201     1
    x[54]     c1206     -1
    x[54]     c1363     1
    x[54]     c1368     -1
    x[54]     c1519     1
    x[54]     c1524     -1
    x[54]     c1669     1
    x[54]     c1674     -1
    x[54]     c1813     1
    x[54]     c1818     -1
    x[54]     c1951     1
    x[54]     c1956     -1
    x[54]     c2083     1
    x[54]     c2088     -1
    x[54]     c2209     1
    x[54]     c2214     -1
    x[54]     c2329     1
    x[54]     c2334     -1
    x[54]     c2443     1
    x[54]     c2448     -1
    x[54]     c2551     1
    x[54]     c2556     -1
    x[54]     c2653     1
    x[54]     c2658     -1
    x[54]     c2755     -1
    x[54]     c2760     1
    x[54]     c2761     -1
    x[54]     c2766     1
    x[54]     c2767     -1
    x[54]     c2772     1
    x[54]     c2773     -1
    x[54]     c2778     1
    x[54]     c2779     -1
    x[54]     c2784     1
    x[54]     c2785     -1
    x[54]     c2790     1
    x[54]     c2791     -1
    x[54]     c2796     1
    x[54]     c2797     -1
    x[54]     c2802     1
    x[54]     c2803     -1
    x[54]     c2808     1
    x[54]     c2809     -1
    x[54]     c2814     1
    x[54]     c2815     -1
    x[54]     c2820     1
    x[54]     c2821     -1
    x[54]     c2826     1
    x[54]     c2827     -1
    x[54]     c2832     1
    x[54]     c2833     -1
    x[54]     c2838     1
    x[54]     c2839     -1
    x[54]     c2844     1
    x[54]     c2845     -1
    x[54]     c2850     1
    x[55]     c39_2     1
    x[55]     c109_1    1
    x[55]     c114_1    -1
    x[55]     c307      1
    x[55]     c312      -1
    x[55]     c499      1
    x[55]     c504      -1
    x[55]     c685      1
    x[55]     c690      -1
    x[55]     c865      1
    x[55]     c870      -1
    x[55]     c1039     1
    x[55]     c1044     -1
    x[55]     c1207     1
    x[55]     c1212     -1
    x[55]     c1369     1
    x[55]     c1374     -1
    x[55]     c1525     1
    x[55]     c1530     -1
    x[55]     c1675     1
    x[55]     c1680     -1
    x[55]     c1819     1
    x[55]     c1824     -1
    x[55]     c1957     1
    x[55]     c1962     -1
    x[55]     c2089     1
    x[55]     c2094     -1
    x[55]     c2215     1
    x[55]     c2220     -1
    x[55]     c2335     1
    x[55]     c2340     -1
    x[55]     c2449     1
    x[55]     c2454     -1
    x[55]     c2557     1
    x[55]     c2562     -1
    x[55]     c2659     1
    x[55]     c2664     -1
    x[55]     c2755     1
    x[55]     c2760     -1
    x[55]     c2851     -1
    x[55]     c2856     1
    x[55]     c2857     -1
    x[55]     c2862     1
    x[55]     c2863     -1
    x[55]     c2868     1
    x[55]     c2869     -1
    x[55]     c2874     1
    x[55]     c2875     -1
    x[55]     c2880     1
    x[55]     c2881     -1
    x[55]     c2886     1
    x[55]     c2887     -1
    x[55]     c2892     1
    x[55]     c2893     -1
    x[55]     c2898     1
    x[55]     c2899     -1
    x[55]     c2904     1
    x[55]     c2905     -1
    x[55]     c2910     1
    x[55]     c2911     -1
    x[55]     c2916     1
    x[55]     c2917     -1
    x[55]     c2922     1
    x[55]     c2923     -1
    x[55]     c2928     1
    x[55]     c2929     -1
    x[55]     c2934     1
    x[55]     c2935     -1
    x[55]     c2940     1
    x[56]     c41_2     1
    x[56]     c115_1    1
    x[56]     c120_1    -1
    x[56]     c313      1
    x[56]     c318      -1
    x[56]     c505      1
    x[56]     c510      -1
    x[56]     c691      1
    x[56]     c696      -1
    x[56]     c871      1
    x[56]     c876      -1
    x[56]     c1045     1
    x[56]     c1050     -1
    x[56]     c1213     1
    x[56]     c1218     -1
    x[56]     c1375     1
    x[56]     c1380     -1
    x[56]     c1531     1
    x[56]     c1536     -1
    x[56]     c1681     1
    x[56]     c1686     -1
    x[56]     c1825     1
    x[56]     c1830     -1
    x[56]     c1963     1
    x[56]     c1968     -1
    x[56]     c2095     1
    x[56]     c2100     -1
    x[56]     c2221     1
    x[56]     c2226     -1
    x[56]     c2341     1
    x[56]     c2346     -1
    x[56]     c2455     1
    x[56]     c2460     -1
    x[56]     c2563     1
    x[56]     c2568     -1
    x[56]     c2665     1
    x[56]     c2670     -1
    x[56]     c2761     1
    x[56]     c2766     -1
    x[56]     c2851     1
    x[56]     c2856     -1
    x[56]     c2941     -1
    x[56]     c2946     1
    x[56]     c2947     -1
    x[56]     c2952     1
    x[56]     c2953     -1
    x[56]     c2958     1
    x[56]     c2959     -1
    x[56]     c2964     1
    x[56]     c2965     -1
    x[56]     c2970     1
    x[56]     c2971     -1
    x[56]     c2976     1
    x[56]     c2977     -1
    x[56]     c2982     1
    x[56]     c2983     -1
    x[56]     c2988     1
    x[56]     c2989     -1
    x[56]     c2994     1
    x[56]     c2995     -1
    x[56]     c3000     1
    x[56]     c3001     -1
    x[56]     c3006     1
    x[56]     c3007     -1
    x[56]     c3012     1
    x[56]     c3013     -1
    x[56]     c3018     1
    x[56]     c3019     -1
    x[56]     c3024     1
    x[57]     c43_2     1
    x[57]     c121_1    1
    x[57]     c126_1    -1
    x[57]     c319      1
    x[57]     c324      -1
    x[57]     c511      1
    x[57]     c516      -1
    x[57]     c697      1
    x[57]     c702      -1
    x[57]     c877      1
    x[57]     c882      -1
    x[57]     c1051     1
    x[57]     c1056     -1
    x[57]     c1219     1
    x[57]     c1224     -1
    x[57]     c1381     1
    x[57]     c1386     -1
    x[57]     c1537     1
    x[57]     c1542     -1
    x[57]     c1687     1
    x[57]     c1692     -1
    x[57]     c1831     1
    x[57]     c1836     -1
    x[57]     c1969     1
    x[57]     c1974     -1
    x[57]     c2101     1
    x[57]     c2106     -1
    x[57]     c2227     1
    x[57]     c2232     -1
    x[57]     c2347     1
    x[57]     c2352     -1
    x[57]     c2461     1
    x[57]     c2466     -1
    x[57]     c2569     1
    x[57]     c2574     -1
    x[57]     c2671     1
    x[57]     c2676     -1
    x[57]     c2767     1
    x[57]     c2772     -1
    x[57]     c2857     1
    x[57]     c2862     -1
    x[57]     c2941     1
    x[57]     c2946     -1
    x[57]     c3025     -1
    x[57]     c3030     1
    x[57]     c3031     -1
    x[57]     c3036     1
    x[57]     c3037     -1
    x[57]     c3042     1
    x[57]     c3043     -1
    x[57]     c3048     1
    x[57]     c3049     -1
    x[57]     c3054     1
    x[57]     c3055     -1
    x[57]     c3060     1
    x[57]     c3061     -1
    x[57]     c3066     1
    x[57]     c3067     -1
    x[57]     c3072     1
    x[57]     c3073     -1
    x[57]     c3078     1
    x[57]     c3079     -1
    x[57]     c3084     1
    x[57]     c3085     -1
    x[57]     c3090     1
    x[57]     c3091     -1
    x[57]     c3096     1
    x[57]     c3097     -1
    x[57]     c3102     1
    x[58]     c45_2     1
    x[58]     c127_1    1
    x[58]     c132_1    -1
    x[58]     c325      1
    x[58]     c330      -1
    x[58]     c517      1
    x[58]     c522      -1
    x[58]     c703      1
    x[58]     c708      -1
    x[58]     c883      1
    x[58]     c888      -1
    x[58]     c1057     1
    x[58]     c1062     -1
    x[58]     c1225     1
    x[58]     c1230     -1
    x[58]     c1387     1
    x[58]     c1392     -1
    x[58]     c1543     1
    x[58]     c1548     -1
    x[58]     c1693     1
    x[58]     c1698     -1
    x[58]     c1837     1
    x[58]     c1842     -1
    x[58]     c1975     1
    x[58]     c1980     -1
    x[58]     c2107     1
    x[58]     c2112     -1
    x[58]     c2233     1
    x[58]     c2238     -1
    x[58]     c2353     1
    x[58]     c2358     -1
    x[58]     c2467     1
    x[58]     c2472     -1
    x[58]     c2575     1
    x[58]     c2580     -1
    x[58]     c2677     1
    x[58]     c2682     -1
    x[58]     c2773     1
    x[58]     c2778     -1
    x[58]     c2863     1
    x[58]     c2868     -1
    x[58]     c2947     1
    x[58]     c2952     -1
    x[58]     c3025     1
    x[58]     c3030     -1
    x[58]     c3103     -1
    x[58]     c3108     1
    x[58]     c3109     -1
    x[58]     c3114     1
    x[58]     c3115     -1
    x[58]     c3120     1
    x[58]     c3121     -1
    x[58]     c3126     1
    x[58]     c3127     -1
    x[58]     c3132     1
    x[58]     c3133     -1
    x[58]     c3138     1
    x[58]     c3139     -1
    x[58]     c3144     1
    x[58]     c3145     -1
    x[58]     c3150     1
    x[58]     c3151     -1
    x[58]     c3156     1
    x[58]     c3157     -1
    x[58]     c3162     1
    x[58]     c3163     -1
    x[58]     c3168     1
    x[58]     c3169     -1
    x[58]     c3174     1
    x[59]     c47_2     1
    x[59]     c133_1    1
    x[59]     c138_1    -1
    x[59]     c331      1
    x[59]     c336      -1
    x[59]     c523      1
    x[59]     c528      -1
    x[59]     c709      1
    x[59]     c714      -1
    x[59]     c889      1
    x[59]     c894      -1
    x[59]     c1063     1
    x[59]     c1068     -1
    x[59]     c1231     1
    x[59]     c1236     -1
    x[59]     c1393     1
    x[59]     c1398     -1
    x[59]     c1549     1
    x[59]     c1554     -1
    x[59]     c1699     1
    x[59]     c1704     -1
    x[59]     c1843     1
    x[59]     c1848     -1
    x[59]     c1981     1
    x[59]     c1986     -1
    x[59]     c2113     1
    x[59]     c2118     -1
    x[59]     c2239     1
    x[59]     c2244     -1
    x[59]     c2359     1
    x[59]     c2364     -1
    x[59]     c2473     1
    x[59]     c2478     -1
    x[59]     c2581     1
    x[59]     c2586     -1
    x[59]     c2683     1
    x[59]     c2688     -1
    x[59]     c2779     1
    x[59]     c2784     -1
    x[59]     c2869     1
    x[59]     c2874     -1
    x[59]     c2953     1
    x[59]     c2958     -1
    x[59]     c3031     1
    x[59]     c3036     -1
    x[59]     c3103     1
    x[59]     c3108     -1
    x[59]     c3175     -1
    x[59]     c3180     1
    x[59]     c3181     -1
    x[59]     c3186     1
    x[59]     c3187     -1
    x[59]     c3192     1
    x[59]     c3193     -1
    x[59]     c3198     1
    x[59]     c3199     -1
    x[59]     c3204     1
    x[59]     c3205     -1
    x[59]     c3210     1
    x[59]     c3211     -1
    x[59]     c3216     1
    x[59]     c3217     -1
    x[59]     c3222     1
    x[59]     c3223     -1
    x[59]     c3228     1
    x[59]     c3229     -1
    x[59]     c3234     1
    x[59]     c3235     -1
    x[59]     c3240     1
    x[60]     c49_2     1
    x[60]     c139_1    1
    x[60]     c144_1    -1
    x[60]     c337      1
    x[60]     c342      -1
    x[60]     c529      1
    x[60]     c534      -1
    x[60]     c715      1
    x[60]     c720      -1
    x[60]     c895      1
    x[60]     c900      -1
    x[60]     c1069     1
    x[60]     c1074     -1
    x[60]     c1237     1
    x[60]     c1242     -1
    x[60]     c1399     1
    x[60]     c1404     -1
    x[60]     c1555     1
    x[60]     c1560     -1
    x[60]     c1705     1
    x[60]     c1710     -1
    x[60]     c1849     1
    x[60]     c1854     -1
    x[60]     c1987     1
    x[60]     c1992     -1
    x[60]     c2119     1
    x[60]     c2124     -1
    x[60]     c2245     1
    x[60]     c2250     -1
    x[60]     c2365     1
    x[60]     c2370     -1
    x[60]     c2479     1
    x[60]     c2484     -1
    x[60]     c2587     1
    x[60]     c2592     -1
    x[60]     c2689     1
    x[60]     c2694     -1
    x[60]     c2785     1
    x[60]     c2790     -1
    x[60]     c2875     1
    x[60]     c2880     -1
    x[60]     c2959     1
    x[60]     c2964     -1
    x[60]     c3037     1
    x[60]     c3042     -1
    x[60]     c3109     1
    x[60]     c3114     -1
    x[60]     c3175     1
    x[60]     c3180     -1
    x[60]     c3241     -1
    x[60]     c3246     1
    x[60]     c3247     -1
    x[60]     c3252     1
    x[60]     c3253     -1
    x[60]     c3258     1
    x[60]     c3259     -1
    x[60]     c3264     1
    x[60]     c3265     -1
    x[60]     c3270     1
    x[60]     c3271     -1
    x[60]     c3276     1
    x[60]     c3277     -1
    x[60]     c3282     1
    x[60]     c3283     -1
    x[60]     c3288     1
    x[60]     c3289     -1
    x[60]     c3294     1
    x[60]     c3295     -1
    x[60]     c3300     1
    x[61]     c51_2     1
    x[61]     c145_1    1
    x[61]     c150_1    -1
    x[61]     c343      1
    x[61]     c348      -1
    x[61]     c535      1
    x[61]     c540      -1
    x[61]     c721      1
    x[61]     c726      -1
    x[61]     c901      1
    x[61]     c906      -1
    x[61]     c1075     1
    x[61]     c1080     -1
    x[61]     c1243     1
    x[61]     c1248     -1
    x[61]     c1405     1
    x[61]     c1410     -1
    x[61]     c1561     1
    x[61]     c1566     -1
    x[61]     c1711     1
    x[61]     c1716     -1
    x[61]     c1855     1
    x[61]     c1860     -1
    x[61]     c1993     1
    x[61]     c1998     -1
    x[61]     c2125     1
    x[61]     c2130     -1
    x[61]     c2251     1
    x[61]     c2256     -1
    x[61]     c2371     1
    x[61]     c2376     -1
    x[61]     c2485     1
    x[61]     c2490     -1
    x[61]     c2593     1
    x[61]     c2598     -1
    x[61]     c2695     1
    x[61]     c2700     -1
    x[61]     c2791     1
    x[61]     c2796     -1
    x[61]     c2881     1
    x[61]     c2886     -1
    x[61]     c2965     1
    x[61]     c2970     -1
    x[61]     c3043     1
    x[61]     c3048     -1
    x[61]     c3115     1
    x[61]     c3120     -1
    x[61]     c3181     1
    x[61]     c3186     -1
    x[61]     c3241     1
    x[61]     c3246     -1
    x[61]     c3301     -1
    x[61]     c3306     1
    x[61]     c3307     -1
    x[61]     c3312     1
    x[61]     c3313     -1
    x[61]     c3318     1
    x[61]     c3319     -1
    x[61]     c3324     1
    x[61]     c3325     -1
    x[61]     c3330     1
    x[61]     c3331     -1
    x[61]     c3336     1
    x[61]     c3337     -1
    x[61]     c3342     1
    x[61]     c3343     -1
    x[61]     c3348     1
    x[61]     c3349     -1
    x[61]     c3354     1
    x[62]     c53_2     1
    x[62]     c151_1    1
    x[62]     c156_1    -1
    x[62]     c349      1
    x[62]     c354      -1
    x[62]     c541      1
    x[62]     c546      -1
    x[62]     c727      1
    x[62]     c732      -1
    x[62]     c907      1
    x[62]     c912      -1
    x[62]     c1081     1
    x[62]     c1086     -1
    x[62]     c1249     1
    x[62]     c1254     -1
    x[62]     c1411     1
    x[62]     c1416     -1
    x[62]     c1567     1
    x[62]     c1572     -1
    x[62]     c1717     1
    x[62]     c1722     -1
    x[62]     c1861     1
    x[62]     c1866     -1
    x[62]     c1999     1
    x[62]     c2004     -1
    x[62]     c2131     1
    x[62]     c2136     -1
    x[62]     c2257     1
    x[62]     c2262     -1
    x[62]     c2377     1
    x[62]     c2382     -1
    x[62]     c2491     1
    x[62]     c2496     -1
    x[62]     c2599     1
    x[62]     c2604     -1
    x[62]     c2701     1
    x[62]     c2706     -1
    x[62]     c2797     1
    x[62]     c2802     -1
    x[62]     c2887     1
    x[62]     c2892     -1
    x[62]     c2971     1
    x[62]     c2976     -1
    x[62]     c3049     1
    x[62]     c3054     -1
    x[62]     c3121     1
    x[62]     c3126     -1
    x[62]     c3187     1
    x[62]     c3192     -1
    x[62]     c3247     1
    x[62]     c3252     -1
    x[62]     c3301     1
    x[62]     c3306     -1
    x[62]     c3355     -1
    x[62]     c3360     1
    x[62]     c3361     -1
    x[62]     c3366     1
    x[62]     c3367     -1
    x[62]     c3372     1
    x[62]     c3373     -1
    x[62]     c3378     1
    x[62]     c3379     -1
    x[62]     c3384     1
    x[62]     c3385     -1
    x[62]     c3390     1
    x[62]     c3391     -1
    x[62]     c3396     1
    x[62]     c3397     -1
    x[62]     c3402     1
    x[63]     c55_2     1
    x[63]     c157_1    1
    x[63]     c162_1    -1
    x[63]     c355      1
    x[63]     c360      -1
    x[63]     c547      1
    x[63]     c552      -1
    x[63]     c733      1
    x[63]     c738      -1
    x[63]     c913      1
    x[63]     c918      -1
    x[63]     c1087     1
    x[63]     c1092     -1
    x[63]     c1255     1
    x[63]     c1260     -1
    x[63]     c1417     1
    x[63]     c1422     -1
    x[63]     c1573     1
    x[63]     c1578     -1
    x[63]     c1723     1
    x[63]     c1728     -1
    x[63]     c1867     1
    x[63]     c1872     -1
    x[63]     c2005     1
    x[63]     c2010     -1
    x[63]     c2137     1
    x[63]     c2142     -1
    x[63]     c2263     1
    x[63]     c2268     -1
    x[63]     c2383     1
    x[63]     c2388     -1
    x[63]     c2497     1
    x[63]     c2502     -1
    x[63]     c2605     1
    x[63]     c2610     -1
    x[63]     c2707     1
    x[63]     c2712     -1
    x[63]     c2803     1
    x[63]     c2808     -1
    x[63]     c2893     1
    x[63]     c2898     -1
    x[63]     c2977     1
    x[63]     c2982     -1
    x[63]     c3055     1
    x[63]     c3060     -1
    x[63]     c3127     1
    x[63]     c3132     -1
    x[63]     c3193     1
    x[63]     c3198     -1
    x[63]     c3253     1
    x[63]     c3258     -1
    x[63]     c3307     1
    x[63]     c3312     -1
    x[63]     c3355     1
    x[63]     c3360     -1
    x[63]     c3403     -1
    x[63]     c3408     1
    x[63]     c3409     -1
    x[63]     c3414     1
    x[63]     c3415     -1
    x[63]     c3420     1
    x[63]     c3421     -1
    x[63]     c3426     1
    x[63]     c3427     -1
    x[63]     c3432     1
    x[63]     c3433     -1
    x[63]     c3438     1
    x[63]     c3439     -1
    x[63]     c3444     1
    x[64]     c57_2     1
    x[64]     c163_1    1
    x[64]     c168_1    -1
    x[64]     c361      1
    x[64]     c366      -1
    x[64]     c553      1
    x[64]     c558      -1
    x[64]     c739      1
    x[64]     c744      -1
    x[64]     c919      1
    x[64]     c924      -1
    x[64]     c1093     1
    x[64]     c1098     -1
    x[64]     c1261     1
    x[64]     c1266     -1
    x[64]     c1423     1
    x[64]     c1428     -1
    x[64]     c1579     1
    x[64]     c1584     -1
    x[64]     c1729     1
    x[64]     c1734     -1
    x[64]     c1873     1
    x[64]     c1878     -1
    x[64]     c2011     1
    x[64]     c2016     -1
    x[64]     c2143     1
    x[64]     c2148     -1
    x[64]     c2269     1
    x[64]     c2274     -1
    x[64]     c2389     1
    x[64]     c2394     -1
    x[64]     c2503     1
    x[64]     c2508     -1
    x[64]     c2611     1
    x[64]     c2616     -1
    x[64]     c2713     1
    x[64]     c2718     -1
    x[64]     c2809     1
    x[64]     c2814     -1
    x[64]     c2899     1
    x[64]     c2904     -1
    x[64]     c2983     1
    x[64]     c2988     -1
    x[64]     c3061     1
    x[64]     c3066     -1
    x[64]     c3133     1
    x[64]     c3138     -1
    x[64]     c3199     1
    x[64]     c3204     -1
    x[64]     c3259     1
    x[64]     c3264     -1
    x[64]     c3313     1
    x[64]     c3318     -1
    x[64]     c3361     1
    x[64]     c3366     -1
    x[64]     c3403     1
    x[64]     c3408     -1
    x[64]     c3445     -1
    x[64]     c3450     1
    x[64]     c3451     -1
    x[64]     c3456     1
    x[64]     c3457     -1
    x[64]     c3462     1
    x[64]     c3463     -1
    x[64]     c3468     1
    x[64]     c3469     -1
    x[64]     c3474     1
    x[64]     c3475     -1
    x[64]     c3480     1
    x[65]     c59_2     1
    x[65]     c169_1    1
    x[65]     c174_1    -1
    x[65]     c367      1
    x[65]     c372      -1
    x[65]     c559      1
    x[65]     c564      -1
    x[65]     c745      1
    x[65]     c750      -1
    x[65]     c925      1
    x[65]     c930      -1
    x[65]     c1099     1
    x[65]     c1104     -1
    x[65]     c1267     1
    x[65]     c1272     -1
    x[65]     c1429     1
    x[65]     c1434     -1
    x[65]     c1585     1
    x[65]     c1590     -1
    x[65]     c1735     1
    x[65]     c1740     -1
    x[65]     c1879     1
    x[65]     c1884     -1
    x[65]     c2017     1
    x[65]     c2022     -1
    x[65]     c2149     1
    x[65]     c2154     -1
    x[65]     c2275     1
    x[65]     c2280     -1
    x[65]     c2395     1
    x[65]     c2400     -1
    x[65]     c2509     1
    x[65]     c2514     -1
    x[65]     c2617     1
    x[65]     c2622     -1
    x[65]     c2719     1
    x[65]     c2724     -1
    x[65]     c2815     1
    x[65]     c2820     -1
    x[65]     c2905     1
    x[65]     c2910     -1
    x[65]     c2989     1
    x[65]     c2994     -1
    x[65]     c3067     1
    x[65]     c3072     -1
    x[65]     c3139     1
    x[65]     c3144     -1
    x[65]     c3205     1
    x[65]     c3210     -1
    x[65]     c3265     1
    x[65]     c3270     -1
    x[65]     c3319     1
    x[65]     c3324     -1
    x[65]     c3367     1
    x[65]     c3372     -1
    x[65]     c3409     1
    x[65]     c3414     -1
    x[65]     c3445     1
    x[65]     c3450     -1
    x[65]     c3481     -1
    x[65]     c3486     1
    x[65]     c3487     -1
    x[65]     c3492     1
    x[65]     c3493     -1
    x[65]     c3498     1
    x[65]     c3499     -1
    x[65]     c3504     1
    x[65]     c3505     -1
    x[65]     c3510     1
    x[66]     c61_2     1
    x[66]     c175_1    1
    x[66]     c180_1    -1
    x[66]     c373      1
    x[66]     c378      -1
    x[66]     c565      1
    x[66]     c570      -1
    x[66]     c751      1
    x[66]     c756      -1
    x[66]     c931      1
    x[66]     c936      -1
    x[66]     c1105     1
    x[66]     c1110     -1
    x[66]     c1273     1
    x[66]     c1278     -1
    x[66]     c1435     1
    x[66]     c1440     -1
    x[66]     c1591     1
    x[66]     c1596     -1
    x[66]     c1741     1
    x[66]     c1746     -1
    x[66]     c1885     1
    x[66]     c1890     -1
    x[66]     c2023     1
    x[66]     c2028     -1
    x[66]     c2155     1
    x[66]     c2160     -1
    x[66]     c2281     1
    x[66]     c2286     -1
    x[66]     c2401     1
    x[66]     c2406     -1
    x[66]     c2515     1
    x[66]     c2520     -1
    x[66]     c2623     1
    x[66]     c2628     -1
    x[66]     c2725     1
    x[66]     c2730     -1
    x[66]     c2821     1
    x[66]     c2826     -1
    x[66]     c2911     1
    x[66]     c2916     -1
    x[66]     c2995     1
    x[66]     c3000     -1
    x[66]     c3073     1
    x[66]     c3078     -1
    x[66]     c3145     1
    x[66]     c3150     -1
    x[66]     c3211     1
    x[66]     c3216     -1
    x[66]     c3271     1
    x[66]     c3276     -1
    x[66]     c3325     1
    x[66]     c3330     -1
    x[66]     c3373     1
    x[66]     c3378     -1
    x[66]     c3415     1
    x[66]     c3420     -1
    x[66]     c3451     1
    x[66]     c3456     -1
    x[66]     c3481     1
    x[66]     c3486     -1
    x[66]     c3511     -1
    x[66]     c3516     1
    x[66]     c3517     -1
    x[66]     c3522     1
    x[66]     c3523     -1
    x[66]     c3528     1
    x[66]     c3529     -1
    x[66]     c3534     1
    x[67]     c63_2     1
    x[67]     c181_1    1
    x[67]     c186_1    -1
    x[67]     c379      1
    x[67]     c384      -1
    x[67]     c571      1
    x[67]     c576      -1
    x[67]     c757      1
    x[67]     c762      -1
    x[67]     c937      1
    x[67]     c942      -1
    x[67]     c1111     1
    x[67]     c1116     -1
    x[67]     c1279     1
    x[67]     c1284     -1
    x[67]     c1441     1
    x[67]     c1446     -1
    x[67]     c1597     1
    x[67]     c1602     -1
    x[67]     c1747     1
    x[67]     c1752     -1
    x[67]     c1891     1
    x[67]     c1896     -1
    x[67]     c2029     1
    x[67]     c2034     -1
    x[67]     c2161     1
    x[67]     c2166     -1
    x[67]     c2287     1
    x[67]     c2292     -1
    x[67]     c2407     1
    x[67]     c2412     -1
    x[67]     c2521     1
    x[67]     c2526     -1
    x[67]     c2629     1
    x[67]     c2634     -1
    x[67]     c2731     1
    x[67]     c2736     -1
    x[67]     c2827     1
    x[67]     c2832     -1
    x[67]     c2917     1
    x[67]     c2922     -1
    x[67]     c3001     1
    x[67]     c3006     -1
    x[67]     c3079     1
    x[67]     c3084     -1
    x[67]     c3151     1
    x[67]     c3156     -1
    x[67]     c3217     1
    x[67]     c3222     -1
    x[67]     c3277     1
    x[67]     c3282     -1
    x[67]     c3331     1
    x[67]     c3336     -1
    x[67]     c3379     1
    x[67]     c3384     -1
    x[67]     c3421     1
    x[67]     c3426     -1
    x[67]     c3457     1
    x[67]     c3462     -1
    x[67]     c3487     1
    x[67]     c3492     -1
    x[67]     c3511     1
    x[67]     c3516     -1
    x[67]     c3535     -1
    x[67]     c3540     1
    x[67]     c3541     -1
    x[67]     c3546     1
    x[67]     c3547     -1
    x[67]     c3552     1
    x[68]     c65_2     1
    x[68]     c187_1    1
    x[68]     c192_1    -1
    x[68]     c385      1
    x[68]     c390      -1
    x[68]     c577      1
    x[68]     c582      -1
    x[68]     c763      1
    x[68]     c768      -1
    x[68]     c943      1
    x[68]     c948      -1
    x[68]     c1117     1
    x[68]     c1122     -1
    x[68]     c1285     1
    x[68]     c1290     -1
    x[68]     c1447     1
    x[68]     c1452     -1
    x[68]     c1603     1
    x[68]     c1608     -1
    x[68]     c1753     1
    x[68]     c1758     -1
    x[68]     c1897     1
    x[68]     c1902     -1
    x[68]     c2035     1
    x[68]     c2040     -1
    x[68]     c2167     1
    x[68]     c2172     -1
    x[68]     c2293     1
    x[68]     c2298     -1
    x[68]     c2413     1
    x[68]     c2418     -1
    x[68]     c2527     1
    x[68]     c2532     -1
    x[68]     c2635     1
    x[68]     c2640     -1
    x[68]     c2737     1
    x[68]     c2742     -1
    x[68]     c2833     1
    x[68]     c2838     -1
    x[68]     c2923     1
    x[68]     c2928     -1
    x[68]     c3007     1
    x[68]     c3012     -1
    x[68]     c3085     1
    x[68]     c3090     -1
    x[68]     c3157     1
    x[68]     c3162     -1
    x[68]     c3223     1
    x[68]     c3228     -1
    x[68]     c3283     1
    x[68]     c3288     -1
    x[68]     c3337     1
    x[68]     c3342     -1
    x[68]     c3385     1
    x[68]     c3390     -1
    x[68]     c3427     1
    x[68]     c3432     -1
    x[68]     c3463     1
    x[68]     c3468     -1
    x[68]     c3493     1
    x[68]     c3498     -1
    x[68]     c3517     1
    x[68]     c3522     -1
    x[68]     c3535     1
    x[68]     c3540     -1
    x[68]     c3553     -1
    x[68]     c3558     1
    x[68]     c3559     -1
    x[68]     c3564     1
    x[69]     c67_2     1
    x[69]     c193_1    1
    x[69]     c198_1    -1
    x[69]     c391      1
    x[69]     c396      -1
    x[69]     c583      1
    x[69]     c588      -1
    x[69]     c769      1
    x[69]     c774      -1
    x[69]     c949      1
    x[69]     c954      -1
    x[69]     c1123     1
    x[69]     c1128     -1
    x[69]     c1291     1
    x[69]     c1296     -1
    x[69]     c1453     1
    x[69]     c1458     -1
    x[69]     c1609     1
    x[69]     c1614     -1
    x[69]     c1759     1
    x[69]     c1764     -1
    x[69]     c1903     1
    x[69]     c1908     -1
    x[69]     c2041     1
    x[69]     c2046     -1
    x[69]     c2173     1
    x[69]     c2178     -1
    x[69]     c2299     1
    x[69]     c2304     -1
    x[69]     c2419     1
    x[69]     c2424     -1
    x[69]     c2533     1
    x[69]     c2538     -1
    x[69]     c2641     1
    x[69]     c2646     -1
    x[69]     c2743     1
    x[69]     c2748     -1
    x[69]     c2839     1
    x[69]     c2844     -1
    x[69]     c2929     1
    x[69]     c2934     -1
    x[69]     c3013     1
    x[69]     c3018     -1
    x[69]     c3091     1
    x[69]     c3096     -1
    x[69]     c3163     1
    x[69]     c3168     -1
    x[69]     c3229     1
    x[69]     c3234     -1
    x[69]     c3289     1
    x[69]     c3294     -1
    x[69]     c3343     1
    x[69]     c3348     -1
    x[69]     c3391     1
    x[69]     c3396     -1
    x[69]     c3433     1
    x[69]     c3438     -1
    x[69]     c3469     1
    x[69]     c3474     -1
    x[69]     c3499     1
    x[69]     c3504     -1
    x[69]     c3523     1
    x[69]     c3528     -1
    x[69]     c3541     1
    x[69]     c3546     -1
    x[69]     c3553     1
    x[69]     c3558     -1
    x[69]     c3565     -1
    x[69]     c3570     1
    x[70]     c69_2     1
    x[70]     c199_1    1
    x[70]     c204_1    -1
    x[70]     c397      1
    x[70]     c402      -1
    x[70]     c589      1
    x[70]     c594      -1
    x[70]     c775      1
    x[70]     c780      -1
    x[70]     c955      1
    x[70]     c960      -1
    x[70]     c1129     1
    x[70]     c1134     -1
    x[70]     c1297     1
    x[70]     c1302     -1
    x[70]     c1459     1
    x[70]     c1464     -1
    x[70]     c1615     1
    x[70]     c1620     -1
    x[70]     c1765     1
    x[70]     c1770     -1
    x[70]     c1909     1
    x[70]     c1914     -1
    x[70]     c2047     1
    x[70]     c2052     -1
    x[70]     c2179     1
    x[70]     c2184     -1
    x[70]     c2305     1
    x[70]     c2310     -1
    x[70]     c2425     1
    x[70]     c2430     -1
    x[70]     c2539     1
    x[70]     c2544     -1
    x[70]     c2647     1
    x[70]     c2652     -1
    x[70]     c2749     1
    x[70]     c2754     -1
    x[70]     c2845     1
    x[70]     c2850     -1
    x[70]     c2935     1
    x[70]     c2940     -1
    x[70]     c3019     1
    x[70]     c3024     -1
    x[70]     c3097     1
    x[70]     c3102     -1
    x[70]     c3169     1
    x[70]     c3174     -1
    x[70]     c3235     1
    x[70]     c3240     -1
    x[70]     c3295     1
    x[70]     c3300     -1
    x[70]     c3349     1
    x[70]     c3354     -1
    x[70]     c3397     1
    x[70]     c3402     -1
    x[70]     c3439     1
    x[70]     c3444     -1
    x[70]     c3475     1
    x[70]     c3480     -1
    x[70]     c3505     1
    x[70]     c3510     -1
    x[70]     c3529     1
    x[70]     c3534     -1
    x[70]     c3547     1
    x[70]     c3552     -1
    x[70]     c3559     1
    x[70]     c3564     -1
    x[70]     c3565     1
    x[70]     c3570     -1
    x[71]     c4_1      1
    x[71]     c5_1      -1
    x[71]     c10_1     1
    x[71]     c11_1     -1
    x[71]     c16_1     1
    x[71]     c17_1     -1
    x[71]     c22_1     1
    x[71]     c23_1     -1
    x[71]     c28_1     1
    x[71]     c29_1     -1
    x[71]     c34_1     1
    x[71]     c35_1     -1
    x[71]     c40_1     1
    x[71]     c41_1     -1
    x[71]     c46_1     1
    x[71]     c47_1     -1
    x[71]     c52_1     1
    x[71]     c53_1     -1
    x[71]     c58_1     1
    x[71]     c59_1     -1
    x[71]     c64_1     1
    x[71]     c65_1     -1
    x[71]     c70_1     1
    x[71]     c71_1     -1
    x[71]     c76_1     1
    x[71]     c77_1     -1
    x[71]     c82_1     1
    x[71]     c83_1     -1
    x[71]     c88_1     1
    x[71]     c89_1     -1
    x[71]     c94_1     1
    x[71]     c95_1     -1
    x[71]     c100_1    1
    x[71]     c101_1    -1
    x[71]     c106_1    1
    x[71]     c107_1    -1
    x[71]     c112_1    1
    x[71]     c113_1    -1
    x[71]     c118_1    1
    x[71]     c119_1    -1
    x[71]     c124_1    1
    x[71]     c125_1    -1
    x[71]     c130_1    1
    x[71]     c131_1    -1
    x[71]     c136_1    1
    x[71]     c137_1    -1
    x[71]     c142_1    1
    x[71]     c143_1    -1
    x[71]     c148_1    1
    x[71]     c149_1    -1
    x[71]     c154_1    1
    x[71]     c155_1    -1
    x[71]     c160_1    1
    x[71]     c161_1    -1
    x[71]     c166_1    1
    x[71]     c167_1    -1
    x[71]     c172_1    1
    x[71]     c173_1    -1
    x[71]     c178_1    1
    x[71]     c179_1    -1
    x[71]     c184_1    1
    x[71]     c185_1    -1
    x[71]     c190_1    1
    x[71]     c191_1    -1
    x[71]     c196_1    1
    x[71]     c197_1    -1
    x[71]     c202_1    1
    x[71]     c203_1    -1
    x[72]     c4_1      -1
    x[72]     c5_1      1
    x[72]     c208_1    1
    x[72]     c209_1    -1
    x[72]     c214_1    1
    x[72]     c215_1    -1
    x[72]     c220_1    1
    x[72]     c221_1    -1
    x[72]     c226_1    1
    x[72]     c227_1    -1
    x[72]     c232_1    1
    x[72]     c233_1    -1
    x[72]     c238_1    1
    x[72]     c239_1    -1
    x[72]     c244      1
    x[72]     c245      -1
    x[72]     c250      1
    x[72]     c251      -1
    x[72]     c256      1
    x[72]     c257      -1
    x[72]     c262      1
    x[72]     c263      -1
    x[72]     c268      1
    x[72]     c269      -1
    x[72]     c274      1
    x[72]     c275      -1
    x[72]     c280      1
    x[72]     c281      -1
    x[72]     c286      1
    x[72]     c287      -1
    x[72]     c292      1
    x[72]     c293      -1
    x[72]     c298      1
    x[72]     c299      -1
    x[72]     c304      1
    x[72]     c305      -1
    x[72]     c310      1
    x[72]     c311      -1
    x[72]     c316      1
    x[72]     c317      -1
    x[72]     c322      1
    x[72]     c323      -1
    x[72]     c328      1
    x[72]     c329      -1
    x[72]     c334      1
    x[72]     c335      -1
    x[72]     c340      1
    x[72]     c341      -1
    x[72]     c346      1
    x[72]     c347      -1
    x[72]     c352      1
    x[72]     c353      -1
    x[72]     c358      1
    x[72]     c359      -1
    x[72]     c364      1
    x[72]     c365      -1
    x[72]     c370      1
    x[72]     c371      -1
    x[72]     c376      1
    x[72]     c377      -1
    x[72]     c382      1
    x[72]     c383      -1
    x[72]     c388      1
    x[72]     c389      -1
    x[72]     c394      1
    x[72]     c395      -1
    x[72]     c400      1
    x[72]     c401      -1
    x[73]     c10_1     -1
    x[73]     c11_1     1
    x[73]     c208_1    -1
    x[73]     c209_1    1
    x[73]     c406      1
    x[73]     c407      -1
    x[73]     c412      1
    x[73]     c413      -1
    x[73]     c418      1
    x[73]     c419      -1
    x[73]     c424      1
    x[73]     c425      -1
    x[73]     c430      1
    x[73]     c431      -1
    x[73]     c436      1
    x[73]     c437      -1
    x[73]     c442      1
    x[73]     c443      -1
    x[73]     c448      1
    x[73]     c449      -1
    x[73]     c454      1
    x[73]     c455      -1
    x[73]     c460      1
    x[73]     c461      -1
    x[73]     c466      1
    x[73]     c467      -1
    x[73]     c472      1
    x[73]     c473      -1
    x[73]     c478      1
    x[73]     c479      -1
    x[73]     c484      1
    x[73]     c485      -1
    x[73]     c490      1
    x[73]     c491      -1
    x[73]     c496      1
    x[73]     c497      -1
    x[73]     c502      1
    x[73]     c503      -1
    x[73]     c508      1
    x[73]     c509      -1
    x[73]     c514      1
    x[73]     c515      -1
    x[73]     c520      1
    x[73]     c521      -1
    x[73]     c526      1
    x[73]     c527      -1
    x[73]     c532      1
    x[73]     c533      -1
    x[73]     c538      1
    x[73]     c539      -1
    x[73]     c544      1
    x[73]     c545      -1
    x[73]     c550      1
    x[73]     c551      -1
    x[73]     c556      1
    x[73]     c557      -1
    x[73]     c562      1
    x[73]     c563      -1
    x[73]     c568      1
    x[73]     c569      -1
    x[73]     c574      1
    x[73]     c575      -1
    x[73]     c580      1
    x[73]     c581      -1
    x[73]     c586      1
    x[73]     c587      -1
    x[73]     c592      1
    x[73]     c593      -1
    x[74]     c16_1     -1
    x[74]     c17_1     1
    x[74]     c214_1    -1
    x[74]     c215_1    1
    x[74]     c406      -1
    x[74]     c407      1
    x[74]     c598      1
    x[74]     c599      -1
    x[74]     c604      1
    x[74]     c605      -1
    x[74]     c610      1
    x[74]     c611      -1
    x[74]     c616      1
    x[74]     c617      -1
    x[74]     c622      1
    x[74]     c623      -1
    x[74]     c628      1
    x[74]     c629      -1
    x[74]     c634      1
    x[74]     c635      -1
    x[74]     c640      1
    x[74]     c641      -1
    x[74]     c646      1
    x[74]     c647      -1
    x[74]     c652      1
    x[74]     c653      -1
    x[74]     c658      1
    x[74]     c659      -1
    x[74]     c664      1
    x[74]     c665      -1
    x[74]     c670      1
    x[74]     c671      -1
    x[74]     c676      1
    x[74]     c677      -1
    x[74]     c682      1
    x[74]     c683      -1
    x[74]     c688      1
    x[74]     c689      -1
    x[74]     c694      1
    x[74]     c695      -1
    x[74]     c700      1
    x[74]     c701      -1
    x[74]     c706      1
    x[74]     c707      -1
    x[74]     c712      1
    x[74]     c713      -1
    x[74]     c718      1
    x[74]     c719      -1
    x[74]     c724      1
    x[74]     c725      -1
    x[74]     c730      1
    x[74]     c731      -1
    x[74]     c736      1
    x[74]     c737      -1
    x[74]     c742      1
    x[74]     c743      -1
    x[74]     c748      1
    x[74]     c749      -1
    x[74]     c754      1
    x[74]     c755      -1
    x[74]     c760      1
    x[74]     c761      -1
    x[74]     c766      1
    x[74]     c767      -1
    x[74]     c772      1
    x[74]     c773      -1
    x[74]     c778      1
    x[74]     c779      -1
    x[75]     c22_1     -1
    x[75]     c23_1     1
    x[75]     c220_1    -1
    x[75]     c221_1    1
    x[75]     c412      -1
    x[75]     c413      1
    x[75]     c598      -1
    x[75]     c599      1
    x[75]     c784      1
    x[75]     c785      -1
    x[75]     c790      1
    x[75]     c791      -1
    x[75]     c796      1
    x[75]     c797      -1
    x[75]     c802      1
    x[75]     c803      -1
    x[75]     c808      1
    x[75]     c809      -1
    x[75]     c814      1
    x[75]     c815      -1
    x[75]     c820      1
    x[75]     c821      -1
    x[75]     c826      1
    x[75]     c827      -1
    x[75]     c832      1
    x[75]     c833      -1
    x[75]     c838      1
    x[75]     c839      -1
    x[75]     c844      1
    x[75]     c845      -1
    x[75]     c850      1
    x[75]     c851      -1
    x[75]     c856      1
    x[75]     c857      -1
    x[75]     c862      1
    x[75]     c863      -1
    x[75]     c868      1
    x[75]     c869      -1
    x[75]     c874      1
    x[75]     c875      -1
    x[75]     c880      1
    x[75]     c881      -1
    x[75]     c886      1
    x[75]     c887      -1
    x[75]     c892      1
    x[75]     c893      -1
    x[75]     c898      1
    x[75]     c899      -1
    x[75]     c904      1
    x[75]     c905      -1
    x[75]     c910      1
    x[75]     c911      -1
    x[75]     c916      1
    x[75]     c917      -1
    x[75]     c922      1
    x[75]     c923      -1
    x[75]     c928      1
    x[75]     c929      -1
    x[75]     c934      1
    x[75]     c935      -1
    x[75]     c940      1
    x[75]     c941      -1
    x[75]     c946      1
    x[75]     c947      -1
    x[75]     c952      1
    x[75]     c953      -1
    x[75]     c958      1
    x[75]     c959      -1
    x[76]     c28_1     -1
    x[76]     c29_1     1
    x[76]     c226_1    -1
    x[76]     c227_1    1
    x[76]     c418      -1
    x[76]     c419      1
    x[76]     c604      -1
    x[76]     c605      1
    x[76]     c784      -1
    x[76]     c785      1
    x[76]     c964      1
    x[76]     c965      -1
    x[76]     c970      1
    x[76]     c971      -1
    x[76]     c976      1
    x[76]     c977      -1
    x[76]     c982      1
    x[76]     c983      -1
    x[76]     c988      1
    x[76]     c989      -1
    x[76]     c994      1
    x[76]     c995      -1
    x[76]     c1000     1
    x[76]     c1001     -1
    x[76]     c1006     1
    x[76]     c1007     -1
    x[76]     c1012     1
    x[76]     c1013     -1
    x[76]     c1018     1
    x[76]     c1019     -1
    x[76]     c1024     1
    x[76]     c1025     -1
    x[76]     c1030     1
    x[76]     c1031     -1
    x[76]     c1036     1
    x[76]     c1037     -1
    x[76]     c1042     1
    x[76]     c1043     -1
    x[76]     c1048     1
    x[76]     c1049     -1
    x[76]     c1054     1
    x[76]     c1055     -1
    x[76]     c1060     1
    x[76]     c1061     -1
    x[76]     c1066     1
    x[76]     c1067     -1
    x[76]     c1072     1
    x[76]     c1073     -1
    x[76]     c1078     1
    x[76]     c1079     -1
    x[76]     c1084     1
    x[76]     c1085     -1
    x[76]     c1090     1
    x[76]     c1091     -1
    x[76]     c1096     1
    x[76]     c1097     -1
    x[76]     c1102     1
    x[76]     c1103     -1
    x[76]     c1108     1
    x[76]     c1109     -1
    x[76]     c1114     1
    x[76]     c1115     -1
    x[76]     c1120     1
    x[76]     c1121     -1
    x[76]     c1126     1
    x[76]     c1127     -1
    x[76]     c1132     1
    x[76]     c1133     -1
    x[77]     c34_1     -1
    x[77]     c35_1     1
    x[77]     c232_1    -1
    x[77]     c233_1    1
    x[77]     c424      -1
    x[77]     c425      1
    x[77]     c610      -1
    x[77]     c611      1
    x[77]     c790      -1
    x[77]     c791      1
    x[77]     c964      -1
    x[77]     c965      1
    x[77]     c1138     1
    x[77]     c1139     -1
    x[77]     c1144     1
    x[77]     c1145     -1
    x[77]     c1150     1
    x[77]     c1151     -1
    x[77]     c1156     1
    x[77]     c1157     -1
    x[77]     c1162     1
    x[77]     c1163     -1
    x[77]     c1168     1
    x[77]     c1169     -1
    x[77]     c1174     1
    x[77]     c1175     -1
    x[77]     c1180     1
    x[77]     c1181     -1
    x[77]     c1186     1
    x[77]     c1187     -1
    x[77]     c1192     1
    x[77]     c1193     -1
    x[77]     c1198     1
    x[77]     c1199     -1
    x[77]     c1204     1
    x[77]     c1205     -1
    x[77]     c1210     1
    x[77]     c1211     -1
    x[77]     c1216     1
    x[77]     c1217     -1
    x[77]     c1222     1
    x[77]     c1223     -1
    x[77]     c1228     1
    x[77]     c1229     -1
    x[77]     c1234     1
    x[77]     c1235     -1
    x[77]     c1240     1
    x[77]     c1241     -1
    x[77]     c1246     1
    x[77]     c1247     -1
    x[77]     c1252     1
    x[77]     c1253     -1
    x[77]     c1258     1
    x[77]     c1259     -1
    x[77]     c1264     1
    x[77]     c1265     -1
    x[77]     c1270     1
    x[77]     c1271     -1
    x[77]     c1276     1
    x[77]     c1277     -1
    x[77]     c1282     1
    x[77]     c1283     -1
    x[77]     c1288     1
    x[77]     c1289     -1
    x[77]     c1294     1
    x[77]     c1295     -1
    x[77]     c1300     1
    x[77]     c1301     -1
    x[78]     c40_1     -1
    x[78]     c41_1     1
    x[78]     c238_1    -1
    x[78]     c239_1    1
    x[78]     c430      -1
    x[78]     c431      1
    x[78]     c616      -1
    x[78]     c617      1
    x[78]     c796      -1
    x[78]     c797      1
    x[78]     c970      -1
    x[78]     c971      1
    x[78]     c1138     -1
    x[78]     c1139     1
    x[78]     c1306     1
    x[78]     c1307     -1
    x[78]     c1312     1
    x[78]     c1313     -1
    x[78]     c1318     1
    x[78]     c1319     -1
    x[78]     c1324     1
    x[78]     c1325     -1
    x[78]     c1330     1
    x[78]     c1331     -1
    x[78]     c1336     1
    x[78]     c1337     -1
    x[78]     c1342     1
    x[78]     c1343     -1
    x[78]     c1348     1
    x[78]     c1349     -1
    x[78]     c1354     1
    x[78]     c1355     -1
    x[78]     c1360     1
    x[78]     c1361     -1
    x[78]     c1366     1
    x[78]     c1367     -1
    x[78]     c1372     1
    x[78]     c1373     -1
    x[78]     c1378     1
    x[78]     c1379     -1
    x[78]     c1384     1
    x[78]     c1385     -1
    x[78]     c1390     1
    x[78]     c1391     -1
    x[78]     c1396     1
    x[78]     c1397     -1
    x[78]     c1402     1
    x[78]     c1403     -1
    x[78]     c1408     1
    x[78]     c1409     -1
    x[78]     c1414     1
    x[78]     c1415     -1
    x[78]     c1420     1
    x[78]     c1421     -1
    x[78]     c1426     1
    x[78]     c1427     -1
    x[78]     c1432     1
    x[78]     c1433     -1
    x[78]     c1438     1
    x[78]     c1439     -1
    x[78]     c1444     1
    x[78]     c1445     -1
    x[78]     c1450     1
    x[78]     c1451     -1
    x[78]     c1456     1
    x[78]     c1457     -1
    x[78]     c1462     1
    x[78]     c1463     -1
    x[79]     c46_1     -1
    x[79]     c47_1     1
    x[79]     c244      -1
    x[79]     c245      1
    x[79]     c436      -1
    x[79]     c437      1
    x[79]     c622      -1
    x[79]     c623      1
    x[79]     c802      -1
    x[79]     c803      1
    x[79]     c976      -1
    x[79]     c977      1
    x[79]     c1144     -1
    x[79]     c1145     1
    x[79]     c1306     -1
    x[79]     c1307     1
    x[79]     c1468     1
    x[79]     c1469     -1
    x[79]     c1474     1
    x[79]     c1475     -1
    x[79]     c1480     1
    x[79]     c1481     -1
    x[79]     c1486     1
    x[79]     c1487     -1
    x[79]     c1492     1
    x[79]     c1493     -1
    x[79]     c1498     1
    x[79]     c1499     -1
    x[79]     c1504     1
    x[79]     c1505     -1
    x[79]     c1510     1
    x[79]     c1511     -1
    x[79]     c1516     1
    x[79]     c1517     -1
    x[79]     c1522     1
    x[79]     c1523     -1
    x[79]     c1528     1
    x[79]     c1529     -1
    x[79]     c1534     1
    x[79]     c1535     -1
    x[79]     c1540     1
    x[79]     c1541     -1
    x[79]     c1546     1
    x[79]     c1547     -1
    x[79]     c1552     1
    x[79]     c1553     -1
    x[79]     c1558     1
    x[79]     c1559     -1
    x[79]     c1564     1
    x[79]     c1565     -1
    x[79]     c1570     1
    x[79]     c1571     -1
    x[79]     c1576     1
    x[79]     c1577     -1
    x[79]     c1582     1
    x[79]     c1583     -1
    x[79]     c1588     1
    x[79]     c1589     -1
    x[79]     c1594     1
    x[79]     c1595     -1
    x[79]     c1600     1
    x[79]     c1601     -1
    x[79]     c1606     1
    x[79]     c1607     -1
    x[79]     c1612     1
    x[79]     c1613     -1
    x[79]     c1618     1
    x[79]     c1619     -1
    x[80]     c52_1     -1
    x[80]     c53_1     1
    x[80]     c250      -1
    x[80]     c251      1
    x[80]     c442      -1
    x[80]     c443      1
    x[80]     c628      -1
    x[80]     c629      1
    x[80]     c808      -1
    x[80]     c809      1
    x[80]     c982      -1
    x[80]     c983      1
    x[80]     c1150     -1
    x[80]     c1151     1
    x[80]     c1312     -1
    x[80]     c1313     1
    x[80]     c1468     -1
    x[80]     c1469     1
    x[80]     c1624     1
    x[80]     c1625     -1
    x[80]     c1630     1
    x[80]     c1631     -1
    x[80]     c1636     1
    x[80]     c1637     -1
    x[80]     c1642     1
    x[80]     c1643     -1
    x[80]     c1648     1
    x[80]     c1649     -1
    x[80]     c1654     1
    x[80]     c1655     -1
    x[80]     c1660     1
    x[80]     c1661     -1
    x[80]     c1666     1
    x[80]     c1667     -1
    x[80]     c1672     1
    x[80]     c1673     -1
    x[80]     c1678     1
    x[80]     c1679     -1
    x[80]     c1684     1
    x[80]     c1685     -1
    x[80]     c1690     1
    x[80]     c1691     -1
    x[80]     c1696     1
    x[80]     c1697     -1
    x[80]     c1702     1
    x[80]     c1703     -1
    x[80]     c1708     1
    x[80]     c1709     -1
    x[80]     c1714     1
    x[80]     c1715     -1
    x[80]     c1720     1
    x[80]     c1721     -1
    x[80]     c1726     1
    x[80]     c1727     -1
    x[80]     c1732     1
    x[80]     c1733     -1
    x[80]     c1738     1
    x[80]     c1739     -1
    x[80]     c1744     1
    x[80]     c1745     -1
    x[80]     c1750     1
    x[80]     c1751     -1
    x[80]     c1756     1
    x[80]     c1757     -1
    x[80]     c1762     1
    x[80]     c1763     -1
    x[80]     c1768     1
    x[80]     c1769     -1
    x[81]     c58_1     -1
    x[81]     c59_1     1
    x[81]     c256      -1
    x[81]     c257      1
    x[81]     c448      -1
    x[81]     c449      1
    x[81]     c634      -1
    x[81]     c635      1
    x[81]     c814      -1
    x[81]     c815      1
    x[81]     c988      -1
    x[81]     c989      1
    x[81]     c1156     -1
    x[81]     c1157     1
    x[81]     c1318     -1
    x[81]     c1319     1
    x[81]     c1474     -1
    x[81]     c1475     1
    x[81]     c1624     -1
    x[81]     c1625     1
    x[81]     c1774     1
    x[81]     c1775     -1
    x[81]     c1780     1
    x[81]     c1781     -1
    x[81]     c1786     1
    x[81]     c1787     -1
    x[81]     c1792     1
    x[81]     c1793     -1
    x[81]     c1798     1
    x[81]     c1799     -1
    x[81]     c1804     1
    x[81]     c1805     -1
    x[81]     c1810     1
    x[81]     c1811     -1
    x[81]     c1816     1
    x[81]     c1817     -1
    x[81]     c1822     1
    x[81]     c1823     -1
    x[81]     c1828     1
    x[81]     c1829     -1
    x[81]     c1834     1
    x[81]     c1835     -1
    x[81]     c1840     1
    x[81]     c1841     -1
    x[81]     c1846     1
    x[81]     c1847     -1
    x[81]     c1852     1
    x[81]     c1853     -1
    x[81]     c1858     1
    x[81]     c1859     -1
    x[81]     c1864     1
    x[81]     c1865     -1
    x[81]     c1870     1
    x[81]     c1871     -1
    x[81]     c1876     1
    x[81]     c1877     -1
    x[81]     c1882     1
    x[81]     c1883     -1
    x[81]     c1888     1
    x[81]     c1889     -1
    x[81]     c1894     1
    x[81]     c1895     -1
    x[81]     c1900     1
    x[81]     c1901     -1
    x[81]     c1906     1
    x[81]     c1907     -1
    x[81]     c1912     1
    x[81]     c1913     -1
    x[82]     c64_1     -1
    x[82]     c65_1     1
    x[82]     c262      -1
    x[82]     c263      1
    x[82]     c454      -1
    x[82]     c455      1
    x[82]     c640      -1
    x[82]     c641      1
    x[82]     c820      -1
    x[82]     c821      1
    x[82]     c994      -1
    x[82]     c995      1
    x[82]     c1162     -1
    x[82]     c1163     1
    x[82]     c1324     -1
    x[82]     c1325     1
    x[82]     c1480     -1
    x[82]     c1481     1
    x[82]     c1630     -1
    x[82]     c1631     1
    x[82]     c1774     -1
    x[82]     c1775     1
    x[82]     c1918     1
    x[82]     c1919     -1
    x[82]     c1924     1
    x[82]     c1925     -1
    x[82]     c1930     1
    x[82]     c1931     -1
    x[82]     c1936     1
    x[82]     c1937     -1
    x[82]     c1942     1
    x[82]     c1943     -1
    x[82]     c1948     1
    x[82]     c1949     -1
    x[82]     c1954     1
    x[82]     c1955     -1
    x[82]     c1960     1
    x[82]     c1961     -1
    x[82]     c1966     1
    x[82]     c1967     -1
    x[82]     c1972     1
    x[82]     c1973     -1
    x[82]     c1978     1
    x[82]     c1979     -1
    x[82]     c1984     1
    x[82]     c1985     -1
    x[82]     c1990     1
    x[82]     c1991     -1
    x[82]     c1996     1
    x[82]     c1997     -1
    x[82]     c2002     1
    x[82]     c2003     -1
    x[82]     c2008     1
    x[82]     c2009     -1
    x[82]     c2014     1
    x[82]     c2015     -1
    x[82]     c2020     1
    x[82]     c2021     -1
    x[82]     c2026     1
    x[82]     c2027     -1
    x[82]     c2032     1
    x[82]     c2033     -1
    x[82]     c2038     1
    x[82]     c2039     -1
    x[82]     c2044     1
    x[82]     c2045     -1
    x[82]     c2050     1
    x[82]     c2051     -1
    x[83]     c70_1     -1
    x[83]     c71_1     1
    x[83]     c268      -1
    x[83]     c269      1
    x[83]     c460      -1
    x[83]     c461      1
    x[83]     c646      -1
    x[83]     c647      1
    x[83]     c826      -1
    x[83]     c827      1
    x[83]     c1000     -1
    x[83]     c1001     1
    x[83]     c1168     -1
    x[83]     c1169     1
    x[83]     c1330     -1
    x[83]     c1331     1
    x[83]     c1486     -1
    x[83]     c1487     1
    x[83]     c1636     -1
    x[83]     c1637     1
    x[83]     c1780     -1
    x[83]     c1781     1
    x[83]     c1918     -1
    x[83]     c1919     1
    x[83]     c2056     1
    x[83]     c2057     -1
    x[83]     c2062     1
    x[83]     c2063     -1
    x[83]     c2068     1
    x[83]     c2069     -1
    x[83]     c2074     1
    x[83]     c2075     -1
    x[83]     c2080     1
    x[83]     c2081     -1
    x[83]     c2086     1
    x[83]     c2087     -1
    x[83]     c2092     1
    x[83]     c2093     -1
    x[83]     c2098     1
    x[83]     c2099     -1
    x[83]     c2104     1
    x[83]     c2105     -1
    x[83]     c2110     1
    x[83]     c2111     -1
    x[83]     c2116     1
    x[83]     c2117     -1
    x[83]     c2122     1
    x[83]     c2123     -1
    x[83]     c2128     1
    x[83]     c2129     -1
    x[83]     c2134     1
    x[83]     c2135     -1
    x[83]     c2140     1
    x[83]     c2141     -1
    x[83]     c2146     1
    x[83]     c2147     -1
    x[83]     c2152     1
    x[83]     c2153     -1
    x[83]     c2158     1
    x[83]     c2159     -1
    x[83]     c2164     1
    x[83]     c2165     -1
    x[83]     c2170     1
    x[83]     c2171     -1
    x[83]     c2176     1
    x[83]     c2177     -1
    x[83]     c2182     1
    x[83]     c2183     -1
    x[84]     c76_1     -1
    x[84]     c77_1     1
    x[84]     c274      -1
    x[84]     c275      1
    x[84]     c466      -1
    x[84]     c467      1
    x[84]     c652      -1
    x[84]     c653      1
    x[84]     c832      -1
    x[84]     c833      1
    x[84]     c1006     -1
    x[84]     c1007     1
    x[84]     c1174     -1
    x[84]     c1175     1
    x[84]     c1336     -1
    x[84]     c1337     1
    x[84]     c1492     -1
    x[84]     c1493     1
    x[84]     c1642     -1
    x[84]     c1643     1
    x[84]     c1786     -1
    x[84]     c1787     1
    x[84]     c1924     -1
    x[84]     c1925     1
    x[84]     c2056     -1
    x[84]     c2057     1
    x[84]     c2188     1
    x[84]     c2189     -1
    x[84]     c2194     1
    x[84]     c2195     -1
    x[84]     c2200     1
    x[84]     c2201     -1
    x[84]     c2206     1
    x[84]     c2207     -1
    x[84]     c2212     1
    x[84]     c2213     -1
    x[84]     c2218     1
    x[84]     c2219     -1
    x[84]     c2224     1
    x[84]     c2225     -1
    x[84]     c2230     1
    x[84]     c2231     -1
    x[84]     c2236     1
    x[84]     c2237     -1
    x[84]     c2242     1
    x[84]     c2243     -1
    x[84]     c2248     1
    x[84]     c2249     -1
    x[84]     c2254     1
    x[84]     c2255     -1
    x[84]     c2260     1
    x[84]     c2261     -1
    x[84]     c2266     1
    x[84]     c2267     -1
    x[84]     c2272     1
    x[84]     c2273     -1
    x[84]     c2278     1
    x[84]     c2279     -1
    x[84]     c2284     1
    x[84]     c2285     -1
    x[84]     c2290     1
    x[84]     c2291     -1
    x[84]     c2296     1
    x[84]     c2297     -1
    x[84]     c2302     1
    x[84]     c2303     -1
    x[84]     c2308     1
    x[84]     c2309     -1
    x[85]     c82_1     -1
    x[85]     c83_1     1
    x[85]     c280      -1
    x[85]     c281      1
    x[85]     c472      -1
    x[85]     c473      1
    x[85]     c658      -1
    x[85]     c659      1
    x[85]     c838      -1
    x[85]     c839      1
    x[85]     c1012     -1
    x[85]     c1013     1
    x[85]     c1180     -1
    x[85]     c1181     1
    x[85]     c1342     -1
    x[85]     c1343     1
    x[85]     c1498     -1
    x[85]     c1499     1
    x[85]     c1648     -1
    x[85]     c1649     1
    x[85]     c1792     -1
    x[85]     c1793     1
    x[85]     c1930     -1
    x[85]     c1931     1
    x[85]     c2062     -1
    x[85]     c2063     1
    x[85]     c2188     -1
    x[85]     c2189     1
    x[85]     c2314     1
    x[85]     c2315     -1
    x[85]     c2320     1
    x[85]     c2321     -1
    x[85]     c2326     1
    x[85]     c2327     -1
    x[85]     c2332     1
    x[85]     c2333     -1
    x[85]     c2338     1
    x[85]     c2339     -1
    x[85]     c2344     1
    x[85]     c2345     -1
    x[85]     c2350     1
    x[85]     c2351     -1
    x[85]     c2356     1
    x[85]     c2357     -1
    x[85]     c2362     1
    x[85]     c2363     -1
    x[85]     c2368     1
    x[85]     c2369     -1
    x[85]     c2374     1
    x[85]     c2375     -1
    x[85]     c2380     1
    x[85]     c2381     -1
    x[85]     c2386     1
    x[85]     c2387     -1
    x[85]     c2392     1
    x[85]     c2393     -1
    x[85]     c2398     1
    x[85]     c2399     -1
    x[85]     c2404     1
    x[85]     c2405     -1
    x[85]     c2410     1
    x[85]     c2411     -1
    x[85]     c2416     1
    x[85]     c2417     -1
    x[85]     c2422     1
    x[85]     c2423     -1
    x[85]     c2428     1
    x[85]     c2429     -1
    x[86]     c88_1     -1
    x[86]     c89_1     1
    x[86]     c286      -1
    x[86]     c287      1
    x[86]     c478      -1
    x[86]     c479      1
    x[86]     c664      -1
    x[86]     c665      1
    x[86]     c844      -1
    x[86]     c845      1
    x[86]     c1018     -1
    x[86]     c1019     1
    x[86]     c1186     -1
    x[86]     c1187     1
    x[86]     c1348     -1
    x[86]     c1349     1
    x[86]     c1504     -1
    x[86]     c1505     1
    x[86]     c1654     -1
    x[86]     c1655     1
    x[86]     c1798     -1
    x[86]     c1799     1
    x[86]     c1936     -1
    x[86]     c1937     1
    x[86]     c2068     -1
    x[86]     c2069     1
    x[86]     c2194     -1
    x[86]     c2195     1
    x[86]     c2314     -1
    x[86]     c2315     1
    x[86]     c2434     1
    x[86]     c2435     -1
    x[86]     c2440     1
    x[86]     c2441     -1
    x[86]     c2446     1
    x[86]     c2447     -1
    x[86]     c2452     1
    x[86]     c2453     -1
    x[86]     c2458     1
    x[86]     c2459     -1
    x[86]     c2464     1
    x[86]     c2465     -1
    x[86]     c2470     1
    x[86]     c2471     -1
    x[86]     c2476     1
    x[86]     c2477     -1
    x[86]     c2482     1
    x[86]     c2483     -1
    x[86]     c2488     1
    x[86]     c2489     -1
    x[86]     c2494     1
    x[86]     c2495     -1
    x[86]     c2500     1
    x[86]     c2501     -1
    x[86]     c2506     1
    x[86]     c2507     -1
    x[86]     c2512     1
    x[86]     c2513     -1
    x[86]     c2518     1
    x[86]     c2519     -1
    x[86]     c2524     1
    x[86]     c2525     -1
    x[86]     c2530     1
    x[86]     c2531     -1
    x[86]     c2536     1
    x[86]     c2537     -1
    x[86]     c2542     1
    x[86]     c2543     -1
    x[87]     c94_1     -1
    x[87]     c95_1     1
    x[87]     c292      -1
    x[87]     c293      1
    x[87]     c484      -1
    x[87]     c485      1
    x[87]     c670      -1
    x[87]     c671      1
    x[87]     c850      -1
    x[87]     c851      1
    x[87]     c1024     -1
    x[87]     c1025     1
    x[87]     c1192     -1
    x[87]     c1193     1
    x[87]     c1354     -1
    x[87]     c1355     1
    x[87]     c1510     -1
    x[87]     c1511     1
    x[87]     c1660     -1
    x[87]     c1661     1
    x[87]     c1804     -1
    x[87]     c1805     1
    x[87]     c1942     -1
    x[87]     c1943     1
    x[87]     c2074     -1
    x[87]     c2075     1
    x[87]     c2200     -1
    x[87]     c2201     1
    x[87]     c2320     -1
    x[87]     c2321     1
    x[87]     c2434     -1
    x[87]     c2435     1
    x[87]     c2548     1
    x[87]     c2549     -1
    x[87]     c2554     1
    x[87]     c2555     -1
    x[87]     c2560     1
    x[87]     c2561     -1
    x[87]     c2566     1
    x[87]     c2567     -1
    x[87]     c2572     1
    x[87]     c2573     -1
    x[87]     c2578     1
    x[87]     c2579     -1
    x[87]     c2584     1
    x[87]     c2585     -1
    x[87]     c2590     1
    x[87]     c2591     -1
    x[87]     c2596     1
    x[87]     c2597     -1
    x[87]     c2602     1
    x[87]     c2603     -1
    x[87]     c2608     1
    x[87]     c2609     -1
    x[87]     c2614     1
    x[87]     c2615     -1
    x[87]     c2620     1
    x[87]     c2621     -1
    x[87]     c2626     1
    x[87]     c2627     -1
    x[87]     c2632     1
    x[87]     c2633     -1
    x[87]     c2638     1
    x[87]     c2639     -1
    x[87]     c2644     1
    x[87]     c2645     -1
    x[87]     c2650     1
    x[87]     c2651     -1
    x[88]     c100_1    -1
    x[88]     c101_1    1
    x[88]     c298      -1
    x[88]     c299      1
    x[88]     c490      -1
    x[88]     c491      1
    x[88]     c676      -1
    x[88]     c677      1
    x[88]     c856      -1
    x[88]     c857      1
    x[88]     c1030     -1
    x[88]     c1031     1
    x[88]     c1198     -1
    x[88]     c1199     1
    x[88]     c1360     -1
    x[88]     c1361     1
    x[88]     c1516     -1
    x[88]     c1517     1
    x[88]     c1666     -1
    x[88]     c1667     1
    x[88]     c1810     -1
    x[88]     c1811     1
    x[88]     c1948     -1
    x[88]     c1949     1
    x[88]     c2080     -1
    x[88]     c2081     1
    x[88]     c2206     -1
    x[88]     c2207     1
    x[88]     c2326     -1
    x[88]     c2327     1
    x[88]     c2440     -1
    x[88]     c2441     1
    x[88]     c2548     -1
    x[88]     c2549     1
    x[88]     c2656     1
    x[88]     c2657     -1
    x[88]     c2662     1
    x[88]     c2663     -1
    x[88]     c2668     1
    x[88]     c2669     -1
    x[88]     c2674     1
    x[88]     c2675     -1
    x[88]     c2680     1
    x[88]     c2681     -1
    x[88]     c2686     1
    x[88]     c2687     -1
    x[88]     c2692     1
    x[88]     c2693     -1
    x[88]     c2698     1
    x[88]     c2699     -1
    x[88]     c2704     1
    x[88]     c2705     -1
    x[88]     c2710     1
    x[88]     c2711     -1
    x[88]     c2716     1
    x[88]     c2717     -1
    x[88]     c2722     1
    x[88]     c2723     -1
    x[88]     c2728     1
    x[88]     c2729     -1
    x[88]     c2734     1
    x[88]     c2735     -1
    x[88]     c2740     1
    x[88]     c2741     -1
    x[88]     c2746     1
    x[88]     c2747     -1
    x[88]     c2752     1
    x[88]     c2753     -1
    x[89]     c106_1    -1
    x[89]     c107_1    1
    x[89]     c304      -1
    x[89]     c305      1
    x[89]     c496      -1
    x[89]     c497      1
    x[89]     c682      -1
    x[89]     c683      1
    x[89]     c862      -1
    x[89]     c863      1
    x[89]     c1036     -1
    x[89]     c1037     1
    x[89]     c1204     -1
    x[89]     c1205     1
    x[89]     c1366     -1
    x[89]     c1367     1
    x[89]     c1522     -1
    x[89]     c1523     1
    x[89]     c1672     -1
    x[89]     c1673     1
    x[89]     c1816     -1
    x[89]     c1817     1
    x[89]     c1954     -1
    x[89]     c1955     1
    x[89]     c2086     -1
    x[89]     c2087     1
    x[89]     c2212     -1
    x[89]     c2213     1
    x[89]     c2332     -1
    x[89]     c2333     1
    x[89]     c2446     -1
    x[89]     c2447     1
    x[89]     c2554     -1
    x[89]     c2555     1
    x[89]     c2656     -1
    x[89]     c2657     1
    x[89]     c2758     1
    x[89]     c2759     -1
    x[89]     c2764     1
    x[89]     c2765     -1
    x[89]     c2770     1
    x[89]     c2771     -1
    x[89]     c2776     1
    x[89]     c2777     -1
    x[89]     c2782     1
    x[89]     c2783     -1
    x[89]     c2788     1
    x[89]     c2789     -1
    x[89]     c2794     1
    x[89]     c2795     -1
    x[89]     c2800     1
    x[89]     c2801     -1
    x[89]     c2806     1
    x[89]     c2807     -1
    x[89]     c2812     1
    x[89]     c2813     -1
    x[89]     c2818     1
    x[89]     c2819     -1
    x[89]     c2824     1
    x[89]     c2825     -1
    x[89]     c2830     1
    x[89]     c2831     -1
    x[89]     c2836     1
    x[89]     c2837     -1
    x[89]     c2842     1
    x[89]     c2843     -1
    x[89]     c2848     1
    x[89]     c2849     -1
    x[90]     c112_1    -1
    x[90]     c113_1    1
    x[90]     c310      -1
    x[90]     c311      1
    x[90]     c502      -1
    x[90]     c503      1
    x[90]     c688      -1
    x[90]     c689      1
    x[90]     c868      -1
    x[90]     c869      1
    x[90]     c1042     -1
    x[90]     c1043     1
    x[90]     c1210     -1
    x[90]     c1211     1
    x[90]     c1372     -1
    x[90]     c1373     1
    x[90]     c1528     -1
    x[90]     c1529     1
    x[90]     c1678     -1
    x[90]     c1679     1
    x[90]     c1822     -1
    x[90]     c1823     1
    x[90]     c1960     -1
    x[90]     c1961     1
    x[90]     c2092     -1
    x[90]     c2093     1
    x[90]     c2218     -1
    x[90]     c2219     1
    x[90]     c2338     -1
    x[90]     c2339     1
    x[90]     c2452     -1
    x[90]     c2453     1
    x[90]     c2560     -1
    x[90]     c2561     1
    x[90]     c2662     -1
    x[90]     c2663     1
    x[90]     c2758     -1
    x[90]     c2759     1
    x[90]     c2854     1
    x[90]     c2855     -1
    x[90]     c2860     1
    x[90]     c2861     -1
    x[90]     c2866     1
    x[90]     c2867     -1
    x[90]     c2872     1
    x[90]     c2873     -1
    x[90]     c2878     1
    x[90]     c2879     -1
    x[90]     c2884     1
    x[90]     c2885     -1
    x[90]     c2890     1
    x[90]     c2891     -1
    x[90]     c2896     1
    x[90]     c2897     -1
    x[90]     c2902     1
    x[90]     c2903     -1
    x[90]     c2908     1
    x[90]     c2909     -1
    x[90]     c2914     1
    x[90]     c2915     -1
    x[90]     c2920     1
    x[90]     c2921     -1
    x[90]     c2926     1
    x[90]     c2927     -1
    x[90]     c2932     1
    x[90]     c2933     -1
    x[90]     c2938     1
    x[90]     c2939     -1
    x[91]     c118_1    -1
    x[91]     c119_1    1
    x[91]     c316      -1
    x[91]     c317      1
    x[91]     c508      -1
    x[91]     c509      1
    x[91]     c694      -1
    x[91]     c695      1
    x[91]     c874      -1
    x[91]     c875      1
    x[91]     c1048     -1
    x[91]     c1049     1
    x[91]     c1216     -1
    x[91]     c1217     1
    x[91]     c1378     -1
    x[91]     c1379     1
    x[91]     c1534     -1
    x[91]     c1535     1
    x[91]     c1684     -1
    x[91]     c1685     1
    x[91]     c1828     -1
    x[91]     c1829     1
    x[91]     c1966     -1
    x[91]     c1967     1
    x[91]     c2098     -1
    x[91]     c2099     1
    x[91]     c2224     -1
    x[91]     c2225     1
    x[91]     c2344     -1
    x[91]     c2345     1
    x[91]     c2458     -1
    x[91]     c2459     1
    x[91]     c2566     -1
    x[91]     c2567     1
    x[91]     c2668     -1
    x[91]     c2669     1
    x[91]     c2764     -1
    x[91]     c2765     1
    x[91]     c2854     -1
    x[91]     c2855     1
    x[91]     c2944     1
    x[91]     c2945     -1
    x[91]     c2950     1
    x[91]     c2951     -1
    x[91]     c2956     1
    x[91]     c2957     -1
    x[91]     c2962     1
    x[91]     c2963     -1
    x[91]     c2968     1
    x[91]     c2969     -1
    x[91]     c2974     1
    x[91]     c2975     -1
    x[91]     c2980     1
    x[91]     c2981     -1
    x[91]     c2986     1
    x[91]     c2987     -1
    x[91]     c2992     1
    x[91]     c2993     -1
    x[91]     c2998     1
    x[91]     c2999     -1
    x[91]     c3004     1
    x[91]     c3005     -1
    x[91]     c3010     1
    x[91]     c3011     -1
    x[91]     c3016     1
    x[91]     c3017     -1
    x[91]     c3022     1
    x[91]     c3023     -1
    x[92]     c124_1    -1
    x[92]     c125_1    1
    x[92]     c322      -1
    x[92]     c323      1
    x[92]     c514      -1
    x[92]     c515      1
    x[92]     c700      -1
    x[92]     c701      1
    x[92]     c880      -1
    x[92]     c881      1
    x[92]     c1054     -1
    x[92]     c1055     1
    x[92]     c1222     -1
    x[92]     c1223     1
    x[92]     c1384     -1
    x[92]     c1385     1
    x[92]     c1540     -1
    x[92]     c1541     1
    x[92]     c1690     -1
    x[92]     c1691     1
    x[92]     c1834     -1
    x[92]     c1835     1
    x[92]     c1972     -1
    x[92]     c1973     1
    x[92]     c2104     -1
    x[92]     c2105     1
    x[92]     c2230     -1
    x[92]     c2231     1
    x[92]     c2350     -1
    x[92]     c2351     1
    x[92]     c2464     -1
    x[92]     c2465     1
    x[92]     c2572     -1
    x[92]     c2573     1
    x[92]     c2674     -1
    x[92]     c2675     1
    x[92]     c2770     -1
    x[92]     c2771     1
    x[92]     c2860     -1
    x[92]     c2861     1
    x[92]     c2944     -1
    x[92]     c2945     1
    x[92]     c3028     1
    x[92]     c3029     -1
    x[92]     c3034     1
    x[92]     c3035     -1
    x[92]     c3040     1
    x[92]     c3041     -1
    x[92]     c3046     1
    x[92]     c3047     -1
    x[92]     c3052     1
    x[92]     c3053     -1
    x[92]     c3058     1
    x[92]     c3059     -1
    x[92]     c3064     1
    x[92]     c3065     -1
    x[92]     c3070     1
    x[92]     c3071     -1
    x[92]     c3076     1
    x[92]     c3077     -1
    x[92]     c3082     1
    x[92]     c3083     -1
    x[92]     c3088     1
    x[92]     c3089     -1
    x[92]     c3094     1
    x[92]     c3095     -1
    x[92]     c3100     1
    x[92]     c3101     -1
    x[93]     c130_1    -1
    x[93]     c131_1    1
    x[93]     c328      -1
    x[93]     c329      1
    x[93]     c520      -1
    x[93]     c521      1
    x[93]     c706      -1
    x[93]     c707      1
    x[93]     c886      -1
    x[93]     c887      1
    x[93]     c1060     -1
    x[93]     c1061     1
    x[93]     c1228     -1
    x[93]     c1229     1
    x[93]     c1390     -1
    x[93]     c1391     1
    x[93]     c1546     -1
    x[93]     c1547     1
    x[93]     c1696     -1
    x[93]     c1697     1
    x[93]     c1840     -1
    x[93]     c1841     1
    x[93]     c1978     -1
    x[93]     c1979     1
    x[93]     c2110     -1
    x[93]     c2111     1
    x[93]     c2236     -1
    x[93]     c2237     1
    x[93]     c2356     -1
    x[93]     c2357     1
    x[93]     c2470     -1
    x[93]     c2471     1
    x[93]     c2578     -1
    x[93]     c2579     1
    x[93]     c2680     -1
    x[93]     c2681     1
    x[93]     c2776     -1
    x[93]     c2777     1
    x[93]     c2866     -1
    x[93]     c2867     1
    x[93]     c2950     -1
    x[93]     c2951     1
    x[93]     c3028     -1
    x[93]     c3029     1
    x[93]     c3106     1
    x[93]     c3107     -1
    x[93]     c3112     1
    x[93]     c3113     -1
    x[93]     c3118     1
    x[93]     c3119     -1
    x[93]     c3124     1
    x[93]     c3125     -1
    x[93]     c3130     1
    x[93]     c3131     -1
    x[93]     c3136     1
    x[93]     c3137     -1
    x[93]     c3142     1
    x[93]     c3143     -1
    x[93]     c3148     1
    x[93]     c3149     -1
    x[93]     c3154     1
    x[93]     c3155     -1
    x[93]     c3160     1
    x[93]     c3161     -1
    x[93]     c3166     1
    x[93]     c3167     -1
    x[93]     c3172     1
    x[93]     c3173     -1
    x[94]     c136_1    -1
    x[94]     c137_1    1
    x[94]     c334      -1
    x[94]     c335      1
    x[94]     c526      -1
    x[94]     c527      1
    x[94]     c712      -1
    x[94]     c713      1
    x[94]     c892      -1
    x[94]     c893      1
    x[94]     c1066     -1
    x[94]     c1067     1
    x[94]     c1234     -1
    x[94]     c1235     1
    x[94]     c1396     -1
    x[94]     c1397     1
    x[94]     c1552     -1
    x[94]     c1553     1
    x[94]     c1702     -1
    x[94]     c1703     1
    x[94]     c1846     -1
    x[94]     c1847     1
    x[94]     c1984     -1
    x[94]     c1985     1
    x[94]     c2116     -1
    x[94]     c2117     1
    x[94]     c2242     -1
    x[94]     c2243     1
    x[94]     c2362     -1
    x[94]     c2363     1
    x[94]     c2476     -1
    x[94]     c2477     1
    x[94]     c2584     -1
    x[94]     c2585     1
    x[94]     c2686     -1
    x[94]     c2687     1
    x[94]     c2782     -1
    x[94]     c2783     1
    x[94]     c2872     -1
    x[94]     c2873     1
    x[94]     c2956     -1
    x[94]     c2957     1
    x[94]     c3034     -1
    x[94]     c3035     1
    x[94]     c3106     -1
    x[94]     c3107     1
    x[94]     c3178     1
    x[94]     c3179     -1
    x[94]     c3184     1
    x[94]     c3185     -1
    x[94]     c3190     1
    x[94]     c3191     -1
    x[94]     c3196     1
    x[94]     c3197     -1
    x[94]     c3202     1
    x[94]     c3203     -1
    x[94]     c3208     1
    x[94]     c3209     -1
    x[94]     c3214     1
    x[94]     c3215     -1
    x[94]     c3220     1
    x[94]     c3221     -1
    x[94]     c3226     1
    x[94]     c3227     -1
    x[94]     c3232     1
    x[94]     c3233     -1
    x[94]     c3238     1
    x[94]     c3239     -1
    x[95]     c142_1    -1
    x[95]     c143_1    1
    x[95]     c340      -1
    x[95]     c341      1
    x[95]     c532      -1
    x[95]     c533      1
    x[95]     c718      -1
    x[95]     c719      1
    x[95]     c898      -1
    x[95]     c899      1
    x[95]     c1072     -1
    x[95]     c1073     1
    x[95]     c1240     -1
    x[95]     c1241     1
    x[95]     c1402     -1
    x[95]     c1403     1
    x[95]     c1558     -1
    x[95]     c1559     1
    x[95]     c1708     -1
    x[95]     c1709     1
    x[95]     c1852     -1
    x[95]     c1853     1
    x[95]     c1990     -1
    x[95]     c1991     1
    x[95]     c2122     -1
    x[95]     c2123     1
    x[95]     c2248     -1
    x[95]     c2249     1
    x[95]     c2368     -1
    x[95]     c2369     1
    x[95]     c2482     -1
    x[95]     c2483     1
    x[95]     c2590     -1
    x[95]     c2591     1
    x[95]     c2692     -1
    x[95]     c2693     1
    x[95]     c2788     -1
    x[95]     c2789     1
    x[95]     c2878     -1
    x[95]     c2879     1
    x[95]     c2962     -1
    x[95]     c2963     1
    x[95]     c3040     -1
    x[95]     c3041     1
    x[95]     c3112     -1
    x[95]     c3113     1
    x[95]     c3178     -1
    x[95]     c3179     1
    x[95]     c3244     1
    x[95]     c3245     -1
    x[95]     c3250     1
    x[95]     c3251     -1
    x[95]     c3256     1
    x[95]     c3257     -1
    x[95]     c3262     1
    x[95]     c3263     -1
    x[95]     c3268     1
    x[95]     c3269     -1
    x[95]     c3274     1
    x[95]     c3275     -1
    x[95]     c3280     1
    x[95]     c3281     -1
    x[95]     c3286     1
    x[95]     c3287     -1
    x[95]     c3292     1
    x[95]     c3293     -1
    x[95]     c3298     1
    x[95]     c3299     -1
    x[96]     c148_1    -1
    x[96]     c149_1    1
    x[96]     c346      -1
    x[96]     c347      1
    x[96]     c538      -1
    x[96]     c539      1
    x[96]     c724      -1
    x[96]     c725      1
    x[96]     c904      -1
    x[96]     c905      1
    x[96]     c1078     -1
    x[96]     c1079     1
    x[96]     c1246     -1
    x[96]     c1247     1
    x[96]     c1408     -1
    x[96]     c1409     1
    x[96]     c1564     -1
    x[96]     c1565     1
    x[96]     c1714     -1
    x[96]     c1715     1
    x[96]     c1858     -1
    x[96]     c1859     1
    x[96]     c1996     -1
    x[96]     c1997     1
    x[96]     c2128     -1
    x[96]     c2129     1
    x[96]     c2254     -1
    x[96]     c2255     1
    x[96]     c2374     -1
    x[96]     c2375     1
    x[96]     c2488     -1
    x[96]     c2489     1
    x[96]     c2596     -1
    x[96]     c2597     1
    x[96]     c2698     -1
    x[96]     c2699     1
    x[96]     c2794     -1
    x[96]     c2795     1
    x[96]     c2884     -1
    x[96]     c2885     1
    x[96]     c2968     -1
    x[96]     c2969     1
    x[96]     c3046     -1
    x[96]     c3047     1
    x[96]     c3118     -1
    x[96]     c3119     1
    x[96]     c3184     -1
    x[96]     c3185     1
    x[96]     c3244     -1
    x[96]     c3245     1
    x[96]     c3304     1
    x[96]     c3305     -1
    x[96]     c3310     1
    x[96]     c3311     -1
    x[96]     c3316     1
    x[96]     c3317     -1
    x[96]     c3322     1
    x[96]     c3323     -1
    x[96]     c3328     1
    x[96]     c3329     -1
    x[96]     c3334     1
    x[96]     c3335     -1
    x[96]     c3340     1
    x[96]     c3341     -1
    x[96]     c3346     1
    x[96]     c3347     -1
    x[96]     c3352     1
    x[96]     c3353     -1
    x[97]     c154_1    -1
    x[97]     c155_1    1
    x[97]     c352      -1
    x[97]     c353      1
    x[97]     c544      -1
    x[97]     c545      1
    x[97]     c730      -1
    x[97]     c731      1
    x[97]     c910      -1
    x[97]     c911      1
    x[97]     c1084     -1
    x[97]     c1085     1
    x[97]     c1252     -1
    x[97]     c1253     1
    x[97]     c1414     -1
    x[97]     c1415     1
    x[97]     c1570     -1
    x[97]     c1571     1
    x[97]     c1720     -1
    x[97]     c1721     1
    x[97]     c1864     -1
    x[97]     c1865     1
    x[97]     c2002     -1
    x[97]     c2003     1
    x[97]     c2134     -1
    x[97]     c2135     1
    x[97]     c2260     -1
    x[97]     c2261     1
    x[97]     c2380     -1
    x[97]     c2381     1
    x[97]     c2494     -1
    x[97]     c2495     1
    x[97]     c2602     -1
    x[97]     c2603     1
    x[97]     c2704     -1
    x[97]     c2705     1
    x[97]     c2800     -1
    x[97]     c2801     1
    x[97]     c2890     -1
    x[97]     c2891     1
    x[97]     c2974     -1
    x[97]     c2975     1
    x[97]     c3052     -1
    x[97]     c3053     1
    x[97]     c3124     -1
    x[97]     c3125     1
    x[97]     c3190     -1
    x[97]     c3191     1
    x[97]     c3250     -1
    x[97]     c3251     1
    x[97]     c3304     -1
    x[97]     c3305     1
    x[97]     c3358     1
    x[97]     c3359     -1
    x[97]     c3364     1
    x[97]     c3365     -1
    x[97]     c3370     1
    x[97]     c3371     -1
    x[97]     c3376     1
    x[97]     c3377     -1
    x[97]     c3382     1
    x[97]     c3383     -1
    x[97]     c3388     1
    x[97]     c3389     -1
    x[97]     c3394     1
    x[97]     c3395     -1
    x[97]     c3400     1
    x[97]     c3401     -1
    x[98]     c160_1    -1
    x[98]     c161_1    1
    x[98]     c358      -1
    x[98]     c359      1
    x[98]     c550      -1
    x[98]     c551      1
    x[98]     c736      -1
    x[98]     c737      1
    x[98]     c916      -1
    x[98]     c917      1
    x[98]     c1090     -1
    x[98]     c1091     1
    x[98]     c1258     -1
    x[98]     c1259     1
    x[98]     c1420     -1
    x[98]     c1421     1
    x[98]     c1576     -1
    x[98]     c1577     1
    x[98]     c1726     -1
    x[98]     c1727     1
    x[98]     c1870     -1
    x[98]     c1871     1
    x[98]     c2008     -1
    x[98]     c2009     1
    x[98]     c2140     -1
    x[98]     c2141     1
    x[98]     c2266     -1
    x[98]     c2267     1
    x[98]     c2386     -1
    x[98]     c2387     1
    x[98]     c2500     -1
    x[98]     c2501     1
    x[98]     c2608     -1
    x[98]     c2609     1
    x[98]     c2710     -1
    x[98]     c2711     1
    x[98]     c2806     -1
    x[98]     c2807     1
    x[98]     c2896     -1
    x[98]     c2897     1
    x[98]     c2980     -1
    x[98]     c2981     1
    x[98]     c3058     -1
    x[98]     c3059     1
    x[98]     c3130     -1
    x[98]     c3131     1
    x[98]     c3196     -1
    x[98]     c3197     1
    x[98]     c3256     -1
    x[98]     c3257     1
    x[98]     c3310     -1
    x[98]     c3311     1
    x[98]     c3358     -1
    x[98]     c3359     1
    x[98]     c3406     1
    x[98]     c3407     -1
    x[98]     c3412     1
    x[98]     c3413     -1
    x[98]     c3418     1
    x[98]     c3419     -1
    x[98]     c3424     1
    x[98]     c3425     -1
    x[98]     c3430     1
    x[98]     c3431     -1
    x[98]     c3436     1
    x[98]     c3437     -1
    x[98]     c3442     1
    x[98]     c3443     -1
    x[99]     c166_1    -1
    x[99]     c167_1    1
    x[99]     c364      -1
    x[99]     c365      1
    x[99]     c556      -1
    x[99]     c557      1
    x[99]     c742      -1
    x[99]     c743      1
    x[99]     c922      -1
    x[99]     c923      1
    x[99]     c1096     -1
    x[99]     c1097     1
    x[99]     c1264     -1
    x[99]     c1265     1
    x[99]     c1426     -1
    x[99]     c1427     1
    x[99]     c1582     -1
    x[99]     c1583     1
    x[99]     c1732     -1
    x[99]     c1733     1
    x[99]     c1876     -1
    x[99]     c1877     1
    x[99]     c2014     -1
    x[99]     c2015     1
    x[99]     c2146     -1
    x[99]     c2147     1
    x[99]     c2272     -1
    x[99]     c2273     1
    x[99]     c2392     -1
    x[99]     c2393     1
    x[99]     c2506     -1
    x[99]     c2507     1
    x[99]     c2614     -1
    x[99]     c2615     1
    x[99]     c2716     -1
    x[99]     c2717     1
    x[99]     c2812     -1
    x[99]     c2813     1
    x[99]     c2902     -1
    x[99]     c2903     1
    x[99]     c2986     -1
    x[99]     c2987     1
    x[99]     c3064     -1
    x[99]     c3065     1
    x[99]     c3136     -1
    x[99]     c3137     1
    x[99]     c3202     -1
    x[99]     c3203     1
    x[99]     c3262     -1
    x[99]     c3263     1
    x[99]     c3316     -1
    x[99]     c3317     1
    x[99]     c3364     -1
    x[99]     c3365     1
    x[99]     c3406     -1
    x[99]     c3407     1
    x[99]     c3448     1
    x[99]     c3449     -1
    x[99]     c3454     1
    x[99]     c3455     -1
    x[99]     c3460     1
    x[99]     c3461     -1
    x[99]     c3466     1
    x[99]     c3467     -1
    x[99]     c3472     1
    x[99]     c3473     -1
    x[99]     c3478     1
    x[99]     c3479     -1
    x[100]    c172_1    -1
    x[100]    c173_1    1
    x[100]    c370      -1
    x[100]    c371      1
    x[100]    c562      -1
    x[100]    c563      1
    x[100]    c748      -1
    x[100]    c749      1
    x[100]    c928      -1
    x[100]    c929      1
    x[100]    c1102     -1
    x[100]    c1103     1
    x[100]    c1270     -1
    x[100]    c1271     1
    x[100]    c1432     -1
    x[100]    c1433     1
    x[100]    c1588     -1
    x[100]    c1589     1
    x[100]    c1738     -1
    x[100]    c1739     1
    x[100]    c1882     -1
    x[100]    c1883     1
    x[100]    c2020     -1
    x[100]    c2021     1
    x[100]    c2152     -1
    x[100]    c2153     1
    x[100]    c2278     -1
    x[100]    c2279     1
    x[100]    c2398     -1
    x[100]    c2399     1
    x[100]    c2512     -1
    x[100]    c2513     1
    x[100]    c2620     -1
    x[100]    c2621     1
    x[100]    c2722     -1
    x[100]    c2723     1
    x[100]    c2818     -1
    x[100]    c2819     1
    x[100]    c2908     -1
    x[100]    c2909     1
    x[100]    c2992     -1
    x[100]    c2993     1
    x[100]    c3070     -1
    x[100]    c3071     1
    x[100]    c3142     -1
    x[100]    c3143     1
    x[100]    c3208     -1
    x[100]    c3209     1
    x[100]    c3268     -1
    x[100]    c3269     1
    x[100]    c3322     -1
    x[100]    c3323     1
    x[100]    c3370     -1
    x[100]    c3371     1
    x[100]    c3412     -1
    x[100]    c3413     1
    x[100]    c3448     -1
    x[100]    c3449     1
    x[100]    c3484     1
    x[100]    c3485     -1
    x[100]    c3490     1
    x[100]    c3491     -1
    x[100]    c3496     1
    x[100]    c3497     -1
    x[100]    c3502     1
    x[100]    c3503     -1
    x[100]    c3508     1
    x[100]    c3509     -1
    x[101]    c178_1    -1
    x[101]    c179_1    1
    x[101]    c376      -1
    x[101]    c377      1
    x[101]    c568      -1
    x[101]    c569      1
    x[101]    c754      -1
    x[101]    c755      1
    x[101]    c934      -1
    x[101]    c935      1
    x[101]    c1108     -1
    x[101]    c1109     1
    x[101]    c1276     -1
    x[101]    c1277     1
    x[101]    c1438     -1
    x[101]    c1439     1
    x[101]    c1594     -1
    x[101]    c1595     1
    x[101]    c1744     -1
    x[101]    c1745     1
    x[101]    c1888     -1
    x[101]    c1889     1
    x[101]    c2026     -1
    x[101]    c2027     1
    x[101]    c2158     -1
    x[101]    c2159     1
    x[101]    c2284     -1
    x[101]    c2285     1
    x[101]    c2404     -1
    x[101]    c2405     1
    x[101]    c2518     -1
    x[101]    c2519     1
    x[101]    c2626     -1
    x[101]    c2627     1
    x[101]    c2728     -1
    x[101]    c2729     1
    x[101]    c2824     -1
    x[101]    c2825     1
    x[101]    c2914     -1
    x[101]    c2915     1
    x[101]    c2998     -1
    x[101]    c2999     1
    x[101]    c3076     -1
    x[101]    c3077     1
    x[101]    c3148     -1
    x[101]    c3149     1
    x[101]    c3214     -1
    x[101]    c3215     1
    x[101]    c3274     -1
    x[101]    c3275     1
    x[101]    c3328     -1
    x[101]    c3329     1
    x[101]    c3376     -1
    x[101]    c3377     1
    x[101]    c3418     -1
    x[101]    c3419     1
    x[101]    c3454     -1
    x[101]    c3455     1
    x[101]    c3484     -1
    x[101]    c3485     1
    x[101]    c3514     1
    x[101]    c3515     -1
    x[101]    c3520     1
    x[101]    c3521     -1
    x[101]    c3526     1
    x[101]    c3527     -1
    x[101]    c3532     1
    x[101]    c3533     -1
    x[102]    c184_1    -1
    x[102]    c185_1    1
    x[102]    c382      -1
    x[102]    c383      1
    x[102]    c574      -1
    x[102]    c575      1
    x[102]    c760      -1
    x[102]    c761      1
    x[102]    c940      -1
    x[102]    c941      1
    x[102]    c1114     -1
    x[102]    c1115     1
    x[102]    c1282     -1
    x[102]    c1283     1
    x[102]    c1444     -1
    x[102]    c1445     1
    x[102]    c1600     -1
    x[102]    c1601     1
    x[102]    c1750     -1
    x[102]    c1751     1
    x[102]    c1894     -1
    x[102]    c1895     1
    x[102]    c2032     -1
    x[102]    c2033     1
    x[102]    c2164     -1
    x[102]    c2165     1
    x[102]    c2290     -1
    x[102]    c2291     1
    x[102]    c2410     -1
    x[102]    c2411     1
    x[102]    c2524     -1
    x[102]    c2525     1
    x[102]    c2632     -1
    x[102]    c2633     1
    x[102]    c2734     -1
    x[102]    c2735     1
    x[102]    c2830     -1
    x[102]    c2831     1
    x[102]    c2920     -1
    x[102]    c2921     1
    x[102]    c3004     -1
    x[102]    c3005     1
    x[102]    c3082     -1
    x[102]    c3083     1
    x[102]    c3154     -1
    x[102]    c3155     1
    x[102]    c3220     -1
    x[102]    c3221     1
    x[102]    c3280     -1
    x[102]    c3281     1
    x[102]    c3334     -1
    x[102]    c3335     1
    x[102]    c3382     -1
    x[102]    c3383     1
    x[102]    c3424     -1
    x[102]    c3425     1
    x[102]    c3460     -1
    x[102]    c3461     1
    x[102]    c3490     -1
    x[102]    c3491     1
    x[102]    c3514     -1
    x[102]    c3515     1
    x[102]    c3538     1
    x[102]    c3539     -1
    x[102]    c3544     1
    x[102]    c3545     -1
    x[102]    c3550     1
    x[102]    c3551     -1
    x[103]    c190_1    -1
    x[103]    c191_1    1
    x[103]    c388      -1
    x[103]    c389      1
    x[103]    c580      -1
    x[103]    c581      1
    x[103]    c766      -1
    x[103]    c767      1
    x[103]    c946      -1
    x[103]    c947      1
    x[103]    c1120     -1
    x[103]    c1121     1
    x[103]    c1288     -1
    x[103]    c1289     1
    x[103]    c1450     -1
    x[103]    c1451     1
    x[103]    c1606     -1
    x[103]    c1607     1
    x[103]    c1756     -1
    x[103]    c1757     1
    x[103]    c1900     -1
    x[103]    c1901     1
    x[103]    c2038     -1
    x[103]    c2039     1
    x[103]    c2170     -1
    x[103]    c2171     1
    x[103]    c2296     -1
    x[103]    c2297     1
    x[103]    c2416     -1
    x[103]    c2417     1
    x[103]    c2530     -1
    x[103]    c2531     1
    x[103]    c2638     -1
    x[103]    c2639     1
    x[103]    c2740     -1
    x[103]    c2741     1
    x[103]    c2836     -1
    x[103]    c2837     1
    x[103]    c2926     -1
    x[103]    c2927     1
    x[103]    c3010     -1
    x[103]    c3011     1
    x[103]    c3088     -1
    x[103]    c3089     1
    x[103]    c3160     -1
    x[103]    c3161     1
    x[103]    c3226     -1
    x[103]    c3227     1
    x[103]    c3286     -1
    x[103]    c3287     1
    x[103]    c3340     -1
    x[103]    c3341     1
    x[103]    c3388     -1
    x[103]    c3389     1
    x[103]    c3430     -1
    x[103]    c3431     1
    x[103]    c3466     -1
    x[103]    c3467     1
    x[103]    c3496     -1
    x[103]    c3497     1
    x[103]    c3520     -1
    x[103]    c3521     1
    x[103]    c3538     -1
    x[103]    c3539     1
    x[103]    c3556     1
    x[103]    c3557     -1
    x[103]    c3562     1
    x[103]    c3563     -1
    x[104]    c196_1    -1
    x[104]    c197_1    1
    x[104]    c394      -1
    x[104]    c395      1
    x[104]    c586      -1
    x[104]    c587      1
    x[104]    c772      -1
    x[104]    c773      1
    x[104]    c952      -1
    x[104]    c953      1
    x[104]    c1126     -1
    x[104]    c1127     1
    x[104]    c1294     -1
    x[104]    c1295     1
    x[104]    c1456     -1
    x[104]    c1457     1
    x[104]    c1612     -1
    x[104]    c1613     1
    x[104]    c1762     -1
    x[104]    c1763     1
    x[104]    c1906     -1
    x[104]    c1907     1
    x[104]    c2044     -1
    x[104]    c2045     1
    x[104]    c2176     -1
    x[104]    c2177     1
    x[104]    c2302     -1
    x[104]    c2303     1
    x[104]    c2422     -1
    x[104]    c2423     1
    x[104]    c2536     -1
    x[104]    c2537     1
    x[104]    c2644     -1
    x[104]    c2645     1
    x[104]    c2746     -1
    x[104]    c2747     1
    x[104]    c2842     -1
    x[104]    c2843     1
    x[104]    c2932     -1
    x[104]    c2933     1
    x[104]    c3016     -1
    x[104]    c3017     1
    x[104]    c3094     -1
    x[104]    c3095     1
    x[104]    c3166     -1
    x[104]    c3167     1
    x[104]    c3232     -1
    x[104]    c3233     1
    x[104]    c3292     -1
    x[104]    c3293     1
    x[104]    c3346     -1
    x[104]    c3347     1
    x[104]    c3394     -1
    x[104]    c3395     1
    x[104]    c3436     -1
    x[104]    c3437     1
    x[104]    c3472     -1
    x[104]    c3473     1
    x[104]    c3502     -1
    x[104]    c3503     1
    x[104]    c3526     -1
    x[104]    c3527     1
    x[104]    c3544     -1
    x[104]    c3545     1
    x[104]    c3556     -1
    x[104]    c3557     1
    x[104]    c3568     1
    x[104]    c3569     -1
    x[105]    c202_1    -1
    x[105]    c203_1    1
    x[105]    c400      -1
    x[105]    c401      1
    x[105]    c592      -1
    x[105]    c593      1
    x[105]    c778      -1
    x[105]    c779      1
    x[105]    c958      -1
    x[105]    c959      1
    x[105]    c1132     -1
    x[105]    c1133     1
    x[105]    c1300     -1
    x[105]    c1301     1
    x[105]    c1462     -1
    x[105]    c1463     1
    x[105]    c1618     -1
    x[105]    c1619     1
    x[105]    c1768     -1
    x[105]    c1769     1
    x[105]    c1912     -1
    x[105]    c1913     1
    x[105]    c2050     -1
    x[105]    c2051     1
    x[105]    c2182     -1
    x[105]    c2183     1
    x[105]    c2308     -1
    x[105]    c2309     1
    x[105]    c2428     -1
    x[105]    c2429     1
    x[105]    c2542     -1
    x[105]    c2543     1
    x[105]    c2650     -1
    x[105]    c2651     1
    x[105]    c2752     -1
    x[105]    c2753     1
    x[105]    c2848     -1
    x[105]    c2849     1
    x[105]    c2938     -1
    x[105]    c2939     1
    x[105]    c3022     -1
    x[105]    c3023     1
    x[105]    c3100     -1
    x[105]    c3101     1
    x[105]    c3172     -1
    x[105]    c3173     1
    x[105]    c3238     -1
    x[105]    c3239     1
    x[105]    c3298     -1
    x[105]    c3299     1
    x[105]    c3352     -1
    x[105]    c3353     1
    x[105]    c3400     -1
    x[105]    c3401     1
    x[105]    c3442     -1
    x[105]    c3443     1
    x[105]    c3478     -1
    x[105]    c3479     1
    x[105]    c3508     -1
    x[105]    c3509     1
    x[105]    c3532     -1
    x[105]    c3533     1
    x[105]    c3550     -1
    x[105]    c3551     1
    x[105]    c3562     -1
    x[105]    c3563     1
    x[105]    c3568     -1
    x[105]    c3569     1
    x[106]    c2_2      1
    x[106]    c2_1      1
    x[106]    c3_1      -1
    x[106]    c8_1      1
    x[106]    c9_1      -1
    x[106]    c14_1     1
    x[106]    c15_1     -1
    x[106]    c20_1     1
    x[106]    c21_1     -1
    x[106]    c26_1     1
    x[106]    c27_1     -1
    x[106]    c32_1     1
    x[106]    c33_1     -1
    x[106]    c38_1     1
    x[106]    c39_1     -1
    x[106]    c44_1     1
    x[106]    c45_1     -1
    x[106]    c50_1     1
    x[106]    c51_1     -1
    x[106]    c56_1     1
    x[106]    c57_1     -1
    x[106]    c62_1     1
    x[106]    c63_1     -1
    x[106]    c68_1     1
    x[106]    c69_1     -1
    x[106]    c74_1     1
    x[106]    c75_1     -1
    x[106]    c80_1     1
    x[106]    c81_1     -1
    x[106]    c86_1     1
    x[106]    c87_1     -1
    x[106]    c92_1     1
    x[106]    c93_1     -1
    x[106]    c98_1     1
    x[106]    c99_1     -1
    x[106]    c104_1    1
    x[106]    c105_1    -1
    x[106]    c110_1    1
    x[106]    c111_1    -1
    x[106]    c116_1    1
    x[106]    c117_1    -1
    x[106]    c122_1    1
    x[106]    c123_1    -1
    x[106]    c128_1    1
    x[106]    c129_1    -1
    x[106]    c134_1    1
    x[106]    c135_1    -1
    x[106]    c140_1    1
    x[106]    c141_1    -1
    x[106]    c146_1    1
    x[106]    c147_1    -1
    x[106]    c152_1    1
    x[106]    c153_1    -1
    x[106]    c158_1    1
    x[106]    c159_1    -1
    x[106]    c164_1    1
    x[106]    c165_1    -1
    x[106]    c170_1    1
    x[106]    c171_1    -1
    x[106]    c176_1    1
    x[106]    c177_1    -1
    x[106]    c182_1    1
    x[106]    c183_1    -1
    x[106]    c188_1    1
    x[106]    c189_1    -1
    x[106]    c194_1    1
    x[106]    c195_1    -1
    x[106]    c200_1    1
    x[106]    c201_1    -1
    x[107]    c4_2      1
    x[107]    c2_1      -1
    x[107]    c3_1      1
    x[107]    c206_1    1
    x[107]    c207_1    -1
    x[107]    c212_1    1
    x[107]    c213_1    -1
    x[107]    c218_1    1
    x[107]    c219_1    -1
    x[107]    c224_1    1
    x[107]    c225_1    -1
    x[107]    c230_1    1
    x[107]    c231_1    -1
    x[107]    c236_1    1
    x[107]    c237_1    -1
    x[107]    c242_1    1
    x[107]    c243_1    -1
    x[107]    c248      1
    x[107]    c249      -1
    x[107]    c254      1
    x[107]    c255      -1
    x[107]    c260      1
    x[107]    c261      -1
    x[107]    c266      1
    x[107]    c267      -1
    x[107]    c272      1
    x[107]    c273      -1
    x[107]    c278      1
    x[107]    c279      -1
    x[107]    c284      1
    x[107]    c285      -1
    x[107]    c290      1
    x[107]    c291      -1
    x[107]    c296      1
    x[107]    c297      -1
    x[107]    c302      1
    x[107]    c303      -1
    x[107]    c308      1
    x[107]    c309      -1
    x[107]    c314      1
    x[107]    c315      -1
    x[107]    c320      1
    x[107]    c321      -1
    x[107]    c326      1
    x[107]    c327      -1
    x[107]    c332      1
    x[107]    c333      -1
    x[107]    c338      1
    x[107]    c339      -1
    x[107]    c344      1
    x[107]    c345      -1
    x[107]    c350      1
    x[107]    c351      -1
    x[107]    c356      1
    x[107]    c357      -1
    x[107]    c362      1
    x[107]    c363      -1
    x[107]    c368      1
    x[107]    c369      -1
    x[107]    c374      1
    x[107]    c375      -1
    x[107]    c380      1
    x[107]    c381      -1
    x[107]    c386      1
    x[107]    c387      -1
    x[107]    c392      1
    x[107]    c393      -1
    x[107]    c398      1
    x[107]    c399      -1
    x[108]    c6_2      1
    x[108]    c8_1      -1
    x[108]    c9_1      1
    x[108]    c206_1    -1
    x[108]    c207_1    1
    x[108]    c404      1
    x[108]    c405      -1
    x[108]    c410      1
    x[108]    c411      -1
    x[108]    c416      1
    x[108]    c417      -1
    x[108]    c422      1
    x[108]    c423      -1
    x[108]    c428      1
    x[108]    c429      -1
    x[108]    c434      1
    x[108]    c435      -1
    x[108]    c440      1
    x[108]    c441      -1
    x[108]    c446      1
    x[108]    c447      -1
    x[108]    c452      1
    x[108]    c453      -1
    x[108]    c458      1
    x[108]    c459      -1
    x[108]    c464      1
    x[108]    c465      -1
    x[108]    c470      1
    x[108]    c471      -1
    x[108]    c476      1
    x[108]    c477      -1
    x[108]    c482      1
    x[108]    c483      -1
    x[108]    c488      1
    x[108]    c489      -1
    x[108]    c494      1
    x[108]    c495      -1
    x[108]    c500      1
    x[108]    c501      -1
    x[108]    c506      1
    x[108]    c507      -1
    x[108]    c512      1
    x[108]    c513      -1
    x[108]    c518      1
    x[108]    c519      -1
    x[108]    c524      1
    x[108]    c525      -1
    x[108]    c530      1
    x[108]    c531      -1
    x[108]    c536      1
    x[108]    c537      -1
    x[108]    c542      1
    x[108]    c543      -1
    x[108]    c548      1
    x[108]    c549      -1
    x[108]    c554      1
    x[108]    c555      -1
    x[108]    c560      1
    x[108]    c561      -1
    x[108]    c566      1
    x[108]    c567      -1
    x[108]    c572      1
    x[108]    c573      -1
    x[108]    c578      1
    x[108]    c579      -1
    x[108]    c584      1
    x[108]    c585      -1
    x[108]    c590      1
    x[108]    c591      -1
    x[109]    c8_2      1
    x[109]    c14_1     -1
    x[109]    c15_1     1
    x[109]    c212_1    -1
    x[109]    c213_1    1
    x[109]    c404      -1
    x[109]    c405      1
    x[109]    c596      1
    x[109]    c597      -1
    x[109]    c602      1
    x[109]    c603      -1
    x[109]    c608      1
    x[109]    c609      -1
    x[109]    c614      1
    x[109]    c615      -1
    x[109]    c620      1
    x[109]    c621      -1
    x[109]    c626      1
    x[109]    c627      -1
    x[109]    c632      1
    x[109]    c633      -1
    x[109]    c638      1
    x[109]    c639      -1
    x[109]    c644      1
    x[109]    c645      -1
    x[109]    c650      1
    x[109]    c651      -1
    x[109]    c656      1
    x[109]    c657      -1
    x[109]    c662      1
    x[109]    c663      -1
    x[109]    c668      1
    x[109]    c669      -1
    x[109]    c674      1
    x[109]    c675      -1
    x[109]    c680      1
    x[109]    c681      -1
    x[109]    c686      1
    x[109]    c687      -1
    x[109]    c692      1
    x[109]    c693      -1
    x[109]    c698      1
    x[109]    c699      -1
    x[109]    c704      1
    x[109]    c705      -1
    x[109]    c710      1
    x[109]    c711      -1
    x[109]    c716      1
    x[109]    c717      -1
    x[109]    c722      1
    x[109]    c723      -1
    x[109]    c728      1
    x[109]    c729      -1
    x[109]    c734      1
    x[109]    c735      -1
    x[109]    c740      1
    x[109]    c741      -1
    x[109]    c746      1
    x[109]    c747      -1
    x[109]    c752      1
    x[109]    c753      -1
    x[109]    c758      1
    x[109]    c759      -1
    x[109]    c764      1
    x[109]    c765      -1
    x[109]    c770      1
    x[109]    c771      -1
    x[109]    c776      1
    x[109]    c777      -1
    x[110]    c10_2     1
    x[110]    c20_1     -1
    x[110]    c21_1     1
    x[110]    c218_1    -1
    x[110]    c219_1    1
    x[110]    c410      -1
    x[110]    c411      1
    x[110]    c596      -1
    x[110]    c597      1
    x[110]    c782      1
    x[110]    c783      -1
    x[110]    c788      1
    x[110]    c789      -1
    x[110]    c794      1
    x[110]    c795      -1
    x[110]    c800      1
    x[110]    c801      -1
    x[110]    c806      1
    x[110]    c807      -1
    x[110]    c812      1
    x[110]    c813      -1
    x[110]    c818      1
    x[110]    c819      -1
    x[110]    c824      1
    x[110]    c825      -1
    x[110]    c830      1
    x[110]    c831      -1
    x[110]    c836      1
    x[110]    c837      -1
    x[110]    c842      1
    x[110]    c843      -1
    x[110]    c848      1
    x[110]    c849      -1
    x[110]    c854      1
    x[110]    c855      -1
    x[110]    c860      1
    x[110]    c861      -1
    x[110]    c866      1
    x[110]    c867      -1
    x[110]    c872      1
    x[110]    c873      -1
    x[110]    c878      1
    x[110]    c879      -1
    x[110]    c884      1
    x[110]    c885      -1
    x[110]    c890      1
    x[110]    c891      -1
    x[110]    c896      1
    x[110]    c897      -1
    x[110]    c902      1
    x[110]    c903      -1
    x[110]    c908      1
    x[110]    c909      -1
    x[110]    c914      1
    x[110]    c915      -1
    x[110]    c920      1
    x[110]    c921      -1
    x[110]    c926      1
    x[110]    c927      -1
    x[110]    c932      1
    x[110]    c933      -1
    x[110]    c938      1
    x[110]    c939      -1
    x[110]    c944      1
    x[110]    c945      -1
    x[110]    c950      1
    x[110]    c951      -1
    x[110]    c956      1
    x[110]    c957      -1
    x[111]    c12_2     1
    x[111]    c26_1     -1
    x[111]    c27_1     1
    x[111]    c224_1    -1
    x[111]    c225_1    1
    x[111]    c416      -1
    x[111]    c417      1
    x[111]    c602      -1
    x[111]    c603      1
    x[111]    c782      -1
    x[111]    c783      1
    x[111]    c962      1
    x[111]    c963      -1
    x[111]    c968      1
    x[111]    c969      -1
    x[111]    c974      1
    x[111]    c975      -1
    x[111]    c980      1
    x[111]    c981      -1
    x[111]    c986      1
    x[111]    c987      -1
    x[111]    c992      1
    x[111]    c993      -1
    x[111]    c998      1
    x[111]    c999      -1
    x[111]    c1004     1
    x[111]    c1005     -1
    x[111]    c1010     1
    x[111]    c1011     -1
    x[111]    c1016     1
    x[111]    c1017     -1
    x[111]    c1022     1
    x[111]    c1023     -1
    x[111]    c1028     1
    x[111]    c1029     -1
    x[111]    c1034     1
    x[111]    c1035     -1
    x[111]    c1040     1
    x[111]    c1041     -1
    x[111]    c1046     1
    x[111]    c1047     -1
    x[111]    c1052     1
    x[111]    c1053     -1
    x[111]    c1058     1
    x[111]    c1059     -1
    x[111]    c1064     1
    x[111]    c1065     -1
    x[111]    c1070     1
    x[111]    c1071     -1
    x[111]    c1076     1
    x[111]    c1077     -1
    x[111]    c1082     1
    x[111]    c1083     -1
    x[111]    c1088     1
    x[111]    c1089     -1
    x[111]    c1094     1
    x[111]    c1095     -1
    x[111]    c1100     1
    x[111]    c1101     -1
    x[111]    c1106     1
    x[111]    c1107     -1
    x[111]    c1112     1
    x[111]    c1113     -1
    x[111]    c1118     1
    x[111]    c1119     -1
    x[111]    c1124     1
    x[111]    c1125     -1
    x[111]    c1130     1
    x[111]    c1131     -1
    x[112]    c14_2     1
    x[112]    c32_1     -1
    x[112]    c33_1     1
    x[112]    c230_1    -1
    x[112]    c231_1    1
    x[112]    c422      -1
    x[112]    c423      1
    x[112]    c608      -1
    x[112]    c609      1
    x[112]    c788      -1
    x[112]    c789      1
    x[112]    c962      -1
    x[112]    c963      1
    x[112]    c1136     1
    x[112]    c1137     -1
    x[112]    c1142     1
    x[112]    c1143     -1
    x[112]    c1148     1
    x[112]    c1149     -1
    x[112]    c1154     1
    x[112]    c1155     -1
    x[112]    c1160     1
    x[112]    c1161     -1
    x[112]    c1166     1
    x[112]    c1167     -1
    x[112]    c1172     1
    x[112]    c1173     -1
    x[112]    c1178     1
    x[112]    c1179     -1
    x[112]    c1184     1
    x[112]    c1185     -1
    x[112]    c1190     1
    x[112]    c1191     -1
    x[112]    c1196     1
    x[112]    c1197     -1
    x[112]    c1202     1
    x[112]    c1203     -1
    x[112]    c1208     1
    x[112]    c1209     -1
    x[112]    c1214     1
    x[112]    c1215     -1
    x[112]    c1220     1
    x[112]    c1221     -1
    x[112]    c1226     1
    x[112]    c1227     -1
    x[112]    c1232     1
    x[112]    c1233     -1
    x[112]    c1238     1
    x[112]    c1239     -1
    x[112]    c1244     1
    x[112]    c1245     -1
    x[112]    c1250     1
    x[112]    c1251     -1
    x[112]    c1256     1
    x[112]    c1257     -1
    x[112]    c1262     1
    x[112]    c1263     -1
    x[112]    c1268     1
    x[112]    c1269     -1
    x[112]    c1274     1
    x[112]    c1275     -1
    x[112]    c1280     1
    x[112]    c1281     -1
    x[112]    c1286     1
    x[112]    c1287     -1
    x[112]    c1292     1
    x[112]    c1293     -1
    x[112]    c1298     1
    x[112]    c1299     -1
    x[113]    c16_2     1
    x[113]    c38_1     -1
    x[113]    c39_1     1
    x[113]    c236_1    -1
    x[113]    c237_1    1
    x[113]    c428      -1
    x[113]    c429      1
    x[113]    c614      -1
    x[113]    c615      1
    x[113]    c794      -1
    x[113]    c795      1
    x[113]    c968      -1
    x[113]    c969      1
    x[113]    c1136     -1
    x[113]    c1137     1
    x[113]    c1304     1
    x[113]    c1305     -1
    x[113]    c1310     1
    x[113]    c1311     -1
    x[113]    c1316     1
    x[113]    c1317     -1
    x[113]    c1322     1
    x[113]    c1323     -1
    x[113]    c1328     1
    x[113]    c1329     -1
    x[113]    c1334     1
    x[113]    c1335     -1
    x[113]    c1340     1
    x[113]    c1341     -1
    x[113]    c1346     1
    x[113]    c1347     -1
    x[113]    c1352     1
    x[113]    c1353     -1
    x[113]    c1358     1
    x[113]    c1359     -1
    x[113]    c1364     1
    x[113]    c1365     -1
    x[113]    c1370     1
    x[113]    c1371     -1
    x[113]    c1376     1
    x[113]    c1377     -1
    x[113]    c1382     1
    x[113]    c1383     -1
    x[113]    c1388     1
    x[113]    c1389     -1
    x[113]    c1394     1
    x[113]    c1395     -1
    x[113]    c1400     1
    x[113]    c1401     -1
    x[113]    c1406     1
    x[113]    c1407     -1
    x[113]    c1412     1
    x[113]    c1413     -1
    x[113]    c1418     1
    x[113]    c1419     -1
    x[113]    c1424     1
    x[113]    c1425     -1
    x[113]    c1430     1
    x[113]    c1431     -1
    x[113]    c1436     1
    x[113]    c1437     -1
    x[113]    c1442     1
    x[113]    c1443     -1
    x[113]    c1448     1
    x[113]    c1449     -1
    x[113]    c1454     1
    x[113]    c1455     -1
    x[113]    c1460     1
    x[113]    c1461     -1
    x[114]    c18_2     1
    x[114]    c44_1     -1
    x[114]    c45_1     1
    x[114]    c242_1    -1
    x[114]    c243_1    1
    x[114]    c434      -1
    x[114]    c435      1
    x[114]    c620      -1
    x[114]    c621      1
    x[114]    c800      -1
    x[114]    c801      1
    x[114]    c974      -1
    x[114]    c975      1
    x[114]    c1142     -1
    x[114]    c1143     1
    x[114]    c1304     -1
    x[114]    c1305     1
    x[114]    c1466     1
    x[114]    c1467     -1
    x[114]    c1472     1
    x[114]    c1473     -1
    x[114]    c1478     1
    x[114]    c1479     -1
    x[114]    c1484     1
    x[114]    c1485     -1
    x[114]    c1490     1
    x[114]    c1491     -1
    x[114]    c1496     1
    x[114]    c1497     -1
    x[114]    c1502     1
    x[114]    c1503     -1
    x[114]    c1508     1
    x[114]    c1509     -1
    x[114]    c1514     1
    x[114]    c1515     -1
    x[114]    c1520     1
    x[114]    c1521     -1
    x[114]    c1526     1
    x[114]    c1527     -1
    x[114]    c1532     1
    x[114]    c1533     -1
    x[114]    c1538     1
    x[114]    c1539     -1
    x[114]    c1544     1
    x[114]    c1545     -1
    x[114]    c1550     1
    x[114]    c1551     -1
    x[114]    c1556     1
    x[114]    c1557     -1
    x[114]    c1562     1
    x[114]    c1563     -1
    x[114]    c1568     1
    x[114]    c1569     -1
    x[114]    c1574     1
    x[114]    c1575     -1
    x[114]    c1580     1
    x[114]    c1581     -1
    x[114]    c1586     1
    x[114]    c1587     -1
    x[114]    c1592     1
    x[114]    c1593     -1
    x[114]    c1598     1
    x[114]    c1599     -1
    x[114]    c1604     1
    x[114]    c1605     -1
    x[114]    c1610     1
    x[114]    c1611     -1
    x[114]    c1616     1
    x[114]    c1617     -1
    x[115]    c20_2     1
    x[115]    c50_1     -1
    x[115]    c51_1     1
    x[115]    c248      -1
    x[115]    c249      1
    x[115]    c440      -1
    x[115]    c441      1
    x[115]    c626      -1
    x[115]    c627      1
    x[115]    c806      -1
    x[115]    c807      1
    x[115]    c980      -1
    x[115]    c981      1
    x[115]    c1148     -1
    x[115]    c1149     1
    x[115]    c1310     -1
    x[115]    c1311     1
    x[115]    c1466     -1
    x[115]    c1467     1
    x[115]    c1622     1
    x[115]    c1623     -1
    x[115]    c1628     1
    x[115]    c1629     -1
    x[115]    c1634     1
    x[115]    c1635     -1
    x[115]    c1640     1
    x[115]    c1641     -1
    x[115]    c1646     1
    x[115]    c1647     -1
    x[115]    c1652     1
    x[115]    c1653     -1
    x[115]    c1658     1
    x[115]    c1659     -1
    x[115]    c1664     1
    x[115]    c1665     -1
    x[115]    c1670     1
    x[115]    c1671     -1
    x[115]    c1676     1
    x[115]    c1677     -1
    x[115]    c1682     1
    x[115]    c1683     -1
    x[115]    c1688     1
    x[115]    c1689     -1
    x[115]    c1694     1
    x[115]    c1695     -1
    x[115]    c1700     1
    x[115]    c1701     -1
    x[115]    c1706     1
    x[115]    c1707     -1
    x[115]    c1712     1
    x[115]    c1713     -1
    x[115]    c1718     1
    x[115]    c1719     -1
    x[115]    c1724     1
    x[115]    c1725     -1
    x[115]    c1730     1
    x[115]    c1731     -1
    x[115]    c1736     1
    x[115]    c1737     -1
    x[115]    c1742     1
    x[115]    c1743     -1
    x[115]    c1748     1
    x[115]    c1749     -1
    x[115]    c1754     1
    x[115]    c1755     -1
    x[115]    c1760     1
    x[115]    c1761     -1
    x[115]    c1766     1
    x[115]    c1767     -1
    x[116]    c22_2     1
    x[116]    c56_1     -1
    x[116]    c57_1     1
    x[116]    c254      -1
    x[116]    c255      1
    x[116]    c446      -1
    x[116]    c447      1
    x[116]    c632      -1
    x[116]    c633      1
    x[116]    c812      -1
    x[116]    c813      1
    x[116]    c986      -1
    x[116]    c987      1
    x[116]    c1154     -1
    x[116]    c1155     1
    x[116]    c1316     -1
    x[116]    c1317     1
    x[116]    c1472     -1
    x[116]    c1473     1
    x[116]    c1622     -1
    x[116]    c1623     1
    x[116]    c1772     1
    x[116]    c1773     -1
    x[116]    c1778     1
    x[116]    c1779     -1
    x[116]    c1784     1
    x[116]    c1785     -1
    x[116]    c1790     1
    x[116]    c1791     -1
    x[116]    c1796     1
    x[116]    c1797     -1
    x[116]    c1802     1
    x[116]    c1803     -1
    x[116]    c1808     1
    x[116]    c1809     -1
    x[116]    c1814     1
    x[116]    c1815     -1
    x[116]    c1820     1
    x[116]    c1821     -1
    x[116]    c1826     1
    x[116]    c1827     -1
    x[116]    c1832     1
    x[116]    c1833     -1
    x[116]    c1838     1
    x[116]    c1839     -1
    x[116]    c1844     1
    x[116]    c1845     -1
    x[116]    c1850     1
    x[116]    c1851     -1
    x[116]    c1856     1
    x[116]    c1857     -1
    x[116]    c1862     1
    x[116]    c1863     -1
    x[116]    c1868     1
    x[116]    c1869     -1
    x[116]    c1874     1
    x[116]    c1875     -1
    x[116]    c1880     1
    x[116]    c1881     -1
    x[116]    c1886     1
    x[116]    c1887     -1
    x[116]    c1892     1
    x[116]    c1893     -1
    x[116]    c1898     1
    x[116]    c1899     -1
    x[116]    c1904     1
    x[116]    c1905     -1
    x[116]    c1910     1
    x[116]    c1911     -1
    x[117]    c24_2     1
    x[117]    c62_1     -1
    x[117]    c63_1     1
    x[117]    c260      -1
    x[117]    c261      1
    x[117]    c452      -1
    x[117]    c453      1
    x[117]    c638      -1
    x[117]    c639      1
    x[117]    c818      -1
    x[117]    c819      1
    x[117]    c992      -1
    x[117]    c993      1
    x[117]    c1160     -1
    x[117]    c1161     1
    x[117]    c1322     -1
    x[117]    c1323     1
    x[117]    c1478     -1
    x[117]    c1479     1
    x[117]    c1628     -1
    x[117]    c1629     1
    x[117]    c1772     -1
    x[117]    c1773     1
    x[117]    c1916     1
    x[117]    c1917     -1
    x[117]    c1922     1
    x[117]    c1923     -1
    x[117]    c1928     1
    x[117]    c1929     -1
    x[117]    c1934     1
    x[117]    c1935     -1
    x[117]    c1940     1
    x[117]    c1941     -1
    x[117]    c1946     1
    x[117]    c1947     -1
    x[117]    c1952     1
    x[117]    c1953     -1
    x[117]    c1958     1
    x[117]    c1959     -1
    x[117]    c1964     1
    x[117]    c1965     -1
    x[117]    c1970     1
    x[117]    c1971     -1
    x[117]    c1976     1
    x[117]    c1977     -1
    x[117]    c1982     1
    x[117]    c1983     -1
    x[117]    c1988     1
    x[117]    c1989     -1
    x[117]    c1994     1
    x[117]    c1995     -1
    x[117]    c2000     1
    x[117]    c2001     -1
    x[117]    c2006     1
    x[117]    c2007     -1
    x[117]    c2012     1
    x[117]    c2013     -1
    x[117]    c2018     1
    x[117]    c2019     -1
    x[117]    c2024     1
    x[117]    c2025     -1
    x[117]    c2030     1
    x[117]    c2031     -1
    x[117]    c2036     1
    x[117]    c2037     -1
    x[117]    c2042     1
    x[117]    c2043     -1
    x[117]    c2048     1
    x[117]    c2049     -1
    x[118]    c26_2     1
    x[118]    c68_1     -1
    x[118]    c69_1     1
    x[118]    c266      -1
    x[118]    c267      1
    x[118]    c458      -1
    x[118]    c459      1
    x[118]    c644      -1
    x[118]    c645      1
    x[118]    c824      -1
    x[118]    c825      1
    x[118]    c998      -1
    x[118]    c999      1
    x[118]    c1166     -1
    x[118]    c1167     1
    x[118]    c1328     -1
    x[118]    c1329     1
    x[118]    c1484     -1
    x[118]    c1485     1
    x[118]    c1634     -1
    x[118]    c1635     1
    x[118]    c1778     -1
    x[118]    c1779     1
    x[118]    c1916     -1
    x[118]    c1917     1
    x[118]    c2054     1
    x[118]    c2055     -1
    x[118]    c2060     1
    x[118]    c2061     -1
    x[118]    c2066     1
    x[118]    c2067     -1
    x[118]    c2072     1
    x[118]    c2073     -1
    x[118]    c2078     1
    x[118]    c2079     -1
    x[118]    c2084     1
    x[118]    c2085     -1
    x[118]    c2090     1
    x[118]    c2091     -1
    x[118]    c2096     1
    x[118]    c2097     -1
    x[118]    c2102     1
    x[118]    c2103     -1
    x[118]    c2108     1
    x[118]    c2109     -1
    x[118]    c2114     1
    x[118]    c2115     -1
    x[118]    c2120     1
    x[118]    c2121     -1
    x[118]    c2126     1
    x[118]    c2127     -1
    x[118]    c2132     1
    x[118]    c2133     -1
    x[118]    c2138     1
    x[118]    c2139     -1
    x[118]    c2144     1
    x[118]    c2145     -1
    x[118]    c2150     1
    x[118]    c2151     -1
    x[118]    c2156     1
    x[118]    c2157     -1
    x[118]    c2162     1
    x[118]    c2163     -1
    x[118]    c2168     1
    x[118]    c2169     -1
    x[118]    c2174     1
    x[118]    c2175     -1
    x[118]    c2180     1
    x[118]    c2181     -1
    x[119]    c28_2     1
    x[119]    c74_1     -1
    x[119]    c75_1     1
    x[119]    c272      -1
    x[119]    c273      1
    x[119]    c464      -1
    x[119]    c465      1
    x[119]    c650      -1
    x[119]    c651      1
    x[119]    c830      -1
    x[119]    c831      1
    x[119]    c1004     -1
    x[119]    c1005     1
    x[119]    c1172     -1
    x[119]    c1173     1
    x[119]    c1334     -1
    x[119]    c1335     1
    x[119]    c1490     -1
    x[119]    c1491     1
    x[119]    c1640     -1
    x[119]    c1641     1
    x[119]    c1784     -1
    x[119]    c1785     1
    x[119]    c1922     -1
    x[119]    c1923     1
    x[119]    c2054     -1
    x[119]    c2055     1
    x[119]    c2186     1
    x[119]    c2187     -1
    x[119]    c2192     1
    x[119]    c2193     -1
    x[119]    c2198     1
    x[119]    c2199     -1
    x[119]    c2204     1
    x[119]    c2205     -1
    x[119]    c2210     1
    x[119]    c2211     -1
    x[119]    c2216     1
    x[119]    c2217     -1
    x[119]    c2222     1
    x[119]    c2223     -1
    x[119]    c2228     1
    x[119]    c2229     -1
    x[119]    c2234     1
    x[119]    c2235     -1
    x[119]    c2240     1
    x[119]    c2241     -1
    x[119]    c2246     1
    x[119]    c2247     -1
    x[119]    c2252     1
    x[119]    c2253     -1
    x[119]    c2258     1
    x[119]    c2259     -1
    x[119]    c2264     1
    x[119]    c2265     -1
    x[119]    c2270     1
    x[119]    c2271     -1
    x[119]    c2276     1
    x[119]    c2277     -1
    x[119]    c2282     1
    x[119]    c2283     -1
    x[119]    c2288     1
    x[119]    c2289     -1
    x[119]    c2294     1
    x[119]    c2295     -1
    x[119]    c2300     1
    x[119]    c2301     -1
    x[119]    c2306     1
    x[119]    c2307     -1
    x[120]    c30_2     1
    x[120]    c80_1     -1
    x[120]    c81_1     1
    x[120]    c278      -1
    x[120]    c279      1
    x[120]    c470      -1
    x[120]    c471      1
    x[120]    c656      -1
    x[120]    c657      1
    x[120]    c836      -1
    x[120]    c837      1
    x[120]    c1010     -1
    x[120]    c1011     1
    x[120]    c1178     -1
    x[120]    c1179     1
    x[120]    c1340     -1
    x[120]    c1341     1
    x[120]    c1496     -1
    x[120]    c1497     1
    x[120]    c1646     -1
    x[120]    c1647     1
    x[120]    c1790     -1
    x[120]    c1791     1
    x[120]    c1928     -1
    x[120]    c1929     1
    x[120]    c2060     -1
    x[120]    c2061     1
    x[120]    c2186     -1
    x[120]    c2187     1
    x[120]    c2312     1
    x[120]    c2313     -1
    x[120]    c2318     1
    x[120]    c2319     -1
    x[120]    c2324     1
    x[120]    c2325     -1
    x[120]    c2330     1
    x[120]    c2331     -1
    x[120]    c2336     1
    x[120]    c2337     -1
    x[120]    c2342     1
    x[120]    c2343     -1
    x[120]    c2348     1
    x[120]    c2349     -1
    x[120]    c2354     1
    x[120]    c2355     -1
    x[120]    c2360     1
    x[120]    c2361     -1
    x[120]    c2366     1
    x[120]    c2367     -1
    x[120]    c2372     1
    x[120]    c2373     -1
    x[120]    c2378     1
    x[120]    c2379     -1
    x[120]    c2384     1
    x[120]    c2385     -1
    x[120]    c2390     1
    x[120]    c2391     -1
    x[120]    c2396     1
    x[120]    c2397     -1
    x[120]    c2402     1
    x[120]    c2403     -1
    x[120]    c2408     1
    x[120]    c2409     -1
    x[120]    c2414     1
    x[120]    c2415     -1
    x[120]    c2420     1
    x[120]    c2421     -1
    x[120]    c2426     1
    x[120]    c2427     -1
    x[121]    c32_2     1
    x[121]    c86_1     -1
    x[121]    c87_1     1
    x[121]    c284      -1
    x[121]    c285      1
    x[121]    c476      -1
    x[121]    c477      1
    x[121]    c662      -1
    x[121]    c663      1
    x[121]    c842      -1
    x[121]    c843      1
    x[121]    c1016     -1
    x[121]    c1017     1
    x[121]    c1184     -1
    x[121]    c1185     1
    x[121]    c1346     -1
    x[121]    c1347     1
    x[121]    c1502     -1
    x[121]    c1503     1
    x[121]    c1652     -1
    x[121]    c1653     1
    x[121]    c1796     -1
    x[121]    c1797     1
    x[121]    c1934     -1
    x[121]    c1935     1
    x[121]    c2066     -1
    x[121]    c2067     1
    x[121]    c2192     -1
    x[121]    c2193     1
    x[121]    c2312     -1
    x[121]    c2313     1
    x[121]    c2432     1
    x[121]    c2433     -1
    x[121]    c2438     1
    x[121]    c2439     -1
    x[121]    c2444     1
    x[121]    c2445     -1
    x[121]    c2450     1
    x[121]    c2451     -1
    x[121]    c2456     1
    x[121]    c2457     -1
    x[121]    c2462     1
    x[121]    c2463     -1
    x[121]    c2468     1
    x[121]    c2469     -1
    x[121]    c2474     1
    x[121]    c2475     -1
    x[121]    c2480     1
    x[121]    c2481     -1
    x[121]    c2486     1
    x[121]    c2487     -1
    x[121]    c2492     1
    x[121]    c2493     -1
    x[121]    c2498     1
    x[121]    c2499     -1
    x[121]    c2504     1
    x[121]    c2505     -1
    x[121]    c2510     1
    x[121]    c2511     -1
    x[121]    c2516     1
    x[121]    c2517     -1
    x[121]    c2522     1
    x[121]    c2523     -1
    x[121]    c2528     1
    x[121]    c2529     -1
    x[121]    c2534     1
    x[121]    c2535     -1
    x[121]    c2540     1
    x[121]    c2541     -1
    x[122]    c34_2     1
    x[122]    c92_1     -1
    x[122]    c93_1     1
    x[122]    c290      -1
    x[122]    c291      1
    x[122]    c482      -1
    x[122]    c483      1
    x[122]    c668      -1
    x[122]    c669      1
    x[122]    c848      -1
    x[122]    c849      1
    x[122]    c1022     -1
    x[122]    c1023     1
    x[122]    c1190     -1
    x[122]    c1191     1
    x[122]    c1352     -1
    x[122]    c1353     1
    x[122]    c1508     -1
    x[122]    c1509     1
    x[122]    c1658     -1
    x[122]    c1659     1
    x[122]    c1802     -1
    x[122]    c1803     1
    x[122]    c1940     -1
    x[122]    c1941     1
    x[122]    c2072     -1
    x[122]    c2073     1
    x[122]    c2198     -1
    x[122]    c2199     1
    x[122]    c2318     -1
    x[122]    c2319     1
    x[122]    c2432     -1
    x[122]    c2433     1
    x[122]    c2546     1
    x[122]    c2547     -1
    x[122]    c2552     1
    x[122]    c2553     -1
    x[122]    c2558     1
    x[122]    c2559     -1
    x[122]    c2564     1
    x[122]    c2565     -1
    x[122]    c2570     1
    x[122]    c2571     -1
    x[122]    c2576     1
    x[122]    c2577     -1
    x[122]    c2582     1
    x[122]    c2583     -1
    x[122]    c2588     1
    x[122]    c2589     -1
    x[122]    c2594     1
    x[122]    c2595     -1
    x[122]    c2600     1
    x[122]    c2601     -1
    x[122]    c2606     1
    x[122]    c2607     -1
    x[122]    c2612     1
    x[122]    c2613     -1
    x[122]    c2618     1
    x[122]    c2619     -1
    x[122]    c2624     1
    x[122]    c2625     -1
    x[122]    c2630     1
    x[122]    c2631     -1
    x[122]    c2636     1
    x[122]    c2637     -1
    x[122]    c2642     1
    x[122]    c2643     -1
    x[122]    c2648     1
    x[122]    c2649     -1
    x[123]    c36_2     1
    x[123]    c98_1     -1
    x[123]    c99_1     1
    x[123]    c296      -1
    x[123]    c297      1
    x[123]    c488      -1
    x[123]    c489      1
    x[123]    c674      -1
    x[123]    c675      1
    x[123]    c854      -1
    x[123]    c855      1
    x[123]    c1028     -1
    x[123]    c1029     1
    x[123]    c1196     -1
    x[123]    c1197     1
    x[123]    c1358     -1
    x[123]    c1359     1
    x[123]    c1514     -1
    x[123]    c1515     1
    x[123]    c1664     -1
    x[123]    c1665     1
    x[123]    c1808     -1
    x[123]    c1809     1
    x[123]    c1946     -1
    x[123]    c1947     1
    x[123]    c2078     -1
    x[123]    c2079     1
    x[123]    c2204     -1
    x[123]    c2205     1
    x[123]    c2324     -1
    x[123]    c2325     1
    x[123]    c2438     -1
    x[123]    c2439     1
    x[123]    c2546     -1
    x[123]    c2547     1
    x[123]    c2654     1
    x[123]    c2655     -1
    x[123]    c2660     1
    x[123]    c2661     -1
    x[123]    c2666     1
    x[123]    c2667     -1
    x[123]    c2672     1
    x[123]    c2673     -1
    x[123]    c2678     1
    x[123]    c2679     -1
    x[123]    c2684     1
    x[123]    c2685     -1
    x[123]    c2690     1
    x[123]    c2691     -1
    x[123]    c2696     1
    x[123]    c2697     -1
    x[123]    c2702     1
    x[123]    c2703     -1
    x[123]    c2708     1
    x[123]    c2709     -1
    x[123]    c2714     1
    x[123]    c2715     -1
    x[123]    c2720     1
    x[123]    c2721     -1
    x[123]    c2726     1
    x[123]    c2727     -1
    x[123]    c2732     1
    x[123]    c2733     -1
    x[123]    c2738     1
    x[123]    c2739     -1
    x[123]    c2744     1
    x[123]    c2745     -1
    x[123]    c2750     1
    x[123]    c2751     -1
    x[124]    c38_2     1
    x[124]    c104_1    -1
    x[124]    c105_1    1
    x[124]    c302      -1
    x[124]    c303      1
    x[124]    c494      -1
    x[124]    c495      1
    x[124]    c680      -1
    x[124]    c681      1
    x[124]    c860      -1
    x[124]    c861      1
    x[124]    c1034     -1
    x[124]    c1035     1
    x[124]    c1202     -1
    x[124]    c1203     1
    x[124]    c1364     -1
    x[124]    c1365     1
    x[124]    c1520     -1
    x[124]    c1521     1
    x[124]    c1670     -1
    x[124]    c1671     1
    x[124]    c1814     -1
    x[124]    c1815     1
    x[124]    c1952     -1
    x[124]    c1953     1
    x[124]    c2084     -1
    x[124]    c2085     1
    x[124]    c2210     -1
    x[124]    c2211     1
    x[124]    c2330     -1
    x[124]    c2331     1
    x[124]    c2444     -1
    x[124]    c2445     1
    x[124]    c2552     -1
    x[124]    c2553     1
    x[124]    c2654     -1
    x[124]    c2655     1
    x[124]    c2756     1
    x[124]    c2757     -1
    x[124]    c2762     1
    x[124]    c2763     -1
    x[124]    c2768     1
    x[124]    c2769     -1
    x[124]    c2774     1
    x[124]    c2775     -1
    x[124]    c2780     1
    x[124]    c2781     -1
    x[124]    c2786     1
    x[124]    c2787     -1
    x[124]    c2792     1
    x[124]    c2793     -1
    x[124]    c2798     1
    x[124]    c2799     -1
    x[124]    c2804     1
    x[124]    c2805     -1
    x[124]    c2810     1
    x[124]    c2811     -1
    x[124]    c2816     1
    x[124]    c2817     -1
    x[124]    c2822     1
    x[124]    c2823     -1
    x[124]    c2828     1
    x[124]    c2829     -1
    x[124]    c2834     1
    x[124]    c2835     -1
    x[124]    c2840     1
    x[124]    c2841     -1
    x[124]    c2846     1
    x[124]    c2847     -1
    x[125]    c40_2     1
    x[125]    c110_1    -1
    x[125]    c111_1    1
    x[125]    c308      -1
    x[125]    c309      1
    x[125]    c500      -1
    x[125]    c501      1
    x[125]    c686      -1
    x[125]    c687      1
    x[125]    c866      -1
    x[125]    c867      1
    x[125]    c1040     -1
    x[125]    c1041     1
    x[125]    c1208     -1
    x[125]    c1209     1
    x[125]    c1370     -1
    x[125]    c1371     1
    x[125]    c1526     -1
    x[125]    c1527     1
    x[125]    c1676     -1
    x[125]    c1677     1
    x[125]    c1820     -1
    x[125]    c1821     1
    x[125]    c1958     -1
    x[125]    c1959     1
    x[125]    c2090     -1
    x[125]    c2091     1
    x[125]    c2216     -1
    x[125]    c2217     1
    x[125]    c2336     -1
    x[125]    c2337     1
    x[125]    c2450     -1
    x[125]    c2451     1
    x[125]    c2558     -1
    x[125]    c2559     1
    x[125]    c2660     -1
    x[125]    c2661     1
    x[125]    c2756     -1
    x[125]    c2757     1
    x[125]    c2852     1
    x[125]    c2853     -1
    x[125]    c2858     1
    x[125]    c2859     -1
    x[125]    c2864     1
    x[125]    c2865     -1
    x[125]    c2870     1
    x[125]    c2871     -1
    x[125]    c2876     1
    x[125]    c2877     -1
    x[125]    c2882     1
    x[125]    c2883     -1
    x[125]    c2888     1
    x[125]    c2889     -1
    x[125]    c2894     1
    x[125]    c2895     -1
    x[125]    c2900     1
    x[125]    c2901     -1
    x[125]    c2906     1
    x[125]    c2907     -1
    x[125]    c2912     1
    x[125]    c2913     -1
    x[125]    c2918     1
    x[125]    c2919     -1
    x[125]    c2924     1
    x[125]    c2925     -1
    x[125]    c2930     1
    x[125]    c2931     -1
    x[125]    c2936     1
    x[125]    c2937     -1
    x[126]    c42_2     1
    x[126]    c116_1    -1
    x[126]    c117_1    1
    x[126]    c314      -1
    x[126]    c315      1
    x[126]    c506      -1
    x[126]    c507      1
    x[126]    c692      -1
    x[126]    c693      1
    x[126]    c872      -1
    x[126]    c873      1
    x[126]    c1046     -1
    x[126]    c1047     1
    x[126]    c1214     -1
    x[126]    c1215     1
    x[126]    c1376     -1
    x[126]    c1377     1
    x[126]    c1532     -1
    x[126]    c1533     1
    x[126]    c1682     -1
    x[126]    c1683     1
    x[126]    c1826     -1
    x[126]    c1827     1
    x[126]    c1964     -1
    x[126]    c1965     1
    x[126]    c2096     -1
    x[126]    c2097     1
    x[126]    c2222     -1
    x[126]    c2223     1
    x[126]    c2342     -1
    x[126]    c2343     1
    x[126]    c2456     -1
    x[126]    c2457     1
    x[126]    c2564     -1
    x[126]    c2565     1
    x[126]    c2666     -1
    x[126]    c2667     1
    x[126]    c2762     -1
    x[126]    c2763     1
    x[126]    c2852     -1
    x[126]    c2853     1
    x[126]    c2942     1
    x[126]    c2943     -1
    x[126]    c2948     1
    x[126]    c2949     -1
    x[126]    c2954     1
    x[126]    c2955     -1
    x[126]    c2960     1
    x[126]    c2961     -1
    x[126]    c2966     1
    x[126]    c2967     -1
    x[126]    c2972     1
    x[126]    c2973     -1
    x[126]    c2978     1
    x[126]    c2979     -1
    x[126]    c2984     1
    x[126]    c2985     -1
    x[126]    c2990     1
    x[126]    c2991     -1
    x[126]    c2996     1
    x[126]    c2997     -1
    x[126]    c3002     1
    x[126]    c3003     -1
    x[126]    c3008     1
    x[126]    c3009     -1
    x[126]    c3014     1
    x[126]    c3015     -1
    x[126]    c3020     1
    x[126]    c3021     -1
    x[127]    c44_2     1
    x[127]    c122_1    -1
    x[127]    c123_1    1
    x[127]    c320      -1
    x[127]    c321      1
    x[127]    c512      -1
    x[127]    c513      1
    x[127]    c698      -1
    x[127]    c699      1
    x[127]    c878      -1
    x[127]    c879      1
    x[127]    c1052     -1
    x[127]    c1053     1
    x[127]    c1220     -1
    x[127]    c1221     1
    x[127]    c1382     -1
    x[127]    c1383     1
    x[127]    c1538     -1
    x[127]    c1539     1
    x[127]    c1688     -1
    x[127]    c1689     1
    x[127]    c1832     -1
    x[127]    c1833     1
    x[127]    c1970     -1
    x[127]    c1971     1
    x[127]    c2102     -1
    x[127]    c2103     1
    x[127]    c2228     -1
    x[127]    c2229     1
    x[127]    c2348     -1
    x[127]    c2349     1
    x[127]    c2462     -1
    x[127]    c2463     1
    x[127]    c2570     -1
    x[127]    c2571     1
    x[127]    c2672     -1
    x[127]    c2673     1
    x[127]    c2768     -1
    x[127]    c2769     1
    x[127]    c2858     -1
    x[127]    c2859     1
    x[127]    c2942     -1
    x[127]    c2943     1
    x[127]    c3026     1
    x[127]    c3027     -1
    x[127]    c3032     1
    x[127]    c3033     -1
    x[127]    c3038     1
    x[127]    c3039     -1
    x[127]    c3044     1
    x[127]    c3045     -1
    x[127]    c3050     1
    x[127]    c3051     -1
    x[127]    c3056     1
    x[127]    c3057     -1
    x[127]    c3062     1
    x[127]    c3063     -1
    x[127]    c3068     1
    x[127]    c3069     -1
    x[127]    c3074     1
    x[127]    c3075     -1
    x[127]    c3080     1
    x[127]    c3081     -1
    x[127]    c3086     1
    x[127]    c3087     -1
    x[127]    c3092     1
    x[127]    c3093     -1
    x[127]    c3098     1
    x[127]    c3099     -1
    x[128]    c46_2     1
    x[128]    c128_1    -1
    x[128]    c129_1    1
    x[128]    c326      -1
    x[128]    c327      1
    x[128]    c518      -1
    x[128]    c519      1
    x[128]    c704      -1
    x[128]    c705      1
    x[128]    c884      -1
    x[128]    c885      1
    x[128]    c1058     -1
    x[128]    c1059     1
    x[128]    c1226     -1
    x[128]    c1227     1
    x[128]    c1388     -1
    x[128]    c1389     1
    x[128]    c1544     -1
    x[128]    c1545     1
    x[128]    c1694     -1
    x[128]    c1695     1
    x[128]    c1838     -1
    x[128]    c1839     1
    x[128]    c1976     -1
    x[128]    c1977     1
    x[128]    c2108     -1
    x[128]    c2109     1
    x[128]    c2234     -1
    x[128]    c2235     1
    x[128]    c2354     -1
    x[128]    c2355     1
    x[128]    c2468     -1
    x[128]    c2469     1
    x[128]    c2576     -1
    x[128]    c2577     1
    x[128]    c2678     -1
    x[128]    c2679     1
    x[128]    c2774     -1
    x[128]    c2775     1
    x[128]    c2864     -1
    x[128]    c2865     1
    x[128]    c2948     -1
    x[128]    c2949     1
    x[128]    c3026     -1
    x[128]    c3027     1
    x[128]    c3104     1
    x[128]    c3105     -1
    x[128]    c3110     1
    x[128]    c3111     -1
    x[128]    c3116     1
    x[128]    c3117     -1
    x[128]    c3122     1
    x[128]    c3123     -1
    x[128]    c3128     1
    x[128]    c3129     -1
    x[128]    c3134     1
    x[128]    c3135     -1
    x[128]    c3140     1
    x[128]    c3141     -1
    x[128]    c3146     1
    x[128]    c3147     -1
    x[128]    c3152     1
    x[128]    c3153     -1
    x[128]    c3158     1
    x[128]    c3159     -1
    x[128]    c3164     1
    x[128]    c3165     -1
    x[128]    c3170     1
    x[128]    c3171     -1
    x[129]    c48_2     1
    x[129]    c134_1    -1
    x[129]    c135_1    1
    x[129]    c332      -1
    x[129]    c333      1
    x[129]    c524      -1
    x[129]    c525      1
    x[129]    c710      -1
    x[129]    c711      1
    x[129]    c890      -1
    x[129]    c891      1
    x[129]    c1064     -1
    x[129]    c1065     1
    x[129]    c1232     -1
    x[129]    c1233     1
    x[129]    c1394     -1
    x[129]    c1395     1
    x[129]    c1550     -1
    x[129]    c1551     1
    x[129]    c1700     -1
    x[129]    c1701     1
    x[129]    c1844     -1
    x[129]    c1845     1
    x[129]    c1982     -1
    x[129]    c1983     1
    x[129]    c2114     -1
    x[129]    c2115     1
    x[129]    c2240     -1
    x[129]    c2241     1
    x[129]    c2360     -1
    x[129]    c2361     1
    x[129]    c2474     -1
    x[129]    c2475     1
    x[129]    c2582     -1
    x[129]    c2583     1
    x[129]    c2684     -1
    x[129]    c2685     1
    x[129]    c2780     -1
    x[129]    c2781     1
    x[129]    c2870     -1
    x[129]    c2871     1
    x[129]    c2954     -1
    x[129]    c2955     1
    x[129]    c3032     -1
    x[129]    c3033     1
    x[129]    c3104     -1
    x[129]    c3105     1
    x[129]    c3176     1
    x[129]    c3177     -1
    x[129]    c3182     1
    x[129]    c3183     -1
    x[129]    c3188     1
    x[129]    c3189     -1
    x[129]    c3194     1
    x[129]    c3195     -1
    x[129]    c3200     1
    x[129]    c3201     -1
    x[129]    c3206     1
    x[129]    c3207     -1
    x[129]    c3212     1
    x[129]    c3213     -1
    x[129]    c3218     1
    x[129]    c3219     -1
    x[129]    c3224     1
    x[129]    c3225     -1
    x[129]    c3230     1
    x[129]    c3231     -1
    x[129]    c3236     1
    x[129]    c3237     -1
    x[130]    c50_2     1
    x[130]    c140_1    -1
    x[130]    c141_1    1
    x[130]    c338      -1
    x[130]    c339      1
    x[130]    c530      -1
    x[130]    c531      1
    x[130]    c716      -1
    x[130]    c717      1
    x[130]    c896      -1
    x[130]    c897      1
    x[130]    c1070     -1
    x[130]    c1071     1
    x[130]    c1238     -1
    x[130]    c1239     1
    x[130]    c1400     -1
    x[130]    c1401     1
    x[130]    c1556     -1
    x[130]    c1557     1
    x[130]    c1706     -1
    x[130]    c1707     1
    x[130]    c1850     -1
    x[130]    c1851     1
    x[130]    c1988     -1
    x[130]    c1989     1
    x[130]    c2120     -1
    x[130]    c2121     1
    x[130]    c2246     -1
    x[130]    c2247     1
    x[130]    c2366     -1
    x[130]    c2367     1
    x[130]    c2480     -1
    x[130]    c2481     1
    x[130]    c2588     -1
    x[130]    c2589     1
    x[130]    c2690     -1
    x[130]    c2691     1
    x[130]    c2786     -1
    x[130]    c2787     1
    x[130]    c2876     -1
    x[130]    c2877     1
    x[130]    c2960     -1
    x[130]    c2961     1
    x[130]    c3038     -1
    x[130]    c3039     1
    x[130]    c3110     -1
    x[130]    c3111     1
    x[130]    c3176     -1
    x[130]    c3177     1
    x[130]    c3242     1
    x[130]    c3243     -1
    x[130]    c3248     1
    x[130]    c3249     -1
    x[130]    c3254     1
    x[130]    c3255     -1
    x[130]    c3260     1
    x[130]    c3261     -1
    x[130]    c3266     1
    x[130]    c3267     -1
    x[130]    c3272     1
    x[130]    c3273     -1
    x[130]    c3278     1
    x[130]    c3279     -1
    x[130]    c3284     1
    x[130]    c3285     -1
    x[130]    c3290     1
    x[130]    c3291     -1
    x[130]    c3296     1
    x[130]    c3297     -1
    x[131]    c52_2     1
    x[131]    c146_1    -1
    x[131]    c147_1    1
    x[131]    c344      -1
    x[131]    c345      1
    x[131]    c536      -1
    x[131]    c537      1
    x[131]    c722      -1
    x[131]    c723      1
    x[131]    c902      -1
    x[131]    c903      1
    x[131]    c1076     -1
    x[131]    c1077     1
    x[131]    c1244     -1
    x[131]    c1245     1
    x[131]    c1406     -1
    x[131]    c1407     1
    x[131]    c1562     -1
    x[131]    c1563     1
    x[131]    c1712     -1
    x[131]    c1713     1
    x[131]    c1856     -1
    x[131]    c1857     1
    x[131]    c1994     -1
    x[131]    c1995     1
    x[131]    c2126     -1
    x[131]    c2127     1
    x[131]    c2252     -1
    x[131]    c2253     1
    x[131]    c2372     -1
    x[131]    c2373     1
    x[131]    c2486     -1
    x[131]    c2487     1
    x[131]    c2594     -1
    x[131]    c2595     1
    x[131]    c2696     -1
    x[131]    c2697     1
    x[131]    c2792     -1
    x[131]    c2793     1
    x[131]    c2882     -1
    x[131]    c2883     1
    x[131]    c2966     -1
    x[131]    c2967     1
    x[131]    c3044     -1
    x[131]    c3045     1
    x[131]    c3116     -1
    x[131]    c3117     1
    x[131]    c3182     -1
    x[131]    c3183     1
    x[131]    c3242     -1
    x[131]    c3243     1
    x[131]    c3302     1
    x[131]    c3303     -1
    x[131]    c3308     1
    x[131]    c3309     -1
    x[131]    c3314     1
    x[131]    c3315     -1
    x[131]    c3320     1
    x[131]    c3321     -1
    x[131]    c3326     1
    x[131]    c3327     -1
    x[131]    c3332     1
    x[131]    c3333     -1
    x[131]    c3338     1
    x[131]    c3339     -1
    x[131]    c3344     1
    x[131]    c3345     -1
    x[131]    c3350     1
    x[131]    c3351     -1
    x[132]    c54_2     1
    x[132]    c152_1    -1
    x[132]    c153_1    1
    x[132]    c350      -1
    x[132]    c351      1
    x[132]    c542      -1
    x[132]    c543      1
    x[132]    c728      -1
    x[132]    c729      1
    x[132]    c908      -1
    x[132]    c909      1
    x[132]    c1082     -1
    x[132]    c1083     1
    x[132]    c1250     -1
    x[132]    c1251     1
    x[132]    c1412     -1
    x[132]    c1413     1
    x[132]    c1568     -1
    x[132]    c1569     1
    x[132]    c1718     -1
    x[132]    c1719     1
    x[132]    c1862     -1
    x[132]    c1863     1
    x[132]    c2000     -1
    x[132]    c2001     1
    x[132]    c2132     -1
    x[132]    c2133     1
    x[132]    c2258     -1
    x[132]    c2259     1
    x[132]    c2378     -1
    x[132]    c2379     1
    x[132]    c2492     -1
    x[132]    c2493     1
    x[132]    c2600     -1
    x[132]    c2601     1
    x[132]    c2702     -1
    x[132]    c2703     1
    x[132]    c2798     -1
    x[132]    c2799     1
    x[132]    c2888     -1
    x[132]    c2889     1
    x[132]    c2972     -1
    x[132]    c2973     1
    x[132]    c3050     -1
    x[132]    c3051     1
    x[132]    c3122     -1
    x[132]    c3123     1
    x[132]    c3188     -1
    x[132]    c3189     1
    x[132]    c3248     -1
    x[132]    c3249     1
    x[132]    c3302     -1
    x[132]    c3303     1
    x[132]    c3356     1
    x[132]    c3357     -1
    x[132]    c3362     1
    x[132]    c3363     -1
    x[132]    c3368     1
    x[132]    c3369     -1
    x[132]    c3374     1
    x[132]    c3375     -1
    x[132]    c3380     1
    x[132]    c3381     -1
    x[132]    c3386     1
    x[132]    c3387     -1
    x[132]    c3392     1
    x[132]    c3393     -1
    x[132]    c3398     1
    x[132]    c3399     -1
    x[133]    c56_2     1
    x[133]    c158_1    -1
    x[133]    c159_1    1
    x[133]    c356      -1
    x[133]    c357      1
    x[133]    c548      -1
    x[133]    c549      1
    x[133]    c734      -1
    x[133]    c735      1
    x[133]    c914      -1
    x[133]    c915      1
    x[133]    c1088     -1
    x[133]    c1089     1
    x[133]    c1256     -1
    x[133]    c1257     1
    x[133]    c1418     -1
    x[133]    c1419     1
    x[133]    c1574     -1
    x[133]    c1575     1
    x[133]    c1724     -1
    x[133]    c1725     1
    x[133]    c1868     -1
    x[133]    c1869     1
    x[133]    c2006     -1
    x[133]    c2007     1
    x[133]    c2138     -1
    x[133]    c2139     1
    x[133]    c2264     -1
    x[133]    c2265     1
    x[133]    c2384     -1
    x[133]    c2385     1
    x[133]    c2498     -1
    x[133]    c2499     1
    x[133]    c2606     -1
    x[133]    c2607     1
    x[133]    c2708     -1
    x[133]    c2709     1
    x[133]    c2804     -1
    x[133]    c2805     1
    x[133]    c2894     -1
    x[133]    c2895     1
    x[133]    c2978     -1
    x[133]    c2979     1
    x[133]    c3056     -1
    x[133]    c3057     1
    x[133]    c3128     -1
    x[133]    c3129     1
    x[133]    c3194     -1
    x[133]    c3195     1
    x[133]    c3254     -1
    x[133]    c3255     1
    x[133]    c3308     -1
    x[133]    c3309     1
    x[133]    c3356     -1
    x[133]    c3357     1
    x[133]    c3404     1
    x[133]    c3405     -1
    x[133]    c3410     1
    x[133]    c3411     -1
    x[133]    c3416     1
    x[133]    c3417     -1
    x[133]    c3422     1
    x[133]    c3423     -1
    x[133]    c3428     1
    x[133]    c3429     -1
    x[133]    c3434     1
    x[133]    c3435     -1
    x[133]    c3440     1
    x[133]    c3441     -1
    x[134]    c58_2     1
    x[134]    c164_1    -1
    x[134]    c165_1    1
    x[134]    c362      -1
    x[134]    c363      1
    x[134]    c554      -1
    x[134]    c555      1
    x[134]    c740      -1
    x[134]    c741      1
    x[134]    c920      -1
    x[134]    c921      1
    x[134]    c1094     -1
    x[134]    c1095     1
    x[134]    c1262     -1
    x[134]    c1263     1
    x[134]    c1424     -1
    x[134]    c1425     1
    x[134]    c1580     -1
    x[134]    c1581     1
    x[134]    c1730     -1
    x[134]    c1731     1
    x[134]    c1874     -1
    x[134]    c1875     1
    x[134]    c2012     -1
    x[134]    c2013     1
    x[134]    c2144     -1
    x[134]    c2145     1
    x[134]    c2270     -1
    x[134]    c2271     1
    x[134]    c2390     -1
    x[134]    c2391     1
    x[134]    c2504     -1
    x[134]    c2505     1
    x[134]    c2612     -1
    x[134]    c2613     1
    x[134]    c2714     -1
    x[134]    c2715     1
    x[134]    c2810     -1
    x[134]    c2811     1
    x[134]    c2900     -1
    x[134]    c2901     1
    x[134]    c2984     -1
    x[134]    c2985     1
    x[134]    c3062     -1
    x[134]    c3063     1
    x[134]    c3134     -1
    x[134]    c3135     1
    x[134]    c3200     -1
    x[134]    c3201     1
    x[134]    c3260     -1
    x[134]    c3261     1
    x[134]    c3314     -1
    x[134]    c3315     1
    x[134]    c3362     -1
    x[134]    c3363     1
    x[134]    c3404     -1
    x[134]    c3405     1
    x[134]    c3446     1
    x[134]    c3447     -1
    x[134]    c3452     1
    x[134]    c3453     -1
    x[134]    c3458     1
    x[134]    c3459     -1
    x[134]    c3464     1
    x[134]    c3465     -1
    x[134]    c3470     1
    x[134]    c3471     -1
    x[134]    c3476     1
    x[134]    c3477     -1
    x[135]    c60_2     1
    x[135]    c170_1    -1
    x[135]    c171_1    1
    x[135]    c368      -1
    x[135]    c369      1
    x[135]    c560      -1
    x[135]    c561      1
    x[135]    c746      -1
    x[135]    c747      1
    x[135]    c926      -1
    x[135]    c927      1
    x[135]    c1100     -1
    x[135]    c1101     1
    x[135]    c1268     -1
    x[135]    c1269     1
    x[135]    c1430     -1
    x[135]    c1431     1
    x[135]    c1586     -1
    x[135]    c1587     1
    x[135]    c1736     -1
    x[135]    c1737     1
    x[135]    c1880     -1
    x[135]    c1881     1
    x[135]    c2018     -1
    x[135]    c2019     1
    x[135]    c2150     -1
    x[135]    c2151     1
    x[135]    c2276     -1
    x[135]    c2277     1
    x[135]    c2396     -1
    x[135]    c2397     1
    x[135]    c2510     -1
    x[135]    c2511     1
    x[135]    c2618     -1
    x[135]    c2619     1
    x[135]    c2720     -1
    x[135]    c2721     1
    x[135]    c2816     -1
    x[135]    c2817     1
    x[135]    c2906     -1
    x[135]    c2907     1
    x[135]    c2990     -1
    x[135]    c2991     1
    x[135]    c3068     -1
    x[135]    c3069     1
    x[135]    c3140     -1
    x[135]    c3141     1
    x[135]    c3206     -1
    x[135]    c3207     1
    x[135]    c3266     -1
    x[135]    c3267     1
    x[135]    c3320     -1
    x[135]    c3321     1
    x[135]    c3368     -1
    x[135]    c3369     1
    x[135]    c3410     -1
    x[135]    c3411     1
    x[135]    c3446     -1
    x[135]    c3447     1
    x[135]    c3482     1
    x[135]    c3483     -1
    x[135]    c3488     1
    x[135]    c3489     -1
    x[135]    c3494     1
    x[135]    c3495     -1
    x[135]    c3500     1
    x[135]    c3501     -1
    x[135]    c3506     1
    x[135]    c3507     -1
    x[136]    c62_2     1
    x[136]    c176_1    -1
    x[136]    c177_1    1
    x[136]    c374      -1
    x[136]    c375      1
    x[136]    c566      -1
    x[136]    c567      1
    x[136]    c752      -1
    x[136]    c753      1
    x[136]    c932      -1
    x[136]    c933      1
    x[136]    c1106     -1
    x[136]    c1107     1
    x[136]    c1274     -1
    x[136]    c1275     1
    x[136]    c1436     -1
    x[136]    c1437     1
    x[136]    c1592     -1
    x[136]    c1593     1
    x[136]    c1742     -1
    x[136]    c1743     1
    x[136]    c1886     -1
    x[136]    c1887     1
    x[136]    c2024     -1
    x[136]    c2025     1
    x[136]    c2156     -1
    x[136]    c2157     1
    x[136]    c2282     -1
    x[136]    c2283     1
    x[136]    c2402     -1
    x[136]    c2403     1
    x[136]    c2516     -1
    x[136]    c2517     1
    x[136]    c2624     -1
    x[136]    c2625     1
    x[136]    c2726     -1
    x[136]    c2727     1
    x[136]    c2822     -1
    x[136]    c2823     1
    x[136]    c2912     -1
    x[136]    c2913     1
    x[136]    c2996     -1
    x[136]    c2997     1
    x[136]    c3074     -1
    x[136]    c3075     1
    x[136]    c3146     -1
    x[136]    c3147     1
    x[136]    c3212     -1
    x[136]    c3213     1
    x[136]    c3272     -1
    x[136]    c3273     1
    x[136]    c3326     -1
    x[136]    c3327     1
    x[136]    c3374     -1
    x[136]    c3375     1
    x[136]    c3416     -1
    x[136]    c3417     1
    x[136]    c3452     -1
    x[136]    c3453     1
    x[136]    c3482     -1
    x[136]    c3483     1
    x[136]    c3512     1
    x[136]    c3513     -1
    x[136]    c3518     1
    x[136]    c3519     -1
    x[136]    c3524     1
    x[136]    c3525     -1
    x[136]    c3530     1
    x[136]    c3531     -1
    x[137]    c64_2     1
    x[137]    c182_1    -1
    x[137]    c183_1    1
    x[137]    c380      -1
    x[137]    c381      1
    x[137]    c572      -1
    x[137]    c573      1
    x[137]    c758      -1
    x[137]    c759      1
    x[137]    c938      -1
    x[137]    c939      1
    x[137]    c1112     -1
    x[137]    c1113     1
    x[137]    c1280     -1
    x[137]    c1281     1
    x[137]    c1442     -1
    x[137]    c1443     1
    x[137]    c1598     -1
    x[137]    c1599     1
    x[137]    c1748     -1
    x[137]    c1749     1
    x[137]    c1892     -1
    x[137]    c1893     1
    x[137]    c2030     -1
    x[137]    c2031     1
    x[137]    c2162     -1
    x[137]    c2163     1
    x[137]    c2288     -1
    x[137]    c2289     1
    x[137]    c2408     -1
    x[137]    c2409     1
    x[137]    c2522     -1
    x[137]    c2523     1
    x[137]    c2630     -1
    x[137]    c2631     1
    x[137]    c2732     -1
    x[137]    c2733     1
    x[137]    c2828     -1
    x[137]    c2829     1
    x[137]    c2918     -1
    x[137]    c2919     1
    x[137]    c3002     -1
    x[137]    c3003     1
    x[137]    c3080     -1
    x[137]    c3081     1
    x[137]    c3152     -1
    x[137]    c3153     1
    x[137]    c3218     -1
    x[137]    c3219     1
    x[137]    c3278     -1
    x[137]    c3279     1
    x[137]    c3332     -1
    x[137]    c3333     1
    x[137]    c3380     -1
    x[137]    c3381     1
    x[137]    c3422     -1
    x[137]    c3423     1
    x[137]    c3458     -1
    x[137]    c3459     1
    x[137]    c3488     -1
    x[137]    c3489     1
    x[137]    c3512     -1
    x[137]    c3513     1
    x[137]    c3536     1
    x[137]    c3537     -1
    x[137]    c3542     1
    x[137]    c3543     -1
    x[137]    c3548     1
    x[137]    c3549     -1
    x[138]    c66_2     1
    x[138]    c188_1    -1
    x[138]    c189_1    1
    x[138]    c386      -1
    x[138]    c387      1
    x[138]    c578      -1
    x[138]    c579      1
    x[138]    c764      -1
    x[138]    c765      1
    x[138]    c944      -1
    x[138]    c945      1
    x[138]    c1118     -1
    x[138]    c1119     1
    x[138]    c1286     -1
    x[138]    c1287     1
    x[138]    c1448     -1
    x[138]    c1449     1
    x[138]    c1604     -1
    x[138]    c1605     1
    x[138]    c1754     -1
    x[138]    c1755     1
    x[138]    c1898     -1
    x[138]    c1899     1
    x[138]    c2036     -1
    x[138]    c2037     1
    x[138]    c2168     -1
    x[138]    c2169     1
    x[138]    c2294     -1
    x[138]    c2295     1
    x[138]    c2414     -1
    x[138]    c2415     1
    x[138]    c2528     -1
    x[138]    c2529     1
    x[138]    c2636     -1
    x[138]    c2637     1
    x[138]    c2738     -1
    x[138]    c2739     1
    x[138]    c2834     -1
    x[138]    c2835     1
    x[138]    c2924     -1
    x[138]    c2925     1
    x[138]    c3008     -1
    x[138]    c3009     1
    x[138]    c3086     -1
    x[138]    c3087     1
    x[138]    c3158     -1
    x[138]    c3159     1
    x[138]    c3224     -1
    x[138]    c3225     1
    x[138]    c3284     -1
    x[138]    c3285     1
    x[138]    c3338     -1
    x[138]    c3339     1
    x[138]    c3386     -1
    x[138]    c3387     1
    x[138]    c3428     -1
    x[138]    c3429     1
    x[138]    c3464     -1
    x[138]    c3465     1
    x[138]    c3494     -1
    x[138]    c3495     1
    x[138]    c3518     -1
    x[138]    c3519     1
    x[138]    c3536     -1
    x[138]    c3537     1
    x[138]    c3554     1
    x[138]    c3555     -1
    x[138]    c3560     1
    x[138]    c3561     -1
    x[139]    c68_2     1
    x[139]    c194_1    -1
    x[139]    c195_1    1
    x[139]    c392      -1
    x[139]    c393      1
    x[139]    c584      -1
    x[139]    c585      1
    x[139]    c770      -1
    x[139]    c771      1
    x[139]    c950      -1
    x[139]    c951      1
    x[139]    c1124     -1
    x[139]    c1125     1
    x[139]    c1292     -1
    x[139]    c1293     1
    x[139]    c1454     -1
    x[139]    c1455     1
    x[139]    c1610     -1
    x[139]    c1611     1
    x[139]    c1760     -1
    x[139]    c1761     1
    x[139]    c1904     -1
    x[139]    c1905     1
    x[139]    c2042     -1
    x[139]    c2043     1
    x[139]    c2174     -1
    x[139]    c2175     1
    x[139]    c2300     -1
    x[139]    c2301     1
    x[139]    c2420     -1
    x[139]    c2421     1
    x[139]    c2534     -1
    x[139]    c2535     1
    x[139]    c2642     -1
    x[139]    c2643     1
    x[139]    c2744     -1
    x[139]    c2745     1
    x[139]    c2840     -1
    x[139]    c2841     1
    x[139]    c2930     -1
    x[139]    c2931     1
    x[139]    c3014     -1
    x[139]    c3015     1
    x[139]    c3092     -1
    x[139]    c3093     1
    x[139]    c3164     -1
    x[139]    c3165     1
    x[139]    c3230     -1
    x[139]    c3231     1
    x[139]    c3290     -1
    x[139]    c3291     1
    x[139]    c3344     -1
    x[139]    c3345     1
    x[139]    c3392     -1
    x[139]    c3393     1
    x[139]    c3434     -1
    x[139]    c3435     1
    x[139]    c3470     -1
    x[139]    c3471     1
    x[139]    c3500     -1
    x[139]    c3501     1
    x[139]    c3524     -1
    x[139]    c3525     1
    x[139]    c3542     -1
    x[139]    c3543     1
    x[139]    c3554     -1
    x[139]    c3555     1
    x[139]    c3566     1
    x[139]    c3567     -1
    x[140]    c70_2     1
    x[140]    c200_1    -1
    x[140]    c201_1    1
    x[140]    c398      -1
    x[140]    c399      1
    x[140]    c590      -1
    x[140]    c591      1
    x[140]    c776      -1
    x[140]    c777      1
    x[140]    c956      -1
    x[140]    c957      1
    x[140]    c1130     -1
    x[140]    c1131     1
    x[140]    c1298     -1
    x[140]    c1299     1
    x[140]    c1460     -1
    x[140]    c1461     1
    x[140]    c1616     -1
    x[140]    c1617     1
    x[140]    c1766     -1
    x[140]    c1767     1
    x[140]    c1910     -1
    x[140]    c1911     1
    x[140]    c2048     -1
    x[140]    c2049     1
    x[140]    c2180     -1
    x[140]    c2181     1
    x[140]    c2306     -1
    x[140]    c2307     1
    x[140]    c2426     -1
    x[140]    c2427     1
    x[140]    c2540     -1
    x[140]    c2541     1
    x[140]    c2648     -1
    x[140]    c2649     1
    x[140]    c2750     -1
    x[140]    c2751     1
    x[140]    c2846     -1
    x[140]    c2847     1
    x[140]    c2936     -1
    x[140]    c2937     1
    x[140]    c3020     -1
    x[140]    c3021     1
    x[140]    c3098     -1
    x[140]    c3099     1
    x[140]    c3170     -1
    x[140]    c3171     1
    x[140]    c3236     -1
    x[140]    c3237     1
    x[140]    c3296     -1
    x[140]    c3297     1
    x[140]    c3350     -1
    x[140]    c3351     1
    x[140]    c3398     -1
    x[140]    c3399     1
    x[140]    c3440     -1
    x[140]    c3441     1
    x[140]    c3476     -1
    x[140]    c3477     1
    x[140]    c3506     -1
    x[140]    c3507     1
    x[140]    c3530     -1
    x[140]    c3531     1
    x[140]    c3548     -1
    x[140]    c3549     1
    x[140]    c3560     -1
    x[140]    c3561     1
    x[140]    c3566     -1
    x[140]    c3567     1
    MARKER    'MARKER'                 'INTORG'
    x[141]    c71_2     1
    x[141]    c960_1    -1
    x[141]    c6_1      360
    x[142]    c71_2     1
    x[142]    c936_1    -1
    x[142]    c1_1      360
    x[143]    c71_2     1
    x[143]    c4_1      100
    x[144]    c71_2     1
    x[144]    c5_1      100
    x[145]    c71_2     1
    x[145]    c2_1      560
    x[146]    c71_2     1
    x[146]    c3_1      560
    x[147]    c73_2     1
    x[147]    c984_1    -1
    x[147]    c12_1     360
    x[148]    c73_2     1
    x[148]    c937_1    -1
    x[148]    c984_1    -1
    x[148]    c7_1      360
    x[149]    c73_2     1
    x[149]    c10_1     100
    x[150]    c73_2     1
    x[150]    c11_1     100
    x[151]    c73_2     1
    x[151]    c8_1      560
    x[152]    c73_2     1
    x[152]    c9_1      560
    x[153]    c75_2     1
    x[153]    c985_1    -1
    x[153]    c18_1     360
    x[154]    c75_2     1
    x[154]    c938_1    -1
    x[154]    c985_1    -1
    x[154]    c13_1     360
    x[155]    c75_2     1
    x[155]    c16_1     100
    x[156]    c75_2     1
    x[156]    c17_1     100
    x[157]    c75_2     1
    x[157]    c14_1     560
    x[158]    c75_2     1
    x[158]    c15_1     560
    x[159]    c77_2     1
    x[159]    c24_1     360
    x[160]    c77_2     1
    x[160]    c939_1    -1
    x[160]    c19_1     360
    x[161]    c77_2     1
    x[161]    c22_1     100
    x[162]    c77_2     1
    x[162]    c23_1     100
    x[163]    c77_2     1
    x[163]    c20_1     560
    x[164]    c77_2     1
    x[164]    c21_1     560
    x[165]    c79_2     1
    x[165]    c30_1     360
    x[166]    c79_2     1
    x[166]    c940_1    -1
    x[166]    c25_1     360
    x[167]    c79_2     1
    x[167]    c28_1     100
    x[168]    c79_2     1
    x[168]    c29_1     100
    x[169]    c79_2     1
    x[169]    c26_1     560
    x[170]    c79_2     1
    x[170]    c27_1     560
    x[171]    c80_2     1
    x[171]    c36_1     360
    x[172]    c80_2     1
    x[172]    c941_1    -1
    x[172]    c31_1     360
    x[173]    c80_2     1
    x[173]    c34_1     100
    x[174]    c80_2     1
    x[174]    c35_1     100
    x[175]    c80_2     1
    x[175]    c32_1     560
    x[176]    c80_2     1
    x[176]    c33_1     560
    x[177]    c81_2     1
    x[177]    c42_1     360
    x[178]    c81_2     1
    x[178]    c942_1    -1
    x[178]    c37_1     360
    x[179]    c81_2     1
    x[179]    c40_1     100
    x[180]    c81_2     1
    x[180]    c41_1     100
    x[181]    c81_2     1
    x[181]    c38_1     560
    x[182]    c81_2     1
    x[182]    c39_1     560
    x[183]    c82_2     1
    x[183]    c48_1     360
    x[184]    c82_2     1
    x[184]    c943_1    -1
    x[184]    c43_1     360
    x[185]    c82_2     1
    x[185]    c46_1     100
    x[186]    c82_2     1
    x[186]    c47_1     100
    x[187]    c82_2     1
    x[187]    c44_1     560
    x[188]    c82_2     1
    x[188]    c45_1     560
    x[189]    c83_2     1
    x[189]    c54_1     360
    x[190]    c83_2     1
    x[190]    c944_1    -1
    x[190]    c49_1     360
    x[191]    c83_2     1
    x[191]    c52_1     100
    x[192]    c83_2     1
    x[192]    c53_1     100
    x[193]    c83_2     1
    x[193]    c50_1     560
    x[194]    c83_2     1
    x[194]    c51_1     560
    x[195]    c84_2     1
    x[195]    c60_1     360
    x[196]    c84_2     1
    x[196]    c945_1    -1
    x[196]    c55_1     360
    x[197]    c84_2     1
    x[197]    c58_1     100
    x[198]    c84_2     1
    x[198]    c59_1     100
    x[199]    c84_2     1
    x[199]    c56_1     560
    x[200]    c84_2     1
    x[200]    c57_1     560
    x[201]    c85_2     1
    x[201]    c66_1     360
    x[202]    c85_2     1
    x[202]    c946_1    -1
    x[202]    c61_1     360
    x[203]    c85_2     1
    x[203]    c64_1     100
    x[204]    c85_2     1
    x[204]    c65_1     100
    x[205]    c85_2     1
    x[205]    c62_1     560
    x[206]    c85_2     1
    x[206]    c63_1     560
    x[207]    c86_2     1
    x[207]    c72_1     360
    x[208]    c86_2     1
    x[208]    c947_1    -1
    x[208]    c67_1     360
    x[209]    c86_2     1
    x[209]    c70_1     100
    x[210]    c86_2     1
    x[210]    c71_1     100
    x[211]    c86_2     1
    x[211]    c68_1     560
    x[212]    c86_2     1
    x[212]    c69_1     560
    x[213]    c87_2     1
    x[213]    c78_1     360
    x[214]    c87_2     1
    x[214]    c948_1    -1
    x[214]    c73_1     360
    x[215]    c87_2     1
    x[215]    c76_1     100
    x[216]    c87_2     1
    x[216]    c77_1     100
    x[217]    c87_2     1
    x[217]    c74_1     560
    x[218]    c87_2     1
    x[218]    c75_1     560
    x[219]    c88_2     1
    x[219]    c84_1     360
    x[220]    c88_2     1
    x[220]    c949_1    -1
    x[220]    c79_1     360
    x[221]    c88_2     1
    x[221]    c82_1     100
    x[222]    c88_2     1
    x[222]    c83_1     100
    x[223]    c88_2     1
    x[223]    c80_1     560
    x[224]    c88_2     1
    x[224]    c81_1     560
    x[225]    c89_2     1
    x[225]    c90_1     360
    x[226]    c89_2     1
    x[226]    c950_1    -1
    x[226]    c85_1     360
    x[227]    c89_2     1
    x[227]    c88_1     100
    x[228]    c89_2     1
    x[228]    c89_1     100
    x[229]    c89_2     1
    x[229]    c86_1     560
    x[230]    c89_2     1
    x[230]    c87_1     560
    x[231]    c90_2     1
    x[231]    c96_1     360
    x[232]    c90_2     1
    x[232]    c951_1    -1
    x[232]    c91_1     360
    x[233]    c90_2     1
    x[233]    c94_1     100
    x[234]    c90_2     1
    x[234]    c95_1     100
    x[235]    c90_2     1
    x[235]    c92_1     560
    x[236]    c90_2     1
    x[236]    c93_1     560
    x[237]    c91_2     1
    x[237]    c102_1    360
    x[238]    c91_2     1
    x[238]    c952_1    -1
    x[238]    c97_1     360
    x[239]    c91_2     1
    x[239]    c100_1    100
    x[240]    c91_2     1
    x[240]    c101_1    100
    x[241]    c91_2     1
    x[241]    c98_1     560
    x[242]    c91_2     1
    x[242]    c99_1     560
    x[243]    c92_2     1
    x[243]    c108_1    360
    x[244]    c92_2     1
    x[244]    c953_1    -1
    x[244]    c103_1    360
    x[245]    c92_2     1
    x[245]    c106_1    100
    x[246]    c92_2     1
    x[246]    c107_1    100
    x[247]    c92_2     1
    x[247]    c104_1    560
    x[248]    c92_2     1
    x[248]    c105_1    560
    x[249]    c93_2     1
    x[249]    c114_1    360
    x[250]    c93_2     1
    x[250]    c954_1    -1
    x[250]    c109_1    360
    x[251]    c93_2     1
    x[251]    c112_1    100
    x[252]    c93_2     1
    x[252]    c113_1    100
    x[253]    c93_2     1
    x[253]    c110_1    560
    x[254]    c93_2     1
    x[254]    c111_1    560
    x[255]    c94_2     1
    x[255]    c120_1    360
    x[256]    c94_2     1
    x[256]    c955_1    -1
    x[256]    c115_1    360
    x[257]    c94_2     1
    x[257]    c118_1    100
    x[258]    c94_2     1
    x[258]    c119_1    100
    x[259]    c94_2     1
    x[259]    c116_1    560
    x[260]    c94_2     1
    x[260]    c117_1    560
    x[261]    c95_2     1
    x[261]    c126_1    360
    x[262]    c95_2     1
    x[262]    c956_1    -1
    x[262]    c121_1    360
    x[263]    c95_2     1
    x[263]    c124_1    100
    x[264]    c95_2     1
    x[264]    c125_1    100
    x[265]    c95_2     1
    x[265]    c122_1    560
    x[266]    c95_2     1
    x[266]    c123_1    560
    x[267]    c96_2     1
    x[267]    c132_1    360
    x[268]    c96_2     1
    x[268]    c957_1    -1
    x[268]    c127_1    360
    x[269]    c96_2     1
    x[269]    c130_1    100
    x[270]    c96_2     1
    x[270]    c131_1    100
    x[271]    c96_2     1
    x[271]    c128_1    560
    x[272]    c96_2     1
    x[272]    c129_1    560
    x[273]    c97_2     1
    x[273]    c138_1    360
    x[274]    c97_2     1
    x[274]    c958_1    -1
    x[274]    c133_1    360
    x[275]    c97_2     1
    x[275]    c136_1    100
    x[276]    c97_2     1
    x[276]    c137_1    100
    x[277]    c97_2     1
    x[277]    c134_1    560
    x[278]    c97_2     1
    x[278]    c135_1    560
    x[279]    c98_2     1
    x[279]    c144_1    360
    x[280]    c98_2     1
    x[280]    c959_1    -1
    x[280]    c139_1    360
    x[281]    c98_2     1
    x[281]    c142_1    100
    x[282]    c98_2     1
    x[282]    c143_1    100
    x[283]    c98_2     1
    x[283]    c140_1    560
    x[284]    c98_2     1
    x[284]    c141_1    560
    x[285]    c99_2     1
    x[285]    c150_1    360
    x[286]    c99_2     1
    x[286]    c145_1    360
    x[287]    c99_2     1
    x[287]    c148_1    100
    x[288]    c99_2     1
    x[288]    c149_1    100
    x[289]    c99_2     1
    x[289]    c146_1    560
    x[290]    c99_2     1
    x[290]    c147_1    560
    x[291]    c100_2    1
    x[291]    c156_1    360
    x[292]    c100_2    1
    x[292]    c151_1    360
    x[293]    c100_2    1
    x[293]    c154_1    100
    x[294]    c100_2    1
    x[294]    c155_1    100
    x[295]    c100_2    1
    x[295]    c152_1    560
    x[296]    c100_2    1
    x[296]    c153_1    560
    x[297]    c101_2    1
    x[297]    c162_1    360
    x[298]    c101_2    1
    x[298]    c157_1    360
    x[299]    c101_2    1
    x[299]    c160_1    100
    x[300]    c101_2    1
    x[300]    c161_1    100
    x[301]    c101_2    1
    x[301]    c158_1    560
    x[302]    c101_2    1
    x[302]    c159_1    560
    x[303]    c102_2    1
    x[303]    c168_1    360
    x[304]    c102_2    1
    x[304]    c163_1    360
    x[305]    c102_2    1
    x[305]    c166_1    100
    x[306]    c102_2    1
    x[306]    c167_1    100
    x[307]    c102_2    1
    x[307]    c164_1    560
    x[308]    c102_2    1
    x[308]    c165_1    560
    x[309]    c103_2    1
    x[309]    c174_1    360
    x[310]    c103_2    1
    x[310]    c169_1    360
    x[311]    c103_2    1
    x[311]    c172_1    100
    x[312]    c103_2    1
    x[312]    c173_1    100
    x[313]    c103_2    1
    x[313]    c170_1    560
    x[314]    c103_2    1
    x[314]    c171_1    560
    x[315]    c104_2    1
    x[315]    c180_1    360
    x[316]    c104_2    1
    x[316]    c175_1    360
    x[317]    c104_2    1
    x[317]    c178_1    100
    x[318]    c104_2    1
    x[318]    c179_1    100
    x[319]    c104_2    1
    x[319]    c176_1    560
    x[320]    c104_2    1
    x[320]    c177_1    560
    x[321]    c105_2    1
    x[321]    c186_1    360
    x[322]    c105_2    1
    x[322]    c181_1    360
    x[323]    c105_2    1
    x[323]    c184_1    100
    x[324]    c105_2    1
    x[324]    c185_1    100
    x[325]    c105_2    1
    x[325]    c182_1    560
    x[326]    c105_2    1
    x[326]    c183_1    560
    x[327]    c106_2    1
    x[327]    c192_1    360
    x[328]    c106_2    1
    x[328]    c187_1    360
    x[329]    c106_2    1
    x[329]    c190_1    100
    x[330]    c106_2    1
    x[330]    c191_1    100
    x[331]    c106_2    1
    x[331]    c188_1    560
    x[332]    c106_2    1
    x[332]    c189_1    560
    x[333]    c107_2    1
    x[333]    c911_1    -1
    x[333]    c198_1    360
    x[334]    c107_2    1
    x[334]    c193_1    360
    x[335]    c107_2    1
    x[335]    c196_1    100
    x[336]    c107_2    1
    x[336]    c197_1    100
    x[337]    c107_2    1
    x[337]    c194_1    560
    x[338]    c107_2    1
    x[338]    c195_1    560
    x[339]    c108_2    1
    x[339]    c204_1    360
    x[340]    c108_2    1
    x[340]    c199_1    360
    x[341]    c108_2    1
    x[341]    c202_1    100
    x[342]    c108_2    1
    x[342]    c203_1    100
    x[343]    c108_2    1
    x[343]    c200_1    560
    x[344]    c108_2    1
    x[344]    c201_1    560
    x[345]    c109_2    1
    x[345]    c210_1    360
    x[346]    c109_2    1
    x[346]    c961_1    -1
    x[346]    c205_1    360
    x[347]    c109_2    1
    x[347]    c208_1    100
    x[348]    c109_2    1
    x[348]    c209_1    100
    x[349]    c109_2    1
    x[349]    c206_1    560
    x[350]    c109_2    1
    x[350]    c207_1    560
    x[351]    c111_2    1
    x[351]    c216_1    360
    x[352]    c111_2    1
    x[352]    c962_1    -1
    x[352]    c211_1    360
    x[353]    c111_2    1
    x[353]    c214_1    100
    x[354]    c111_2    1
    x[354]    c215_1    100
    x[355]    c111_2    1
    x[355]    c212_1    560
    x[356]    c111_2    1
    x[356]    c213_1    560
    x[357]    c113_2    1
    x[357]    c222_1    360
    x[358]    c113_2    1
    x[358]    c963_1    -1
    x[358]    c217_1    360
    x[359]    c113_2    1
    x[359]    c220_1    100
    x[360]    c113_2    1
    x[360]    c221_1    100
    x[361]    c113_2    1
    x[361]    c218_1    560
    x[362]    c113_2    1
    x[362]    c219_1    560
    x[363]    c115_2    1
    x[363]    c228_1    360
    x[364]    c115_2    1
    x[364]    c964_1    -1
    x[364]    c223_1    360
    x[365]    c115_2    1
    x[365]    c226_1    100
    x[366]    c115_2    1
    x[366]    c227_1    100
    x[367]    c115_2    1
    x[367]    c224_1    560
    x[368]    c115_2    1
    x[368]    c225_1    560
    x[369]    c116_2    1
    x[369]    c234_1    360
    x[370]    c116_2    1
    x[370]    c965_1    -1
    x[370]    c229_1    360
    x[371]    c116_2    1
    x[371]    c232_1    100
    x[372]    c116_2    1
    x[372]    c233_1    100
    x[373]    c116_2    1
    x[373]    c230_1    560
    x[374]    c116_2    1
    x[374]    c231_1    560
    x[375]    c117_2    1
    x[375]    c240_1    360
    x[376]    c117_2    1
    x[376]    c966_1    -1
    x[376]    c235_1    360
    x[377]    c117_2    1
    x[377]    c238_1    100
    x[378]    c117_2    1
    x[378]    c239_1    100
    x[379]    c117_2    1
    x[379]    c236_1    560
    x[380]    c117_2    1
    x[380]    c237_1    560
    x[381]    c118_2    1
    x[381]    c246      360
    x[382]    c118_2    1
    x[382]    c967_1    -1
    x[382]    c241_1    360
    x[383]    c118_2    1
    x[383]    c244      100
    x[384]    c118_2    1
    x[384]    c245      100
    x[385]    c118_2    1
    x[385]    c242_1    560
    x[386]    c118_2    1
    x[386]    c243_1    560
    x[387]    c119_2    1
    x[387]    c252      360
    x[388]    c119_2    1
    x[388]    c968_1    -1
    x[388]    c247      360
    x[389]    c119_2    1
    x[389]    c250      100
    x[390]    c119_2    1
    x[390]    c251      100
    x[391]    c119_2    1
    x[391]    c248      560
    x[392]    c119_2    1
    x[392]    c249      560
    x[393]    c120_2    1
    x[393]    c258      360
    x[394]    c120_2    1
    x[394]    c969_1    -1
    x[394]    c253      360
    x[395]    c120_2    1
    x[395]    c256      100
    x[396]    c120_2    1
    x[396]    c257      100
    x[397]    c120_2    1
    x[397]    c254      560
    x[398]    c120_2    1
    x[398]    c255      560
    x[399]    c121_2    1
    x[399]    c264      360
    x[400]    c121_2    1
    x[400]    c970_1    -1
    x[400]    c259      360
    x[401]    c121_2    1
    x[401]    c262      100
    x[402]    c121_2    1
    x[402]    c263      100
    x[403]    c121_2    1
    x[403]    c260      560
    x[404]    c121_2    1
    x[404]    c261      560
    x[405]    c122_2    1
    x[405]    c270      360
    x[406]    c122_2    1
    x[406]    c971_1    -1
    x[406]    c265      360
    x[407]    c122_2    1
    x[407]    c268      100
    x[408]    c122_2    1
    x[408]    c269      100
    x[409]    c122_2    1
    x[409]    c266      560
    x[410]    c122_2    1
    x[410]    c267      560
    x[411]    c123_2    1
    x[411]    c276      360
    x[412]    c123_2    1
    x[412]    c972_1    -1
    x[412]    c271      360
    x[413]    c123_2    1
    x[413]    c274      100
    x[414]    c123_2    1
    x[414]    c275      100
    x[415]    c123_2    1
    x[415]    c272      560
    x[416]    c123_2    1
    x[416]    c273      560
    x[417]    c124_2    1
    x[417]    c282      360
    x[418]    c124_2    1
    x[418]    c973_1    -1
    x[418]    c277      360
    x[419]    c124_2    1
    x[419]    c280      100
    x[420]    c124_2    1
    x[420]    c281      100
    x[421]    c124_2    1
    x[421]    c278      560
    x[422]    c124_2    1
    x[422]    c279      560
    x[423]    c125_2    1
    x[423]    c288      360
    x[424]    c125_2    1
    x[424]    c974_1    -1
    x[424]    c283      360
    x[425]    c125_2    1
    x[425]    c286      100
    x[426]    c125_2    1
    x[426]    c287      100
    x[427]    c125_2    1
    x[427]    c284      560
    x[428]    c125_2    1
    x[428]    c285      560
    x[429]    c126_2    1
    x[429]    c294      360
    x[430]    c126_2    1
    x[430]    c975_1    -1
    x[430]    c289      360
    x[431]    c126_2    1
    x[431]    c292      100
    x[432]    c126_2    1
    x[432]    c293      100
    x[433]    c126_2    1
    x[433]    c290      560
    x[434]    c126_2    1
    x[434]    c291      560
    x[435]    c127_2    1
    x[435]    c300      360
    x[436]    c127_2    1
    x[436]    c976_1    -1
    x[436]    c295      360
    x[437]    c127_2    1
    x[437]    c298      100
    x[438]    c127_2    1
    x[438]    c299      100
    x[439]    c127_2    1
    x[439]    c296      560
    x[440]    c127_2    1
    x[440]    c297      560
    x[441]    c128_2    1
    x[441]    c306      360
    x[442]    c128_2    1
    x[442]    c977_1    -1
    x[442]    c301      360
    x[443]    c128_2    1
    x[443]    c304      100
    x[444]    c128_2    1
    x[444]    c305      100
    x[445]    c128_2    1
    x[445]    c302      560
    x[446]    c128_2    1
    x[446]    c303      560
    x[447]    c129_2    1
    x[447]    c312      360
    x[448]    c129_2    1
    x[448]    c978_1    -1
    x[448]    c307      360
    x[449]    c129_2    1
    x[449]    c310      100
    x[450]    c129_2    1
    x[450]    c311      100
    x[451]    c129_2    1
    x[451]    c308      560
    x[452]    c129_2    1
    x[452]    c309      560
    x[453]    c130_2    1
    x[453]    c318      360
    x[454]    c130_2    1
    x[454]    c979_1    -1
    x[454]    c313      360
    x[455]    c130_2    1
    x[455]    c316      100
    x[456]    c130_2    1
    x[456]    c317      100
    x[457]    c130_2    1
    x[457]    c314      560
    x[458]    c130_2    1
    x[458]    c315      560
    x[459]    c131_2    1
    x[459]    c324      360
    x[460]    c131_2    1
    x[460]    c980_1    -1
    x[460]    c319      360
    x[461]    c131_2    1
    x[461]    c322      100
    x[462]    c131_2    1
    x[462]    c323      100
    x[463]    c131_2    1
    x[463]    c320      560
    x[464]    c131_2    1
    x[464]    c321      560
    x[465]    c132_2    1
    x[465]    c330      360
    x[466]    c132_2    1
    x[466]    c981_1    -1
    x[466]    c325      360
    x[467]    c132_2    1
    x[467]    c328      100
    x[468]    c132_2    1
    x[468]    c329      100
    x[469]    c132_2    1
    x[469]    c326      560
    x[470]    c132_2    1
    x[470]    c327      560
    x[471]    c133_2    1
    x[471]    c336      360
    x[472]    c133_2    1
    x[472]    c982_1    -1
    x[472]    c331      360
    x[473]    c133_2    1
    x[473]    c334      100
    x[474]    c133_2    1
    x[474]    c335      100
    x[475]    c133_2    1
    x[475]    c332      560
    x[476]    c133_2    1
    x[476]    c333      560
    x[477]    c134_2    1
    x[477]    c342      360
    x[478]    c134_2    1
    x[478]    c983_1    -1
    x[478]    c337      360
    x[479]    c134_2    1
    x[479]    c340      100
    x[480]    c134_2    1
    x[480]    c341      100
    x[481]    c134_2    1
    x[481]    c338      560
    x[482]    c134_2    1
    x[482]    c339      560
    x[483]    c135_2    1
    x[483]    c348      360
    x[484]    c135_2    1
    x[484]    c343      360
    x[485]    c135_2    1
    x[485]    c346      100
    x[486]    c135_2    1
    x[486]    c347      100
    x[487]    c135_2    1
    x[487]    c344      560
    x[488]    c135_2    1
    x[488]    c345      560
    x[489]    c136_2    1
    x[489]    c354      360
    x[490]    c136_2    1
    x[490]    c349      360
    x[491]    c136_2    1
    x[491]    c352      100
    x[492]    c136_2    1
    x[492]    c353      100
    x[493]    c136_2    1
    x[493]    c350      560
    x[494]    c136_2    1
    x[494]    c351      560
    x[495]    c137_2    1
    x[495]    c360      360
    x[496]    c137_2    1
    x[496]    c355      360
    x[497]    c137_2    1
    x[497]    c358      100
    x[498]    c137_2    1
    x[498]    c359      100
    x[499]    c137_2    1
    x[499]    c356      560
    x[500]    c137_2    1
    x[500]    c357      560
    x[501]    c138_2    1
    x[501]    c366      360
    x[502]    c138_2    1
    x[502]    c361      360
    x[503]    c138_2    1
    x[503]    c364      100
    x[504]    c138_2    1
    x[504]    c365      100
    x[505]    c138_2    1
    x[505]    c362      560
    x[506]    c138_2    1
    x[506]    c363      560
    x[507]    c139_2    1
    x[507]    c372      360
    x[508]    c139_2    1
    x[508]    c367      360
    x[509]    c139_2    1
    x[509]    c370      100
    x[510]    c139_2    1
    x[510]    c371      100
    x[511]    c139_2    1
    x[511]    c368      560
    x[512]    c139_2    1
    x[512]    c369      560
    x[513]    c140_2    1
    x[513]    c378      360
    x[514]    c140_2    1
    x[514]    c373      360
    x[515]    c140_2    1
    x[515]    c376      100
    x[516]    c140_2    1
    x[516]    c377      100
    x[517]    c140_2    1
    x[517]    c374      560
    x[518]    c140_2    1
    x[518]    c375      560
    x[519]    c141_2    1
    x[519]    c384      360
    x[520]    c141_2    1
    x[520]    c379      360
    x[521]    c141_2    1
    x[521]    c382      100
    x[522]    c141_2    1
    x[522]    c383      100
    x[523]    c141_2    1
    x[523]    c380      560
    x[524]    c141_2    1
    x[524]    c381      560
    x[525]    c142_2    1
    x[525]    c390      360
    x[526]    c142_2    1
    x[526]    c385      360
    x[527]    c142_2    1
    x[527]    c388      100
    x[528]    c142_2    1
    x[528]    c389      100
    x[529]    c142_2    1
    x[529]    c386      560
    x[530]    c142_2    1
    x[530]    c387      560
    x[531]    c143_2    1
    x[531]    c912_1    -1
    x[531]    c396      360
    x[532]    c143_2    1
    x[532]    c391      360
    x[533]    c143_2    1
    x[533]    c394      100
    x[534]    c143_2    1
    x[534]    c395      100
    x[535]    c143_2    1
    x[535]    c392      560
    x[536]    c143_2    1
    x[536]    c393      560
    x[537]    c144_2    1
    x[537]    c402      360
    x[538]    c144_2    1
    x[538]    c397      360
    x[539]    c144_2    1
    x[539]    c400      100
    x[540]    c144_2    1
    x[540]    c401      100
    x[541]    c144_2    1
    x[541]    c398      560
    x[542]    c144_2    1
    x[542]    c399      560
    x[543]    c145_2    1
    x[543]    c408      360
    x[544]    c145_2    1
    x[544]    c403      360
    x[545]    c145_2    1
    x[545]    c406      100
    x[546]    c145_2    1
    x[546]    c407      100
    x[547]    c145_2    1
    x[547]    c404      560
    x[548]    c145_2    1
    x[548]    c405      560
    x[549]    c147_2    1
    x[549]    c414      360
    x[550]    c147_2    1
    x[550]    c409      360
    x[551]    c147_2    1
    x[551]    c412      100
    x[552]    c147_2    1
    x[552]    c413      100
    x[553]    c147_2    1
    x[553]    c410      560
    x[554]    c147_2    1
    x[554]    c411      560
    x[555]    c149_2    1
    x[555]    c420      360
    x[556]    c149_2    1
    x[556]    c415      360
    x[557]    c149_2    1
    x[557]    c418      100
    x[558]    c149_2    1
    x[558]    c419      100
    x[559]    c149_2    1
    x[559]    c416      560
    x[560]    c149_2    1
    x[560]    c417      560
    x[561]    c150_2    1
    x[561]    c426      360
    x[562]    c150_2    1
    x[562]    c421      360
    x[563]    c150_2    1
    x[563]    c424      100
    x[564]    c150_2    1
    x[564]    c425      100
    x[565]    c150_2    1
    x[565]    c422      560
    x[566]    c150_2    1
    x[566]    c423      560
    x[567]    c151_2    1
    x[567]    c432      360
    x[568]    c151_2    1
    x[568]    c427      360
    x[569]    c151_2    1
    x[569]    c430      100
    x[570]    c151_2    1
    x[570]    c431      100
    x[571]    c151_2    1
    x[571]    c428      560
    x[572]    c151_2    1
    x[572]    c429      560
    x[573]    c152_2    1
    x[573]    c438      360
    x[574]    c152_2    1
    x[574]    c433      360
    x[575]    c152_2    1
    x[575]    c436      100
    x[576]    c152_2    1
    x[576]    c437      100
    x[577]    c152_2    1
    x[577]    c434      560
    x[578]    c152_2    1
    x[578]    c435      560
    x[579]    c153_2    1
    x[579]    c444      360
    x[580]    c153_2    1
    x[580]    c439      360
    x[581]    c153_2    1
    x[581]    c442      100
    x[582]    c153_2    1
    x[582]    c443      100
    x[583]    c153_2    1
    x[583]    c440      560
    x[584]    c153_2    1
    x[584]    c441      560
    x[585]    c154_2    1
    x[585]    c450      360
    x[586]    c154_2    1
    x[586]    c445      360
    x[587]    c154_2    1
    x[587]    c448      100
    x[588]    c154_2    1
    x[588]    c449      100
    x[589]    c154_2    1
    x[589]    c446      560
    x[590]    c154_2    1
    x[590]    c447      560
    x[591]    c155_2    1
    x[591]    c456      360
    x[592]    c155_2    1
    x[592]    c451      360
    x[593]    c155_2    1
    x[593]    c454      100
    x[594]    c155_2    1
    x[594]    c455      100
    x[595]    c155_2    1
    x[595]    c452      560
    x[596]    c155_2    1
    x[596]    c453      560
    x[597]    c156_2    1
    x[597]    c462      360
    x[598]    c156_2    1
    x[598]    c457      360
    x[599]    c156_2    1
    x[599]    c460      100
    x[600]    c156_2    1
    x[600]    c461      100
    x[601]    c156_2    1
    x[601]    c458      560
    x[602]    c156_2    1
    x[602]    c459      560
    x[603]    c157_2    1
    x[603]    c468      360
    x[604]    c157_2    1
    x[604]    c463      360
    x[605]    c157_2    1
    x[605]    c466      100
    x[606]    c157_2    1
    x[606]    c467      100
    x[607]    c157_2    1
    x[607]    c464      560
    x[608]    c157_2    1
    x[608]    c465      560
    x[609]    c158_2    1
    x[609]    c474      360
    x[610]    c158_2    1
    x[610]    c469      360
    x[611]    c158_2    1
    x[611]    c472      100
    x[612]    c158_2    1
    x[612]    c473      100
    x[613]    c158_2    1
    x[613]    c470      560
    x[614]    c158_2    1
    x[614]    c471      560
    x[615]    c159_2    1
    x[615]    c480      360
    x[616]    c159_2    1
    x[616]    c475      360
    x[617]    c159_2    1
    x[617]    c478      100
    x[618]    c159_2    1
    x[618]    c479      100
    x[619]    c159_2    1
    x[619]    c476      560
    x[620]    c159_2    1
    x[620]    c477      560
    x[621]    c160_2    1
    x[621]    c486      360
    x[622]    c160_2    1
    x[622]    c481      360
    x[623]    c160_2    1
    x[623]    c484      100
    x[624]    c160_2    1
    x[624]    c485      100
    x[625]    c160_2    1
    x[625]    c482      560
    x[626]    c160_2    1
    x[626]    c483      560
    x[627]    c161_2    1
    x[627]    c492      360
    x[628]    c161_2    1
    x[628]    c487      360
    x[629]    c161_2    1
    x[629]    c490      100
    x[630]    c161_2    1
    x[630]    c491      100
    x[631]    c161_2    1
    x[631]    c488      560
    x[632]    c161_2    1
    x[632]    c489      560
    x[633]    c162_2    1
    x[633]    c498      360
    x[634]    c162_2    1
    x[634]    c493      360
    x[635]    c162_2    1
    x[635]    c496      100
    x[636]    c162_2    1
    x[636]    c497      100
    x[637]    c162_2    1
    x[637]    c494      560
    x[638]    c162_2    1
    x[638]    c495      560
    x[639]    c163_2    1
    x[639]    c504      360
    x[640]    c163_2    1
    x[640]    c499      360
    x[641]    c163_2    1
    x[641]    c502      100
    x[642]    c163_2    1
    x[642]    c503      100
    x[643]    c163_2    1
    x[643]    c500      560
    x[644]    c163_2    1
    x[644]    c501      560
    x[645]    c164_2    1
    x[645]    c510      360
    x[646]    c164_2    1
    x[646]    c505      360
    x[647]    c164_2    1
    x[647]    c508      100
    x[648]    c164_2    1
    x[648]    c509      100
    x[649]    c164_2    1
    x[649]    c506      560
    x[650]    c164_2    1
    x[650]    c507      560
    x[651]    c165_2    1
    x[651]    c516      360
    x[652]    c165_2    1
    x[652]    c511      360
    x[653]    c165_2    1
    x[653]    c514      100
    x[654]    c165_2    1
    x[654]    c515      100
    x[655]    c165_2    1
    x[655]    c512      560
    x[656]    c165_2    1
    x[656]    c513      560
    x[657]    c166_2    1
    x[657]    c522      360
    x[658]    c166_2    1
    x[658]    c517      360
    x[659]    c166_2    1
    x[659]    c520      100
    x[660]    c166_2    1
    x[660]    c521      100
    x[661]    c166_2    1
    x[661]    c518      560
    x[662]    c166_2    1
    x[662]    c519      560
    x[663]    c167_2    1
    x[663]    c528      360
    x[664]    c167_2    1
    x[664]    c523      360
    x[665]    c167_2    1
    x[665]    c526      100
    x[666]    c167_2    1
    x[666]    c527      100
    x[667]    c167_2    1
    x[667]    c524      560
    x[668]    c167_2    1
    x[668]    c525      560
    x[669]    c168_2    1
    x[669]    c534      360
    x[670]    c168_2    1
    x[670]    c529      360
    x[671]    c168_2    1
    x[671]    c532      100
    x[672]    c168_2    1
    x[672]    c533      100
    x[673]    c168_2    1
    x[673]    c530      560
    x[674]    c168_2    1
    x[674]    c531      560
    x[675]    c169_2    1
    x[675]    c540      360
    x[676]    c169_2    1
    x[676]    c535      360
    x[677]    c169_2    1
    x[677]    c538      100
    x[678]    c169_2    1
    x[678]    c539      100
    x[679]    c169_2    1
    x[679]    c536      560
    x[680]    c169_2    1
    x[680]    c537      560
    x[681]    c170_2    1
    x[681]    c546      360
    x[682]    c170_2    1
    x[682]    c541      360
    x[683]    c170_2    1
    x[683]    c544      100
    x[684]    c170_2    1
    x[684]    c545      100
    x[685]    c170_2    1
    x[685]    c542      560
    x[686]    c170_2    1
    x[686]    c543      560
    x[687]    c171_2    1
    x[687]    c552      360
    x[688]    c171_2    1
    x[688]    c547      360
    x[689]    c171_2    1
    x[689]    c550      100
    x[690]    c171_2    1
    x[690]    c551      100
    x[691]    c171_2    1
    x[691]    c548      560
    x[692]    c171_2    1
    x[692]    c549      560
    x[693]    c172_2    1
    x[693]    c558      360
    x[694]    c172_2    1
    x[694]    c553      360
    x[695]    c172_2    1
    x[695]    c556      100
    x[696]    c172_2    1
    x[696]    c557      100
    x[697]    c172_2    1
    x[697]    c554      560
    x[698]    c172_2    1
    x[698]    c555      560
    x[699]    c173_2    1
    x[699]    c564      360
    x[700]    c173_2    1
    x[700]    c559      360
    x[701]    c173_2    1
    x[701]    c562      100
    x[702]    c173_2    1
    x[702]    c563      100
    x[703]    c173_2    1
    x[703]    c560      560
    x[704]    c173_2    1
    x[704]    c561      560
    x[705]    c174_2    1
    x[705]    c570      360
    x[706]    c174_2    1
    x[706]    c565      360
    x[707]    c174_2    1
    x[707]    c568      100
    x[708]    c174_2    1
    x[708]    c569      100
    x[709]    c174_2    1
    x[709]    c566      560
    x[710]    c174_2    1
    x[710]    c567      560
    x[711]    c175_2    1
    x[711]    c576      360
    x[712]    c175_2    1
    x[712]    c571      360
    x[713]    c175_2    1
    x[713]    c574      100
    x[714]    c175_2    1
    x[714]    c575      100
    x[715]    c175_2    1
    x[715]    c572      560
    x[716]    c175_2    1
    x[716]    c573      560
    x[717]    c176_2    1
    x[717]    c582      360
    x[718]    c176_2    1
    x[718]    c577      360
    x[719]    c176_2    1
    x[719]    c580      100
    x[720]    c176_2    1
    x[720]    c581      100
    x[721]    c176_2    1
    x[721]    c578      560
    x[722]    c176_2    1
    x[722]    c579      560
    x[723]    c177_2    1
    x[723]    c913_1    -1
    x[723]    c588      360
    x[724]    c177_2    1
    x[724]    c583      360
    x[725]    c177_2    1
    x[725]    c586      100
    x[726]    c177_2    1
    x[726]    c587      100
    x[727]    c177_2    1
    x[727]    c584      560
    x[728]    c177_2    1
    x[728]    c585      560
    x[729]    c178_2    1
    x[729]    c594      360
    x[730]    c178_2    1
    x[730]    c589      360
    x[731]    c178_2    1
    x[731]    c592      100
    x[732]    c178_2    1
    x[732]    c593      100
    x[733]    c178_2    1
    x[733]    c590      560
    x[734]    c178_2    1
    x[734]    c591      560
    x[735]    c179_2    1
    x[735]    c600      360
    x[736]    c179_2    1
    x[736]    c595      360
    x[737]    c179_2    1
    x[737]    c598      100
    x[738]    c179_2    1
    x[738]    c599      100
    x[739]    c179_2    1
    x[739]    c596      560
    x[740]    c179_2    1
    x[740]    c597      560
    x[741]    c181_2    1
    x[741]    c606      360
    x[742]    c181_2    1
    x[742]    c601      360
    x[743]    c181_2    1
    x[743]    c604      100
    x[744]    c181_2    1
    x[744]    c605      100
    x[745]    c181_2    1
    x[745]    c602      560
    x[746]    c181_2    1
    x[746]    c603      560
    x[747]    c182_2    1
    x[747]    c612      360
    x[748]    c182_2    1
    x[748]    c607      360
    x[749]    c182_2    1
    x[749]    c610      100
    x[750]    c182_2    1
    x[750]    c611      100
    x[751]    c182_2    1
    x[751]    c608      560
    x[752]    c182_2    1
    x[752]    c609      560
    x[753]    c183_2    1
    x[753]    c618      360
    x[754]    c183_2    1
    x[754]    c613      360
    x[755]    c183_2    1
    x[755]    c616      100
    x[756]    c183_2    1
    x[756]    c617      100
    x[757]    c183_2    1
    x[757]    c614      560
    x[758]    c183_2    1
    x[758]    c615      560
    x[759]    c184_2    1
    x[759]    c624      360
    x[760]    c184_2    1
    x[760]    c619      360
    x[761]    c184_2    1
    x[761]    c622      100
    x[762]    c184_2    1
    x[762]    c623      100
    x[763]    c184_2    1
    x[763]    c620      560
    x[764]    c184_2    1
    x[764]    c621      560
    x[765]    c185_2    1
    x[765]    c630      360
    x[766]    c185_2    1
    x[766]    c625      360
    x[767]    c185_2    1
    x[767]    c628      100
    x[768]    c185_2    1
    x[768]    c629      100
    x[769]    c185_2    1
    x[769]    c626      560
    x[770]    c185_2    1
    x[770]    c627      560
    x[771]    c186_2    1
    x[771]    c636      360
    x[772]    c186_2    1
    x[772]    c631      360
    x[773]    c186_2    1
    x[773]    c634      100
    x[774]    c186_2    1
    x[774]    c635      100
    x[775]    c186_2    1
    x[775]    c632      560
    x[776]    c186_2    1
    x[776]    c633      560
    x[777]    c187_2    1
    x[777]    c642      360
    x[778]    c187_2    1
    x[778]    c637      360
    x[779]    c187_2    1
    x[779]    c640      100
    x[780]    c187_2    1
    x[780]    c641      100
    x[781]    c187_2    1
    x[781]    c638      560
    x[782]    c187_2    1
    x[782]    c639      560
    x[783]    c188_2    1
    x[783]    c648      360
    x[784]    c188_2    1
    x[784]    c643      360
    x[785]    c188_2    1
    x[785]    c646      100
    x[786]    c188_2    1
    x[786]    c647      100
    x[787]    c188_2    1
    x[787]    c644      560
    x[788]    c188_2    1
    x[788]    c645      560
    x[789]    c189_2    1
    x[789]    c654      360
    x[790]    c189_2    1
    x[790]    c649      360
    x[791]    c189_2    1
    x[791]    c652      100
    x[792]    c189_2    1
    x[792]    c653      100
    x[793]    c189_2    1
    x[793]    c650      560
    x[794]    c189_2    1
    x[794]    c651      560
    x[795]    c190_2    1
    x[795]    c660      360
    x[796]    c190_2    1
    x[796]    c655      360
    x[797]    c190_2    1
    x[797]    c658      100
    x[798]    c190_2    1
    x[798]    c659      100
    x[799]    c190_2    1
    x[799]    c656      560
    x[800]    c190_2    1
    x[800]    c657      560
    x[801]    c191_2    1
    x[801]    c666      360
    x[802]    c191_2    1
    x[802]    c661      360
    x[803]    c191_2    1
    x[803]    c664      100
    x[804]    c191_2    1
    x[804]    c665      100
    x[805]    c191_2    1
    x[805]    c662      560
    x[806]    c191_2    1
    x[806]    c663      560
    x[807]    c192_2    1
    x[807]    c672      360
    x[808]    c192_2    1
    x[808]    c667      360
    x[809]    c192_2    1
    x[809]    c670      100
    x[810]    c192_2    1
    x[810]    c671      100
    x[811]    c192_2    1
    x[811]    c668      560
    x[812]    c192_2    1
    x[812]    c669      560
    x[813]    c193_2    1
    x[813]    c678      360
    x[814]    c193_2    1
    x[814]    c673      360
    x[815]    c193_2    1
    x[815]    c676      100
    x[816]    c193_2    1
    x[816]    c677      100
    x[817]    c193_2    1
    x[817]    c674      560
    x[818]    c193_2    1
    x[818]    c675      560
    x[819]    c194_2    1
    x[819]    c684      360
    x[820]    c194_2    1
    x[820]    c679      360
    x[821]    c194_2    1
    x[821]    c682      100
    x[822]    c194_2    1
    x[822]    c683      100
    x[823]    c194_2    1
    x[823]    c680      560
    x[824]    c194_2    1
    x[824]    c681      560
    x[825]    c195_2    1
    x[825]    c690      360
    x[826]    c195_2    1
    x[826]    c685      360
    x[827]    c195_2    1
    x[827]    c688      100
    x[828]    c195_2    1
    x[828]    c689      100
    x[829]    c195_2    1
    x[829]    c686      560
    x[830]    c195_2    1
    x[830]    c687      560
    x[831]    c196_2    1
    x[831]    c696      360
    x[832]    c196_2    1
    x[832]    c691      360
    x[833]    c196_2    1
    x[833]    c694      100
    x[834]    c196_2    1
    x[834]    c695      100
    x[835]    c196_2    1
    x[835]    c692      560
    x[836]    c196_2    1
    x[836]    c693      560
    x[837]    c197_2    1
    x[837]    c702      360
    x[838]    c197_2    1
    x[838]    c697      360
    x[839]    c197_2    1
    x[839]    c700      100
    x[840]    c197_2    1
    x[840]    c701      100
    x[841]    c197_2    1
    x[841]    c698      560
    x[842]    c197_2    1
    x[842]    c699      560
    x[843]    c198_2    1
    x[843]    c708      360
    x[844]    c198_2    1
    x[844]    c703      360
    x[845]    c198_2    1
    x[845]    c706      100
    x[846]    c198_2    1
    x[846]    c707      100
    x[847]    c198_2    1
    x[847]    c704      560
    x[848]    c198_2    1
    x[848]    c705      560
    x[849]    c199_2    1
    x[849]    c714      360
    x[850]    c199_2    1
    x[850]    c709      360
    x[851]    c199_2    1
    x[851]    c712      100
    x[852]    c199_2    1
    x[852]    c713      100
    x[853]    c199_2    1
    x[853]    c710      560
    x[854]    c199_2    1
    x[854]    c711      560
    x[855]    c200_2    1
    x[855]    c720      360
    x[856]    c200_2    1
    x[856]    c715      360
    x[857]    c200_2    1
    x[857]    c718      100
    x[858]    c200_2    1
    x[858]    c719      100
    x[859]    c200_2    1
    x[859]    c716      560
    x[860]    c200_2    1
    x[860]    c717      560
    x[861]    c201_2    1
    x[861]    c726      360
    x[862]    c201_2    1
    x[862]    c721      360
    x[863]    c201_2    1
    x[863]    c724      100
    x[864]    c201_2    1
    x[864]    c725      100
    x[865]    c201_2    1
    x[865]    c722      560
    x[866]    c201_2    1
    x[866]    c723      560
    x[867]    c202_2    1
    x[867]    c732      360
    x[868]    c202_2    1
    x[868]    c727      360
    x[869]    c202_2    1
    x[869]    c730      100
    x[870]    c202_2    1
    x[870]    c731      100
    x[871]    c202_2    1
    x[871]    c728      560
    x[872]    c202_2    1
    x[872]    c729      560
    x[873]    c203_2    1
    x[873]    c738      360
    x[874]    c203_2    1
    x[874]    c733      360
    x[875]    c203_2    1
    x[875]    c736      100
    x[876]    c203_2    1
    x[876]    c737      100
    x[877]    c203_2    1
    x[877]    c734      560
    x[878]    c203_2    1
    x[878]    c735      560
    x[879]    c204_2    1
    x[879]    c744      360
    x[880]    c204_2    1
    x[880]    c739      360
    x[881]    c204_2    1
    x[881]    c742      100
    x[882]    c204_2    1
    x[882]    c743      100
    x[883]    c204_2    1
    x[883]    c740      560
    x[884]    c204_2    1
    x[884]    c741      560
    x[885]    c205_2    1
    x[885]    c750      360
    x[886]    c205_2    1
    x[886]    c745      360
    x[887]    c205_2    1
    x[887]    c748      100
    x[888]    c205_2    1
    x[888]    c749      100
    x[889]    c205_2    1
    x[889]    c746      560
    x[890]    c205_2    1
    x[890]    c747      560
    x[891]    c206_2    1
    x[891]    c756      360
    x[892]    c206_2    1
    x[892]    c751      360
    x[893]    c206_2    1
    x[893]    c754      100
    x[894]    c206_2    1
    x[894]    c755      100
    x[895]    c206_2    1
    x[895]    c752      560
    x[896]    c206_2    1
    x[896]    c753      560
    x[897]    c207_2    1
    x[897]    c762      360
    x[898]    c207_2    1
    x[898]    c757      360
    x[899]    c207_2    1
    x[899]    c760      100
    x[900]    c207_2    1
    x[900]    c761      100
    x[901]    c207_2    1
    x[901]    c758      560
    x[902]    c207_2    1
    x[902]    c759      560
    x[903]    c208_2    1
    x[903]    c768      360
    x[904]    c208_2    1
    x[904]    c763      360
    x[905]    c208_2    1
    x[905]    c766      100
    x[906]    c208_2    1
    x[906]    c767      100
    x[907]    c208_2    1
    x[907]    c764      560
    x[908]    c208_2    1
    x[908]    c765      560
    x[909]    c209_2    1
    x[909]    c914_1    -1
    x[909]    c774      360
    x[910]    c209_2    1
    x[910]    c769      360
    x[911]    c209_2    1
    x[911]    c772      100
    x[912]    c209_2    1
    x[912]    c773      100
    x[913]    c209_2    1
    x[913]    c770      560
    x[914]    c209_2    1
    x[914]    c771      560
    x[915]    c210_2    1
    x[915]    c780      360
    x[916]    c210_2    1
    x[916]    c775      360
    x[917]    c210_2    1
    x[917]    c778      100
    x[918]    c210_2    1
    x[918]    c779      100
    x[919]    c210_2    1
    x[919]    c776      560
    x[920]    c210_2    1
    x[920]    c777      560
    x[921]    c211_2    1
    x[921]    c786      360
    x[922]    c211_2    1
    x[922]    c781      360
    x[923]    c211_2    1
    x[923]    c784      100
    x[924]    c211_2    1
    x[924]    c785      100
    x[925]    c211_2    1
    x[925]    c782      560
    x[926]    c211_2    1
    x[926]    c783      560
    x[927]    c212_2    1
    x[927]    c792      360
    x[928]    c212_2    1
    x[928]    c787      360
    x[929]    c212_2    1
    x[929]    c790      100
    x[930]    c212_2    1
    x[930]    c791      100
    x[931]    c212_2    1
    x[931]    c788      560
    x[932]    c212_2    1
    x[932]    c789      560
    x[933]    c213_2    1
    x[933]    c798      360
    x[934]    c213_2    1
    x[934]    c793      360
    x[935]    c213_2    1
    x[935]    c796      100
    x[936]    c213_2    1
    x[936]    c797      100
    x[937]    c213_2    1
    x[937]    c794      560
    x[938]    c213_2    1
    x[938]    c795      560
    x[939]    c214_2    1
    x[939]    c804      360
    x[940]    c214_2    1
    x[940]    c799      360
    x[941]    c214_2    1
    x[941]    c802      100
    x[942]    c214_2    1
    x[942]    c803      100
    x[943]    c214_2    1
    x[943]    c800      560
    x[944]    c214_2    1
    x[944]    c801      560
    x[945]    c215_2    1
    x[945]    c810      360
    x[946]    c215_2    1
    x[946]    c805      360
    x[947]    c215_2    1
    x[947]    c808      100
    x[948]    c215_2    1
    x[948]    c809      100
    x[949]    c215_2    1
    x[949]    c806      560
    x[950]    c215_2    1
    x[950]    c807      560
    x[951]    c216_2    1
    x[951]    c816      360
    x[952]    c216_2    1
    x[952]    c811      360
    x[953]    c216_2    1
    x[953]    c814      100
    x[954]    c216_2    1
    x[954]    c815      100
    x[955]    c216_2    1
    x[955]    c812      560
    x[956]    c216_2    1
    x[956]    c813      560
    x[957]    c217_2    1
    x[957]    c822      360
    x[958]    c217_2    1
    x[958]    c817      360
    x[959]    c217_2    1
    x[959]    c820      100
    x[960]    c217_2    1
    x[960]    c821      100
    x[961]    c217_2    1
    x[961]    c818      560
    x[962]    c217_2    1
    x[962]    c819      560
    x[963]    c218_2    1
    x[963]    c828      360
    x[964]    c218_2    1
    x[964]    c823      360
    x[965]    c218_2    1
    x[965]    c826      100
    x[966]    c218_2    1
    x[966]    c827      100
    x[967]    c218_2    1
    x[967]    c824      560
    x[968]    c218_2    1
    x[968]    c825      560
    x[969]    c219_2    1
    x[969]    c834      360
    x[970]    c219_2    1
    x[970]    c829      360
    x[971]    c219_2    1
    x[971]    c832      100
    x[972]    c219_2    1
    x[972]    c833      100
    x[973]    c219_2    1
    x[973]    c830      560
    x[974]    c219_2    1
    x[974]    c831      560
    x[975]    c220_2    1
    x[975]    c840      360
    x[976]    c220_2    1
    x[976]    c835      360
    x[977]    c220_2    1
    x[977]    c838      100
    x[978]    c220_2    1
    x[978]    c839      100
    x[979]    c220_2    1
    x[979]    c836      560
    x[980]    c220_2    1
    x[980]    c837      560
    x[981]    c221_2    1
    x[981]    c846      360
    x[982]    c221_2    1
    x[982]    c841      360
    x[983]    c221_2    1
    x[983]    c844      100
    x[984]    c221_2    1
    x[984]    c845      100
    x[985]    c221_2    1
    x[985]    c842      560
    x[986]    c221_2    1
    x[986]    c843      560
    x[987]    c222_2    1
    x[987]    c852      360
    x[988]    c222_2    1
    x[988]    c847      360
    x[989]    c222_2    1
    x[989]    c850      100
    x[990]    c222_2    1
    x[990]    c851      100
    x[991]    c222_2    1
    x[991]    c848      560
    x[992]    c222_2    1
    x[992]    c849      560
    x[993]    c223_2    1
    x[993]    c858      360
    x[994]    c223_2    1
    x[994]    c853      360
    x[995]    c223_2    1
    x[995]    c856      100
    x[996]    c223_2    1
    x[996]    c857      100
    x[997]    c223_2    1
    x[997]    c854      560
    x[998]    c223_2    1
    x[998]    c855      560
    x[999]    c224_2    1
    x[999]    c864      360
    x[1000]   c224_2    1
    x[1000]   c859      360
    x[1001]   c224_2    1
    x[1001]   c862      100
    x[1002]   c224_2    1
    x[1002]   c863      100
    x[1003]   c224_2    1
    x[1003]   c860      560
    x[1004]   c224_2    1
    x[1004]   c861      560
    x[1005]   c225_2    1
    x[1005]   c870      360
    x[1006]   c225_2    1
    x[1006]   c865      360
    x[1007]   c225_2    1
    x[1007]   c868      100
    x[1008]   c225_2    1
    x[1008]   c869      100
    x[1009]   c225_2    1
    x[1009]   c866      560
    x[1010]   c225_2    1
    x[1010]   c867      560
    x[1011]   c226_2    1
    x[1011]   c876      360
    x[1012]   c226_2    1
    x[1012]   c871      360
    x[1013]   c226_2    1
    x[1013]   c874      100
    x[1014]   c226_2    1
    x[1014]   c875      100
    x[1015]   c226_2    1
    x[1015]   c872      560
    x[1016]   c226_2    1
    x[1016]   c873      560
    x[1017]   c227_2    1
    x[1017]   c882      360
    x[1018]   c227_2    1
    x[1018]   c877      360
    x[1019]   c227_2    1
    x[1019]   c880      100
    x[1020]   c227_2    1
    x[1020]   c881      100
    x[1021]   c227_2    1
    x[1021]   c878      560
    x[1022]   c227_2    1
    x[1022]   c879      560
    x[1023]   c228_2    1
    x[1023]   c888      360
    x[1024]   c228_2    1
    x[1024]   c883      360
    x[1025]   c228_2    1
    x[1025]   c886      100
    x[1026]   c228_2    1
    x[1026]   c887      100
    x[1027]   c228_2    1
    x[1027]   c884      560
    x[1028]   c228_2    1
    x[1028]   c885      560
    x[1029]   c229_2    1
    x[1029]   c894      360
    x[1030]   c229_2    1
    x[1030]   c889      360
    x[1031]   c229_2    1
    x[1031]   c892      100
    x[1032]   c229_2    1
    x[1032]   c893      100
    x[1033]   c229_2    1
    x[1033]   c890      560
    x[1034]   c229_2    1
    x[1034]   c891      560
    x[1035]   c230_2    1
    x[1035]   c900      360
    x[1036]   c230_2    1
    x[1036]   c895      360
    x[1037]   c230_2    1
    x[1037]   c898      100
    x[1038]   c230_2    1
    x[1038]   c899      100
    x[1039]   c230_2    1
    x[1039]   c896      560
    x[1040]   c230_2    1
    x[1040]   c897      560
    x[1041]   c231_2    1
    x[1041]   c906      360
    x[1042]   c231_2    1
    x[1042]   c901      360
    x[1043]   c231_2    1
    x[1043]   c904      100
    x[1044]   c231_2    1
    x[1044]   c905      100
    x[1045]   c231_2    1
    x[1045]   c902      560
    x[1046]   c231_2    1
    x[1046]   c903      560
    x[1047]   c232_2    1
    x[1047]   c912      360
    x[1048]   c232_2    1
    x[1048]   c907      360
    x[1049]   c232_2    1
    x[1049]   c910      100
    x[1050]   c232_2    1
    x[1050]   c911      100
    x[1051]   c232_2    1
    x[1051]   c908      560
    x[1052]   c232_2    1
    x[1052]   c909      560
    x[1053]   c233_2    1
    x[1053]   c918      360
    x[1054]   c233_2    1
    x[1054]   c913      360
    x[1055]   c233_2    1
    x[1055]   c916      100
    x[1056]   c233_2    1
    x[1056]   c917      100
    x[1057]   c233_2    1
    x[1057]   c914      560
    x[1058]   c233_2    1
    x[1058]   c915      560
    x[1059]   c234_2    1
    x[1059]   c924      360
    x[1060]   c234_2    1
    x[1060]   c919      360
    x[1061]   c234_2    1
    x[1061]   c922      100
    x[1062]   c234_2    1
    x[1062]   c923      100
    x[1063]   c234_2    1
    x[1063]   c920      560
    x[1064]   c234_2    1
    x[1064]   c921      560
    x[1065]   c235_2    1
    x[1065]   c930      360
    x[1066]   c235_2    1
    x[1066]   c925      360
    x[1067]   c235_2    1
    x[1067]   c928      100
    x[1068]   c235_2    1
    x[1068]   c929      100
    x[1069]   c235_2    1
    x[1069]   c926      560
    x[1070]   c235_2    1
    x[1070]   c927      560
    x[1071]   c236_2    1
    x[1071]   c936      360
    x[1072]   c236_2    1
    x[1072]   c931      360
    x[1073]   c236_2    1
    x[1073]   c934      100
    x[1074]   c236_2    1
    x[1074]   c935      100
    x[1075]   c236_2    1
    x[1075]   c932      560
    x[1076]   c236_2    1
    x[1076]   c933      560
    x[1077]   c237_2    1
    x[1077]   c942      360
    x[1078]   c237_2    1
    x[1078]   c937      360
    x[1079]   c237_2    1
    x[1079]   c940      100
    x[1080]   c237_2    1
    x[1080]   c941      100
    x[1081]   c237_2    1
    x[1081]   c938      560
    x[1082]   c237_2    1
    x[1082]   c939      560
    x[1083]   c238_2    1
    x[1083]   c948      360
    x[1084]   c238_2    1
    x[1084]   c943      360
    x[1085]   c238_2    1
    x[1085]   c946      100
    x[1086]   c238_2    1
    x[1086]   c947      100
    x[1087]   c238_2    1
    x[1087]   c944      560
    x[1088]   c238_2    1
    x[1088]   c945      560
    x[1089]   c239_2    1
    x[1089]   c915_1    -1
    x[1089]   c954      360
    x[1090]   c239_2    1
    x[1090]   c949      360
    x[1091]   c239_2    1
    x[1091]   c952      100
    x[1092]   c239_2    1
    x[1092]   c953      100
    x[1093]   c239_2    1
    x[1093]   c950      560
    x[1094]   c239_2    1
    x[1094]   c951      560
    x[1095]   c240_2    1
    x[1095]   c960      360
    x[1096]   c240_2    1
    x[1096]   c955      360
    x[1097]   c240_2    1
    x[1097]   c958      100
    x[1098]   c240_2    1
    x[1098]   c959      100
    x[1099]   c240_2    1
    x[1099]   c956      560
    x[1100]   c240_2    1
    x[1100]   c957      560
    x[1101]   c241_2    1
    x[1101]   c966      360
    x[1102]   c241_2    1
    x[1102]   c961      360
    x[1103]   c241_2    1
    x[1103]   c964      100
    x[1104]   c241_2    1
    x[1104]   c965      100
    x[1105]   c241_2    1
    x[1105]   c962      560
    x[1106]   c241_2    1
    x[1106]   c963      560
    x[1107]   c243_2    1
    x[1107]   c972      360
    x[1108]   c243_2    1
    x[1108]   c967      360
    x[1109]   c243_2    1
    x[1109]   c970      100
    x[1110]   c243_2    1
    x[1110]   c971      100
    x[1111]   c243_2    1
    x[1111]   c968      560
    x[1112]   c243_2    1
    x[1112]   c969      560
    x[1113]   c245_1    1
    x[1113]   c978      360
    x[1114]   c245_1    1
    x[1114]   c973      360
    x[1115]   c245_1    1
    x[1115]   c976      100
    x[1116]   c245_1    1
    x[1116]   c977      100
    x[1117]   c245_1    1
    x[1117]   c974      560
    x[1118]   c245_1    1
    x[1118]   c975      560
    x[1119]   c247_1    1
    x[1119]   c984      360
    x[1120]   c247_1    1
    x[1120]   c979      360
    x[1121]   c247_1    1
    x[1121]   c982      100
    x[1122]   c247_1    1
    x[1122]   c983      100
    x[1123]   c247_1    1
    x[1123]   c980      560
    x[1124]   c247_1    1
    x[1124]   c981      560
    x[1125]   c249_1    1
    x[1125]   c990      360
    x[1126]   c249_1    1
    x[1126]   c985      360
    x[1127]   c249_1    1
    x[1127]   c988      100
    x[1128]   c249_1    1
    x[1128]   c989      100
    x[1129]   c249_1    1
    x[1129]   c986      560
    x[1130]   c249_1    1
    x[1130]   c987      560
    x[1131]   c251_1    1
    x[1131]   c996      360
    x[1132]   c251_1    1
    x[1132]   c991      360
    x[1133]   c251_1    1
    x[1133]   c994      100
    x[1134]   c251_1    1
    x[1134]   c995      100
    x[1135]   c251_1    1
    x[1135]   c992      560
    x[1136]   c251_1    1
    x[1136]   c993      560
    x[1137]   c253_1    1
    x[1137]   c1002     360
    x[1138]   c253_1    1
    x[1138]   c997      360
    x[1139]   c253_1    1
    x[1139]   c1000     100
    x[1140]   c253_1    1
    x[1140]   c1001     100
    x[1141]   c253_1    1
    x[1141]   c998      560
    x[1142]   c253_1    1
    x[1142]   c999      560
    x[1143]   c255_1    1
    x[1143]   c1008     360
    x[1144]   c255_1    1
    x[1144]   c1003     360
    x[1145]   c255_1    1
    x[1145]   c1006     100
    x[1146]   c255_1    1
    x[1146]   c1007     100
    x[1147]   c255_1    1
    x[1147]   c1004     560
    x[1148]   c255_1    1
    x[1148]   c1005     560
    x[1149]   c257_1    1
    x[1149]   c1014     360
    x[1150]   c257_1    1
    x[1150]   c1009     360
    x[1151]   c257_1    1
    x[1151]   c1012     100
    x[1152]   c257_1    1
    x[1152]   c1013     100
    x[1153]   c257_1    1
    x[1153]   c1010     560
    x[1154]   c257_1    1
    x[1154]   c1011     560
    x[1155]   c259_1    1
    x[1155]   c1020     360
    x[1156]   c259_1    1
    x[1156]   c1015     360
    x[1157]   c259_1    1
    x[1157]   c1018     100
    x[1158]   c259_1    1
    x[1158]   c1019     100
    x[1159]   c259_1    1
    x[1159]   c1016     560
    x[1160]   c259_1    1
    x[1160]   c1017     560
    x[1161]   c261_1    1
    x[1161]   c1026     360
    x[1162]   c261_1    1
    x[1162]   c1021     360
    x[1163]   c261_1    1
    x[1163]   c1024     100
    x[1164]   c261_1    1
    x[1164]   c1025     100
    x[1165]   c261_1    1
    x[1165]   c1022     560
    x[1166]   c261_1    1
    x[1166]   c1023     560
    x[1167]   c263_1    1
    x[1167]   c1032     360
    x[1168]   c263_1    1
    x[1168]   c1027     360
    x[1169]   c263_1    1
    x[1169]   c1030     100
    x[1170]   c263_1    1
    x[1170]   c1031     100
    x[1171]   c263_1    1
    x[1171]   c1028     560
    x[1172]   c263_1    1
    x[1172]   c1029     560
    x[1173]   c265_1    1
    x[1173]   c1038     360
    x[1174]   c265_1    1
    x[1174]   c1033     360
    x[1175]   c265_1    1
    x[1175]   c1036     100
    x[1176]   c265_1    1
    x[1176]   c1037     100
    x[1177]   c265_1    1
    x[1177]   c1034     560
    x[1178]   c265_1    1
    x[1178]   c1035     560
    x[1179]   c267_1    1
    x[1179]   c1044     360
    x[1180]   c267_1    1
    x[1180]   c1039     360
    x[1181]   c267_1    1
    x[1181]   c1042     100
    x[1182]   c267_1    1
    x[1182]   c1043     100
    x[1183]   c267_1    1
    x[1183]   c1040     560
    x[1184]   c267_1    1
    x[1184]   c1041     560
    x[1185]   c269_1    1
    x[1185]   c1050     360
    x[1186]   c269_1    1
    x[1186]   c1045     360
    x[1187]   c269_1    1
    x[1187]   c1048     100
    x[1188]   c269_1    1
    x[1188]   c1049     100
    x[1189]   c269_1    1
    x[1189]   c1046     560
    x[1190]   c269_1    1
    x[1190]   c1047     560
    x[1191]   c271_1    1
    x[1191]   c1056     360
    x[1192]   c271_1    1
    x[1192]   c1051     360
    x[1193]   c271_1    1
    x[1193]   c1054     100
    x[1194]   c271_1    1
    x[1194]   c1055     100
    x[1195]   c271_1    1
    x[1195]   c1052     560
    x[1196]   c271_1    1
    x[1196]   c1053     560
    x[1197]   c273_1    1
    x[1197]   c1062     360
    x[1198]   c273_1    1
    x[1198]   c1057     360
    x[1199]   c273_1    1
    x[1199]   c1060     100
    x[1200]   c273_1    1
    x[1200]   c1061     100
    x[1201]   c273_1    1
    x[1201]   c1058     560
    x[1202]   c273_1    1
    x[1202]   c1059     560
    x[1203]   c275_1    1
    x[1203]   c1068     360
    x[1204]   c275_1    1
    x[1204]   c1063     360
    x[1205]   c275_1    1
    x[1205]   c1066     100
    x[1206]   c275_1    1
    x[1206]   c1067     100
    x[1207]   c275_1    1
    x[1207]   c1064     560
    x[1208]   c275_1    1
    x[1208]   c1065     560
    x[1209]   c277_1    1
    x[1209]   c1074     360
    x[1210]   c277_1    1
    x[1210]   c1069     360
    x[1211]   c277_1    1
    x[1211]   c1072     100
    x[1212]   c277_1    1
    x[1212]   c1073     100
    x[1213]   c277_1    1
    x[1213]   c1070     560
    x[1214]   c277_1    1
    x[1214]   c1071     560
    x[1215]   c279_1    1
    x[1215]   c1080     360
    x[1216]   c279_1    1
    x[1216]   c1075     360
    x[1217]   c279_1    1
    x[1217]   c1078     100
    x[1218]   c279_1    1
    x[1218]   c1079     100
    x[1219]   c279_1    1
    x[1219]   c1076     560
    x[1220]   c279_1    1
    x[1220]   c1077     560
    x[1221]   c280_1    1
    x[1221]   c1086     360
    x[1222]   c280_1    1
    x[1222]   c1081     360
    x[1223]   c280_1    1
    x[1223]   c1084     100
    x[1224]   c280_1    1
    x[1224]   c1085     100
    x[1225]   c280_1    1
    x[1225]   c1082     560
    x[1226]   c280_1    1
    x[1226]   c1083     560
    x[1227]   c281_1    1
    x[1227]   c1092     360
    x[1228]   c281_1    1
    x[1228]   c1087     360
    x[1229]   c281_1    1
    x[1229]   c1090     100
    x[1230]   c281_1    1
    x[1230]   c1091     100
    x[1231]   c281_1    1
    x[1231]   c1088     560
    x[1232]   c281_1    1
    x[1232]   c1089     560
    x[1233]   c282_1    1
    x[1233]   c1098     360
    x[1234]   c282_1    1
    x[1234]   c1093     360
    x[1235]   c282_1    1
    x[1235]   c1096     100
    x[1236]   c282_1    1
    x[1236]   c1097     100
    x[1237]   c282_1    1
    x[1237]   c1094     560
    x[1238]   c282_1    1
    x[1238]   c1095     560
    x[1239]   c283_1    1
    x[1239]   c1104     360
    x[1240]   c283_1    1
    x[1240]   c1099     360
    x[1241]   c283_1    1
    x[1241]   c1102     100
    x[1242]   c283_1    1
    x[1242]   c1103     100
    x[1243]   c283_1    1
    x[1243]   c1100     560
    x[1244]   c283_1    1
    x[1244]   c1101     560
    x[1245]   c284_1    1
    x[1245]   c1110     360
    x[1246]   c284_1    1
    x[1246]   c1105     360
    x[1247]   c284_1    1
    x[1247]   c1108     100
    x[1248]   c284_1    1
    x[1248]   c1109     100
    x[1249]   c284_1    1
    x[1249]   c1106     560
    x[1250]   c284_1    1
    x[1250]   c1107     560
    x[1251]   c285_1    1
    x[1251]   c1116     360
    x[1252]   c285_1    1
    x[1252]   c1111     360
    x[1253]   c285_1    1
    x[1253]   c1114     100
    x[1254]   c285_1    1
    x[1254]   c1115     100
    x[1255]   c285_1    1
    x[1255]   c1112     560
    x[1256]   c285_1    1
    x[1256]   c1113     560
    x[1257]   c286_1    1
    x[1257]   c1122     360
    x[1258]   c286_1    1
    x[1258]   c1117     360
    x[1259]   c286_1    1
    x[1259]   c1120     100
    x[1260]   c286_1    1
    x[1260]   c1121     100
    x[1261]   c286_1    1
    x[1261]   c1118     560
    x[1262]   c286_1    1
    x[1262]   c1119     560
    x[1263]   c287_1    1
    x[1263]   c916_1    -1
    x[1263]   c1128     360
    x[1264]   c287_1    1
    x[1264]   c1123     360
    x[1265]   c287_1    1
    x[1265]   c1126     100
    x[1266]   c287_1    1
    x[1266]   c1127     100
    x[1267]   c287_1    1
    x[1267]   c1124     560
    x[1268]   c287_1    1
    x[1268]   c1125     560
    x[1269]   c288_1    1
    x[1269]   c1134     360
    x[1270]   c288_1    1
    x[1270]   c1129     360
    x[1271]   c288_1    1
    x[1271]   c1132     100
    x[1272]   c288_1    1
    x[1272]   c1133     100
    x[1273]   c288_1    1
    x[1273]   c1130     560
    x[1274]   c288_1    1
    x[1274]   c1131     560
    x[1275]   c289_1    1
    x[1275]   c1140     360
    x[1276]   c289_1    1
    x[1276]   c1135     360
    x[1277]   c289_1    1
    x[1277]   c1138     100
    x[1278]   c289_1    1
    x[1278]   c1139     100
    x[1279]   c289_1    1
    x[1279]   c1136     560
    x[1280]   c289_1    1
    x[1280]   c1137     560
    x[1281]   c291_1    1
    x[1281]   c1146     360
    x[1282]   c291_1    1
    x[1282]   c1141     360
    x[1283]   c291_1    1
    x[1283]   c1144     100
    x[1284]   c291_1    1
    x[1284]   c1145     100
    x[1285]   c291_1    1
    x[1285]   c1142     560
    x[1286]   c291_1    1
    x[1286]   c1143     560
    x[1287]   c293_1    1
    x[1287]   c1152     360
    x[1288]   c293_1    1
    x[1288]   c1147     360
    x[1289]   c293_1    1
    x[1289]   c1150     100
    x[1290]   c293_1    1
    x[1290]   c1151     100
    x[1291]   c293_1    1
    x[1291]   c1148     560
    x[1292]   c293_1    1
    x[1292]   c1149     560
    x[1293]   c295_1    1
    x[1293]   c1158     360
    x[1294]   c295_1    1
    x[1294]   c1153     360
    x[1295]   c295_1    1
    x[1295]   c1156     100
    x[1296]   c295_1    1
    x[1296]   c1157     100
    x[1297]   c295_1    1
    x[1297]   c1154     560
    x[1298]   c295_1    1
    x[1298]   c1155     560
    x[1299]   c297_1    1
    x[1299]   c1164     360
    x[1300]   c297_1    1
    x[1300]   c1159     360
    x[1301]   c297_1    1
    x[1301]   c1162     100
    x[1302]   c297_1    1
    x[1302]   c1163     100
    x[1303]   c297_1    1
    x[1303]   c1160     560
    x[1304]   c297_1    1
    x[1304]   c1161     560
    x[1305]   c299_1    1
    x[1305]   c1170     360
    x[1306]   c299_1    1
    x[1306]   c1165     360
    x[1307]   c299_1    1
    x[1307]   c1168     100
    x[1308]   c299_1    1
    x[1308]   c1169     100
    x[1309]   c299_1    1
    x[1309]   c1166     560
    x[1310]   c299_1    1
    x[1310]   c1167     560
    x[1311]   c301_1    1
    x[1311]   c1176     360
    x[1312]   c301_1    1
    x[1312]   c1171     360
    x[1313]   c301_1    1
    x[1313]   c1174     100
    x[1314]   c301_1    1
    x[1314]   c1175     100
    x[1315]   c301_1    1
    x[1315]   c1172     560
    x[1316]   c301_1    1
    x[1316]   c1173     560
    x[1317]   c303_1    1
    x[1317]   c1182     360
    x[1318]   c303_1    1
    x[1318]   c1177     360
    x[1319]   c303_1    1
    x[1319]   c1180     100
    x[1320]   c303_1    1
    x[1320]   c1181     100
    x[1321]   c303_1    1
    x[1321]   c1178     560
    x[1322]   c303_1    1
    x[1322]   c1179     560
    x[1323]   c305_1    1
    x[1323]   c1188     360
    x[1324]   c305_1    1
    x[1324]   c1183     360
    x[1325]   c305_1    1
    x[1325]   c1186     100
    x[1326]   c305_1    1
    x[1326]   c1187     100
    x[1327]   c305_1    1
    x[1327]   c1184     560
    x[1328]   c305_1    1
    x[1328]   c1185     560
    x[1329]   c307_1    1
    x[1329]   c1194     360
    x[1330]   c307_1    1
    x[1330]   c1189     360
    x[1331]   c307_1    1
    x[1331]   c1192     100
    x[1332]   c307_1    1
    x[1332]   c1193     100
    x[1333]   c307_1    1
    x[1333]   c1190     560
    x[1334]   c307_1    1
    x[1334]   c1191     560
    x[1335]   c309_1    1
    x[1335]   c1200     360
    x[1336]   c309_1    1
    x[1336]   c1195     360
    x[1337]   c309_1    1
    x[1337]   c1198     100
    x[1338]   c309_1    1
    x[1338]   c1199     100
    x[1339]   c309_1    1
    x[1339]   c1196     560
    x[1340]   c309_1    1
    x[1340]   c1197     560
    x[1341]   c311_1    1
    x[1341]   c1206     360
    x[1342]   c311_1    1
    x[1342]   c1201     360
    x[1343]   c311_1    1
    x[1343]   c1204     100
    x[1344]   c311_1    1
    x[1344]   c1205     100
    x[1345]   c311_1    1
    x[1345]   c1202     560
    x[1346]   c311_1    1
    x[1346]   c1203     560
    x[1347]   c313_1    1
    x[1347]   c1212     360
    x[1348]   c313_1    1
    x[1348]   c1207     360
    x[1349]   c313_1    1
    x[1349]   c1210     100
    x[1350]   c313_1    1
    x[1350]   c1211     100
    x[1351]   c313_1    1
    x[1351]   c1208     560
    x[1352]   c313_1    1
    x[1352]   c1209     560
    x[1353]   c315_1    1
    x[1353]   c1218     360
    x[1354]   c315_1    1
    x[1354]   c1213     360
    x[1355]   c315_1    1
    x[1355]   c1216     100
    x[1356]   c315_1    1
    x[1356]   c1217     100
    x[1357]   c315_1    1
    x[1357]   c1214     560
    x[1358]   c315_1    1
    x[1358]   c1215     560
    x[1359]   c317_1    1
    x[1359]   c1224     360
    x[1360]   c317_1    1
    x[1360]   c1219     360
    x[1361]   c317_1    1
    x[1361]   c1222     100
    x[1362]   c317_1    1
    x[1362]   c1223     100
    x[1363]   c317_1    1
    x[1363]   c1220     560
    x[1364]   c317_1    1
    x[1364]   c1221     560
    x[1365]   c319_1    1
    x[1365]   c1230     360
    x[1366]   c319_1    1
    x[1366]   c1225     360
    x[1367]   c319_1    1
    x[1367]   c1228     100
    x[1368]   c319_1    1
    x[1368]   c1229     100
    x[1369]   c319_1    1
    x[1369]   c1226     560
    x[1370]   c319_1    1
    x[1370]   c1227     560
    x[1371]   c321_1    1
    x[1371]   c1236     360
    x[1372]   c321_1    1
    x[1372]   c1231     360
    x[1373]   c321_1    1
    x[1373]   c1234     100
    x[1374]   c321_1    1
    x[1374]   c1235     100
    x[1375]   c321_1    1
    x[1375]   c1232     560
    x[1376]   c321_1    1
    x[1376]   c1233     560
    x[1377]   c323_1    1
    x[1377]   c1242     360
    x[1378]   c323_1    1
    x[1378]   c1237     360
    x[1379]   c323_1    1
    x[1379]   c1240     100
    x[1380]   c323_1    1
    x[1380]   c1241     100
    x[1381]   c323_1    1
    x[1381]   c1238     560
    x[1382]   c323_1    1
    x[1382]   c1239     560
    x[1383]   c325_1    1
    x[1383]   c1248     360
    x[1384]   c325_1    1
    x[1384]   c1243     360
    x[1385]   c325_1    1
    x[1385]   c1246     100
    x[1386]   c325_1    1
    x[1386]   c1247     100
    x[1387]   c325_1    1
    x[1387]   c1244     560
    x[1388]   c325_1    1
    x[1388]   c1245     560
    x[1389]   c326_1    1
    x[1389]   c1254     360
    x[1390]   c326_1    1
    x[1390]   c1249     360
    x[1391]   c326_1    1
    x[1391]   c1252     100
    x[1392]   c326_1    1
    x[1392]   c1253     100
    x[1393]   c326_1    1
    x[1393]   c1250     560
    x[1394]   c326_1    1
    x[1394]   c1251     560
    x[1395]   c327_1    1
    x[1395]   c1260     360
    x[1396]   c327_1    1
    x[1396]   c1255     360
    x[1397]   c327_1    1
    x[1397]   c1258     100
    x[1398]   c327_1    1
    x[1398]   c1259     100
    x[1399]   c327_1    1
    x[1399]   c1256     560
    x[1400]   c327_1    1
    x[1400]   c1257     560
    x[1401]   c328_1    1
    x[1401]   c1266     360
    x[1402]   c328_1    1
    x[1402]   c1261     360
    x[1403]   c328_1    1
    x[1403]   c1264     100
    x[1404]   c328_1    1
    x[1404]   c1265     100
    x[1405]   c328_1    1
    x[1405]   c1262     560
    x[1406]   c328_1    1
    x[1406]   c1263     560
    x[1407]   c329_1    1
    x[1407]   c1272     360
    x[1408]   c329_1    1
    x[1408]   c1267     360
    x[1409]   c329_1    1
    x[1409]   c1270     100
    x[1410]   c329_1    1
    x[1410]   c1271     100
    x[1411]   c329_1    1
    x[1411]   c1268     560
    x[1412]   c329_1    1
    x[1412]   c1269     560
    x[1413]   c330_1    1
    x[1413]   c1278     360
    x[1414]   c330_1    1
    x[1414]   c1273     360
    x[1415]   c330_1    1
    x[1415]   c1276     100
    x[1416]   c330_1    1
    x[1416]   c1277     100
    x[1417]   c330_1    1
    x[1417]   c1274     560
    x[1418]   c330_1    1
    x[1418]   c1275     560
    x[1419]   c331_1    1
    x[1419]   c1284     360
    x[1420]   c331_1    1
    x[1420]   c1279     360
    x[1421]   c331_1    1
    x[1421]   c1282     100
    x[1422]   c331_1    1
    x[1422]   c1283     100
    x[1423]   c331_1    1
    x[1423]   c1280     560
    x[1424]   c331_1    1
    x[1424]   c1281     560
    x[1425]   c332_1    1
    x[1425]   c1290     360
    x[1426]   c332_1    1
    x[1426]   c1285     360
    x[1427]   c332_1    1
    x[1427]   c1288     100
    x[1428]   c332_1    1
    x[1428]   c1289     100
    x[1429]   c332_1    1
    x[1429]   c1286     560
    x[1430]   c332_1    1
    x[1430]   c1287     560
    x[1431]   c333_1    1
    x[1431]   c917_1    -1
    x[1431]   c1296     360
    x[1432]   c333_1    1
    x[1432]   c1291     360
    x[1433]   c333_1    1
    x[1433]   c1294     100
    x[1434]   c333_1    1
    x[1434]   c1295     100
    x[1435]   c333_1    1
    x[1435]   c1292     560
    x[1436]   c333_1    1
    x[1436]   c1293     560
    x[1437]   c334_1    1
    x[1437]   c1302     360
    x[1438]   c334_1    1
    x[1438]   c1297     360
    x[1439]   c334_1    1
    x[1439]   c1300     100
    x[1440]   c334_1    1
    x[1440]   c1301     100
    x[1441]   c334_1    1
    x[1441]   c1298     560
    x[1442]   c334_1    1
    x[1442]   c1299     560
    x[1443]   c335_1    1
    x[1443]   c1308     360
    x[1444]   c335_1    1
    x[1444]   c1303     360
    x[1445]   c335_1    1
    x[1445]   c1306     100
    x[1446]   c335_1    1
    x[1446]   c1307     100
    x[1447]   c335_1    1
    x[1447]   c1304     560
    x[1448]   c335_1    1
    x[1448]   c1305     560
    x[1449]   c337_1    1
    x[1449]   c1314     360
    x[1450]   c337_1    1
    x[1450]   c1309     360
    x[1451]   c337_1    1
    x[1451]   c1312     100
    x[1452]   c337_1    1
    x[1452]   c1313     100
    x[1453]   c337_1    1
    x[1453]   c1310     560
    x[1454]   c337_1    1
    x[1454]   c1311     560
    x[1455]   c339_1    1
    x[1455]   c1320     360
    x[1456]   c339_1    1
    x[1456]   c1315     360
    x[1457]   c339_1    1
    x[1457]   c1318     100
    x[1458]   c339_1    1
    x[1458]   c1319     100
    x[1459]   c339_1    1
    x[1459]   c1316     560
    x[1460]   c339_1    1
    x[1460]   c1317     560
    x[1461]   c341_1    1
    x[1461]   c1326     360
    x[1462]   c341_1    1
    x[1462]   c1321     360
    x[1463]   c341_1    1
    x[1463]   c1324     100
    x[1464]   c341_1    1
    x[1464]   c1325     100
    x[1465]   c341_1    1
    x[1465]   c1322     560
    x[1466]   c341_1    1
    x[1466]   c1323     560
    x[1467]   c343_1    1
    x[1467]   c1332     360
    x[1468]   c343_1    1
    x[1468]   c1327     360
    x[1469]   c343_1    1
    x[1469]   c1330     100
    x[1470]   c343_1    1
    x[1470]   c1331     100
    x[1471]   c343_1    1
    x[1471]   c1328     560
    x[1472]   c343_1    1
    x[1472]   c1329     560
    x[1473]   c345_1    1
    x[1473]   c1338     360
    x[1474]   c345_1    1
    x[1474]   c1333     360
    x[1475]   c345_1    1
    x[1475]   c1336     100
    x[1476]   c345_1    1
    x[1476]   c1337     100
    x[1477]   c345_1    1
    x[1477]   c1334     560
    x[1478]   c345_1    1
    x[1478]   c1335     560
    x[1479]   c347_1    1
    x[1479]   c1344     360
    x[1480]   c347_1    1
    x[1480]   c1339     360
    x[1481]   c347_1    1
    x[1481]   c1342     100
    x[1482]   c347_1    1
    x[1482]   c1343     100
    x[1483]   c347_1    1
    x[1483]   c1340     560
    x[1484]   c347_1    1
    x[1484]   c1341     560
    x[1485]   c349_1    1
    x[1485]   c1350     360
    x[1486]   c349_1    1
    x[1486]   c1345     360
    x[1487]   c349_1    1
    x[1487]   c1348     100
    x[1488]   c349_1    1
    x[1488]   c1349     100
    x[1489]   c349_1    1
    x[1489]   c1346     560
    x[1490]   c349_1    1
    x[1490]   c1347     560
    x[1491]   c351_1    1
    x[1491]   c1356     360
    x[1492]   c351_1    1
    x[1492]   c1351     360
    x[1493]   c351_1    1
    x[1493]   c1354     100
    x[1494]   c351_1    1
    x[1494]   c1355     100
    x[1495]   c351_1    1
    x[1495]   c1352     560
    x[1496]   c351_1    1
    x[1496]   c1353     560
    x[1497]   c353_1    1
    x[1497]   c1362     360
    x[1498]   c353_1    1
    x[1498]   c1357     360
    x[1499]   c353_1    1
    x[1499]   c1360     100
    x[1500]   c353_1    1
    x[1500]   c1361     100
    x[1501]   c353_1    1
    x[1501]   c1358     560
    x[1502]   c353_1    1
    x[1502]   c1359     560
    x[1503]   c355_1    1
    x[1503]   c1368     360
    x[1504]   c355_1    1
    x[1504]   c1363     360
    x[1505]   c355_1    1
    x[1505]   c1366     100
    x[1506]   c355_1    1
    x[1506]   c1367     100
    x[1507]   c355_1    1
    x[1507]   c1364     560
    x[1508]   c355_1    1
    x[1508]   c1365     560
    x[1509]   c357_1    1
    x[1509]   c1374     360
    x[1510]   c357_1    1
    x[1510]   c1369     360
    x[1511]   c357_1    1
    x[1511]   c1372     100
    x[1512]   c357_1    1
    x[1512]   c1373     100
    x[1513]   c357_1    1
    x[1513]   c1370     560
    x[1514]   c357_1    1
    x[1514]   c1371     560
    x[1515]   c359_1    1
    x[1515]   c1380     360
    x[1516]   c359_1    1
    x[1516]   c1375     360
    x[1517]   c359_1    1
    x[1517]   c1378     100
    x[1518]   c359_1    1
    x[1518]   c1379     100
    x[1519]   c359_1    1
    x[1519]   c1376     560
    x[1520]   c359_1    1
    x[1520]   c1377     560
    x[1521]   c361_1    1
    x[1521]   c1386     360
    x[1522]   c361_1    1
    x[1522]   c1381     360
    x[1523]   c361_1    1
    x[1523]   c1384     100
    x[1524]   c361_1    1
    x[1524]   c1385     100
    x[1525]   c361_1    1
    x[1525]   c1382     560
    x[1526]   c361_1    1
    x[1526]   c1383     560
    x[1527]   c363_1    1
    x[1527]   c1392     360
    x[1528]   c363_1    1
    x[1528]   c1387     360
    x[1529]   c363_1    1
    x[1529]   c1390     100
    x[1530]   c363_1    1
    x[1530]   c1391     100
    x[1531]   c363_1    1
    x[1531]   c1388     560
    x[1532]   c363_1    1
    x[1532]   c1389     560
    x[1533]   c365_1    1
    x[1533]   c1398     360
    x[1534]   c365_1    1
    x[1534]   c1393     360
    x[1535]   c365_1    1
    x[1535]   c1396     100
    x[1536]   c365_1    1
    x[1536]   c1397     100
    x[1537]   c365_1    1
    x[1537]   c1394     560
    x[1538]   c365_1    1
    x[1538]   c1395     560
    x[1539]   c367_1    1
    x[1539]   c1404     360
    x[1540]   c367_1    1
    x[1540]   c1399     360
    x[1541]   c367_1    1
    x[1541]   c1402     100
    x[1542]   c367_1    1
    x[1542]   c1403     100
    x[1543]   c367_1    1
    x[1543]   c1400     560
    x[1544]   c367_1    1
    x[1544]   c1401     560
    x[1545]   c369_1    1
    x[1545]   c1410     360
    x[1546]   c369_1    1
    x[1546]   c1405     360
    x[1547]   c369_1    1
    x[1547]   c1408     100
    x[1548]   c369_1    1
    x[1548]   c1409     100
    x[1549]   c369_1    1
    x[1549]   c1406     560
    x[1550]   c369_1    1
    x[1550]   c1407     560
    x[1551]   c370_1    1
    x[1551]   c1416     360
    x[1552]   c370_1    1
    x[1552]   c1411     360
    x[1553]   c370_1    1
    x[1553]   c1414     100
    x[1554]   c370_1    1
    x[1554]   c1415     100
    x[1555]   c370_1    1
    x[1555]   c1412     560
    x[1556]   c370_1    1
    x[1556]   c1413     560
    x[1557]   c371_1    1
    x[1557]   c1422     360
    x[1558]   c371_1    1
    x[1558]   c1417     360
    x[1559]   c371_1    1
    x[1559]   c1420     100
    x[1560]   c371_1    1
    x[1560]   c1421     100
    x[1561]   c371_1    1
    x[1561]   c1418     560
    x[1562]   c371_1    1
    x[1562]   c1419     560
    x[1563]   c372_1    1
    x[1563]   c1428     360
    x[1564]   c372_1    1
    x[1564]   c1423     360
    x[1565]   c372_1    1
    x[1565]   c1426     100
    x[1566]   c372_1    1
    x[1566]   c1427     100
    x[1567]   c372_1    1
    x[1567]   c1424     560
    x[1568]   c372_1    1
    x[1568]   c1425     560
    x[1569]   c373_1    1
    x[1569]   c1434     360
    x[1570]   c373_1    1
    x[1570]   c1429     360
    x[1571]   c373_1    1
    x[1571]   c1432     100
    x[1572]   c373_1    1
    x[1572]   c1433     100
    x[1573]   c373_1    1
    x[1573]   c1430     560
    x[1574]   c373_1    1
    x[1574]   c1431     560
    x[1575]   c374_1    1
    x[1575]   c1440     360
    x[1576]   c374_1    1
    x[1576]   c1435     360
    x[1577]   c374_1    1
    x[1577]   c1438     100
    x[1578]   c374_1    1
    x[1578]   c1439     100
    x[1579]   c374_1    1
    x[1579]   c1436     560
    x[1580]   c374_1    1
    x[1580]   c1437     560
    x[1581]   c375_1    1
    x[1581]   c1446     360
    x[1582]   c375_1    1
    x[1582]   c1441     360
    x[1583]   c375_1    1
    x[1583]   c1444     100
    x[1584]   c375_1    1
    x[1584]   c1445     100
    x[1585]   c375_1    1
    x[1585]   c1442     560
    x[1586]   c375_1    1
    x[1586]   c1443     560
    x[1587]   c376_1    1
    x[1587]   c1452     360
    x[1588]   c376_1    1
    x[1588]   c1447     360
    x[1589]   c376_1    1
    x[1589]   c1450     100
    x[1590]   c376_1    1
    x[1590]   c1451     100
    x[1591]   c376_1    1
    x[1591]   c1448     560
    x[1592]   c376_1    1
    x[1592]   c1449     560
    x[1593]   c377_1    1
    x[1593]   c918_1    -1
    x[1593]   c1458     360
    x[1594]   c377_1    1
    x[1594]   c1453     360
    x[1595]   c377_1    1
    x[1595]   c1456     100
    x[1596]   c377_1    1
    x[1596]   c1457     100
    x[1597]   c377_1    1
    x[1597]   c1454     560
    x[1598]   c377_1    1
    x[1598]   c1455     560
    x[1599]   c378_1    1
    x[1599]   c1464     360
    x[1600]   c378_1    1
    x[1600]   c1459     360
    x[1601]   c378_1    1
    x[1601]   c1462     100
    x[1602]   c378_1    1
    x[1602]   c1463     100
    x[1603]   c378_1    1
    x[1603]   c1460     560
    x[1604]   c378_1    1
    x[1604]   c1461     560
    x[1605]   c379_1    1
    x[1605]   c1470     360
    x[1606]   c379_1    1
    x[1606]   c1465     360
    x[1607]   c379_1    1
    x[1607]   c1468     100
    x[1608]   c379_1    1
    x[1608]   c1469     100
    x[1609]   c379_1    1
    x[1609]   c1466     560
    x[1610]   c379_1    1
    x[1610]   c1467     560
    x[1611]   c381_1    1
    x[1611]   c1476     360
    x[1612]   c381_1    1
    x[1612]   c1471     360
    x[1613]   c381_1    1
    x[1613]   c1474     100
    x[1614]   c381_1    1
    x[1614]   c1475     100
    x[1615]   c381_1    1
    x[1615]   c1472     560
    x[1616]   c381_1    1
    x[1616]   c1473     560
    x[1617]   c383_1    1
    x[1617]   c1482     360
    x[1618]   c383_1    1
    x[1618]   c1477     360
    x[1619]   c383_1    1
    x[1619]   c1480     100
    x[1620]   c383_1    1
    x[1620]   c1481     100
    x[1621]   c383_1    1
    x[1621]   c1478     560
    x[1622]   c383_1    1
    x[1622]   c1479     560
    x[1623]   c385_1    1
    x[1623]   c1488     360
    x[1624]   c385_1    1
    x[1624]   c1483     360
    x[1625]   c385_1    1
    x[1625]   c1486     100
    x[1626]   c385_1    1
    x[1626]   c1487     100
    x[1627]   c385_1    1
    x[1627]   c1484     560
    x[1628]   c385_1    1
    x[1628]   c1485     560
    x[1629]   c387_1    1
    x[1629]   c1494     360
    x[1630]   c387_1    1
    x[1630]   c1489     360
    x[1631]   c387_1    1
    x[1631]   c1492     100
    x[1632]   c387_1    1
    x[1632]   c1493     100
    x[1633]   c387_1    1
    x[1633]   c1490     560
    x[1634]   c387_1    1
    x[1634]   c1491     560
    x[1635]   c389_1    1
    x[1635]   c1500     360
    x[1636]   c389_1    1
    x[1636]   c1495     360
    x[1637]   c389_1    1
    x[1637]   c1498     100
    x[1638]   c389_1    1
    x[1638]   c1499     100
    x[1639]   c389_1    1
    x[1639]   c1496     560
    x[1640]   c389_1    1
    x[1640]   c1497     560
    x[1641]   c391_1    1
    x[1641]   c1506     360
    x[1642]   c391_1    1
    x[1642]   c1501     360
    x[1643]   c391_1    1
    x[1643]   c1504     100
    x[1644]   c391_1    1
    x[1644]   c1505     100
    x[1645]   c391_1    1
    x[1645]   c1502     560
    x[1646]   c391_1    1
    x[1646]   c1503     560
    x[1647]   c393_1    1
    x[1647]   c1512     360
    x[1648]   c393_1    1
    x[1648]   c1507     360
    x[1649]   c393_1    1
    x[1649]   c1510     100
    x[1650]   c393_1    1
    x[1650]   c1511     100
    x[1651]   c393_1    1
    x[1651]   c1508     560
    x[1652]   c393_1    1
    x[1652]   c1509     560
    x[1653]   c395_1    1
    x[1653]   c1518     360
    x[1654]   c395_1    1
    x[1654]   c1513     360
    x[1655]   c395_1    1
    x[1655]   c1516     100
    x[1656]   c395_1    1
    x[1656]   c1517     100
    x[1657]   c395_1    1
    x[1657]   c1514     560
    x[1658]   c395_1    1
    x[1658]   c1515     560
    x[1659]   c397_1    1
    x[1659]   c1524     360
    x[1660]   c397_1    1
    x[1660]   c1519     360
    x[1661]   c397_1    1
    x[1661]   c1522     100
    x[1662]   c397_1    1
    x[1662]   c1523     100
    x[1663]   c397_1    1
    x[1663]   c1520     560
    x[1664]   c397_1    1
    x[1664]   c1521     560
    x[1665]   c399_1    1
    x[1665]   c1530     360
    x[1666]   c399_1    1
    x[1666]   c1525     360
    x[1667]   c399_1    1
    x[1667]   c1528     100
    x[1668]   c399_1    1
    x[1668]   c1529     100
    x[1669]   c399_1    1
    x[1669]   c1526     560
    x[1670]   c399_1    1
    x[1670]   c1527     560
    x[1671]   c401_1    1
    x[1671]   c1536     360
    x[1672]   c401_1    1
    x[1672]   c1531     360
    x[1673]   c401_1    1
    x[1673]   c1534     100
    x[1674]   c401_1    1
    x[1674]   c1535     100
    x[1675]   c401_1    1
    x[1675]   c1532     560
    x[1676]   c401_1    1
    x[1676]   c1533     560
    x[1677]   c403_1    1
    x[1677]   c1542     360
    x[1678]   c403_1    1
    x[1678]   c1537     360
    x[1679]   c403_1    1
    x[1679]   c1540     100
    x[1680]   c403_1    1
    x[1680]   c1541     100
    x[1681]   c403_1    1
    x[1681]   c1538     560
    x[1682]   c403_1    1
    x[1682]   c1539     560
    x[1683]   c405_1    1
    x[1683]   c1548     360
    x[1684]   c405_1    1
    x[1684]   c1543     360
    x[1685]   c405_1    1
    x[1685]   c1546     100
    x[1686]   c405_1    1
    x[1686]   c1547     100
    x[1687]   c405_1    1
    x[1687]   c1544     560
    x[1688]   c405_1    1
    x[1688]   c1545     560
    x[1689]   c407_1    1
    x[1689]   c1554     360
    x[1690]   c407_1    1
    x[1690]   c1549     360
    x[1691]   c407_1    1
    x[1691]   c1552     100
    x[1692]   c407_1    1
    x[1692]   c1553     100
    x[1693]   c407_1    1
    x[1693]   c1550     560
    x[1694]   c407_1    1
    x[1694]   c1551     560
    x[1695]   c409_1    1
    x[1695]   c1560     360
    x[1696]   c409_1    1
    x[1696]   c1555     360
    x[1697]   c409_1    1
    x[1697]   c1558     100
    x[1698]   c409_1    1
    x[1698]   c1559     100
    x[1699]   c409_1    1
    x[1699]   c1556     560
    x[1700]   c409_1    1
    x[1700]   c1557     560
    x[1701]   c411_1    1
    x[1701]   c1566     360
    x[1702]   c411_1    1
    x[1702]   c1561     360
    x[1703]   c411_1    1
    x[1703]   c1564     100
    x[1704]   c411_1    1
    x[1704]   c1565     100
    x[1705]   c411_1    1
    x[1705]   c1562     560
    x[1706]   c411_1    1
    x[1706]   c1563     560
    x[1707]   c412_1    1
    x[1707]   c1572     360
    x[1708]   c412_1    1
    x[1708]   c1567     360
    x[1709]   c412_1    1
    x[1709]   c1570     100
    x[1710]   c412_1    1
    x[1710]   c1571     100
    x[1711]   c412_1    1
    x[1711]   c1568     560
    x[1712]   c412_1    1
    x[1712]   c1569     560
    x[1713]   c413_1    1
    x[1713]   c1578     360
    x[1714]   c413_1    1
    x[1714]   c1573     360
    x[1715]   c413_1    1
    x[1715]   c1576     100
    x[1716]   c413_1    1
    x[1716]   c1577     100
    x[1717]   c413_1    1
    x[1717]   c1574     560
    x[1718]   c413_1    1
    x[1718]   c1575     560
    x[1719]   c414_1    1
    x[1719]   c1584     360
    x[1720]   c414_1    1
    x[1720]   c1579     360
    x[1721]   c414_1    1
    x[1721]   c1582     100
    x[1722]   c414_1    1
    x[1722]   c1583     100
    x[1723]   c414_1    1
    x[1723]   c1580     560
    x[1724]   c414_1    1
    x[1724]   c1581     560
    x[1725]   c415_1    1
    x[1725]   c1590     360
    x[1726]   c415_1    1
    x[1726]   c1585     360
    x[1727]   c415_1    1
    x[1727]   c1588     100
    x[1728]   c415_1    1
    x[1728]   c1589     100
    x[1729]   c415_1    1
    x[1729]   c1586     560
    x[1730]   c415_1    1
    x[1730]   c1587     560
    x[1731]   c416_1    1
    x[1731]   c1596     360
    x[1732]   c416_1    1
    x[1732]   c1591     360
    x[1733]   c416_1    1
    x[1733]   c1594     100
    x[1734]   c416_1    1
    x[1734]   c1595     100
    x[1735]   c416_1    1
    x[1735]   c1592     560
    x[1736]   c416_1    1
    x[1736]   c1593     560
    x[1737]   c417_1    1
    x[1737]   c1602     360
    x[1738]   c417_1    1
    x[1738]   c1597     360
    x[1739]   c417_1    1
    x[1739]   c1600     100
    x[1740]   c417_1    1
    x[1740]   c1601     100
    x[1741]   c417_1    1
    x[1741]   c1598     560
    x[1742]   c417_1    1
    x[1742]   c1599     560
    x[1743]   c418_1    1
    x[1743]   c1608     360
    x[1744]   c418_1    1
    x[1744]   c1603     360
    x[1745]   c418_1    1
    x[1745]   c1606     100
    x[1746]   c418_1    1
    x[1746]   c1607     100
    x[1747]   c418_1    1
    x[1747]   c1604     560
    x[1748]   c418_1    1
    x[1748]   c1605     560
    x[1749]   c419_1    1
    x[1749]   c919_1    -1
    x[1749]   c1614     360
    x[1750]   c419_1    1
    x[1750]   c1609     360
    x[1751]   c419_1    1
    x[1751]   c1612     100
    x[1752]   c419_1    1
    x[1752]   c1613     100
    x[1753]   c419_1    1
    x[1753]   c1610     560
    x[1754]   c419_1    1
    x[1754]   c1611     560
    x[1755]   c420_1    1
    x[1755]   c1620     360
    x[1756]   c420_1    1
    x[1756]   c1615     360
    x[1757]   c420_1    1
    x[1757]   c1618     100
    x[1758]   c420_1    1
    x[1758]   c1619     100
    x[1759]   c420_1    1
    x[1759]   c1616     560
    x[1760]   c420_1    1
    x[1760]   c1617     560
    x[1761]   c421_1    1
    x[1761]   c1626     360
    x[1762]   c421_1    1
    x[1762]   c1621     360
    x[1763]   c421_1    1
    x[1763]   c1624     100
    x[1764]   c421_1    1
    x[1764]   c1625     100
    x[1765]   c421_1    1
    x[1765]   c1622     560
    x[1766]   c421_1    1
    x[1766]   c1623     560
    x[1767]   c423_1    1
    x[1767]   c1632     360
    x[1768]   c423_1    1
    x[1768]   c1627     360
    x[1769]   c423_1    1
    x[1769]   c1630     100
    x[1770]   c423_1    1
    x[1770]   c1631     100
    x[1771]   c423_1    1
    x[1771]   c1628     560
    x[1772]   c423_1    1
    x[1772]   c1629     560
    x[1773]   c425_1    1
    x[1773]   c1638     360
    x[1774]   c425_1    1
    x[1774]   c1633     360
    x[1775]   c425_1    1
    x[1775]   c1636     100
    x[1776]   c425_1    1
    x[1776]   c1637     100
    x[1777]   c425_1    1
    x[1777]   c1634     560
    x[1778]   c425_1    1
    x[1778]   c1635     560
    x[1779]   c427_1    1
    x[1779]   c1644     360
    x[1780]   c427_1    1
    x[1780]   c1639     360
    x[1781]   c427_1    1
    x[1781]   c1642     100
    x[1782]   c427_1    1
    x[1782]   c1643     100
    x[1783]   c427_1    1
    x[1783]   c1640     560
    x[1784]   c427_1    1
    x[1784]   c1641     560
    x[1785]   c429_1    1
    x[1785]   c1650     360
    x[1786]   c429_1    1
    x[1786]   c1645     360
    x[1787]   c429_1    1
    x[1787]   c1648     100
    x[1788]   c429_1    1
    x[1788]   c1649     100
    x[1789]   c429_1    1
    x[1789]   c1646     560
    x[1790]   c429_1    1
    x[1790]   c1647     560
    x[1791]   c431_1    1
    x[1791]   c1656     360
    x[1792]   c431_1    1
    x[1792]   c1651     360
    x[1793]   c431_1    1
    x[1793]   c1654     100
    x[1794]   c431_1    1
    x[1794]   c1655     100
    x[1795]   c431_1    1
    x[1795]   c1652     560
    x[1796]   c431_1    1
    x[1796]   c1653     560
    x[1797]   c433_1    1
    x[1797]   c1662     360
    x[1798]   c433_1    1
    x[1798]   c1657     360
    x[1799]   c433_1    1
    x[1799]   c1660     100
    x[1800]   c433_1    1
    x[1800]   c1661     100
    x[1801]   c433_1    1
    x[1801]   c1658     560
    x[1802]   c433_1    1
    x[1802]   c1659     560
    x[1803]   c435_1    1
    x[1803]   c1668     360
    x[1804]   c435_1    1
    x[1804]   c1663     360
    x[1805]   c435_1    1
    x[1805]   c1666     100
    x[1806]   c435_1    1
    x[1806]   c1667     100
    x[1807]   c435_1    1
    x[1807]   c1664     560
    x[1808]   c435_1    1
    x[1808]   c1665     560
    x[1809]   c437_1    1
    x[1809]   c1674     360
    x[1810]   c437_1    1
    x[1810]   c1669     360
    x[1811]   c437_1    1
    x[1811]   c1672     100
    x[1812]   c437_1    1
    x[1812]   c1673     100
    x[1813]   c437_1    1
    x[1813]   c1670     560
    x[1814]   c437_1    1
    x[1814]   c1671     560
    x[1815]   c439_1    1
    x[1815]   c1680     360
    x[1816]   c439_1    1
    x[1816]   c1675     360
    x[1817]   c439_1    1
    x[1817]   c1678     100
    x[1818]   c439_1    1
    x[1818]   c1679     100
    x[1819]   c439_1    1
    x[1819]   c1676     560
    x[1820]   c439_1    1
    x[1820]   c1677     560
    x[1821]   c441_1    1
    x[1821]   c1686     360
    x[1822]   c441_1    1
    x[1822]   c1681     360
    x[1823]   c441_1    1
    x[1823]   c1684     100
    x[1824]   c441_1    1
    x[1824]   c1685     100
    x[1825]   c441_1    1
    x[1825]   c1682     560
    x[1826]   c441_1    1
    x[1826]   c1683     560
    x[1827]   c443_1    1
    x[1827]   c1692     360
    x[1828]   c443_1    1
    x[1828]   c1687     360
    x[1829]   c443_1    1
    x[1829]   c1690     100
    x[1830]   c443_1    1
    x[1830]   c1691     100
    x[1831]   c443_1    1
    x[1831]   c1688     560
    x[1832]   c443_1    1
    x[1832]   c1689     560
    x[1833]   c445_1    1
    x[1833]   c1698     360
    x[1834]   c445_1    1
    x[1834]   c1693     360
    x[1835]   c445_1    1
    x[1835]   c1696     100
    x[1836]   c445_1    1
    x[1836]   c1697     100
    x[1837]   c445_1    1
    x[1837]   c1694     560
    x[1838]   c445_1    1
    x[1838]   c1695     560
    x[1839]   c447_1    1
    x[1839]   c1704     360
    x[1840]   c447_1    1
    x[1840]   c1699     360
    x[1841]   c447_1    1
    x[1841]   c1702     100
    x[1842]   c447_1    1
    x[1842]   c1703     100
    x[1843]   c447_1    1
    x[1843]   c1700     560
    x[1844]   c447_1    1
    x[1844]   c1701     560
    x[1845]   c449_1    1
    x[1845]   c1710     360
    x[1846]   c449_1    1
    x[1846]   c1705     360
    x[1847]   c449_1    1
    x[1847]   c1708     100
    x[1848]   c449_1    1
    x[1848]   c1709     100
    x[1849]   c449_1    1
    x[1849]   c1706     560
    x[1850]   c449_1    1
    x[1850]   c1707     560
    x[1851]   c451_1    1
    x[1851]   c1716     360
    x[1852]   c451_1    1
    x[1852]   c1711     360
    x[1853]   c451_1    1
    x[1853]   c1714     100
    x[1854]   c451_1    1
    x[1854]   c1715     100
    x[1855]   c451_1    1
    x[1855]   c1712     560
    x[1856]   c451_1    1
    x[1856]   c1713     560
    x[1857]   c452_1    1
    x[1857]   c1722     360
    x[1858]   c452_1    1
    x[1858]   c1717     360
    x[1859]   c452_1    1
    x[1859]   c1720     100
    x[1860]   c452_1    1
    x[1860]   c1721     100
    x[1861]   c452_1    1
    x[1861]   c1718     560
    x[1862]   c452_1    1
    x[1862]   c1719     560
    x[1863]   c453_1    1
    x[1863]   c1728     360
    x[1864]   c453_1    1
    x[1864]   c1723     360
    x[1865]   c453_1    1
    x[1865]   c1726     100
    x[1866]   c453_1    1
    x[1866]   c1727     100
    x[1867]   c453_1    1
    x[1867]   c1724     560
    x[1868]   c453_1    1
    x[1868]   c1725     560
    x[1869]   c454_1    1
    x[1869]   c1734     360
    x[1870]   c454_1    1
    x[1870]   c1729     360
    x[1871]   c454_1    1
    x[1871]   c1732     100
    x[1872]   c454_1    1
    x[1872]   c1733     100
    x[1873]   c454_1    1
    x[1873]   c1730     560
    x[1874]   c454_1    1
    x[1874]   c1731     560
    x[1875]   c455_1    1
    x[1875]   c1740     360
    x[1876]   c455_1    1
    x[1876]   c1735     360
    x[1877]   c455_1    1
    x[1877]   c1738     100
    x[1878]   c455_1    1
    x[1878]   c1739     100
    x[1879]   c455_1    1
    x[1879]   c1736     560
    x[1880]   c455_1    1
    x[1880]   c1737     560
    x[1881]   c456_1    1
    x[1881]   c1746     360
    x[1882]   c456_1    1
    x[1882]   c1741     360
    x[1883]   c456_1    1
    x[1883]   c1744     100
    x[1884]   c456_1    1
    x[1884]   c1745     100
    x[1885]   c456_1    1
    x[1885]   c1742     560
    x[1886]   c456_1    1
    x[1886]   c1743     560
    x[1887]   c457_1    1
    x[1887]   c1752     360
    x[1888]   c457_1    1
    x[1888]   c1747     360
    x[1889]   c457_1    1
    x[1889]   c1750     100
    x[1890]   c457_1    1
    x[1890]   c1751     100
    x[1891]   c457_1    1
    x[1891]   c1748     560
    x[1892]   c457_1    1
    x[1892]   c1749     560
    x[1893]   c458_1    1
    x[1893]   c1758     360
    x[1894]   c458_1    1
    x[1894]   c1753     360
    x[1895]   c458_1    1
    x[1895]   c1756     100
    x[1896]   c458_1    1
    x[1896]   c1757     100
    x[1897]   c458_1    1
    x[1897]   c1754     560
    x[1898]   c458_1    1
    x[1898]   c1755     560
    x[1899]   c459_1    1
    x[1899]   c920_1    -1
    x[1899]   c1764     360
    x[1900]   c459_1    1
    x[1900]   c1759     360
    x[1901]   c459_1    1
    x[1901]   c1762     100
    x[1902]   c459_1    1
    x[1902]   c1763     100
    x[1903]   c459_1    1
    x[1903]   c1760     560
    x[1904]   c459_1    1
    x[1904]   c1761     560
    x[1905]   c460_1    1
    x[1905]   c1770     360
    x[1906]   c460_1    1
    x[1906]   c1765     360
    x[1907]   c460_1    1
    x[1907]   c1768     100
    x[1908]   c460_1    1
    x[1908]   c1769     100
    x[1909]   c460_1    1
    x[1909]   c1766     560
    x[1910]   c460_1    1
    x[1910]   c1767     560
    x[1911]   c461_1    1
    x[1911]   c1776     360
    x[1912]   c461_1    1
    x[1912]   c1771     360
    x[1913]   c461_1    1
    x[1913]   c1774     100
    x[1914]   c461_1    1
    x[1914]   c1775     100
    x[1915]   c461_1    1
    x[1915]   c1772     560
    x[1916]   c461_1    1
    x[1916]   c1773     560
    x[1917]   c463_1    1
    x[1917]   c1782     360
    x[1918]   c463_1    1
    x[1918]   c1777     360
    x[1919]   c463_1    1
    x[1919]   c1780     100
    x[1920]   c463_1    1
    x[1920]   c1781     100
    x[1921]   c463_1    1
    x[1921]   c1778     560
    x[1922]   c463_1    1
    x[1922]   c1779     560
    x[1923]   c465_1    1
    x[1923]   c1788     360
    x[1924]   c465_1    1
    x[1924]   c1783     360
    x[1925]   c465_1    1
    x[1925]   c1786     100
    x[1926]   c465_1    1
    x[1926]   c1787     100
    x[1927]   c465_1    1
    x[1927]   c1784     560
    x[1928]   c465_1    1
    x[1928]   c1785     560
    x[1929]   c467_1    1
    x[1929]   c1794     360
    x[1930]   c467_1    1
    x[1930]   c1789     360
    x[1931]   c467_1    1
    x[1931]   c1792     100
    x[1932]   c467_1    1
    x[1932]   c1793     100
    x[1933]   c467_1    1
    x[1933]   c1790     560
    x[1934]   c467_1    1
    x[1934]   c1791     560
    x[1935]   c469_1    1
    x[1935]   c1800     360
    x[1936]   c469_1    1
    x[1936]   c1795     360
    x[1937]   c469_1    1
    x[1937]   c1798     100
    x[1938]   c469_1    1
    x[1938]   c1799     100
    x[1939]   c469_1    1
    x[1939]   c1796     560
    x[1940]   c469_1    1
    x[1940]   c1797     560
    x[1941]   c471_1    1
    x[1941]   c1806     360
    x[1942]   c471_1    1
    x[1942]   c1801     360
    x[1943]   c471_1    1
    x[1943]   c1804     100
    x[1944]   c471_1    1
    x[1944]   c1805     100
    x[1945]   c471_1    1
    x[1945]   c1802     560
    x[1946]   c471_1    1
    x[1946]   c1803     560
    x[1947]   c473_1    1
    x[1947]   c1812     360
    x[1948]   c473_1    1
    x[1948]   c1807     360
    x[1949]   c473_1    1
    x[1949]   c1810     100
    x[1950]   c473_1    1
    x[1950]   c1811     100
    x[1951]   c473_1    1
    x[1951]   c1808     560
    x[1952]   c473_1    1
    x[1952]   c1809     560
    x[1953]   c475_1    1
    x[1953]   c1818     360
    x[1954]   c475_1    1
    x[1954]   c1813     360
    x[1955]   c475_1    1
    x[1955]   c1816     100
    x[1956]   c475_1    1
    x[1956]   c1817     100
    x[1957]   c475_1    1
    x[1957]   c1814     560
    x[1958]   c475_1    1
    x[1958]   c1815     560
    x[1959]   c477_1    1
    x[1959]   c1824     360
    x[1960]   c477_1    1
    x[1960]   c1819     360
    x[1961]   c477_1    1
    x[1961]   c1822     100
    x[1962]   c477_1    1
    x[1962]   c1823     100
    x[1963]   c477_1    1
    x[1963]   c1820     560
    x[1964]   c477_1    1
    x[1964]   c1821     560
    x[1965]   c479_1    1
    x[1965]   c1830     360
    x[1966]   c479_1    1
    x[1966]   c1825     360
    x[1967]   c479_1    1
    x[1967]   c1828     100
    x[1968]   c479_1    1
    x[1968]   c1829     100
    x[1969]   c479_1    1
    x[1969]   c1826     560
    x[1970]   c479_1    1
    x[1970]   c1827     560
    x[1971]   c481_1    1
    x[1971]   c1836     360
    x[1972]   c481_1    1
    x[1972]   c1831     360
    x[1973]   c481_1    1
    x[1973]   c1834     100
    x[1974]   c481_1    1
    x[1974]   c1835     100
    x[1975]   c481_1    1
    x[1975]   c1832     560
    x[1976]   c481_1    1
    x[1976]   c1833     560
    x[1977]   c483_1    1
    x[1977]   c1842     360
    x[1978]   c483_1    1
    x[1978]   c1837     360
    x[1979]   c483_1    1
    x[1979]   c1840     100
    x[1980]   c483_1    1
    x[1980]   c1841     100
    x[1981]   c483_1    1
    x[1981]   c1838     560
    x[1982]   c483_1    1
    x[1982]   c1839     560
    x[1983]   c485_1    1
    x[1983]   c1848     360
    x[1984]   c485_1    1
    x[1984]   c1843     360
    x[1985]   c485_1    1
    x[1985]   c1846     100
    x[1986]   c485_1    1
    x[1986]   c1847     100
    x[1987]   c485_1    1
    x[1987]   c1844     560
    x[1988]   c485_1    1
    x[1988]   c1845     560
    x[1989]   c487_1    1
    x[1989]   c1854     360
    x[1990]   c487_1    1
    x[1990]   c1849     360
    x[1991]   c487_1    1
    x[1991]   c1852     100
    x[1992]   c487_1    1
    x[1992]   c1853     100
    x[1993]   c487_1    1
    x[1993]   c1850     560
    x[1994]   c487_1    1
    x[1994]   c1851     560
    x[1995]   c489_1    1
    x[1995]   c1860     360
    x[1996]   c489_1    1
    x[1996]   c1855     360
    x[1997]   c489_1    1
    x[1997]   c1858     100
    x[1998]   c489_1    1
    x[1998]   c1859     100
    x[1999]   c489_1    1
    x[1999]   c1856     560
    x[2000]   c489_1    1
    x[2000]   c1857     560
    x[2001]   c490_1    1
    x[2001]   c1866     360
    x[2002]   c490_1    1
    x[2002]   c1861     360
    x[2003]   c490_1    1
    x[2003]   c1864     100
    x[2004]   c490_1    1
    x[2004]   c1865     100
    x[2005]   c490_1    1
    x[2005]   c1862     560
    x[2006]   c490_1    1
    x[2006]   c1863     560
    x[2007]   c491_1    1
    x[2007]   c1872     360
    x[2008]   c491_1    1
    x[2008]   c1867     360
    x[2009]   c491_1    1
    x[2009]   c1870     100
    x[2010]   c491_1    1
    x[2010]   c1871     100
    x[2011]   c491_1    1
    x[2011]   c1868     560
    x[2012]   c491_1    1
    x[2012]   c1869     560
    x[2013]   c492_1    1
    x[2013]   c1878     360
    x[2014]   c492_1    1
    x[2014]   c1873     360
    x[2015]   c492_1    1
    x[2015]   c1876     100
    x[2016]   c492_1    1
    x[2016]   c1877     100
    x[2017]   c492_1    1
    x[2017]   c1874     560
    x[2018]   c492_1    1
    x[2018]   c1875     560
    x[2019]   c493_1    1
    x[2019]   c1884     360
    x[2020]   c493_1    1
    x[2020]   c1879     360
    x[2021]   c493_1    1
    x[2021]   c1882     100
    x[2022]   c493_1    1
    x[2022]   c1883     100
    x[2023]   c493_1    1
    x[2023]   c1880     560
    x[2024]   c493_1    1
    x[2024]   c1881     560
    x[2025]   c494_1    1
    x[2025]   c1890     360
    x[2026]   c494_1    1
    x[2026]   c1885     360
    x[2027]   c494_1    1
    x[2027]   c1888     100
    x[2028]   c494_1    1
    x[2028]   c1889     100
    x[2029]   c494_1    1
    x[2029]   c1886     560
    x[2030]   c494_1    1
    x[2030]   c1887     560
    x[2031]   c495_1    1
    x[2031]   c1896     360
    x[2032]   c495_1    1
    x[2032]   c1891     360
    x[2033]   c495_1    1
    x[2033]   c1894     100
    x[2034]   c495_1    1
    x[2034]   c1895     100
    x[2035]   c495_1    1
    x[2035]   c1892     560
    x[2036]   c495_1    1
    x[2036]   c1893     560
    x[2037]   c496_1    1
    x[2037]   c1902     360
    x[2038]   c496_1    1
    x[2038]   c1897     360
    x[2039]   c496_1    1
    x[2039]   c1900     100
    x[2040]   c496_1    1
    x[2040]   c1901     100
    x[2041]   c496_1    1
    x[2041]   c1898     560
    x[2042]   c496_1    1
    x[2042]   c1899     560
    x[2043]   c497_1    1
    x[2043]   c921_1    -1
    x[2043]   c1908     360
    x[2044]   c497_1    1
    x[2044]   c1903     360
    x[2045]   c497_1    1
    x[2045]   c1906     100
    x[2046]   c497_1    1
    x[2046]   c1907     100
    x[2047]   c497_1    1
    x[2047]   c1904     560
    x[2048]   c497_1    1
    x[2048]   c1905     560
    x[2049]   c498_1    1
    x[2049]   c1914     360
    x[2050]   c498_1    1
    x[2050]   c1909     360
    x[2051]   c498_1    1
    x[2051]   c1912     100
    x[2052]   c498_1    1
    x[2052]   c1913     100
    x[2053]   c498_1    1
    x[2053]   c1910     560
    x[2054]   c498_1    1
    x[2054]   c1911     560
    x[2055]   c499_1    1
    x[2055]   c1920     360
    x[2056]   c499_1    1
    x[2056]   c1915     360
    x[2057]   c499_1    1
    x[2057]   c1918     100
    x[2058]   c499_1    1
    x[2058]   c1919     100
    x[2059]   c499_1    1
    x[2059]   c1916     560
    x[2060]   c499_1    1
    x[2060]   c1917     560
    x[2061]   c501_1    1
    x[2061]   c1926     360
    x[2062]   c501_1    1
    x[2062]   c1921     360
    x[2063]   c501_1    1
    x[2063]   c1924     100
    x[2064]   c501_1    1
    x[2064]   c1925     100
    x[2065]   c501_1    1
    x[2065]   c1922     560
    x[2066]   c501_1    1
    x[2066]   c1923     560
    x[2067]   c503_1    1
    x[2067]   c1932     360
    x[2068]   c503_1    1
    x[2068]   c1927     360
    x[2069]   c503_1    1
    x[2069]   c1930     100
    x[2070]   c503_1    1
    x[2070]   c1931     100
    x[2071]   c503_1    1
    x[2071]   c1928     560
    x[2072]   c503_1    1
    x[2072]   c1929     560
    x[2073]   c505_1    1
    x[2073]   c1938     360
    x[2074]   c505_1    1
    x[2074]   c1933     360
    x[2075]   c505_1    1
    x[2075]   c1936     100
    x[2076]   c505_1    1
    x[2076]   c1937     100
    x[2077]   c505_1    1
    x[2077]   c1934     560
    x[2078]   c505_1    1
    x[2078]   c1935     560
    x[2079]   c507_1    1
    x[2079]   c1944     360
    x[2080]   c507_1    1
    x[2080]   c1939     360
    x[2081]   c507_1    1
    x[2081]   c1942     100
    x[2082]   c507_1    1
    x[2082]   c1943     100
    x[2083]   c507_1    1
    x[2083]   c1940     560
    x[2084]   c507_1    1
    x[2084]   c1941     560
    x[2085]   c509_1    1
    x[2085]   c1950     360
    x[2086]   c509_1    1
    x[2086]   c1945     360
    x[2087]   c509_1    1
    x[2087]   c1948     100
    x[2088]   c509_1    1
    x[2088]   c1949     100
    x[2089]   c509_1    1
    x[2089]   c1946     560
    x[2090]   c509_1    1
    x[2090]   c1947     560
    x[2091]   c511_1    1
    x[2091]   c1956     360
    x[2092]   c511_1    1
    x[2092]   c1951     360
    x[2093]   c511_1    1
    x[2093]   c1954     100
    x[2094]   c511_1    1
    x[2094]   c1955     100
    x[2095]   c511_1    1
    x[2095]   c1952     560
    x[2096]   c511_1    1
    x[2096]   c1953     560
    x[2097]   c513_1    1
    x[2097]   c1962     360
    x[2098]   c513_1    1
    x[2098]   c1957     360
    x[2099]   c513_1    1
    x[2099]   c1960     100
    x[2100]   c513_1    1
    x[2100]   c1961     100
    x[2101]   c513_1    1
    x[2101]   c1958     560
    x[2102]   c513_1    1
    x[2102]   c1959     560
    x[2103]   c515_1    1
    x[2103]   c1968     360
    x[2104]   c515_1    1
    x[2104]   c1963     360
    x[2105]   c515_1    1
    x[2105]   c1966     100
    x[2106]   c515_1    1
    x[2106]   c1967     100
    x[2107]   c515_1    1
    x[2107]   c1964     560
    x[2108]   c515_1    1
    x[2108]   c1965     560
    x[2109]   c517_1    1
    x[2109]   c1974     360
    x[2110]   c517_1    1
    x[2110]   c1969     360
    x[2111]   c517_1    1
    x[2111]   c1972     100
    x[2112]   c517_1    1
    x[2112]   c1973     100
    x[2113]   c517_1    1
    x[2113]   c1970     560
    x[2114]   c517_1    1
    x[2114]   c1971     560
    x[2115]   c519_1    1
    x[2115]   c1980     360
    x[2116]   c519_1    1
    x[2116]   c1975     360
    x[2117]   c519_1    1
    x[2117]   c1978     100
    x[2118]   c519_1    1
    x[2118]   c1979     100
    x[2119]   c519_1    1
    x[2119]   c1976     560
    x[2120]   c519_1    1
    x[2120]   c1977     560
    x[2121]   c521_1    1
    x[2121]   c1986     360
    x[2122]   c521_1    1
    x[2122]   c1981     360
    x[2123]   c521_1    1
    x[2123]   c1984     100
    x[2124]   c521_1    1
    x[2124]   c1985     100
    x[2125]   c521_1    1
    x[2125]   c1982     560
    x[2126]   c521_1    1
    x[2126]   c1983     560
    x[2127]   c523_1    1
    x[2127]   c1992     360
    x[2128]   c523_1    1
    x[2128]   c1987     360
    x[2129]   c523_1    1
    x[2129]   c1990     100
    x[2130]   c523_1    1
    x[2130]   c1991     100
    x[2131]   c523_1    1
    x[2131]   c1988     560
    x[2132]   c523_1    1
    x[2132]   c1989     560
    x[2133]   c525_1    1
    x[2133]   c1998     360
    x[2134]   c525_1    1
    x[2134]   c1993     360
    x[2135]   c525_1    1
    x[2135]   c1996     100
    x[2136]   c525_1    1
    x[2136]   c1997     100
    x[2137]   c525_1    1
    x[2137]   c1994     560
    x[2138]   c525_1    1
    x[2138]   c1995     560
    x[2139]   c526_1    1
    x[2139]   c2004     360
    x[2140]   c526_1    1
    x[2140]   c1999     360
    x[2141]   c526_1    1
    x[2141]   c2002     100
    x[2142]   c526_1    1
    x[2142]   c2003     100
    x[2143]   c526_1    1
    x[2143]   c2000     560
    x[2144]   c526_1    1
    x[2144]   c2001     560
    x[2145]   c527_1    1
    x[2145]   c2010     360
    x[2146]   c527_1    1
    x[2146]   c2005     360
    x[2147]   c527_1    1
    x[2147]   c2008     100
    x[2148]   c527_1    1
    x[2148]   c2009     100
    x[2149]   c527_1    1
    x[2149]   c2006     560
    x[2150]   c527_1    1
    x[2150]   c2007     560
    x[2151]   c528_1    1
    x[2151]   c2016     360
    x[2152]   c528_1    1
    x[2152]   c2011     360
    x[2153]   c528_1    1
    x[2153]   c2014     100
    x[2154]   c528_1    1
    x[2154]   c2015     100
    x[2155]   c528_1    1
    x[2155]   c2012     560
    x[2156]   c528_1    1
    x[2156]   c2013     560
    x[2157]   c529_1    1
    x[2157]   c2022     360
    x[2158]   c529_1    1
    x[2158]   c2017     360
    x[2159]   c529_1    1
    x[2159]   c2020     100
    x[2160]   c529_1    1
    x[2160]   c2021     100
    x[2161]   c529_1    1
    x[2161]   c2018     560
    x[2162]   c529_1    1
    x[2162]   c2019     560
    x[2163]   c530_1    1
    x[2163]   c2028     360
    x[2164]   c530_1    1
    x[2164]   c2023     360
    x[2165]   c530_1    1
    x[2165]   c2026     100
    x[2166]   c530_1    1
    x[2166]   c2027     100
    x[2167]   c530_1    1
    x[2167]   c2024     560
    x[2168]   c530_1    1
    x[2168]   c2025     560
    x[2169]   c531_1    1
    x[2169]   c2034     360
    x[2170]   c531_1    1
    x[2170]   c2029     360
    x[2171]   c531_1    1
    x[2171]   c2032     100
    x[2172]   c531_1    1
    x[2172]   c2033     100
    x[2173]   c531_1    1
    x[2173]   c2030     560
    x[2174]   c531_1    1
    x[2174]   c2031     560
    x[2175]   c532_1    1
    x[2175]   c2040     360
    x[2176]   c532_1    1
    x[2176]   c2035     360
    x[2177]   c532_1    1
    x[2177]   c2038     100
    x[2178]   c532_1    1
    x[2178]   c2039     100
    x[2179]   c532_1    1
    x[2179]   c2036     560
    x[2180]   c532_1    1
    x[2180]   c2037     560
    x[2181]   c533_1    1
    x[2181]   c922_1    -1
    x[2181]   c2046     360
    x[2182]   c533_1    1
    x[2182]   c2041     360
    x[2183]   c533_1    1
    x[2183]   c2044     100
    x[2184]   c533_1    1
    x[2184]   c2045     100
    x[2185]   c533_1    1
    x[2185]   c2042     560
    x[2186]   c533_1    1
    x[2186]   c2043     560
    x[2187]   c534_1    1
    x[2187]   c2052     360
    x[2188]   c534_1    1
    x[2188]   c2047     360
    x[2189]   c534_1    1
    x[2189]   c2050     100
    x[2190]   c534_1    1
    x[2190]   c2051     100
    x[2191]   c534_1    1
    x[2191]   c2048     560
    x[2192]   c534_1    1
    x[2192]   c2049     560
    x[2193]   c535_1    1
    x[2193]   c2058     360
    x[2194]   c535_1    1
    x[2194]   c2053     360
    x[2195]   c535_1    1
    x[2195]   c2056     100
    x[2196]   c535_1    1
    x[2196]   c2057     100
    x[2197]   c535_1    1
    x[2197]   c2054     560
    x[2198]   c535_1    1
    x[2198]   c2055     560
    x[2199]   c537_1    1
    x[2199]   c2064     360
    x[2200]   c537_1    1
    x[2200]   c2059     360
    x[2201]   c537_1    1
    x[2201]   c2062     100
    x[2202]   c537_1    1
    x[2202]   c2063     100
    x[2203]   c537_1    1
    x[2203]   c2060     560
    x[2204]   c537_1    1
    x[2204]   c2061     560
    x[2205]   c539_1    1
    x[2205]   c2070     360
    x[2206]   c539_1    1
    x[2206]   c2065     360
    x[2207]   c539_1    1
    x[2207]   c2068     100
    x[2208]   c539_1    1
    x[2208]   c2069     100
    x[2209]   c539_1    1
    x[2209]   c2066     560
    x[2210]   c539_1    1
    x[2210]   c2067     560
    x[2211]   c541_1    1
    x[2211]   c2076     360
    x[2212]   c541_1    1
    x[2212]   c2071     360
    x[2213]   c541_1    1
    x[2213]   c2074     100
    x[2214]   c541_1    1
    x[2214]   c2075     100
    x[2215]   c541_1    1
    x[2215]   c2072     560
    x[2216]   c541_1    1
    x[2216]   c2073     560
    x[2217]   c543_1    1
    x[2217]   c2082     360
    x[2218]   c543_1    1
    x[2218]   c2077     360
    x[2219]   c543_1    1
    x[2219]   c2080     100
    x[2220]   c543_1    1
    x[2220]   c2081     100
    x[2221]   c543_1    1
    x[2221]   c2078     560
    x[2222]   c543_1    1
    x[2222]   c2079     560
    x[2223]   c545_1    1
    x[2223]   c2088     360
    x[2224]   c545_1    1
    x[2224]   c2083     360
    x[2225]   c545_1    1
    x[2225]   c2086     100
    x[2226]   c545_1    1
    x[2226]   c2087     100
    x[2227]   c545_1    1
    x[2227]   c2084     560
    x[2228]   c545_1    1
    x[2228]   c2085     560
    x[2229]   c547_1    1
    x[2229]   c2094     360
    x[2230]   c547_1    1
    x[2230]   c2089     360
    x[2231]   c547_1    1
    x[2231]   c2092     100
    x[2232]   c547_1    1
    x[2232]   c2093     100
    x[2233]   c547_1    1
    x[2233]   c2090     560
    x[2234]   c547_1    1
    x[2234]   c2091     560
    x[2235]   c549_1    1
    x[2235]   c2100     360
    x[2236]   c549_1    1
    x[2236]   c2095     360
    x[2237]   c549_1    1
    x[2237]   c2098     100
    x[2238]   c549_1    1
    x[2238]   c2099     100
    x[2239]   c549_1    1
    x[2239]   c2096     560
    x[2240]   c549_1    1
    x[2240]   c2097     560
    x[2241]   c551_1    1
    x[2241]   c2106     360
    x[2242]   c551_1    1
    x[2242]   c2101     360
    x[2243]   c551_1    1
    x[2243]   c2104     100
    x[2244]   c551_1    1
    x[2244]   c2105     100
    x[2245]   c551_1    1
    x[2245]   c2102     560
    x[2246]   c551_1    1
    x[2246]   c2103     560
    x[2247]   c553_1    1
    x[2247]   c2112     360
    x[2248]   c553_1    1
    x[2248]   c2107     360
    x[2249]   c553_1    1
    x[2249]   c2110     100
    x[2250]   c553_1    1
    x[2250]   c2111     100
    x[2251]   c553_1    1
    x[2251]   c2108     560
    x[2252]   c553_1    1
    x[2252]   c2109     560
    x[2253]   c555_1    1
    x[2253]   c2118     360
    x[2254]   c555_1    1
    x[2254]   c2113     360
    x[2255]   c555_1    1
    x[2255]   c2116     100
    x[2256]   c555_1    1
    x[2256]   c2117     100
    x[2257]   c555_1    1
    x[2257]   c2114     560
    x[2258]   c555_1    1
    x[2258]   c2115     560
    x[2259]   c557_1    1
    x[2259]   c2124     360
    x[2260]   c557_1    1
    x[2260]   c2119     360
    x[2261]   c557_1    1
    x[2261]   c2122     100
    x[2262]   c557_1    1
    x[2262]   c2123     100
    x[2263]   c557_1    1
    x[2263]   c2120     560
    x[2264]   c557_1    1
    x[2264]   c2121     560
    x[2265]   c559_1    1
    x[2265]   c2130     360
    x[2266]   c559_1    1
    x[2266]   c2125     360
    x[2267]   c559_1    1
    x[2267]   c2128     100
    x[2268]   c559_1    1
    x[2268]   c2129     100
    x[2269]   c559_1    1
    x[2269]   c2126     560
    x[2270]   c559_1    1
    x[2270]   c2127     560
    x[2271]   c560_1    1
    x[2271]   c2136     360
    x[2272]   c560_1    1
    x[2272]   c2131     360
    x[2273]   c560_1    1
    x[2273]   c2134     100
    x[2274]   c560_1    1
    x[2274]   c2135     100
    x[2275]   c560_1    1
    x[2275]   c2132     560
    x[2276]   c560_1    1
    x[2276]   c2133     560
    x[2277]   c561_1    1
    x[2277]   c2142     360
    x[2278]   c561_1    1
    x[2278]   c2137     360
    x[2279]   c561_1    1
    x[2279]   c2140     100
    x[2280]   c561_1    1
    x[2280]   c2141     100
    x[2281]   c561_1    1
    x[2281]   c2138     560
    x[2282]   c561_1    1
    x[2282]   c2139     560
    x[2283]   c562_1    1
    x[2283]   c2148     360
    x[2284]   c562_1    1
    x[2284]   c2143     360
    x[2285]   c562_1    1
    x[2285]   c2146     100
    x[2286]   c562_1    1
    x[2286]   c2147     100
    x[2287]   c562_1    1
    x[2287]   c2144     560
    x[2288]   c562_1    1
    x[2288]   c2145     560
    x[2289]   c563_1    1
    x[2289]   c2154     360
    x[2290]   c563_1    1
    x[2290]   c2149     360
    x[2291]   c563_1    1
    x[2291]   c2152     100
    x[2292]   c563_1    1
    x[2292]   c2153     100
    x[2293]   c563_1    1
    x[2293]   c2150     560
    x[2294]   c563_1    1
    x[2294]   c2151     560
    x[2295]   c564_1    1
    x[2295]   c2160     360
    x[2296]   c564_1    1
    x[2296]   c2155     360
    x[2297]   c564_1    1
    x[2297]   c2158     100
    x[2298]   c564_1    1
    x[2298]   c2159     100
    x[2299]   c564_1    1
    x[2299]   c2156     560
    x[2300]   c564_1    1
    x[2300]   c2157     560
    x[2301]   c565_1    1
    x[2301]   c2166     360
    x[2302]   c565_1    1
    x[2302]   c2161     360
    x[2303]   c565_1    1
    x[2303]   c2164     100
    x[2304]   c565_1    1
    x[2304]   c2165     100
    x[2305]   c565_1    1
    x[2305]   c2162     560
    x[2306]   c565_1    1
    x[2306]   c2163     560
    x[2307]   c566_1    1
    x[2307]   c2172     360
    x[2308]   c566_1    1
    x[2308]   c2167     360
    x[2309]   c566_1    1
    x[2309]   c2170     100
    x[2310]   c566_1    1
    x[2310]   c2171     100
    x[2311]   c566_1    1
    x[2311]   c2168     560
    x[2312]   c566_1    1
    x[2312]   c2169     560
    x[2313]   c567_1    1
    x[2313]   c923_1    -1
    x[2313]   c2178     360
    x[2314]   c567_1    1
    x[2314]   c2173     360
    x[2315]   c567_1    1
    x[2315]   c2176     100
    x[2316]   c567_1    1
    x[2316]   c2177     100
    x[2317]   c567_1    1
    x[2317]   c2174     560
    x[2318]   c567_1    1
    x[2318]   c2175     560
    x[2319]   c568_1    1
    x[2319]   c2184     360
    x[2320]   c568_1    1
    x[2320]   c2179     360
    x[2321]   c568_1    1
    x[2321]   c2182     100
    x[2322]   c568_1    1
    x[2322]   c2183     100
    x[2323]   c568_1    1
    x[2323]   c2180     560
    x[2324]   c568_1    1
    x[2324]   c2181     560
    x[2325]   c569_1    1
    x[2325]   c2190     360
    x[2326]   c569_1    1
    x[2326]   c2185     360
    x[2327]   c569_1    1
    x[2327]   c2188     100
    x[2328]   c569_1    1
    x[2328]   c2189     100
    x[2329]   c569_1    1
    x[2329]   c2186     560
    x[2330]   c569_1    1
    x[2330]   c2187     560
    x[2331]   c571_1    1
    x[2331]   c2196     360
    x[2332]   c571_1    1
    x[2332]   c2191     360
    x[2333]   c571_1    1
    x[2333]   c2194     100
    x[2334]   c571_1    1
    x[2334]   c2195     100
    x[2335]   c571_1    1
    x[2335]   c2192     560
    x[2336]   c571_1    1
    x[2336]   c2193     560
    x[2337]   c573_1    1
    x[2337]   c2202     360
    x[2338]   c573_1    1
    x[2338]   c2197     360
    x[2339]   c573_1    1
    x[2339]   c2200     100
    x[2340]   c573_1    1
    x[2340]   c2201     100
    x[2341]   c573_1    1
    x[2341]   c2198     560
    x[2342]   c573_1    1
    x[2342]   c2199     560
    x[2343]   c575_1    1
    x[2343]   c2208     360
    x[2344]   c575_1    1
    x[2344]   c2203     360
    x[2345]   c575_1    1
    x[2345]   c2206     100
    x[2346]   c575_1    1
    x[2346]   c2207     100
    x[2347]   c575_1    1
    x[2347]   c2204     560
    x[2348]   c575_1    1
    x[2348]   c2205     560
    x[2349]   c577_1    1
    x[2349]   c2214     360
    x[2350]   c577_1    1
    x[2350]   c2209     360
    x[2351]   c577_1    1
    x[2351]   c2212     100
    x[2352]   c577_1    1
    x[2352]   c2213     100
    x[2353]   c577_1    1
    x[2353]   c2210     560
    x[2354]   c577_1    1
    x[2354]   c2211     560
    x[2355]   c579_1    1
    x[2355]   c2220     360
    x[2356]   c579_1    1
    x[2356]   c2215     360
    x[2357]   c579_1    1
    x[2357]   c2218     100
    x[2358]   c579_1    1
    x[2358]   c2219     100
    x[2359]   c579_1    1
    x[2359]   c2216     560
    x[2360]   c579_1    1
    x[2360]   c2217     560
    x[2361]   c581_1    1
    x[2361]   c2226     360
    x[2362]   c581_1    1
    x[2362]   c2221     360
    x[2363]   c581_1    1
    x[2363]   c2224     100
    x[2364]   c581_1    1
    x[2364]   c2225     100
    x[2365]   c581_1    1
    x[2365]   c2222     560
    x[2366]   c581_1    1
    x[2366]   c2223     560
    x[2367]   c583_1    1
    x[2367]   c2232     360
    x[2368]   c583_1    1
    x[2368]   c2227     360
    x[2369]   c583_1    1
    x[2369]   c2230     100
    x[2370]   c583_1    1
    x[2370]   c2231     100
    x[2371]   c583_1    1
    x[2371]   c2228     560
    x[2372]   c583_1    1
    x[2372]   c2229     560
    x[2373]   c585_1    1
    x[2373]   c2238     360
    x[2374]   c585_1    1
    x[2374]   c2233     360
    x[2375]   c585_1    1
    x[2375]   c2236     100
    x[2376]   c585_1    1
    x[2376]   c2237     100
    x[2377]   c585_1    1
    x[2377]   c2234     560
    x[2378]   c585_1    1
    x[2378]   c2235     560
    x[2379]   c587_1    1
    x[2379]   c2244     360
    x[2380]   c587_1    1
    x[2380]   c2239     360
    x[2381]   c587_1    1
    x[2381]   c2242     100
    x[2382]   c587_1    1
    x[2382]   c2243     100
    x[2383]   c587_1    1
    x[2383]   c2240     560
    x[2384]   c587_1    1
    x[2384]   c2241     560
    x[2385]   c589_1    1
    x[2385]   c2250     360
    x[2386]   c589_1    1
    x[2386]   c2245     360
    x[2387]   c589_1    1
    x[2387]   c2248     100
    x[2388]   c589_1    1
    x[2388]   c2249     100
    x[2389]   c589_1    1
    x[2389]   c2246     560
    x[2390]   c589_1    1
    x[2390]   c2247     560
    x[2391]   c591_1    1
    x[2391]   c2256     360
    x[2392]   c591_1    1
    x[2392]   c2251     360
    x[2393]   c591_1    1
    x[2393]   c2254     100
    x[2394]   c591_1    1
    x[2394]   c2255     100
    x[2395]   c591_1    1
    x[2395]   c2252     560
    x[2396]   c591_1    1
    x[2396]   c2253     560
    x[2397]   c592_1    1
    x[2397]   c2262     360
    x[2398]   c592_1    1
    x[2398]   c2257     360
    x[2399]   c592_1    1
    x[2399]   c2260     100
    x[2400]   c592_1    1
    x[2400]   c2261     100
    x[2401]   c592_1    1
    x[2401]   c2258     560
    x[2402]   c592_1    1
    x[2402]   c2259     560
    x[2403]   c593_1    1
    x[2403]   c2268     360
    x[2404]   c593_1    1
    x[2404]   c2263     360
    x[2405]   c593_1    1
    x[2405]   c2266     100
    x[2406]   c593_1    1
    x[2406]   c2267     100
    x[2407]   c593_1    1
    x[2407]   c2264     560
    x[2408]   c593_1    1
    x[2408]   c2265     560
    x[2409]   c594_1    1
    x[2409]   c2274     360
    x[2410]   c594_1    1
    x[2410]   c2269     360
    x[2411]   c594_1    1
    x[2411]   c2272     100
    x[2412]   c594_1    1
    x[2412]   c2273     100
    x[2413]   c594_1    1
    x[2413]   c2270     560
    x[2414]   c594_1    1
    x[2414]   c2271     560
    x[2415]   c595_1    1
    x[2415]   c2280     360
    x[2416]   c595_1    1
    x[2416]   c2275     360
    x[2417]   c595_1    1
    x[2417]   c2278     100
    x[2418]   c595_1    1
    x[2418]   c2279     100
    x[2419]   c595_1    1
    x[2419]   c2276     560
    x[2420]   c595_1    1
    x[2420]   c2277     560
    x[2421]   c596_1    1
    x[2421]   c2286     360
    x[2422]   c596_1    1
    x[2422]   c2281     360
    x[2423]   c596_1    1
    x[2423]   c2284     100
    x[2424]   c596_1    1
    x[2424]   c2285     100
    x[2425]   c596_1    1
    x[2425]   c2282     560
    x[2426]   c596_1    1
    x[2426]   c2283     560
    x[2427]   c597_1    1
    x[2427]   c2292     360
    x[2428]   c597_1    1
    x[2428]   c2287     360
    x[2429]   c597_1    1
    x[2429]   c2290     100
    x[2430]   c597_1    1
    x[2430]   c2291     100
    x[2431]   c597_1    1
    x[2431]   c2288     560
    x[2432]   c597_1    1
    x[2432]   c2289     560
    x[2433]   c598_1    1
    x[2433]   c2298     360
    x[2434]   c598_1    1
    x[2434]   c2293     360
    x[2435]   c598_1    1
    x[2435]   c2296     100
    x[2436]   c598_1    1
    x[2436]   c2297     100
    x[2437]   c598_1    1
    x[2437]   c2294     560
    x[2438]   c598_1    1
    x[2438]   c2295     560
    x[2439]   c599_1    1
    x[2439]   c924_1    -1
    x[2439]   c2304     360
    x[2440]   c599_1    1
    x[2440]   c2299     360
    x[2441]   c599_1    1
    x[2441]   c2302     100
    x[2442]   c599_1    1
    x[2442]   c2303     100
    x[2443]   c599_1    1
    x[2443]   c2300     560
    x[2444]   c599_1    1
    x[2444]   c2301     560
    x[2445]   c600_1    1
    x[2445]   c2310     360
    x[2446]   c600_1    1
    x[2446]   c2305     360
    x[2447]   c600_1    1
    x[2447]   c2308     100
    x[2448]   c600_1    1
    x[2448]   c2309     100
    x[2449]   c600_1    1
    x[2449]   c2306     560
    x[2450]   c600_1    1
    x[2450]   c2307     560
    x[2451]   c601_1    1
    x[2451]   c2316     360
    x[2452]   c601_1    1
    x[2452]   c2311     360
    x[2453]   c601_1    1
    x[2453]   c2314     100
    x[2454]   c601_1    1
    x[2454]   c2315     100
    x[2455]   c601_1    1
    x[2455]   c2312     560
    x[2456]   c601_1    1
    x[2456]   c2313     560
    x[2457]   c603_1    1
    x[2457]   c2322     360
    x[2458]   c603_1    1
    x[2458]   c2317     360
    x[2459]   c603_1    1
    x[2459]   c2320     100
    x[2460]   c603_1    1
    x[2460]   c2321     100
    x[2461]   c603_1    1
    x[2461]   c2318     560
    x[2462]   c603_1    1
    x[2462]   c2319     560
    x[2463]   c605_1    1
    x[2463]   c2328     360
    x[2464]   c605_1    1
    x[2464]   c2323     360
    x[2465]   c605_1    1
    x[2465]   c2326     100
    x[2466]   c605_1    1
    x[2466]   c2327     100
    x[2467]   c605_1    1
    x[2467]   c2324     560
    x[2468]   c605_1    1
    x[2468]   c2325     560
    x[2469]   c607_1    1
    x[2469]   c2334     360
    x[2470]   c607_1    1
    x[2470]   c2329     360
    x[2471]   c607_1    1
    x[2471]   c2332     100
    x[2472]   c607_1    1
    x[2472]   c2333     100
    x[2473]   c607_1    1
    x[2473]   c2330     560
    x[2474]   c607_1    1
    x[2474]   c2331     560
    x[2475]   c609_1    1
    x[2475]   c2340     360
    x[2476]   c609_1    1
    x[2476]   c2335     360
    x[2477]   c609_1    1
    x[2477]   c2338     100
    x[2478]   c609_1    1
    x[2478]   c2339     100
    x[2479]   c609_1    1
    x[2479]   c2336     560
    x[2480]   c609_1    1
    x[2480]   c2337     560
    x[2481]   c611_1    1
    x[2481]   c2346     360
    x[2482]   c611_1    1
    x[2482]   c2341     360
    x[2483]   c611_1    1
    x[2483]   c2344     100
    x[2484]   c611_1    1
    x[2484]   c2345     100
    x[2485]   c611_1    1
    x[2485]   c2342     560
    x[2486]   c611_1    1
    x[2486]   c2343     560
    x[2487]   c613_1    1
    x[2487]   c2352     360
    x[2488]   c613_1    1
    x[2488]   c2347     360
    x[2489]   c613_1    1
    x[2489]   c2350     100
    x[2490]   c613_1    1
    x[2490]   c2351     100
    x[2491]   c613_1    1
    x[2491]   c2348     560
    x[2492]   c613_1    1
    x[2492]   c2349     560
    x[2493]   c615_1    1
    x[2493]   c2358     360
    x[2494]   c615_1    1
    x[2494]   c2353     360
    x[2495]   c615_1    1
    x[2495]   c2356     100
    x[2496]   c615_1    1
    x[2496]   c2357     100
    x[2497]   c615_1    1
    x[2497]   c2354     560
    x[2498]   c615_1    1
    x[2498]   c2355     560
    x[2499]   c617_1    1
    x[2499]   c2364     360
    x[2500]   c617_1    1
    x[2500]   c2359     360
    x[2501]   c617_1    1
    x[2501]   c2362     100
    x[2502]   c617_1    1
    x[2502]   c2363     100
    x[2503]   c617_1    1
    x[2503]   c2360     560
    x[2504]   c617_1    1
    x[2504]   c2361     560
    x[2505]   c619_1    1
    x[2505]   c2370     360
    x[2506]   c619_1    1
    x[2506]   c2365     360
    x[2507]   c619_1    1
    x[2507]   c2368     100
    x[2508]   c619_1    1
    x[2508]   c2369     100
    x[2509]   c619_1    1
    x[2509]   c2366     560
    x[2510]   c619_1    1
    x[2510]   c2367     560
    x[2511]   c621_1    1
    x[2511]   c2376     360
    x[2512]   c621_1    1
    x[2512]   c2371     360
    x[2513]   c621_1    1
    x[2513]   c2374     100
    x[2514]   c621_1    1
    x[2514]   c2375     100
    x[2515]   c621_1    1
    x[2515]   c2372     560
    x[2516]   c621_1    1
    x[2516]   c2373     560
    x[2517]   c622_1    1
    x[2517]   c2382     360
    x[2518]   c622_1    1
    x[2518]   c2377     360
    x[2519]   c622_1    1
    x[2519]   c2380     100
    x[2520]   c622_1    1
    x[2520]   c2381     100
    x[2521]   c622_1    1
    x[2521]   c2378     560
    x[2522]   c622_1    1
    x[2522]   c2379     560
    x[2523]   c623_1    1
    x[2523]   c2388     360
    x[2524]   c623_1    1
    x[2524]   c2383     360
    x[2525]   c623_1    1
    x[2525]   c2386     100
    x[2526]   c623_1    1
    x[2526]   c2387     100
    x[2527]   c623_1    1
    x[2527]   c2384     560
    x[2528]   c623_1    1
    x[2528]   c2385     560
    x[2529]   c624_1    1
    x[2529]   c2394     360
    x[2530]   c624_1    1
    x[2530]   c2389     360
    x[2531]   c624_1    1
    x[2531]   c2392     100
    x[2532]   c624_1    1
    x[2532]   c2393     100
    x[2533]   c624_1    1
    x[2533]   c2390     560
    x[2534]   c624_1    1
    x[2534]   c2391     560
    x[2535]   c625_1    1
    x[2535]   c2400     360
    x[2536]   c625_1    1
    x[2536]   c2395     360
    x[2537]   c625_1    1
    x[2537]   c2398     100
    x[2538]   c625_1    1
    x[2538]   c2399     100
    x[2539]   c625_1    1
    x[2539]   c2396     560
    x[2540]   c625_1    1
    x[2540]   c2397     560
    x[2541]   c626_1    1
    x[2541]   c2406     360
    x[2542]   c626_1    1
    x[2542]   c2401     360
    x[2543]   c626_1    1
    x[2543]   c2404     100
    x[2544]   c626_1    1
    x[2544]   c2405     100
    x[2545]   c626_1    1
    x[2545]   c2402     560
    x[2546]   c626_1    1
    x[2546]   c2403     560
    x[2547]   c627_1    1
    x[2547]   c2412     360
    x[2548]   c627_1    1
    x[2548]   c2407     360
    x[2549]   c627_1    1
    x[2549]   c2410     100
    x[2550]   c627_1    1
    x[2550]   c2411     100
    x[2551]   c627_1    1
    x[2551]   c2408     560
    x[2552]   c627_1    1
    x[2552]   c2409     560
    x[2553]   c628_1    1
    x[2553]   c2418     360
    x[2554]   c628_1    1
    x[2554]   c2413     360
    x[2555]   c628_1    1
    x[2555]   c2416     100
    x[2556]   c628_1    1
    x[2556]   c2417     100
    x[2557]   c628_1    1
    x[2557]   c2414     560
    x[2558]   c628_1    1
    x[2558]   c2415     560
    x[2559]   c629_1    1
    x[2559]   c925_1    -1
    x[2559]   c2424     360
    x[2560]   c629_1    1
    x[2560]   c2419     360
    x[2561]   c629_1    1
    x[2561]   c2422     100
    x[2562]   c629_1    1
    x[2562]   c2423     100
    x[2563]   c629_1    1
    x[2563]   c2420     560
    x[2564]   c629_1    1
    x[2564]   c2421     560
    x[2565]   c630_1    1
    x[2565]   c2430     360
    x[2566]   c630_1    1
    x[2566]   c2425     360
    x[2567]   c630_1    1
    x[2567]   c2428     100
    x[2568]   c630_1    1
    x[2568]   c2429     100
    x[2569]   c630_1    1
    x[2569]   c2426     560
    x[2570]   c630_1    1
    x[2570]   c2427     560
    x[2571]   c631_1    1
    x[2571]   c2436     360
    x[2572]   c631_1    1
    x[2572]   c2431     360
    x[2573]   c631_1    1
    x[2573]   c2434     100
    x[2574]   c631_1    1
    x[2574]   c2435     100
    x[2575]   c631_1    1
    x[2575]   c2432     560
    x[2576]   c631_1    1
    x[2576]   c2433     560
    x[2577]   c633_1    1
    x[2577]   c2442     360
    x[2578]   c633_1    1
    x[2578]   c2437     360
    x[2579]   c633_1    1
    x[2579]   c2440     100
    x[2580]   c633_1    1
    x[2580]   c2441     100
    x[2581]   c633_1    1
    x[2581]   c2438     560
    x[2582]   c633_1    1
    x[2582]   c2439     560
    x[2583]   c635_1    1
    x[2583]   c2448     360
    x[2584]   c635_1    1
    x[2584]   c2443     360
    x[2585]   c635_1    1
    x[2585]   c2446     100
    x[2586]   c635_1    1
    x[2586]   c2447     100
    x[2587]   c635_1    1
    x[2587]   c2444     560
    x[2588]   c635_1    1
    x[2588]   c2445     560
    x[2589]   c637_1    1
    x[2589]   c2454     360
    x[2590]   c637_1    1
    x[2590]   c2449     360
    x[2591]   c637_1    1
    x[2591]   c2452     100
    x[2592]   c637_1    1
    x[2592]   c2453     100
    x[2593]   c637_1    1
    x[2593]   c2450     560
    x[2594]   c637_1    1
    x[2594]   c2451     560
    x[2595]   c639_1    1
    x[2595]   c2460     360
    x[2596]   c639_1    1
    x[2596]   c2455     360
    x[2597]   c639_1    1
    x[2597]   c2458     100
    x[2598]   c639_1    1
    x[2598]   c2459     100
    x[2599]   c639_1    1
    x[2599]   c2456     560
    x[2600]   c639_1    1
    x[2600]   c2457     560
    x[2601]   c641_1    1
    x[2601]   c2466     360
    x[2602]   c641_1    1
    x[2602]   c2461     360
    x[2603]   c641_1    1
    x[2603]   c2464     100
    x[2604]   c641_1    1
    x[2604]   c2465     100
    x[2605]   c641_1    1
    x[2605]   c2462     560
    x[2606]   c641_1    1
    x[2606]   c2463     560
    x[2607]   c643_1    1
    x[2607]   c2472     360
    x[2608]   c643_1    1
    x[2608]   c2467     360
    x[2609]   c643_1    1
    x[2609]   c2470     100
    x[2610]   c643_1    1
    x[2610]   c2471     100
    x[2611]   c643_1    1
    x[2611]   c2468     560
    x[2612]   c643_1    1
    x[2612]   c2469     560
    x[2613]   c645_1    1
    x[2613]   c2478     360
    x[2614]   c645_1    1
    x[2614]   c2473     360
    x[2615]   c645_1    1
    x[2615]   c2476     100
    x[2616]   c645_1    1
    x[2616]   c2477     100
    x[2617]   c645_1    1
    x[2617]   c2474     560
    x[2618]   c645_1    1
    x[2618]   c2475     560
    x[2619]   c647_1    1
    x[2619]   c2484     360
    x[2620]   c647_1    1
    x[2620]   c2479     360
    x[2621]   c647_1    1
    x[2621]   c2482     100
    x[2622]   c647_1    1
    x[2622]   c2483     100
    x[2623]   c647_1    1
    x[2623]   c2480     560
    x[2624]   c647_1    1
    x[2624]   c2481     560
    x[2625]   c649_1    1
    x[2625]   c2490     360
    x[2626]   c649_1    1
    x[2626]   c2485     360
    x[2627]   c649_1    1
    x[2627]   c2488     100
    x[2628]   c649_1    1
    x[2628]   c2489     100
    x[2629]   c649_1    1
    x[2629]   c2486     560
    x[2630]   c649_1    1
    x[2630]   c2487     560
    x[2631]   c650_1    1
    x[2631]   c2496     360
    x[2632]   c650_1    1
    x[2632]   c2491     360
    x[2633]   c650_1    1
    x[2633]   c2494     100
    x[2634]   c650_1    1
    x[2634]   c2495     100
    x[2635]   c650_1    1
    x[2635]   c2492     560
    x[2636]   c650_1    1
    x[2636]   c2493     560
    x[2637]   c651_1    1
    x[2637]   c2502     360
    x[2638]   c651_1    1
    x[2638]   c2497     360
    x[2639]   c651_1    1
    x[2639]   c2500     100
    x[2640]   c651_1    1
    x[2640]   c2501     100
    x[2641]   c651_1    1
    x[2641]   c2498     560
    x[2642]   c651_1    1
    x[2642]   c2499     560
    x[2643]   c652_1    1
    x[2643]   c2508     360
    x[2644]   c652_1    1
    x[2644]   c2503     360
    x[2645]   c652_1    1
    x[2645]   c2506     100
    x[2646]   c652_1    1
    x[2646]   c2507     100
    x[2647]   c652_1    1
    x[2647]   c2504     560
    x[2648]   c652_1    1
    x[2648]   c2505     560
    x[2649]   c653_1    1
    x[2649]   c2514     360
    x[2650]   c653_1    1
    x[2650]   c2509     360
    x[2651]   c653_1    1
    x[2651]   c2512     100
    x[2652]   c653_1    1
    x[2652]   c2513     100
    x[2653]   c653_1    1
    x[2653]   c2510     560
    x[2654]   c653_1    1
    x[2654]   c2511     560
    x[2655]   c654_1    1
    x[2655]   c2520     360
    x[2656]   c654_1    1
    x[2656]   c2515     360
    x[2657]   c654_1    1
    x[2657]   c2518     100
    x[2658]   c654_1    1
    x[2658]   c2519     100
    x[2659]   c654_1    1
    x[2659]   c2516     560
    x[2660]   c654_1    1
    x[2660]   c2517     560
    x[2661]   c655_1    1
    x[2661]   c2526     360
    x[2662]   c655_1    1
    x[2662]   c2521     360
    x[2663]   c655_1    1
    x[2663]   c2524     100
    x[2664]   c655_1    1
    x[2664]   c2525     100
    x[2665]   c655_1    1
    x[2665]   c2522     560
    x[2666]   c655_1    1
    x[2666]   c2523     560
    x[2667]   c656_1    1
    x[2667]   c2532     360
    x[2668]   c656_1    1
    x[2668]   c2527     360
    x[2669]   c656_1    1
    x[2669]   c2530     100
    x[2670]   c656_1    1
    x[2670]   c2531     100
    x[2671]   c656_1    1
    x[2671]   c2528     560
    x[2672]   c656_1    1
    x[2672]   c2529     560
    x[2673]   c657_1    1
    x[2673]   c926_1    -1
    x[2673]   c2538     360
    x[2674]   c657_1    1
    x[2674]   c2533     360
    x[2675]   c657_1    1
    x[2675]   c2536     100
    x[2676]   c657_1    1
    x[2676]   c2537     100
    x[2677]   c657_1    1
    x[2677]   c2534     560
    x[2678]   c657_1    1
    x[2678]   c2535     560
    x[2679]   c658_1    1
    x[2679]   c2544     360
    x[2680]   c658_1    1
    x[2680]   c2539     360
    x[2681]   c658_1    1
    x[2681]   c2542     100
    x[2682]   c658_1    1
    x[2682]   c2543     100
    x[2683]   c658_1    1
    x[2683]   c2540     560
    x[2684]   c658_1    1
    x[2684]   c2541     560
    x[2685]   c659_1    1
    x[2685]   c2550     360
    x[2686]   c659_1    1
    x[2686]   c2545     360
    x[2687]   c659_1    1
    x[2687]   c2548     100
    x[2688]   c659_1    1
    x[2688]   c2549     100
    x[2689]   c659_1    1
    x[2689]   c2546     560
    x[2690]   c659_1    1
    x[2690]   c2547     560
    x[2691]   c661_1    1
    x[2691]   c2556     360
    x[2692]   c661_1    1
    x[2692]   c2551     360
    x[2693]   c661_1    1
    x[2693]   c2554     100
    x[2694]   c661_1    1
    x[2694]   c2555     100
    x[2695]   c661_1    1
    x[2695]   c2552     560
    x[2696]   c661_1    1
    x[2696]   c2553     560
    x[2697]   c663_1    1
    x[2697]   c2562     360
    x[2698]   c663_1    1
    x[2698]   c2557     360
    x[2699]   c663_1    1
    x[2699]   c2560     100
    x[2700]   c663_1    1
    x[2700]   c2561     100
    x[2701]   c663_1    1
    x[2701]   c2558     560
    x[2702]   c663_1    1
    x[2702]   c2559     560
    x[2703]   c665_1    1
    x[2703]   c2568     360
    x[2704]   c665_1    1
    x[2704]   c2563     360
    x[2705]   c665_1    1
    x[2705]   c2566     100
    x[2706]   c665_1    1
    x[2706]   c2567     100
    x[2707]   c665_1    1
    x[2707]   c2564     560
    x[2708]   c665_1    1
    x[2708]   c2565     560
    x[2709]   c667_1    1
    x[2709]   c2574     360
    x[2710]   c667_1    1
    x[2710]   c2569     360
    x[2711]   c667_1    1
    x[2711]   c2572     100
    x[2712]   c667_1    1
    x[2712]   c2573     100
    x[2713]   c667_1    1
    x[2713]   c2570     560
    x[2714]   c667_1    1
    x[2714]   c2571     560
    x[2715]   c669_1    1
    x[2715]   c2580     360
    x[2716]   c669_1    1
    x[2716]   c2575     360
    x[2717]   c669_1    1
    x[2717]   c2578     100
    x[2718]   c669_1    1
    x[2718]   c2579     100
    x[2719]   c669_1    1
    x[2719]   c2576     560
    x[2720]   c669_1    1
    x[2720]   c2577     560
    x[2721]   c671_1    1
    x[2721]   c2586     360
    x[2722]   c671_1    1
    x[2722]   c2581     360
    x[2723]   c671_1    1
    x[2723]   c2584     100
    x[2724]   c671_1    1
    x[2724]   c2585     100
    x[2725]   c671_1    1
    x[2725]   c2582     560
    x[2726]   c671_1    1
    x[2726]   c2583     560
    x[2727]   c673_1    1
    x[2727]   c2592     360
    x[2728]   c673_1    1
    x[2728]   c2587     360
    x[2729]   c673_1    1
    x[2729]   c2590     100
    x[2730]   c673_1    1
    x[2730]   c2591     100
    x[2731]   c673_1    1
    x[2731]   c2588     560
    x[2732]   c673_1    1
    x[2732]   c2589     560
    x[2733]   c675_1    1
    x[2733]   c2598     360
    x[2734]   c675_1    1
    x[2734]   c2593     360
    x[2735]   c675_1    1
    x[2735]   c2596     100
    x[2736]   c675_1    1
    x[2736]   c2597     100
    x[2737]   c675_1    1
    x[2737]   c2594     560
    x[2738]   c675_1    1
    x[2738]   c2595     560
    x[2739]   c676_1    1
    x[2739]   c2604     360
    x[2740]   c676_1    1
    x[2740]   c2599     360
    x[2741]   c676_1    1
    x[2741]   c2602     100
    x[2742]   c676_1    1
    x[2742]   c2603     100
    x[2743]   c676_1    1
    x[2743]   c2600     560
    x[2744]   c676_1    1
    x[2744]   c2601     560
    x[2745]   c677_1    1
    x[2745]   c2610     360
    x[2746]   c677_1    1
    x[2746]   c2605     360
    x[2747]   c677_1    1
    x[2747]   c2608     100
    x[2748]   c677_1    1
    x[2748]   c2609     100
    x[2749]   c677_1    1
    x[2749]   c2606     560
    x[2750]   c677_1    1
    x[2750]   c2607     560
    x[2751]   c678_1    1
    x[2751]   c2616     360
    x[2752]   c678_1    1
    x[2752]   c2611     360
    x[2753]   c678_1    1
    x[2753]   c2614     100
    x[2754]   c678_1    1
    x[2754]   c2615     100
    x[2755]   c678_1    1
    x[2755]   c2612     560
    x[2756]   c678_1    1
    x[2756]   c2613     560
    x[2757]   c679_1    1
    x[2757]   c2622     360
    x[2758]   c679_1    1
    x[2758]   c2617     360
    x[2759]   c679_1    1
    x[2759]   c2620     100
    x[2760]   c679_1    1
    x[2760]   c2621     100
    x[2761]   c679_1    1
    x[2761]   c2618     560
    x[2762]   c679_1    1
    x[2762]   c2619     560
    x[2763]   c680_1    1
    x[2763]   c2628     360
    x[2764]   c680_1    1
    x[2764]   c2623     360
    x[2765]   c680_1    1
    x[2765]   c2626     100
    x[2766]   c680_1    1
    x[2766]   c2627     100
    x[2767]   c680_1    1
    x[2767]   c2624     560
    x[2768]   c680_1    1
    x[2768]   c2625     560
    x[2769]   c681_1    1
    x[2769]   c2634     360
    x[2770]   c681_1    1
    x[2770]   c2629     360
    x[2771]   c681_1    1
    x[2771]   c2632     100
    x[2772]   c681_1    1
    x[2772]   c2633     100
    x[2773]   c681_1    1
    x[2773]   c2630     560
    x[2774]   c681_1    1
    x[2774]   c2631     560
    x[2775]   c682_1    1
    x[2775]   c2640     360
    x[2776]   c682_1    1
    x[2776]   c2635     360
    x[2777]   c682_1    1
    x[2777]   c2638     100
    x[2778]   c682_1    1
    x[2778]   c2639     100
    x[2779]   c682_1    1
    x[2779]   c2636     560
    x[2780]   c682_1    1
    x[2780]   c2637     560
    x[2781]   c683_1    1
    x[2781]   c927_1    -1
    x[2781]   c2646     360
    x[2782]   c683_1    1
    x[2782]   c2641     360
    x[2783]   c683_1    1
    x[2783]   c2644     100
    x[2784]   c683_1    1
    x[2784]   c2645     100
    x[2785]   c683_1    1
    x[2785]   c2642     560
    x[2786]   c683_1    1
    x[2786]   c2643     560
    x[2787]   c684_1    1
    x[2787]   c2652     360
    x[2788]   c684_1    1
    x[2788]   c2647     360
    x[2789]   c684_1    1
    x[2789]   c2650     100
    x[2790]   c684_1    1
    x[2790]   c2651     100
    x[2791]   c684_1    1
    x[2791]   c2648     560
    x[2792]   c684_1    1
    x[2792]   c2649     560
    x[2793]   c685_1    1
    x[2793]   c2658     360
    x[2794]   c685_1    1
    x[2794]   c2653     360
    x[2795]   c685_1    1
    x[2795]   c2656     100
    x[2796]   c685_1    1
    x[2796]   c2657     100
    x[2797]   c685_1    1
    x[2797]   c2654     560
    x[2798]   c685_1    1
    x[2798]   c2655     560
    x[2799]   c687_1    1
    x[2799]   c2664     360
    x[2800]   c687_1    1
    x[2800]   c2659     360
    x[2801]   c687_1    1
    x[2801]   c2662     100
    x[2802]   c687_1    1
    x[2802]   c2663     100
    x[2803]   c687_1    1
    x[2803]   c2660     560
    x[2804]   c687_1    1
    x[2804]   c2661     560
    x[2805]   c689_1    1
    x[2805]   c2670     360
    x[2806]   c689_1    1
    x[2806]   c2665     360
    x[2807]   c689_1    1
    x[2807]   c2668     100
    x[2808]   c689_1    1
    x[2808]   c2669     100
    x[2809]   c689_1    1
    x[2809]   c2666     560
    x[2810]   c689_1    1
    x[2810]   c2667     560
    x[2811]   c691_1    1
    x[2811]   c2676     360
    x[2812]   c691_1    1
    x[2812]   c2671     360
    x[2813]   c691_1    1
    x[2813]   c2674     100
    x[2814]   c691_1    1
    x[2814]   c2675     100
    x[2815]   c691_1    1
    x[2815]   c2672     560
    x[2816]   c691_1    1
    x[2816]   c2673     560
    x[2817]   c693_1    1
    x[2817]   c2682     360
    x[2818]   c693_1    1
    x[2818]   c2677     360
    x[2819]   c693_1    1
    x[2819]   c2680     100
    x[2820]   c693_1    1
    x[2820]   c2681     100
    x[2821]   c693_1    1
    x[2821]   c2678     560
    x[2822]   c693_1    1
    x[2822]   c2679     560
    x[2823]   c695_1    1
    x[2823]   c2688     360
    x[2824]   c695_1    1
    x[2824]   c2683     360
    x[2825]   c695_1    1
    x[2825]   c2686     100
    x[2826]   c695_1    1
    x[2826]   c2687     100
    x[2827]   c695_1    1
    x[2827]   c2684     560
    x[2828]   c695_1    1
    x[2828]   c2685     560
    x[2829]   c697_1    1
    x[2829]   c2694     360
    x[2830]   c697_1    1
    x[2830]   c2689     360
    x[2831]   c697_1    1
    x[2831]   c2692     100
    x[2832]   c697_1    1
    x[2832]   c2693     100
    x[2833]   c697_1    1
    x[2833]   c2690     560
    x[2834]   c697_1    1
    x[2834]   c2691     560
    x[2835]   c699_1    1
    x[2835]   c2700     360
    x[2836]   c699_1    1
    x[2836]   c2695     360
    x[2837]   c699_1    1
    x[2837]   c2698     100
    x[2838]   c699_1    1
    x[2838]   c2699     100
    x[2839]   c699_1    1
    x[2839]   c2696     560
    x[2840]   c699_1    1
    x[2840]   c2697     560
    x[2841]   c700_1    1
    x[2841]   c2706     360
    x[2842]   c700_1    1
    x[2842]   c2701     360
    x[2843]   c700_1    1
    x[2843]   c2704     100
    x[2844]   c700_1    1
    x[2844]   c2705     100
    x[2845]   c700_1    1
    x[2845]   c2702     560
    x[2846]   c700_1    1
    x[2846]   c2703     560
    x[2847]   c701_1    1
    x[2847]   c2712     360
    x[2848]   c701_1    1
    x[2848]   c2707     360
    x[2849]   c701_1    1
    x[2849]   c2710     100
    x[2850]   c701_1    1
    x[2850]   c2711     100
    x[2851]   c701_1    1
    x[2851]   c2708     560
    x[2852]   c701_1    1
    x[2852]   c2709     560
    x[2853]   c702_1    1
    x[2853]   c2718     360
    x[2854]   c702_1    1
    x[2854]   c2713     360
    x[2855]   c702_1    1
    x[2855]   c2716     100
    x[2856]   c702_1    1
    x[2856]   c2717     100
    x[2857]   c702_1    1
    x[2857]   c2714     560
    x[2858]   c702_1    1
    x[2858]   c2715     560
    x[2859]   c703_1    1
    x[2859]   c2724     360
    x[2860]   c703_1    1
    x[2860]   c2719     360
    x[2861]   c703_1    1
    x[2861]   c2722     100
    x[2862]   c703_1    1
    x[2862]   c2723     100
    x[2863]   c703_1    1
    x[2863]   c2720     560
    x[2864]   c703_1    1
    x[2864]   c2721     560
    x[2865]   c704_1    1
    x[2865]   c2730     360
    x[2866]   c704_1    1
    x[2866]   c2725     360
    x[2867]   c704_1    1
    x[2867]   c2728     100
    x[2868]   c704_1    1
    x[2868]   c2729     100
    x[2869]   c704_1    1
    x[2869]   c2726     560
    x[2870]   c704_1    1
    x[2870]   c2727     560
    x[2871]   c705_1    1
    x[2871]   c2736     360
    x[2872]   c705_1    1
    x[2872]   c2731     360
    x[2873]   c705_1    1
    x[2873]   c2734     100
    x[2874]   c705_1    1
    x[2874]   c2735     100
    x[2875]   c705_1    1
    x[2875]   c2732     560
    x[2876]   c705_1    1
    x[2876]   c2733     560
    x[2877]   c706_1    1
    x[2877]   c2742     360
    x[2878]   c706_1    1
    x[2878]   c2737     360
    x[2879]   c706_1    1
    x[2879]   c2740     100
    x[2880]   c706_1    1
    x[2880]   c2741     100
    x[2881]   c706_1    1
    x[2881]   c2738     560
    x[2882]   c706_1    1
    x[2882]   c2739     560
    x[2883]   c707_1    1
    x[2883]   c928_1    -1
    x[2883]   c2748     360
    x[2884]   c707_1    1
    x[2884]   c2743     360
    x[2885]   c707_1    1
    x[2885]   c2746     100
    x[2886]   c707_1    1
    x[2886]   c2747     100
    x[2887]   c707_1    1
    x[2887]   c2744     560
    x[2888]   c707_1    1
    x[2888]   c2745     560
    x[2889]   c708_1    1
    x[2889]   c2754     360
    x[2890]   c708_1    1
    x[2890]   c2749     360
    x[2891]   c708_1    1
    x[2891]   c2752     100
    x[2892]   c708_1    1
    x[2892]   c2753     100
    x[2893]   c708_1    1
    x[2893]   c2750     560
    x[2894]   c708_1    1
    x[2894]   c2751     560
    x[2895]   c709_1    1
    x[2895]   c2760     360
    x[2896]   c709_1    1
    x[2896]   c2755     360
    x[2897]   c709_1    1
    x[2897]   c2758     100
    x[2898]   c709_1    1
    x[2898]   c2759     100
    x[2899]   c709_1    1
    x[2899]   c2756     560
    x[2900]   c709_1    1
    x[2900]   c2757     560
    x[2901]   c711_1    1
    x[2901]   c2766     360
    x[2902]   c711_1    1
    x[2902]   c2761     360
    x[2903]   c711_1    1
    x[2903]   c2764     100
    x[2904]   c711_1    1
    x[2904]   c2765     100
    x[2905]   c711_1    1
    x[2905]   c2762     560
    x[2906]   c711_1    1
    x[2906]   c2763     560
    x[2907]   c713_1    1
    x[2907]   c2772     360
    x[2908]   c713_1    1
    x[2908]   c2767     360
    x[2909]   c713_1    1
    x[2909]   c2770     100
    x[2910]   c713_1    1
    x[2910]   c2771     100
    x[2911]   c713_1    1
    x[2911]   c2768     560
    x[2912]   c713_1    1
    x[2912]   c2769     560
    x[2913]   c715_1    1
    x[2913]   c2778     360
    x[2914]   c715_1    1
    x[2914]   c2773     360
    x[2915]   c715_1    1
    x[2915]   c2776     100
    x[2916]   c715_1    1
    x[2916]   c2777     100
    x[2917]   c715_1    1
    x[2917]   c2774     560
    x[2918]   c715_1    1
    x[2918]   c2775     560
    x[2919]   c717_1    1
    x[2919]   c2784     360
    x[2920]   c717_1    1
    x[2920]   c2779     360
    x[2921]   c717_1    1
    x[2921]   c2782     100
    x[2922]   c717_1    1
    x[2922]   c2783     100
    x[2923]   c717_1    1
    x[2923]   c2780     560
    x[2924]   c717_1    1
    x[2924]   c2781     560
    x[2925]   c719_1    1
    x[2925]   c2790     360
    x[2926]   c719_1    1
    x[2926]   c2785     360
    x[2927]   c719_1    1
    x[2927]   c2788     100
    x[2928]   c719_1    1
    x[2928]   c2789     100
    x[2929]   c719_1    1
    x[2929]   c2786     560
    x[2930]   c719_1    1
    x[2930]   c2787     560
    x[2931]   c721_1    1
    x[2931]   c2796     360
    x[2932]   c721_1    1
    x[2932]   c2791     360
    x[2933]   c721_1    1
    x[2933]   c2794     100
    x[2934]   c721_1    1
    x[2934]   c2795     100
    x[2935]   c721_1    1
    x[2935]   c2792     560
    x[2936]   c721_1    1
    x[2936]   c2793     560
    x[2937]   c722_1    1
    x[2937]   c2802     360
    x[2938]   c722_1    1
    x[2938]   c2797     360
    x[2939]   c722_1    1
    x[2939]   c2800     100
    x[2940]   c722_1    1
    x[2940]   c2801     100
    x[2941]   c722_1    1
    x[2941]   c2798     560
    x[2942]   c722_1    1
    x[2942]   c2799     560
    x[2943]   c723_1    1
    x[2943]   c2808     360
    x[2944]   c723_1    1
    x[2944]   c2803     360
    x[2945]   c723_1    1
    x[2945]   c2806     100
    x[2946]   c723_1    1
    x[2946]   c2807     100
    x[2947]   c723_1    1
    x[2947]   c2804     560
    x[2948]   c723_1    1
    x[2948]   c2805     560
    x[2949]   c724_1    1
    x[2949]   c2814     360
    x[2950]   c724_1    1
    x[2950]   c2809     360
    x[2951]   c724_1    1
    x[2951]   c2812     100
    x[2952]   c724_1    1
    x[2952]   c2813     100
    x[2953]   c724_1    1
    x[2953]   c2810     560
    x[2954]   c724_1    1
    x[2954]   c2811     560
    x[2955]   c725_1    1
    x[2955]   c2820     360
    x[2956]   c725_1    1
    x[2956]   c2815     360
    x[2957]   c725_1    1
    x[2957]   c2818     100
    x[2958]   c725_1    1
    x[2958]   c2819     100
    x[2959]   c725_1    1
    x[2959]   c2816     560
    x[2960]   c725_1    1
    x[2960]   c2817     560
    x[2961]   c726_1    1
    x[2961]   c2826     360
    x[2962]   c726_1    1
    x[2962]   c2821     360
    x[2963]   c726_1    1
    x[2963]   c2824     100
    x[2964]   c726_1    1
    x[2964]   c2825     100
    x[2965]   c726_1    1
    x[2965]   c2822     560
    x[2966]   c726_1    1
    x[2966]   c2823     560
    x[2967]   c727_1    1
    x[2967]   c2832     360
    x[2968]   c727_1    1
    x[2968]   c2827     360
    x[2969]   c727_1    1
    x[2969]   c2830     100
    x[2970]   c727_1    1
    x[2970]   c2831     100
    x[2971]   c727_1    1
    x[2971]   c2828     560
    x[2972]   c727_1    1
    x[2972]   c2829     560
    x[2973]   c728_1    1
    x[2973]   c2838     360
    x[2974]   c728_1    1
    x[2974]   c2833     360
    x[2975]   c728_1    1
    x[2975]   c2836     100
    x[2976]   c728_1    1
    x[2976]   c2837     100
    x[2977]   c728_1    1
    x[2977]   c2834     560
    x[2978]   c728_1    1
    x[2978]   c2835     560
    x[2979]   c729_1    1
    x[2979]   c929_1    -1
    x[2979]   c2844     360
    x[2980]   c729_1    1
    x[2980]   c2839     360
    x[2981]   c729_1    1
    x[2981]   c2842     100
    x[2982]   c729_1    1
    x[2982]   c2843     100
    x[2983]   c729_1    1
    x[2983]   c2840     560
    x[2984]   c729_1    1
    x[2984]   c2841     560
    x[2985]   c730_1    1
    x[2985]   c2850     360
    x[2986]   c730_1    1
    x[2986]   c2845     360
    x[2987]   c730_1    1
    x[2987]   c2848     100
    x[2988]   c730_1    1
    x[2988]   c2849     100
    x[2989]   c730_1    1
    x[2989]   c2846     560
    x[2990]   c730_1    1
    x[2990]   c2847     560
    x[2991]   c731_1    1
    x[2991]   c2856     360
    x[2992]   c731_1    1
    x[2992]   c2851     360
    x[2993]   c731_1    1
    x[2993]   c2854     100
    x[2994]   c731_1    1
    x[2994]   c2855     100
    x[2995]   c731_1    1
    x[2995]   c2852     560
    x[2996]   c731_1    1
    x[2996]   c2853     560
    x[2997]   c733_1    1
    x[2997]   c2862     360
    x[2998]   c733_1    1
    x[2998]   c2857     360
    x[2999]   c733_1    1
    x[2999]   c2860     100
    x[3000]   c733_1    1
    x[3000]   c2861     100
    x[3001]   c733_1    1
    x[3001]   c2858     560
    x[3002]   c733_1    1
    x[3002]   c2859     560
    x[3003]   c735_1    1
    x[3003]   c2868     360
    x[3004]   c735_1    1
    x[3004]   c2863     360
    x[3005]   c735_1    1
    x[3005]   c2866     100
    x[3006]   c735_1    1
    x[3006]   c2867     100
    x[3007]   c735_1    1
    x[3007]   c2864     560
    x[3008]   c735_1    1
    x[3008]   c2865     560
    x[3009]   c737_1    1
    x[3009]   c2874     360
    x[3010]   c737_1    1
    x[3010]   c2869     360
    x[3011]   c737_1    1
    x[3011]   c2872     100
    x[3012]   c737_1    1
    x[3012]   c2873     100
    x[3013]   c737_1    1
    x[3013]   c2870     560
    x[3014]   c737_1    1
    x[3014]   c2871     560
    x[3015]   c739_1    1
    x[3015]   c2880     360
    x[3016]   c739_1    1
    x[3016]   c2875     360
    x[3017]   c739_1    1
    x[3017]   c2878     100
    x[3018]   c739_1    1
    x[3018]   c2879     100
    x[3019]   c739_1    1
    x[3019]   c2876     560
    x[3020]   c739_1    1
    x[3020]   c2877     560
    x[3021]   c741_1    1
    x[3021]   c2886     360
    x[3022]   c741_1    1
    x[3022]   c2881     360
    x[3023]   c741_1    1
    x[3023]   c2884     100
    x[3024]   c741_1    1
    x[3024]   c2885     100
    x[3025]   c741_1    1
    x[3025]   c2882     560
    x[3026]   c741_1    1
    x[3026]   c2883     560
    x[3027]   c742_1    1
    x[3027]   c2892     360
    x[3028]   c742_1    1
    x[3028]   c2887     360
    x[3029]   c742_1    1
    x[3029]   c2890     100
    x[3030]   c742_1    1
    x[3030]   c2891     100
    x[3031]   c742_1    1
    x[3031]   c2888     560
    x[3032]   c742_1    1
    x[3032]   c2889     560
    x[3033]   c743_1    1
    x[3033]   c2898     360
    x[3034]   c743_1    1
    x[3034]   c2893     360
    x[3035]   c743_1    1
    x[3035]   c2896     100
    x[3036]   c743_1    1
    x[3036]   c2897     100
    x[3037]   c743_1    1
    x[3037]   c2894     560
    x[3038]   c743_1    1
    x[3038]   c2895     560
    x[3039]   c744_1    1
    x[3039]   c2904     360
    x[3040]   c744_1    1
    x[3040]   c2899     360
    x[3041]   c744_1    1
    x[3041]   c2902     100
    x[3042]   c744_1    1
    x[3042]   c2903     100
    x[3043]   c744_1    1
    x[3043]   c2900     560
    x[3044]   c744_1    1
    x[3044]   c2901     560
    x[3045]   c745_1    1
    x[3045]   c2910     360
    x[3046]   c745_1    1
    x[3046]   c2905     360
    x[3047]   c745_1    1
    x[3047]   c2908     100
    x[3048]   c745_1    1
    x[3048]   c2909     100
    x[3049]   c745_1    1
    x[3049]   c2906     560
    x[3050]   c745_1    1
    x[3050]   c2907     560
    x[3051]   c746_1    1
    x[3051]   c2916     360
    x[3052]   c746_1    1
    x[3052]   c2911     360
    x[3053]   c746_1    1
    x[3053]   c2914     100
    x[3054]   c746_1    1
    x[3054]   c2915     100
    x[3055]   c746_1    1
    x[3055]   c2912     560
    x[3056]   c746_1    1
    x[3056]   c2913     560
    x[3057]   c747_1    1
    x[3057]   c2922     360
    x[3058]   c747_1    1
    x[3058]   c2917     360
    x[3059]   c747_1    1
    x[3059]   c2920     100
    x[3060]   c747_1    1
    x[3060]   c2921     100
    x[3061]   c747_1    1
    x[3061]   c2918     560
    x[3062]   c747_1    1
    x[3062]   c2919     560
    x[3063]   c748_1    1
    x[3063]   c2928     360
    x[3064]   c748_1    1
    x[3064]   c2923     360
    x[3065]   c748_1    1
    x[3065]   c2926     100
    x[3066]   c748_1    1
    x[3066]   c2927     100
    x[3067]   c748_1    1
    x[3067]   c2924     560
    x[3068]   c748_1    1
    x[3068]   c2925     560
    x[3069]   c749_1    1
    x[3069]   c930_1    -1
    x[3069]   c2934     360
    x[3070]   c749_1    1
    x[3070]   c2929     360
    x[3071]   c749_1    1
    x[3071]   c2932     100
    x[3072]   c749_1    1
    x[3072]   c2933     100
    x[3073]   c749_1    1
    x[3073]   c2930     560
    x[3074]   c749_1    1
    x[3074]   c2931     560
    x[3075]   c750_1    1
    x[3075]   c2940     360
    x[3076]   c750_1    1
    x[3076]   c2935     360
    x[3077]   c750_1    1
    x[3077]   c2938     100
    x[3078]   c750_1    1
    x[3078]   c2939     100
    x[3079]   c750_1    1
    x[3079]   c2936     560
    x[3080]   c750_1    1
    x[3080]   c2937     560
    x[3081]   c751_1    1
    x[3081]   c2946     360
    x[3082]   c751_1    1
    x[3082]   c2941     360
    x[3083]   c751_1    1
    x[3083]   c2944     100
    x[3084]   c751_1    1
    x[3084]   c2945     100
    x[3085]   c751_1    1
    x[3085]   c2942     560
    x[3086]   c751_1    1
    x[3086]   c2943     560
    x[3087]   c753_1    1
    x[3087]   c2952     360
    x[3088]   c753_1    1
    x[3088]   c2947     360
    x[3089]   c753_1    1
    x[3089]   c2950     100
    x[3090]   c753_1    1
    x[3090]   c2951     100
    x[3091]   c753_1    1
    x[3091]   c2948     560
    x[3092]   c753_1    1
    x[3092]   c2949     560
    x[3093]   c755_1    1
    x[3093]   c2958     360
    x[3094]   c755_1    1
    x[3094]   c2953     360
    x[3095]   c755_1    1
    x[3095]   c2956     100
    x[3096]   c755_1    1
    x[3096]   c2957     100
    x[3097]   c755_1    1
    x[3097]   c2954     560
    x[3098]   c755_1    1
    x[3098]   c2955     560
    x[3099]   c757_1    1
    x[3099]   c2964     360
    x[3100]   c757_1    1
    x[3100]   c2959     360
    x[3101]   c757_1    1
    x[3101]   c2962     100
    x[3102]   c757_1    1
    x[3102]   c2963     100
    x[3103]   c757_1    1
    x[3103]   c2960     560
    x[3104]   c757_1    1
    x[3104]   c2961     560
    x[3105]   c759_1    1
    x[3105]   c2970     360
    x[3106]   c759_1    1
    x[3106]   c2965     360
    x[3107]   c759_1    1
    x[3107]   c2968     100
    x[3108]   c759_1    1
    x[3108]   c2969     100
    x[3109]   c759_1    1
    x[3109]   c2966     560
    x[3110]   c759_1    1
    x[3110]   c2967     560
    x[3111]   c760_1    1
    x[3111]   c2976     360
    x[3112]   c760_1    1
    x[3112]   c2971     360
    x[3113]   c760_1    1
    x[3113]   c2974     100
    x[3114]   c760_1    1
    x[3114]   c2975     100
    x[3115]   c760_1    1
    x[3115]   c2972     560
    x[3116]   c760_1    1
    x[3116]   c2973     560
    x[3117]   c761_1    1
    x[3117]   c2982     360
    x[3118]   c761_1    1
    x[3118]   c2977     360
    x[3119]   c761_1    1
    x[3119]   c2980     100
    x[3120]   c761_1    1
    x[3120]   c2981     100
    x[3121]   c761_1    1
    x[3121]   c2978     560
    x[3122]   c761_1    1
    x[3122]   c2979     560
    x[3123]   c762_1    1
    x[3123]   c2988     360
    x[3124]   c762_1    1
    x[3124]   c2983     360
    x[3125]   c762_1    1
    x[3125]   c2986     100
    x[3126]   c762_1    1
    x[3126]   c2987     100
    x[3127]   c762_1    1
    x[3127]   c2984     560
    x[3128]   c762_1    1
    x[3128]   c2985     560
    x[3129]   c763_1    1
    x[3129]   c2994     360
    x[3130]   c763_1    1
    x[3130]   c2989     360
    x[3131]   c763_1    1
    x[3131]   c2992     100
    x[3132]   c763_1    1
    x[3132]   c2993     100
    x[3133]   c763_1    1
    x[3133]   c2990     560
    x[3134]   c763_1    1
    x[3134]   c2991     560
    x[3135]   c764_1    1
    x[3135]   c3000     360
    x[3136]   c764_1    1
    x[3136]   c2995     360
    x[3137]   c764_1    1
    x[3137]   c2998     100
    x[3138]   c764_1    1
    x[3138]   c2999     100
    x[3139]   c764_1    1
    x[3139]   c2996     560
    x[3140]   c764_1    1
    x[3140]   c2997     560
    x[3141]   c765_1    1
    x[3141]   c3006     360
    x[3142]   c765_1    1
    x[3142]   c3001     360
    x[3143]   c765_1    1
    x[3143]   c3004     100
    x[3144]   c765_1    1
    x[3144]   c3005     100
    x[3145]   c765_1    1
    x[3145]   c3002     560
    x[3146]   c765_1    1
    x[3146]   c3003     560
    x[3147]   c766_1    1
    x[3147]   c3012     360
    x[3148]   c766_1    1
    x[3148]   c3007     360
    x[3149]   c766_1    1
    x[3149]   c3010     100
    x[3150]   c766_1    1
    x[3150]   c3011     100
    x[3151]   c766_1    1
    x[3151]   c3008     560
    x[3152]   c766_1    1
    x[3152]   c3009     560
    x[3153]   c767_1    1
    x[3153]   c931_1    -1
    x[3153]   c3018     360
    x[3154]   c767_1    1
    x[3154]   c3013     360
    x[3155]   c767_1    1
    x[3155]   c3016     100
    x[3156]   c767_1    1
    x[3156]   c3017     100
    x[3157]   c767_1    1
    x[3157]   c3014     560
    x[3158]   c767_1    1
    x[3158]   c3015     560
    x[3159]   c768_1    1
    x[3159]   c3024     360
    x[3160]   c768_1    1
    x[3160]   c3019     360
    x[3161]   c768_1    1
    x[3161]   c3022     100
    x[3162]   c768_1    1
    x[3162]   c3023     100
    x[3163]   c768_1    1
    x[3163]   c3020     560
    x[3164]   c768_1    1
    x[3164]   c3021     560
    x[3165]   c769_1    1
    x[3165]   c3030     360
    x[3166]   c769_1    1
    x[3166]   c3025     360
    x[3167]   c769_1    1
    x[3167]   c3028     100
    x[3168]   c769_1    1
    x[3168]   c3029     100
    x[3169]   c769_1    1
    x[3169]   c3026     560
    x[3170]   c769_1    1
    x[3170]   c3027     560
    x[3171]   c771_1    1
    x[3171]   c3036     360
    x[3172]   c771_1    1
    x[3172]   c3031     360
    x[3173]   c771_1    1
    x[3173]   c3034     100
    x[3174]   c771_1    1
    x[3174]   c3035     100
    x[3175]   c771_1    1
    x[3175]   c3032     560
    x[3176]   c771_1    1
    x[3176]   c3033     560
    x[3177]   c773_1    1
    x[3177]   c3042     360
    x[3178]   c773_1    1
    x[3178]   c3037     360
    x[3179]   c773_1    1
    x[3179]   c3040     100
    x[3180]   c773_1    1
    x[3180]   c3041     100
    x[3181]   c773_1    1
    x[3181]   c3038     560
    x[3182]   c773_1    1
    x[3182]   c3039     560
    x[3183]   c775_1    1
    x[3183]   c3048     360
    x[3184]   c775_1    1
    x[3184]   c3043     360
    x[3185]   c775_1    1
    x[3185]   c3046     100
    x[3186]   c775_1    1
    x[3186]   c3047     100
    x[3187]   c775_1    1
    x[3187]   c3044     560
    x[3188]   c775_1    1
    x[3188]   c3045     560
    x[3189]   c776_1    1
    x[3189]   c3054     360
    x[3190]   c776_1    1
    x[3190]   c3049     360
    x[3191]   c776_1    1
    x[3191]   c3052     100
    x[3192]   c776_1    1
    x[3192]   c3053     100
    x[3193]   c776_1    1
    x[3193]   c3050     560
    x[3194]   c776_1    1
    x[3194]   c3051     560
    x[3195]   c777_1    1
    x[3195]   c3060     360
    x[3196]   c777_1    1
    x[3196]   c3055     360
    x[3197]   c777_1    1
    x[3197]   c3058     100
    x[3198]   c777_1    1
    x[3198]   c3059     100
    x[3199]   c777_1    1
    x[3199]   c3056     560
    x[3200]   c777_1    1
    x[3200]   c3057     560
    x[3201]   c778_1    1
    x[3201]   c3066     360
    x[3202]   c778_1    1
    x[3202]   c3061     360
    x[3203]   c778_1    1
    x[3203]   c3064     100
    x[3204]   c778_1    1
    x[3204]   c3065     100
    x[3205]   c778_1    1
    x[3205]   c3062     560
    x[3206]   c778_1    1
    x[3206]   c3063     560
    x[3207]   c779_1    1
    x[3207]   c3072     360
    x[3208]   c779_1    1
    x[3208]   c3067     360
    x[3209]   c779_1    1
    x[3209]   c3070     100
    x[3210]   c779_1    1
    x[3210]   c3071     100
    x[3211]   c779_1    1
    x[3211]   c3068     560
    x[3212]   c779_1    1
    x[3212]   c3069     560
    x[3213]   c780_1    1
    x[3213]   c3078     360
    x[3214]   c780_1    1
    x[3214]   c3073     360
    x[3215]   c780_1    1
    x[3215]   c3076     100
    x[3216]   c780_1    1
    x[3216]   c3077     100
    x[3217]   c780_1    1
    x[3217]   c3074     560
    x[3218]   c780_1    1
    x[3218]   c3075     560
    x[3219]   c781_1    1
    x[3219]   c3084     360
    x[3220]   c781_1    1
    x[3220]   c3079     360
    x[3221]   c781_1    1
    x[3221]   c3082     100
    x[3222]   c781_1    1
    x[3222]   c3083     100
    x[3223]   c781_1    1
    x[3223]   c3080     560
    x[3224]   c781_1    1
    x[3224]   c3081     560
    x[3225]   c782_1    1
    x[3225]   c3090     360
    x[3226]   c782_1    1
    x[3226]   c3085     360
    x[3227]   c782_1    1
    x[3227]   c3088     100
    x[3228]   c782_1    1
    x[3228]   c3089     100
    x[3229]   c782_1    1
    x[3229]   c3086     560
    x[3230]   c782_1    1
    x[3230]   c3087     560
    x[3231]   c783_1    1
    x[3231]   c932_1    -1
    x[3231]   c3096     360
    x[3232]   c783_1    1
    x[3232]   c3091     360
    x[3233]   c783_1    1
    x[3233]   c3094     100
    x[3234]   c783_1    1
    x[3234]   c3095     100
    x[3235]   c783_1    1
    x[3235]   c3092     560
    x[3236]   c783_1    1
    x[3236]   c3093     560
    x[3237]   c784_1    1
    x[3237]   c3102     360
    x[3238]   c784_1    1
    x[3238]   c3097     360
    x[3239]   c784_1    1
    x[3239]   c3100     100
    x[3240]   c784_1    1
    x[3240]   c3101     100
    x[3241]   c784_1    1
    x[3241]   c3098     560
    x[3242]   c784_1    1
    x[3242]   c3099     560
    x[3243]   c785_1    1
    x[3243]   c3108     360
    x[3244]   c785_1    1
    x[3244]   c3103     360
    x[3245]   c785_1    1
    x[3245]   c3106     100
    x[3246]   c785_1    1
    x[3246]   c3107     100
    x[3247]   c785_1    1
    x[3247]   c3104     560
    x[3248]   c785_1    1
    x[3248]   c3105     560
    x[3249]   c787_1    1
    x[3249]   c3114     360
    x[3250]   c787_1    1
    x[3250]   c3109     360
    x[3251]   c787_1    1
    x[3251]   c3112     100
    x[3252]   c787_1    1
    x[3252]   c3113     100
    x[3253]   c787_1    1
    x[3253]   c3110     560
    x[3254]   c787_1    1
    x[3254]   c3111     560
    x[3255]   c789_1    1
    x[3255]   c3120     360
    x[3256]   c789_1    1
    x[3256]   c3115     360
    x[3257]   c789_1    1
    x[3257]   c3118     100
    x[3258]   c789_1    1
    x[3258]   c3119     100
    x[3259]   c789_1    1
    x[3259]   c3116     560
    x[3260]   c789_1    1
    x[3260]   c3117     560
    x[3261]   c790_1    1
    x[3261]   c3126     360
    x[3262]   c790_1    1
    x[3262]   c3121     360
    x[3263]   c790_1    1
    x[3263]   c3124     100
    x[3264]   c790_1    1
    x[3264]   c3125     100
    x[3265]   c790_1    1
    x[3265]   c3122     560
    x[3266]   c790_1    1
    x[3266]   c3123     560
    x[3267]   c791_1    1
    x[3267]   c3132     360
    x[3268]   c791_1    1
    x[3268]   c3127     360
    x[3269]   c791_1    1
    x[3269]   c3130     100
    x[3270]   c791_1    1
    x[3270]   c3131     100
    x[3271]   c791_1    1
    x[3271]   c3128     560
    x[3272]   c791_1    1
    x[3272]   c3129     560
    x[3273]   c792_1    1
    x[3273]   c3138     360
    x[3274]   c792_1    1
    x[3274]   c3133     360
    x[3275]   c792_1    1
    x[3275]   c3136     100
    x[3276]   c792_1    1
    x[3276]   c3137     100
    x[3277]   c792_1    1
    x[3277]   c3134     560
    x[3278]   c792_1    1
    x[3278]   c3135     560
    x[3279]   c793_1    1
    x[3279]   c3144     360
    x[3280]   c793_1    1
    x[3280]   c3139     360
    x[3281]   c793_1    1
    x[3281]   c3142     100
    x[3282]   c793_1    1
    x[3282]   c3143     100
    x[3283]   c793_1    1
    x[3283]   c3140     560
    x[3284]   c793_1    1
    x[3284]   c3141     560
    x[3285]   c794_1    1
    x[3285]   c3150     360
    x[3286]   c794_1    1
    x[3286]   c3145     360
    x[3287]   c794_1    1
    x[3287]   c3148     100
    x[3288]   c794_1    1
    x[3288]   c3149     100
    x[3289]   c794_1    1
    x[3289]   c3146     560
    x[3290]   c794_1    1
    x[3290]   c3147     560
    x[3291]   c795_1    1
    x[3291]   c3156     360
    x[3292]   c795_1    1
    x[3292]   c3151     360
    x[3293]   c795_1    1
    x[3293]   c3154     100
    x[3294]   c795_1    1
    x[3294]   c3155     100
    x[3295]   c795_1    1
    x[3295]   c3152     560
    x[3296]   c795_1    1
    x[3296]   c3153     560
    x[3297]   c796_1    1
    x[3297]   c3162     360
    x[3298]   c796_1    1
    x[3298]   c3157     360
    x[3299]   c796_1    1
    x[3299]   c3160     100
    x[3300]   c796_1    1
    x[3300]   c3161     100
    x[3301]   c796_1    1
    x[3301]   c3158     560
    x[3302]   c796_1    1
    x[3302]   c3159     560
    x[3303]   c797_1    1
    x[3303]   c933_1    -1
    x[3303]   c3168     360
    x[3304]   c797_1    1
    x[3304]   c3163     360
    x[3305]   c797_1    1
    x[3305]   c3166     100
    x[3306]   c797_1    1
    x[3306]   c3167     100
    x[3307]   c797_1    1
    x[3307]   c3164     560
    x[3308]   c797_1    1
    x[3308]   c3165     560
    x[3309]   c798_1    1
    x[3309]   c3174     360
    x[3310]   c798_1    1
    x[3310]   c3169     360
    x[3311]   c798_1    1
    x[3311]   c3172     100
    x[3312]   c798_1    1
    x[3312]   c3173     100
    x[3313]   c798_1    1
    x[3313]   c3170     560
    x[3314]   c798_1    1
    x[3314]   c3171     560
    x[3315]   c799_1    1
    x[3315]   c3180     360
    x[3316]   c799_1    1
    x[3316]   c3175     360
    x[3317]   c799_1    1
    x[3317]   c3178     100
    x[3318]   c799_1    1
    x[3318]   c3179     100
    x[3319]   c799_1    1
    x[3319]   c3176     560
    x[3320]   c799_1    1
    x[3320]   c3177     560
    x[3321]   c801_1    1
    x[3321]   c3186     360
    x[3322]   c801_1    1
    x[3322]   c3181     360
    x[3323]   c801_1    1
    x[3323]   c3184     100
    x[3324]   c801_1    1
    x[3324]   c3185     100
    x[3325]   c801_1    1
    x[3325]   c3182     560
    x[3326]   c801_1    1
    x[3326]   c3183     560
    x[3327]   c802_1    1
    x[3327]   c3192     360
    x[3328]   c802_1    1
    x[3328]   c3187     360
    x[3329]   c802_1    1
    x[3329]   c3190     100
    x[3330]   c802_1    1
    x[3330]   c3191     100
    x[3331]   c802_1    1
    x[3331]   c3188     560
    x[3332]   c802_1    1
    x[3332]   c3189     560
    x[3333]   c803_1    1
    x[3333]   c3198     360
    x[3334]   c803_1    1
    x[3334]   c3193     360
    x[3335]   c803_1    1
    x[3335]   c3196     100
    x[3336]   c803_1    1
    x[3336]   c3197     100
    x[3337]   c803_1    1
    x[3337]   c3194     560
    x[3338]   c803_1    1
    x[3338]   c3195     560
    x[3339]   c804_1    1
    x[3339]   c3204     360
    x[3340]   c804_1    1
    x[3340]   c3199     360
    x[3341]   c804_1    1
    x[3341]   c3202     100
    x[3342]   c804_1    1
    x[3342]   c3203     100
    x[3343]   c804_1    1
    x[3343]   c3200     560
    x[3344]   c804_1    1
    x[3344]   c3201     560
    x[3345]   c805_1    1
    x[3345]   c3210     360
    x[3346]   c805_1    1
    x[3346]   c3205     360
    x[3347]   c805_1    1
    x[3347]   c3208     100
    x[3348]   c805_1    1
    x[3348]   c3209     100
    x[3349]   c805_1    1
    x[3349]   c3206     560
    x[3350]   c805_1    1
    x[3350]   c3207     560
    x[3351]   c806_1    1
    x[3351]   c3216     360
    x[3352]   c806_1    1
    x[3352]   c3211     360
    x[3353]   c806_1    1
    x[3353]   c3214     100
    x[3354]   c806_1    1
    x[3354]   c3215     100
    x[3355]   c806_1    1
    x[3355]   c3212     560
    x[3356]   c806_1    1
    x[3356]   c3213     560
    x[3357]   c807_1    1
    x[3357]   c3222     360
    x[3358]   c807_1    1
    x[3358]   c3217     360
    x[3359]   c807_1    1
    x[3359]   c3220     100
    x[3360]   c807_1    1
    x[3360]   c3221     100
    x[3361]   c807_1    1
    x[3361]   c3218     560
    x[3362]   c807_1    1
    x[3362]   c3219     560
    x[3363]   c808_1    1
    x[3363]   c3228     360
    x[3364]   c808_1    1
    x[3364]   c3223     360
    x[3365]   c808_1    1
    x[3365]   c3226     100
    x[3366]   c808_1    1
    x[3366]   c3227     100
    x[3367]   c808_1    1
    x[3367]   c3224     560
    x[3368]   c808_1    1
    x[3368]   c3225     560
    x[3369]   c809_1    1
    x[3369]   c934_1    -1
    x[3369]   c3234     360
    x[3370]   c809_1    1
    x[3370]   c3229     360
    x[3371]   c809_1    1
    x[3371]   c3232     100
    x[3372]   c809_1    1
    x[3372]   c3233     100
    x[3373]   c809_1    1
    x[3373]   c3230     560
    x[3374]   c809_1    1
    x[3374]   c3231     560
    x[3375]   c810_1    1
    x[3375]   c3240     360
    x[3376]   c810_1    1
    x[3376]   c3235     360
    x[3377]   c810_1    1
    x[3377]   c3238     100
    x[3378]   c810_1    1
    x[3378]   c3239     100
    x[3379]   c810_1    1
    x[3379]   c3236     560
    x[3380]   c810_1    1
    x[3380]   c3237     560
    x[3381]   c811_1    1
    x[3381]   c3246     360
    x[3382]   c811_1    1
    x[3382]   c3241     360
    x[3383]   c811_1    1
    x[3383]   c3244     100
    x[3384]   c811_1    1
    x[3384]   c3245     100
    x[3385]   c811_1    1
    x[3385]   c3242     560
    x[3386]   c811_1    1
    x[3386]   c3243     560
    x[3387]   c812_1    1
    x[3387]   c3252     360
    x[3388]   c812_1    1
    x[3388]   c3247     360
    x[3389]   c812_1    1
    x[3389]   c3250     100
    x[3390]   c812_1    1
    x[3390]   c3251     100
    x[3391]   c812_1    1
    x[3391]   c3248     560
    x[3392]   c812_1    1
    x[3392]   c3249     560
    x[3393]   c813_1    1
    x[3393]   c3258     360
    x[3394]   c813_1    1
    x[3394]   c3253     360
    x[3395]   c813_1    1
    x[3395]   c3256     100
    x[3396]   c813_1    1
    x[3396]   c3257     100
    x[3397]   c813_1    1
    x[3397]   c3254     560
    x[3398]   c813_1    1
    x[3398]   c3255     560
    x[3399]   c814_1    1
    x[3399]   c3264     360
    x[3400]   c814_1    1
    x[3400]   c3259     360
    x[3401]   c814_1    1
    x[3401]   c3262     100
    x[3402]   c814_1    1
    x[3402]   c3263     100
    x[3403]   c814_1    1
    x[3403]   c3260     560
    x[3404]   c814_1    1
    x[3404]   c3261     560
    x[3405]   c815_1    1
    x[3405]   c3270     360
    x[3406]   c815_1    1
    x[3406]   c3265     360
    x[3407]   c815_1    1
    x[3407]   c3268     100
    x[3408]   c815_1    1
    x[3408]   c3269     100
    x[3409]   c815_1    1
    x[3409]   c3266     560
    x[3410]   c815_1    1
    x[3410]   c3267     560
    x[3411]   c816_1    1
    x[3411]   c3276     360
    x[3412]   c816_1    1
    x[3412]   c3271     360
    x[3413]   c816_1    1
    x[3413]   c3274     100
    x[3414]   c816_1    1
    x[3414]   c3275     100
    x[3415]   c816_1    1
    x[3415]   c3272     560
    x[3416]   c816_1    1
    x[3416]   c3273     560
    x[3417]   c817_1    1
    x[3417]   c3282     360
    x[3418]   c817_1    1
    x[3418]   c3277     360
    x[3419]   c817_1    1
    x[3419]   c3280     100
    x[3420]   c817_1    1
    x[3420]   c3281     100
    x[3421]   c817_1    1
    x[3421]   c3278     560
    x[3422]   c817_1    1
    x[3422]   c3279     560
    x[3423]   c818_1    1
    x[3423]   c3288     360
    x[3424]   c818_1    1
    x[3424]   c3283     360
    x[3425]   c818_1    1
    x[3425]   c3286     100
    x[3426]   c818_1    1
    x[3426]   c3287     100
    x[3427]   c818_1    1
    x[3427]   c3284     560
    x[3428]   c818_1    1
    x[3428]   c3285     560
    x[3429]   c819_1    1
    x[3429]   c935_1    -1
    x[3429]   c3294     360
    x[3430]   c819_1    1
    x[3430]   c3289     360
    x[3431]   c819_1    1
    x[3431]   c3292     100
    x[3432]   c819_1    1
    x[3432]   c3293     100
    x[3433]   c819_1    1
    x[3433]   c3290     560
    x[3434]   c819_1    1
    x[3434]   c3291     560
    x[3435]   c820_1    1
    x[3435]   c3300     360
    x[3436]   c820_1    1
    x[3436]   c3295     360
    x[3437]   c820_1    1
    x[3437]   c3298     100
    x[3438]   c820_1    1
    x[3438]   c3299     100
    x[3439]   c820_1    1
    x[3439]   c3296     560
    x[3440]   c820_1    1
    x[3440]   c3297     560
    x[3441]   c821_1    1
    x[3441]   c3306     360
    x[3442]   c821_1    1
    x[3442]   c3301     360
    x[3443]   c821_1    1
    x[3443]   c3304     100
    x[3444]   c821_1    1
    x[3444]   c3305     100
    x[3445]   c821_1    1
    x[3445]   c3302     560
    x[3446]   c821_1    1
    x[3446]   c3303     560
    x[3447]   c823_1    1
    x[3447]   c3312     360
    x[3448]   c823_1    1
    x[3448]   c3307     360
    x[3449]   c823_1    1
    x[3449]   c3310     100
    x[3450]   c823_1    1
    x[3450]   c3311     100
    x[3451]   c823_1    1
    x[3451]   c3308     560
    x[3452]   c823_1    1
    x[3452]   c3309     560
    x[3453]   c825_1    1
    x[3453]   c3318     360
    x[3454]   c825_1    1
    x[3454]   c3313     360
    x[3455]   c825_1    1
    x[3455]   c3316     100
    x[3456]   c825_1    1
    x[3456]   c3317     100
    x[3457]   c825_1    1
    x[3457]   c3314     560
    x[3458]   c825_1    1
    x[3458]   c3315     560
    x[3459]   c827_1    1
    x[3459]   c3324     360
    x[3460]   c827_1    1
    x[3460]   c3319     360
    x[3461]   c827_1    1
    x[3461]   c3322     100
    x[3462]   c827_1    1
    x[3462]   c3323     100
    x[3463]   c827_1    1
    x[3463]   c3320     560
    x[3464]   c827_1    1
    x[3464]   c3321     560
    x[3465]   c829_1    1
    x[3465]   c3330     360
    x[3466]   c829_1    1
    x[3466]   c3325     360
    x[3467]   c829_1    1
    x[3467]   c3328     100
    x[3468]   c829_1    1
    x[3468]   c3329     100
    x[3469]   c829_1    1
    x[3469]   c3326     560
    x[3470]   c829_1    1
    x[3470]   c3327     560
    x[3471]   c831_1    1
    x[3471]   c3336     360
    x[3472]   c831_1    1
    x[3472]   c3331     360
    x[3473]   c831_1    1
    x[3473]   c3334     100
    x[3474]   c831_1    1
    x[3474]   c3335     100
    x[3475]   c831_1    1
    x[3475]   c3332     560
    x[3476]   c831_1    1
    x[3476]   c3333     560
    x[3477]   c833_1    1
    x[3477]   c3342     360
    x[3478]   c833_1    1
    x[3478]   c3337     360
    x[3479]   c833_1    1
    x[3479]   c3340     100
    x[3480]   c833_1    1
    x[3480]   c3341     100
    x[3481]   c833_1    1
    x[3481]   c3338     560
    x[3482]   c833_1    1
    x[3482]   c3339     560
    x[3483]   c835_1    1
    x[3483]   c3348     360
    x[3484]   c835_1    1
    x[3484]   c3343     360
    x[3485]   c835_1    1
    x[3485]   c3346     100
    x[3486]   c835_1    1
    x[3486]   c3347     100
    x[3487]   c835_1    1
    x[3487]   c3344     560
    x[3488]   c835_1    1
    x[3488]   c3345     560
    x[3489]   c837_1    1
    x[3489]   c3354     360
    x[3490]   c837_1    1
    x[3490]   c3349     360
    x[3491]   c837_1    1
    x[3491]   c3352     100
    x[3492]   c837_1    1
    x[3492]   c3353     100
    x[3493]   c837_1    1
    x[3493]   c3350     560
    x[3494]   c837_1    1
    x[3494]   c3351     560
    x[3495]   c839_1    1
    x[3495]   c3360     360
    x[3496]   c839_1    1
    x[3496]   c3355     360
    x[3497]   c839_1    1
    x[3497]   c3358     100
    x[3498]   c839_1    1
    x[3498]   c3359     100
    x[3499]   c839_1    1
    x[3499]   c3356     560
    x[3500]   c839_1    1
    x[3500]   c3357     560
    x[3501]   c841_1    1
    x[3501]   c3366     360
    x[3502]   c841_1    1
    x[3502]   c3361     360
    x[3503]   c841_1    1
    x[3503]   c3364     100
    x[3504]   c841_1    1
    x[3504]   c3365     100
    x[3505]   c841_1    1
    x[3505]   c3362     560
    x[3506]   c841_1    1
    x[3506]   c3363     560
    x[3507]   c843_1    1
    x[3507]   c3372     360
    x[3508]   c843_1    1
    x[3508]   c3367     360
    x[3509]   c843_1    1
    x[3509]   c3370     100
    x[3510]   c843_1    1
    x[3510]   c3371     100
    x[3511]   c843_1    1
    x[3511]   c3368     560
    x[3512]   c843_1    1
    x[3512]   c3369     560
    x[3513]   c845_1    1
    x[3513]   c3378     360
    x[3514]   c845_1    1
    x[3514]   c3373     360
    x[3515]   c845_1    1
    x[3515]   c3376     100
    x[3516]   c845_1    1
    x[3516]   c3377     100
    x[3517]   c845_1    1
    x[3517]   c3374     560
    x[3518]   c845_1    1
    x[3518]   c3375     560
    x[3519]   c847_1    1
    x[3519]   c3384     360
    x[3520]   c847_1    1
    x[3520]   c3379     360
    x[3521]   c847_1    1
    x[3521]   c3382     100
    x[3522]   c847_1    1
    x[3522]   c3383     100
    x[3523]   c847_1    1
    x[3523]   c3380     560
    x[3524]   c847_1    1
    x[3524]   c3381     560
    x[3525]   c849_1    1
    x[3525]   c3390     360
    x[3526]   c849_1    1
    x[3526]   c3385     360
    x[3527]   c849_1    1
    x[3527]   c3388     100
    x[3528]   c849_1    1
    x[3528]   c3389     100
    x[3529]   c849_1    1
    x[3529]   c3386     560
    x[3530]   c849_1    1
    x[3530]   c3387     560
    x[3531]   c851_1    1
    x[3531]   c3396     360
    x[3532]   c851_1    1
    x[3532]   c3391     360
    x[3533]   c851_1    1
    x[3533]   c3394     100
    x[3534]   c851_1    1
    x[3534]   c3395     100
    x[3535]   c851_1    1
    x[3535]   c3392     560
    x[3536]   c851_1    1
    x[3536]   c3393     560
    x[3537]   c853_1    1
    x[3537]   c3402     360
    x[3538]   c853_1    1
    x[3538]   c3397     360
    x[3539]   c853_1    1
    x[3539]   c3400     100
    x[3540]   c853_1    1
    x[3540]   c3401     100
    x[3541]   c853_1    1
    x[3541]   c3398     560
    x[3542]   c853_1    1
    x[3542]   c3399     560
    x[3543]   c855_1    1
    x[3543]   c3408     360
    x[3544]   c855_1    1
    x[3544]   c3403     360
    x[3545]   c855_1    1
    x[3545]   c3406     100
    x[3546]   c855_1    1
    x[3546]   c3407     100
    x[3547]   c855_1    1
    x[3547]   c3404     560
    x[3548]   c855_1    1
    x[3548]   c3405     560
    x[3549]   c857_1    1
    x[3549]   c3414     360
    x[3550]   c857_1    1
    x[3550]   c3409     360
    x[3551]   c857_1    1
    x[3551]   c3412     100
    x[3552]   c857_1    1
    x[3552]   c3413     100
    x[3553]   c857_1    1
    x[3553]   c3410     560
    x[3554]   c857_1    1
    x[3554]   c3411     560
    x[3555]   c859_1    1
    x[3555]   c3420     360
    x[3556]   c859_1    1
    x[3556]   c3415     360
    x[3557]   c859_1    1
    x[3557]   c3418     100
    x[3558]   c859_1    1
    x[3558]   c3419     100
    x[3559]   c859_1    1
    x[3559]   c3416     560
    x[3560]   c859_1    1
    x[3560]   c3417     560
    x[3561]   c861_1    1
    x[3561]   c3426     360
    x[3562]   c861_1    1
    x[3562]   c3421     360
    x[3563]   c861_1    1
    x[3563]   c3424     100
    x[3564]   c861_1    1
    x[3564]   c3425     100
    x[3565]   c861_1    1
    x[3565]   c3422     560
    x[3566]   c861_1    1
    x[3566]   c3423     560
    x[3567]   c863_1    1
    x[3567]   c3432     360
    x[3568]   c863_1    1
    x[3568]   c3427     360
    x[3569]   c863_1    1
    x[3569]   c3430     100
    x[3570]   c863_1    1
    x[3570]   c3431     100
    x[3571]   c863_1    1
    x[3571]   c3428     560
    x[3572]   c863_1    1
    x[3572]   c3429     560
    x[3573]   c865_1    1
    x[3573]   c3438     360
    x[3574]   c865_1    1
    x[3574]   c3433     360
    x[3575]   c865_1    1
    x[3575]   c3436     100
    x[3576]   c865_1    1
    x[3576]   c3437     100
    x[3577]   c865_1    1
    x[3577]   c3434     560
    x[3578]   c865_1    1
    x[3578]   c3435     560
    x[3579]   c867_1    1
    x[3579]   c3444     360
    x[3580]   c867_1    1
    x[3580]   c3439     360
    x[3581]   c867_1    1
    x[3581]   c3442     100
    x[3582]   c867_1    1
    x[3582]   c3443     100
    x[3583]   c867_1    1
    x[3583]   c3440     560
    x[3584]   c867_1    1
    x[3584]   c3441     560
    x[3585]   c869_1    1
    x[3585]   c3450     360
    x[3586]   c869_1    1
    x[3586]   c3445     360
    x[3587]   c869_1    1
    x[3587]   c3448     100
    x[3588]   c869_1    1
    x[3588]   c3449     100
    x[3589]   c869_1    1
    x[3589]   c3446     560
    x[3590]   c869_1    1
    x[3590]   c3447     560
    x[3591]   c871_1    1
    x[3591]   c3456     360
    x[3592]   c871_1    1
    x[3592]   c3451     360
    x[3593]   c871_1    1
    x[3593]   c3454     100
    x[3594]   c871_1    1
    x[3594]   c3455     100
    x[3595]   c871_1    1
    x[3595]   c3452     560
    x[3596]   c871_1    1
    x[3596]   c3453     560
    x[3597]   c873_1    1
    x[3597]   c3462     360
    x[3598]   c873_1    1
    x[3598]   c3457     360
    x[3599]   c873_1    1
    x[3599]   c3460     100
    x[3600]   c873_1    1
    x[3600]   c3461     100
    x[3601]   c873_1    1
    x[3601]   c3458     560
    x[3602]   c873_1    1
    x[3602]   c3459     560
    x[3603]   c875_1    1
    x[3603]   c3468     360
    x[3604]   c875_1    1
    x[3604]   c3463     360
    x[3605]   c875_1    1
    x[3605]   c3466     100
    x[3606]   c875_1    1
    x[3606]   c3467     100
    x[3607]   c875_1    1
    x[3607]   c3464     560
    x[3608]   c875_1    1
    x[3608]   c3465     560
    x[3609]   c877_1    1
    x[3609]   c3474     360
    x[3610]   c877_1    1
    x[3610]   c3469     360
    x[3611]   c877_1    1
    x[3611]   c3472     100
    x[3612]   c877_1    1
    x[3612]   c3473     100
    x[3613]   c877_1    1
    x[3613]   c3470     560
    x[3614]   c877_1    1
    x[3614]   c3471     560
    x[3615]   c879_1    1
    x[3615]   c3480     360
    x[3616]   c879_1    1
    x[3616]   c3475     360
    x[3617]   c879_1    1
    x[3617]   c3478     100
    x[3618]   c879_1    1
    x[3618]   c3479     100
    x[3619]   c879_1    1
    x[3619]   c3476     560
    x[3620]   c879_1    1
    x[3620]   c3477     560
    x[3621]   c881_1    1
    x[3621]   c3486     360
    x[3622]   c881_1    1
    x[3622]   c3481     360
    x[3623]   c881_1    1
    x[3623]   c3484     100
    x[3624]   c881_1    1
    x[3624]   c3485     100
    x[3625]   c881_1    1
    x[3625]   c3482     560
    x[3626]   c881_1    1
    x[3626]   c3483     560
    x[3627]   c883_1    1
    x[3627]   c3492     360
    x[3628]   c883_1    1
    x[3628]   c3487     360
    x[3629]   c883_1    1
    x[3629]   c3490     100
    x[3630]   c883_1    1
    x[3630]   c3491     100
    x[3631]   c883_1    1
    x[3631]   c3488     560
    x[3632]   c883_1    1
    x[3632]   c3489     560
    x[3633]   c885_1    1
    x[3633]   c3498     360
    x[3634]   c885_1    1
    x[3634]   c3493     360
    x[3635]   c885_1    1
    x[3635]   c3496     100
    x[3636]   c885_1    1
    x[3636]   c3497     100
    x[3637]   c885_1    1
    x[3637]   c3494     560
    x[3638]   c885_1    1
    x[3638]   c3495     560
    x[3639]   c887_1    1
    x[3639]   c3504     360
    x[3640]   c887_1    1
    x[3640]   c3499     360
    x[3641]   c887_1    1
    x[3641]   c3502     100
    x[3642]   c887_1    1
    x[3642]   c3503     100
    x[3643]   c887_1    1
    x[3643]   c3500     560
    x[3644]   c887_1    1
    x[3644]   c3501     560
    x[3645]   c889_1    1
    x[3645]   c3510     360
    x[3646]   c889_1    1
    x[3646]   c3505     360
    x[3647]   c889_1    1
    x[3647]   c3508     100
    x[3648]   c889_1    1
    x[3648]   c3509     100
    x[3649]   c889_1    1
    x[3649]   c3506     560
    x[3650]   c889_1    1
    x[3650]   c3507     560
    x[3651]   c891_1    1
    x[3651]   c3516     360
    x[3652]   c891_1    1
    x[3652]   c3511     360
    x[3653]   c891_1    1
    x[3653]   c3514     100
    x[3654]   c891_1    1
    x[3654]   c3515     100
    x[3655]   c891_1    1
    x[3655]   c3512     560
    x[3656]   c891_1    1
    x[3656]   c3513     560
    x[3657]   c893_1    1
    x[3657]   c3522     360
    x[3658]   c893_1    1
    x[3658]   c3517     360
    x[3659]   c893_1    1
    x[3659]   c3520     100
    x[3660]   c893_1    1
    x[3660]   c3521     100
    x[3661]   c893_1    1
    x[3661]   c3518     560
    x[3662]   c893_1    1
    x[3662]   c3519     560
    x[3663]   c895_1    1
    x[3663]   c3528     360
    x[3664]   c895_1    1
    x[3664]   c3523     360
    x[3665]   c895_1    1
    x[3665]   c3526     100
    x[3666]   c895_1    1
    x[3666]   c3527     100
    x[3667]   c895_1    1
    x[3667]   c3524     560
    x[3668]   c895_1    1
    x[3668]   c3525     560
    x[3669]   c897_1    1
    x[3669]   c3534     360
    x[3670]   c897_1    1
    x[3670]   c3529     360
    x[3671]   c897_1    1
    x[3671]   c3532     100
    x[3672]   c897_1    1
    x[3672]   c3533     100
    x[3673]   c897_1    1
    x[3673]   c3530     560
    x[3674]   c897_1    1
    x[3674]   c3531     560
    x[3675]   c899_1    1
    x[3675]   c3540     360
    x[3676]   c899_1    1
    x[3676]   c3535     360
    x[3677]   c899_1    1
    x[3677]   c3538     100
    x[3678]   c899_1    1
    x[3678]   c3539     100
    x[3679]   c899_1    1
    x[3679]   c3536     560
    x[3680]   c899_1    1
    x[3680]   c3537     560
    x[3681]   c901_1    1
    x[3681]   c3546     360
    x[3682]   c901_1    1
    x[3682]   c3541     360
    x[3683]   c901_1    1
    x[3683]   c3544     100
    x[3684]   c901_1    1
    x[3684]   c3545     100
    x[3685]   c901_1    1
    x[3685]   c3542     560
    x[3686]   c901_1    1
    x[3686]   c3543     560
    x[3687]   c903_1    1
    x[3687]   c3552     360
    x[3688]   c903_1    1
    x[3688]   c3547     360
    x[3689]   c903_1    1
    x[3689]   c3550     100
    x[3690]   c903_1    1
    x[3690]   c3551     100
    x[3691]   c903_1    1
    x[3691]   c3548     560
    x[3692]   c903_1    1
    x[3692]   c3549     560
    x[3693]   c905_1    1
    x[3693]   c3558     360
    x[3694]   c905_1    1
    x[3694]   c3553     360
    x[3695]   c905_1    1
    x[3695]   c3556     100
    x[3696]   c905_1    1
    x[3696]   c3557     100
    x[3697]   c905_1    1
    x[3697]   c3554     560
    x[3698]   c905_1    1
    x[3698]   c3555     560
    x[3699]   c907_1    1
    x[3699]   c3564     360
    x[3700]   c907_1    1
    x[3700]   c3559     360
    x[3701]   c907_1    1
    x[3701]   c3562     100
    x[3702]   c907_1    1
    x[3702]   c3563     100
    x[3703]   c907_1    1
    x[3703]   c3560     560
    x[3704]   c907_1    1
    x[3704]   c3561     560
    x[3705]   c909_1    1
    x[3705]   c3570     360
    x[3706]   c909_1    1
    x[3706]   c3565     360
    x[3707]   c909_1    1
    x[3707]   c3568     100
    x[3708]   c909_1    1
    x[3708]   c3569     100
    x[3709]   c909_1    1
    x[3709]   c3566     560
    x[3710]   c909_1    1
    x[3710]   c3567     560
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1_2      130
    rhs       c2_2      423
    rhs       c3_2      130
    rhs       c4_2      423
    rhs       c5_2      130
    rhs       c6_2      423
    rhs       c7_2      130
    rhs       c8_2      423
    rhs       c9_2      130
    rhs       c10_2     423
    rhs       c11_2     130
    rhs       c12_2     350
    rhs       c13_2     130
    rhs       c14_2     350
    rhs       c15_2     130
    rhs       c16_2     350
    rhs       c17_2     130
    rhs       c18_2     350
    rhs       c19_2     130
    rhs       c20_2     350
    rhs       c21_2     130
    rhs       c22_2     350
    rhs       c23_2     130
    rhs       c24_2     350
    rhs       c25_2     130
    rhs       c26_2     350
    rhs       c27_2     130
    rhs       c28_2     350
    rhs       c29_2     130
    rhs       c30_2     350
    rhs       c31_2     130
    rhs       c32_2     350
    rhs       c33_2     130
    rhs       c34_2     350
    rhs       c35_2     130
    rhs       c36_2     350
    rhs       c37_2     130
    rhs       c38_2     350
    rhs       c39_2     130
    rhs       c40_2     350
    rhs       c41_2     130
    rhs       c42_2     350
    rhs       c43_2     130
    rhs       c44_2     350
    rhs       c45_2     130
    rhs       c46_2     350
    rhs       c47_2     130
    rhs       c48_2     350
    rhs       c49_2     130
    rhs       c50_2     350
    rhs       c51_2     130
    rhs       c52_2     430
    rhs       c53_2     130
    rhs       c54_2     430
    rhs       c55_2     130
    rhs       c56_2     430
    rhs       c57_2     130
    rhs       c58_2     430
    rhs       c59_2     130
    rhs       c60_2     430
    rhs       c61_2     130
    rhs       c62_2     430
    rhs       c63_2     130
    rhs       c64_2     430
    rhs       c65_2     130
    rhs       c66_2     430
    rhs       c67_2     130
    rhs       c68_2     430
    rhs       c69_2     130
    rhs       c70_2     430
    rhs       c71_2     5
    rhs       c72_2     0
    rhs       c73_2     5
    rhs       c74_2     0
    rhs       c75_2     5
    rhs       c76_2     0
    rhs       c77_2     5
    rhs       c78_2     0
    rhs       c79_2     5
    rhs       c80_2     5
    rhs       c81_2     5
    rhs       c82_2     5
    rhs       c83_2     5
    rhs       c84_2     5
    rhs       c85_2     5
    rhs       c86_2     5
    rhs       c87_2     5
    rhs       c88_2     5
    rhs       c89_2     5
    rhs       c90_2     5
    rhs       c91_2     5
    rhs       c92_2     5
    rhs       c93_2     5
    rhs       c94_2     5
    rhs       c95_2     5
    rhs       c96_2     5
    rhs       c97_2     5
    rhs       c98_2     5
    rhs       c99_2     5
    rhs       c100_2    5
    rhs       c101_2    5
    rhs       c102_2    5
    rhs       c103_2    5
    rhs       c104_2    5
    rhs       c105_2    5
    rhs       c106_2    5
    rhs       c107_2    5
    rhs       c108_2    5
    rhs       c109_2    5
    rhs       c110_2    0
    rhs       c111_2    5
    rhs       c112_2    0
    rhs       c113_2    5
    rhs       c114_2    0
    rhs       c115_2    5
    rhs       c116_2    5
    rhs       c117_2    5
    rhs       c118_2    5
    rhs       c119_2    5
    rhs       c120_2    5
    rhs       c121_2    5
    rhs       c122_2    5
    rhs       c123_2    5
    rhs       c124_2    5
    rhs       c125_2    5
    rhs       c126_2    5
    rhs       c127_2    5
    rhs       c128_2    5
    rhs       c129_2    5
    rhs       c130_2    5
    rhs       c131_2    5
    rhs       c132_2    5
    rhs       c133_2    5
    rhs       c134_2    5
    rhs       c135_2    5
    rhs       c136_2    5
    rhs       c137_2    5
    rhs       c138_2    5
    rhs       c139_2    5
    rhs       c140_2    5
    rhs       c141_2    5
    rhs       c142_2    5
    rhs       c143_2    5
    rhs       c144_2    5
    rhs       c145_2    5
    rhs       c146_2    0
    rhs       c147_2    5
    rhs       c148_2    0
    rhs       c149_2    5
    rhs       c150_2    5
    rhs       c151_2    5
    rhs       c152_2    5
    rhs       c153_2    5
    rhs       c154_2    5
    rhs       c155_2    5
    rhs       c156_2    5
    rhs       c157_2    5
    rhs       c158_2    5
    rhs       c159_2    5
    rhs       c160_2    5
    rhs       c161_2    5
    rhs       c162_2    5
    rhs       c163_2    5
    rhs       c164_2    5
    rhs       c165_2    5
    rhs       c166_2    5
    rhs       c167_2    5
    rhs       c168_2    5
    rhs       c169_2    5
    rhs       c170_2    5
    rhs       c171_2    5
    rhs       c172_2    5
    rhs       c173_2    5
    rhs       c174_2    5
    rhs       c175_2    5
    rhs       c176_2    5
    rhs       c177_2    5
    rhs       c178_2    5
    rhs       c179_2    5
    rhs       c180_2    0
    rhs       c181_2    5
    rhs       c182_2    5
    rhs       c183_2    5
    rhs       c184_2    5
    rhs       c185_2    5
    rhs       c186_2    5
    rhs       c187_2    5
    rhs       c188_2    5
    rhs       c189_2    5
    rhs       c190_2    5
    rhs       c191_2    5
    rhs       c192_2    5
    rhs       c193_2    5
    rhs       c194_2    5
    rhs       c195_2    5
    rhs       c196_2    5
    rhs       c197_2    5
    rhs       c198_2    5
    rhs       c199_2    5
    rhs       c200_2    5
    rhs       c201_2    5
    rhs       c202_2    5
    rhs       c203_2    5
    rhs       c204_2    5
    rhs       c205_2    5
    rhs       c206_2    5
    rhs       c207_2    5
    rhs       c208_2    5
    rhs       c209_2    5
    rhs       c210_2    5
    rhs       c211_2    5
    rhs       c212_2    5
    rhs       c213_2    5
    rhs       c214_2    5
    rhs       c215_2    5
    rhs       c216_2    5
    rhs       c217_2    5
    rhs       c218_2    5
    rhs       c219_2    5
    rhs       c220_2    5
    rhs       c221_2    5
    rhs       c222_2    5
    rhs       c223_2    5
    rhs       c224_2    5
    rhs       c225_2    5
    rhs       c226_2    5
    rhs       c227_2    5
    rhs       c228_2    5
    rhs       c229_2    5
    rhs       c230_2    5
    rhs       c231_2    5
    rhs       c232_2    5
    rhs       c233_2    5
    rhs       c234_2    5
    rhs       c235_2    5
    rhs       c236_2    5
    rhs       c237_2    5
    rhs       c238_2    5
    rhs       c239_2    5
    rhs       c240_2    5
    rhs       c241_2    5
    rhs       c242_2    0
    rhs       c243_2    5
    rhs       c244_1    0
    rhs       c245_1    5
    rhs       c246_1    0
    rhs       c247_1    5
    rhs       c248_1    0
    rhs       c249_1    5
    rhs       c250_1    0
    rhs       c251_1    5
    rhs       c252_1    0
    rhs       c253_1    5
    rhs       c254_1    0
    rhs       c255_1    5
    rhs       c256_1    0
    rhs       c257_1    5
    rhs       c258_1    0
    rhs       c259_1    5
    rhs       c260_1    0
    rhs       c261_1    5
    rhs       c262_1    0
    rhs       c263_1    5
    rhs       c264_1    0
    rhs       c265_1    5
    rhs       c266_1    0
    rhs       c267_1    5
    rhs       c268_1    0
    rhs       c269_1    5
    rhs       c270_1    0
    rhs       c271_1    5
    rhs       c272_1    0
    rhs       c273_1    5
    rhs       c274_1    0
    rhs       c275_1    5
    rhs       c276_1    0
    rhs       c277_1    5
    rhs       c278_1    0
    rhs       c279_1    5
    rhs       c280_1    5
    rhs       c281_1    5
    rhs       c282_1    5
    rhs       c283_1    5
    rhs       c284_1    5
    rhs       c285_1    5
    rhs       c286_1    5
    rhs       c287_1    5
    rhs       c288_1    5
    rhs       c289_1    5
    rhs       c290_1    0
    rhs       c291_1    5
    rhs       c292_1    0
    rhs       c293_1    5
    rhs       c294_1    0
    rhs       c295_1    5
    rhs       c296_1    0
    rhs       c297_1    5
    rhs       c298_1    0
    rhs       c299_1    5
    rhs       c300_1    0
    rhs       c301_1    5
    rhs       c302_1    0
    rhs       c303_1    5
    rhs       c304_1    0
    rhs       c305_1    5
    rhs       c306_1    0
    rhs       c307_1    5
    rhs       c308_1    0
    rhs       c309_1    5
    rhs       c310_1    0
    rhs       c311_1    5
    rhs       c312_1    0
    rhs       c313_1    5
    rhs       c314_1    0
    rhs       c315_1    5
    rhs       c316_1    0
    rhs       c317_1    5
    rhs       c318_1    0
    rhs       c319_1    5
    rhs       c320_1    0
    rhs       c321_1    5
    rhs       c322_1    0
    rhs       c323_1    5
    rhs       c324_1    0
    rhs       c325_1    5
    rhs       c326_1    5
    rhs       c327_1    5
    rhs       c328_1    5
    rhs       c329_1    5
    rhs       c330_1    5
    rhs       c331_1    5
    rhs       c332_1    5
    rhs       c333_1    5
    rhs       c334_1    5
    rhs       c335_1    5
    rhs       c336_1    0
    rhs       c337_1    5
    rhs       c338_1    0
    rhs       c339_1    5
    rhs       c340_1    0
    rhs       c341_1    5
    rhs       c342_1    0
    rhs       c343_1    5
    rhs       c344_1    0
    rhs       c345_1    5
    rhs       c346_1    0
    rhs       c347_1    5
    rhs       c348_1    0
    rhs       c349_1    5
    rhs       c350_1    0
    rhs       c351_1    5
    rhs       c352_1    0
    rhs       c353_1    5
    rhs       c354_1    0
    rhs       c355_1    5
    rhs       c356_1    0
    rhs       c357_1    5
    rhs       c358_1    0
    rhs       c359_1    5
    rhs       c360_1    0
    rhs       c361_1    5
    rhs       c362_1    0
    rhs       c363_1    5
    rhs       c364_1    0
    rhs       c365_1    5
    rhs       c366_1    0
    rhs       c367_1    5
    rhs       c368_1    0
    rhs       c369_1    5
    rhs       c370_1    5
    rhs       c371_1    5
    rhs       c372_1    5
    rhs       c373_1    5
    rhs       c374_1    5
    rhs       c375_1    5
    rhs       c376_1    5
    rhs       c377_1    5
    rhs       c378_1    5
    rhs       c379_1    5
    rhs       c380_1    0
    rhs       c381_1    5
    rhs       c382_1    0
    rhs       c383_1    5
    rhs       c384_1    0
    rhs       c385_1    5
    rhs       c386_1    0
    rhs       c387_1    5
    rhs       c388_1    0
    rhs       c389_1    5
    rhs       c390_1    0
    rhs       c391_1    5
    rhs       c392_1    0
    rhs       c393_1    5
    rhs       c394_1    0
    rhs       c395_1    5
    rhs       c396_1    0
    rhs       c397_1    5
    rhs       c398_1    0
    rhs       c399_1    5
    rhs       c400_1    0
    rhs       c401_1    5
    rhs       c402_1    0
    rhs       c403_1    5
    rhs       c404_1    0
    rhs       c405_1    5
    rhs       c406_1    0
    rhs       c407_1    5
    rhs       c408_1    0
    rhs       c409_1    5
    rhs       c410_1    0
    rhs       c411_1    5
    rhs       c412_1    5
    rhs       c413_1    5
    rhs       c414_1    5
    rhs       c415_1    5
    rhs       c416_1    5
    rhs       c417_1    5
    rhs       c418_1    5
    rhs       c419_1    5
    rhs       c420_1    5
    rhs       c421_1    5
    rhs       c422_1    0
    rhs       c423_1    5
    rhs       c424_1    0
    rhs       c425_1    5
    rhs       c426_1    0
    rhs       c427_1    5
    rhs       c428_1    0
    rhs       c429_1    5
    rhs       c430_1    0
    rhs       c431_1    5
    rhs       c432_1    0
    rhs       c433_1    5
    rhs       c434_1    0
    rhs       c435_1    5
    rhs       c436_1    0
    rhs       c437_1    5
    rhs       c438_1    0
    rhs       c439_1    5
    rhs       c440_1    0
    rhs       c441_1    5
    rhs       c442_1    0
    rhs       c443_1    5
    rhs       c444_1    0
    rhs       c445_1    5
    rhs       c446_1    0
    rhs       c447_1    5
    rhs       c448_1    0
    rhs       c449_1    5
    rhs       c450_1    0
    rhs       c451_1    5
    rhs       c452_1    5
    rhs       c453_1    5
    rhs       c454_1    5
    rhs       c455_1    5
    rhs       c456_1    5
    rhs       c457_1    5
    rhs       c458_1    5
    rhs       c459_1    5
    rhs       c460_1    5
    rhs       c461_1    5
    rhs       c462_1    0
    rhs       c463_1    5
    rhs       c464_1    0
    rhs       c465_1    5
    rhs       c466_1    0
    rhs       c467_1    5
    rhs       c468_1    0
    rhs       c469_1    5
    rhs       c470_1    0
    rhs       c471_1    5
    rhs       c472_1    0
    rhs       c473_1    5
    rhs       c474_1    0
    rhs       c475_1    5
    rhs       c476_1    0
    rhs       c477_1    5
    rhs       c478_1    0
    rhs       c479_1    5
    rhs       c480_1    0
    rhs       c481_1    5
    rhs       c482_1    0
    rhs       c483_1    5
    rhs       c484_1    0
    rhs       c485_1    5
    rhs       c486_1    0
    rhs       c487_1    5
    rhs       c488_1    0
    rhs       c489_1    5
    rhs       c490_1    5
    rhs       c491_1    5
    rhs       c492_1    5
    rhs       c493_1    5
    rhs       c494_1    5
    rhs       c495_1    5
    rhs       c496_1    5
    rhs       c497_1    5
    rhs       c498_1    5
    rhs       c499_1    5
    rhs       c500_1    0
    rhs       c501_1    5
    rhs       c502_1    0
    rhs       c503_1    5
    rhs       c504_1    0
    rhs       c505_1    5
    rhs       c506_1    0
    rhs       c507_1    5
    rhs       c508_1    0
    rhs       c509_1    5
    rhs       c510_1    0
    rhs       c511_1    5
    rhs       c512_1    0
    rhs       c513_1    5
    rhs       c514_1    0
    rhs       c515_1    5
    rhs       c516_1    0
    rhs       c517_1    5
    rhs       c518_1    0
    rhs       c519_1    5
    rhs       c520_1    0
    rhs       c521_1    5
    rhs       c522_1    0
    rhs       c523_1    5
    rhs       c524_1    0
    rhs       c525_1    5
    rhs       c526_1    5
    rhs       c527_1    5
    rhs       c528_1    5
    rhs       c529_1    5
    rhs       c530_1    5
    rhs       c531_1    5
    rhs       c532_1    5
    rhs       c533_1    5
    rhs       c534_1    5
    rhs       c535_1    5
    rhs       c536_1    0
    rhs       c537_1    5
    rhs       c538_1    0
    rhs       c539_1    5
    rhs       c540_1    0
    rhs       c541_1    5
    rhs       c542_1    0
    rhs       c543_1    5
    rhs       c544_1    0
    rhs       c545_1    5
    rhs       c546_1    0
    rhs       c547_1    5
    rhs       c548_1    0
    rhs       c549_1    5
    rhs       c550_1    0
    rhs       c551_1    5
    rhs       c552_1    0
    rhs       c553_1    5
    rhs       c554_1    0
    rhs       c555_1    5
    rhs       c556_1    0
    rhs       c557_1    5
    rhs       c558_1    0
    rhs       c559_1    5
    rhs       c560_1    5
    rhs       c561_1    5
    rhs       c562_1    5
    rhs       c563_1    5
    rhs       c564_1    5
    rhs       c565_1    5
    rhs       c566_1    5
    rhs       c567_1    5
    rhs       c568_1    5
    rhs       c569_1    5
    rhs       c570_1    0
    rhs       c571_1    5
    rhs       c572_1    0
    rhs       c573_1    5
    rhs       c574_1    0
    rhs       c575_1    5
    rhs       c576_1    0
    rhs       c577_1    5
    rhs       c578_1    0
    rhs       c579_1    5
    rhs       c580_1    0
    rhs       c581_1    5
    rhs       c582_1    0
    rhs       c583_1    5
    rhs       c584_1    0
    rhs       c585_1    5
    rhs       c586_1    0
    rhs       c587_1    5
    rhs       c588_1    0
    rhs       c589_1    5
    rhs       c590_1    0
    rhs       c591_1    5
    rhs       c592_1    5
    rhs       c593_1    5
    rhs       c594_1    5
    rhs       c595_1    5
    rhs       c596_1    5
    rhs       c597_1    5
    rhs       c598_1    5
    rhs       c599_1    5
    rhs       c600_1    5
    rhs       c601_1    5
    rhs       c602_1    0
    rhs       c603_1    5
    rhs       c604_1    0
    rhs       c605_1    5
    rhs       c606_1    0
    rhs       c607_1    5
    rhs       c608_1    0
    rhs       c609_1    5
    rhs       c610_1    0
    rhs       c611_1    5
    rhs       c612_1    0
    rhs       c613_1    5
    rhs       c614_1    0
    rhs       c615_1    5
    rhs       c616_1    0
    rhs       c617_1    5
    rhs       c618_1    0
    rhs       c619_1    5
    rhs       c620_1    0
    rhs       c621_1    5
    rhs       c622_1    5
    rhs       c623_1    5
    rhs       c624_1    5
    rhs       c625_1    5
    rhs       c626_1    5
    rhs       c627_1    5
    rhs       c628_1    5
    rhs       c629_1    5
    rhs       c630_1    5
    rhs       c631_1    5
    rhs       c632_1    0
    rhs       c633_1    5
    rhs       c634_1    0
    rhs       c635_1    5
    rhs       c636_1    0
    rhs       c637_1    5
    rhs       c638_1    0
    rhs       c639_1    5
    rhs       c640_1    0
    rhs       c641_1    5
    rhs       c642_1    0
    rhs       c643_1    5
    rhs       c644_1    0
    rhs       c645_1    5
    rhs       c646_1    0
    rhs       c647_1    5
    rhs       c648_1    0
    rhs       c649_1    5
    rhs       c650_1    5
    rhs       c651_1    5
    rhs       c652_1    5
    rhs       c653_1    5
    rhs       c654_1    5
    rhs       c655_1    5
    rhs       c656_1    5
    rhs       c657_1    5
    rhs       c658_1    5
    rhs       c659_1    5
    rhs       c660_1    0
    rhs       c661_1    5
    rhs       c662_1    0
    rhs       c663_1    5
    rhs       c664_1    0
    rhs       c665_1    5
    rhs       c666_1    0
    rhs       c667_1    5
    rhs       c668_1    0
    rhs       c669_1    5
    rhs       c670_1    0
    rhs       c671_1    5
    rhs       c672_1    0
    rhs       c673_1    5
    rhs       c674_1    0
    rhs       c675_1    5
    rhs       c676_1    5
    rhs       c677_1    5
    rhs       c678_1    5
    rhs       c679_1    5
    rhs       c680_1    5
    rhs       c681_1    5
    rhs       c682_1    5
    rhs       c683_1    5
    rhs       c684_1    5
    rhs       c685_1    5
    rhs       c686_1    0
    rhs       c687_1    5
    rhs       c688_1    0
    rhs       c689_1    5
    rhs       c690_1    0
    rhs       c691_1    5
    rhs       c692_1    0
    rhs       c693_1    5
    rhs       c694_1    0
    rhs       c695_1    5
    rhs       c696_1    0
    rhs       c697_1    5
    rhs       c698_1    0
    rhs       c699_1    5
    rhs       c700_1    5
    rhs       c701_1    5
    rhs       c702_1    5
    rhs       c703_1    5
    rhs       c704_1    5
    rhs       c705_1    5
    rhs       c706_1    5
    rhs       c707_1    5
    rhs       c708_1    5
    rhs       c709_1    5
    rhs       c710_1    0
    rhs       c711_1    5
    rhs       c712_1    0
    rhs       c713_1    5
    rhs       c714_1    0
    rhs       c715_1    5
    rhs       c716_1    0
    rhs       c717_1    5
    rhs       c718_1    0
    rhs       c719_1    5
    rhs       c720_1    0
    rhs       c721_1    5
    rhs       c722_1    5
    rhs       c723_1    5
    rhs       c724_1    5
    rhs       c725_1    5
    rhs       c726_1    5
    rhs       c727_1    5
    rhs       c728_1    5
    rhs       c729_1    5
    rhs       c730_1    5
    rhs       c731_1    5
    rhs       c732_1    0
    rhs       c733_1    5
    rhs       c734_1    0
    rhs       c735_1    5
    rhs       c736_1    0
    rhs       c737_1    5
    rhs       c738_1    0
    rhs       c739_1    5
    rhs       c740_1    0
    rhs       c741_1    5
    rhs       c742_1    5
    rhs       c743_1    5
    rhs       c744_1    5
    rhs       c745_1    5
    rhs       c746_1    5
    rhs       c747_1    5
    rhs       c748_1    5
    rhs       c749_1    5
    rhs       c750_1    5
    rhs       c751_1    5
    rhs       c752_1    0
    rhs       c753_1    5
    rhs       c754_1    0
    rhs       c755_1    5
    rhs       c756_1    0
    rhs       c757_1    5
    rhs       c758_1    0
    rhs       c759_1    5
    rhs       c760_1    5
    rhs       c761_1    5
    rhs       c762_1    5
    rhs       c763_1    5
    rhs       c764_1    5
    rhs       c765_1    5
    rhs       c766_1    5
    rhs       c767_1    5
    rhs       c768_1    5
    rhs       c769_1    5
    rhs       c770_1    0
    rhs       c771_1    5
    rhs       c772_1    0
    rhs       c773_1    5
    rhs       c774_1    0
    rhs       c775_1    5
    rhs       c776_1    5
    rhs       c777_1    5
    rhs       c778_1    5
    rhs       c779_1    5
    rhs       c780_1    5
    rhs       c781_1    5
    rhs       c782_1    5
    rhs       c783_1    5
    rhs       c784_1    5
    rhs       c785_1    5
    rhs       c786_1    0
    rhs       c787_1    5
    rhs       c788_1    0
    rhs       c789_1    5
    rhs       c790_1    5
    rhs       c791_1    5
    rhs       c792_1    5
    rhs       c793_1    5
    rhs       c794_1    5
    rhs       c795_1    5
    rhs       c796_1    5
    rhs       c797_1    5
    rhs       c798_1    5
    rhs       c799_1    5
    rhs       c800_1    0
    rhs       c801_1    5
    rhs       c802_1    5
    rhs       c803_1    5
    rhs       c804_1    5
    rhs       c805_1    5
    rhs       c806_1    5
    rhs       c807_1    5
    rhs       c808_1    5
    rhs       c809_1    5
    rhs       c810_1    5
    rhs       c811_1    5
    rhs       c812_1    5
    rhs       c813_1    5
    rhs       c814_1    5
    rhs       c815_1    5
    rhs       c816_1    5
    rhs       c817_1    5
    rhs       c818_1    5
    rhs       c819_1    5
    rhs       c820_1    5
    rhs       c821_1    5
    rhs       c822_1    0
    rhs       c823_1    5
    rhs       c824_1    0
    rhs       c825_1    5
    rhs       c826_1    0
    rhs       c827_1    5
    rhs       c828_1    0
    rhs       c829_1    5
    rhs       c830_1    0
    rhs       c831_1    5
    rhs       c832_1    0
    rhs       c833_1    5
    rhs       c834_1    0
    rhs       c835_1    5
    rhs       c836_1    0
    rhs       c837_1    5
    rhs       c838_1    0
    rhs       c839_1    5
    rhs       c840_1    0
    rhs       c841_1    5
    rhs       c842_1    0
    rhs       c843_1    5
    rhs       c844_1    0
    rhs       c845_1    5
    rhs       c846_1    0
    rhs       c847_1    5
    rhs       c848_1    0
    rhs       c849_1    5
    rhs       c850_1    0
    rhs       c851_1    5
    rhs       c852_1    0
    rhs       c853_1    5
    rhs       c854_1    0
    rhs       c855_1    5
    rhs       c856_1    0
    rhs       c857_1    5
    rhs       c858_1    0
    rhs       c859_1    5
    rhs       c860_1    0
    rhs       c861_1    5
    rhs       c862_1    0
    rhs       c863_1    5
    rhs       c864_1    0
    rhs       c865_1    5
    rhs       c866_1    0
    rhs       c867_1    5
    rhs       c868_1    0
    rhs       c869_1    5
    rhs       c870_1    0
    rhs       c871_1    5
    rhs       c872_1    0
    rhs       c873_1    5
    rhs       c874_1    0
    rhs       c875_1    5
    rhs       c876_1    0
    rhs       c877_1    5
    rhs       c878_1    0
    rhs       c879_1    5
    rhs       c880_1    0
    rhs       c881_1    5
    rhs       c882_1    0
    rhs       c883_1    5
    rhs       c884_1    0
    rhs       c885_1    5
    rhs       c886_1    0
    rhs       c887_1    5
    rhs       c888_1    0
    rhs       c889_1    5
    rhs       c890_1    0
    rhs       c891_1    5
    rhs       c892_1    0
    rhs       c893_1    5
    rhs       c894_1    0
    rhs       c895_1    5
    rhs       c896_1    0
    rhs       c897_1    5
    rhs       c898_1    0
    rhs       c899_1    5
    rhs       c900_1    0
    rhs       c901_1    5
    rhs       c902_1    0
    rhs       c903_1    5
    rhs       c904_1    0
    rhs       c905_1    5
    rhs       c906_1    0
    rhs       c907_1    5
    rhs       c908_1    0
    rhs       c909_1    5
    rhs       c910_1    0
    rhs       c911_1    -1
    rhs       c912_1    -1
    rhs       c913_1    -1
    rhs       c914_1    -1
    rhs       c915_1    -1
    rhs       c916_1    -1
    rhs       c917_1    -1
    rhs       c918_1    -1
    rhs       c919_1    -1
    rhs       c920_1    -1
    rhs       c921_1    -1
    rhs       c922_1    -1
    rhs       c923_1    -1
    rhs       c924_1    -1
    rhs       c925_1    -1
    rhs       c926_1    -1
    rhs       c927_1    -1
    rhs       c928_1    -1
    rhs       c929_1    -1
    rhs       c930_1    -1
    rhs       c931_1    -1
    rhs       c932_1    -1
    rhs       c933_1    -1
    rhs       c934_1    -1
    rhs       c935_1    -1
    rhs       c936_1    -1
    rhs       c937_1    -1
    rhs       c938_1    -1
    rhs       c939_1    -1
    rhs       c940_1    -1
    rhs       c941_1    -1
    rhs       c942_1    -1
    rhs       c943_1    -1
    rhs       c944_1    -1
    rhs       c945_1    -1
    rhs       c946_1    -1
    rhs       c947_1    -1
    rhs       c948_1    -1
    rhs       c949_1    -1
    rhs       c950_1    -1
    rhs       c951_1    -1
    rhs       c952_1    -1
    rhs       c953_1    -1
    rhs       c954_1    -1
    rhs       c955_1    -1
    rhs       c956_1    -1
    rhs       c957_1    -1
    rhs       c958_1    -1
    rhs       c959_1    -1
    rhs       c960_1    -1
    rhs       c961_1    -1
    rhs       c962_1    -1
    rhs       c963_1    -1
    rhs       c964_1    -1
    rhs       c965_1    -1
    rhs       c966_1    -1
    rhs       c967_1    -1
    rhs       c968_1    -1
    rhs       c969_1    -1
    rhs       c970_1    -1
    rhs       c971_1    -1
    rhs       c972_1    -1
    rhs       c973_1    -1
    rhs       c974_1    -1
    rhs       c975_1    -1
    rhs       c976_1    -1
    rhs       c977_1    -1
    rhs       c978_1    -1
    rhs       c979_1    -1
    rhs       c980_1    -1
    rhs       c981_1    -1
    rhs       c982_1    -1
    rhs       c983_1    -1
    rhs       c984_1    -1
    rhs       c985_1    -1
    rhs       c1_1      230
    rhs       c2_1      137
    rhs       c3_1      137
    rhs       c4_1      15
    rhs       c5_1      15
    rhs       c6_1      230
    rhs       c7_1      230
    rhs       c8_1      137
    rhs       c9_1      137
    rhs       c10_1     15
    rhs       c11_1     15
    rhs       c12_1     230
    rhs       c13_1     230
    rhs       c14_1     137
    rhs       c15_1     137
    rhs       c16_1     15
    rhs       c17_1     15
    rhs       c18_1     230
    rhs       c19_1     230
    rhs       c20_1     137
    rhs       c21_1     137
    rhs       c22_1     15
    rhs       c23_1     15
    rhs       c24_1     230
    rhs       c25_1     230
    rhs       c26_1     210
    rhs       c27_1     137
    rhs       c28_1     10
    rhs       c29_1     15
    rhs       c30_1     230
    rhs       c31_1     230
    rhs       c32_1     210
    rhs       c33_1     137
    rhs       c34_1     10
    rhs       c35_1     15
    rhs       c36_1     230
    rhs       c37_1     230
    rhs       c38_1     210
    rhs       c39_1     137
    rhs       c40_1     10
    rhs       c41_1     15
    rhs       c42_1     230
    rhs       c43_1     230
    rhs       c44_1     210
    rhs       c45_1     137
    rhs       c46_1     10
    rhs       c47_1     15
    rhs       c48_1     230
    rhs       c49_1     230
    rhs       c50_1     210
    rhs       c51_1     137
    rhs       c52_1     10
    rhs       c53_1     15
    rhs       c54_1     230
    rhs       c55_1     230
    rhs       c56_1     210
    rhs       c57_1     137
    rhs       c58_1     10
    rhs       c59_1     15
    rhs       c60_1     230
    rhs       c61_1     230
    rhs       c62_1     210
    rhs       c63_1     137
    rhs       c64_1     10
    rhs       c65_1     15
    rhs       c66_1     230
    rhs       c67_1     230
    rhs       c68_1     210
    rhs       c69_1     137
    rhs       c70_1     10
    rhs       c71_1     15
    rhs       c72_1     230
    rhs       c73_1     230
    rhs       c74_1     210
    rhs       c75_1     137
    rhs       c76_1     10
    rhs       c77_1     15
    rhs       c78_1     230
    rhs       c79_1     230
    rhs       c80_1     210
    rhs       c81_1     137
    rhs       c82_1     10
    rhs       c83_1     15
    rhs       c84_1     230
    rhs       c85_1     230
    rhs       c86_1     210
    rhs       c87_1     137
    rhs       c88_1     10
    rhs       c89_1     15
    rhs       c90_1     230
    rhs       c91_1     230
    rhs       c92_1     210
    rhs       c93_1     137
    rhs       c94_1     10
    rhs       c95_1     15
    rhs       c96_1     230
    rhs       c97_1     230
    rhs       c98_1     210
    rhs       c99_1     137
    rhs       c100_1    10
    rhs       c101_1    15
    rhs       c102_1    230
    rhs       c103_1    230
    rhs       c104_1    210
    rhs       c105_1    137
    rhs       c106_1    10
    rhs       c107_1    15
    rhs       c108_1    230
    rhs       c109_1    230
    rhs       c110_1    210
    rhs       c111_1    137
    rhs       c112_1    10
    rhs       c113_1    15
    rhs       c114_1    230
    rhs       c115_1    230
    rhs       c116_1    210
    rhs       c117_1    137
    rhs       c118_1    10
    rhs       c119_1    15
    rhs       c120_1    230
    rhs       c121_1    230
    rhs       c122_1    210
    rhs       c123_1    137
    rhs       c124_1    10
    rhs       c125_1    15
    rhs       c126_1    230
    rhs       c127_1    230
    rhs       c128_1    210
    rhs       c129_1    137
    rhs       c130_1    10
    rhs       c131_1    15
    rhs       c132_1    230
    rhs       c133_1    230
    rhs       c134_1    210
    rhs       c135_1    137
    rhs       c136_1    10
    rhs       c137_1    15
    rhs       c138_1    230
    rhs       c139_1    230
    rhs       c140_1    210
    rhs       c141_1    137
    rhs       c142_1    10
    rhs       c143_1    15
    rhs       c144_1    230
    rhs       c145_1    230
    rhs       c146_1    130
    rhs       c147_1    137
    rhs       c148_1    13
    rhs       c149_1    15
    rhs       c150_1    230
    rhs       c151_1    230
    rhs       c152_1    130
    rhs       c153_1    137
    rhs       c154_1    13
    rhs       c155_1    15
    rhs       c156_1    230
    rhs       c157_1    230
    rhs       c158_1    130
    rhs       c159_1    137
    rhs       c160_1    13
    rhs       c161_1    15
    rhs       c162_1    230
    rhs       c163_1    230
    rhs       c164_1    130
    rhs       c165_1    137
    rhs       c166_1    13
    rhs       c167_1    15
    rhs       c168_1    230
    rhs       c169_1    230
    rhs       c170_1    130
    rhs       c171_1    137
    rhs       c172_1    13
    rhs       c173_1    15
    rhs       c174_1    230
    rhs       c175_1    230
    rhs       c176_1    130
    rhs       c177_1    137
    rhs       c178_1    13
    rhs       c179_1    15
    rhs       c180_1    230
    rhs       c181_1    230
    rhs       c182_1    130
    rhs       c183_1    137
    rhs       c184_1    13
    rhs       c185_1    15
    rhs       c186_1    230
    rhs       c187_1    230
    rhs       c188_1    130
    rhs       c189_1    137
    rhs       c190_1    13
    rhs       c191_1    15
    rhs       c192_1    230
    rhs       c193_1    230
    rhs       c194_1    130
    rhs       c195_1    137
    rhs       c196_1    13
    rhs       c197_1    15
    rhs       c198_1    230
    rhs       c199_1    230
    rhs       c200_1    130
    rhs       c201_1    137
    rhs       c202_1    13
    rhs       c203_1    15
    rhs       c204_1    230
    rhs       c205_1    230
    rhs       c206_1    137
    rhs       c207_1    137
    rhs       c208_1    15
    rhs       c209_1    15
    rhs       c210_1    230
    rhs       c211_1    230
    rhs       c212_1    137
    rhs       c213_1    137
    rhs       c214_1    15
    rhs       c215_1    15
    rhs       c216_1    230
    rhs       c217_1    230
    rhs       c218_1    137
    rhs       c219_1    137
    rhs       c220_1    15
    rhs       c221_1    15
    rhs       c222_1    230
    rhs       c223_1    230
    rhs       c224_1    210
    rhs       c225_1    137
    rhs       c226_1    10
    rhs       c227_1    15
    rhs       c228_1    230
    rhs       c229_1    230
    rhs       c230_1    210
    rhs       c231_1    137
    rhs       c232_1    10
    rhs       c233_1    15
    rhs       c234_1    230
    rhs       c235_1    230
    rhs       c236_1    210
    rhs       c237_1    137
    rhs       c238_1    10
    rhs       c239_1    15
    rhs       c240_1    230
    rhs       c241_1    230
    rhs       c242_1    210
    rhs       c243_1    137
    rhs       c244      10
    rhs       c245      15
    rhs       c246      230
    rhs       c247      230
    rhs       c248      210
    rhs       c249      137
    rhs       c250      10
    rhs       c251      15
    rhs       c252      230
    rhs       c253      230
    rhs       c254      210
    rhs       c255      137
    rhs       c256      10
    rhs       c257      15
    rhs       c258      230
    rhs       c259      230
    rhs       c260      210
    rhs       c261      137
    rhs       c262      10
    rhs       c263      15
    rhs       c264      230
    rhs       c265      230
    rhs       c266      210
    rhs       c267      137
    rhs       c268      10
    rhs       c269      15
    rhs       c270      230
    rhs       c271      230
    rhs       c272      210
    rhs       c273      137
    rhs       c274      10
    rhs       c275      15
    rhs       c276      230
    rhs       c277      230
    rhs       c278      210
    rhs       c279      137
    rhs       c280      10
    rhs       c281      15
    rhs       c282      230
    rhs       c283      230
    rhs       c284      210
    rhs       c285      137
    rhs       c286      10
    rhs       c287      15
    rhs       c288      230
    rhs       c289      230
    rhs       c290      210
    rhs       c291      137
    rhs       c292      10
    rhs       c293      15
    rhs       c294      230
    rhs       c295      230
    rhs       c296      210
    rhs       c297      137
    rhs       c298      10
    rhs       c299      15
    rhs       c300      230
    rhs       c301      230
    rhs       c302      210
    rhs       c303      137
    rhs       c304      10
    rhs       c305      15
    rhs       c306      230
    rhs       c307      230
    rhs       c308      210
    rhs       c309      137
    rhs       c310      10
    rhs       c311      15
    rhs       c312      230
    rhs       c313      230
    rhs       c314      210
    rhs       c315      137
    rhs       c316      10
    rhs       c317      15
    rhs       c318      230
    rhs       c319      230
    rhs       c320      210
    rhs       c321      137
    rhs       c322      10
    rhs       c323      15
    rhs       c324      230
    rhs       c325      230
    rhs       c326      210
    rhs       c327      137
    rhs       c328      10
    rhs       c329      15
    rhs       c330      230
    rhs       c331      230
    rhs       c332      210
    rhs       c333      137
    rhs       c334      10
    rhs       c335      15
    rhs       c336      230
    rhs       c337      230
    rhs       c338      210
    rhs       c339      137
    rhs       c340      10
    rhs       c341      15
    rhs       c342      230
    rhs       c343      230
    rhs       c344      130
    rhs       c345      137
    rhs       c346      13
    rhs       c347      15
    rhs       c348      230
    rhs       c349      230
    rhs       c350      130
    rhs       c351      137
    rhs       c352      13
    rhs       c353      15
    rhs       c354      230
    rhs       c355      230
    rhs       c356      130
    rhs       c357      137
    rhs       c358      13
    rhs       c359      15
    rhs       c360      230
    rhs       c361      230
    rhs       c362      130
    rhs       c363      137
    rhs       c364      13
    rhs       c365      15
    rhs       c366      230
    rhs       c367      230
    rhs       c368      130
    rhs       c369      137
    rhs       c370      13
    rhs       c371      15
    rhs       c372      230
    rhs       c373      230
    rhs       c374      130
    rhs       c375      137
    rhs       c376      13
    rhs       c377      15
    rhs       c378      230
    rhs       c379      230
    rhs       c380      130
    rhs       c381      137
    rhs       c382      13
    rhs       c383      15
    rhs       c384      230
    rhs       c385      230
    rhs       c386      130
    rhs       c387      137
    rhs       c388      13
    rhs       c389      15
    rhs       c390      230
    rhs       c391      230
    rhs       c392      130
    rhs       c393      137
    rhs       c394      13
    rhs       c395      15
    rhs       c396      230
    rhs       c397      230
    rhs       c398      130
    rhs       c399      137
    rhs       c400      13
    rhs       c401      15
    rhs       c402      230
    rhs       c403      230
    rhs       c404      137
    rhs       c405      137
    rhs       c406      15
    rhs       c407      15
    rhs       c408      230
    rhs       c409      230
    rhs       c410      137
    rhs       c411      137
    rhs       c412      15
    rhs       c413      15
    rhs       c414      230
    rhs       c415      230
    rhs       c416      210
    rhs       c417      137
    rhs       c418      10
    rhs       c419      15
    rhs       c420      230
    rhs       c421      230
    rhs       c422      210
    rhs       c423      137
    rhs       c424      10
    rhs       c425      15
    rhs       c426      230
    rhs       c427      230
    rhs       c428      210
    rhs       c429      137
    rhs       c430      10
    rhs       c431      15
    rhs       c432      230
    rhs       c433      230
    rhs       c434      210
    rhs       c435      137
    rhs       c436      10
    rhs       c437      15
    rhs       c438      230
    rhs       c439      230
    rhs       c440      210
    rhs       c441      137
    rhs       c442      10
    rhs       c443      15
    rhs       c444      230
    rhs       c445      230
    rhs       c446      210
    rhs       c447      137
    rhs       c448      10
    rhs       c449      15
    rhs       c450      230
    rhs       c451      230
    rhs       c452      210
    rhs       c453      137
    rhs       c454      10
    rhs       c455      15
    rhs       c456      230
    rhs       c457      230
    rhs       c458      210
    rhs       c459      137
    rhs       c460      10
    rhs       c461      15
    rhs       c462      230
    rhs       c463      230
    rhs       c464      210
    rhs       c465      137
    rhs       c466      10
    rhs       c467      15
    rhs       c468      230
    rhs       c469      230
    rhs       c470      210
    rhs       c471      137
    rhs       c472      10
    rhs       c473      15
    rhs       c474      230
    rhs       c475      230
    rhs       c476      210
    rhs       c477      137
    rhs       c478      10
    rhs       c479      15
    rhs       c480      230
    rhs       c481      230
    rhs       c482      210
    rhs       c483      137
    rhs       c484      10
    rhs       c485      15
    rhs       c486      230
    rhs       c487      230
    rhs       c488      210
    rhs       c489      137
    rhs       c490      10
    rhs       c491      15
    rhs       c492      230
    rhs       c493      230
    rhs       c494      210
    rhs       c495      137
    rhs       c496      10
    rhs       c497      15
    rhs       c498      230
    rhs       c499      230
    rhs       c500      210
    rhs       c501      137
    rhs       c502      10
    rhs       c503      15
    rhs       c504      230
    rhs       c505      230
    rhs       c506      210
    rhs       c507      137
    rhs       c508      10
    rhs       c509      15
    rhs       c510      230
    rhs       c511      230
    rhs       c512      210
    rhs       c513      137
    rhs       c514      10
    rhs       c515      15
    rhs       c516      230
    rhs       c517      230
    rhs       c518      210
    rhs       c519      137
    rhs       c520      10
    rhs       c521      15
    rhs       c522      230
    rhs       c523      230
    rhs       c524      210
    rhs       c525      137
    rhs       c526      10
    rhs       c527      15
    rhs       c528      230
    rhs       c529      230
    rhs       c530      210
    rhs       c531      137
    rhs       c532      10
    rhs       c533      15
    rhs       c534      230
    rhs       c535      230
    rhs       c536      130
    rhs       c537      137
    rhs       c538      13
    rhs       c539      15
    rhs       c540      230
    rhs       c541      230
    rhs       c542      130
    rhs       c543      137
    rhs       c544      13
    rhs       c545      15
    rhs       c546      230
    rhs       c547      230
    rhs       c548      130
    rhs       c549      137
    rhs       c550      13
    rhs       c551      15
    rhs       c552      230
    rhs       c553      230
    rhs       c554      130
    rhs       c555      137
    rhs       c556      13
    rhs       c557      15
    rhs       c558      230
    rhs       c559      230
    rhs       c560      130
    rhs       c561      137
    rhs       c562      13
    rhs       c563      15
    rhs       c564      230
    rhs       c565      230
    rhs       c566      130
    rhs       c567      137
    rhs       c568      13
    rhs       c569      15
    rhs       c570      230
    rhs       c571      230
    rhs       c572      130
    rhs       c573      137
    rhs       c574      13
    rhs       c575      15
    rhs       c576      230
    rhs       c577      230
    rhs       c578      130
    rhs       c579      137
    rhs       c580      13
    rhs       c581      15
    rhs       c582      230
    rhs       c583      230
    rhs       c584      130
    rhs       c585      137
    rhs       c586      13
    rhs       c587      15
    rhs       c588      230
    rhs       c589      230
    rhs       c590      130
    rhs       c591      137
    rhs       c592      13
    rhs       c593      15
    rhs       c594      230
    rhs       c595      230
    rhs       c596      137
    rhs       c597      137
    rhs       c598      15
    rhs       c599      15
    rhs       c600      230
    rhs       c601      230
    rhs       c602      210
    rhs       c603      137
    rhs       c604      10
    rhs       c605      15
    rhs       c606      230
    rhs       c607      230
    rhs       c608      210
    rhs       c609      137
    rhs       c610      10
    rhs       c611      15
    rhs       c612      230
    rhs       c613      230
    rhs       c614      210
    rhs       c615      137
    rhs       c616      10
    rhs       c617      15
    rhs       c618      230
    rhs       c619      230
    rhs       c620      210
    rhs       c621      137
    rhs       c622      10
    rhs       c623      15
    rhs       c624      230
    rhs       c625      230
    rhs       c626      210
    rhs       c627      137
    rhs       c628      10
    rhs       c629      15
    rhs       c630      230
    rhs       c631      230
    rhs       c632      210
    rhs       c633      137
    rhs       c634      10
    rhs       c635      15
    rhs       c636      230
    rhs       c637      230
    rhs       c638      210
    rhs       c639      137
    rhs       c640      10
    rhs       c641      15
    rhs       c642      230
    rhs       c643      230
    rhs       c644      210
    rhs       c645      137
    rhs       c646      10
    rhs       c647      15
    rhs       c648      230
    rhs       c649      230
    rhs       c650      210
    rhs       c651      137
    rhs       c652      10
    rhs       c653      15
    rhs       c654      230
    rhs       c655      230
    rhs       c656      210
    rhs       c657      137
    rhs       c658      10
    rhs       c659      15
    rhs       c660      230
    rhs       c661      230
    rhs       c662      210
    rhs       c663      137
    rhs       c664      10
    rhs       c665      15
    rhs       c666      230
    rhs       c667      230
    rhs       c668      210
    rhs       c669      137
    rhs       c670      10
    rhs       c671      15
    rhs       c672      230
    rhs       c673      230
    rhs       c674      210
    rhs       c675      137
    rhs       c676      10
    rhs       c677      15
    rhs       c678      230
    rhs       c679      230
    rhs       c680      210
    rhs       c681      137
    rhs       c682      10
    rhs       c683      15
    rhs       c684      230
    rhs       c685      230
    rhs       c686      210
    rhs       c687      137
    rhs       c688      10
    rhs       c689      15
    rhs       c690      230
    rhs       c691      230
    rhs       c692      210
    rhs       c693      137
    rhs       c694      10
    rhs       c695      15
    rhs       c696      230
    rhs       c697      230
    rhs       c698      210
    rhs       c699      137
    rhs       c700      10
    rhs       c701      15
    rhs       c702      230
    rhs       c703      230
    rhs       c704      210
    rhs       c705      137
    rhs       c706      10
    rhs       c707      15
    rhs       c708      230
    rhs       c709      230
    rhs       c710      210
    rhs       c711      137
    rhs       c712      10
    rhs       c713      15
    rhs       c714      230
    rhs       c715      230
    rhs       c716      210
    rhs       c717      137
    rhs       c718      10
    rhs       c719      15
    rhs       c720      230
    rhs       c721      230
    rhs       c722      130
    rhs       c723      137
    rhs       c724      13
    rhs       c725      15
    rhs       c726      230
    rhs       c727      230
    rhs       c728      130
    rhs       c729      137
    rhs       c730      13
    rhs       c731      15
    rhs       c732      230
    rhs       c733      230
    rhs       c734      130
    rhs       c735      137
    rhs       c736      13
    rhs       c737      15
    rhs       c738      230
    rhs       c739      230
    rhs       c740      130
    rhs       c741      137
    rhs       c742      13
    rhs       c743      15
    rhs       c744      230
    rhs       c745      230
    rhs       c746      130
    rhs       c747      137
    rhs       c748      13
    rhs       c749      15
    rhs       c750      230
    rhs       c751      230
    rhs       c752      130
    rhs       c753      137
    rhs       c754      13
    rhs       c755      15
    rhs       c756      230
    rhs       c757      230
    rhs       c758      130
    rhs       c759      137
    rhs       c760      13
    rhs       c761      15
    rhs       c762      230
    rhs       c763      230
    rhs       c764      130
    rhs       c765      137
    rhs       c766      13
    rhs       c767      15
    rhs       c768      230
    rhs       c769      230
    rhs       c770      130
    rhs       c771      137
    rhs       c772      13
    rhs       c773      15
    rhs       c774      230
    rhs       c775      230
    rhs       c776      130
    rhs       c777      137
    rhs       c778      13
    rhs       c779      15
    rhs       c780      230
    rhs       c781      230
    rhs       c782      210
    rhs       c783      137
    rhs       c784      10
    rhs       c785      15
    rhs       c786      230
    rhs       c787      230
    rhs       c788      210
    rhs       c789      137
    rhs       c790      10
    rhs       c791      15
    rhs       c792      230
    rhs       c793      230
    rhs       c794      210
    rhs       c795      137
    rhs       c796      10
    rhs       c797      15
    rhs       c798      230
    rhs       c799      230
    rhs       c800      210
    rhs       c801      137
    rhs       c802      10
    rhs       c803      15
    rhs       c804      230
    rhs       c805      230
    rhs       c806      210
    rhs       c807      137
    rhs       c808      10
    rhs       c809      15
    rhs       c810      230
    rhs       c811      230
    rhs       c812      210
    rhs       c813      137
    rhs       c814      10
    rhs       c815      15
    rhs       c816      230
    rhs       c817      230
    rhs       c818      210
    rhs       c819      137
    rhs       c820      10
    rhs       c821      15
    rhs       c822      230
    rhs       c823      230
    rhs       c824      210
    rhs       c825      137
    rhs       c826      10
    rhs       c827      15
    rhs       c828      230
    rhs       c829      230
    rhs       c830      210
    rhs       c831      137
    rhs       c832      10
    rhs       c833      15
    rhs       c834      230
    rhs       c835      230
    rhs       c836      210
    rhs       c837      137
    rhs       c838      10
    rhs       c839      15
    rhs       c840      230
    rhs       c841      230
    rhs       c842      210
    rhs       c843      137
    rhs       c844      10
    rhs       c845      15
    rhs       c846      230
    rhs       c847      230
    rhs       c848      210
    rhs       c849      137
    rhs       c850      10
    rhs       c851      15
    rhs       c852      230
    rhs       c853      230
    rhs       c854      210
    rhs       c855      137
    rhs       c856      10
    rhs       c857      15
    rhs       c858      230
    rhs       c859      230
    rhs       c860      210
    rhs       c861      137
    rhs       c862      10
    rhs       c863      15
    rhs       c864      230
    rhs       c865      230
    rhs       c866      210
    rhs       c867      137
    rhs       c868      10
    rhs       c869      15
    rhs       c870      230
    rhs       c871      230
    rhs       c872      210
    rhs       c873      137
    rhs       c874      10
    rhs       c875      15
    rhs       c876      230
    rhs       c877      230
    rhs       c878      210
    rhs       c879      137
    rhs       c880      10
    rhs       c881      15
    rhs       c882      230
    rhs       c883      230
    rhs       c884      210
    rhs       c885      137
    rhs       c886      10
    rhs       c887      15
    rhs       c888      230
    rhs       c889      230
    rhs       c890      210
    rhs       c891      137
    rhs       c892      10
    rhs       c893      15
    rhs       c894      230
    rhs       c895      230
    rhs       c896      210
    rhs       c897      137
    rhs       c898      10
    rhs       c899      15
    rhs       c900      230
    rhs       c901      230
    rhs       c902      130
    rhs       c903      137
    rhs       c904      13
    rhs       c905      15
    rhs       c906      230
    rhs       c907      230
    rhs       c908      130
    rhs       c909      137
    rhs       c910      13
    rhs       c911      15
    rhs       c912      230
    rhs       c913      230
    rhs       c914      130
    rhs       c915      137
    rhs       c916      13
    rhs       c917      15
    rhs       c918      230
    rhs       c919      230
    rhs       c920      130
    rhs       c921      137
    rhs       c922      13
    rhs       c923      15
    rhs       c924      230
    rhs       c925      230
    rhs       c926      130
    rhs       c927      137
    rhs       c928      13
    rhs       c929      15
    rhs       c930      230
    rhs       c931      230
    rhs       c932      130
    rhs       c933      137
    rhs       c934      13
    rhs       c935      15
    rhs       c936      230
    rhs       c937      230
    rhs       c938      130
    rhs       c939      137
    rhs       c940      13
    rhs       c941      15
    rhs       c942      230
    rhs       c943      230
    rhs       c944      130
    rhs       c945      137
    rhs       c946      13
    rhs       c947      15
    rhs       c948      230
    rhs       c949      230
    rhs       c950      130
    rhs       c951      137
    rhs       c952      13
    rhs       c953      15
    rhs       c954      230
    rhs       c955      230
    rhs       c956      130
    rhs       c957      137
    rhs       c958      13
    rhs       c959      15
    rhs       c960      230
    rhs       c961      230
    rhs       c962      210
    rhs       c963      210
    rhs       c964      10
    rhs       c965      10
    rhs       c966      230
    rhs       c967      230
    rhs       c968      210
    rhs       c969      210
    rhs       c970      10
    rhs       c971      10
    rhs       c972      230
    rhs       c973      230
    rhs       c974      210
    rhs       c975      210
    rhs       c976      10
    rhs       c977      10
    rhs       c978      230
    rhs       c979      230
    rhs       c980      210
    rhs       c981      210
    rhs       c982      10
    rhs       c983      10
    rhs       c984      230
    rhs       c985      230
    rhs       c986      210
    rhs       c987      210
    rhs       c988      10
    rhs       c989      10
    rhs       c990      230
    rhs       c991      230
    rhs       c992      210
    rhs       c993      210
    rhs       c994      10
    rhs       c995      10
    rhs       c996      230
    rhs       c997      230
    rhs       c998      210
    rhs       c999      210
    rhs       c1000     10
    rhs       c1001     10
    rhs       c1002     230
    rhs       c1003     230
    rhs       c1004     210
    rhs       c1005     210
    rhs       c1006     10
    rhs       c1007     10
    rhs       c1008     230
    rhs       c1009     230
    rhs       c1010     210
    rhs       c1011     210
    rhs       c1012     10
    rhs       c1013     10
    rhs       c1014     230
    rhs       c1015     230
    rhs       c1016     210
    rhs       c1017     210
    rhs       c1018     10
    rhs       c1019     10
    rhs       c1020     230
    rhs       c1021     230
    rhs       c1022     210
    rhs       c1023     210
    rhs       c1024     10
    rhs       c1025     10
    rhs       c1026     230
    rhs       c1027     230
    rhs       c1028     210
    rhs       c1029     210
    rhs       c1030     10
    rhs       c1031     10
    rhs       c1032     230
    rhs       c1033     230
    rhs       c1034     210
    rhs       c1035     210
    rhs       c1036     10
    rhs       c1037     10
    rhs       c1038     230
    rhs       c1039     230
    rhs       c1040     210
    rhs       c1041     210
    rhs       c1042     10
    rhs       c1043     10
    rhs       c1044     230
    rhs       c1045     230
    rhs       c1046     210
    rhs       c1047     210
    rhs       c1048     10
    rhs       c1049     10
    rhs       c1050     230
    rhs       c1051     230
    rhs       c1052     210
    rhs       c1053     210
    rhs       c1054     10
    rhs       c1055     10
    rhs       c1056     230
    rhs       c1057     230
    rhs       c1058     210
    rhs       c1059     210
    rhs       c1060     10
    rhs       c1061     10
    rhs       c1062     230
    rhs       c1063     230
    rhs       c1064     210
    rhs       c1065     210
    rhs       c1066     10
    rhs       c1067     10
    rhs       c1068     230
    rhs       c1069     230
    rhs       c1070     210
    rhs       c1071     210
    rhs       c1072     10
    rhs       c1073     10
    rhs       c1074     230
    rhs       c1075     230
    rhs       c1076     130
    rhs       c1077     210
    rhs       c1078     13
    rhs       c1079     10
    rhs       c1080     230
    rhs       c1081     230
    rhs       c1082     130
    rhs       c1083     210
    rhs       c1084     13
    rhs       c1085     10
    rhs       c1086     230
    rhs       c1087     230
    rhs       c1088     130
    rhs       c1089     210
    rhs       c1090     13
    rhs       c1091     10
    rhs       c1092     230
    rhs       c1093     230
    rhs       c1094     130
    rhs       c1095     210
    rhs       c1096     13
    rhs       c1097     10
    rhs       c1098     230
    rhs       c1099     230
    rhs       c1100     130
    rhs       c1101     210
    rhs       c1102     13
    rhs       c1103     10
    rhs       c1104     230
    rhs       c1105     230
    rhs       c1106     130
    rhs       c1107     210
    rhs       c1108     13
    rhs       c1109     10
    rhs       c1110     230
    rhs       c1111     230
    rhs       c1112     130
    rhs       c1113     210
    rhs       c1114     13
    rhs       c1115     10
    rhs       c1116     230
    rhs       c1117     230
    rhs       c1118     130
    rhs       c1119     210
    rhs       c1120     13
    rhs       c1121     10
    rhs       c1122     230
    rhs       c1123     230
    rhs       c1124     130
    rhs       c1125     210
    rhs       c1126     13
    rhs       c1127     10
    rhs       c1128     230
    rhs       c1129     230
    rhs       c1130     130
    rhs       c1131     210
    rhs       c1132     13
    rhs       c1133     10
    rhs       c1134     230
    rhs       c1135     230
    rhs       c1136     210
    rhs       c1137     210
    rhs       c1138     10
    rhs       c1139     10
    rhs       c1140     230
    rhs       c1141     230
    rhs       c1142     210
    rhs       c1143     210
    rhs       c1144     10
    rhs       c1145     10
    rhs       c1146     230
    rhs       c1147     230
    rhs       c1148     210
    rhs       c1149     210
    rhs       c1150     10
    rhs       c1151     10
    rhs       c1152     230
    rhs       c1153     230
    rhs       c1154     210
    rhs       c1155     210
    rhs       c1156     10
    rhs       c1157     10
    rhs       c1158     230
    rhs       c1159     230
    rhs       c1160     210
    rhs       c1161     210
    rhs       c1162     10
    rhs       c1163     10
    rhs       c1164     230
    rhs       c1165     230
    rhs       c1166     210
    rhs       c1167     210
    rhs       c1168     10
    rhs       c1169     10
    rhs       c1170     230
    rhs       c1171     230
    rhs       c1172     210
    rhs       c1173     210
    rhs       c1174     10
    rhs       c1175     10
    rhs       c1176     230
    rhs       c1177     230
    rhs       c1178     210
    rhs       c1179     210
    rhs       c1180     10
    rhs       c1181     10
    rhs       c1182     230
    rhs       c1183     230
    rhs       c1184     210
    rhs       c1185     210
    rhs       c1186     10
    rhs       c1187     10
    rhs       c1188     230
    rhs       c1189     230
    rhs       c1190     210
    rhs       c1191     210
    rhs       c1192     10
    rhs       c1193     10
    rhs       c1194     230
    rhs       c1195     230
    rhs       c1196     210
    rhs       c1197     210
    rhs       c1198     10
    rhs       c1199     10
    rhs       c1200     230
    rhs       c1201     230
    rhs       c1202     210
    rhs       c1203     210
    rhs       c1204     10
    rhs       c1205     10
    rhs       c1206     230
    rhs       c1207     230
    rhs       c1208     210
    rhs       c1209     210
    rhs       c1210     10
    rhs       c1211     10
    rhs       c1212     230
    rhs       c1213     230
    rhs       c1214     210
    rhs       c1215     210
    rhs       c1216     10
    rhs       c1217     10
    rhs       c1218     230
    rhs       c1219     230
    rhs       c1220     210
    rhs       c1221     210
    rhs       c1222     10
    rhs       c1223     10
    rhs       c1224     230
    rhs       c1225     230
    rhs       c1226     210
    rhs       c1227     210
    rhs       c1228     10
    rhs       c1229     10
    rhs       c1230     230
    rhs       c1231     230
    rhs       c1232     210
    rhs       c1233     210
    rhs       c1234     10
    rhs       c1235     10
    rhs       c1236     230
    rhs       c1237     230
    rhs       c1238     210
    rhs       c1239     210
    rhs       c1240     10
    rhs       c1241     10
    rhs       c1242     230
    rhs       c1243     230
    rhs       c1244     130
    rhs       c1245     210
    rhs       c1246     13
    rhs       c1247     10
    rhs       c1248     230
    rhs       c1249     230
    rhs       c1250     130
    rhs       c1251     210
    rhs       c1252     13
    rhs       c1253     10
    rhs       c1254     230
    rhs       c1255     230
    rhs       c1256     130
    rhs       c1257     210
    rhs       c1258     13
    rhs       c1259     10
    rhs       c1260     230
    rhs       c1261     230
    rhs       c1262     130
    rhs       c1263     210
    rhs       c1264     13
    rhs       c1265     10
    rhs       c1266     230
    rhs       c1267     230
    rhs       c1268     130
    rhs       c1269     210
    rhs       c1270     13
    rhs       c1271     10
    rhs       c1272     230
    rhs       c1273     230
    rhs       c1274     130
    rhs       c1275     210
    rhs       c1276     13
    rhs       c1277     10
    rhs       c1278     230
    rhs       c1279     230
    rhs       c1280     130
    rhs       c1281     210
    rhs       c1282     13
    rhs       c1283     10
    rhs       c1284     230
    rhs       c1285     230
    rhs       c1286     130
    rhs       c1287     210
    rhs       c1288     13
    rhs       c1289     10
    rhs       c1290     230
    rhs       c1291     230
    rhs       c1292     130
    rhs       c1293     210
    rhs       c1294     13
    rhs       c1295     10
    rhs       c1296     230
    rhs       c1297     230
    rhs       c1298     130
    rhs       c1299     210
    rhs       c1300     13
    rhs       c1301     10
    rhs       c1302     230
    rhs       c1303     230
    rhs       c1304     210
    rhs       c1305     210
    rhs       c1306     10
    rhs       c1307     10
    rhs       c1308     230
    rhs       c1309     230
    rhs       c1310     210
    rhs       c1311     210
    rhs       c1312     10
    rhs       c1313     10
    rhs       c1314     230
    rhs       c1315     230
    rhs       c1316     210
    rhs       c1317     210
    rhs       c1318     10
    rhs       c1319     10
    rhs       c1320     230
    rhs       c1321     230
    rhs       c1322     210
    rhs       c1323     210
    rhs       c1324     10
    rhs       c1325     10
    rhs       c1326     230
    rhs       c1327     230
    rhs       c1328     210
    rhs       c1329     210
    rhs       c1330     10
    rhs       c1331     10
    rhs       c1332     230
    rhs       c1333     230
    rhs       c1334     210
    rhs       c1335     210
    rhs       c1336     10
    rhs       c1337     10
    rhs       c1338     230
    rhs       c1339     230
    rhs       c1340     210
    rhs       c1341     210
    rhs       c1342     10
    rhs       c1343     10
    rhs       c1344     230
    rhs       c1345     230
    rhs       c1346     210
    rhs       c1347     210
    rhs       c1348     10
    rhs       c1349     10
    rhs       c1350     230
    rhs       c1351     230
    rhs       c1352     210
    rhs       c1353     210
    rhs       c1354     10
    rhs       c1355     10
    rhs       c1356     230
    rhs       c1357     230
    rhs       c1358     210
    rhs       c1359     210
    rhs       c1360     10
    rhs       c1361     10
    rhs       c1362     230
    rhs       c1363     230
    rhs       c1364     210
    rhs       c1365     210
    rhs       c1366     10
    rhs       c1367     10
    rhs       c1368     230
    rhs       c1369     230
    rhs       c1370     210
    rhs       c1371     210
    rhs       c1372     10
    rhs       c1373     10
    rhs       c1374     230
    rhs       c1375     230
    rhs       c1376     210
    rhs       c1377     210
    rhs       c1378     10
    rhs       c1379     10
    rhs       c1380     230
    rhs       c1381     230
    rhs       c1382     210
    rhs       c1383     210
    rhs       c1384     10
    rhs       c1385     10
    rhs       c1386     230
    rhs       c1387     230
    rhs       c1388     210
    rhs       c1389     210
    rhs       c1390     10
    rhs       c1391     10
    rhs       c1392     230
    rhs       c1393     230
    rhs       c1394     210
    rhs       c1395     210
    rhs       c1396     10
    rhs       c1397     10
    rhs       c1398     230
    rhs       c1399     230
    rhs       c1400     210
    rhs       c1401     210
    rhs       c1402     10
    rhs       c1403     10
    rhs       c1404     230
    rhs       c1405     230
    rhs       c1406     130
    rhs       c1407     210
    rhs       c1408     13
    rhs       c1409     10
    rhs       c1410     230
    rhs       c1411     230
    rhs       c1412     130
    rhs       c1413     210
    rhs       c1414     13
    rhs       c1415     10
    rhs       c1416     230
    rhs       c1417     230
    rhs       c1418     130
    rhs       c1419     210
    rhs       c1420     13
    rhs       c1421     10
    rhs       c1422     230
    rhs       c1423     230
    rhs       c1424     130
    rhs       c1425     210
    rhs       c1426     13
    rhs       c1427     10
    rhs       c1428     230
    rhs       c1429     230
    rhs       c1430     130
    rhs       c1431     210
    rhs       c1432     13
    rhs       c1433     10
    rhs       c1434     230
    rhs       c1435     230
    rhs       c1436     130
    rhs       c1437     210
    rhs       c1438     13
    rhs       c1439     10
    rhs       c1440     230
    rhs       c1441     230
    rhs       c1442     130
    rhs       c1443     210
    rhs       c1444     13
    rhs       c1445     10
    rhs       c1446     230
    rhs       c1447     230
    rhs       c1448     130
    rhs       c1449     210
    rhs       c1450     13
    rhs       c1451     10
    rhs       c1452     230
    rhs       c1453     230
    rhs       c1454     130
    rhs       c1455     210
    rhs       c1456     13
    rhs       c1457     10
    rhs       c1458     230
    rhs       c1459     230
    rhs       c1460     130
    rhs       c1461     210
    rhs       c1462     13
    rhs       c1463     10
    rhs       c1464     230
    rhs       c1465     230
    rhs       c1466     210
    rhs       c1467     210
    rhs       c1468     10
    rhs       c1469     10
    rhs       c1470     230
    rhs       c1471     230
    rhs       c1472     210
    rhs       c1473     210
    rhs       c1474     10
    rhs       c1475     10
    rhs       c1476     230
    rhs       c1477     230
    rhs       c1478     210
    rhs       c1479     210
    rhs       c1480     10
    rhs       c1481     10
    rhs       c1482     230
    rhs       c1483     230
    rhs       c1484     210
    rhs       c1485     210
    rhs       c1486     10
    rhs       c1487     10
    rhs       c1488     230
    rhs       c1489     230
    rhs       c1490     210
    rhs       c1491     210
    rhs       c1492     10
    rhs       c1493     10
    rhs       c1494     230
    rhs       c1495     230
    rhs       c1496     210
    rhs       c1497     210
    rhs       c1498     10
    rhs       c1499     10
    rhs       c1500     230
    rhs       c1501     230
    rhs       c1502     210
    rhs       c1503     210
    rhs       c1504     10
    rhs       c1505     10
    rhs       c1506     230
    rhs       c1507     230
    rhs       c1508     210
    rhs       c1509     210
    rhs       c1510     10
    rhs       c1511     10
    rhs       c1512     230
    rhs       c1513     230
    rhs       c1514     210
    rhs       c1515     210
    rhs       c1516     10
    rhs       c1517     10
    rhs       c1518     230
    rhs       c1519     230
    rhs       c1520     210
    rhs       c1521     210
    rhs       c1522     10
    rhs       c1523     10
    rhs       c1524     230
    rhs       c1525     230
    rhs       c1526     210
    rhs       c1527     210
    rhs       c1528     10
    rhs       c1529     10
    rhs       c1530     230
    rhs       c1531     230
    rhs       c1532     210
    rhs       c1533     210
    rhs       c1534     10
    rhs       c1535     10
    rhs       c1536     230
    rhs       c1537     230
    rhs       c1538     210
    rhs       c1539     210
    rhs       c1540     10
    rhs       c1541     10
    rhs       c1542     230
    rhs       c1543     230
    rhs       c1544     210
    rhs       c1545     210
    rhs       c1546     10
    rhs       c1547     10
    rhs       c1548     230
    rhs       c1549     230
    rhs       c1550     210
    rhs       c1551     210
    rhs       c1552     10
    rhs       c1553     10
    rhs       c1554     230
    rhs       c1555     230
    rhs       c1556     210
    rhs       c1557     210
    rhs       c1558     10
    rhs       c1559     10
    rhs       c1560     230
    rhs       c1561     230
    rhs       c1562     130
    rhs       c1563     210
    rhs       c1564     13
    rhs       c1565     10
    rhs       c1566     230
    rhs       c1567     230
    rhs       c1568     130
    rhs       c1569     210
    rhs       c1570     13
    rhs       c1571     10
    rhs       c1572     230
    rhs       c1573     230
    rhs       c1574     130
    rhs       c1575     210
    rhs       c1576     13
    rhs       c1577     10
    rhs       c1578     230
    rhs       c1579     230
    rhs       c1580     130
    rhs       c1581     210
    rhs       c1582     13
    rhs       c1583     10
    rhs       c1584     230
    rhs       c1585     230
    rhs       c1586     130
    rhs       c1587     210
    rhs       c1588     13
    rhs       c1589     10
    rhs       c1590     230
    rhs       c1591     230
    rhs       c1592     130
    rhs       c1593     210
    rhs       c1594     13
    rhs       c1595     10
    rhs       c1596     230
    rhs       c1597     230
    rhs       c1598     130
    rhs       c1599     210
    rhs       c1600     13
    rhs       c1601     10
    rhs       c1602     230
    rhs       c1603     230
    rhs       c1604     130
    rhs       c1605     210
    rhs       c1606     13
    rhs       c1607     10
    rhs       c1608     230
    rhs       c1609     230
    rhs       c1610     130
    rhs       c1611     210
    rhs       c1612     13
    rhs       c1613     10
    rhs       c1614     230
    rhs       c1615     230
    rhs       c1616     130
    rhs       c1617     210
    rhs       c1618     13
    rhs       c1619     10
    rhs       c1620     230
    rhs       c1621     230
    rhs       c1622     210
    rhs       c1623     210
    rhs       c1624     10
    rhs       c1625     10
    rhs       c1626     230
    rhs       c1627     230
    rhs       c1628     210
    rhs       c1629     210
    rhs       c1630     10
    rhs       c1631     10
    rhs       c1632     230
    rhs       c1633     230
    rhs       c1634     210
    rhs       c1635     210
    rhs       c1636     10
    rhs       c1637     10
    rhs       c1638     230
    rhs       c1639     230
    rhs       c1640     210
    rhs       c1641     210
    rhs       c1642     10
    rhs       c1643     10
    rhs       c1644     230
    rhs       c1645     230
    rhs       c1646     210
    rhs       c1647     210
    rhs       c1648     10
    rhs       c1649     10
    rhs       c1650     230
    rhs       c1651     230
    rhs       c1652     210
    rhs       c1653     210
    rhs       c1654     10
    rhs       c1655     10
    rhs       c1656     230
    rhs       c1657     230
    rhs       c1658     210
    rhs       c1659     210
    rhs       c1660     10
    rhs       c1661     10
    rhs       c1662     230
    rhs       c1663     230
    rhs       c1664     210
    rhs       c1665     210
    rhs       c1666     10
    rhs       c1667     10
    rhs       c1668     230
    rhs       c1669     230
    rhs       c1670     210
    rhs       c1671     210
    rhs       c1672     10
    rhs       c1673     10
    rhs       c1674     230
    rhs       c1675     230
    rhs       c1676     210
    rhs       c1677     210
    rhs       c1678     10
    rhs       c1679     10
    rhs       c1680     230
    rhs       c1681     230
    rhs       c1682     210
    rhs       c1683     210
    rhs       c1684     10
    rhs       c1685     10
    rhs       c1686     230
    rhs       c1687     230
    rhs       c1688     210
    rhs       c1689     210
    rhs       c1690     10
    rhs       c1691     10
    rhs       c1692     230
    rhs       c1693     230
    rhs       c1694     210
    rhs       c1695     210
    rhs       c1696     10
    rhs       c1697     10
    rhs       c1698     230
    rhs       c1699     230
    rhs       c1700     210
    rhs       c1701     210
    rhs       c1702     10
    rhs       c1703     10
    rhs       c1704     230
    rhs       c1705     230
    rhs       c1706     210
    rhs       c1707     210
    rhs       c1708     10
    rhs       c1709     10
    rhs       c1710     230
    rhs       c1711     230
    rhs       c1712     130
    rhs       c1713     210
    rhs       c1714     13
    rhs       c1715     10
    rhs       c1716     230
    rhs       c1717     230
    rhs       c1718     130
    rhs       c1719     210
    rhs       c1720     13
    rhs       c1721     10
    rhs       c1722     230
    rhs       c1723     230
    rhs       c1724     130
    rhs       c1725     210
    rhs       c1726     13
    rhs       c1727     10
    rhs       c1728     230
    rhs       c1729     230
    rhs       c1730     130
    rhs       c1731     210
    rhs       c1732     13
    rhs       c1733     10
    rhs       c1734     230
    rhs       c1735     230
    rhs       c1736     130
    rhs       c1737     210
    rhs       c1738     13
    rhs       c1739     10
    rhs       c1740     230
    rhs       c1741     230
    rhs       c1742     130
    rhs       c1743     210
    rhs       c1744     13
    rhs       c1745     10
    rhs       c1746     230
    rhs       c1747     230
    rhs       c1748     130
    rhs       c1749     210
    rhs       c1750     13
    rhs       c1751     10
    rhs       c1752     230
    rhs       c1753     230
    rhs       c1754     130
    rhs       c1755     210
    rhs       c1756     13
    rhs       c1757     10
    rhs       c1758     230
    rhs       c1759     230
    rhs       c1760     130
    rhs       c1761     210
    rhs       c1762     13
    rhs       c1763     10
    rhs       c1764     230
    rhs       c1765     230
    rhs       c1766     130
    rhs       c1767     210
    rhs       c1768     13
    rhs       c1769     10
    rhs       c1770     230
    rhs       c1771     230
    rhs       c1772     210
    rhs       c1773     210
    rhs       c1774     10
    rhs       c1775     10
    rhs       c1776     230
    rhs       c1777     230
    rhs       c1778     210
    rhs       c1779     210
    rhs       c1780     10
    rhs       c1781     10
    rhs       c1782     230
    rhs       c1783     230
    rhs       c1784     210
    rhs       c1785     210
    rhs       c1786     10
    rhs       c1787     10
    rhs       c1788     230
    rhs       c1789     230
    rhs       c1790     210
    rhs       c1791     210
    rhs       c1792     10
    rhs       c1793     10
    rhs       c1794     230
    rhs       c1795     230
    rhs       c1796     210
    rhs       c1797     210
    rhs       c1798     10
    rhs       c1799     10
    rhs       c1800     230
    rhs       c1801     230
    rhs       c1802     210
    rhs       c1803     210
    rhs       c1804     10
    rhs       c1805     10
    rhs       c1806     230
    rhs       c1807     230
    rhs       c1808     210
    rhs       c1809     210
    rhs       c1810     10
    rhs       c1811     10
    rhs       c1812     230
    rhs       c1813     230
    rhs       c1814     210
    rhs       c1815     210
    rhs       c1816     10
    rhs       c1817     10
    rhs       c1818     230
    rhs       c1819     230
    rhs       c1820     210
    rhs       c1821     210
    rhs       c1822     10
    rhs       c1823     10
    rhs       c1824     230
    rhs       c1825     230
    rhs       c1826     210
    rhs       c1827     210
    rhs       c1828     10
    rhs       c1829     10
    rhs       c1830     230
    rhs       c1831     230
    rhs       c1832     210
    rhs       c1833     210
    rhs       c1834     10
    rhs       c1835     10
    rhs       c1836     230
    rhs       c1837     230
    rhs       c1838     210
    rhs       c1839     210
    rhs       c1840     10
    rhs       c1841     10
    rhs       c1842     230
    rhs       c1843     230
    rhs       c1844     210
    rhs       c1845     210
    rhs       c1846     10
    rhs       c1847     10
    rhs       c1848     230
    rhs       c1849     230
    rhs       c1850     210
    rhs       c1851     210
    rhs       c1852     10
    rhs       c1853     10
    rhs       c1854     230
    rhs       c1855     230
    rhs       c1856     130
    rhs       c1857     210
    rhs       c1858     13
    rhs       c1859     10
    rhs       c1860     230
    rhs       c1861     230
    rhs       c1862     130
    rhs       c1863     210
    rhs       c1864     13
    rhs       c1865     10
    rhs       c1866     230
    rhs       c1867     230
    rhs       c1868     130
    rhs       c1869     210
    rhs       c1870     13
    rhs       c1871     10
    rhs       c1872     230
    rhs       c1873     230
    rhs       c1874     130
    rhs       c1875     210
    rhs       c1876     13
    rhs       c1877     10
    rhs       c1878     230
    rhs       c1879     230
    rhs       c1880     130
    rhs       c1881     210
    rhs       c1882     13
    rhs       c1883     10
    rhs       c1884     230
    rhs       c1885     230
    rhs       c1886     130
    rhs       c1887     210
    rhs       c1888     13
    rhs       c1889     10
    rhs       c1890     230
    rhs       c1891     230
    rhs       c1892     130
    rhs       c1893     210
    rhs       c1894     13
    rhs       c1895     10
    rhs       c1896     230
    rhs       c1897     230
    rhs       c1898     130
    rhs       c1899     210
    rhs       c1900     13
    rhs       c1901     10
    rhs       c1902     230
    rhs       c1903     230
    rhs       c1904     130
    rhs       c1905     210
    rhs       c1906     13
    rhs       c1907     10
    rhs       c1908     230
    rhs       c1909     230
    rhs       c1910     130
    rhs       c1911     210
    rhs       c1912     13
    rhs       c1913     10
    rhs       c1914     230
    rhs       c1915     230
    rhs       c1916     210
    rhs       c1917     210
    rhs       c1918     10
    rhs       c1919     10
    rhs       c1920     230
    rhs       c1921     230
    rhs       c1922     210
    rhs       c1923     210
    rhs       c1924     10
    rhs       c1925     10
    rhs       c1926     230
    rhs       c1927     230
    rhs       c1928     210
    rhs       c1929     210
    rhs       c1930     10
    rhs       c1931     10
    rhs       c1932     230
    rhs       c1933     230
    rhs       c1934     210
    rhs       c1935     210
    rhs       c1936     10
    rhs       c1937     10
    rhs       c1938     230
    rhs       c1939     230
    rhs       c1940     210
    rhs       c1941     210
    rhs       c1942     10
    rhs       c1943     10
    rhs       c1944     230
    rhs       c1945     230
    rhs       c1946     210
    rhs       c1947     210
    rhs       c1948     10
    rhs       c1949     10
    rhs       c1950     230
    rhs       c1951     230
    rhs       c1952     210
    rhs       c1953     210
    rhs       c1954     10
    rhs       c1955     10
    rhs       c1956     230
    rhs       c1957     230
    rhs       c1958     210
    rhs       c1959     210
    rhs       c1960     10
    rhs       c1961     10
    rhs       c1962     230
    rhs       c1963     230
    rhs       c1964     210
    rhs       c1965     210
    rhs       c1966     10
    rhs       c1967     10
    rhs       c1968     230
    rhs       c1969     230
    rhs       c1970     210
    rhs       c1971     210
    rhs       c1972     10
    rhs       c1973     10
    rhs       c1974     230
    rhs       c1975     230
    rhs       c1976     210
    rhs       c1977     210
    rhs       c1978     10
    rhs       c1979     10
    rhs       c1980     230
    rhs       c1981     230
    rhs       c1982     210
    rhs       c1983     210
    rhs       c1984     10
    rhs       c1985     10
    rhs       c1986     230
    rhs       c1987     230
    rhs       c1988     210
    rhs       c1989     210
    rhs       c1990     10
    rhs       c1991     10
    rhs       c1992     230
    rhs       c1993     230
    rhs       c1994     130
    rhs       c1995     210
    rhs       c1996     13
    rhs       c1997     10
    rhs       c1998     230
    rhs       c1999     230
    rhs       c2000     130
    rhs       c2001     210
    rhs       c2002     13
    rhs       c2003     10
    rhs       c2004     230
    rhs       c2005     230
    rhs       c2006     130
    rhs       c2007     210
    rhs       c2008     13
    rhs       c2009     10
    rhs       c2010     230
    rhs       c2011     230
    rhs       c2012     130
    rhs       c2013     210
    rhs       c2014     13
    rhs       c2015     10
    rhs       c2016     230
    rhs       c2017     230
    rhs       c2018     130
    rhs       c2019     210
    rhs       c2020     13
    rhs       c2021     10
    rhs       c2022     230
    rhs       c2023     230
    rhs       c2024     130
    rhs       c2025     210
    rhs       c2026     13
    rhs       c2027     10
    rhs       c2028     230
    rhs       c2029     230
    rhs       c2030     130
    rhs       c2031     210
    rhs       c2032     13
    rhs       c2033     10
    rhs       c2034     230
    rhs       c2035     230
    rhs       c2036     130
    rhs       c2037     210
    rhs       c2038     13
    rhs       c2039     10
    rhs       c2040     230
    rhs       c2041     230
    rhs       c2042     130
    rhs       c2043     210
    rhs       c2044     13
    rhs       c2045     10
    rhs       c2046     230
    rhs       c2047     230
    rhs       c2048     130
    rhs       c2049     210
    rhs       c2050     13
    rhs       c2051     10
    rhs       c2052     230
    rhs       c2053     230
    rhs       c2054     210
    rhs       c2055     210
    rhs       c2056     10
    rhs       c2057     10
    rhs       c2058     230
    rhs       c2059     230
    rhs       c2060     210
    rhs       c2061     210
    rhs       c2062     10
    rhs       c2063     10
    rhs       c2064     230
    rhs       c2065     230
    rhs       c2066     210
    rhs       c2067     210
    rhs       c2068     10
    rhs       c2069     10
    rhs       c2070     230
    rhs       c2071     230
    rhs       c2072     210
    rhs       c2073     210
    rhs       c2074     10
    rhs       c2075     10
    rhs       c2076     230
    rhs       c2077     230
    rhs       c2078     210
    rhs       c2079     210
    rhs       c2080     10
    rhs       c2081     10
    rhs       c2082     230
    rhs       c2083     230
    rhs       c2084     210
    rhs       c2085     210
    rhs       c2086     10
    rhs       c2087     10
    rhs       c2088     230
    rhs       c2089     230
    rhs       c2090     210
    rhs       c2091     210
    rhs       c2092     10
    rhs       c2093     10
    rhs       c2094     230
    rhs       c2095     230
    rhs       c2096     210
    rhs       c2097     210
    rhs       c2098     10
    rhs       c2099     10
    rhs       c2100     230
    rhs       c2101     230
    rhs       c2102     210
    rhs       c2103     210
    rhs       c2104     10
    rhs       c2105     10
    rhs       c2106     230
    rhs       c2107     230
    rhs       c2108     210
    rhs       c2109     210
    rhs       c2110     10
    rhs       c2111     10
    rhs       c2112     230
    rhs       c2113     230
    rhs       c2114     210
    rhs       c2115     210
    rhs       c2116     10
    rhs       c2117     10
    rhs       c2118     230
    rhs       c2119     230
    rhs       c2120     210
    rhs       c2121     210
    rhs       c2122     10
    rhs       c2123     10
    rhs       c2124     230
    rhs       c2125     230
    rhs       c2126     130
    rhs       c2127     210
    rhs       c2128     13
    rhs       c2129     10
    rhs       c2130     230
    rhs       c2131     230
    rhs       c2132     130
    rhs       c2133     210
    rhs       c2134     13
    rhs       c2135     10
    rhs       c2136     230
    rhs       c2137     230
    rhs       c2138     130
    rhs       c2139     210
    rhs       c2140     13
    rhs       c2141     10
    rhs       c2142     230
    rhs       c2143     230
    rhs       c2144     130
    rhs       c2145     210
    rhs       c2146     13
    rhs       c2147     10
    rhs       c2148     230
    rhs       c2149     230
    rhs       c2150     130
    rhs       c2151     210
    rhs       c2152     13
    rhs       c2153     10
    rhs       c2154     230
    rhs       c2155     230
    rhs       c2156     130
    rhs       c2157     210
    rhs       c2158     13
    rhs       c2159     10
    rhs       c2160     230
    rhs       c2161     230
    rhs       c2162     130
    rhs       c2163     210
    rhs       c2164     13
    rhs       c2165     10
    rhs       c2166     230
    rhs       c2167     230
    rhs       c2168     130
    rhs       c2169     210
    rhs       c2170     13
    rhs       c2171     10
    rhs       c2172     230
    rhs       c2173     230
    rhs       c2174     130
    rhs       c2175     210
    rhs       c2176     13
    rhs       c2177     10
    rhs       c2178     230
    rhs       c2179     230
    rhs       c2180     130
    rhs       c2181     210
    rhs       c2182     13
    rhs       c2183     10
    rhs       c2184     230
    rhs       c2185     230
    rhs       c2186     210
    rhs       c2187     210
    rhs       c2188     10
    rhs       c2189     10
    rhs       c2190     230
    rhs       c2191     230
    rhs       c2192     210
    rhs       c2193     210
    rhs       c2194     10
    rhs       c2195     10
    rhs       c2196     230
    rhs       c2197     230
    rhs       c2198     210
    rhs       c2199     210
    rhs       c2200     10
    rhs       c2201     10
    rhs       c2202     230
    rhs       c2203     230
    rhs       c2204     210
    rhs       c2205     210
    rhs       c2206     10
    rhs       c2207     10
    rhs       c2208     230
    rhs       c2209     230
    rhs       c2210     210
    rhs       c2211     210
    rhs       c2212     10
    rhs       c2213     10
    rhs       c2214     230
    rhs       c2215     230
    rhs       c2216     210
    rhs       c2217     210
    rhs       c2218     10
    rhs       c2219     10
    rhs       c2220     230
    rhs       c2221     230
    rhs       c2222     210
    rhs       c2223     210
    rhs       c2224     10
    rhs       c2225     10
    rhs       c2226     230
    rhs       c2227     230
    rhs       c2228     210
    rhs       c2229     210
    rhs       c2230     10
    rhs       c2231     10
    rhs       c2232     230
    rhs       c2233     230
    rhs       c2234     210
    rhs       c2235     210
    rhs       c2236     10
    rhs       c2237     10
    rhs       c2238     230
    rhs       c2239     230
    rhs       c2240     210
    rhs       c2241     210
    rhs       c2242     10
    rhs       c2243     10
    rhs       c2244     230
    rhs       c2245     230
    rhs       c2246     210
    rhs       c2247     210
    rhs       c2248     10
    rhs       c2249     10
    rhs       c2250     230
    rhs       c2251     230
    rhs       c2252     130
    rhs       c2253     210
    rhs       c2254     13
    rhs       c2255     10
    rhs       c2256     230
    rhs       c2257     230
    rhs       c2258     130
    rhs       c2259     210
    rhs       c2260     13
    rhs       c2261     10
    rhs       c2262     230
    rhs       c2263     230
    rhs       c2264     130
    rhs       c2265     210
    rhs       c2266     13
    rhs       c2267     10
    rhs       c2268     230
    rhs       c2269     230
    rhs       c2270     130
    rhs       c2271     210
    rhs       c2272     13
    rhs       c2273     10
    rhs       c2274     230
    rhs       c2275     230
    rhs       c2276     130
    rhs       c2277     210
    rhs       c2278     13
    rhs       c2279     10
    rhs       c2280     230
    rhs       c2281     230
    rhs       c2282     130
    rhs       c2283     210
    rhs       c2284     13
    rhs       c2285     10
    rhs       c2286     230
    rhs       c2287     230
    rhs       c2288     130
    rhs       c2289     210
    rhs       c2290     13
    rhs       c2291     10
    rhs       c2292     230
    rhs       c2293     230
    rhs       c2294     130
    rhs       c2295     210
    rhs       c2296     13
    rhs       c2297     10
    rhs       c2298     230
    rhs       c2299     230
    rhs       c2300     130
    rhs       c2301     210
    rhs       c2302     13
    rhs       c2303     10
    rhs       c2304     230
    rhs       c2305     230
    rhs       c2306     130
    rhs       c2307     210
    rhs       c2308     13
    rhs       c2309     10
    rhs       c2310     230
    rhs       c2311     230
    rhs       c2312     210
    rhs       c2313     210
    rhs       c2314     10
    rhs       c2315     10
    rhs       c2316     230
    rhs       c2317     230
    rhs       c2318     210
    rhs       c2319     210
    rhs       c2320     10
    rhs       c2321     10
    rhs       c2322     230
    rhs       c2323     230
    rhs       c2324     210
    rhs       c2325     210
    rhs       c2326     10
    rhs       c2327     10
    rhs       c2328     230
    rhs       c2329     230
    rhs       c2330     210
    rhs       c2331     210
    rhs       c2332     10
    rhs       c2333     10
    rhs       c2334     230
    rhs       c2335     230
    rhs       c2336     210
    rhs       c2337     210
    rhs       c2338     10
    rhs       c2339     10
    rhs       c2340     230
    rhs       c2341     230
    rhs       c2342     210
    rhs       c2343     210
    rhs       c2344     10
    rhs       c2345     10
    rhs       c2346     230
    rhs       c2347     230
    rhs       c2348     210
    rhs       c2349     210
    rhs       c2350     10
    rhs       c2351     10
    rhs       c2352     230
    rhs       c2353     230
    rhs       c2354     210
    rhs       c2355     210
    rhs       c2356     10
    rhs       c2357     10
    rhs       c2358     230
    rhs       c2359     230
    rhs       c2360     210
    rhs       c2361     210
    rhs       c2362     10
    rhs       c2363     10
    rhs       c2364     230
    rhs       c2365     230
    rhs       c2366     210
    rhs       c2367     210
    rhs       c2368     10
    rhs       c2369     10
    rhs       c2370     230
    rhs       c2371     230
    rhs       c2372     130
    rhs       c2373     210
    rhs       c2374     13
    rhs       c2375     10
    rhs       c2376     230
    rhs       c2377     230
    rhs       c2378     130
    rhs       c2379     210
    rhs       c2380     13
    rhs       c2381     10
    rhs       c2382     230
    rhs       c2383     230
    rhs       c2384     130
    rhs       c2385     210
    rhs       c2386     13
    rhs       c2387     10
    rhs       c2388     230
    rhs       c2389     230
    rhs       c2390     130
    rhs       c2391     210
    rhs       c2392     13
    rhs       c2393     10
    rhs       c2394     230
    rhs       c2395     230
    rhs       c2396     130
    rhs       c2397     210
    rhs       c2398     13
    rhs       c2399     10
    rhs       c2400     230
    rhs       c2401     230
    rhs       c2402     130
    rhs       c2403     210
    rhs       c2404     13
    rhs       c2405     10
    rhs       c2406     230
    rhs       c2407     230
    rhs       c2408     130
    rhs       c2409     210
    rhs       c2410     13
    rhs       c2411     10
    rhs       c2412     230
    rhs       c2413     230
    rhs       c2414     130
    rhs       c2415     210
    rhs       c2416     13
    rhs       c2417     10
    rhs       c2418     230
    rhs       c2419     230
    rhs       c2420     130
    rhs       c2421     210
    rhs       c2422     13
    rhs       c2423     10
    rhs       c2424     230
    rhs       c2425     230
    rhs       c2426     130
    rhs       c2427     210
    rhs       c2428     13
    rhs       c2429     10
    rhs       c2430     230
    rhs       c2431     230
    rhs       c2432     210
    rhs       c2433     210
    rhs       c2434     10
    rhs       c2435     10
    rhs       c2436     230
    rhs       c2437     230
    rhs       c2438     210
    rhs       c2439     210
    rhs       c2440     10
    rhs       c2441     10
    rhs       c2442     230
    rhs       c2443     230
    rhs       c2444     210
    rhs       c2445     210
    rhs       c2446     10
    rhs       c2447     10
    rhs       c2448     230
    rhs       c2449     230
    rhs       c2450     210
    rhs       c2451     210
    rhs       c2452     10
    rhs       c2453     10
    rhs       c2454     230
    rhs       c2455     230
    rhs       c2456     210
    rhs       c2457     210
    rhs       c2458     10
    rhs       c2459     10
    rhs       c2460     230
    rhs       c2461     230
    rhs       c2462     210
    rhs       c2463     210
    rhs       c2464     10
    rhs       c2465     10
    rhs       c2466     230
    rhs       c2467     230
    rhs       c2468     210
    rhs       c2469     210
    rhs       c2470     10
    rhs       c2471     10
    rhs       c2472     230
    rhs       c2473     230
    rhs       c2474     210
    rhs       c2475     210
    rhs       c2476     10
    rhs       c2477     10
    rhs       c2478     230
    rhs       c2479     230
    rhs       c2480     210
    rhs       c2481     210
    rhs       c2482     10
    rhs       c2483     10
    rhs       c2484     230
    rhs       c2485     230
    rhs       c2486     130
    rhs       c2487     210
    rhs       c2488     13
    rhs       c2489     10
    rhs       c2490     230
    rhs       c2491     230
    rhs       c2492     130
    rhs       c2493     210
    rhs       c2494     13
    rhs       c2495     10
    rhs       c2496     230
    rhs       c2497     230
    rhs       c2498     130
    rhs       c2499     210
    rhs       c2500     13
    rhs       c2501     10
    rhs       c2502     230
    rhs       c2503     230
    rhs       c2504     130
    rhs       c2505     210
    rhs       c2506     13
    rhs       c2507     10
    rhs       c2508     230
    rhs       c2509     230
    rhs       c2510     130
    rhs       c2511     210
    rhs       c2512     13
    rhs       c2513     10
    rhs       c2514     230
    rhs       c2515     230
    rhs       c2516     130
    rhs       c2517     210
    rhs       c2518     13
    rhs       c2519     10
    rhs       c2520     230
    rhs       c2521     230
    rhs       c2522     130
    rhs       c2523     210
    rhs       c2524     13
    rhs       c2525     10
    rhs       c2526     230
    rhs       c2527     230
    rhs       c2528     130
    rhs       c2529     210
    rhs       c2530     13
    rhs       c2531     10
    rhs       c2532     230
    rhs       c2533     230
    rhs       c2534     130
    rhs       c2535     210
    rhs       c2536     13
    rhs       c2537     10
    rhs       c2538     230
    rhs       c2539     230
    rhs       c2540     130
    rhs       c2541     210
    rhs       c2542     13
    rhs       c2543     10
    rhs       c2544     230
    rhs       c2545     230
    rhs       c2546     210
    rhs       c2547     210
    rhs       c2548     10
    rhs       c2549     10
    rhs       c2550     230
    rhs       c2551     230
    rhs       c2552     210
    rhs       c2553     210
    rhs       c2554     10
    rhs       c2555     10
    rhs       c2556     230
    rhs       c2557     230
    rhs       c2558     210
    rhs       c2559     210
    rhs       c2560     10
    rhs       c2561     10
    rhs       c2562     230
    rhs       c2563     230
    rhs       c2564     210
    rhs       c2565     210
    rhs       c2566     10
    rhs       c2567     10
    rhs       c2568     230
    rhs       c2569     230
    rhs       c2570     210
    rhs       c2571     210
    rhs       c2572     10
    rhs       c2573     10
    rhs       c2574     230
    rhs       c2575     230
    rhs       c2576     210
    rhs       c2577     210
    rhs       c2578     10
    rhs       c2579     10
    rhs       c2580     230
    rhs       c2581     230
    rhs       c2582     210
    rhs       c2583     210
    rhs       c2584     10
    rhs       c2585     10
    rhs       c2586     230
    rhs       c2587     230
    rhs       c2588     210
    rhs       c2589     210
    rhs       c2590     10
    rhs       c2591     10
    rhs       c2592     230
    rhs       c2593     230
    rhs       c2594     130
    rhs       c2595     210
    rhs       c2596     13
    rhs       c2597     10
    rhs       c2598     230
    rhs       c2599     230
    rhs       c2600     130
    rhs       c2601     210
    rhs       c2602     13
    rhs       c2603     10
    rhs       c2604     230
    rhs       c2605     230
    rhs       c2606     130
    rhs       c2607     210
    rhs       c2608     13
    rhs       c2609     10
    rhs       c2610     230
    rhs       c2611     230
    rhs       c2612     130
    rhs       c2613     210
    rhs       c2614     13
    rhs       c2615     10
    rhs       c2616     230
    rhs       c2617     230
    rhs       c2618     130
    rhs       c2619     210
    rhs       c2620     13
    rhs       c2621     10
    rhs       c2622     230
    rhs       c2623     230
    rhs       c2624     130
    rhs       c2625     210
    rhs       c2626     13
    rhs       c2627     10
    rhs       c2628     230
    rhs       c2629     230
    rhs       c2630     130
    rhs       c2631     210
    rhs       c2632     13
    rhs       c2633     10
    rhs       c2634     230
    rhs       c2635     230
    rhs       c2636     130
    rhs       c2637     210
    rhs       c2638     13
    rhs       c2639     10
    rhs       c2640     230
    rhs       c2641     230
    rhs       c2642     130
    rhs       c2643     210
    rhs       c2644     13
    rhs       c2645     10
    rhs       c2646     230
    rhs       c2647     230
    rhs       c2648     130
    rhs       c2649     210
    rhs       c2650     13
    rhs       c2651     10
    rhs       c2652     230
    rhs       c2653     230
    rhs       c2654     210
    rhs       c2655     210
    rhs       c2656     10
    rhs       c2657     10
    rhs       c2658     230
    rhs       c2659     230
    rhs       c2660     210
    rhs       c2661     210
    rhs       c2662     10
    rhs       c2663     10
    rhs       c2664     230
    rhs       c2665     230
    rhs       c2666     210
    rhs       c2667     210
    rhs       c2668     10
    rhs       c2669     10
    rhs       c2670     230
    rhs       c2671     230
    rhs       c2672     210
    rhs       c2673     210
    rhs       c2674     10
    rhs       c2675     10
    rhs       c2676     230
    rhs       c2677     230
    rhs       c2678     210
    rhs       c2679     210
    rhs       c2680     10
    rhs       c2681     10
    rhs       c2682     230
    rhs       c2683     230
    rhs       c2684     210
    rhs       c2685     210
    rhs       c2686     10
    rhs       c2687     10
    rhs       c2688     230
    rhs       c2689     230
    rhs       c2690     210
    rhs       c2691     210
    rhs       c2692     10
    rhs       c2693     10
    rhs       c2694     230
    rhs       c2695     230
    rhs       c2696     130
    rhs       c2697     210
    rhs       c2698     13
    rhs       c2699     10
    rhs       c2700     230
    rhs       c2701     230
    rhs       c2702     130
    rhs       c2703     210
    rhs       c2704     13
    rhs       c2705     10
    rhs       c2706     230
    rhs       c2707     230
    rhs       c2708     130
    rhs       c2709     210
    rhs       c2710     13
    rhs       c2711     10
    rhs       c2712     230
    rhs       c2713     230
    rhs       c2714     130
    rhs       c2715     210
    rhs       c2716     13
    rhs       c2717     10
    rhs       c2718     230
    rhs       c2719     230
    rhs       c2720     130
    rhs       c2721     210
    rhs       c2722     13
    rhs       c2723     10
    rhs       c2724     230
    rhs       c2725     230
    rhs       c2726     130
    rhs       c2727     210
    rhs       c2728     13
    rhs       c2729     10
    rhs       c2730     230
    rhs       c2731     230
    rhs       c2732     130
    rhs       c2733     210
    rhs       c2734     13
    rhs       c2735     10
    rhs       c2736     230
    rhs       c2737     230
    rhs       c2738     130
    rhs       c2739     210
    rhs       c2740     13
    rhs       c2741     10
    rhs       c2742     230
    rhs       c2743     230
    rhs       c2744     130
    rhs       c2745     210
    rhs       c2746     13
    rhs       c2747     10
    rhs       c2748     230
    rhs       c2749     230
    rhs       c2750     130
    rhs       c2751     210
    rhs       c2752     13
    rhs       c2753     10
    rhs       c2754     230
    rhs       c2755     230
    rhs       c2756     210
    rhs       c2757     210
    rhs       c2758     10
    rhs       c2759     10
    rhs       c2760     230
    rhs       c2761     230
    rhs       c2762     210
    rhs       c2763     210
    rhs       c2764     10
    rhs       c2765     10
    rhs       c2766     230
    rhs       c2767     230
    rhs       c2768     210
    rhs       c2769     210
    rhs       c2770     10
    rhs       c2771     10
    rhs       c2772     230
    rhs       c2773     230
    rhs       c2774     210
    rhs       c2775     210
    rhs       c2776     10
    rhs       c2777     10
    rhs       c2778     230
    rhs       c2779     230
    rhs       c2780     210
    rhs       c2781     210
    rhs       c2782     10
    rhs       c2783     10
    rhs       c2784     230
    rhs       c2785     230
    rhs       c2786     210
    rhs       c2787     210
    rhs       c2788     10
    rhs       c2789     10
    rhs       c2790     230
    rhs       c2791     230
    rhs       c2792     130
    rhs       c2793     210
    rhs       c2794     13
    rhs       c2795     10
    rhs       c2796     230
    rhs       c2797     230
    rhs       c2798     130
    rhs       c2799     210
    rhs       c2800     13
    rhs       c2801     10
    rhs       c2802     230
    rhs       c2803     230
    rhs       c2804     130
    rhs       c2805     210
    rhs       c2806     13
    rhs       c2807     10
    rhs       c2808     230
    rhs       c2809     230
    rhs       c2810     130
    rhs       c2811     210
    rhs       c2812     13
    rhs       c2813     10
    rhs       c2814     230
    rhs       c2815     230
    rhs       c2816     130
    rhs       c2817     210
    rhs       c2818     13
    rhs       c2819     10
    rhs       c2820     230
    rhs       c2821     230
    rhs       c2822     130
    rhs       c2823     210
    rhs       c2824     13
    rhs       c2825     10
    rhs       c2826     230
    rhs       c2827     230
    rhs       c2828     130
    rhs       c2829     210
    rhs       c2830     13
    rhs       c2831     10
    rhs       c2832     230
    rhs       c2833     230
    rhs       c2834     130
    rhs       c2835     210
    rhs       c2836     13
    rhs       c2837     10
    rhs       c2838     230
    rhs       c2839     230
    rhs       c2840     130
    rhs       c2841     210
    rhs       c2842     13
    rhs       c2843     10
    rhs       c2844     230
    rhs       c2845     230
    rhs       c2846     130
    rhs       c2847     210
    rhs       c2848     13
    rhs       c2849     10
    rhs       c2850     230
    rhs       c2851     230
    rhs       c2852     210
    rhs       c2853     210
    rhs       c2854     10
    rhs       c2855     10
    rhs       c2856     230
    rhs       c2857     230
    rhs       c2858     210
    rhs       c2859     210
    rhs       c2860     10
    rhs       c2861     10
    rhs       c2862     230
    rhs       c2863     230
    rhs       c2864     210
    rhs       c2865     210
    rhs       c2866     10
    rhs       c2867     10
    rhs       c2868     230
    rhs       c2869     230
    rhs       c2870     210
    rhs       c2871     210
    rhs       c2872     10
    rhs       c2873     10
    rhs       c2874     230
    rhs       c2875     230
    rhs       c2876     210
    rhs       c2877     210
    rhs       c2878     10
    rhs       c2879     10
    rhs       c2880     230
    rhs       c2881     230
    rhs       c2882     130
    rhs       c2883     210
    rhs       c2884     13
    rhs       c2885     10
    rhs       c2886     230
    rhs       c2887     230
    rhs       c2888     130
    rhs       c2889     210
    rhs       c2890     13
    rhs       c2891     10
    rhs       c2892     230
    rhs       c2893     230
    rhs       c2894     130
    rhs       c2895     210
    rhs       c2896     13
    rhs       c2897     10
    rhs       c2898     230
    rhs       c2899     230
    rhs       c2900     130
    rhs       c2901     210
    rhs       c2902     13
    rhs       c2903     10
    rhs       c2904     230
    rhs       c2905     230
    rhs       c2906     130
    rhs       c2907     210
    rhs       c2908     13
    rhs       c2909     10
    rhs       c2910     230
    rhs       c2911     230
    rhs       c2912     130
    rhs       c2913     210
    rhs       c2914     13
    rhs       c2915     10
    rhs       c2916     230
    rhs       c2917     230
    rhs       c2918     130
    rhs       c2919     210
    rhs       c2920     13
    rhs       c2921     10
    rhs       c2922     230
    rhs       c2923     230
    rhs       c2924     130
    rhs       c2925     210
    rhs       c2926     13
    rhs       c2927     10
    rhs       c2928     230
    rhs       c2929     230
    rhs       c2930     130
    rhs       c2931     210
    rhs       c2932     13
    rhs       c2933     10
    rhs       c2934     230
    rhs       c2935     230
    rhs       c2936     130
    rhs       c2937     210
    rhs       c2938     13
    rhs       c2939     10
    rhs       c2940     230
    rhs       c2941     230
    rhs       c2942     210
    rhs       c2943     210
    rhs       c2944     10
    rhs       c2945     10
    rhs       c2946     230
    rhs       c2947     230
    rhs       c2948     210
    rhs       c2949     210
    rhs       c2950     10
    rhs       c2951     10
    rhs       c2952     230
    rhs       c2953     230
    rhs       c2954     210
    rhs       c2955     210
    rhs       c2956     10
    rhs       c2957     10
    rhs       c2958     230
    rhs       c2959     230
    rhs       c2960     210
    rhs       c2961     210
    rhs       c2962     10
    rhs       c2963     10
    rhs       c2964     230
    rhs       c2965     230
    rhs       c2966     130
    rhs       c2967     210
    rhs       c2968     13
    rhs       c2969     10
    rhs       c2970     230
    rhs       c2971     230
    rhs       c2972     130
    rhs       c2973     210
    rhs       c2974     13
    rhs       c2975     10
    rhs       c2976     230
    rhs       c2977     230
    rhs       c2978     130
    rhs       c2979     210
    rhs       c2980     13
    rhs       c2981     10
    rhs       c2982     230
    rhs       c2983     230
    rhs       c2984     130
    rhs       c2985     210
    rhs       c2986     13
    rhs       c2987     10
    rhs       c2988     230
    rhs       c2989     230
    rhs       c2990     130
    rhs       c2991     210
    rhs       c2992     13
    rhs       c2993     10
    rhs       c2994     230
    rhs       c2995     230
    rhs       c2996     130
    rhs       c2997     210
    rhs       c2998     13
    rhs       c2999     10
    rhs       c3000     230
    rhs       c3001     230
    rhs       c3002     130
    rhs       c3003     210
    rhs       c3004     13
    rhs       c3005     10
    rhs       c3006     230
    rhs       c3007     230
    rhs       c3008     130
    rhs       c3009     210
    rhs       c3010     13
    rhs       c3011     10
    rhs       c3012     230
    rhs       c3013     230
    rhs       c3014     130
    rhs       c3015     210
    rhs       c3016     13
    rhs       c3017     10
    rhs       c3018     230
    rhs       c3019     230
    rhs       c3020     130
    rhs       c3021     210
    rhs       c3022     13
    rhs       c3023     10
    rhs       c3024     230
    rhs       c3025     230
    rhs       c3026     210
    rhs       c3027     210
    rhs       c3028     10
    rhs       c3029     10
    rhs       c3030     230
    rhs       c3031     230
    rhs       c3032     210
    rhs       c3033     210
    rhs       c3034     10
    rhs       c3035     10
    rhs       c3036     230
    rhs       c3037     230
    rhs       c3038     210
    rhs       c3039     210
    rhs       c3040     10
    rhs       c3041     10
    rhs       c3042     230
    rhs       c3043     230
    rhs       c3044     130
    rhs       c3045     210
    rhs       c3046     13
    rhs       c3047     10
    rhs       c3048     230
    rhs       c3049     230
    rhs       c3050     130
    rhs       c3051     210
    rhs       c3052     13
    rhs       c3053     10
    rhs       c3054     230
    rhs       c3055     230
    rhs       c3056     130
    rhs       c3057     210
    rhs       c3058     13
    rhs       c3059     10
    rhs       c3060     230
    rhs       c3061     230
    rhs       c3062     130
    rhs       c3063     210
    rhs       c3064     13
    rhs       c3065     10
    rhs       c3066     230
    rhs       c3067     230
    rhs       c3068     130
    rhs       c3069     210
    rhs       c3070     13
    rhs       c3071     10
    rhs       c3072     230
    rhs       c3073     230
    rhs       c3074     130
    rhs       c3075     210
    rhs       c3076     13
    rhs       c3077     10
    rhs       c3078     230
    rhs       c3079     230
    rhs       c3080     130
    rhs       c3081     210
    rhs       c3082     13
    rhs       c3083     10
    rhs       c3084     230
    rhs       c3085     230
    rhs       c3086     130
    rhs       c3087     210
    rhs       c3088     13
    rhs       c3089     10
    rhs       c3090     230
    rhs       c3091     230
    rhs       c3092     130
    rhs       c3093     210
    rhs       c3094     13
    rhs       c3095     10
    rhs       c3096     230
    rhs       c3097     230
    rhs       c3098     130
    rhs       c3099     210
    rhs       c3100     13
    rhs       c3101     10
    rhs       c3102     230
    rhs       c3103     230
    rhs       c3104     210
    rhs       c3105     210
    rhs       c3106     10
    rhs       c3107     10
    rhs       c3108     230
    rhs       c3109     230
    rhs       c3110     210
    rhs       c3111     210
    rhs       c3112     10
    rhs       c3113     10
    rhs       c3114     230
    rhs       c3115     230
    rhs       c3116     130
    rhs       c3117     210
    rhs       c3118     13
    rhs       c3119     10
    rhs       c3120     230
    rhs       c3121     230
    rhs       c3122     130
    rhs       c3123     210
    rhs       c3124     13
    rhs       c3125     10
    rhs       c3126     230
    rhs       c3127     230
    rhs       c3128     130
    rhs       c3129     210
    rhs       c3130     13
    rhs       c3131     10
    rhs       c3132     230
    rhs       c3133     230
    rhs       c3134     130
    rhs       c3135     210
    rhs       c3136     13
    rhs       c3137     10
    rhs       c3138     230
    rhs       c3139     230
    rhs       c3140     130
    rhs       c3141     210
    rhs       c3142     13
    rhs       c3143     10
    rhs       c3144     230
    rhs       c3145     230
    rhs       c3146     130
    rhs       c3147     210
    rhs       c3148     13
    rhs       c3149     10
    rhs       c3150     230
    rhs       c3151     230
    rhs       c3152     130
    rhs       c3153     210
    rhs       c3154     13
    rhs       c3155     10
    rhs       c3156     230
    rhs       c3157     230
    rhs       c3158     130
    rhs       c3159     210
    rhs       c3160     13
    rhs       c3161     10
    rhs       c3162     230
    rhs       c3163     230
    rhs       c3164     130
    rhs       c3165     210
    rhs       c3166     13
    rhs       c3167     10
    rhs       c3168     230
    rhs       c3169     230
    rhs       c3170     130
    rhs       c3171     210
    rhs       c3172     13
    rhs       c3173     10
    rhs       c3174     230
    rhs       c3175     230
    rhs       c3176     210
    rhs       c3177     210
    rhs       c3178     10
    rhs       c3179     10
    rhs       c3180     230
    rhs       c3181     230
    rhs       c3182     130
    rhs       c3183     210
    rhs       c3184     13
    rhs       c3185     10
    rhs       c3186     230
    rhs       c3187     230
    rhs       c3188     130
    rhs       c3189     210
    rhs       c3190     13
    rhs       c3191     10
    rhs       c3192     230
    rhs       c3193     230
    rhs       c3194     130
    rhs       c3195     210
    rhs       c3196     13
    rhs       c3197     10
    rhs       c3198     230
    rhs       c3199     230
    rhs       c3200     130
    rhs       c3201     210
    rhs       c3202     13
    rhs       c3203     10
    rhs       c3204     230
    rhs       c3205     230
    rhs       c3206     130
    rhs       c3207     210
    rhs       c3208     13
    rhs       c3209     10
    rhs       c3210     230
    rhs       c3211     230
    rhs       c3212     130
    rhs       c3213     210
    rhs       c3214     13
    rhs       c3215     10
    rhs       c3216     230
    rhs       c3217     230
    rhs       c3218     130
    rhs       c3219     210
    rhs       c3220     13
    rhs       c3221     10
    rhs       c3222     230
    rhs       c3223     230
    rhs       c3224     130
    rhs       c3225     210
    rhs       c3226     13
    rhs       c3227     10
    rhs       c3228     230
    rhs       c3229     230
    rhs       c3230     130
    rhs       c3231     210
    rhs       c3232     13
    rhs       c3233     10
    rhs       c3234     230
    rhs       c3235     230
    rhs       c3236     130
    rhs       c3237     210
    rhs       c3238     13
    rhs       c3239     10
    rhs       c3240     230
    rhs       c3241     230
    rhs       c3242     130
    rhs       c3243     210
    rhs       c3244     13
    rhs       c3245     10
    rhs       c3246     230
    rhs       c3247     230
    rhs       c3248     130
    rhs       c3249     210
    rhs       c3250     13
    rhs       c3251     10
    rhs       c3252     230
    rhs       c3253     230
    rhs       c3254     130
    rhs       c3255     210
    rhs       c3256     13
    rhs       c3257     10
    rhs       c3258     230
    rhs       c3259     230
    rhs       c3260     130
    rhs       c3261     210
    rhs       c3262     13
    rhs       c3263     10
    rhs       c3264     230
    rhs       c3265     230
    rhs       c3266     130
    rhs       c3267     210
    rhs       c3268     13
    rhs       c3269     10
    rhs       c3270     230
    rhs       c3271     230
    rhs       c3272     130
    rhs       c3273     210
    rhs       c3274     13
    rhs       c3275     10
    rhs       c3276     230
    rhs       c3277     230
    rhs       c3278     130
    rhs       c3279     210
    rhs       c3280     13
    rhs       c3281     10
    rhs       c3282     230
    rhs       c3283     230
    rhs       c3284     130
    rhs       c3285     210
    rhs       c3286     13
    rhs       c3287     10
    rhs       c3288     230
    rhs       c3289     230
    rhs       c3290     130
    rhs       c3291     210
    rhs       c3292     13
    rhs       c3293     10
    rhs       c3294     230
    rhs       c3295     230
    rhs       c3296     130
    rhs       c3297     210
    rhs       c3298     13
    rhs       c3299     10
    rhs       c3300     230
    rhs       c3301     230
    rhs       c3302     130
    rhs       c3303     130
    rhs       c3304     13
    rhs       c3305     13
    rhs       c3306     230
    rhs       c3307     230
    rhs       c3308     130
    rhs       c3309     130
    rhs       c3310     13
    rhs       c3311     13
    rhs       c3312     230
    rhs       c3313     230
    rhs       c3314     130
    rhs       c3315     130
    rhs       c3316     13
    rhs       c3317     13
    rhs       c3318     230
    rhs       c3319     230
    rhs       c3320     130
    rhs       c3321     130
    rhs       c3322     13
    rhs       c3323     13
    rhs       c3324     230
    rhs       c3325     230
    rhs       c3326     130
    rhs       c3327     130
    rhs       c3328     13
    rhs       c3329     13
    rhs       c3330     230
    rhs       c3331     230
    rhs       c3332     130
    rhs       c3333     130
    rhs       c3334     13
    rhs       c3335     13
    rhs       c3336     230
    rhs       c3337     230
    rhs       c3338     130
    rhs       c3339     130
    rhs       c3340     13
    rhs       c3341     13
    rhs       c3342     230
    rhs       c3343     230
    rhs       c3344     130
    rhs       c3345     130
    rhs       c3346     13
    rhs       c3347     13
    rhs       c3348     230
    rhs       c3349     230
    rhs       c3350     130
    rhs       c3351     130
    rhs       c3352     13
    rhs       c3353     13
    rhs       c3354     230
    rhs       c3355     230
    rhs       c3356     130
    rhs       c3357     130
    rhs       c3358     13
    rhs       c3359     13
    rhs       c3360     230
    rhs       c3361     230
    rhs       c3362     130
    rhs       c3363     130
    rhs       c3364     13
    rhs       c3365     13
    rhs       c3366     230
    rhs       c3367     230
    rhs       c3368     130
    rhs       c3369     130
    rhs       c3370     13
    rhs       c3371     13
    rhs       c3372     230
    rhs       c3373     230
    rhs       c3374     130
    rhs       c3375     130
    rhs       c3376     13
    rhs       c3377     13
    rhs       c3378     230
    rhs       c3379     230
    rhs       c3380     130
    rhs       c3381     130
    rhs       c3382     13
    rhs       c3383     13
    rhs       c3384     230
    rhs       c3385     230
    rhs       c3386     130
    rhs       c3387     130
    rhs       c3388     13
    rhs       c3389     13
    rhs       c3390     230
    rhs       c3391     230
    rhs       c3392     130
    rhs       c3393     130
    rhs       c3394     13
    rhs       c3395     13
    rhs       c3396     230
    rhs       c3397     230
    rhs       c3398     130
    rhs       c3399     130
    rhs       c3400     13
    rhs       c3401     13
    rhs       c3402     230
    rhs       c3403     230
    rhs       c3404     130
    rhs       c3405     130
    rhs       c3406     13
    rhs       c3407     13
    rhs       c3408     230
    rhs       c3409     230
    rhs       c3410     130
    rhs       c3411     130
    rhs       c3412     13
    rhs       c3413     13
    rhs       c3414     230
    rhs       c3415     230
    rhs       c3416     130
    rhs       c3417     130
    rhs       c3418     13
    rhs       c3419     13
    rhs       c3420     230
    rhs       c3421     230
    rhs       c3422     130
    rhs       c3423     130
    rhs       c3424     13
    rhs       c3425     13
    rhs       c3426     230
    rhs       c3427     230
    rhs       c3428     130
    rhs       c3429     130
    rhs       c3430     13
    rhs       c3431     13
    rhs       c3432     230
    rhs       c3433     230
    rhs       c3434     130
    rhs       c3435     130
    rhs       c3436     13
    rhs       c3437     13
    rhs       c3438     230
    rhs       c3439     230
    rhs       c3440     130
    rhs       c3441     130
    rhs       c3442     13
    rhs       c3443     13
    rhs       c3444     230
    rhs       c3445     230
    rhs       c3446     130
    rhs       c3447     130
    rhs       c3448     13
    rhs       c3449     13
    rhs       c3450     230
    rhs       c3451     230
    rhs       c3452     130
    rhs       c3453     130
    rhs       c3454     13
    rhs       c3455     13
    rhs       c3456     230
    rhs       c3457     230
    rhs       c3458     130
    rhs       c3459     130
    rhs       c3460     13
    rhs       c3461     13
    rhs       c3462     230
    rhs       c3463     230
    rhs       c3464     130
    rhs       c3465     130
    rhs       c3466     13
    rhs       c3467     13
    rhs       c3468     230
    rhs       c3469     230
    rhs       c3470     130
    rhs       c3471     130
    rhs       c3472     13
    rhs       c3473     13
    rhs       c3474     230
    rhs       c3475     230
    rhs       c3476     130
    rhs       c3477     130
    rhs       c3478     13
    rhs       c3479     13
    rhs       c3480     230
    rhs       c3481     230
    rhs       c3482     130
    rhs       c3483     130
    rhs       c3484     13
    rhs       c3485     13
    rhs       c3486     230
    rhs       c3487     230
    rhs       c3488     130
    rhs       c3489     130
    rhs       c3490     13
    rhs       c3491     13
    rhs       c3492     230
    rhs       c3493     230
    rhs       c3494     130
    rhs       c3495     130
    rhs       c3496     13
    rhs       c3497     13
    rhs       c3498     230
    rhs       c3499     230
    rhs       c3500     130
    rhs       c3501     130
    rhs       c3502     13
    rhs       c3503     13
    rhs       c3504     230
    rhs       c3505     230
    rhs       c3506     130
    rhs       c3507     130
    rhs       c3508     13
    rhs       c3509     13
    rhs       c3510     230
    rhs       c3511     230
    rhs       c3512     130
    rhs       c3513     130
    rhs       c3514     13
    rhs       c3515     13
    rhs       c3516     230
    rhs       c3517     230
    rhs       c3518     130
    rhs       c3519     130
    rhs       c3520     13
    rhs       c3521     13
    rhs       c3522     230
    rhs       c3523     230
    rhs       c3524     130
    rhs       c3525     130
    rhs       c3526     13
    rhs       c3527     13
    rhs       c3528     230
    rhs       c3529     230
    rhs       c3530     130
    rhs       c3531     130
    rhs       c3532     13
    rhs       c3533     13
    rhs       c3534     230
    rhs       c3535     230
    rhs       c3536     130
    rhs       c3537     130
    rhs       c3538     13
    rhs       c3539     13
    rhs       c3540     230
    rhs       c3541     230
    rhs       c3542     130
    rhs       c3543     130
    rhs       c3544     13
    rhs       c3545     13
    rhs       c3546     230
    rhs       c3547     230
    rhs       c3548     130
    rhs       c3549     130
    rhs       c3550     13
    rhs       c3551     13
    rhs       c3552     230
    rhs       c3553     230
    rhs       c3554     130
    rhs       c3555     130
    rhs       c3556     13
    rhs       c3557     13
    rhs       c3558     230
    rhs       c3559     230
    rhs       c3560     130
    rhs       c3561     130
    rhs       c3562     13
    rhs       c3563     13
    rhs       c3564     230
    rhs       c3565     230
    rhs       c3566     130
    rhs       c3567     130
    rhs       c3568     13
    rhs       c3569     13
    rhs       c3570     230
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
RANGES
BOUNDS
 BV bounds    x[1]
 BV bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 LO bounds    x[36]     0
 UP bounds    x[36]     223
 LO bounds    x[37]     0
 UP bounds    x[37]     223
 LO bounds    x[38]     0
 UP bounds    x[38]     223
 LO bounds    x[39]     0
 UP bounds    x[39]     223
 LO bounds    x[40]     0
 UP bounds    x[40]     223
 LO bounds    x[41]     0
 UP bounds    x[41]     150
 LO bounds    x[42]     0
 UP bounds    x[42]     150
 LO bounds    x[43]     0
 UP bounds    x[43]     150
 LO bounds    x[44]     0
 UP bounds    x[44]     150
 LO bounds    x[45]     0
 UP bounds    x[45]     150
 LO bounds    x[46]     0
 UP bounds    x[46]     150
 LO bounds    x[47]     0
 UP bounds    x[47]     150
 LO bounds    x[48]     0
 UP bounds    x[48]     150
 LO bounds    x[49]     0
 UP bounds    x[49]     150
 LO bounds    x[50]     0
 UP bounds    x[50]     150
 LO bounds    x[51]     0
 UP bounds    x[51]     150
 LO bounds    x[52]     0
 UP bounds    x[52]     150
 LO bounds    x[53]     0
 UP bounds    x[53]     150
 LO bounds    x[54]     0
 UP bounds    x[54]     150
 LO bounds    x[55]     0
 UP bounds    x[55]     150
 LO bounds    x[56]     0
 UP bounds    x[56]     150
 LO bounds    x[57]     0
 UP bounds    x[57]     150
 LO bounds    x[58]     0
 UP bounds    x[58]     150
 LO bounds    x[59]     0
 UP bounds    x[59]     150
 LO bounds    x[60]     0
 UP bounds    x[60]     150
 LO bounds    x[61]     0
 UP bounds    x[61]     230
 LO bounds    x[62]     0
 UP bounds    x[62]     230
 LO bounds    x[63]     0
 UP bounds    x[63]     230
 LO bounds    x[64]     0
 UP bounds    x[64]     230
 LO bounds    x[65]     0
 UP bounds    x[65]     230
 LO bounds    x[66]     0
 UP bounds    x[66]     230
 LO bounds    x[67]     0
 UP bounds    x[67]     230
 LO bounds    x[68]     0
 UP bounds    x[68]     230
 LO bounds    x[69]     0
 UP bounds    x[69]     230
 LO bounds    x[70]     0
 UP bounds    x[70]     230
 LO bounds    x[71]     0
 UP bounds    x[71]     85
 LO bounds    x[72]     0
 UP bounds    x[72]     85
 LO bounds    x[73]     0
 UP bounds    x[73]     85
 LO bounds    x[74]     0
 UP bounds    x[74]     85
 LO bounds    x[75]     0
 UP bounds    x[75]     85
 LO bounds    x[76]     0
 UP bounds    x[76]     90
 LO bounds    x[77]     0
 UP bounds    x[77]     90
 LO bounds    x[78]     0
 UP bounds    x[78]     90
 LO bounds    x[79]     0
 UP bounds    x[79]     90
 LO bounds    x[80]     0
 UP bounds    x[80]     90
 LO bounds    x[81]     0
 UP bounds    x[81]     90
 LO bounds    x[82]     0
 UP bounds    x[82]     90
 LO bounds    x[83]     0
 UP bounds    x[83]     90
 LO bounds    x[84]     0
 UP bounds    x[84]     90
 LO bounds    x[85]     0
 UP bounds    x[85]     90
 LO bounds    x[86]     0
 UP bounds    x[86]     90
 LO bounds    x[87]     0
 UP bounds    x[87]     90
 LO bounds    x[88]     0
 UP bounds    x[88]     90
 LO bounds    x[89]     0
 UP bounds    x[89]     90
 LO bounds    x[90]     0
 UP bounds    x[90]     90
 LO bounds    x[91]     0
 UP bounds    x[91]     90
 LO bounds    x[92]     0
 UP bounds    x[92]     90
 LO bounds    x[93]     0
 UP bounds    x[93]     90
 LO bounds    x[94]     0
 UP bounds    x[94]     90
 LO bounds    x[95]     0
 UP bounds    x[95]     90
 LO bounds    x[96]     0
 UP bounds    x[96]     87
 LO bounds    x[97]     0
 UP bounds    x[97]     87
 LO bounds    x[98]     0
 UP bounds    x[98]     87
 LO bounds    x[99]     0
 UP bounds    x[99]     87
 LO bounds    x[100]    0
 UP bounds    x[100]    87
 LO bounds    x[101]    0
 UP bounds    x[101]    87
 LO bounds    x[102]    0
 UP bounds    x[102]    87
 LO bounds    x[103]    0
 UP bounds    x[103]    87
 LO bounds    x[104]    0
 UP bounds    x[104]    87
 LO bounds    x[105]    0
 UP bounds    x[105]    87
 LO bounds    x[106]    0
 UP bounds    x[106]    423
 LO bounds    x[107]    0
 UP bounds    x[107]    423
 LO bounds    x[108]    0
 UP bounds    x[108]    423
 LO bounds    x[109]    0
 UP bounds    x[109]    423
 LO bounds    x[110]    0
 UP bounds    x[110]    423
 LO bounds    x[111]    0
 UP bounds    x[111]    350
 LO bounds    x[112]    0
 UP bounds    x[112]    350
 LO bounds    x[113]    0
 UP bounds    x[113]    350
 LO bounds    x[114]    0
 UP bounds    x[114]    350
 LO bounds    x[115]    0
 UP bounds    x[115]    350
 LO bounds    x[116]    0
 UP bounds    x[116]    350
 LO bounds    x[117]    0
 UP bounds    x[117]    350
 LO bounds    x[118]    0
 UP bounds    x[118]    350
 LO bounds    x[119]    0
 UP bounds    x[119]    350
 LO bounds    x[120]    0
 UP bounds    x[120]    350
 LO bounds    x[121]    0
 UP bounds    x[121]    350
 LO bounds    x[122]    0
 UP bounds    x[122]    350
 LO bounds    x[123]    0
 UP bounds    x[123]    350
 LO bounds    x[124]    0
 UP bounds    x[124]    350
 LO bounds    x[125]    0
 UP bounds    x[125]    350
 LO bounds    x[126]    0
 UP bounds    x[126]    350
 LO bounds    x[127]    0
 UP bounds    x[127]    350
 LO bounds    x[128]    0
 UP bounds    x[128]    350
 LO bounds    x[129]    0
 UP bounds    x[129]    350
 LO bounds    x[130]    0
 UP bounds    x[130]    350
 LO bounds    x[131]    0
 UP bounds    x[131]    430
 LO bounds    x[132]    0
 UP bounds    x[132]    430
 LO bounds    x[133]    0
 UP bounds    x[133]    430
 LO bounds    x[134]    0
 UP bounds    x[134]    430
 LO bounds    x[135]    0
 UP bounds    x[135]    430
 LO bounds    x[136]    0
 UP bounds    x[136]    430
 LO bounds    x[137]    0
 UP bounds    x[137]    430
 LO bounds    x[138]    0
 UP bounds    x[138]    430
 LO bounds    x[139]    0
 UP bounds    x[139]    430
 LO bounds    x[140]    0
 UP bounds    x[140]    430
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 BV bounds    x[168]
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 BV bounds    x[178]
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 BV bounds    x[182]
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 BV bounds    x[188]
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 BV bounds    x[198]
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 BV bounds    x[248]
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 BV bounds    x[260]
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 BV bounds    x[272]
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 BV bounds    x[284]
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 BV bounds    x[332]
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 BV bounds    x[341]
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 BV bounds    x[369]
 BV bounds    x[370]
 BV bounds    x[371]
 BV bounds    x[372]
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 BV bounds    x[411]
 BV bounds    x[412]
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 BV bounds    x[422]
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 BV bounds    x[457]
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 BV bounds    x[461]
 BV bounds    x[462]
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 BV bounds    x[467]
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 BV bounds    x[499]
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 BV bounds    x[510]
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 BV bounds    x[552]
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 BV bounds    x[588]
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 BV bounds    x[640]
 BV bounds    x[641]
 BV bounds    x[642]
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 BV bounds    x[668]
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 BV bounds    x[712]
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 BV bounds    x[722]
 BV bounds    x[723]
 BV bounds    x[724]
 BV bounds    x[725]
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 BV bounds    x[736]
 BV bounds    x[737]
 BV bounds    x[738]
 BV bounds    x[739]
 BV bounds    x[740]
 BV bounds    x[741]
 BV bounds    x[742]
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 BV bounds    x[816]
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 BV bounds    x[822]
 BV bounds    x[823]
 BV bounds    x[824]
 BV bounds    x[825]
 BV bounds    x[826]
 BV bounds    x[827]
 BV bounds    x[828]
 BV bounds    x[829]
 BV bounds    x[830]
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 BV bounds    x[904]
 BV bounds    x[905]
 BV bounds    x[906]
 BV bounds    x[907]
 BV bounds    x[908]
 BV bounds    x[909]
 BV bounds    x[910]
 BV bounds    x[911]
 BV bounds    x[912]
 BV bounds    x[913]
 BV bounds    x[914]
 BV bounds    x[915]
 BV bounds    x[916]
 BV bounds    x[917]
 BV bounds    x[918]
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 BV bounds    x[989]
 BV bounds    x[990]
 BV bounds    x[991]
 BV bounds    x[992]
 BV bounds    x[993]
 BV bounds    x[994]
 BV bounds    x[995]
 BV bounds    x[996]
 BV bounds    x[997]
 BV bounds    x[998]
 BV bounds    x[999]
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 BV bounds    x[1003]
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 BV bounds    x[1017]
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 BV bounds    x[1071]
 BV bounds    x[1072]
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 BV bounds    x[1082]
 BV bounds    x[1083]
 BV bounds    x[1084]
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 BV bounds    x[1096]
 BV bounds    x[1097]
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 FX bounds    x[1101]   1
 FX bounds    x[1102]   1
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 FX bounds    x[1107]   1
 FX bounds    x[1108]   1
 BV bounds    x[1109]
 BV bounds    x[1110]
 BV bounds    x[1111]
 BV bounds    x[1112]
 FX bounds    x[1113]   1
 FX bounds    x[1114]   1
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 FX bounds    x[1119]   1
 FX bounds    x[1120]   1
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 FX bounds    x[1125]   1
 FX bounds    x[1126]   1
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 FX bounds    x[1131]   1
 FX bounds    x[1132]   1
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 FX bounds    x[1137]   1
 FX bounds    x[1138]   1
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 FX bounds    x[1143]   1
 FX bounds    x[1144]   1
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 FX bounds    x[1149]   1
 FX bounds    x[1150]   1
 BV bounds    x[1151]
 BV bounds    x[1152]
 BV bounds    x[1153]
 BV bounds    x[1154]
 FX bounds    x[1155]   1
 FX bounds    x[1156]   1
 BV bounds    x[1157]
 BV bounds    x[1158]
 BV bounds    x[1159]
 BV bounds    x[1160]
 FX bounds    x[1161]   1
 FX bounds    x[1162]   1
 BV bounds    x[1163]
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 FX bounds    x[1167]   1
 FX bounds    x[1168]   1
 BV bounds    x[1169]
 BV bounds    x[1170]
 BV bounds    x[1171]
 BV bounds    x[1172]
 FX bounds    x[1173]   1
 FX bounds    x[1174]   1
 BV bounds    x[1175]
 BV bounds    x[1176]
 BV bounds    x[1177]
 BV bounds    x[1178]
 FX bounds    x[1179]   1
 FX bounds    x[1180]   1
 BV bounds    x[1181]
 BV bounds    x[1182]
 BV bounds    x[1183]
 BV bounds    x[1184]
 FX bounds    x[1185]   1
 FX bounds    x[1186]   1
 BV bounds    x[1187]
 BV bounds    x[1188]
 BV bounds    x[1189]
 BV bounds    x[1190]
 FX bounds    x[1191]   1
 FX bounds    x[1192]   1
 BV bounds    x[1193]
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 FX bounds    x[1197]   1
 FX bounds    x[1198]   1
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 FX bounds    x[1203]   1
 FX bounds    x[1204]   1
 BV bounds    x[1205]
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 FX bounds    x[1209]   1
 FX bounds    x[1210]   1
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 BV bounds    x[1217]
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 BV bounds    x[1229]
 BV bounds    x[1230]
 BV bounds    x[1231]
 BV bounds    x[1232]
 BV bounds    x[1233]
 BV bounds    x[1234]
 BV bounds    x[1235]
 BV bounds    x[1236]
 BV bounds    x[1237]
 BV bounds    x[1238]
 BV bounds    x[1239]
 BV bounds    x[1240]
 BV bounds    x[1241]
 BV bounds    x[1242]
 BV bounds    x[1243]
 BV bounds    x[1244]
 BV bounds    x[1245]
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 BV bounds    x[1249]
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 BV bounds    x[1260]
 BV bounds    x[1261]
 BV bounds    x[1262]
 BV bounds    x[1263]
 BV bounds    x[1264]
 BV bounds    x[1265]
 BV bounds    x[1266]
 BV bounds    x[1267]
 BV bounds    x[1268]
 BV bounds    x[1269]
 BV bounds    x[1270]
 BV bounds    x[1271]
 BV bounds    x[1272]
 BV bounds    x[1273]
 BV bounds    x[1274]
 FX bounds    x[1275]   1
 FX bounds    x[1276]   1
 BV bounds    x[1277]
 BV bounds    x[1278]
 BV bounds    x[1279]
 BV bounds    x[1280]
 FX bounds    x[1281]   1
 FX bounds    x[1282]   1
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 FX bounds    x[1287]   1
 FX bounds    x[1288]   1
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 FX bounds    x[1293]   1
 FX bounds    x[1294]   1
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 FX bounds    x[1299]   1
 FX bounds    x[1300]   1
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 FX bounds    x[1305]   1
 FX bounds    x[1306]   1
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 FX bounds    x[1311]   1
 FX bounds    x[1312]   1
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 FX bounds    x[1317]   1
 FX bounds    x[1318]   1
 BV bounds    x[1319]
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 FX bounds    x[1323]   1
 FX bounds    x[1324]   1
 BV bounds    x[1325]
 BV bounds    x[1326]
 BV bounds    x[1327]
 BV bounds    x[1328]
 FX bounds    x[1329]   1
 FX bounds    x[1330]   1
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 FX bounds    x[1335]   1
 FX bounds    x[1336]   1
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 FX bounds    x[1341]   1
 FX bounds    x[1342]   1
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 FX bounds    x[1347]   1
 FX bounds    x[1348]   1
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 FX bounds    x[1353]   1
 FX bounds    x[1354]   1
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 FX bounds    x[1359]   1
 FX bounds    x[1360]   1
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 BV bounds    x[1364]
 FX bounds    x[1365]   1
 FX bounds    x[1366]   1
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 FX bounds    x[1371]   1
 FX bounds    x[1372]   1
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 FX bounds    x[1377]   1
 FX bounds    x[1378]   1
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 BV bounds    x[1401]
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 BV bounds    x[1409]
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 BV bounds    x[1442]
 FX bounds    x[1443]   1
 FX bounds    x[1444]   1
 BV bounds    x[1445]
 BV bounds    x[1446]
 BV bounds    x[1447]
 BV bounds    x[1448]
 FX bounds    x[1449]   1
 FX bounds    x[1450]   1
 BV bounds    x[1451]
 BV bounds    x[1452]
 BV bounds    x[1453]
 BV bounds    x[1454]
 FX bounds    x[1455]   1
 FX bounds    x[1456]   1
 BV bounds    x[1457]
 BV bounds    x[1458]
 BV bounds    x[1459]
 BV bounds    x[1460]
 FX bounds    x[1461]   1
 FX bounds    x[1462]   1
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 FX bounds    x[1467]   1
 FX bounds    x[1468]   1
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 FX bounds    x[1473]   1
 FX bounds    x[1474]   1
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 BV bounds    x[1478]
 FX bounds    x[1479]   1
 FX bounds    x[1480]   1
 BV bounds    x[1481]
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 FX bounds    x[1485]   1
 FX bounds    x[1486]   1
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 FX bounds    x[1491]   1
 FX bounds    x[1492]   1
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 FX bounds    x[1497]   1
 FX bounds    x[1498]   1
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 FX bounds    x[1503]   1
 FX bounds    x[1504]   1
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 FX bounds    x[1509]   1
 FX bounds    x[1510]   1
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 FX bounds    x[1515]   1
 FX bounds    x[1516]   1
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 FX bounds    x[1521]   1
 FX bounds    x[1522]   1
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 FX bounds    x[1527]   1
 FX bounds    x[1528]   1
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 BV bounds    x[1532]
 FX bounds    x[1533]   1
 FX bounds    x[1534]   1
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 FX bounds    x[1539]   1
 FX bounds    x[1540]   1
 BV bounds    x[1541]
 BV bounds    x[1542]
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 BV bounds    x[1550]
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 BV bounds    x[1566]
 BV bounds    x[1567]
 BV bounds    x[1568]
 BV bounds    x[1569]
 BV bounds    x[1570]
 BV bounds    x[1571]
 BV bounds    x[1572]
 BV bounds    x[1573]
 BV bounds    x[1574]
 BV bounds    x[1575]
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 BV bounds    x[1580]
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 BV bounds    x[1586]
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 BV bounds    x[1592]
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 BV bounds    x[1599]
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 FX bounds    x[1605]   1
 FX bounds    x[1606]   1
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 FX bounds    x[1611]   1
 FX bounds    x[1612]   1
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 BV bounds    x[1616]
 FX bounds    x[1617]   1
 FX bounds    x[1618]   1
 BV bounds    x[1619]
 BV bounds    x[1620]
 BV bounds    x[1621]
 BV bounds    x[1622]
 FX bounds    x[1623]   1
 FX bounds    x[1624]   1
 BV bounds    x[1625]
 BV bounds    x[1626]
 BV bounds    x[1627]
 BV bounds    x[1628]
 FX bounds    x[1629]   1
 FX bounds    x[1630]   1
 BV bounds    x[1631]
 BV bounds    x[1632]
 BV bounds    x[1633]
 BV bounds    x[1634]
 FX bounds    x[1635]   1
 FX bounds    x[1636]   1
 BV bounds    x[1637]
 BV bounds    x[1638]
 BV bounds    x[1639]
 BV bounds    x[1640]
 FX bounds    x[1641]   1
 FX bounds    x[1642]   1
 BV bounds    x[1643]
 BV bounds    x[1644]
 BV bounds    x[1645]
 BV bounds    x[1646]
 FX bounds    x[1647]   1
 FX bounds    x[1648]   1
 BV bounds    x[1649]
 BV bounds    x[1650]
 BV bounds    x[1651]
 BV bounds    x[1652]
 FX bounds    x[1653]   1
 FX bounds    x[1654]   1
 BV bounds    x[1655]
 BV bounds    x[1656]
 BV bounds    x[1657]
 BV bounds    x[1658]
 FX bounds    x[1659]   1
 FX bounds    x[1660]   1
 BV bounds    x[1661]
 BV bounds    x[1662]
 BV bounds    x[1663]
 BV bounds    x[1664]
 FX bounds    x[1665]   1
 FX bounds    x[1666]   1
 BV bounds    x[1667]
 BV bounds    x[1668]
 BV bounds    x[1669]
 BV bounds    x[1670]
 FX bounds    x[1671]   1
 FX bounds    x[1672]   1
 BV bounds    x[1673]
 BV bounds    x[1674]
 BV bounds    x[1675]
 BV bounds    x[1676]
 FX bounds    x[1677]   1
 FX bounds    x[1678]   1
 BV bounds    x[1679]
 BV bounds    x[1680]
 BV bounds    x[1681]
 BV bounds    x[1682]
 FX bounds    x[1683]   1
 FX bounds    x[1684]   1
 BV bounds    x[1685]
 BV bounds    x[1686]
 BV bounds    x[1687]
 BV bounds    x[1688]
 FX bounds    x[1689]   1
 FX bounds    x[1690]   1
 BV bounds    x[1691]
 BV bounds    x[1692]
 BV bounds    x[1693]
 BV bounds    x[1694]
 FX bounds    x[1695]   1
 FX bounds    x[1696]   1
 BV bounds    x[1697]
 BV bounds    x[1698]
 BV bounds    x[1699]
 BV bounds    x[1700]
 BV bounds    x[1701]
 BV bounds    x[1702]
 BV bounds    x[1703]
 BV bounds    x[1704]
 BV bounds    x[1705]
 BV bounds    x[1706]
 BV bounds    x[1707]
 BV bounds    x[1708]
 BV bounds    x[1709]
 BV bounds    x[1710]
 BV bounds    x[1711]
 BV bounds    x[1712]
 BV bounds    x[1713]
 BV bounds    x[1714]
 BV bounds    x[1715]
 BV bounds    x[1716]
 BV bounds    x[1717]
 BV bounds    x[1718]
 BV bounds    x[1719]
 BV bounds    x[1720]
 BV bounds    x[1721]
 BV bounds    x[1722]
 BV bounds    x[1723]
 BV bounds    x[1724]
 BV bounds    x[1725]
 BV bounds    x[1726]
 BV bounds    x[1727]
 BV bounds    x[1728]
 BV bounds    x[1729]
 BV bounds    x[1730]
 BV bounds    x[1731]
 BV bounds    x[1732]
 BV bounds    x[1733]
 BV bounds    x[1734]
 BV bounds    x[1735]
 BV bounds    x[1736]
 BV bounds    x[1737]
 BV bounds    x[1738]
 BV bounds    x[1739]
 BV bounds    x[1740]
 BV bounds    x[1741]
 BV bounds    x[1742]
 BV bounds    x[1743]
 BV bounds    x[1744]
 BV bounds    x[1745]
 BV bounds    x[1746]
 BV bounds    x[1747]
 BV bounds    x[1748]
 BV bounds    x[1749]
 BV bounds    x[1750]
 BV bounds    x[1751]
 BV bounds    x[1752]
 BV bounds    x[1753]
 BV bounds    x[1754]
 BV bounds    x[1755]
 BV bounds    x[1756]
 BV bounds    x[1757]
 BV bounds    x[1758]
 BV bounds    x[1759]
 BV bounds    x[1760]
 FX bounds    x[1761]   1
 FX bounds    x[1762]   1
 BV bounds    x[1763]
 BV bounds    x[1764]
 BV bounds    x[1765]
 BV bounds    x[1766]
 FX bounds    x[1767]   1
 FX bounds    x[1768]   1
 BV bounds    x[1769]
 BV bounds    x[1770]
 BV bounds    x[1771]
 BV bounds    x[1772]
 FX bounds    x[1773]   1
 FX bounds    x[1774]   1
 BV bounds    x[1775]
 BV bounds    x[1776]
 BV bounds    x[1777]
 BV bounds    x[1778]
 FX bounds    x[1779]   1
 FX bounds    x[1780]   1
 BV bounds    x[1781]
 BV bounds    x[1782]
 BV bounds    x[1783]
 BV bounds    x[1784]
 FX bounds    x[1785]   1
 FX bounds    x[1786]   1
 BV bounds    x[1787]
 BV bounds    x[1788]
 BV bounds    x[1789]
 BV bounds    x[1790]
 FX bounds    x[1791]   1
 FX bounds    x[1792]   1
 BV bounds    x[1793]
 BV bounds    x[1794]
 BV bounds    x[1795]
 BV bounds    x[1796]
 FX bounds    x[1797]   1
 FX bounds    x[1798]   1
 BV bounds    x[1799]
 BV bounds    x[1800]
 BV bounds    x[1801]
 BV bounds    x[1802]
 FX bounds    x[1803]   1
 FX bounds    x[1804]   1
 BV bounds    x[1805]
 BV bounds    x[1806]
 BV bounds    x[1807]
 BV bounds    x[1808]
 FX bounds    x[1809]   1
 FX bounds    x[1810]   1
 BV bounds    x[1811]
 BV bounds    x[1812]
 BV bounds    x[1813]
 BV bounds    x[1814]
 FX bounds    x[1815]   1
 FX bounds    x[1816]   1
 BV bounds    x[1817]
 BV bounds    x[1818]
 BV bounds    x[1819]
 BV bounds    x[1820]
 FX bounds    x[1821]   1
 FX bounds    x[1822]   1
 BV bounds    x[1823]
 BV bounds    x[1824]
 BV bounds    x[1825]
 BV bounds    x[1826]
 FX bounds    x[1827]   1
 FX bounds    x[1828]   1
 BV bounds    x[1829]
 BV bounds    x[1830]
 BV bounds    x[1831]
 BV bounds    x[1832]
 FX bounds    x[1833]   1
 FX bounds    x[1834]   1
 BV bounds    x[1835]
 BV bounds    x[1836]
 BV bounds    x[1837]
 BV bounds    x[1838]
 FX bounds    x[1839]   1
 FX bounds    x[1840]   1
 BV bounds    x[1841]
 BV bounds    x[1842]
 BV bounds    x[1843]
 BV bounds    x[1844]
 FX bounds    x[1845]   1
 FX bounds    x[1846]   1
 BV bounds    x[1847]
 BV bounds    x[1848]
 BV bounds    x[1849]
 BV bounds    x[1850]
 BV bounds    x[1851]
 BV bounds    x[1852]
 BV bounds    x[1853]
 BV bounds    x[1854]
 BV bounds    x[1855]
 BV bounds    x[1856]
 BV bounds    x[1857]
 BV bounds    x[1858]
 BV bounds    x[1859]
 BV bounds    x[1860]
 BV bounds    x[1861]
 BV bounds    x[1862]
 BV bounds    x[1863]
 BV bounds    x[1864]
 BV bounds    x[1865]
 BV bounds    x[1866]
 BV bounds    x[1867]
 BV bounds    x[1868]
 BV bounds    x[1869]
 BV bounds    x[1870]
 BV bounds    x[1871]
 BV bounds    x[1872]
 BV bounds    x[1873]
 BV bounds    x[1874]
 BV bounds    x[1875]
 BV bounds    x[1876]
 BV bounds    x[1877]
 BV bounds    x[1878]
 BV bounds    x[1879]
 BV bounds    x[1880]
 BV bounds    x[1881]
 BV bounds    x[1882]
 BV bounds    x[1883]
 BV bounds    x[1884]
 BV bounds    x[1885]
 BV bounds    x[1886]
 BV bounds    x[1887]
 BV bounds    x[1888]
 BV bounds    x[1889]
 BV bounds    x[1890]
 BV bounds    x[1891]
 BV bounds    x[1892]
 BV bounds    x[1893]
 BV bounds    x[1894]
 BV bounds    x[1895]
 BV bounds    x[1896]
 BV bounds    x[1897]
 BV bounds    x[1898]
 BV bounds    x[1899]
 BV bounds    x[1900]
 BV bounds    x[1901]
 BV bounds    x[1902]
 BV bounds    x[1903]
 BV bounds    x[1904]
 BV bounds    x[1905]
 BV bounds    x[1906]
 BV bounds    x[1907]
 BV bounds    x[1908]
 BV bounds    x[1909]
 BV bounds    x[1910]
 FX bounds    x[1911]   1
 FX bounds    x[1912]   1
 BV bounds    x[1913]
 BV bounds    x[1914]
 BV bounds    x[1915]
 BV bounds    x[1916]
 FX bounds    x[1917]   1
 FX bounds    x[1918]   1
 BV bounds    x[1919]
 BV bounds    x[1920]
 BV bounds    x[1921]
 BV bounds    x[1922]
 FX bounds    x[1923]   1
 FX bounds    x[1924]   1
 BV bounds    x[1925]
 BV bounds    x[1926]
 BV bounds    x[1927]
 BV bounds    x[1928]
 FX bounds    x[1929]   1
 FX bounds    x[1930]   1
 BV bounds    x[1931]
 BV bounds    x[1932]
 BV bounds    x[1933]
 BV bounds    x[1934]
 FX bounds    x[1935]   1
 FX bounds    x[1936]   1
 BV bounds    x[1937]
 BV bounds    x[1938]
 BV bounds    x[1939]
 BV bounds    x[1940]
 FX bounds    x[1941]   1
 FX bounds    x[1942]   1
 BV bounds    x[1943]
 BV bounds    x[1944]
 BV bounds    x[1945]
 BV bounds    x[1946]
 FX bounds    x[1947]   1
 FX bounds    x[1948]   1
 BV bounds    x[1949]
 BV bounds    x[1950]
 BV bounds    x[1951]
 BV bounds    x[1952]
 FX bounds    x[1953]   1
 FX bounds    x[1954]   1
 BV bounds    x[1955]
 BV bounds    x[1956]
 BV bounds    x[1957]
 BV bounds    x[1958]
 FX bounds    x[1959]   1
 FX bounds    x[1960]   1
 BV bounds    x[1961]
 BV bounds    x[1962]
 BV bounds    x[1963]
 BV bounds    x[1964]
 FX bounds    x[1965]   1
 FX bounds    x[1966]   1
 BV bounds    x[1967]
 BV bounds    x[1968]
 BV bounds    x[1969]
 BV bounds    x[1970]
 FX bounds    x[1971]   1
 FX bounds    x[1972]   1
 BV bounds    x[1973]
 BV bounds    x[1974]
 BV bounds    x[1975]
 BV bounds    x[1976]
 FX bounds    x[1977]   1
 FX bounds    x[1978]   1
 BV bounds    x[1979]
 BV bounds    x[1980]
 BV bounds    x[1981]
 BV bounds    x[1982]
 FX bounds    x[1983]   1
 FX bounds    x[1984]   1
 BV bounds    x[1985]
 BV bounds    x[1986]
 BV bounds    x[1987]
 BV bounds    x[1988]
 FX bounds    x[1989]   1
 FX bounds    x[1990]   1
 BV bounds    x[1991]
 BV bounds    x[1992]
 BV bounds    x[1993]
 BV bounds    x[1994]
 BV bounds    x[1995]
 BV bounds    x[1996]
 BV bounds    x[1997]
 BV bounds    x[1998]
 BV bounds    x[1999]
 BV bounds    x[2000]
 BV bounds    x[2001]
 BV bounds    x[2002]
 BV bounds    x[2003]
 BV bounds    x[2004]
 BV bounds    x[2005]
 BV bounds    x[2006]
 BV bounds    x[2007]
 BV bounds    x[2008]
 BV bounds    x[2009]
 BV bounds    x[2010]
 BV bounds    x[2011]
 BV bounds    x[2012]
 BV bounds    x[2013]
 BV bounds    x[2014]
 BV bounds    x[2015]
 BV bounds    x[2016]
 BV bounds    x[2017]
 BV bounds    x[2018]
 BV bounds    x[2019]
 BV bounds    x[2020]
 BV bounds    x[2021]
 BV bounds    x[2022]
 BV bounds    x[2023]
 BV bounds    x[2024]
 BV bounds    x[2025]
 BV bounds    x[2026]
 BV bounds    x[2027]
 BV bounds    x[2028]
 BV bounds    x[2029]
 BV bounds    x[2030]
 BV bounds    x[2031]
 BV bounds    x[2032]
 BV bounds    x[2033]
 BV bounds    x[2034]
 BV bounds    x[2035]
 BV bounds    x[2036]
 BV bounds    x[2037]
 BV bounds    x[2038]
 BV bounds    x[2039]
 BV bounds    x[2040]
 BV bounds    x[2041]
 BV bounds    x[2042]
 BV bounds    x[2043]
 BV bounds    x[2044]
 BV bounds    x[2045]
 BV bounds    x[2046]
 BV bounds    x[2047]
 BV bounds    x[2048]
 BV bounds    x[2049]
 BV bounds    x[2050]
 BV bounds    x[2051]
 BV bounds    x[2052]
 BV bounds    x[2053]
 BV bounds    x[2054]
 FX bounds    x[2055]   1
 FX bounds    x[2056]   1
 BV bounds    x[2057]
 BV bounds    x[2058]
 BV bounds    x[2059]
 BV bounds    x[2060]
 FX bounds    x[2061]   1
 FX bounds    x[2062]   1
 BV bounds    x[2063]
 BV bounds    x[2064]
 BV bounds    x[2065]
 BV bounds    x[2066]
 FX bounds    x[2067]   1
 FX bounds    x[2068]   1
 BV bounds    x[2069]
 BV bounds    x[2070]
 BV bounds    x[2071]
 BV bounds    x[2072]
 FX bounds    x[2073]   1
 FX bounds    x[2074]   1
 BV bounds    x[2075]
 BV bounds    x[2076]
 BV bounds    x[2077]
 BV bounds    x[2078]
 FX bounds    x[2079]   1
 FX bounds    x[2080]   1
 BV bounds    x[2081]
 BV bounds    x[2082]
 BV bounds    x[2083]
 BV bounds    x[2084]
 FX bounds    x[2085]   1
 FX bounds    x[2086]   1
 BV bounds    x[2087]
 BV bounds    x[2088]
 BV bounds    x[2089]
 BV bounds    x[2090]
 FX bounds    x[2091]   1
 FX bounds    x[2092]   1
 BV bounds    x[2093]
 BV bounds    x[2094]
 BV bounds    x[2095]
 BV bounds    x[2096]
 FX bounds    x[2097]   1
 FX bounds    x[2098]   1
 BV bounds    x[2099]
 BV bounds    x[2100]
 BV bounds    x[2101]
 BV bounds    x[2102]
 FX bounds    x[2103]   1
 FX bounds    x[2104]   1
 BV bounds    x[2105]
 BV bounds    x[2106]
 BV bounds    x[2107]
 BV bounds    x[2108]
 FX bounds    x[2109]   1
 FX bounds    x[2110]   1
 BV bounds    x[2111]
 BV bounds    x[2112]
 BV bounds    x[2113]
 BV bounds    x[2114]
 FX bounds    x[2115]   1
 FX bounds    x[2116]   1
 BV bounds    x[2117]
 BV bounds    x[2118]
 BV bounds    x[2119]
 BV bounds    x[2120]
 FX bounds    x[2121]   1
 FX bounds    x[2122]   1
 BV bounds    x[2123]
 BV bounds    x[2124]
 BV bounds    x[2125]
 BV bounds    x[2126]
 FX bounds    x[2127]   1
 FX bounds    x[2128]   1
 BV bounds    x[2129]
 BV bounds    x[2130]
 BV bounds    x[2131]
 BV bounds    x[2132]
 BV bounds    x[2133]
 BV bounds    x[2134]
 BV bounds    x[2135]
 BV bounds    x[2136]
 BV bounds    x[2137]
 BV bounds    x[2138]
 BV bounds    x[2139]
 BV bounds    x[2140]
 BV bounds    x[2141]
 BV bounds    x[2142]
 BV bounds    x[2143]
 BV bounds    x[2144]
 BV bounds    x[2145]
 BV bounds    x[2146]
 BV bounds    x[2147]
 BV bounds    x[2148]
 BV bounds    x[2149]
 BV bounds    x[2150]
 BV bounds    x[2151]
 BV bounds    x[2152]
 BV bounds    x[2153]
 BV bounds    x[2154]
 BV bounds    x[2155]
 BV bounds    x[2156]
 BV bounds    x[2157]
 BV bounds    x[2158]
 BV bounds    x[2159]
 BV bounds    x[2160]
 BV bounds    x[2161]
 BV bounds    x[2162]
 BV bounds    x[2163]
 BV bounds    x[2164]
 BV bounds    x[2165]
 BV bounds    x[2166]
 BV bounds    x[2167]
 BV bounds    x[2168]
 BV bounds    x[2169]
 BV bounds    x[2170]
 BV bounds    x[2171]
 BV bounds    x[2172]
 BV bounds    x[2173]
 BV bounds    x[2174]
 BV bounds    x[2175]
 BV bounds    x[2176]
 BV bounds    x[2177]
 BV bounds    x[2178]
 BV bounds    x[2179]
 BV bounds    x[2180]
 BV bounds    x[2181]
 BV bounds    x[2182]
 BV bounds    x[2183]
 BV bounds    x[2184]
 BV bounds    x[2185]
 BV bounds    x[2186]
 BV bounds    x[2187]
 BV bounds    x[2188]
 BV bounds    x[2189]
 BV bounds    x[2190]
 BV bounds    x[2191]
 BV bounds    x[2192]
 FX bounds    x[2193]   1
 FX bounds    x[2194]   1
 BV bounds    x[2195]
 BV bounds    x[2196]
 BV bounds    x[2197]
 BV bounds    x[2198]
 FX bounds    x[2199]   1
 FX bounds    x[2200]   1
 BV bounds    x[2201]
 BV bounds    x[2202]
 BV bounds    x[2203]
 BV bounds    x[2204]
 FX bounds    x[2205]   1
 FX bounds    x[2206]   1
 BV bounds    x[2207]
 BV bounds    x[2208]
 BV bounds    x[2209]
 BV bounds    x[2210]
 FX bounds    x[2211]   1
 FX bounds    x[2212]   1
 BV bounds    x[2213]
 BV bounds    x[2214]
 BV bounds    x[2215]
 BV bounds    x[2216]
 FX bounds    x[2217]   1
 FX bounds    x[2218]   1
 BV bounds    x[2219]
 BV bounds    x[2220]
 BV bounds    x[2221]
 BV bounds    x[2222]
 FX bounds    x[2223]   1
 FX bounds    x[2224]   1
 BV bounds    x[2225]
 BV bounds    x[2226]
 BV bounds    x[2227]
 BV bounds    x[2228]
 FX bounds    x[2229]   1
 FX bounds    x[2230]   1
 BV bounds    x[2231]
 BV bounds    x[2232]
 BV bounds    x[2233]
 BV bounds    x[2234]
 FX bounds    x[2235]   1
 FX bounds    x[2236]   1
 BV bounds    x[2237]
 BV bounds    x[2238]
 BV bounds    x[2239]
 BV bounds    x[2240]
 FX bounds    x[2241]   1
 FX bounds    x[2242]   1
 BV bounds    x[2243]
 BV bounds    x[2244]
 BV bounds    x[2245]
 BV bounds    x[2246]
 FX bounds    x[2247]   1
 FX bounds    x[2248]   1
 BV bounds    x[2249]
 BV bounds    x[2250]
 BV bounds    x[2251]
 BV bounds    x[2252]
 FX bounds    x[2253]   1
 FX bounds    x[2254]   1
 BV bounds    x[2255]
 BV bounds    x[2256]
 BV bounds    x[2257]
 BV bounds    x[2258]
 FX bounds    x[2259]   1
 FX bounds    x[2260]   1
 BV bounds    x[2261]
 BV bounds    x[2262]
 BV bounds    x[2263]
 BV bounds    x[2264]
 BV bounds    x[2265]
 BV bounds    x[2266]
 BV bounds    x[2267]
 BV bounds    x[2268]
 BV bounds    x[2269]
 BV bounds    x[2270]
 BV bounds    x[2271]
 BV bounds    x[2272]
 BV bounds    x[2273]
 BV bounds    x[2274]
 BV bounds    x[2275]
 BV bounds    x[2276]
 BV bounds    x[2277]
 BV bounds    x[2278]
 BV bounds    x[2279]
 BV bounds    x[2280]
 BV bounds    x[2281]
 BV bounds    x[2282]
 BV bounds    x[2283]
 BV bounds    x[2284]
 BV bounds    x[2285]
 BV bounds    x[2286]
 BV bounds    x[2287]
 BV bounds    x[2288]
 BV bounds    x[2289]
 BV bounds    x[2290]
 BV bounds    x[2291]
 BV bounds    x[2292]
 BV bounds    x[2293]
 BV bounds    x[2294]
 BV bounds    x[2295]
 BV bounds    x[2296]
 BV bounds    x[2297]
 BV bounds    x[2298]
 BV bounds    x[2299]
 BV bounds    x[2300]
 BV bounds    x[2301]
 BV bounds    x[2302]
 BV bounds    x[2303]
 BV bounds    x[2304]
 BV bounds    x[2305]
 BV bounds    x[2306]
 BV bounds    x[2307]
 BV bounds    x[2308]
 BV bounds    x[2309]
 BV bounds    x[2310]
 BV bounds    x[2311]
 BV bounds    x[2312]
 BV bounds    x[2313]
 BV bounds    x[2314]
 BV bounds    x[2315]
 BV bounds    x[2316]
 BV bounds    x[2317]
 BV bounds    x[2318]
 BV bounds    x[2319]
 BV bounds    x[2320]
 BV bounds    x[2321]
 BV bounds    x[2322]
 BV bounds    x[2323]
 BV bounds    x[2324]
 FX bounds    x[2325]   1
 FX bounds    x[2326]   1
 BV bounds    x[2327]
 BV bounds    x[2328]
 BV bounds    x[2329]
 BV bounds    x[2330]
 FX bounds    x[2331]   1
 FX bounds    x[2332]   1
 BV bounds    x[2333]
 BV bounds    x[2334]
 BV bounds    x[2335]
 BV bounds    x[2336]
 FX bounds    x[2337]   1
 FX bounds    x[2338]   1
 BV bounds    x[2339]
 BV bounds    x[2340]
 BV bounds    x[2341]
 BV bounds    x[2342]
 FX bounds    x[2343]   1
 FX bounds    x[2344]   1
 BV bounds    x[2345]
 BV bounds    x[2346]
 BV bounds    x[2347]
 BV bounds    x[2348]
 FX bounds    x[2349]   1
 FX bounds    x[2350]   1
 BV bounds    x[2351]
 BV bounds    x[2352]
 BV bounds    x[2353]
 BV bounds    x[2354]
 FX bounds    x[2355]   1
 FX bounds    x[2356]   1
 BV bounds    x[2357]
 BV bounds    x[2358]
 BV bounds    x[2359]
 BV bounds    x[2360]
 FX bounds    x[2361]   1
 FX bounds    x[2362]   1
 BV bounds    x[2363]
 BV bounds    x[2364]
 BV bounds    x[2365]
 BV bounds    x[2366]
 FX bounds    x[2367]   1
 FX bounds    x[2368]   1
 BV bounds    x[2369]
 BV bounds    x[2370]
 BV bounds    x[2371]
 BV bounds    x[2372]
 FX bounds    x[2373]   1
 FX bounds    x[2374]   1
 BV bounds    x[2375]
 BV bounds    x[2376]
 BV bounds    x[2377]
 BV bounds    x[2378]
 FX bounds    x[2379]   1
 FX bounds    x[2380]   1
 BV bounds    x[2381]
 BV bounds    x[2382]
 BV bounds    x[2383]
 BV bounds    x[2384]
 FX bounds    x[2385]   1
 FX bounds    x[2386]   1
 BV bounds    x[2387]
 BV bounds    x[2388]
 BV bounds    x[2389]
 BV bounds    x[2390]
 BV bounds    x[2391]
 BV bounds    x[2392]
 BV bounds    x[2393]
 BV bounds    x[2394]
 BV bounds    x[2395]
 BV bounds    x[2396]
 BV bounds    x[2397]
 BV bounds    x[2398]
 BV bounds    x[2399]
 BV bounds    x[2400]
 BV bounds    x[2401]
 BV bounds    x[2402]
 BV bounds    x[2403]
 BV bounds    x[2404]
 BV bounds    x[2405]
 BV bounds    x[2406]
 BV bounds    x[2407]
 BV bounds    x[2408]
 BV bounds    x[2409]
 BV bounds    x[2410]
 BV bounds    x[2411]
 BV bounds    x[2412]
 BV bounds    x[2413]
 BV bounds    x[2414]
 BV bounds    x[2415]
 BV bounds    x[2416]
 BV bounds    x[2417]
 BV bounds    x[2418]
 BV bounds    x[2419]
 BV bounds    x[2420]
 BV bounds    x[2421]
 BV bounds    x[2422]
 BV bounds    x[2423]
 BV bounds    x[2424]
 BV bounds    x[2425]
 BV bounds    x[2426]
 BV bounds    x[2427]
 BV bounds    x[2428]
 BV bounds    x[2429]
 BV bounds    x[2430]
 BV bounds    x[2431]
 BV bounds    x[2432]
 BV bounds    x[2433]
 BV bounds    x[2434]
 BV bounds    x[2435]
 BV bounds    x[2436]
 BV bounds    x[2437]
 BV bounds    x[2438]
 BV bounds    x[2439]
 BV bounds    x[2440]
 BV bounds    x[2441]
 BV bounds    x[2442]
 BV bounds    x[2443]
 BV bounds    x[2444]
 BV bounds    x[2445]
 BV bounds    x[2446]
 BV bounds    x[2447]
 BV bounds    x[2448]
 BV bounds    x[2449]
 BV bounds    x[2450]
 FX bounds    x[2451]   1
 FX bounds    x[2452]   1
 BV bounds    x[2453]
 BV bounds    x[2454]
 BV bounds    x[2455]
 BV bounds    x[2456]
 FX bounds    x[2457]   1
 FX bounds    x[2458]   1
 BV bounds    x[2459]
 BV bounds    x[2460]
 BV bounds    x[2461]
 BV bounds    x[2462]
 FX bounds    x[2463]   1
 FX bounds    x[2464]   1
 BV bounds    x[2465]
 BV bounds    x[2466]
 BV bounds    x[2467]
 BV bounds    x[2468]
 FX bounds    x[2469]   1
 FX bounds    x[2470]   1
 BV bounds    x[2471]
 BV bounds    x[2472]
 BV bounds    x[2473]
 BV bounds    x[2474]
 FX bounds    x[2475]   1
 FX bounds    x[2476]   1
 BV bounds    x[2477]
 BV bounds    x[2478]
 BV bounds    x[2479]
 BV bounds    x[2480]
 FX bounds    x[2481]   1
 FX bounds    x[2482]   1
 BV bounds    x[2483]
 BV bounds    x[2484]
 BV bounds    x[2485]
 BV bounds    x[2486]
 FX bounds    x[2487]   1
 FX bounds    x[2488]   1
 BV bounds    x[2489]
 BV bounds    x[2490]
 BV bounds    x[2491]
 BV bounds    x[2492]
 FX bounds    x[2493]   1
 FX bounds    x[2494]   1
 BV bounds    x[2495]
 BV bounds    x[2496]
 BV bounds    x[2497]
 BV bounds    x[2498]
 FX bounds    x[2499]   1
 FX bounds    x[2500]   1
 BV bounds    x[2501]
 BV bounds    x[2502]
 BV bounds    x[2503]
 BV bounds    x[2504]
 FX bounds    x[2505]   1
 FX bounds    x[2506]   1
 BV bounds    x[2507]
 BV bounds    x[2508]
 BV bounds    x[2509]
 BV bounds    x[2510]
 BV bounds    x[2511]
 BV bounds    x[2512]
 BV bounds    x[2513]
 BV bounds    x[2514]
 BV bounds    x[2515]
 BV bounds    x[2516]
 BV bounds    x[2517]
 BV bounds    x[2518]
 BV bounds    x[2519]
 BV bounds    x[2520]
 BV bounds    x[2521]
 BV bounds    x[2522]
 BV bounds    x[2523]
 BV bounds    x[2524]
 BV bounds    x[2525]
 BV bounds    x[2526]
 BV bounds    x[2527]
 BV bounds    x[2528]
 BV bounds    x[2529]
 BV bounds    x[2530]
 BV bounds    x[2531]
 BV bounds    x[2532]
 BV bounds    x[2533]
 BV bounds    x[2534]
 BV bounds    x[2535]
 BV bounds    x[2536]
 BV bounds    x[2537]
 BV bounds    x[2538]
 BV bounds    x[2539]
 BV bounds    x[2540]
 BV bounds    x[2541]
 BV bounds    x[2542]
 BV bounds    x[2543]
 BV bounds    x[2544]
 BV bounds    x[2545]
 BV bounds    x[2546]
 BV bounds    x[2547]
 BV bounds    x[2548]
 BV bounds    x[2549]
 BV bounds    x[2550]
 BV bounds    x[2551]
 BV bounds    x[2552]
 BV bounds    x[2553]
 BV bounds    x[2554]
 BV bounds    x[2555]
 BV bounds    x[2556]
 BV bounds    x[2557]
 BV bounds    x[2558]
 BV bounds    x[2559]
 BV bounds    x[2560]
 BV bounds    x[2561]
 BV bounds    x[2562]
 BV bounds    x[2563]
 BV bounds    x[2564]
 BV bounds    x[2565]
 BV bounds    x[2566]
 BV bounds    x[2567]
 BV bounds    x[2568]
 BV bounds    x[2569]
 BV bounds    x[2570]
 FX bounds    x[2571]   1
 FX bounds    x[2572]   1
 BV bounds    x[2573]
 BV bounds    x[2574]
 BV bounds    x[2575]
 BV bounds    x[2576]
 FX bounds    x[2577]   1
 FX bounds    x[2578]   1
 BV bounds    x[2579]
 BV bounds    x[2580]
 BV bounds    x[2581]
 BV bounds    x[2582]
 FX bounds    x[2583]   1
 FX bounds    x[2584]   1
 BV bounds    x[2585]
 BV bounds    x[2586]
 BV bounds    x[2587]
 BV bounds    x[2588]
 FX bounds    x[2589]   1
 FX bounds    x[2590]   1
 BV bounds    x[2591]
 BV bounds    x[2592]
 BV bounds    x[2593]
 BV bounds    x[2594]
 FX bounds    x[2595]   1
 FX bounds    x[2596]   1
 BV bounds    x[2597]
 BV bounds    x[2598]
 BV bounds    x[2599]
 BV bounds    x[2600]
 FX bounds    x[2601]   1
 FX bounds    x[2602]   1
 BV bounds    x[2603]
 BV bounds    x[2604]
 BV bounds    x[2605]
 BV bounds    x[2606]
 FX bounds    x[2607]   1
 FX bounds    x[2608]   1
 BV bounds    x[2609]
 BV bounds    x[2610]
 BV bounds    x[2611]
 BV bounds    x[2612]
 FX bounds    x[2613]   1
 FX bounds    x[2614]   1
 BV bounds    x[2615]
 BV bounds    x[2616]
 BV bounds    x[2617]
 BV bounds    x[2618]
 FX bounds    x[2619]   1
 FX bounds    x[2620]   1
 BV bounds    x[2621]
 BV bounds    x[2622]
 BV bounds    x[2623]
 BV bounds    x[2624]
 BV bounds    x[2625]
 BV bounds    x[2626]
 BV bounds    x[2627]
 BV bounds    x[2628]
 BV bounds    x[2629]
 BV bounds    x[2630]
 BV bounds    x[2631]
 BV bounds    x[2632]
 BV bounds    x[2633]
 BV bounds    x[2634]
 BV bounds    x[2635]
 BV bounds    x[2636]
 BV bounds    x[2637]
 BV bounds    x[2638]
 BV bounds    x[2639]
 BV bounds    x[2640]
 BV bounds    x[2641]
 BV bounds    x[2642]
 BV bounds    x[2643]
 BV bounds    x[2644]
 BV bounds    x[2645]
 BV bounds    x[2646]
 BV bounds    x[2647]
 BV bounds    x[2648]
 BV bounds    x[2649]
 BV bounds    x[2650]
 BV bounds    x[2651]
 BV bounds    x[2652]
 BV bounds    x[2653]
 BV bounds    x[2654]
 BV bounds    x[2655]
 BV bounds    x[2656]
 BV bounds    x[2657]
 BV bounds    x[2658]
 BV bounds    x[2659]
 BV bounds    x[2660]
 BV bounds    x[2661]
 BV bounds    x[2662]
 BV bounds    x[2663]
 BV bounds    x[2664]
 BV bounds    x[2665]
 BV bounds    x[2666]
 BV bounds    x[2667]
 BV bounds    x[2668]
 BV bounds    x[2669]
 BV bounds    x[2670]
 BV bounds    x[2671]
 BV bounds    x[2672]
 BV bounds    x[2673]
 BV bounds    x[2674]
 BV bounds    x[2675]
 BV bounds    x[2676]
 BV bounds    x[2677]
 BV bounds    x[2678]
 BV bounds    x[2679]
 BV bounds    x[2680]
 BV bounds    x[2681]
 BV bounds    x[2682]
 BV bounds    x[2683]
 BV bounds    x[2684]
 FX bounds    x[2685]   1
 FX bounds    x[2686]   1
 BV bounds    x[2687]
 BV bounds    x[2688]
 BV bounds    x[2689]
 BV bounds    x[2690]
 FX bounds    x[2691]   1
 FX bounds    x[2692]   1
 BV bounds    x[2693]
 BV bounds    x[2694]
 BV bounds    x[2695]
 BV bounds    x[2696]
 FX bounds    x[2697]   1
 FX bounds    x[2698]   1
 BV bounds    x[2699]
 BV bounds    x[2700]
 BV bounds    x[2701]
 BV bounds    x[2702]
 FX bounds    x[2703]   1
 FX bounds    x[2704]   1
 BV bounds    x[2705]
 BV bounds    x[2706]
 BV bounds    x[2707]
 BV bounds    x[2708]
 FX bounds    x[2709]   1
 FX bounds    x[2710]   1
 BV bounds    x[2711]
 BV bounds    x[2712]
 BV bounds    x[2713]
 BV bounds    x[2714]
 FX bounds    x[2715]   1
 FX bounds    x[2716]   1
 BV bounds    x[2717]
 BV bounds    x[2718]
 BV bounds    x[2719]
 BV bounds    x[2720]
 FX bounds    x[2721]   1
 FX bounds    x[2722]   1
 BV bounds    x[2723]
 BV bounds    x[2724]
 BV bounds    x[2725]
 BV bounds    x[2726]
 FX bounds    x[2727]   1
 FX bounds    x[2728]   1
 BV bounds    x[2729]
 BV bounds    x[2730]
 BV bounds    x[2731]
 BV bounds    x[2732]
 BV bounds    x[2733]
 BV bounds    x[2734]
 BV bounds    x[2735]
 BV bounds    x[2736]
 BV bounds    x[2737]
 BV bounds    x[2738]
 BV bounds    x[2739]
 BV bounds    x[2740]
 BV bounds    x[2741]
 BV bounds    x[2742]
 BV bounds    x[2743]
 BV bounds    x[2744]
 BV bounds    x[2745]
 BV bounds    x[2746]
 BV bounds    x[2747]
 BV bounds    x[2748]
 BV bounds    x[2749]
 BV bounds    x[2750]
 BV bounds    x[2751]
 BV bounds    x[2752]
 BV bounds    x[2753]
 BV bounds    x[2754]
 BV bounds    x[2755]
 BV bounds    x[2756]
 BV bounds    x[2757]
 BV bounds    x[2758]
 BV bounds    x[2759]
 BV bounds    x[2760]
 BV bounds    x[2761]
 BV bounds    x[2762]
 BV bounds    x[2763]
 BV bounds    x[2764]
 BV bounds    x[2765]
 BV bounds    x[2766]
 BV bounds    x[2767]
 BV bounds    x[2768]
 BV bounds    x[2769]
 BV bounds    x[2770]
 BV bounds    x[2771]
 BV bounds    x[2772]
 BV bounds    x[2773]
 BV bounds    x[2774]
 BV bounds    x[2775]
 BV bounds    x[2776]
 BV bounds    x[2777]
 BV bounds    x[2778]
 BV bounds    x[2779]
 BV bounds    x[2780]
 BV bounds    x[2781]
 BV bounds    x[2782]
 BV bounds    x[2783]
 BV bounds    x[2784]
 BV bounds    x[2785]
 BV bounds    x[2786]
 BV bounds    x[2787]
 BV bounds    x[2788]
 BV bounds    x[2789]
 BV bounds    x[2790]
 BV bounds    x[2791]
 BV bounds    x[2792]
 FX bounds    x[2793]   1
 FX bounds    x[2794]   1
 BV bounds    x[2795]
 BV bounds    x[2796]
 BV bounds    x[2797]
 BV bounds    x[2798]
 FX bounds    x[2799]   1
 FX bounds    x[2800]   1
 BV bounds    x[2801]
 BV bounds    x[2802]
 BV bounds    x[2803]
 BV bounds    x[2804]
 FX bounds    x[2805]   1
 FX bounds    x[2806]   1
 BV bounds    x[2807]
 BV bounds    x[2808]
 BV bounds    x[2809]
 BV bounds    x[2810]
 FX bounds    x[2811]   1
 FX bounds    x[2812]   1
 BV bounds    x[2813]
 BV bounds    x[2814]
 BV bounds    x[2815]
 BV bounds    x[2816]
 FX bounds    x[2817]   1
 FX bounds    x[2818]   1
 BV bounds    x[2819]
 BV bounds    x[2820]
 BV bounds    x[2821]
 BV bounds    x[2822]
 FX bounds    x[2823]   1
 FX bounds    x[2824]   1
 BV bounds    x[2825]
 BV bounds    x[2826]
 BV bounds    x[2827]
 BV bounds    x[2828]
 FX bounds    x[2829]   1
 FX bounds    x[2830]   1
 BV bounds    x[2831]
 BV bounds    x[2832]
 BV bounds    x[2833]
 BV bounds    x[2834]
 BV bounds    x[2835]
 BV bounds    x[2836]
 BV bounds    x[2837]
 BV bounds    x[2838]
 BV bounds    x[2839]
 BV bounds    x[2840]
 BV bounds    x[2841]
 BV bounds    x[2842]
 BV bounds    x[2843]
 BV bounds    x[2844]
 BV bounds    x[2845]
 BV bounds    x[2846]
 BV bounds    x[2847]
 BV bounds    x[2848]
 BV bounds    x[2849]
 BV bounds    x[2850]
 BV bounds    x[2851]
 BV bounds    x[2852]
 BV bounds    x[2853]
 BV bounds    x[2854]
 BV bounds    x[2855]
 BV bounds    x[2856]
 BV bounds    x[2857]
 BV bounds    x[2858]
 BV bounds    x[2859]
 BV bounds    x[2860]
 BV bounds    x[2861]
 BV bounds    x[2862]
 BV bounds    x[2863]
 BV bounds    x[2864]
 BV bounds    x[2865]
 BV bounds    x[2866]
 BV bounds    x[2867]
 BV bounds    x[2868]
 BV bounds    x[2869]
 BV bounds    x[2870]
 BV bounds    x[2871]
 BV bounds    x[2872]
 BV bounds    x[2873]
 BV bounds    x[2874]
 BV bounds    x[2875]
 BV bounds    x[2876]
 BV bounds    x[2877]
 BV bounds    x[2878]
 BV bounds    x[2879]
 BV bounds    x[2880]
 BV bounds    x[2881]
 BV bounds    x[2882]
 BV bounds    x[2883]
 BV bounds    x[2884]
 BV bounds    x[2885]
 BV bounds    x[2886]
 BV bounds    x[2887]
 BV bounds    x[2888]
 BV bounds    x[2889]
 BV bounds    x[2890]
 BV bounds    x[2891]
 BV bounds    x[2892]
 BV bounds    x[2893]
 BV bounds    x[2894]
 FX bounds    x[2895]   1
 FX bounds    x[2896]   1
 BV bounds    x[2897]
 BV bounds    x[2898]
 BV bounds    x[2899]
 BV bounds    x[2900]
 FX bounds    x[2901]   1
 FX bounds    x[2902]   1
 BV bounds    x[2903]
 BV bounds    x[2904]
 BV bounds    x[2905]
 BV bounds    x[2906]
 FX bounds    x[2907]   1
 FX bounds    x[2908]   1
 BV bounds    x[2909]
 BV bounds    x[2910]
 BV bounds    x[2911]
 BV bounds    x[2912]
 FX bounds    x[2913]   1
 FX bounds    x[2914]   1
 BV bounds    x[2915]
 BV bounds    x[2916]
 BV bounds    x[2917]
 BV bounds    x[2918]
 FX bounds    x[2919]   1
 FX bounds    x[2920]   1
 BV bounds    x[2921]
 BV bounds    x[2922]
 BV bounds    x[2923]
 BV bounds    x[2924]
 FX bounds    x[2925]   1
 FX bounds    x[2926]   1
 BV bounds    x[2927]
 BV bounds    x[2928]
 BV bounds    x[2929]
 BV bounds    x[2930]
 BV bounds    x[2931]
 BV bounds    x[2932]
 BV bounds    x[2933]
 BV bounds    x[2934]
 BV bounds    x[2935]
 BV bounds    x[2936]
 BV bounds    x[2937]
 BV bounds    x[2938]
 BV bounds    x[2939]
 BV bounds    x[2940]
 BV bounds    x[2941]
 BV bounds    x[2942]
 BV bounds    x[2943]
 BV bounds    x[2944]
 BV bounds    x[2945]
 BV bounds    x[2946]
 BV bounds    x[2947]
 BV bounds    x[2948]
 BV bounds    x[2949]
 BV bounds    x[2950]
 BV bounds    x[2951]
 BV bounds    x[2952]
 BV bounds    x[2953]
 BV bounds    x[2954]
 BV bounds    x[2955]
 BV bounds    x[2956]
 BV bounds    x[2957]
 BV bounds    x[2958]
 BV bounds    x[2959]
 BV bounds    x[2960]
 BV bounds    x[2961]
 BV bounds    x[2962]
 BV bounds    x[2963]
 BV bounds    x[2964]
 BV bounds    x[2965]
 BV bounds    x[2966]
 BV bounds    x[2967]
 BV bounds    x[2968]
 BV bounds    x[2969]
 BV bounds    x[2970]
 BV bounds    x[2971]
 BV bounds    x[2972]
 BV bounds    x[2973]
 BV bounds    x[2974]
 BV bounds    x[2975]
 BV bounds    x[2976]
 BV bounds    x[2977]
 BV bounds    x[2978]
 BV bounds    x[2979]
 BV bounds    x[2980]
 BV bounds    x[2981]
 BV bounds    x[2982]
 BV bounds    x[2983]
 BV bounds    x[2984]
 BV bounds    x[2985]
 BV bounds    x[2986]
 BV bounds    x[2987]
 BV bounds    x[2988]
 BV bounds    x[2989]
 BV bounds    x[2990]
 FX bounds    x[2991]   1
 FX bounds    x[2992]   1
 BV bounds    x[2993]
 BV bounds    x[2994]
 BV bounds    x[2995]
 BV bounds    x[2996]
 FX bounds    x[2997]   1
 FX bounds    x[2998]   1
 BV bounds    x[2999]
 BV bounds    x[3000]
 BV bounds    x[3001]
 BV bounds    x[3002]
 FX bounds    x[3003]   1
 FX bounds    x[3004]   1
 BV bounds    x[3005]
 BV bounds    x[3006]
 BV bounds    x[3007]
 BV bounds    x[3008]
 FX bounds    x[3009]   1
 FX bounds    x[3010]   1
 BV bounds    x[3011]
 BV bounds    x[3012]
 BV bounds    x[3013]
 BV bounds    x[3014]
 FX bounds    x[3015]   1
 FX bounds    x[3016]   1
 BV bounds    x[3017]
 BV bounds    x[3018]
 BV bounds    x[3019]
 BV bounds    x[3020]
 BV bounds    x[3021]
 BV bounds    x[3022]
 BV bounds    x[3023]
 BV bounds    x[3024]
 BV bounds    x[3025]
 BV bounds    x[3026]
 BV bounds    x[3027]
 BV bounds    x[3028]
 BV bounds    x[3029]
 BV bounds    x[3030]
 BV bounds    x[3031]
 BV bounds    x[3032]
 BV bounds    x[3033]
 BV bounds    x[3034]
 BV bounds    x[3035]
 BV bounds    x[3036]
 BV bounds    x[3037]
 BV bounds    x[3038]
 BV bounds    x[3039]
 BV bounds    x[3040]
 BV bounds    x[3041]
 BV bounds    x[3042]
 BV bounds    x[3043]
 BV bounds    x[3044]
 BV bounds    x[3045]
 BV bounds    x[3046]
 BV bounds    x[3047]
 BV bounds    x[3048]
 BV bounds    x[3049]
 BV bounds    x[3050]
 BV bounds    x[3051]
 BV bounds    x[3052]
 BV bounds    x[3053]
 BV bounds    x[3054]
 BV bounds    x[3055]
 BV bounds    x[3056]
 BV bounds    x[3057]
 BV bounds    x[3058]
 BV bounds    x[3059]
 BV bounds    x[3060]
 BV bounds    x[3061]
 BV bounds    x[3062]
 BV bounds    x[3063]
 BV bounds    x[3064]
 BV bounds    x[3065]
 BV bounds    x[3066]
 BV bounds    x[3067]
 BV bounds    x[3068]
 BV bounds    x[3069]
 BV bounds    x[3070]
 BV bounds    x[3071]
 BV bounds    x[3072]
 BV bounds    x[3073]
 BV bounds    x[3074]
 BV bounds    x[3075]
 BV bounds    x[3076]
 BV bounds    x[3077]
 BV bounds    x[3078]
 BV bounds    x[3079]
 BV bounds    x[3080]
 FX bounds    x[3081]   1
 FX bounds    x[3082]   1
 BV bounds    x[3083]
 BV bounds    x[3084]
 BV bounds    x[3085]
 BV bounds    x[3086]
 FX bounds    x[3087]   1
 FX bounds    x[3088]   1
 BV bounds    x[3089]
 BV bounds    x[3090]
 BV bounds    x[3091]
 BV bounds    x[3092]
 FX bounds    x[3093]   1
 FX bounds    x[3094]   1
 BV bounds    x[3095]
 BV bounds    x[3096]
 BV bounds    x[3097]
 BV bounds    x[3098]
 FX bounds    x[3099]   1
 FX bounds    x[3100]   1
 BV bounds    x[3101]
 BV bounds    x[3102]
 BV bounds    x[3103]
 BV bounds    x[3104]
 BV bounds    x[3105]
 BV bounds    x[3106]
 BV bounds    x[3107]
 BV bounds    x[3108]
 BV bounds    x[3109]
 BV bounds    x[3110]
 BV bounds    x[3111]
 BV bounds    x[3112]
 BV bounds    x[3113]
 BV bounds    x[3114]
 BV bounds    x[3115]
 BV bounds    x[3116]
 BV bounds    x[3117]
 BV bounds    x[3118]
 BV bounds    x[3119]
 BV bounds    x[3120]
 BV bounds    x[3121]
 BV bounds    x[3122]
 BV bounds    x[3123]
 BV bounds    x[3124]
 BV bounds    x[3125]
 BV bounds    x[3126]
 BV bounds    x[3127]
 BV bounds    x[3128]
 BV bounds    x[3129]
 BV bounds    x[3130]
 BV bounds    x[3131]
 BV bounds    x[3132]
 BV bounds    x[3133]
 BV bounds    x[3134]
 BV bounds    x[3135]
 BV bounds    x[3136]
 BV bounds    x[3137]
 BV bounds    x[3138]
 BV bounds    x[3139]
 BV bounds    x[3140]
 BV bounds    x[3141]
 BV bounds    x[3142]
 BV bounds    x[3143]
 BV bounds    x[3144]
 BV bounds    x[3145]
 BV bounds    x[3146]
 BV bounds    x[3147]
 BV bounds    x[3148]
 BV bounds    x[3149]
 BV bounds    x[3150]
 BV bounds    x[3151]
 BV bounds    x[3152]
 BV bounds    x[3153]
 BV bounds    x[3154]
 BV bounds    x[3155]
 BV bounds    x[3156]
 BV bounds    x[3157]
 BV bounds    x[3158]
 BV bounds    x[3159]
 BV bounds    x[3160]
 BV bounds    x[3161]
 BV bounds    x[3162]
 BV bounds    x[3163]
 BV bounds    x[3164]
 FX bounds    x[3165]   1
 FX bounds    x[3166]   1
 BV bounds    x[3167]
 BV bounds    x[3168]
 BV bounds    x[3169]
 BV bounds    x[3170]
 FX bounds    x[3171]   1
 FX bounds    x[3172]   1
 BV bounds    x[3173]
 BV bounds    x[3174]
 BV bounds    x[3175]
 BV bounds    x[3176]
 FX bounds    x[3177]   1
 FX bounds    x[3178]   1
 BV bounds    x[3179]
 BV bounds    x[3180]
 BV bounds    x[3181]
 BV bounds    x[3182]
 BV bounds    x[3183]
 BV bounds    x[3184]
 BV bounds    x[3185]
 BV bounds    x[3186]
 BV bounds    x[3187]
 BV bounds    x[3188]
 BV bounds    x[3189]
 BV bounds    x[3190]
 BV bounds    x[3191]
 BV bounds    x[3192]
 BV bounds    x[3193]
 BV bounds    x[3194]
 BV bounds    x[3195]
 BV bounds    x[3196]
 BV bounds    x[3197]
 BV bounds    x[3198]
 BV bounds    x[3199]
 BV bounds    x[3200]
 BV bounds    x[3201]
 BV bounds    x[3202]
 BV bounds    x[3203]
 BV bounds    x[3204]
 BV bounds    x[3205]
 BV bounds    x[3206]
 BV bounds    x[3207]
 BV bounds    x[3208]
 BV bounds    x[3209]
 BV bounds    x[3210]
 BV bounds    x[3211]
 BV bounds    x[3212]
 BV bounds    x[3213]
 BV bounds    x[3214]
 BV bounds    x[3215]
 BV bounds    x[3216]
 BV bounds    x[3217]
 BV bounds    x[3218]
 BV bounds    x[3219]
 BV bounds    x[3220]
 BV bounds    x[3221]
 BV bounds    x[3222]
 BV bounds    x[3223]
 BV bounds    x[3224]
 BV bounds    x[3225]
 BV bounds    x[3226]
 BV bounds    x[3227]
 BV bounds    x[3228]
 BV bounds    x[3229]
 BV bounds    x[3230]
 BV bounds    x[3231]
 BV bounds    x[3232]
 BV bounds    x[3233]
 BV bounds    x[3234]
 BV bounds    x[3235]
 BV bounds    x[3236]
 BV bounds    x[3237]
 BV bounds    x[3238]
 BV bounds    x[3239]
 BV bounds    x[3240]
 BV bounds    x[3241]
 BV bounds    x[3242]
 FX bounds    x[3243]   1
 FX bounds    x[3244]   1
 BV bounds    x[3245]
 BV bounds    x[3246]
 BV bounds    x[3247]
 BV bounds    x[3248]
 FX bounds    x[3249]   1
 FX bounds    x[3250]   1
 BV bounds    x[3251]
 BV bounds    x[3252]
 BV bounds    x[3253]
 BV bounds    x[3254]
 BV bounds    x[3255]
 BV bounds    x[3256]
 BV bounds    x[3257]
 BV bounds    x[3258]
 BV bounds    x[3259]
 BV bounds    x[3260]
 BV bounds    x[3261]
 BV bounds    x[3262]
 BV bounds    x[3263]
 BV bounds    x[3264]
 BV bounds    x[3265]
 BV bounds    x[3266]
 BV bounds    x[3267]
 BV bounds    x[3268]
 BV bounds    x[3269]
 BV bounds    x[3270]
 BV bounds    x[3271]
 BV bounds    x[3272]
 BV bounds    x[3273]
 BV bounds    x[3274]
 BV bounds    x[3275]
 BV bounds    x[3276]
 BV bounds    x[3277]
 BV bounds    x[3278]
 BV bounds    x[3279]
 BV bounds    x[3280]
 BV bounds    x[3281]
 BV bounds    x[3282]
 BV bounds    x[3283]
 BV bounds    x[3284]
 BV bounds    x[3285]
 BV bounds    x[3286]
 BV bounds    x[3287]
 BV bounds    x[3288]
 BV bounds    x[3289]
 BV bounds    x[3290]
 BV bounds    x[3291]
 BV bounds    x[3292]
 BV bounds    x[3293]
 BV bounds    x[3294]
 BV bounds    x[3295]
 BV bounds    x[3296]
 BV bounds    x[3297]
 BV bounds    x[3298]
 BV bounds    x[3299]
 BV bounds    x[3300]
 BV bounds    x[3301]
 BV bounds    x[3302]
 BV bounds    x[3303]
 BV bounds    x[3304]
 BV bounds    x[3305]
 BV bounds    x[3306]
 BV bounds    x[3307]
 BV bounds    x[3308]
 BV bounds    x[3309]
 BV bounds    x[3310]
 BV bounds    x[3311]
 BV bounds    x[3312]
 BV bounds    x[3313]
 BV bounds    x[3314]
 FX bounds    x[3315]   1
 FX bounds    x[3316]   1
 BV bounds    x[3317]
 BV bounds    x[3318]
 BV bounds    x[3319]
 BV bounds    x[3320]
 BV bounds    x[3321]
 BV bounds    x[3322]
 BV bounds    x[3323]
 BV bounds    x[3324]
 BV bounds    x[3325]
 BV bounds    x[3326]
 BV bounds    x[3327]
 BV bounds    x[3328]
 BV bounds    x[3329]
 BV bounds    x[3330]
 BV bounds    x[3331]
 BV bounds    x[3332]
 BV bounds    x[3333]
 BV bounds    x[3334]
 BV bounds    x[3335]
 BV bounds    x[3336]
 BV bounds    x[3337]
 BV bounds    x[3338]
 BV bounds    x[3339]
 BV bounds    x[3340]
 BV bounds    x[3341]
 BV bounds    x[3342]
 BV bounds    x[3343]
 BV bounds    x[3344]
 BV bounds    x[3345]
 BV bounds    x[3346]
 BV bounds    x[3347]
 BV bounds    x[3348]
 BV bounds    x[3349]
 BV bounds    x[3350]
 BV bounds    x[3351]
 BV bounds    x[3352]
 BV bounds    x[3353]
 BV bounds    x[3354]
 BV bounds    x[3355]
 BV bounds    x[3356]
 BV bounds    x[3357]
 BV bounds    x[3358]
 BV bounds    x[3359]
 BV bounds    x[3360]
 BV bounds    x[3361]
 BV bounds    x[3362]
 BV bounds    x[3363]
 BV bounds    x[3364]
 BV bounds    x[3365]
 BV bounds    x[3366]
 BV bounds    x[3367]
 BV bounds    x[3368]
 BV bounds    x[3369]
 BV bounds    x[3370]
 BV bounds    x[3371]
 BV bounds    x[3372]
 BV bounds    x[3373]
 BV bounds    x[3374]
 BV bounds    x[3375]
 BV bounds    x[3376]
 BV bounds    x[3377]
 BV bounds    x[3378]
 BV bounds    x[3379]
 BV bounds    x[3380]
 BV bounds    x[3381]
 BV bounds    x[3382]
 BV bounds    x[3383]
 BV bounds    x[3384]
 BV bounds    x[3385]
 BV bounds    x[3386]
 BV bounds    x[3387]
 BV bounds    x[3388]
 BV bounds    x[3389]
 BV bounds    x[3390]
 BV bounds    x[3391]
 BV bounds    x[3392]
 BV bounds    x[3393]
 BV bounds    x[3394]
 BV bounds    x[3395]
 BV bounds    x[3396]
 BV bounds    x[3397]
 BV bounds    x[3398]
 BV bounds    x[3399]
 BV bounds    x[3400]
 BV bounds    x[3401]
 BV bounds    x[3402]
 BV bounds    x[3403]
 BV bounds    x[3404]
 BV bounds    x[3405]
 BV bounds    x[3406]
 BV bounds    x[3407]
 BV bounds    x[3408]
 BV bounds    x[3409]
 BV bounds    x[3410]
 BV bounds    x[3411]
 BV bounds    x[3412]
 BV bounds    x[3413]
 BV bounds    x[3414]
 BV bounds    x[3415]
 BV bounds    x[3416]
 BV bounds    x[3417]
 BV bounds    x[3418]
 BV bounds    x[3419]
 BV bounds    x[3420]
 BV bounds    x[3421]
 BV bounds    x[3422]
 BV bounds    x[3423]
 BV bounds    x[3424]
 BV bounds    x[3425]
 BV bounds    x[3426]
 BV bounds    x[3427]
 BV bounds    x[3428]
 BV bounds    x[3429]
 BV bounds    x[3430]
 BV bounds    x[3431]
 BV bounds    x[3432]
 BV bounds    x[3433]
 BV bounds    x[3434]
 BV bounds    x[3435]
 BV bounds    x[3436]
 BV bounds    x[3437]
 BV bounds    x[3438]
 BV bounds    x[3439]
 BV bounds    x[3440]
 BV bounds    x[3441]
 BV bounds    x[3442]
 BV bounds    x[3443]
 BV bounds    x[3444]
 BV bounds    x[3445]
 BV bounds    x[3446]
 BV bounds    x[3447]
 BV bounds    x[3448]
 BV bounds    x[3449]
 BV bounds    x[3450]
 BV bounds    x[3451]
 BV bounds    x[3452]
 BV bounds    x[3453]
 BV bounds    x[3454]
 BV bounds    x[3455]
 BV bounds    x[3456]
 BV bounds    x[3457]
 BV bounds    x[3458]
 BV bounds    x[3459]
 BV bounds    x[3460]
 BV bounds    x[3461]
 BV bounds    x[3462]
 BV bounds    x[3463]
 BV bounds    x[3464]
 BV bounds    x[3465]
 BV bounds    x[3466]
 BV bounds    x[3467]
 BV bounds    x[3468]
 BV bounds    x[3469]
 BV bounds    x[3470]
 BV bounds    x[3471]
 BV bounds    x[3472]
 BV bounds    x[3473]
 BV bounds    x[3474]
 BV bounds    x[3475]
 BV bounds    x[3476]
 BV bounds    x[3477]
 BV bounds    x[3478]
 BV bounds    x[3479]
 BV bounds    x[3480]
 BV bounds    x[3481]
 BV bounds    x[3482]
 BV bounds    x[3483]
 BV bounds    x[3484]
 BV bounds    x[3485]
 BV bounds    x[3486]
 BV bounds    x[3487]
 BV bounds    x[3488]
 BV bounds    x[3489]
 BV bounds    x[3490]
 BV bounds    x[3491]
 BV bounds    x[3492]
 BV bounds    x[3493]
 BV bounds    x[3494]
 BV bounds    x[3495]
 BV bounds    x[3496]
 BV bounds    x[3497]
 BV bounds    x[3498]
 BV bounds    x[3499]
 BV bounds    x[3500]
 BV bounds    x[3501]
 BV bounds    x[3502]
 BV bounds    x[3503]
 BV bounds    x[3504]
 BV bounds    x[3505]
 BV bounds    x[3506]
 BV bounds    x[3507]
 BV bounds    x[3508]
 BV bounds    x[3509]
 BV bounds    x[3510]
 BV bounds    x[3511]
 BV bounds    x[3512]
 BV bounds    x[3513]
 BV bounds    x[3514]
 BV bounds    x[3515]
 BV bounds    x[3516]
 BV bounds    x[3517]
 BV bounds    x[3518]
 BV bounds    x[3519]
 BV bounds    x[3520]
 BV bounds    x[3521]
 BV bounds    x[3522]
 BV bounds    x[3523]
 BV bounds    x[3524]
 BV bounds    x[3525]
 BV bounds    x[3526]
 BV bounds    x[3527]
 BV bounds    x[3528]
 BV bounds    x[3529]
 BV bounds    x[3530]
 BV bounds    x[3531]
 BV bounds    x[3532]
 BV bounds    x[3533]
 BV bounds    x[3534]
 BV bounds    x[3535]
 BV bounds    x[3536]
 BV bounds    x[3537]
 BV bounds    x[3538]
 BV bounds    x[3539]
 BV bounds    x[3540]
 BV bounds    x[3541]
 BV bounds    x[3542]
 BV bounds    x[3543]
 BV bounds    x[3544]
 BV bounds    x[3545]
 BV bounds    x[3546]
 BV bounds    x[3547]
 BV bounds    x[3548]
 BV bounds    x[3549]
 BV bounds    x[3550]
 BV bounds    x[3551]
 BV bounds    x[3552]
 BV bounds    x[3553]
 BV bounds    x[3554]
 BV bounds    x[3555]
 BV bounds    x[3556]
 BV bounds    x[3557]
 BV bounds    x[3558]
 BV bounds    x[3559]
 BV bounds    x[3560]
 BV bounds    x[3561]
 BV bounds    x[3562]
 BV bounds    x[3563]
 BV bounds    x[3564]
 BV bounds    x[3565]
 BV bounds    x[3566]
 BV bounds    x[3567]
 BV bounds    x[3568]
 BV bounds    x[3569]
 BV bounds    x[3570]
 BV bounds    x[3571]
 BV bounds    x[3572]
 BV bounds    x[3573]
 BV bounds    x[3574]
 BV bounds    x[3575]
 BV bounds    x[3576]
 BV bounds    x[3577]
 BV bounds    x[3578]
 BV bounds    x[3579]
 BV bounds    x[3580]
 BV bounds    x[3581]
 BV bounds    x[3582]
 BV bounds    x[3583]
 BV bounds    x[3584]
 BV bounds    x[3585]
 BV bounds    x[3586]
 BV bounds    x[3587]
 BV bounds    x[3588]
 BV bounds    x[3589]
 BV bounds    x[3590]
 BV bounds    x[3591]
 BV bounds    x[3592]
 BV bounds    x[3593]
 BV bounds    x[3594]
 BV bounds    x[3595]
 BV bounds    x[3596]
 BV bounds    x[3597]
 BV bounds    x[3598]
 BV bounds    x[3599]
 BV bounds    x[3600]
 BV bounds    x[3601]
 BV bounds    x[3602]
 BV bounds    x[3603]
 BV bounds    x[3604]
 BV bounds    x[3605]
 BV bounds    x[3606]
 BV bounds    x[3607]
 BV bounds    x[3608]
 BV bounds    x[3609]
 BV bounds    x[3610]
 BV bounds    x[3611]
 BV bounds    x[3612]
 BV bounds    x[3613]
 BV bounds    x[3614]
 BV bounds    x[3615]
 BV bounds    x[3616]
 BV bounds    x[3617]
 BV bounds    x[3618]
 BV bounds    x[3619]
 BV bounds    x[3620]
 BV bounds    x[3621]
 BV bounds    x[3622]
 BV bounds    x[3623]
 BV bounds    x[3624]
 BV bounds    x[3625]
 BV bounds    x[3626]
 BV bounds    x[3627]
 BV bounds    x[3628]
 BV bounds    x[3629]
 BV bounds    x[3630]
 BV bounds    x[3631]
 BV bounds    x[3632]
 BV bounds    x[3633]
 BV bounds    x[3634]
 BV bounds    x[3635]
 BV bounds    x[3636]
 BV bounds    x[3637]
 BV bounds    x[3638]
 BV bounds    x[3639]
 BV bounds    x[3640]
 BV bounds    x[3641]
 BV bounds    x[3642]
 BV bounds    x[3643]
 BV bounds    x[3644]
 BV bounds    x[3645]
 BV bounds    x[3646]
 BV bounds    x[3647]
 BV bounds    x[3648]
 BV bounds    x[3649]
 BV bounds    x[3650]
 BV bounds    x[3651]
 BV bounds    x[3652]
 BV bounds    x[3653]
 BV bounds    x[3654]
 BV bounds    x[3655]
 BV bounds    x[3656]
 BV bounds    x[3657]
 BV bounds    x[3658]
 BV bounds    x[3659]
 BV bounds    x[3660]
 BV bounds    x[3661]
 BV bounds    x[3662]
 BV bounds    x[3663]
 BV bounds    x[3664]
 BV bounds    x[3665]
 BV bounds    x[3666]
 BV bounds    x[3667]
 BV bounds    x[3668]
 BV bounds    x[3669]
 BV bounds    x[3670]
 BV bounds    x[3671]
 BV bounds    x[3672]
 BV bounds    x[3673]
 BV bounds    x[3674]
 BV bounds    x[3675]
 BV bounds    x[3676]
 BV bounds    x[3677]
 BV bounds    x[3678]
 BV bounds    x[3679]
 BV bounds    x[3680]
 BV bounds    x[3681]
 BV bounds    x[3682]
 BV bounds    x[3683]
 BV bounds    x[3684]
 BV bounds    x[3685]
 BV bounds    x[3686]
 BV bounds    x[3687]
 BV bounds    x[3688]
 BV bounds    x[3689]
 BV bounds    x[3690]
 BV bounds    x[3691]
 BV bounds    x[3692]
 BV bounds    x[3693]
 BV bounds    x[3694]
 BV bounds    x[3695]
 BV bounds    x[3696]
 BV bounds    x[3697]
 BV bounds    x[3698]
 BV bounds    x[3699]
 BV bounds    x[3700]
 BV bounds    x[3701]
 BV bounds    x[3702]
 BV bounds    x[3703]
 BV bounds    x[3704]
 BV bounds    x[3705]
 BV bounds    x[3706]
 BV bounds    x[3707]
 BV bounds    x[3708]
 BV bounds    x[3709]
 BV bounds    x[3710]
ENDATA
