NAME
ROWS
 N  OBJ
 L  c1_1
 L  c2_1
 L  c3_1
 L  c4_1
 L  c5_1
 L  c6_1
 L  c7_1
 L  c8_1
 L  c9_1
 L  c10_1
 L  c11_1
 L  c12_1
 L  c13_1
 L  c14_1
 L  c15_1
 L  c16_1
 L  c17_1
 L  c18_1
 L  c19_1
 L  c20_1
 L  c21_1
 L  c22_1
 L  c23_1
 L  c24_1
 L  c25_1
 L  c26_1
 L  c27_1
 L  c28_1
 L  c29_1
 L  c30_1
 L  c31_1
 L  c32_1
 L  c33_1
 L  c34_1
 L  c35_1
 L  c36_1
 L  c37_1
 L  c38_1
 L  c39_1
 L  c40_1
 L  c41_1
 L  c42_1
 L  c43_1
 L  c44_1
 L  c45_1
 L  c46_1
 L  c47_1
 L  c48_1
 L  c49_1
 L  c50_1
 L  c51_1
 L  c52_1
 L  c53_1
 L  c54_1
 L  c55_1
 L  c56_1
 L  c57_1
 L  c58_1
 L  c59_1
 L  c60_1
 L  c61_1
 L  c62_1
 L  c63_1
 L  c64_1
 L  c65_1
 L  c66_1
 L  c67_1
 L  c68_1
 L  c69_1
 L  c70_1
 L  c71_1
 L  c72_1
 L  c73_1
 L  c74_1
 L  c75_1
 L  c76_1
 L  c77_1
 L  c78_1
 L  c79_1
 L  c80_1
 L  c81_1
 L  c82_1
 L  c83_1
 L  c84_1
 L  c85_1
 L  c86_1
 L  c87_1
 L  c88_1
 L  c89_1
 L  c90_1
 L  c91_1
 L  c92_1
 L  c93_1
 L  c94_1
 L  c95_1
 L  c96_1
 L  c97_1
 L  c98_1
 L  c99_1
 L  c100_1
 L  c101_1
 L  c102_1
 L  c103_1
 L  c104_1
 L  c105_1
 L  c106_1
 L  c107_1
 L  c108_1
 L  c109_1
 L  c110_1
 L  c111_1
 L  c112_1
 L  c113_1
 L  c114_1
 L  c115_1
 L  c116_1
 L  c117_1
 L  c118_1
 L  c119_1
 L  c120_1
 L  c121_1
 L  c122_1
 L  c123_1
 L  c124_1
 L  c125_1
 L  c126_1
 L  c127_1
 L  c128_1
 L  c129_1
 L  c130_1
 L  c131_1
 L  c132_1
 L  c133_1
 L  c134_1
 L  c135_1
 L  c136_1
 L  c137_1
 L  c138_1
 L  c139_1
 L  c140_1
 L  c141_1
 L  c142_1
 L  c143_1
 L  c144_1
 L  c145_1
 L  c146_1
 L  c147_1
 L  c148_1
 L  c149_1
 L  c150_1
 L  c151_1
 L  c152_1
 L  c153_1
 L  c154_1
 L  c155_1
 L  c156_1
 L  c157_1
 L  c158_1
 L  c159_1
 L  c160_1
 L  c161_1
 L  c162_1
 L  c163_1
 L  c164_1
 L  c165_1
 L  c166_1
 L  c167_1
 L  c168_1
 L  c169_1
 L  c170_1
 L  c171_1
 L  c172_1
 L  c173_1
 L  c174_1
 L  c175_1
 L  c176_1
 L  c177_1
 L  c178_1
 L  c179_1
 L  c180_1
 L  c181_1
 L  c182_1
 L  c183_1
 L  c184_1
 L  c185_1
 L  c186_1
 L  c187_1
 L  c188_1
 L  c189_1
 L  c190_1
 L  c191_1
 L  c192_1
 L  c193_1
 L  c194_1
 L  c195_1
 L  c196_1
 L  c197_1
 L  c198_1
 L  c199_1
 L  c200_1
 L  c201_1
 L  c202_1
 L  c203_1
 L  c204_1
 L  c205_1
 L  c206_1
 L  c207_1
 L  c208_1
 L  c209_1
 L  c210_1
 L  c211_1
 L  c212_1
 L  c213_1
 L  c214_1
 L  c215_1
 L  c216_1
 L  c217_1
 L  c218_1
 L  c219_1
 L  c220_1
 L  c221_1
 L  c222_1
 L  c223_1
 L  c224_1
 L  c225_1
 L  c226_1
 L  c227_1
 L  c228_1
 L  c229_1
 L  c230_1
 L  c231_1
 L  c232_1
 L  c233_1
 L  c234_1
 L  c235_1
 L  c236_1
 L  c237_1
 L  c238_1
 L  c239_1
 L  c240_1
 L  c241_1
 L  c242_1
 L  c243_1
 L  c244_1
 L  c245_1
 L  c246_1
 L  c247_1
 L  c248_1
 L  c249_1
 L  c250_1
 L  c251_1
 L  c252_1
 L  c253_1
 L  c254_1
 L  c255_1
 L  c256_1
 L  c257_1
 L  c258_1
 L  c259_1
 L  c260_1
 L  c261_1
 L  c262_1
 L  c263_1
 L  c264_1
 L  c265_1
 L  c266_1
 L  c267_1
 L  c268_1
 L  c269_1
 L  c270_1
 L  c271_1
 L  c272_1
 L  c273_1
 L  c274_1
 L  c275_1
 L  c276_1
 L  c277_1
 L  c278_1
 L  c279_1
 L  c280_1
 L  c281_1
 L  c282_1
 L  c283_1
 L  c284_1
 L  c285_1
 L  c286_1
 L  c287_1
 L  c288_1
 L  c289_1
 L  c290_1
 L  c291_1
 L  c292_1
 L  c293_1
 L  c294_1
 L  c295_1
 L  c296_1
 L  c297_1
 L  c298_1
 L  c299_1
 L  c300_1
 L  c301_1
 L  c302_1
 L  c303_1
 L  c304_1
 L  c305_1
 L  c306_1
 L  c307_1
 L  c308_1
 L  c309_1
 L  c310_1
 L  c311_1
 L  c312_1
 L  c313_1
 L  c314_1
 L  c315_1
 L  c316_1
 L  c317_1
 L  c318_1
 L  c319_1
 L  c320_1
 L  c321_1
 L  c322_1
 L  c323_1
 L  c324_1
 L  c325_1
 L  c326_1
 L  c327_1
 L  c328_1
 L  c329_1
 L  c330_1
 L  c331_1
 L  c332_1
 L  c333_1
 L  c334_1
 L  c335_1
 L  c336_1
 L  c337_1
 L  c338_1
 L  c339_1
 L  c340_1
 L  c341_1
 L  c342_1
 L  c343_1
 L  c344_1
 L  c345_1
 L  c346_1
 L  c347_1
 L  c348_1
 L  c349_1
 L  c350_1
 L  c351_1
 L  c352_1
 L  c353_1
 L  c354_1
 L  c355_1
 L  c356_1
 L  c357_1
 L  c358_1
 L  c359_1
 L  c360_1
 L  c361_1
 L  c362_1
 L  c363_1
 L  c364_1
 L  c365_1
 L  c366_1
 L  c367_1
 L  c368_1
 L  c369_1
 L  c370_1
 L  c371_1
 L  c372_1
 L  c373_1
 L  c374_1
 L  c375_1
 L  c376_1
 L  c377_1
 L  c378_1
 L  c379_1
 L  c380_1
 L  c381_1
 L  c382_1
 L  c383_1
 L  c384_1
 L  c385_1
 L  c386_1
 L  c387_1
 L  c388_1
 L  c389_1
 L  c390_1
 L  c391_1
 L  c392_1
 L  c393_1
 L  c394_1
 L  c395_1
 L  c396_1
 L  c397_1
 L  c398_1
 L  c399_1
 L  c400_1
 L  c401_1
 L  c402_1
 L  c403_1
 L  c404_1
 L  c405_1
 L  c406_1
 L  c407_1
 L  c408_1
 L  c409_1
 L  c410_1
 L  c411_1
 L  c412_1
 L  c413_1
 L  c414_1
 L  c415_1
 L  c416_1
 L  c417_1
 L  c418_1
 L  c419_1
 L  c420_1
 L  c421_1
 L  c422_1
 L  c423_1
 L  c424_1
 L  c425_1
 L  c426_1
 L  c427_1
 L  c428_1
 L  c429_1
 L  c430_1
 L  c431_1
 L  c432_1
 L  c433_1
 L  c434_1
 L  c435_1
 L  c436_1
 L  c437_1
 L  c438_1
 L  c439_1
 L  c440_1
 L  c441_1
 L  c442_1
 L  c443_1
 L  c444_1
 L  c445_1
 L  c446_1
 L  c447_1
 L  c448_1
 L  c449_1
 L  c450_1
 L  c451_1
 L  c452_1
 L  c453_1
 L  c454_1
 L  c455_1
 L  c456_1
 L  c457_1
 L  c458_1
 L  c459_1
 L  c460_1
 L  c461_1
 L  c462_1
 L  c463_1
 L  c464_1
 L  c465_1
 L  c466_1
 L  c467_1
 L  c468_1
 L  c469_1
 L  c470_1
 L  c471_1
 L  c472_1
 L  c473_1
 L  c474_1
 L  c475_1
 L  c476_1
 L  c477_1
 L  c478_1
 L  c479_1
 L  c480_1
 L  c481_1
 L  c482_1
 L  c483_1
 L  c484_1
 L  c485_1
 L  c486_1
 L  c487_1
 L  c488_1
 L  c489_1
 L  c490_1
 L  c491_1
 L  c492_1
 L  c493_1
 L  c494_1
 L  c495_1
 L  c496_1
 L  c497_1
 L  c498_1
 L  c499_1
 L  c500_1
 L  c501_1
 L  c502_1
 L  c503_1
 L  c504_1
 L  c505_1
 L  c506_1
 L  c507_1
 L  c508_1
 L  c509_1
 L  c510_1
 L  c511_1
 L  c512_1
 L  c513_1
 L  c514_1
 L  c515_1
 L  c516_1
 L  c517_1
 L  c518_1
 L  c519_1
 L  c520_1
 L  c521_1
 L  c522_1
 L  c523_1
 L  c524_1
 L  c525_1
 L  c526_1
 L  c527_1
 L  c528_1
 L  c529_1
 L  c530_1
 L  c531_1
 L  c532_1
 L  c533_1
 L  c534_1
 L  c535_1
 L  c536_1
 L  c537_1
 L  c538_1
 L  c539_1
 L  c540_1
 L  c541_1
 L  c542_1
 L  c543_1
 L  c544_1
 L  c545_1
 L  c546_1
 L  c547_1
 L  c548_1
 L  c549_1
 L  c550_1
 L  c551_1
 L  c552_1
 L  c553_1
 L  c554_1
 L  c555_1
 L  c556_1
 L  c557_1
 L  c558_1
 L  c559_1
 L  c560_1
 L  c561_1
 L  c562_1
 L  c563_1
 L  c564_1
 L  c565_1
 L  c566_1
 L  c567_1
 L  c568_1
 L  c569_1
 L  c570_1
 L  c571_1
 L  c572_1
 L  c573_1
 L  c574_1
 L  c575_1
 L  c576_1
 L  c577_1
 L  c578_1
 L  c579_1
 L  c580_1
 L  c581_1
 L  c582_1
 L  c583_1
 L  c584_1
 L  c585_1
 L  c586_1
 L  c587_1
 L  c588_1
 L  c589_1
 L  c590_1
 L  c591_1
 L  c592_1
 L  c593_1
 L  c594_1
 L  c595_1
 L  c596_1
 L  c597_1
 L  c598_1
 L  c599_1
 L  c600_1
 L  c601_1
 L  c602_1
 L  c603_1
 L  c604_1
 L  c605_1
 L  c606_1
 L  c607_1
 L  c608_1
 L  c609_1
 L  c610_1
 L  c611_1
 L  c612_1
 L  c613_1
 L  c614_1
 L  c615_1
 L  c616_1
 L  c617_1
 L  c618_1
 L  c619_1
 L  c620_1
 L  c621_1
 L  c622_1
 L  c623_1
 L  c624_1
 L  c625_1
 L  c626_1
 L  c627_1
 L  c628_1
 L  c629_1
 L  c630_1
 L  c631_1
 L  c632_1
 L  c633_1
 L  c634_1
 L  c635_1
 L  c636_1
 L  c637_1
 L  c638_1
 L  c639_1
 L  c640_1
 L  c641_1
 L  c642_1
 L  c643_1
 L  c644_1
 L  c645_1
 L  c646_1
 L  c647_1
 L  c648_1
 L  c649_1
 L  c650_1
 L  c651_1
 L  c652_1
 L  c653_1
 L  c654_1
 L  c655_1
 L  c656_1
 L  c657_1
 L  c658_1
 L  c659_1
 L  c660_1
 L  c661_1
 L  c662_1
 L  c663_1
 L  c664_1
 L  c665_1
 L  c666_1
 L  c667_1
 L  c668_1
 L  c669_1
 L  c670_1
 L  c671_1
 L  c672_1
 L  c673_1
 L  c674_1
 L  c675_1
 L  c676_1
 L  c677_1
 L  c678_1
 L  c679_1
 L  c680_1
 L  c681_1
 L  c682_1
 L  c683_1
 L  c684_1
 L  c685_1
 L  c686_1
 L  c687_1
 L  c688_1
 L  c689_1
 L  c690_1
 L  c691_1
 L  c692_1
 L  c693_1
 L  c694_1
 L  c695_1
 L  c696_1
 L  c697_1
 L  c698_1
 L  c699_1
 L  c700_1
 L  c701_1
 L  c702_1
 L  c703_1
 L  c704_1
 L  c705_1
 L  c706_1
 L  c707_1
 L  c708_1
 L  c709_1
 L  c710_1
 L  c711_1
 L  c712_1
 L  c713_1
 L  c714_1
 L  c715_1
 L  c716_1
 L  c717_1
 L  c718_1
 L  c719_1
 L  c720_1
 L  c721_1
 L  c722_1
 L  c723_1
 L  c724_1
 L  c725_1
 L  c726_1
 L  c727_1
 L  c728_1
 L  c729_1
 L  c730_1
 L  c731_1
 L  c732_1
 L  c733_1
 L  c734_1
 L  c735_1
 L  c736_1
 L  c737_1
 L  c738_1
 L  c739_1
 L  c740_1
 L  c741_1
 L  c742_1
 L  c743_1
 L  c744_1
 L  c745_1
 L  c746_1
 L  c747_1
 L  c748_1
 L  c749_1
 L  c750_1
 L  c751_1
 L  c752_1
 L  c753_1
 L  c754_1
 L  c755_1
 L  c756_1
 L  c757_1
 L  c758_1
 L  c759_1
 L  c760_1
 L  c761_1
 L  c762_1
 L  c763_1
 L  c764_1
 L  c765_1
 L  c766_1
 L  c767_1
 L  c768_1
 L  c769_1
 L  c770_1
 L  c771_1
 L  c772_1
 L  c773_1
 L  c774_1
 L  c775_1
 L  c776_1
 L  c777_1
 L  c778_1
 L  c779_1
 L  c780_1
 L  c781_1
 L  c782_1
 L  c783_1
 L  c784_1
 L  c785_1
 L  c786_1
 L  c787_1
 L  c788_1
 L  c789_1
 L  c790_1
 L  c791_1
 L  c792_1
 L  c793_1
 L  c794_1
 L  c795_1
 L  c796_1
 L  c797_1
 L  c798_1
 L  c799_1
 L  c800_1
 L  c801_1
 L  c802_1
 L  c803_1
 L  c804_1
 L  c805_1
 L  c806_1
 L  c807_1
 L  c808_1
 L  c809_1
 L  c810_1
 L  c811_1
 L  c812_1
 L  c813_1
 L  c814_1
 L  c815_1
 L  c816_1
 L  c817_1
 L  c818_1
 L  c819_1
 L  c820_1
 L  c821_1
 L  c822_1
 L  c823_1
 L  c824_1
 L  c825_1
 L  c826_1
 L  c827_1
 L  c828_1
 L  c829_1
 L  c830_1
 L  c831_1
 L  c832_1
 L  c833_1
 L  c834_1
 L  c835_1
 L  c836_1
 L  c837_1
 L  c838_1
 L  c839_1
 L  c840_1
 L  c841_1
 L  c842_1
 L  c843_1
 L  c844_1
 L  c845_1
 L  c846_1
 L  c847_1
 L  c848_1
 L  c849_1
 L  c850_1
 L  c851_1
 L  c852_1
 L  c853_1
 L  c854_1
 L  c855_1
 L  c856_1
 L  c857_1
 L  c858_1
 L  c859_1
 L  c860_1
 L  c861_1
 L  c862_1
 L  c863_1
 L  c864_1
 L  c865_1
 L  c866_1
 L  c867_1
 L  c868_1
 L  c869_1
 L  c870_1
 L  c871_1
 L  c872_1
 L  c873_1
 L  c874_1
 L  c875_1
 L  c876_1
 L  c877_1
 L  c878_1
 L  c879_1
 L  c880_1
 L  c881_1
 L  c882_1
 L  c883_1
 L  c884_1
 L  c885_1
 L  c886_1
 L  c887_1
 L  c888_1
 L  c889_1
 L  c890_1
 L  c891_1
 L  c892_1
 L  c893_1
 L  c894_1
 L  c895_1
 L  c896_1
 L  c897_1
 L  c898_1
 L  c899_1
 L  c900_1
 L  c901_1
 L  c902_1
 L  c903_1
 L  c904_1
 L  c905_1
 L  c906_1
 L  c907_1
 L  c908_1
 L  c909_1
 L  c910_1
 L  c911_1
 L  c912_1
 L  c913_1
 L  c914_1
 L  c915_1
 L  c916_1
 L  c917_1
 L  c918_1
 L  c919_1
 L  c920_1
 L  c921_1
 L  c922_1
 L  c923_1
 L  c924_1
 L  c925_1
 L  c926_1
 L  c927_1
 L  c928_1
 L  c929_1
 L  c930_1
 L  c931_1
 L  c932_1
 L  c933_1
 L  c934_1
 L  c935_1
 L  c936_1
 L  c937_1
 L  c938_1
 L  c939_1
 L  c940_1
 L  c941_1
 L  c942_1
 L  c943_1
 L  c944_1
 L  c945_1
 L  c946_1
 L  c947
 L  c948
 L  c949
 L  c950
 L  c951
 L  c952
 L  c953
 L  c954
 L  c955
 L  c956
 L  c957
 L  c958
 L  c959
 L  c960
 L  c961
 L  c962
 L  c963
 L  c964
 L  c965
 L  c966
 L  c967
 L  c968
 L  c969
 L  c970
 L  c971
 L  c972
 L  c973
 L  c974
 L  c975
 L  c976
 L  c977
 L  c978
 L  c979
 L  c980
 L  c981
 L  c982
 L  c983
 L  c984
 L  c985
 L  c986
 L  c987
 L  c988
 L  c989
 L  c990
 L  c991
 L  c992
 L  c993
 L  c994
 L  c995
 L  c996
 L  c997
 L  c998
 L  c999
 L  c1000
 L  c1001
 L  c1002
 L  c1003
 L  c1004
 L  c1005
 L  c1006
 L  c1007
 L  c1008
 L  c1009
 L  c1010
 L  c1011
 L  c1012
 L  c1013
 L  c1014
 L  c1015
 L  c1016
 L  c1017
 L  c1018
 L  c1019
 L  c1020
 L  c1021
 L  c1022
 L  c1023
 L  c1024
 L  c1025
 L  c1026
 L  c1027
 L  c1028
 L  c1029
 L  c1030
 L  c1031
 L  c1032
 L  c1033
 L  c1034
 L  c1035
 L  c1036
 L  c1037
 L  c1038
 L  c1039
 L  c1040
 L  c1041
 L  c1042
 L  c1043
 L  c1044
 L  c1045
 L  c1046
 L  c1047
 L  c1048
 L  c1049
 L  c1050
 L  c1051
 L  c1052
 L  c1053
 L  c1054
 L  c1055
 L  c1056
 L  c1057
 L  c1058
 L  c1059
 L  c1060
 L  c1061
 L  c1062
 L  c1063
 L  c1064
 L  c1065
 L  c1066
 L  c1067
 L  c1068
 L  c1069
 L  c1070
 L  c1071
 L  c1072
 L  c1073
 L  c1074
 L  c1075
 L  c1076
 L  c1077
 L  c1078
 L  c1079
 L  c1080
 L  c1081
 L  c1082
 L  c1083
 L  c1084
 L  c1085
 L  c1086
 L  c1087
 L  c1088
 L  c1089
 L  c1090
 L  c1091
 L  c1092
 L  c1093
 L  c1094
 L  c1095
 L  c1096
 L  c1097
 L  c1098
 L  c1099
 L  c1100
 L  c1101
 L  c1102
 L  c1103
 L  c1104
 L  c1105
 L  c1106
 L  c1107
 L  c1108
 L  c1109
 L  c1110
 L  c1111
 L  c1112
 L  c1113
 L  c1114
 L  c1115
 L  c1116
 L  c1117
 L  c1118
 L  c1119
 L  c1120
 L  c1121
 L  c1122
 L  c1123
 L  c1124
 L  c1125
 L  c1126
 L  c1127
 L  c1128
 L  c1129
 L  c1130
 L  c1131
 L  c1132
 L  c1133
 L  c1134
 L  c1135
 L  c1136
 L  c1137
 L  c1138
 L  c1139
 L  c1140
 L  c1141
 L  c1142
 L  c1143
 L  c1144
 L  c1145
 L  c1146
 L  c1147
 L  c1148
 L  c1149
 L  c1150
 L  c1151
 L  c1152
 L  c1153
 L  c1154
 L  c1155
 L  c1156
 L  c1157
 L  c1158
 L  c1159
 L  c1160
 L  c1161
 L  c1162
 L  c1163
 L  c1164
 L  c1165
 L  c1166
 L  c1167
 L  c1168
 L  c1169
 L  c1170
 L  c1171
 L  c1172
 L  c1173
 L  c1174
 L  c1175
 L  c1176
 L  c1177
 L  c1178
 L  c1179
 L  c1180
 L  c1181
 L  c1182
 L  c1183
 L  c1184
 L  c1185
 L  c1186
 L  c1187
 L  c1188
 L  c1189
 L  c1190
 L  c1191
 L  c1192
 L  c1193
 L  c1194
 L  c1195
 L  c1196
 L  c1197
 L  c1198
 L  c1199
 L  c1200
 L  c1201
 L  c1202
 L  c1203
 L  c1204
 L  c1205
 L  c1206
 L  c1207
 L  c1208
 L  c1209
 L  c1210
 L  c1211
 L  c1212
 L  c1213
 L  c1214
 L  c1215
 L  c1216
 L  c1217
 L  c1218
 L  c1219
 L  c1220
 L  c1221
 L  c1222
 L  c1223
 L  c1224
 L  c1225
 L  c1226
 L  c1227
 L  c1228
 L  c1229
 L  c1230
 L  c1231
 L  c1232
 L  c1233
 L  c1234
 L  c1235
 L  c1236
 L  c1237
 L  c1238
 L  c1239
 L  c1240
 L  c1241
 L  c1242
 L  c1243
 L  c1244
 L  c1245
 L  c1246
 L  c1247
 L  c1248
 L  c1249
 L  c1250
 L  c1251
 L  c1252
 L  c1253
 L  c1254
 L  c1255
 L  c1256
 L  c1257
 L  c1258
 L  c1259
 L  c1260
 L  c1261
 L  c1262
 L  c1263
 L  c1264
 L  c1265
 L  c1266
 L  c1267
 L  c1268
 L  c1269
 L  c1270
 L  c1271
 L  c1272
 L  c1273
 L  c1274
 L  c1275
 L  c1276
 L  c1277
 L  c1278
 L  c1279
 L  c1280
 L  c1281
 L  c1282
 L  c1283
 L  c1284
 L  c1285
 L  c1286
 L  c1287
 L  c1288
 L  c1289
 L  c1290
 L  c1291
 L  c1292
 L  c1293
 L  c1294
 L  c1295
 L  c1296
 L  c1297
 L  c1298
 L  c1299
 L  c1300
 L  c1301
 L  c1302
 L  c1303
 L  c1304
 L  c1305
 L  c1306
 L  c1307
 L  c1308
 L  c1309
 L  c1310
 L  c1311
 L  c1312
 L  c1313
 L  c1314
 L  c1315
 L  c1316
 L  c1317
 L  c1318
 L  c1319
 L  c1320
 L  c1321
 L  c1322
 L  c1323
 L  c1324
 L  c1325
 L  c1326
 L  c1327
 L  c1328
 L  c1329
 L  c1330
 L  c1331
 L  c1332
 L  c1333
 L  c1334
 L  c1335
 L  c1336
 L  c1337
 L  c1338
 L  c1339
 L  c1340
 L  c1341
 L  c1342
 L  c1343
 L  c1344
 L  c1345
 L  c1346
 L  c1347
 L  c1348
 L  c1349
 L  c1350
 L  c1351
 L  c1352
 L  c1353
 L  c1354
 L  c1355
 L  c1356
 L  c1357
 L  c1358
 L  c1359
 L  c1360
 L  c1361
 L  c1362
 L  c1363
 L  c1364
 L  c1365
 L  c1366
 L  c1367
 L  c1368
 L  c1369
 L  c1370
 L  c1371
 L  c1372
 L  c1373
 L  c1374
 L  c1375
 L  c1376
 L  c1377
 L  c1378
 L  c1379
 L  c1380
 L  c1381
 L  c1382
 L  c1383
 L  c1384
 L  c1385
 L  c1386
 L  c1387
 L  c1388
 L  c1389
 L  c1390
 L  c1391
 L  c1392
 L  c1393
 L  c1394
 L  c1395
 L  c1396
 L  c1397
 L  c1398
 L  c1399
 L  c1400
 L  c1401
 L  c1402
 L  c1403
 L  c1404
 L  c1405
 L  c1406
 L  c1407
 L  c1408
 L  c1409
 L  c1410
 L  c1411
 L  c1412
 L  c1413
 L  c1414
 L  c1415
 L  c1416
 L  c1417
 L  c1418
 L  c1419
 L  c1420
 L  c1421
 L  c1422
 L  c1423
 L  c1424
 L  c1425
 L  c1426
 L  c1427
 L  c1428
 L  c1429
 L  c1430
 L  c1431
 L  c1432
 L  c1433
 L  c1434
 L  c1435
 L  c1436
 L  c1437
 L  c1438
 L  c1439
 L  c1440
 L  c1441
 L  c1442
 L  c1443
 L  c1444
 L  c1445
 L  c1446
 L  c1447
 L  c1448
 L  c1449
 L  c1450
 L  c1451
 L  c1452
 L  c1453
 L  c1454
 L  c1455
 L  c1456
 L  c1457
 L  c1458
 L  c1459
 L  c1460
 L  c1461
 L  c1462
 L  c1463
 L  c1464
 L  c1465
 L  c1466
 L  c1467
 L  c1468
 L  c1469
 L  c1470
 L  c1471
 L  c1472
 L  c1473
 L  c1474
 L  c1475
 L  c1476
 L  c1477
 L  c1478
 L  c1479
 L  c1480
 L  c1481
 L  c1482
 L  c1483
 L  c1484
 L  c1485
 L  c1486
 L  c1487
 L  c1488
 L  c1489
 L  c1490
 L  c1491
 L  c1492
 L  c1493
 L  c1494
 L  c1495
 L  c1496
 L  c1497
 L  c1498
 L  c1499
 L  c1500
 L  c1501
 L  c1502
 L  c1503
 L  c1504
 L  c1505
 L  c1506
 L  c1507
 L  c1508
 L  c1509
 L  c1510
 L  c1511
 L  c1512
 L  c1513
 L  c1514
 L  c1515
 L  c1516
 L  c1517
 L  c1518
 L  c1519
 L  c1520
 L  c1521
 L  c1522
 L  c1523
 L  c1524
 L  c1525
 L  c1526
 L  c1527
 L  c1528
 L  c1529
 L  c1530
 L  c1531
 L  c1532
 L  c1533
 L  c1534
 L  c1535
 L  c1536
 L  c1537
 L  c1538
 L  c1539
 L  c1540
 L  c1541
 L  c1542
 L  c1543
 L  c1544
 L  c1545
 L  c1546
 L  c1547
 L  c1548
 L  c1549
 L  c1550
 L  c1551
 L  c1552
 L  c1553
 L  c1554
 L  c1555
 L  c1556
 L  c1557
 L  c1558
 L  c1559
 L  c1560
 L  c1561
 L  c1562
 L  c1563
 L  c1564
 L  c1565
 L  c1566
 L  c1567
 L  c1568
 L  c1569
 L  c1570
 L  c1571
 L  c1572
 L  c1573
 L  c1574
 L  c1575
 L  c1576
 L  c1577
 L  c1578
 L  c1579
 L  c1580
 L  c1581
 L  c1582
 L  c1583
 L  c1584
 L  c1585
 L  c1586
 L  c1587
 L  c1588
 L  c1589
 L  c1590
 L  c1591
 L  c1592
 L  c1593
 L  c1594
 L  c1595
 L  c1596
 L  c1597
 L  c1598
 L  c1599
 L  c1600
 L  c1601
 L  c1602
 L  c1603
 L  c1604
 L  c1605
 L  c1606
 L  c1607
 L  c1608
 L  c1609
 L  c1610
 L  c1611
 L  c1612
 L  c1613
 L  c1614
 L  c1615
 L  c1616
 L  c1617
 L  c1618
 L  c1619
 L  c1620
 L  c1621
 L  c1622
 L  c1623
 L  c1624
 L  c1625
 L  c1626
 L  c1627
 L  c1628
 L  c1629
 L  c1630
 L  c1631
 L  c1632
 L  c1633
 L  c1634
 L  c1635
 L  c1636
 L  c1637
 L  c1638
 L  c1639
 L  c1640
 L  c1641
 L  c1642
 L  c1643
 L  c1644
 L  c1645
 L  c1646
 L  c1647
 L  c1648
 L  c1649
 L  c1650
 L  c1651
 L  c1652
 L  c1653
 L  c1654
 L  c1655
 L  c1656
 L  c1657
 L  c1658
 L  c1659
 L  c1660
 L  c1661
 L  c1662
 L  c1663
 L  c1664
 L  c1665
 L  c1666
 L  c1667
 L  c1668
 L  c1669
 L  c1670
 L  c1671
 L  c1672
 L  c1673
 L  c1674
 L  c1675
 L  c1676
 L  c1677
 L  c1678
 L  c1679
 L  c1680
 L  c1681
 L  c1682
 L  c1683
 L  c1684
 L  c1685
 L  c1686
 L  c1687
 L  c1688
 L  c1689
 L  c1690
 L  c1691
 L  c1692
 L  c1693
 L  c1694
 L  c1695
 L  c1696
 L  c1697
 L  c1698
 L  c1699
 L  c1700
 L  c1701
 L  c1702
 L  c1703
 L  c1704
 L  c1705
 L  c1706
 L  c1707
 L  c1708
 L  c1709
 L  c1710
 L  c1711
 L  c1712
 L  c1713
 L  c1714
 L  c1715
 L  c1716
 L  c1717
 L  c1718
 L  c1719
 L  c1720
 L  c1721
 L  c1722
 L  c1723
 L  c1724
 L  c1725
 L  c1726
 L  c1727
 L  c1728
 L  c1729
 L  c1730
 L  c1731
 L  c1732
 L  c1733
 L  c1734
 L  c1735
 L  c1736
 L  c1737
 L  c1738
 L  c1739
 L  c1740
 L  c1741
 L  c1742
 L  c1743
 L  c1744
 L  c1745
 L  c1746
 L  c1747
 L  c1748
 L  c1749
 L  c1750
 L  c1751
 L  c1752
 L  c1753
 L  c1754
 L  c1755
 L  c1756
 L  c1757
 L  c1758
 L  c1759
 L  c1760
 L  c1761
 L  c1762
 L  c1763
 L  c1764
 L  c1765
 L  c1766
 L  c1767
 L  c1768
 L  c1769
 L  c1770
 L  c1771
 L  c1772
 L  c1773
 L  c1774
 L  c1775
 L  c1776
 L  c1777
 L  c1778
 L  c1779
 L  c1780
 L  c1781
 L  c1782
 L  c1783
 L  c1784
 L  c1785
 L  c1786
 L  c1787
 L  c1788
 L  c1789
 L  c1790
 L  c1791
 L  c1792
 L  c1793
 L  c1794
 L  c1795
 L  c1796
 L  c1797
 L  c1798
 L  c1799
 L  c1800
 L  c1801
 L  c1802
 L  c1803
 L  c1804
 L  c1805
 L  c1806
 L  c1807
 L  c1808
 L  c1809
 L  c1810
 L  c1811
 L  c1812
 L  c1813
 L  c1814
 L  c1815
 L  c1816
 L  c1817
 L  c1818
 L  c1819
 L  c1820
 L  c1821
 L  c1822
 L  c1823
 L  c1824
 L  c1825
 L  c1826
 L  c1827
 L  c1828
 L  c1829
 L  c1830
 L  c1831
 L  c1832
 L  c1833
 L  c1834
 L  c1835
 L  c1836
 L  c1837
 L  c1838
 L  c1839
 L  c1840
 L  c1841
 L  c1842
 L  c1843
 L  c1844
 L  c1845
 L  c1846
 L  c1847
 L  c1848
 L  c1849
 L  c1850
 L  c1851
 L  c1852
 L  c1853
 L  c1854
 L  c1855
 L  c1856
 L  c1857
 L  c1858
 L  c1859
 L  c1860
 L  c1861
 L  c1862
 L  c1863
 L  c1864
 L  c1865
 L  c1866
 L  c1867
 L  c1868
 L  c1869
 L  c1870
 L  c1871
 L  c1872
 L  c1873
 L  c1874
 L  c1875
 L  c1876
 L  c1877
 L  c1878
 L  c1879
 L  c1880
 L  c1881
 L  c1882
 L  c1883
 L  c1884
 L  c1885
 L  c1886
 L  c1887
 L  c1888
 L  c1889
 L  c1890
 L  c1891
 L  c1892
 L  c1893
 L  c1894
 L  c1895
 L  c1896
 L  c1897
 L  c1898
 L  c1899
 L  c1900
 L  c1901
 L  c1902
 L  c1903
 L  c1904
 L  c1905
 L  c1906
 L  c1907
 L  c1908
 L  c1909
 L  c1910
 L  c1911
 L  c1912
 L  c1913
 L  c1914
 L  c1915
 L  c1916
 L  c1917
 L  c1918
 L  c1919
 L  c1920
 L  c1921
 L  c1922
 L  c1923
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
 E  c625
 E  c626
 E  c627
 E  c628
 E  c629
 E  c630
 E  c631
 E  c632
 E  c633
 E  c634
 E  c635
 E  c636
 E  c637
 E  c638
 E  c639
 E  c640
 E  c641
 E  c642
 E  c643
 E  c644
 E  c645
 E  c646
 E  c647
 E  c648
 E  c649
 E  c650
 E  c651
 E  c652
 E  c653
 E  c654
 E  c655
 E  c656
 E  c657
 E  c658
 E  c659
 E  c660
 E  c661
 E  c662
 E  c663
 E  c664
 E  c665
 E  c666
 E  c667
 E  c668
 E  c669
 E  c670
 E  c671
 E  c672
 E  c673
 E  c674
 E  c675
 E  c676
 E  c677
 E  c678
 E  c679
 E  c680
 E  c681
 E  c682
 E  c683
 E  c684
 E  c685
 E  c686
 E  c687
 E  c688
 E  c689
 E  c690
 E  c691
 E  c692
 E  c693
 E  c694
 E  c695
 E  c696
 E  c697
 E  c698
 E  c699
 E  c700
 E  c701
 E  c702
 E  c703
 E  c704
 E  c705
 E  c706
 E  c707
 E  c708
 E  c709
 E  c710
 E  c711
 E  c712
 E  c713
 E  c714
 E  c715
 E  c716
 E  c717
 E  c718
 E  c719
 E  c720
 E  c721
 E  c722
 E  c723
 E  c724
 E  c725
 E  c726
 E  c727
 E  c728
 E  c729
 E  c730
 E  c731
 E  c732
 E  c733
 E  c734
 E  c735
 E  c736
 E  c737
 E  c738
 E  c739
 E  c740
 E  c741
 E  c742
 E  c743
 E  c744
 E  c745
 E  c746
 E  c747
 E  c748
 E  c749
 E  c750
 E  c751
 E  c752
 E  c753
 E  c754
 E  c755
 E  c756
 E  c757
 E  c758
 E  c759
 E  c760
 E  c761
 E  c762
 E  c763
 E  c764
 E  c765
 E  c766
 E  c767
 E  c768
 E  c769
 E  c770
 E  c771
 E  c772
 E  c773
 E  c774
 E  c775
 E  c776
 E  c777
 E  c778
 E  c779
 E  c780
 E  c781
 E  c782
 E  c783
 E  c784
 E  c785
 E  c786
 E  c787
 E  c788
 E  c789
 E  c790
 E  c791
 E  c792
 E  c793
 E  c794
 E  c795
 E  c796
 E  c797
 E  c798
 E  c799
 E  c800
 E  c801
 E  c802
 E  c803
 E  c804
 E  c805
 E  c806
 E  c807
 E  c808
 E  c809
 E  c810
 E  c811
 E  c812
 E  c813
 E  c814
 E  c815
 E  c816
 E  c817
 E  c818
 E  c819
 E  c820
 E  c821
 E  c822
 E  c823
 E  c824
 E  c825
 E  c826
 E  c827
 E  c828
 E  c829
 E  c830
 E  c831
 E  c832
 E  c833
 E  c834
 E  c835
 E  c836
 E  c837
 E  c838
 E  c839
 E  c840
 E  c841
 E  c842
 E  c843
 E  c844
 E  c845
 E  c846
 E  c847
 E  c848
 E  c849
 E  c850
 E  c851
 E  c852
 E  c853
 E  c854
 E  c855
 E  c856
 E  c857
 E  c858
 E  c859
 E  c860
 E  c861
 E  c862
 E  c863
 E  c864
 E  c865
 E  c866
 E  c867
 E  c868
 E  c869
 E  c870
 E  c871
 E  c872
 E  c873
 E  c874
 E  c875
 E  c876
 E  c877
 E  c878
 E  c879
 E  c880
 E  c881
 E  c882
 E  c883
 E  c884
 E  c885
 E  c886
 E  c887
 E  c888
 E  c889
 E  c890
 E  c891
 E  c892
 E  c893
 E  c894
 E  c895
 E  c896
 E  c897
 E  c898
 E  c899
 E  c900
 E  c901
 E  c902
 E  c903
 E  c904
 E  c905
 E  c906
 E  c907
 E  c908
 E  c909
 E  c910
 E  c911
 E  c912
 E  c913
 E  c914
 E  c915
 E  c916
 E  c917
 E  c918
 E  c919
 E  c920
 E  c921
 E  c922
 E  c923
 E  c924
 E  c925
 E  c926
 E  c927
 E  c928
 E  c929
 E  c930
 E  c931
 E  c932
 E  c933
 E  c934
 E  c935
 E  c936
 E  c937
 E  c938
 E  c939
 E  c940
 E  c941
 E  c942
 E  c943
 E  c944
 E  c945
 E  c946
COLUMNS
    x[1]      c202      1
    x[1]      OBJ       1
    x[2]      c31       1
    x[2]      c202      -1000
    MARKER    'MARKER'                 'INTORG'
    x[3]      c1_1      1
    x[3]      c481_1    1
    x[3]      c31       1
    x[3]      c202      -1
    x[4]      c2_1      1
    x[4]      c482_1    1
    x[4]      c31       1
    x[4]      c202      -1
    x[5]      c3_1      1
    x[5]      c483_1    1
    x[5]      c31       1
    x[5]      c202      -1
    x[6]      c4_1      1
    x[6]      c484_1    1
    x[6]      c31       1
    x[6]      c202      -1
    x[7]      c5_1      1
    x[7]      c485_1    1
    x[7]      c31       1
    x[7]      c202      -1
    x[8]      c1_1      1
    x[8]      c486_1    1
    x[8]      c31       1
    x[8]      c202      -2
    x[9]      c2_1      1
    x[9]      c487_1    1
    x[9]      c31       1
    x[9]      c202      -2
    x[10]     c3_1      1
    x[10]     c488_1    1
    x[10]     c31       1
    x[10]     c202      -2
    x[11]     c4_1      1
    x[11]     c489_1    1
    x[11]     c31       1
    x[11]     c202      -2
    x[12]     c5_1      1
    x[12]     c490_1    1
    x[12]     c31       1
    x[12]     c202      -2
    x[13]     c1_1      1
    x[13]     c491_1    1
    x[13]     c31       1
    x[13]     c202      -3
    x[14]     c2_1      1
    x[14]     c492_1    1
    x[14]     c31       1
    x[14]     c202      -3
    x[15]     c3_1      1
    x[15]     c493_1    1
    x[15]     c31       1
    x[15]     c202      -3
    x[16]     c4_1      1
    x[16]     c494_1    1
    x[16]     c31       1
    x[16]     c202      -3
    x[17]     c5_1      1
    x[17]     c495_1    1
    x[17]     c31       1
    x[17]     c202      -3
    x[18]     c6_1      1
    x[18]     c496_1    1
    x[18]     c31       1
    x[18]     c202      -1
    x[19]     c7_1      1
    x[19]     c497_1    1
    x[19]     c31       1
    x[19]     c202      -1
    x[20]     c8_1      1
    x[20]     c498_1    1
    x[20]     c31       1
    x[20]     c202      -1
    x[21]     c9_1      1
    x[21]     c499_1    1
    x[21]     c31       1
    x[21]     c202      -1
    x[22]     c10_1     1
    x[22]     c500_1    1
    x[22]     c31       1
    x[22]     c202      -1
    x[23]     c6_1      1
    x[23]     c501_1    1
    x[23]     c31       1
    x[23]     c202      -3
    x[24]     c7_1      1
    x[24]     c502_1    1
    x[24]     c31       1
    x[24]     c202      -3
    x[25]     c8_1      1
    x[25]     c503_1    1
    x[25]     c31       1
    x[25]     c202      -3
    x[26]     c9_1      1
    x[26]     c504_1    1
    x[26]     c31       1
    x[26]     c202      -3
    x[27]     c10_1     1
    x[27]     c505_1    1
    x[27]     c31       1
    x[27]     c202      -3
    x[28]     c6_1      1
    x[28]     c32       1
    x[28]     c629      -1
    x[28]     c635      -1
    x[29]     c7_1      1
    x[29]     c33       1
    x[29]     c639      -1
    x[29]     c643      -1
    x[30]     c8_1      1
    x[30]     c34       1
    x[30]     c647      -1
    x[30]     c651      -1
    x[31]     c9_1      1
    x[31]     c35       1
    x[31]     c655      -1
    x[31]     c659      -1
    x[32]     c10_1     1
    x[32]     c36       1
    x[32]     c663      -1
    x[32]     c667      -1
    x[33]     c6_1      1
    x[33]     c506_1    1
    x[33]     c31       1
    x[33]     c202      -2
    x[34]     c7_1      1
    x[34]     c507_1    1
    x[34]     c31       1
    x[34]     c202      -2
    x[35]     c8_1      1
    x[35]     c508_1    1
    x[35]     c31       1
    x[35]     c202      -2
    x[36]     c9_1      1
    x[36]     c509_1    1
    x[36]     c31       1
    x[36]     c202      -2
    x[37]     c10_1     1
    x[37]     c510_1    1
    x[37]     c31       1
    x[37]     c202      -2
    x[38]     c11_1     1
    x[38]     c511_1    1
    x[38]     c31       1
    x[38]     c202      -1
    x[39]     c12_1     1
    x[39]     c512_1    1
    x[39]     c31       1
    x[39]     c202      -1
    x[40]     c13_1     1
    x[40]     c513_1    1
    x[40]     c31       1
    x[40]     c202      -1
    x[41]     c14_1     1
    x[41]     c514_1    1
    x[41]     c31       1
    x[41]     c202      -1
    x[42]     c15_1     1
    x[42]     c515_1    1
    x[42]     c31       1
    x[42]     c202      -1
    x[43]     c11_1     1
    x[43]     c516_1    1
    x[43]     c31       1
    x[43]     c202      -3
    x[44]     c12_1     1
    x[44]     c517_1    1
    x[44]     c31       1
    x[44]     c202      -3
    x[45]     c13_1     1
    x[45]     c518_1    1
    x[45]     c31       1
    x[45]     c202      -3
    x[46]     c14_1     1
    x[46]     c519_1    1
    x[46]     c31       1
    x[46]     c202      -3
    x[47]     c15_1     1
    x[47]     c520_1    1
    x[47]     c31       1
    x[47]     c202      -3
    x[48]     c11_1     1
    x[48]     c521_1    1
    x[48]     c31       1
    x[48]     c202      -2
    x[49]     c12_1     1
    x[49]     c522_1    1
    x[49]     c31       1
    x[49]     c202      -2
    x[50]     c13_1     1
    x[50]     c523_1    1
    x[50]     c31       1
    x[50]     c202      -2
    x[51]     c14_1     1
    x[51]     c524_1    1
    x[51]     c31       1
    x[51]     c202      -2
    x[52]     c15_1     1
    x[52]     c525_1    1
    x[52]     c31       1
    x[52]     c202      -2
    x[53]     c16_1     1
    x[53]     c526_1    1
    x[53]     c31       1
    x[53]     c202      -3
    x[54]     c17_1     1
    x[54]     c527_1    1
    x[54]     c31       1
    x[54]     c202      -3
    x[55]     c18_1     1
    x[55]     c528_1    1
    x[55]     c31       1
    x[55]     c202      -3
    x[56]     c19_1     1
    x[56]     c529_1    1
    x[56]     c31       1
    x[56]     c202      -3
    x[57]     c20_1     1
    x[57]     c530_1    1
    x[57]     c31       1
    x[57]     c202      -3
    x[58]     c16_1     1
    x[58]     c531_1    1
    x[58]     c31       1
    x[58]     c202      -1
    x[59]     c17_1     1
    x[59]     c532_1    1
    x[59]     c31       1
    x[59]     c202      -1
    x[60]     c18_1     1
    x[60]     c533_1    1
    x[60]     c31       1
    x[60]     c202      -1
    x[61]     c19_1     1
    x[61]     c534_1    1
    x[61]     c31       1
    x[61]     c202      -1
    x[62]     c20_1     1
    x[62]     c535_1    1
    x[62]     c31       1
    x[62]     c202      -1
    x[63]     c16_1     1
    x[63]     c536_1    1
    x[63]     c31       1
    x[63]     c202      -2
    x[64]     c17_1     1
    x[64]     c537_1    1
    x[64]     c31       1
    x[64]     c202      -2
    x[65]     c18_1     1
    x[65]     c538_1    1
    x[65]     c31       1
    x[65]     c202      -2
    x[66]     c19_1     1
    x[66]     c539_1    1
    x[66]     c31       1
    x[66]     c202      -2
    x[67]     c20_1     1
    x[67]     c540_1    1
    x[67]     c31       1
    x[67]     c202      -2
    x[68]     c21_1     1
    x[68]     c541_1    1
    x[68]     c31       1
    x[68]     c202      -2
    x[69]     c22_1     1
    x[69]     c542_1    1
    x[69]     c31       1
    x[69]     c202      -2
    x[70]     c23_1     1
    x[70]     c543_1    1
    x[70]     c31       1
    x[70]     c202      -2
    x[71]     c24_1     1
    x[71]     c544_1    1
    x[71]     c31       1
    x[71]     c202      -2
    x[72]     c25_1     1
    x[72]     c545_1    1
    x[72]     c31       1
    x[72]     c202      -2
    x[73]     c21_1     1
    x[73]     c546_1    1
    x[73]     c31       1
    x[73]     c202      -3
    x[74]     c22_1     1
    x[74]     c547_1    1
    x[74]     c31       1
    x[74]     c202      -3
    x[75]     c23_1     1
    x[75]     c548_1    1
    x[75]     c31       1
    x[75]     c202      -3
    x[76]     c24_1     1
    x[76]     c549_1    1
    x[76]     c31       1
    x[76]     c202      -3
    x[77]     c25_1     1
    x[77]     c550_1    1
    x[77]     c31       1
    x[77]     c202      -3
    x[78]     c21_1     1
    x[78]     c551_1    1
    x[78]     c31       1
    x[78]     c202      -1
    x[79]     c22_1     1
    x[79]     c552_1    1
    x[79]     c31       1
    x[79]     c202      -1
    x[80]     c23_1     1
    x[80]     c553_1    1
    x[80]     c31       1
    x[80]     c202      -1
    x[81]     c24_1     1
    x[81]     c554_1    1
    x[81]     c31       1
    x[81]     c202      -1
    x[82]     c25_1     1
    x[82]     c555_1    1
    x[82]     c31       1
    x[82]     c202      -1
    x[83]     c26_1     1
    x[83]     c556_1    1
    x[83]     c31       1
    x[83]     c202      -1
    x[84]     c27_1     1
    x[84]     c557_1    1
    x[84]     c31       1
    x[84]     c202      -1
    x[85]     c28_1     1
    x[85]     c558_1    1
    x[85]     c31       1
    x[85]     c202      -1
    x[86]     c29_1     1
    x[86]     c559_1    1
    x[86]     c31       1
    x[86]     c202      -1
    x[87]     c30_1     1
    x[87]     c560_1    1
    x[87]     c31       1
    x[87]     c202      -1
    x[88]     c26_1     1
    x[88]     c561_1    1
    x[88]     c31       1
    x[88]     c202      -2
    x[89]     c27_1     1
    x[89]     c562_1    1
    x[89]     c31       1
    x[89]     c202      -2
    x[90]     c28_1     1
    x[90]     c563_1    1
    x[90]     c31       1
    x[90]     c202      -2
    x[91]     c29_1     1
    x[91]     c564_1    1
    x[91]     c31       1
    x[91]     c202      -2
    x[92]     c30_1     1
    x[92]     c565_1    1
    x[92]     c31       1
    x[92]     c202      -2
    x[93]     c26_1     1
    x[93]     c566_1    1
    x[93]     c31       1
    x[93]     c202      -3
    x[94]     c27_1     1
    x[94]     c567_1    1
    x[94]     c31       1
    x[94]     c202      -3
    x[95]     c28_1     1
    x[95]     c568_1    1
    x[95]     c31       1
    x[95]     c202      -3
    x[96]     c29_1     1
    x[96]     c569_1    1
    x[96]     c31       1
    x[96]     c202      -3
    x[97]     c30_1     1
    x[97]     c570_1    1
    x[97]     c31       1
    x[97]     c202      -3
    x[98]     c31_1     1
    x[98]     c571_1    1
    x[98]     c31       1
    x[98]     c202      -3
    x[99]     c32_1     1
    x[99]     c572_1    1
    x[99]     c31       1
    x[99]     c202      -3
    x[100]    c33_1     1
    x[100]    c573_1    1
    x[100]    c31       1
    x[100]    c202      -3
    x[101]    c34_1     1
    x[101]    c574_1    1
    x[101]    c31       1
    x[101]    c202      -3
    x[102]    c35_1     1
    x[102]    c575_1    1
    x[102]    c31       1
    x[102]    c202      -3
    x[103]    c31_1     1
    x[103]    c37       1
    x[103]    c772      -1
    x[103]    c778      -1
    x[104]    c32_1     1
    x[104]    c38       1
    x[104]    c781      -1
    x[104]    c787      -1
    x[104]    c789      -1
    x[105]    c33_1     1
    x[105]    c39       1
    x[105]    c792      -1
    x[105]    c795      -1
    x[106]    c34_1     1
    x[106]    c40       1
    x[106]    c798      -1
    x[106]    c801      -1
    x[107]    c35_1     1
    x[107]    c41       1
    x[107]    c804      -1
    x[107]    c807      -1
    x[108]    c31_1     1
    x[108]    c576_1    1
    x[108]    c31       1
    x[108]    c202      -1
    x[109]    c32_1     1
    x[109]    c577_1    1
    x[109]    c31       1
    x[109]    c202      -1
    x[110]    c33_1     1
    x[110]    c578_1    1
    x[110]    c31       1
    x[110]    c202      -1
    x[111]    c34_1     1
    x[111]    c579_1    1
    x[111]    c31       1
    x[111]    c202      -1
    x[112]    c35_1     1
    x[112]    c580_1    1
    x[112]    c31       1
    x[112]    c202      -1
    x[113]    c31_1     1
    x[113]    c581_1    1
    x[113]    c31       1
    x[113]    c202      -2
    x[114]    c32_1     1
    x[114]    c582_1    1
    x[114]    c31       1
    x[114]    c202      -2
    x[115]    c33_1     1
    x[115]    c583_1    1
    x[115]    c31       1
    x[115]    c202      -2
    x[116]    c34_1     1
    x[116]    c584_1    1
    x[116]    c31       1
    x[116]    c202      -2
    x[117]    c35_1     1
    x[117]    c585_1    1
    x[117]    c31       1
    x[117]    c202      -2
    x[118]    c36_1     1
    x[118]    c586_1    1
    x[118]    c31       1
    x[118]    c202      -3
    x[119]    c37_1     1
    x[119]    c587_1    1
    x[119]    c31       1
    x[119]    c202      -3
    x[120]    c38_1     1
    x[120]    c588_1    1
    x[120]    c31       1
    x[120]    c202      -3
    x[121]    c39_1     1
    x[121]    c589_1    1
    x[121]    c31       1
    x[121]    c202      -3
    x[122]    c40_1     1
    x[122]    c590_1    1
    x[122]    c31       1
    x[122]    c202      -3
    x[123]    c36_1     1
    x[123]    c591_1    1
    x[123]    c31       1
    x[123]    c202      -2
    x[124]    c37_1     1
    x[124]    c592_1    1
    x[124]    c31       1
    x[124]    c202      -2
    x[125]    c38_1     1
    x[125]    c593_1    1
    x[125]    c31       1
    x[125]    c202      -2
    x[126]    c39_1     1
    x[126]    c594_1    1
    x[126]    c31       1
    x[126]    c202      -2
    x[127]    c40_1     1
    x[127]    c595_1    1
    x[127]    c31       1
    x[127]    c202      -2
    x[128]    c36_1     1
    x[128]    c596_1    1
    x[128]    c31       1
    x[128]    c202      -1
    x[129]    c37_1     1
    x[129]    c597_1    1
    x[129]    c31       1
    x[129]    c202      -1
    x[130]    c38_1     1
    x[130]    c598_1    1
    x[130]    c31       1
    x[130]    c202      -1
    x[131]    c39_1     1
    x[131]    c599_1    1
    x[131]    c31       1
    x[131]    c202      -1
    x[132]    c40_1     1
    x[132]    c600_1    1
    x[132]    c31       1
    x[132]    c202      -1
    x[133]    c41_1     1
    x[133]    c601_1    1
    x[133]    c31       1
    x[133]    c202      -1
    x[134]    c42_1     1
    x[134]    c602_1    1
    x[134]    c31       1
    x[134]    c202      -1
    x[135]    c43_1     1
    x[135]    c603_1    1
    x[135]    c31       1
    x[135]    c202      -1
    x[136]    c44_1     1
    x[136]    c604_1    1
    x[136]    c31       1
    x[136]    c202      -1
    x[137]    c45_1     1
    x[137]    c605_1    1
    x[137]    c31       1
    x[137]    c202      -1
    x[138]    c41_1     1
    x[138]    c606_1    1
    x[138]    c31       1
    x[138]    c202      -3
    x[139]    c42_1     1
    x[139]    c607_1    1
    x[139]    c31       1
    x[139]    c202      -3
    x[140]    c43_1     1
    x[140]    c608_1    1
    x[140]    c31       1
    x[140]    c202      -3
    x[141]    c44_1     1
    x[141]    c609_1    1
    x[141]    c31       1
    x[141]    c202      -3
    x[142]    c45_1     1
    x[142]    c610_1    1
    x[142]    c31       1
    x[142]    c202      -3
    x[143]    c41_1     1
    x[143]    c611_1    1
    x[143]    c31       1
    x[143]    c202      -2
    x[144]    c42_1     1
    x[144]    c612_1    1
    x[144]    c31       1
    x[144]    c202      -2
    x[145]    c43_1     1
    x[145]    c613_1    1
    x[145]    c31       1
    x[145]    c202      -2
    x[146]    c44_1     1
    x[146]    c614_1    1
    x[146]    c31       1
    x[146]    c202      -2
    x[147]    c45_1     1
    x[147]    c615_1    1
    x[147]    c31       1
    x[147]    c202      -2
    x[148]    c41_1     1
    x[148]    c42       1
    x[148]    c694      -1
    x[148]    c697      -1
    x[149]    c42_1     1
    x[149]    c43       1
    x[149]    c700      -1
    x[149]    c703      -1
    x[150]    c43_1     1
    x[150]    c44       1
    x[150]    c706      -1
    x[150]    c709      -1
    x[151]    c44_1     1
    x[151]    c45       1
    x[151]    c712      -1
    x[151]    c715      -1
    x[152]    c45_1     1
    x[152]    c46       1
    x[152]    c718      -1
    x[152]    c721      -1
    x[153]    c46_1     1
    x[153]    c616_1    1
    x[153]    c31       1
    x[153]    c202      -1
    x[154]    c47_1     1
    x[154]    c617_1    1
    x[154]    c31       1
    x[154]    c202      -1
    x[155]    c48_1     1
    x[155]    c618_1    1
    x[155]    c31       1
    x[155]    c202      -1
    x[156]    c49_1     1
    x[156]    c619_1    1
    x[156]    c31       1
    x[156]    c202      -1
    x[157]    c50_1     1
    x[157]    c620_1    1
    x[157]    c31       1
    x[157]    c202      -1
    x[158]    c46_1     1
    x[158]    c621_1    1
    x[158]    c31       1
    x[158]    c202      -2
    x[159]    c47_1     1
    x[159]    c622_1    1
    x[159]    c31       1
    x[159]    c202      -2
    x[160]    c48_1     1
    x[160]    c623_1    1
    x[160]    c31       1
    x[160]    c202      -2
    x[161]    c49_1     1
    x[161]    c624_1    1
    x[161]    c31       1
    x[161]    c202      -2
    x[162]    c50_1     1
    x[162]    c625_1    1
    x[162]    c31       1
    x[162]    c202      -2
    x[163]    c46_1     1
    x[163]    c626_1    1
    x[163]    c31       1
    x[163]    c202      -3
    x[164]    c47_1     1
    x[164]    c627_1    1
    x[164]    c31       1
    x[164]    c202      -3
    x[165]    c48_1     1
    x[165]    c628_1    1
    x[165]    c31       1
    x[165]    c202      -3
    x[166]    c49_1     1
    x[166]    c629_1    1
    x[166]    c31       1
    x[166]    c202      -3
    x[167]    c50_1     1
    x[167]    c630_1    1
    x[167]    c31       1
    x[167]    c202      -3
    x[168]    c46_1     1
    x[168]    c47       1
    x[168]    c478      -1
    x[168]    c480      -1
    x[169]    c47_1     1
    x[169]    c48       1
    x[169]    c482      -1
    x[169]    c484      -1
    x[170]    c48_1     1
    x[170]    c49       1
    x[170]    c486      -1
    x[170]    c488      -1
    x[171]    c49_1     1
    x[171]    c50       1
    x[171]    c490      -1
    x[171]    c492      -1
    x[172]    c50_1     1
    x[172]    c51       1
    x[172]    c494      -1
    x[172]    c496      -1
    x[173]    c51_1     1
    x[173]    c631_1    1
    x[173]    c31       1
    x[173]    c202      -1
    x[174]    c52_1     1
    x[174]    c632_1    1
    x[174]    c31       1
    x[174]    c202      -1
    x[175]    c53_1     1
    x[175]    c633_1    1
    x[175]    c31       1
    x[175]    c202      -1
    x[176]    c54_1     1
    x[176]    c634_1    1
    x[176]    c31       1
    x[176]    c202      -1
    x[177]    c55_1     1
    x[177]    c635_1    1
    x[177]    c31       1
    x[177]    c202      -1
    x[178]    c51_1     1
    x[178]    c636_1    1
    x[178]    c31       1
    x[178]    c202      -3
    x[179]    c52_1     1
    x[179]    c637_1    1
    x[179]    c31       1
    x[179]    c202      -3
    x[180]    c53_1     1
    x[180]    c638_1    1
    x[180]    c31       1
    x[180]    c202      -3
    x[181]    c54_1     1
    x[181]    c639_1    1
    x[181]    c31       1
    x[181]    c202      -3
    x[182]    c55_1     1
    x[182]    c640_1    1
    x[182]    c31       1
    x[182]    c202      -3
    x[183]    c51_1     1
    x[183]    c641_1    1
    x[183]    c31       1
    x[183]    c202      -2
    x[184]    c52_1     1
    x[184]    c642_1    1
    x[184]    c31       1
    x[184]    c202      -2
    x[185]    c53_1     1
    x[185]    c643_1    1
    x[185]    c31       1
    x[185]    c202      -2
    x[186]    c54_1     1
    x[186]    c644_1    1
    x[186]    c31       1
    x[186]    c202      -2
    x[187]    c55_1     1
    x[187]    c645_1    1
    x[187]    c31       1
    x[187]    c202      -2
    x[188]    c56_1     1
    x[188]    c646_1    1
    x[188]    c31       1
    x[188]    c202      -1
    x[189]    c57_1     1
    x[189]    c647_1    1
    x[189]    c31       1
    x[189]    c202      -1
    x[190]    c58_1     1
    x[190]    c648_1    1
    x[190]    c31       1
    x[190]    c202      -1
    x[191]    c59_1     1
    x[191]    c649_1    1
    x[191]    c31       1
    x[191]    c202      -1
    x[192]    c60_1     1
    x[192]    c650_1    1
    x[192]    c31       1
    x[192]    c202      -1
    x[193]    c56_1     1
    x[193]    c651_1    1
    x[193]    c31       1
    x[193]    c202      -2
    x[194]    c57_1     1
    x[194]    c652_1    1
    x[194]    c31       1
    x[194]    c202      -2
    x[195]    c58_1     1
    x[195]    c653_1    1
    x[195]    c31       1
    x[195]    c202      -2
    x[196]    c59_1     1
    x[196]    c654_1    1
    x[196]    c31       1
    x[196]    c202      -2
    x[197]    c60_1     1
    x[197]    c655_1    1
    x[197]    c31       1
    x[197]    c202      -2
    x[198]    c56_1     1
    x[198]    c656_1    1
    x[198]    c31       1
    x[198]    c202      -3
    x[199]    c57_1     1
    x[199]    c657_1    1
    x[199]    c31       1
    x[199]    c202      -3
    x[200]    c58_1     1
    x[200]    c658_1    1
    x[200]    c31       1
    x[200]    c202      -3
    x[201]    c59_1     1
    x[201]    c659_1    1
    x[201]    c31       1
    x[201]    c202      -3
    x[202]    c60_1     1
    x[202]    c660_1    1
    x[202]    c31       1
    x[202]    c202      -3
    x[203]    c61_1     1
    x[203]    c661_1    1
    x[203]    c31       1
    x[203]    c202      -1
    x[204]    c62_1     1
    x[204]    c662_1    1
    x[204]    c31       1
    x[204]    c202      -1
    x[205]    c63_1     1
    x[205]    c663_1    1
    x[205]    c31       1
    x[205]    c202      -1
    x[206]    c64_1     1
    x[206]    c664_1    1
    x[206]    c31       1
    x[206]    c202      -1
    x[207]    c65_1     1
    x[207]    c665_1    1
    x[207]    c31       1
    x[207]    c202      -1
    x[208]    c61_1     1
    x[208]    c666_1    1
    x[208]    c31       1
    x[208]    c202      -3
    x[209]    c62_1     1
    x[209]    c667_1    1
    x[209]    c31       1
    x[209]    c202      -3
    x[210]    c63_1     1
    x[210]    c668_1    1
    x[210]    c31       1
    x[210]    c202      -3
    x[211]    c64_1     1
    x[211]    c669_1    1
    x[211]    c31       1
    x[211]    c202      -3
    x[212]    c65_1     1
    x[212]    c670_1    1
    x[212]    c31       1
    x[212]    c202      -3
    x[213]    c61_1     1
    x[213]    c671_1    1
    x[213]    c31       1
    x[213]    c202      -2
    x[214]    c62_1     1
    x[214]    c672_1    1
    x[214]    c31       1
    x[214]    c202      -2
    x[215]    c63_1     1
    x[215]    c673_1    1
    x[215]    c31       1
    x[215]    c202      -2
    x[216]    c64_1     1
    x[216]    c674_1    1
    x[216]    c31       1
    x[216]    c202      -2
    x[217]    c65_1     1
    x[217]    c675_1    1
    x[217]    c31       1
    x[217]    c202      -2
    x[218]    c61_1     1
    x[218]    c52       1
    x[218]    c742      -1
    x[218]    c751      -1
    x[218]    c755      -1
    x[219]    c62_1     1
    x[219]    c53       1
    x[219]    c810      -1
    x[219]    c819      -1
    x[219]    c823      -1
    x[220]    c63_1     1
    x[220]    c54       1
    x[220]    c859      -1
    x[220]    c868      -1
    x[220]    c872      -1
    x[221]    c64_1     1
    x[221]    c55       1
    x[222]    c65_1     1
    x[222]    c56       1
    x[223]    c66_1     1
    x[223]    c676_1    1
    x[223]    c31       1
    x[223]    c202      -1
    x[224]    c67_1     1
    x[224]    c677_1    1
    x[224]    c31       1
    x[224]    c202      -1
    x[225]    c68_1     1
    x[225]    c678_1    1
    x[225]    c31       1
    x[225]    c202      -1
    x[226]    c69_1     1
    x[226]    c679_1    1
    x[226]    c31       1
    x[226]    c202      -1
    x[227]    c70_1     1
    x[227]    c680_1    1
    x[227]    c31       1
    x[227]    c202      -1
    x[228]    c66_1     1
    x[228]    c681_1    1
    x[228]    c31       1
    x[228]    c202      -2
    x[229]    c67_1     1
    x[229]    c682_1    1
    x[229]    c31       1
    x[229]    c202      -2
    x[230]    c68_1     1
    x[230]    c683_1    1
    x[230]    c31       1
    x[230]    c202      -2
    x[231]    c69_1     1
    x[231]    c684_1    1
    x[231]    c31       1
    x[231]    c202      -2
    x[232]    c70_1     1
    x[232]    c685_1    1
    x[232]    c31       1
    x[232]    c202      -2
    x[233]    c66_1     1
    x[233]    c686_1    1
    x[233]    c31       1
    x[233]    c202      -3
    x[234]    c67_1     1
    x[234]    c687_1    1
    x[234]    c31       1
    x[234]    c202      -3
    x[235]    c68_1     1
    x[235]    c688_1    1
    x[235]    c31       1
    x[235]    c202      -3
    x[236]    c69_1     1
    x[236]    c689_1    1
    x[236]    c31       1
    x[236]    c202      -3
    x[237]    c70_1     1
    x[237]    c690_1    1
    x[237]    c31       1
    x[237]    c202      -3
    x[238]    c71_1     1
    x[238]    c691_1    1
    x[238]    c31       1
    x[238]    c202      -2
    x[239]    c72_1     1
    x[239]    c692_1    1
    x[239]    c31       1
    x[239]    c202      -2
    x[240]    c73_1     1
    x[240]    c693_1    1
    x[240]    c31       1
    x[240]    c202      -2
    x[241]    c74_1     1
    x[241]    c694_1    1
    x[241]    c31       1
    x[241]    c202      -2
    x[242]    c75_1     1
    x[242]    c695_1    1
    x[242]    c31       1
    x[242]    c202      -2
    x[243]    c71_1     1
    x[243]    c696_1    1
    x[243]    c31       1
    x[243]    c202      -3
    x[244]    c72_1     1
    x[244]    c697_1    1
    x[244]    c31       1
    x[244]    c202      -3
    x[245]    c73_1     1
    x[245]    c698_1    1
    x[245]    c31       1
    x[245]    c202      -3
    x[246]    c74_1     1
    x[246]    c699_1    1
    x[246]    c31       1
    x[246]    c202      -3
    x[247]    c75_1     1
    x[247]    c700_1    1
    x[247]    c31       1
    x[247]    c202      -3
    x[248]    c71_1     1
    x[248]    c701_1    1
    x[248]    c31       1
    x[248]    c202      -1
    x[249]    c72_1     1
    x[249]    c702_1    1
    x[249]    c31       1
    x[249]    c202      -1
    x[250]    c73_1     1
    x[250]    c703_1    1
    x[250]    c31       1
    x[250]    c202      -1
    x[251]    c74_1     1
    x[251]    c704_1    1
    x[251]    c31       1
    x[251]    c202      -1
    x[252]    c75_1     1
    x[252]    c705_1    1
    x[252]    c31       1
    x[252]    c202      -1
    x[253]    c76_1     1
    x[253]    c706_1    1
    x[253]    c31       1
    x[253]    c202      -1
    x[254]    c77_1     1
    x[254]    c707_1    1
    x[254]    c31       1
    x[254]    c202      -1
    x[255]    c78_1     1
    x[255]    c708_1    1
    x[255]    c31       1
    x[255]    c202      -1
    x[256]    c79_1     1
    x[256]    c709_1    1
    x[256]    c31       1
    x[256]    c202      -1
    x[257]    c80_1     1
    x[257]    c710_1    1
    x[257]    c31       1
    x[257]    c202      -1
    x[258]    c76_1     1
    x[258]    c57       1
    x[258]    c891      -1
    x[258]    c896      -1
    x[258]    c898      -1
    x[259]    c77_1     1
    x[259]    c58       1
    x[259]    c900      -1
    x[259]    c905      -1
    x[260]    c78_1     1
    x[260]    c59       1
    x[260]    c907      -1
    x[260]    c909      -1
    x[261]    c79_1     1
    x[261]    c60       1
    x[261]    c911      -1
    x[261]    c913      -1
    x[262]    c80_1     1
    x[262]    c61       1
    x[262]    c915      -1
    x[262]    c917      -1
    x[263]    c76_1     1
    x[263]    c62       1
    x[263]    c923      -1
    x[263]    c927      -1
    x[264]    c77_1     1
    x[264]    c63       1
    x[264]    c929      -1
    x[264]    c931      -1
    x[265]    c78_1     1
    x[265]    c64       1
    x[265]    c933      -1
    x[265]    c937      -1
    x[266]    c79_1     1
    x[266]    c65       1
    x[266]    c939      -1
    x[266]    c941      -1
    x[267]    c80_1     1
    x[267]    c66       1
    x[267]    c943      -1
    x[267]    c945      -1
    x[268]    c76_1     1
    x[268]    c711_1    1
    x[268]    c31       1
    x[268]    c202      -3
    x[269]    c77_1     1
    x[269]    c712_1    1
    x[269]    c31       1
    x[269]    c202      -3
    x[270]    c78_1     1
    x[270]    c713_1    1
    x[270]    c31       1
    x[270]    c202      -3
    x[271]    c79_1     1
    x[271]    c714_1    1
    x[271]    c31       1
    x[271]    c202      -3
    x[272]    c80_1     1
    x[272]    c715_1    1
    x[272]    c31       1
    x[272]    c202      -3
    x[273]    c76_1     1
    x[273]    c716_1    1
    x[273]    c31       1
    x[273]    c202      -2
    x[274]    c77_1     1
    x[274]    c717_1    1
    x[274]    c31       1
    x[274]    c202      -2
    x[275]    c78_1     1
    x[275]    c718_1    1
    x[275]    c31       1
    x[275]    c202      -2
    x[276]    c79_1     1
    x[276]    c719_1    1
    x[276]    c31       1
    x[276]    c202      -2
    x[277]    c80_1     1
    x[277]    c720_1    1
    x[277]    c31       1
    x[277]    c202      -2
    x[278]    c81_1     1
    x[278]    c67       1
    x[278]    c283      -1
    x[278]    c287      -1
    x[279]    c82_1     1
    x[279]    c68       1
    x[279]    c291      -1
    x[279]    c295      -1
    x[280]    c83_1     1
    x[280]    c69       1
    x[280]    c299      -1
    x[280]    c305      -1
    x[281]    c84_1     1
    x[281]    c70       1
    x[281]    c309      -1
    x[281]    c313      -1
    x[282]    c85_1     1
    x[282]    c71       1
    x[282]    c317      -1
    x[282]    c321      -1
    x[283]    c81_1     1
    x[283]    c721_1    1
    x[283]    c31       1
    x[283]    c202      -3
    x[284]    c82_1     1
    x[284]    c722_1    1
    x[284]    c31       1
    x[284]    c202      -3
    x[285]    c83_1     1
    x[285]    c723_1    1
    x[285]    c31       1
    x[285]    c202      -3
    x[286]    c84_1     1
    x[286]    c724_1    1
    x[286]    c31       1
    x[286]    c202      -3
    x[287]    c85_1     1
    x[287]    c725_1    1
    x[287]    c31       1
    x[287]    c202      -3
    x[288]    c81_1     1
    x[288]    c726_1    1
    x[288]    c31       1
    x[288]    c202      -1
    x[289]    c82_1     1
    x[289]    c727_1    1
    x[289]    c31       1
    x[289]    c202      -1
    x[290]    c83_1     1
    x[290]    c728_1    1
    x[290]    c31       1
    x[290]    c202      -1
    x[291]    c84_1     1
    x[291]    c729_1    1
    x[291]    c31       1
    x[291]    c202      -1
    x[292]    c85_1     1
    x[292]    c730_1    1
    x[292]    c31       1
    x[292]    c202      -1
    x[293]    c81_1     1
    x[293]    c731_1    1
    x[293]    c31       1
    x[293]    c202      -2
    x[294]    c82_1     1
    x[294]    c732_1    1
    x[294]    c31       1
    x[294]    c202      -2
    x[295]    c83_1     1
    x[295]    c733_1    1
    x[295]    c31       1
    x[295]    c202      -2
    x[296]    c84_1     1
    x[296]    c734_1    1
    x[296]    c31       1
    x[296]    c202      -2
    x[297]    c85_1     1
    x[297]    c735_1    1
    x[297]    c31       1
    x[297]    c202      -2
    x[298]    c86_1     1
    x[298]    c736_1    1
    x[298]    c31       1
    x[298]    c202      -1
    x[299]    c87_1     1
    x[299]    c737_1    1
    x[299]    c31       1
    x[299]    c202      -1
    x[300]    c88_1     1
    x[300]    c738_1    1
    x[300]    c31       1
    x[300]    c202      -1
    x[301]    c89_1     1
    x[301]    c739_1    1
    x[301]    c31       1
    x[301]    c202      -1
    x[302]    c90_1     1
    x[302]    c740_1    1
    x[302]    c31       1
    x[302]    c202      -1
    x[303]    c86_1     1
    x[303]    c741_1    1
    x[303]    c31       1
    x[303]    c202      -2
    x[304]    c87_1     1
    x[304]    c742_1    1
    x[304]    c31       1
    x[304]    c202      -2
    x[305]    c88_1     1
    x[305]    c743_1    1
    x[305]    c31       1
    x[305]    c202      -2
    x[306]    c89_1     1
    x[306]    c744_1    1
    x[306]    c31       1
    x[306]    c202      -2
    x[307]    c90_1     1
    x[307]    c745_1    1
    x[307]    c31       1
    x[307]    c202      -2
    x[308]    c86_1     1
    x[308]    c746_1    1
    x[308]    c31       1
    x[308]    c202      -3
    x[309]    c87_1     1
    x[309]    c747_1    1
    x[309]    c31       1
    x[309]    c202      -3
    x[310]    c88_1     1
    x[310]    c748_1    1
    x[310]    c31       1
    x[310]    c202      -3
    x[311]    c89_1     1
    x[311]    c749_1    1
    x[311]    c31       1
    x[311]    c202      -3
    x[312]    c90_1     1
    x[312]    c750_1    1
    x[312]    c31       1
    x[312]    c202      -3
    x[313]    c91_1     1
    x[313]    c751_1    1
    x[313]    c31       1
    x[313]    c202      -2
    x[314]    c92_1     1
    x[314]    c752_1    1
    x[314]    c31       1
    x[314]    c202      -2
    x[315]    c93_1     1
    x[315]    c753_1    1
    x[315]    c31       1
    x[315]    c202      -2
    x[316]    c94_1     1
    x[316]    c754_1    1
    x[316]    c31       1
    x[316]    c202      -2
    x[317]    c95_1     1
    x[317]    c755_1    1
    x[317]    c31       1
    x[317]    c202      -2
    x[318]    c91_1     1
    x[318]    c756_1    1
    x[318]    c31       1
    x[318]    c202      -1
    x[319]    c92_1     1
    x[319]    c757_1    1
    x[319]    c31       1
    x[319]    c202      -1
    x[320]    c93_1     1
    x[320]    c758_1    1
    x[320]    c31       1
    x[320]    c202      -1
    x[321]    c94_1     1
    x[321]    c759_1    1
    x[321]    c31       1
    x[321]    c202      -1
    x[322]    c95_1     1
    x[322]    c760_1    1
    x[322]    c31       1
    x[322]    c202      -1
    x[323]    c91_1     1
    x[323]    c761_1    1
    x[323]    c31       1
    x[323]    c202      -3
    x[324]    c92_1     1
    x[324]    c762_1    1
    x[324]    c31       1
    x[324]    c202      -3
    x[325]    c93_1     1
    x[325]    c763_1    1
    x[325]    c31       1
    x[325]    c202      -3
    x[326]    c94_1     1
    x[326]    c764_1    1
    x[326]    c31       1
    x[326]    c202      -3
    x[327]    c95_1     1
    x[327]    c765_1    1
    x[327]    c31       1
    x[327]    c202      -3
    x[328]    c96_1     1
    x[328]    c766_1    1
    x[328]    c31       1
    x[328]    c202      -3
    x[329]    c97_1     1
    x[329]    c767_1    1
    x[329]    c31       1
    x[329]    c202      -3
    x[330]    c98_1     1
    x[330]    c768_1    1
    x[330]    c31       1
    x[330]    c202      -3
    x[331]    c99_1     1
    x[331]    c769_1    1
    x[331]    c31       1
    x[331]    c202      -3
    x[332]    c100_1    1
    x[332]    c770_1    1
    x[332]    c31       1
    x[332]    c202      -3
    x[333]    c96_1     1
    x[333]    c771_1    1
    x[333]    c31       1
    x[333]    c202      -1
    x[334]    c97_1     1
    x[334]    c772_1    1
    x[334]    c31       1
    x[334]    c202      -1
    x[335]    c98_1     1
    x[335]    c773_1    1
    x[335]    c31       1
    x[335]    c202      -1
    x[336]    c99_1     1
    x[336]    c774_1    1
    x[336]    c31       1
    x[336]    c202      -1
    x[337]    c100_1    1
    x[337]    c775_1    1
    x[337]    c31       1
    x[337]    c202      -1
    x[338]    c96_1     1
    x[338]    c776_1    1
    x[338]    c31       1
    x[338]    c202      -2
    x[339]    c97_1     1
    x[339]    c777_1    1
    x[339]    c31       1
    x[339]    c202      -2
    x[340]    c98_1     1
    x[340]    c778_1    1
    x[340]    c31       1
    x[340]    c202      -2
    x[341]    c99_1     1
    x[341]    c779_1    1
    x[341]    c31       1
    x[341]    c202      -2
    x[342]    c100_1    1
    x[342]    c780_1    1
    x[342]    c31       1
    x[342]    c202      -2
    x[343]    c101_1    1
    x[343]    c781_1    1
    x[343]    c31       1
    x[343]    c202      -3
    x[344]    c102_1    1
    x[344]    c782_1    1
    x[344]    c31       1
    x[344]    c202      -3
    x[345]    c103_1    1
    x[345]    c783_1    1
    x[345]    c31       1
    x[345]    c202      -3
    x[346]    c104_1    1
    x[346]    c784_1    1
    x[346]    c31       1
    x[346]    c202      -3
    x[347]    c105_1    1
    x[347]    c785_1    1
    x[347]    c31       1
    x[347]    c202      -3
    x[348]    c101_1    1
    x[348]    c786_1    1
    x[348]    c31       1
    x[348]    c202      -2
    x[349]    c102_1    1
    x[349]    c787_1    1
    x[349]    c31       1
    x[349]    c202      -2
    x[350]    c103_1    1
    x[350]    c788_1    1
    x[350]    c31       1
    x[350]    c202      -2
    x[351]    c104_1    1
    x[351]    c789_1    1
    x[351]    c31       1
    x[351]    c202      -2
    x[352]    c105_1    1
    x[352]    c790_1    1
    x[352]    c31       1
    x[352]    c202      -2
    x[353]    c101_1    1
    x[353]    c791_1    1
    x[353]    c31       1
    x[353]    c202      -1
    x[354]    c102_1    1
    x[354]    c792_1    1
    x[354]    c31       1
    x[354]    c202      -1
    x[355]    c103_1    1
    x[355]    c793_1    1
    x[355]    c31       1
    x[355]    c202      -1
    x[356]    c104_1    1
    x[356]    c794_1    1
    x[356]    c31       1
    x[356]    c202      -1
    x[357]    c105_1    1
    x[357]    c795_1    1
    x[357]    c31       1
    x[357]    c202      -1
    x[358]    c106_1    1
    x[358]    c796_1    1
    x[358]    c31       1
    x[358]    c202      -2
    x[359]    c107_1    1
    x[359]    c797_1    1
    x[359]    c31       1
    x[359]    c202      -2
    x[360]    c108_1    1
    x[360]    c798_1    1
    x[360]    c31       1
    x[360]    c202      -2
    x[361]    c109_1    1
    x[361]    c799_1    1
    x[361]    c31       1
    x[361]    c202      -2
    x[362]    c110_1    1
    x[362]    c800_1    1
    x[362]    c31       1
    x[362]    c202      -2
    x[363]    c106_1    1
    x[363]    c801_1    1
    x[363]    c31       1
    x[363]    c202      -1
    x[364]    c107_1    1
    x[364]    c802_1    1
    x[364]    c31       1
    x[364]    c202      -1
    x[365]    c108_1    1
    x[365]    c803_1    1
    x[365]    c31       1
    x[365]    c202      -1
    x[366]    c109_1    1
    x[366]    c804_1    1
    x[366]    c31       1
    x[366]    c202      -1
    x[367]    c110_1    1
    x[367]    c805_1    1
    x[367]    c31       1
    x[367]    c202      -1
    x[368]    c106_1    1
    x[368]    c806_1    1
    x[368]    c31       1
    x[368]    c202      -3
    x[369]    c107_1    1
    x[369]    c807_1    1
    x[369]    c31       1
    x[369]    c202      -3
    x[370]    c108_1    1
    x[370]    c808_1    1
    x[370]    c31       1
    x[370]    c202      -3
    x[371]    c109_1    1
    x[371]    c809_1    1
    x[371]    c31       1
    x[371]    c202      -3
    x[372]    c110_1    1
    x[372]    c810_1    1
    x[372]    c31       1
    x[372]    c202      -3
    x[373]    c111_1    1
    x[373]    c811_1    1
    x[373]    c31       1
    x[373]    c202      -3
    x[374]    c112_1    1
    x[374]    c812_1    1
    x[374]    c31       1
    x[374]    c202      -3
    x[375]    c113_1    1
    x[375]    c813_1    1
    x[375]    c31       1
    x[375]    c202      -3
    x[376]    c114_1    1
    x[376]    c814_1    1
    x[376]    c31       1
    x[376]    c202      -3
    x[377]    c115_1    1
    x[377]    c815_1    1
    x[377]    c31       1
    x[377]    c202      -3
    x[378]    c111_1    1
    x[378]    c816_1    1
    x[378]    c31       1
    x[378]    c202      -1
    x[379]    c112_1    1
    x[379]    c817_1    1
    x[379]    c31       1
    x[379]    c202      -1
    x[380]    c113_1    1
    x[380]    c818_1    1
    x[380]    c31       1
    x[380]    c202      -1
    x[381]    c114_1    1
    x[381]    c819_1    1
    x[381]    c31       1
    x[381]    c202      -1
    x[382]    c115_1    1
    x[382]    c820_1    1
    x[382]    c31       1
    x[382]    c202      -1
    x[383]    c111_1    1
    x[383]    c821_1    1
    x[383]    c31       1
    x[383]    c202      -2
    x[384]    c112_1    1
    x[384]    c822_1    1
    x[384]    c31       1
    x[384]    c202      -2
    x[385]    c113_1    1
    x[385]    c823_1    1
    x[385]    c31       1
    x[385]    c202      -2
    x[386]    c114_1    1
    x[386]    c824_1    1
    x[386]    c31       1
    x[386]    c202      -2
    x[387]    c115_1    1
    x[387]    c825_1    1
    x[387]    c31       1
    x[387]    c202      -2
    x[388]    c116_1    1
    x[388]    c826_1    1
    x[388]    c31       1
    x[388]    c202      -3
    x[389]    c117_1    1
    x[389]    c827_1    1
    x[389]    c31       1
    x[389]    c202      -3
    x[390]    c118_1    1
    x[390]    c828_1    1
    x[390]    c31       1
    x[390]    c202      -3
    x[391]    c119_1    1
    x[391]    c829_1    1
    x[391]    c31       1
    x[391]    c202      -3
    x[392]    c120_1    1
    x[392]    c830_1    1
    x[392]    c31       1
    x[392]    c202      -3
    x[393]    c116_1    1
    x[393]    c831_1    1
    x[393]    c31       1
    x[393]    c202      -2
    x[394]    c117_1    1
    x[394]    c832_1    1
    x[394]    c31       1
    x[394]    c202      -2
    x[395]    c118_1    1
    x[395]    c833_1    1
    x[395]    c31       1
    x[395]    c202      -2
    x[396]    c119_1    1
    x[396]    c834_1    1
    x[396]    c31       1
    x[396]    c202      -2
    x[397]    c120_1    1
    x[397]    c835_1    1
    x[397]    c31       1
    x[397]    c202      -2
    x[398]    c116_1    1
    x[398]    c836_1    1
    x[398]    c31       1
    x[398]    c202      -1
    x[399]    c117_1    1
    x[399]    c837_1    1
    x[399]    c31       1
    x[399]    c202      -1
    x[400]    c118_1    1
    x[400]    c838_1    1
    x[400]    c31       1
    x[400]    c202      -1
    x[401]    c119_1    1
    x[401]    c839_1    1
    x[401]    c31       1
    x[401]    c202      -1
    x[402]    c120_1    1
    x[402]    c840_1    1
    x[402]    c31       1
    x[402]    c202      -1
    x[403]    c116_1    1
    x[403]    c72       1
    x[403]    c695      -1
    x[403]    c698      -1
    x[404]    c117_1    1
    x[404]    c73       1
    x[404]    c701      -1
    x[404]    c704      -1
    x[405]    c118_1    1
    x[405]    c74       1
    x[405]    c707      -1
    x[405]    c710      -1
    x[406]    c119_1    1
    x[406]    c75       1
    x[406]    c713      -1
    x[406]    c716      -1
    x[407]    c120_1    1
    x[407]    c76       1
    x[407]    c719      -1
    x[407]    c722      -1
    x[408]    c121_1    1
    x[408]    c841_1    1
    x[408]    c31       1
    x[408]    c202      -3
    x[409]    c122_1    1
    x[409]    c842_1    1
    x[409]    c31       1
    x[409]    c202      -3
    x[410]    c123_1    1
    x[410]    c843_1    1
    x[410]    c31       1
    x[410]    c202      -3
    x[411]    c124_1    1
    x[411]    c844_1    1
    x[411]    c31       1
    x[411]    c202      -3
    x[412]    c125_1    1
    x[412]    c845_1    1
    x[412]    c31       1
    x[412]    c202      -3
    x[413]    c121_1    1
    x[413]    c846_1    1
    x[413]    c31       1
    x[413]    c202      -2
    x[414]    c122_1    1
    x[414]    c847_1    1
    x[414]    c31       1
    x[414]    c202      -2
    x[415]    c123_1    1
    x[415]    c848_1    1
    x[415]    c31       1
    x[415]    c202      -2
    x[416]    c124_1    1
    x[416]    c849_1    1
    x[416]    c31       1
    x[416]    c202      -2
    x[417]    c125_1    1
    x[417]    c850_1    1
    x[417]    c31       1
    x[417]    c202      -2
    x[418]    c121_1    1
    x[418]    c851_1    1
    x[418]    c31       1
    x[418]    c202      -1
    x[419]    c122_1    1
    x[419]    c852_1    1
    x[419]    c31       1
    x[419]    c202      -1
    x[420]    c123_1    1
    x[420]    c853_1    1
    x[420]    c31       1
    x[420]    c202      -1
    x[421]    c124_1    1
    x[421]    c854_1    1
    x[421]    c31       1
    x[421]    c202      -1
    x[422]    c125_1    1
    x[422]    c855_1    1
    x[422]    c31       1
    x[422]    c202      -1
    x[423]    c126_1    1
    x[423]    c856_1    1
    x[423]    c31       1
    x[423]    c202      -3
    x[424]    c127_1    1
    x[424]    c857_1    1
    x[424]    c31       1
    x[424]    c202      -3
    x[425]    c128_1    1
    x[425]    c858_1    1
    x[425]    c31       1
    x[425]    c202      -3
    x[426]    c129_1    1
    x[426]    c859_1    1
    x[426]    c31       1
    x[426]    c202      -3
    x[427]    c130_1    1
    x[427]    c860_1    1
    x[427]    c31       1
    x[427]    c202      -3
    x[428]    c126_1    1
    x[428]    c861_1    1
    x[428]    c31       1
    x[428]    c202      -1
    x[429]    c127_1    1
    x[429]    c862_1    1
    x[429]    c31       1
    x[429]    c202      -1
    x[430]    c128_1    1
    x[430]    c863_1    1
    x[430]    c31       1
    x[430]    c202      -1
    x[431]    c129_1    1
    x[431]    c864_1    1
    x[431]    c31       1
    x[431]    c202      -1
    x[432]    c130_1    1
    x[432]    c865_1    1
    x[432]    c31       1
    x[432]    c202      -1
    x[433]    c126_1    1
    x[433]    c866_1    1
    x[433]    c31       1
    x[433]    c202      -2
    x[434]    c127_1    1
    x[434]    c867_1    1
    x[434]    c31       1
    x[434]    c202      -2
    x[435]    c128_1    1
    x[435]    c868_1    1
    x[435]    c31       1
    x[435]    c202      -2
    x[436]    c129_1    1
    x[436]    c869_1    1
    x[436]    c31       1
    x[436]    c202      -2
    x[437]    c130_1    1
    x[437]    c870_1    1
    x[437]    c31       1
    x[437]    c202      -2
    x[438]    c131_1    1
    x[438]    c871_1    1
    x[438]    c31       1
    x[438]    c202      -3
    x[439]    c132_1    1
    x[439]    c872_1    1
    x[439]    c31       1
    x[439]    c202      -3
    x[440]    c133_1    1
    x[440]    c873_1    1
    x[440]    c31       1
    x[440]    c202      -3
    x[441]    c134_1    1
    x[441]    c874_1    1
    x[441]    c31       1
    x[441]    c202      -3
    x[442]    c135_1    1
    x[442]    c875_1    1
    x[442]    c31       1
    x[442]    c202      -3
    x[443]    c131_1    1
    x[443]    c876_1    1
    x[443]    c31       1
    x[443]    c202      -2
    x[444]    c132_1    1
    x[444]    c877_1    1
    x[444]    c31       1
    x[444]    c202      -2
    x[445]    c133_1    1
    x[445]    c878_1    1
    x[445]    c31       1
    x[445]    c202      -2
    x[446]    c134_1    1
    x[446]    c879_1    1
    x[446]    c31       1
    x[446]    c202      -2
    x[447]    c135_1    1
    x[447]    c880_1    1
    x[447]    c31       1
    x[447]    c202      -2
    x[448]    c131_1    1
    x[448]    c881_1    1
    x[448]    c31       1
    x[448]    c202      -1
    x[449]    c132_1    1
    x[449]    c882_1    1
    x[449]    c31       1
    x[449]    c202      -1
    x[450]    c133_1    1
    x[450]    c883_1    1
    x[450]    c31       1
    x[450]    c202      -1
    x[451]    c134_1    1
    x[451]    c884_1    1
    x[451]    c31       1
    x[451]    c202      -1
    x[452]    c135_1    1
    x[452]    c885_1    1
    x[452]    c31       1
    x[452]    c202      -1
    x[453]    c136_1    1
    x[453]    c886_1    1
    x[453]    c31       1
    x[453]    c202      -3
    x[454]    c137_1    1
    x[454]    c887_1    1
    x[454]    c31       1
    x[454]    c202      -3
    x[455]    c138_1    1
    x[455]    c888_1    1
    x[455]    c31       1
    x[455]    c202      -3
    x[456]    c139_1    1
    x[456]    c889_1    1
    x[456]    c31       1
    x[456]    c202      -3
    x[457]    c140_1    1
    x[457]    c890_1    1
    x[457]    c31       1
    x[457]    c202      -3
    x[458]    c136_1    1
    x[458]    c891_1    1
    x[458]    c31       1
    x[458]    c202      -2
    x[459]    c137_1    1
    x[459]    c892_1    1
    x[459]    c31       1
    x[459]    c202      -2
    x[460]    c138_1    1
    x[460]    c893_1    1
    x[460]    c31       1
    x[460]    c202      -2
    x[461]    c139_1    1
    x[461]    c894_1    1
    x[461]    c31       1
    x[461]    c202      -2
    x[462]    c140_1    1
    x[462]    c895_1    1
    x[462]    c31       1
    x[462]    c202      -2
    x[463]    c136_1    1
    x[463]    c896_1    1
    x[463]    c31       1
    x[463]    c202      -1
    x[464]    c137_1    1
    x[464]    c897_1    1
    x[464]    c31       1
    x[464]    c202      -1
    x[465]    c138_1    1
    x[465]    c898_1    1
    x[465]    c31       1
    x[465]    c202      -1
    x[466]    c139_1    1
    x[466]    c899_1    1
    x[466]    c31       1
    x[466]    c202      -1
    x[467]    c140_1    1
    x[467]    c900_1    1
    x[467]    c31       1
    x[467]    c202      -1
    x[468]    c141_1    1
    x[468]    c901_1    1
    x[468]    c31       1
    x[468]    c202      -2
    x[469]    c142_1    1
    x[469]    c902_1    1
    x[469]    c31       1
    x[469]    c202      -2
    x[470]    c143_1    1
    x[470]    c903_1    1
    x[470]    c31       1
    x[470]    c202      -2
    x[471]    c144_1    1
    x[471]    c904_1    1
    x[471]    c31       1
    x[471]    c202      -2
    x[472]    c145_1    1
    x[472]    c905_1    1
    x[472]    c31       1
    x[472]    c202      -2
    x[473]    c141_1    1
    x[473]    c906_1    1
    x[473]    c31       1
    x[473]    c202      -3
    x[474]    c142_1    1
    x[474]    c907_1    1
    x[474]    c31       1
    x[474]    c202      -3
    x[475]    c143_1    1
    x[475]    c908_1    1
    x[475]    c31       1
    x[475]    c202      -3
    x[476]    c144_1    1
    x[476]    c909_1    1
    x[476]    c31       1
    x[476]    c202      -3
    x[477]    c145_1    1
    x[477]    c910_1    1
    x[477]    c31       1
    x[477]    c202      -3
    x[478]    c141_1    1
    x[478]    c77       1
    x[478]    c325      -1
    x[478]    c327      -1
    x[479]    c142_1    1
    x[479]    c78       1
    x[479]    c329      -1
    x[479]    c331      -1
    x[480]    c143_1    1
    x[480]    c79       1
    x[480]    c333      -1
    x[480]    c335      -1
    x[481]    c144_1    1
    x[481]    c80       1
    x[481]    c337      -1
    x[481]    c339      -1
    x[482]    c145_1    1
    x[482]    c81       1
    x[482]    c341      -1
    x[482]    c343      -1
    x[483]    c141_1    1
    x[483]    c82       1
    x[483]    c365      -1
    x[483]    c369      -1
    x[484]    c142_1    1
    x[484]    c83       1
    x[484]    c373      -1
    x[484]    c377      -1
    x[485]    c143_1    1
    x[485]    c84       1
    x[485]    c381      -1
    x[485]    c385      -1
    x[486]    c144_1    1
    x[486]    c85       1
    x[486]    c389      -1
    x[486]    c393      -1
    x[487]    c145_1    1
    x[487]    c86       1
    x[487]    c397      -1
    x[487]    c401      -1
    x[488]    c141_1    1
    x[488]    c911_1    1
    x[488]    c31       1
    x[488]    c202      -1
    x[489]    c142_1    1
    x[489]    c912_1    1
    x[489]    c31       1
    x[489]    c202      -1
    x[490]    c143_1    1
    x[490]    c913_1    1
    x[490]    c31       1
    x[490]    c202      -1
    x[491]    c144_1    1
    x[491]    c914_1    1
    x[491]    c31       1
    x[491]    c202      -1
    x[492]    c145_1    1
    x[492]    c915_1    1
    x[492]    c31       1
    x[492]    c202      -1
    x[493]    c146_1    1
    x[493]    c916_1    1
    x[493]    c31       1
    x[493]    c202      -1
    x[494]    c147_1    1
    x[494]    c917_1    1
    x[494]    c31       1
    x[494]    c202      -1
    x[495]    c148_1    1
    x[495]    c918_1    1
    x[495]    c31       1
    x[495]    c202      -1
    x[496]    c149_1    1
    x[496]    c919_1    1
    x[496]    c31       1
    x[496]    c202      -1
    x[497]    c150_1    1
    x[497]    c920_1    1
    x[497]    c31       1
    x[497]    c202      -1
    x[498]    c146_1    1
    x[498]    c921_1    1
    x[498]    c31       1
    x[498]    c202      -3
    x[499]    c147_1    1
    x[499]    c922_1    1
    x[499]    c31       1
    x[499]    c202      -3
    x[500]    c148_1    1
    x[500]    c923_1    1
    x[500]    c31       1
    x[500]    c202      -3
    x[501]    c149_1    1
    x[501]    c924_1    1
    x[501]    c31       1
    x[501]    c202      -3
    x[502]    c150_1    1
    x[502]    c925_1    1
    x[502]    c31       1
    x[502]    c202      -3
    x[503]    c146_1    1
    x[503]    c926_1    1
    x[503]    c31       1
    x[503]    c202      -2
    x[504]    c147_1    1
    x[504]    c927_1    1
    x[504]    c31       1
    x[504]    c202      -2
    x[505]    c148_1    1
    x[505]    c928_1    1
    x[505]    c31       1
    x[505]    c202      -2
    x[506]    c149_1    1
    x[506]    c929_1    1
    x[506]    c31       1
    x[506]    c202      -2
    x[507]    c150_1    1
    x[507]    c930_1    1
    x[507]    c31       1
    x[507]    c202      -2
    x[508]    c151_1    1
    x[508]    c931_1    1
    x[508]    c31       1
    x[508]    c202      -1
    x[509]    c152_1    1
    x[509]    c932_1    1
    x[509]    c31       1
    x[509]    c202      -1
    x[510]    c153_1    1
    x[510]    c933_1    1
    x[510]    c31       1
    x[510]    c202      -1
    x[511]    c154_1    1
    x[511]    c934_1    1
    x[511]    c31       1
    x[511]    c202      -1
    x[512]    c155_1    1
    x[512]    c935_1    1
    x[512]    c31       1
    x[512]    c202      -1
    x[513]    c151_1    1
    x[513]    c936_1    1
    x[513]    c31       1
    x[513]    c202      -2
    x[514]    c152_1    1
    x[514]    c937_1    1
    x[514]    c31       1
    x[514]    c202      -2
    x[515]    c153_1    1
    x[515]    c938_1    1
    x[515]    c31       1
    x[515]    c202      -2
    x[516]    c154_1    1
    x[516]    c939_1    1
    x[516]    c31       1
    x[516]    c202      -2
    x[517]    c155_1    1
    x[517]    c940_1    1
    x[517]    c31       1
    x[517]    c202      -2
    x[518]    c151_1    1
    x[518]    c941_1    1
    x[518]    c31       1
    x[518]    c202      -3
    x[519]    c152_1    1
    x[519]    c942_1    1
    x[519]    c31       1
    x[519]    c202      -3
    x[520]    c153_1    1
    x[520]    c943_1    1
    x[520]    c31       1
    x[520]    c202      -3
    x[521]    c154_1    1
    x[521]    c944_1    1
    x[521]    c31       1
    x[521]    c202      -3
    x[522]    c155_1    1
    x[522]    c945_1    1
    x[522]    c31       1
    x[522]    c202      -3
    x[523]    c156_1    1
    x[523]    c946_1    1
    x[523]    c31       1
    x[523]    c202      -3
    x[524]    c157_1    1
    x[524]    c947      1
    x[524]    c31       1
    x[524]    c202      -3
    x[525]    c158_1    1
    x[525]    c948      1
    x[525]    c31       1
    x[525]    c202      -3
    x[526]    c159_1    1
    x[526]    c949      1
    x[526]    c31       1
    x[526]    c202      -3
    x[527]    c160_1    1
    x[527]    c950      1
    x[527]    c31       1
    x[527]    c202      -3
    x[528]    c156_1    1
    x[528]    c951      1
    x[528]    c31       1
    x[528]    c202      -2
    x[529]    c157_1    1
    x[529]    c952      1
    x[529]    c31       1
    x[529]    c202      -2
    x[530]    c158_1    1
    x[530]    c953      1
    x[530]    c31       1
    x[530]    c202      -2
    x[531]    c159_1    1
    x[531]    c954      1
    x[531]    c31       1
    x[531]    c202      -2
    x[532]    c160_1    1
    x[532]    c955      1
    x[532]    c31       1
    x[532]    c202      -2
    x[533]    c156_1    1
    x[533]    c956      1
    x[533]    c31       1
    x[533]    c202      -1
    x[534]    c157_1    1
    x[534]    c957      1
    x[534]    c31       1
    x[534]    c202      -1
    x[535]    c158_1    1
    x[535]    c958      1
    x[535]    c31       1
    x[535]    c202      -1
    x[536]    c159_1    1
    x[536]    c959      1
    x[536]    c31       1
    x[536]    c202      -1
    x[537]    c160_1    1
    x[537]    c960      1
    x[537]    c31       1
    x[537]    c202      -1
    x[538]    c161_1    1
    x[538]    c87       1
    x[538]    c284      -1
    x[538]    c288      -1
    x[539]    c162_1    1
    x[539]    c88       1
    x[539]    c292      -1
    x[539]    c296      -1
    x[540]    c163_1    1
    x[540]    c89       1
    x[540]    c300      -1
    x[540]    c303      -1
    x[540]    c306      -1
    x[541]    c164_1    1
    x[541]    c90       1
    x[541]    c310      -1
    x[541]    c314      -1
    x[542]    c165_1    1
    x[542]    c91       1
    x[542]    c318      -1
    x[542]    c322      -1
    x[543]    c161_1    1
    x[543]    c92       1
    x[543]    c345      -1
    x[543]    c347      -1
    x[544]    c162_1    1
    x[544]    c93       1
    x[544]    c349      -1
    x[544]    c351      -1
    x[545]    c163_1    1
    x[545]    c94       1
    x[545]    c353      -1
    x[545]    c355      -1
    x[546]    c164_1    1
    x[546]    c95       1
    x[546]    c357      -1
    x[546]    c359      -1
    x[547]    c165_1    1
    x[547]    c96       1
    x[547]    c361      -1
    x[547]    c363      -1
    x[548]    c161_1    1
    x[548]    c97       1
    x[548]    c672      -1
    x[548]    c674      -1
    x[549]    c162_1    1
    x[549]    c98       1
    x[549]    c676      -1
    x[549]    c678      -1
    x[549]    c680      -1
    x[550]    c163_1    1
    x[550]    c99       1
    x[550]    c682      -1
    x[550]    c684      -1
    x[551]    c164_1    1
    x[551]    c100      1
    x[551]    c686      -1
    x[551]    c688      -1
    x[552]    c165_1    1
    x[552]    c101      1
    x[552]    c690      -1
    x[552]    c692      -1
    x[553]    c161_1    1
    x[553]    c961      1
    x[553]    c31       1
    x[553]    c202      -1
    x[554]    c162_1    1
    x[554]    c962      1
    x[554]    c31       1
    x[554]    c202      -1
    x[555]    c163_1    1
    x[555]    c963      1
    x[555]    c31       1
    x[555]    c202      -1
    x[556]    c164_1    1
    x[556]    c964      1
    x[556]    c31       1
    x[556]    c202      -1
    x[557]    c165_1    1
    x[557]    c965      1
    x[557]    c31       1
    x[557]    c202      -1
    x[558]    c161_1    1
    x[558]    c966      1
    x[558]    c31       1
    x[558]    c202      -2
    x[559]    c162_1    1
    x[559]    c967      1
    x[559]    c31       1
    x[559]    c202      -2
    x[560]    c163_1    1
    x[560]    c968      1
    x[560]    c31       1
    x[560]    c202      -2
    x[561]    c164_1    1
    x[561]    c969      1
    x[561]    c31       1
    x[561]    c202      -2
    x[562]    c165_1    1
    x[562]    c970      1
    x[562]    c31       1
    x[562]    c202      -2
    x[563]    c161_1    1
    x[563]    c971      1
    x[563]    c31       1
    x[563]    c202      -3
    x[564]    c162_1    1
    x[564]    c972      1
    x[564]    c31       1
    x[564]    c202      -3
    x[565]    c163_1    1
    x[565]    c973      1
    x[565]    c31       1
    x[565]    c202      -3
    x[566]    c164_1    1
    x[566]    c974      1
    x[566]    c31       1
    x[566]    c202      -3
    x[567]    c165_1    1
    x[567]    c975      1
    x[567]    c31       1
    x[567]    c202      -3
    x[568]    c166_1    1
    x[568]    c976      1
    x[568]    c31       1
    x[568]    c202      -3
    x[569]    c167_1    1
    x[569]    c977      1
    x[569]    c31       1
    x[569]    c202      -3
    x[570]    c168_1    1
    x[570]    c978      1
    x[570]    c31       1
    x[570]    c202      -3
    x[571]    c169_1    1
    x[571]    c979      1
    x[571]    c31       1
    x[571]    c202      -3
    x[572]    c170_1    1
    x[572]    c980      1
    x[572]    c31       1
    x[572]    c202      -3
    x[573]    c166_1    1
    x[573]    c981      1
    x[573]    c31       1
    x[573]    c202      -2
    x[574]    c167_1    1
    x[574]    c982      1
    x[574]    c31       1
    x[574]    c202      -2
    x[575]    c168_1    1
    x[575]    c983      1
    x[575]    c31       1
    x[575]    c202      -2
    x[576]    c169_1    1
    x[576]    c984      1
    x[576]    c31       1
    x[576]    c202      -2
    x[577]    c170_1    1
    x[577]    c985      1
    x[577]    c31       1
    x[577]    c202      -2
    x[578]    c166_1    1
    x[578]    c986      1
    x[578]    c31       1
    x[578]    c202      -1
    x[579]    c167_1    1
    x[579]    c987      1
    x[579]    c31       1
    x[579]    c202      -1
    x[580]    c168_1    1
    x[580]    c988      1
    x[580]    c31       1
    x[580]    c202      -1
    x[581]    c169_1    1
    x[581]    c989      1
    x[581]    c31       1
    x[581]    c202      -1
    x[582]    c170_1    1
    x[582]    c990      1
    x[582]    c31       1
    x[582]    c202      -1
    x[583]    c171_1    1
    x[583]    c991      1
    x[583]    c31       1
    x[583]    c202      -2
    x[584]    c172_1    1
    x[584]    c992      1
    x[584]    c31       1
    x[584]    c202      -2
    x[585]    c173_1    1
    x[585]    c993      1
    x[585]    c31       1
    x[585]    c202      -2
    x[586]    c174_1    1
    x[586]    c994      1
    x[586]    c31       1
    x[586]    c202      -2
    x[587]    c175_1    1
    x[587]    c995      1
    x[587]    c31       1
    x[587]    c202      -2
    x[588]    c171_1    1
    x[588]    c996      1
    x[588]    c31       1
    x[588]    c202      -1
    x[589]    c172_1    1
    x[589]    c997      1
    x[589]    c31       1
    x[589]    c202      -1
    x[590]    c173_1    1
    x[590]    c998      1
    x[590]    c31       1
    x[590]    c202      -1
    x[591]    c174_1    1
    x[591]    c999      1
    x[591]    c31       1
    x[591]    c202      -1
    x[592]    c175_1    1
    x[592]    c1000     1
    x[592]    c31       1
    x[592]    c202      -1
    x[593]    c171_1    1
    x[593]    c1001     1
    x[593]    c31       1
    x[593]    c202      -3
    x[594]    c172_1    1
    x[594]    c1002     1
    x[594]    c31       1
    x[594]    c202      -3
    x[595]    c173_1    1
    x[595]    c1003     1
    x[595]    c31       1
    x[595]    c202      -3
    x[596]    c174_1    1
    x[596]    c1004     1
    x[596]    c31       1
    x[596]    c202      -3
    x[597]    c175_1    1
    x[597]    c1005     1
    x[597]    c31       1
    x[597]    c202      -3
    x[598]    c176_1    1
    x[598]    c1006     1
    x[598]    c31       1
    x[598]    c202      -3
    x[599]    c177_1    1
    x[599]    c1007     1
    x[599]    c31       1
    x[599]    c202      -3
    x[600]    c178_1    1
    x[600]    c1008     1
    x[600]    c31       1
    x[600]    c202      -3
    x[601]    c179_1    1
    x[601]    c1009     1
    x[601]    c31       1
    x[601]    c202      -3
    x[602]    c180_1    1
    x[602]    c1010     1
    x[602]    c31       1
    x[602]    c202      -3
    x[603]    c176_1    1
    x[603]    c1011     1
    x[603]    c31       1
    x[603]    c202      -2
    x[604]    c177_1    1
    x[604]    c1012     1
    x[604]    c31       1
    x[604]    c202      -2
    x[605]    c178_1    1
    x[605]    c1013     1
    x[605]    c31       1
    x[605]    c202      -2
    x[606]    c179_1    1
    x[606]    c1014     1
    x[606]    c31       1
    x[606]    c202      -2
    x[607]    c180_1    1
    x[607]    c1015     1
    x[607]    c31       1
    x[607]    c202      -2
    x[608]    c176_1    1
    x[608]    c102      1
    x[608]    c248      -1
    x[608]    c253      -1
    x[609]    c177_1    1
    x[609]    c103      1
    x[609]    c256      -1
    x[609]    c259      -1
    x[610]    c178_1    1
    x[610]    c104      1
    x[610]    c262      -1
    x[610]    c265      -1
    x[610]    c267      -1
    x[611]    c179_1    1
    x[611]    c105      1
    x[611]    c270      -1
    x[611]    c273      -1
    x[612]    c180_1    1
    x[612]    c106      1
    x[612]    c276      -1
    x[612]    c279      -1
    x[613]    c176_1    1
    x[613]    c1016     1
    x[613]    c31       1
    x[613]    c202      -1
    x[614]    c177_1    1
    x[614]    c1017     1
    x[614]    c31       1
    x[614]    c202      -1
    x[615]    c178_1    1
    x[615]    c1018     1
    x[615]    c31       1
    x[615]    c202      -1
    x[616]    c179_1    1
    x[616]    c1019     1
    x[616]    c31       1
    x[616]    c202      -1
    x[617]    c180_1    1
    x[617]    c1020     1
    x[617]    c31       1
    x[617]    c202      -1
    x[618]    c181_1    1
    x[618]    c1021     1
    x[618]    c31       1
    x[618]    c202      -1
    x[619]    c182_1    1
    x[619]    c1022     1
    x[619]    c31       1
    x[619]    c202      -1
    x[620]    c183_1    1
    x[620]    c1023     1
    x[620]    c31       1
    x[620]    c202      -1
    x[621]    c184_1    1
    x[621]    c1024     1
    x[621]    c31       1
    x[621]    c202      -1
    x[622]    c185_1    1
    x[622]    c1025     1
    x[622]    c31       1
    x[622]    c202      -1
    x[623]    c181_1    1
    x[623]    c1026     1
    x[623]    c31       1
    x[623]    c202      -2
    x[624]    c182_1    1
    x[624]    c1027     1
    x[624]    c31       1
    x[624]    c202      -2
    x[625]    c183_1    1
    x[625]    c1028     1
    x[625]    c31       1
    x[625]    c202      -2
    x[626]    c184_1    1
    x[626]    c1029     1
    x[626]    c31       1
    x[626]    c202      -2
    x[627]    c185_1    1
    x[627]    c1030     1
    x[627]    c31       1
    x[627]    c202      -2
    x[628]    c181_1    1
    x[628]    c1031     1
    x[628]    c31       1
    x[628]    c202      -3
    x[629]    c182_1    1
    x[629]    c1032     1
    x[629]    c31       1
    x[629]    c202      -3
    x[630]    c183_1    1
    x[630]    c1033     1
    x[630]    c31       1
    x[630]    c202      -3
    x[631]    c184_1    1
    x[631]    c1034     1
    x[631]    c31       1
    x[631]    c202      -3
    x[632]    c185_1    1
    x[632]    c1035     1
    x[632]    c31       1
    x[632]    c202      -3
    x[633]    c186_1    1
    x[633]    c1036     1
    x[633]    c31       1
    x[633]    c202      -1
    x[634]    c187_1    1
    x[634]    c1037     1
    x[634]    c31       1
    x[634]    c202      -1
    x[635]    c188_1    1
    x[635]    c1038     1
    x[635]    c31       1
    x[635]    c202      -1
    x[636]    c189_1    1
    x[636]    c1039     1
    x[636]    c31       1
    x[636]    c202      -1
    x[637]    c190_1    1
    x[637]    c1040     1
    x[637]    c31       1
    x[637]    c202      -1
    x[638]    c186_1    1
    x[638]    c1041     1
    x[638]    c31       1
    x[638]    c202      -3
    x[639]    c187_1    1
    x[639]    c1042     1
    x[639]    c31       1
    x[639]    c202      -3
    x[640]    c188_1    1
    x[640]    c1043     1
    x[640]    c31       1
    x[640]    c202      -3
    x[641]    c189_1    1
    x[641]    c1044     1
    x[641]    c31       1
    x[641]    c202      -3
    x[642]    c190_1    1
    x[642]    c1045     1
    x[642]    c31       1
    x[642]    c202      -3
    x[643]    c186_1    1
    x[643]    c1046     1
    x[643]    c31       1
    x[643]    c202      -2
    x[644]    c187_1    1
    x[644]    c1047     1
    x[644]    c31       1
    x[644]    c202      -2
    x[645]    c188_1    1
    x[645]    c1048     1
    x[645]    c31       1
    x[645]    c202      -2
    x[646]    c189_1    1
    x[646]    c1049     1
    x[646]    c31       1
    x[646]    c202      -2
    x[647]    c190_1    1
    x[647]    c1050     1
    x[647]    c31       1
    x[647]    c202      -2
    x[648]    c191_1    1
    x[648]    c1051     1
    x[648]    c31       1
    x[648]    c202      -1
    x[649]    c192_1    1
    x[649]    c1052     1
    x[649]    c31       1
    x[649]    c202      -1
    x[650]    c193_1    1
    x[650]    c1053     1
    x[650]    c31       1
    x[650]    c202      -1
    x[651]    c194_1    1
    x[651]    c1054     1
    x[651]    c31       1
    x[651]    c202      -1
    x[652]    c195_1    1
    x[652]    c1055     1
    x[652]    c31       1
    x[652]    c202      -1
    x[653]    c191_1    1
    x[653]    c1056     1
    x[653]    c31       1
    x[653]    c202      -3
    x[654]    c192_1    1
    x[654]    c1057     1
    x[654]    c31       1
    x[654]    c202      -3
    x[655]    c193_1    1
    x[655]    c1058     1
    x[655]    c31       1
    x[655]    c202      -3
    x[656]    c194_1    1
    x[656]    c1059     1
    x[656]    c31       1
    x[656]    c202      -3
    x[657]    c195_1    1
    x[657]    c1060     1
    x[657]    c31       1
    x[657]    c202      -3
    x[658]    c191_1    1
    x[658]    c1061     1
    x[658]    c31       1
    x[658]    c202      -2
    x[659]    c192_1    1
    x[659]    c1062     1
    x[659]    c31       1
    x[659]    c202      -2
    x[660]    c193_1    1
    x[660]    c1063     1
    x[660]    c31       1
    x[660]    c202      -2
    x[661]    c194_1    1
    x[661]    c1064     1
    x[661]    c31       1
    x[661]    c202      -2
    x[662]    c195_1    1
    x[662]    c1065     1
    x[662]    c31       1
    x[662]    c202      -2
    x[663]    c196_1    1
    x[663]    c1066     1
    x[663]    c31       1
    x[663]    c202      -3
    x[664]    c197_1    1
    x[664]    c1067     1
    x[664]    c31       1
    x[664]    c202      -3
    x[665]    c198_1    1
    x[665]    c1068     1
    x[665]    c31       1
    x[665]    c202      -3
    x[666]    c199_1    1
    x[666]    c1069     1
    x[666]    c31       1
    x[666]    c202      -3
    x[667]    c200_1    1
    x[667]    c1070     1
    x[667]    c31       1
    x[667]    c202      -3
    x[668]    c196_1    1
    x[668]    c1071     1
    x[668]    c31       1
    x[668]    c202      -2
    x[669]    c197_1    1
    x[669]    c1072     1
    x[669]    c31       1
    x[669]    c202      -2
    x[670]    c198_1    1
    x[670]    c1073     1
    x[670]    c31       1
    x[670]    c202      -2
    x[671]    c199_1    1
    x[671]    c1074     1
    x[671]    c31       1
    x[671]    c202      -2
    x[672]    c200_1    1
    x[672]    c1075     1
    x[672]    c31       1
    x[672]    c202      -2
    x[673]    c196_1    1
    x[673]    c1076     1
    x[673]    c31       1
    x[673]    c202      -1
    x[674]    c197_1    1
    x[674]    c1077     1
    x[674]    c31       1
    x[674]    c202      -1
    x[675]    c198_1    1
    x[675]    c1078     1
    x[675]    c31       1
    x[675]    c202      -1
    x[676]    c199_1    1
    x[676]    c1079     1
    x[676]    c31       1
    x[676]    c202      -1
    x[677]    c200_1    1
    x[677]    c1080     1
    x[677]    c31       1
    x[677]    c202      -1
    x[678]    c201_1    1
    x[678]    c1081     1
    x[678]    c31       1
    x[678]    c202      -3
    x[679]    c202_1    1
    x[679]    c1082     1
    x[679]    c31       1
    x[679]    c202      -3
    x[680]    c203_1    1
    x[680]    c1083     1
    x[680]    c31       1
    x[680]    c202      -3
    x[681]    c204_1    1
    x[681]    c1084     1
    x[681]    c31       1
    x[681]    c202      -3
    x[682]    c205_1    1
    x[682]    c1085     1
    x[682]    c31       1
    x[682]    c202      -3
    x[683]    c201_1    1
    x[683]    c1086     1
    x[683]    c31       1
    x[683]    c202      -2
    x[684]    c202_1    1
    x[684]    c1087     1
    x[684]    c31       1
    x[684]    c202      -2
    x[685]    c203_1    1
    x[685]    c1088     1
    x[685]    c31       1
    x[685]    c202      -2
    x[686]    c204_1    1
    x[686]    c1089     1
    x[686]    c31       1
    x[686]    c202      -2
    x[687]    c205_1    1
    x[687]    c1090     1
    x[687]    c31       1
    x[687]    c202      -2
    x[688]    c201_1    1
    x[688]    c1091     1
    x[688]    c31       1
    x[688]    c202      -1
    x[689]    c202_1    1
    x[689]    c1092     1
    x[689]    c31       1
    x[689]    c202      -1
    x[690]    c203_1    1
    x[690]    c1093     1
    x[690]    c31       1
    x[690]    c202      -1
    x[691]    c204_1    1
    x[691]    c1094     1
    x[691]    c31       1
    x[691]    c202      -1
    x[692]    c205_1    1
    x[692]    c1095     1
    x[692]    c31       1
    x[692]    c202      -1
    x[693]    c206_1    1
    x[693]    c1096     1
    x[693]    c31       1
    x[693]    c202      -2
    x[694]    c207_1    1
    x[694]    c1097     1
    x[694]    c31       1
    x[694]    c202      -2
    x[695]    c208_1    1
    x[695]    c1098     1
    x[695]    c31       1
    x[695]    c202      -2
    x[696]    c209_1    1
    x[696]    c1099     1
    x[696]    c31       1
    x[696]    c202      -2
    x[697]    c210_1    1
    x[697]    c1100     1
    x[697]    c31       1
    x[697]    c202      -2
    x[698]    c206_1    1
    x[698]    c1101     1
    x[698]    c31       1
    x[698]    c202      -3
    x[699]    c207_1    1
    x[699]    c1102     1
    x[699]    c31       1
    x[699]    c202      -3
    x[700]    c208_1    1
    x[700]    c1103     1
    x[700]    c31       1
    x[700]    c202      -3
    x[701]    c209_1    1
    x[701]    c1104     1
    x[701]    c31       1
    x[701]    c202      -3
    x[702]    c210_1    1
    x[702]    c1105     1
    x[702]    c31       1
    x[702]    c202      -3
    x[703]    c206_1    1
    x[703]    c107      1
    x[703]    c426      -1
    x[703]    c428      -1
    x[703]    c430      -1
    x[704]    c207_1    1
    x[704]    c108      1
    x[704]    c432      -1
    x[704]    c434      -1
    x[705]    c208_1    1
    x[705]    c109      1
    x[705]    c436      -1
    x[705]    c438      -1
    x[706]    c209_1    1
    x[706]    c110      1
    x[706]    c440      -1
    x[706]    c442      -1
    x[707]    c210_1    1
    x[707]    c111      1
    x[707]    c444      -1
    x[707]    c446      -1
    x[708]    c206_1    1
    x[708]    c1106     1
    x[708]    c31       1
    x[708]    c202      -1
    x[709]    c207_1    1
    x[709]    c1107     1
    x[709]    c31       1
    x[709]    c202      -1
    x[710]    c208_1    1
    x[710]    c1108     1
    x[710]    c31       1
    x[710]    c202      -1
    x[711]    c209_1    1
    x[711]    c1109     1
    x[711]    c31       1
    x[711]    c202      -1
    x[712]    c210_1    1
    x[712]    c1110     1
    x[712]    c31       1
    x[712]    c202      -1
    x[713]    c211_1    1
    x[713]    c1111     1
    x[713]    c31       1
    x[713]    c202      -1
    x[714]    c212_1    1
    x[714]    c1112     1
    x[714]    c31       1
    x[714]    c202      -1
    x[715]    c213_1    1
    x[715]    c1113     1
    x[715]    c31       1
    x[715]    c202      -1
    x[716]    c214_1    1
    x[716]    c1114     1
    x[716]    c31       1
    x[716]    c202      -1
    x[717]    c215_1    1
    x[717]    c1115     1
    x[717]    c31       1
    x[717]    c202      -1
    x[718]    c211_1    1
    x[718]    c1116     1
    x[718]    c31       1
    x[718]    c202      -2
    x[719]    c212_1    1
    x[719]    c1117     1
    x[719]    c31       1
    x[719]    c202      -2
    x[720]    c213_1    1
    x[720]    c1118     1
    x[720]    c31       1
    x[720]    c202      -2
    x[721]    c214_1    1
    x[721]    c1119     1
    x[721]    c31       1
    x[721]    c202      -2
    x[722]    c215_1    1
    x[722]    c1120     1
    x[722]    c31       1
    x[722]    c202      -2
    x[723]    c211_1    1
    x[723]    c1121     1
    x[723]    c31       1
    x[723]    c202      -3
    x[724]    c212_1    1
    x[724]    c1122     1
    x[724]    c31       1
    x[724]    c202      -3
    x[725]    c213_1    1
    x[725]    c1123     1
    x[725]    c31       1
    x[725]    c202      -3
    x[726]    c214_1    1
    x[726]    c1124     1
    x[726]    c31       1
    x[726]    c202      -3
    x[727]    c215_1    1
    x[727]    c1125     1
    x[727]    c31       1
    x[727]    c202      -3
    x[728]    c216_1    1
    x[728]    c1126     1
    x[728]    c31       1
    x[728]    c202      -1
    x[729]    c217_1    1
    x[729]    c1127     1
    x[729]    c31       1
    x[729]    c202      -1
    x[730]    c218_1    1
    x[730]    c1128     1
    x[730]    c31       1
    x[730]    c202      -1
    x[731]    c219_1    1
    x[731]    c1129     1
    x[731]    c31       1
    x[731]    c202      -1
    x[732]    c220_1    1
    x[732]    c1130     1
    x[732]    c31       1
    x[732]    c202      -1
    x[733]    c216_1    1
    x[733]    c1131     1
    x[733]    c31       1
    x[733]    c202      -2
    x[734]    c217_1    1
    x[734]    c1132     1
    x[734]    c31       1
    x[734]    c202      -2
    x[735]    c218_1    1
    x[735]    c1133     1
    x[735]    c31       1
    x[735]    c202      -2
    x[736]    c219_1    1
    x[736]    c1134     1
    x[736]    c31       1
    x[736]    c202      -2
    x[737]    c220_1    1
    x[737]    c1135     1
    x[737]    c31       1
    x[737]    c202      -2
    x[738]    c216_1    1
    x[738]    c1136     1
    x[738]    c31       1
    x[738]    c202      -3
    x[739]    c217_1    1
    x[739]    c1137     1
    x[739]    c31       1
    x[739]    c202      -3
    x[740]    c218_1    1
    x[740]    c1138     1
    x[740]    c31       1
    x[740]    c202      -3
    x[741]    c219_1    1
    x[741]    c1139     1
    x[741]    c31       1
    x[741]    c202      -3
    x[742]    c220_1    1
    x[742]    c1140     1
    x[742]    c31       1
    x[742]    c202      -3
    x[743]    c221_1    1
    x[743]    c1141     1
    x[743]    c31       1
    x[743]    c202      -2
    x[744]    c222_1    1
    x[744]    c1142     1
    x[744]    c31       1
    x[744]    c202      -2
    x[745]    c223_1    1
    x[745]    c1143     1
    x[745]    c31       1
    x[745]    c202      -2
    x[746]    c224_1    1
    x[746]    c1144     1
    x[746]    c31       1
    x[746]    c202      -2
    x[747]    c225_1    1
    x[747]    c1145     1
    x[747]    c31       1
    x[747]    c202      -2
    x[748]    c221_1    1
    x[748]    c1146     1
    x[748]    c31       1
    x[748]    c202      -3
    x[749]    c222_1    1
    x[749]    c1147     1
    x[749]    c31       1
    x[749]    c202      -3
    x[750]    c223_1    1
    x[750]    c1148     1
    x[750]    c31       1
    x[750]    c202      -3
    x[751]    c224_1    1
    x[751]    c1149     1
    x[751]    c31       1
    x[751]    c202      -3
    x[752]    c225_1    1
    x[752]    c1150     1
    x[752]    c31       1
    x[752]    c202      -3
    x[753]    c221_1    1
    x[753]    c1151     1
    x[753]    c31       1
    x[753]    c202      -1
    x[754]    c222_1    1
    x[754]    c1152     1
    x[754]    c31       1
    x[754]    c202      -1
    x[755]    c223_1    1
    x[755]    c1153     1
    x[755]    c31       1
    x[755]    c202      -1
    x[756]    c224_1    1
    x[756]    c1154     1
    x[756]    c31       1
    x[756]    c202      -1
    x[757]    c225_1    1
    x[757]    c1155     1
    x[757]    c31       1
    x[757]    c202      -1
    x[758]    c226_1    1
    x[758]    c1156     1
    x[758]    c31       1
    x[758]    c202      -1
    x[759]    c227_1    1
    x[759]    c1157     1
    x[759]    c31       1
    x[759]    c202      -1
    x[760]    c228_1    1
    x[760]    c1158     1
    x[760]    c31       1
    x[760]    c202      -1
    x[761]    c229_1    1
    x[761]    c1159     1
    x[761]    c31       1
    x[761]    c202      -1
    x[762]    c230_1    1
    x[762]    c1160     1
    x[762]    c31       1
    x[762]    c202      -1
    x[763]    c226_1    1
    x[763]    c112      1
    x[763]    c448      -1
    x[763]    c451      -1
    x[764]    c227_1    1
    x[764]    c113      1
    x[764]    c454      -1
    x[764]    c457      -1
    x[765]    c228_1    1
    x[765]    c114      1
    x[765]    c460      -1
    x[765]    c463      -1
    x[766]    c229_1    1
    x[766]    c115      1
    x[766]    c466      -1
    x[766]    c469      -1
    x[767]    c230_1    1
    x[767]    c116      1
    x[767]    c472      -1
    x[767]    c475      -1
    x[768]    c226_1    1
    x[768]    c1161     1
    x[768]    c31       1
    x[768]    c202      -2
    x[769]    c227_1    1
    x[769]    c1162     1
    x[769]    c31       1
    x[769]    c202      -2
    x[770]    c228_1    1
    x[770]    c1163     1
    x[770]    c31       1
    x[770]    c202      -2
    x[771]    c229_1    1
    x[771]    c1164     1
    x[771]    c31       1
    x[771]    c202      -2
    x[772]    c230_1    1
    x[772]    c1165     1
    x[772]    c31       1
    x[772]    c202      -2
    x[773]    c226_1    1
    x[773]    c1166     1
    x[773]    c31       1
    x[773]    c202      -3
    x[774]    c227_1    1
    x[774]    c1167     1
    x[774]    c31       1
    x[774]    c202      -3
    x[775]    c228_1    1
    x[775]    c1168     1
    x[775]    c31       1
    x[775]    c202      -3
    x[776]    c229_1    1
    x[776]    c1169     1
    x[776]    c31       1
    x[776]    c202      -3
    x[777]    c230_1    1
    x[777]    c1170     1
    x[777]    c31       1
    x[777]    c202      -3
    x[778]    c231_1    1
    x[778]    c1171     1
    x[778]    c31       1
    x[778]    c202      -1
    x[779]    c232_1    1
    x[779]    c1172     1
    x[779]    c31       1
    x[779]    c202      -1
    x[780]    c233_1    1
    x[780]    c1173     1
    x[780]    c31       1
    x[780]    c202      -1
    x[781]    c234_1    1
    x[781]    c1174     1
    x[781]    c31       1
    x[781]    c202      -1
    x[782]    c235_1    1
    x[782]    c1175     1
    x[782]    c31       1
    x[782]    c202      -1
    x[783]    c231_1    1
    x[783]    c1176     1
    x[783]    c31       1
    x[783]    c202      -3
    x[784]    c232_1    1
    x[784]    c1177     1
    x[784]    c31       1
    x[784]    c202      -3
    x[785]    c233_1    1
    x[785]    c1178     1
    x[785]    c31       1
    x[785]    c202      -3
    x[786]    c234_1    1
    x[786]    c1179     1
    x[786]    c31       1
    x[786]    c202      -3
    x[787]    c235_1    1
    x[787]    c1180     1
    x[787]    c31       1
    x[787]    c202      -3
    x[788]    c231_1    1
    x[788]    c1181     1
    x[788]    c31       1
    x[788]    c202      -2
    x[789]    c232_1    1
    x[789]    c1182     1
    x[789]    c31       1
    x[789]    c202      -2
    x[790]    c233_1    1
    x[790]    c1183     1
    x[790]    c31       1
    x[790]    c202      -2
    x[791]    c234_1    1
    x[791]    c1184     1
    x[791]    c31       1
    x[791]    c202      -2
    x[792]    c235_1    1
    x[792]    c1185     1
    x[792]    c31       1
    x[792]    c202      -2
    x[793]    c231_1    1
    x[793]    c117      1
    x[793]    c630      -1
    x[793]    c636      -1
    x[794]    c232_1    1
    x[794]    c118      1
    x[794]    c640      -1
    x[794]    c644      -1
    x[795]    c233_1    1
    x[795]    c119      1
    x[795]    c648      -1
    x[795]    c652      -1
    x[796]    c234_1    1
    x[796]    c120      1
    x[796]    c656      -1
    x[796]    c660      -1
    x[797]    c235_1    1
    x[797]    c121      1
    x[797]    c664      -1
    x[797]    c668      -1
    x[798]    c236_1    1
    x[798]    c1186     1
    x[798]    c31       1
    x[798]    c202      -3
    x[799]    c237_1    1
    x[799]    c1187     1
    x[799]    c31       1
    x[799]    c202      -3
    x[800]    c238_1    1
    x[800]    c1188     1
    x[800]    c31       1
    x[800]    c202      -3
    x[801]    c239_1    1
    x[801]    c1189     1
    x[801]    c31       1
    x[801]    c202      -3
    x[802]    c240_1    1
    x[802]    c1190     1
    x[802]    c31       1
    x[802]    c202      -3
    x[803]    c236_1    1
    x[803]    c1191     1
    x[803]    c31       1
    x[803]    c202      -1
    x[804]    c237_1    1
    x[804]    c1192     1
    x[804]    c31       1
    x[804]    c202      -1
    x[805]    c238_1    1
    x[805]    c1193     1
    x[805]    c31       1
    x[805]    c202      -1
    x[806]    c239_1    1
    x[806]    c1194     1
    x[806]    c31       1
    x[806]    c202      -1
    x[807]    c240_1    1
    x[807]    c1195     1
    x[807]    c31       1
    x[807]    c202      -1
    x[808]    c236_1    1
    x[808]    c1196     1
    x[808]    c31       1
    x[808]    c202      -2
    x[809]    c237_1    1
    x[809]    c1197     1
    x[809]    c31       1
    x[809]    c202      -2
    x[810]    c238_1    1
    x[810]    c1198     1
    x[810]    c31       1
    x[810]    c202      -2
    x[811]    c239_1    1
    x[811]    c1199     1
    x[811]    c31       1
    x[811]    c202      -2
    x[812]    c240_1    1
    x[812]    c1200     1
    x[812]    c31       1
    x[812]    c202      -2
    x[813]    c241_1    1
    x[813]    c1201     1
    x[813]    c31       1
    x[813]    c202      -3
    x[814]    c242_1    1
    x[814]    c1202     1
    x[814]    c31       1
    x[814]    c202      -3
    x[815]    c243_1    1
    x[815]    c1203     1
    x[815]    c31       1
    x[815]    c202      -3
    x[816]    c244_1    1
    x[816]    c1204     1
    x[816]    c31       1
    x[816]    c202      -3
    x[817]    c245_1    1
    x[817]    c1205     1
    x[817]    c31       1
    x[817]    c202      -3
    x[818]    c241_1    1
    x[818]    c1206     1
    x[818]    c31       1
    x[818]    c202      -2
    x[819]    c242_1    1
    x[819]    c1207     1
    x[819]    c31       1
    x[819]    c202      -2
    x[820]    c243_1    1
    x[820]    c1208     1
    x[820]    c31       1
    x[820]    c202      -2
    x[821]    c244_1    1
    x[821]    c1209     1
    x[821]    c31       1
    x[821]    c202      -2
    x[822]    c245_1    1
    x[822]    c1210     1
    x[822]    c31       1
    x[822]    c202      -2
    x[823]    c241_1    1
    x[823]    c1211     1
    x[823]    c31       1
    x[823]    c202      -1
    x[824]    c242_1    1
    x[824]    c1212     1
    x[824]    c31       1
    x[824]    c202      -1
    x[825]    c243_1    1
    x[825]    c1213     1
    x[825]    c31       1
    x[825]    c202      -1
    x[826]    c244_1    1
    x[826]    c1214     1
    x[826]    c31       1
    x[826]    c202      -1
    x[827]    c245_1    1
    x[827]    c1215     1
    x[827]    c31       1
    x[827]    c202      -1
    x[828]    c246_1    1
    x[828]    c1216     1
    x[828]    c31       1
    x[828]    c202      -1
    x[829]    c247_1    1
    x[829]    c1217     1
    x[829]    c31       1
    x[829]    c202      -1
    x[830]    c248_1    1
    x[830]    c1218     1
    x[830]    c31       1
    x[830]    c202      -1
    x[831]    c249_1    1
    x[831]    c1219     1
    x[831]    c31       1
    x[831]    c202      -1
    x[832]    c250_1    1
    x[832]    c1220     1
    x[832]    c31       1
    x[832]    c202      -1
    x[833]    c246_1    1
    x[833]    c1221     1
    x[833]    c31       1
    x[833]    c202      -2
    x[834]    c247_1    1
    x[834]    c1222     1
    x[834]    c31       1
    x[834]    c202      -2
    x[835]    c248_1    1
    x[835]    c1223     1
    x[835]    c31       1
    x[835]    c202      -2
    x[836]    c249_1    1
    x[836]    c1224     1
    x[836]    c31       1
    x[836]    c202      -2
    x[837]    c250_1    1
    x[837]    c1225     1
    x[837]    c31       1
    x[837]    c202      -2
    x[838]    c246_1    1
    x[838]    c1226     1
    x[838]    c31       1
    x[838]    c202      -3
    x[839]    c247_1    1
    x[839]    c1227     1
    x[839]    c31       1
    x[839]    c202      -3
    x[840]    c248_1    1
    x[840]    c1228     1
    x[840]    c31       1
    x[840]    c202      -3
    x[841]    c249_1    1
    x[841]    c1229     1
    x[841]    c31       1
    x[841]    c202      -3
    x[842]    c250_1    1
    x[842]    c1230     1
    x[842]    c31       1
    x[842]    c202      -3
    x[843]    c251_1    1
    x[843]    c122      1
    x[843]    c206      -1
    x[843]    c210      -1
    x[844]    c252_1    1
    x[844]    c123      1
    x[844]    c214      -1
    x[844]    c218      -1
    x[845]    c253_1    1
    x[845]    c124      1
    x[845]    c222      -1
    x[845]    c228      -1
    x[846]    c254_1    1
    x[846]    c125      1
    x[846]    c232      -1
    x[846]    c236      -1
    x[847]    c255_1    1
    x[847]    c126      1
    x[847]    c240      -1
    x[847]    c244      -1
    x[848]    c251_1    1
    x[848]    c1231     1
    x[848]    c31       1
    x[848]    c202      -3
    x[849]    c252_1    1
    x[849]    c1232     1
    x[849]    c31       1
    x[849]    c202      -3
    x[850]    c253_1    1
    x[850]    c1233     1
    x[850]    c31       1
    x[850]    c202      -3
    x[851]    c254_1    1
    x[851]    c1234     1
    x[851]    c31       1
    x[851]    c202      -3
    x[852]    c255_1    1
    x[852]    c1235     1
    x[852]    c31       1
    x[852]    c202      -3
    x[853]    c251_1    1
    x[853]    c1236     1
    x[853]    c31       1
    x[853]    c202      -2
    x[854]    c252_1    1
    x[854]    c1237     1
    x[854]    c31       1
    x[854]    c202      -2
    x[855]    c253_1    1
    x[855]    c1238     1
    x[855]    c31       1
    x[855]    c202      -2
    x[856]    c254_1    1
    x[856]    c1239     1
    x[856]    c31       1
    x[856]    c202      -2
    x[857]    c255_1    1
    x[857]    c1240     1
    x[857]    c31       1
    x[857]    c202      -2
    x[858]    c251_1    1
    x[858]    c1241     1
    x[858]    c31       1
    x[858]    c202      -1
    x[859]    c252_1    1
    x[859]    c1242     1
    x[859]    c31       1
    x[859]    c202      -1
    x[860]    c253_1    1
    x[860]    c1243     1
    x[860]    c31       1
    x[860]    c202      -1
    x[861]    c254_1    1
    x[861]    c1244     1
    x[861]    c31       1
    x[861]    c202      -1
    x[862]    c255_1    1
    x[862]    c1245     1
    x[862]    c31       1
    x[862]    c202      -1
    x[863]    c256_1    1
    x[863]    c1246     1
    x[863]    c31       1
    x[863]    c202      -2
    x[864]    c257_1    1
    x[864]    c1247     1
    x[864]    c31       1
    x[864]    c202      -2
    x[865]    c258_1    1
    x[865]    c1248     1
    x[865]    c31       1
    x[865]    c202      -2
    x[866]    c259_1    1
    x[866]    c1249     1
    x[866]    c31       1
    x[866]    c202      -2
    x[867]    c260_1    1
    x[867]    c1250     1
    x[867]    c31       1
    x[867]    c202      -2
    x[868]    c256_1    1
    x[868]    c127      1
    x[868]    c406      -1
    x[868]    c408      -1
    x[869]    c257_1    1
    x[869]    c128      1
    x[869]    c410      -1
    x[869]    c412      -1
    x[870]    c258_1    1
    x[870]    c129      1
    x[870]    c414      -1
    x[870]    c416      -1
    x[871]    c259_1    1
    x[871]    c130      1
    x[871]    c418      -1
    x[871]    c420      -1
    x[872]    c260_1    1
    x[872]    c131      1
    x[872]    c422      -1
    x[872]    c424      -1
    x[873]    c256_1    1
    x[873]    c1251     1
    x[873]    c31       1
    x[873]    c202      -1
    x[874]    c257_1    1
    x[874]    c1252     1
    x[874]    c31       1
    x[874]    c202      -1
    x[875]    c258_1    1
    x[875]    c1253     1
    x[875]    c31       1
    x[875]    c202      -1
    x[876]    c259_1    1
    x[876]    c1254     1
    x[876]    c31       1
    x[876]    c202      -1
    x[877]    c260_1    1
    x[877]    c1255     1
    x[877]    c31       1
    x[877]    c202      -1
    x[878]    c256_1    1
    x[878]    c1256     1
    x[878]    c31       1
    x[878]    c202      -3
    x[879]    c257_1    1
    x[879]    c1257     1
    x[879]    c31       1
    x[879]    c202      -3
    x[880]    c258_1    1
    x[880]    c1258     1
    x[880]    c31       1
    x[880]    c202      -3
    x[881]    c259_1    1
    x[881]    c1259     1
    x[881]    c31       1
    x[881]    c202      -3
    x[882]    c260_1    1
    x[882]    c1260     1
    x[882]    c31       1
    x[882]    c202      -3
    x[883]    c261_1    1
    x[883]    c1261     1
    x[883]    c31       1
    x[883]    c202      -3
    x[884]    c262_1    1
    x[884]    c1262     1
    x[884]    c31       1
    x[884]    c202      -3
    x[885]    c263_1    1
    x[885]    c1263     1
    x[885]    c31       1
    x[885]    c202      -3
    x[886]    c264_1    1
    x[886]    c1264     1
    x[886]    c31       1
    x[886]    c202      -3
    x[887]    c265_1    1
    x[887]    c1265     1
    x[887]    c31       1
    x[887]    c202      -3
    x[888]    c261_1    1
    x[888]    c1266     1
    x[888]    c31       1
    x[888]    c202      -1
    x[889]    c262_1    1
    x[889]    c1267     1
    x[889]    c31       1
    x[889]    c202      -1
    x[890]    c263_1    1
    x[890]    c1268     1
    x[890]    c31       1
    x[890]    c202      -1
    x[891]    c264_1    1
    x[891]    c1269     1
    x[891]    c31       1
    x[891]    c202      -1
    x[892]    c265_1    1
    x[892]    c1270     1
    x[892]    c31       1
    x[892]    c202      -1
    x[893]    c261_1    1
    x[893]    c1271     1
    x[893]    c31       1
    x[893]    c202      -2
    x[894]    c262_1    1
    x[894]    c1272     1
    x[894]    c31       1
    x[894]    c202      -2
    x[895]    c263_1    1
    x[895]    c1273     1
    x[895]    c31       1
    x[895]    c202      -2
    x[896]    c264_1    1
    x[896]    c1274     1
    x[896]    c31       1
    x[896]    c202      -2
    x[897]    c265_1    1
    x[897]    c1275     1
    x[897]    c31       1
    x[897]    c202      -2
    x[898]    c266_1    1
    x[898]    c1276     1
    x[898]    c31       1
    x[898]    c202      -1
    x[899]    c267_1    1
    x[899]    c1277     1
    x[899]    c31       1
    x[899]    c202      -1
    x[900]    c268_1    1
    x[900]    c1278     1
    x[900]    c31       1
    x[900]    c202      -1
    x[901]    c269_1    1
    x[901]    c1279     1
    x[901]    c31       1
    x[901]    c202      -1
    x[902]    c270_1    1
    x[902]    c1280     1
    x[902]    c31       1
    x[902]    c202      -1
    x[903]    c266_1    1
    x[903]    c1281     1
    x[903]    c31       1
    x[903]    c202      -3
    x[904]    c267_1    1
    x[904]    c1282     1
    x[904]    c31       1
    x[904]    c202      -3
    x[905]    c268_1    1
    x[905]    c1283     1
    x[905]    c31       1
    x[905]    c202      -3
    x[906]    c269_1    1
    x[906]    c1284     1
    x[906]    c31       1
    x[906]    c202      -3
    x[907]    c270_1    1
    x[907]    c1285     1
    x[907]    c31       1
    x[907]    c202      -3
    x[908]    c266_1    1
    x[908]    c1286     1
    x[908]    c31       1
    x[908]    c202      -2
    x[909]    c267_1    1
    x[909]    c1287     1
    x[909]    c31       1
    x[909]    c202      -2
    x[910]    c268_1    1
    x[910]    c1288     1
    x[910]    c31       1
    x[910]    c202      -2
    x[911]    c269_1    1
    x[911]    c1289     1
    x[911]    c31       1
    x[911]    c202      -2
    x[912]    c270_1    1
    x[912]    c1290     1
    x[912]    c31       1
    x[912]    c202      -2
    x[913]    c271_1    1
    x[913]    c1291     1
    x[913]    c31       1
    x[913]    c202      -3
    x[914]    c272_1    1
    x[914]    c1292     1
    x[914]    c31       1
    x[914]    c202      -3
    x[915]    c273_1    1
    x[915]    c1293     1
    x[915]    c31       1
    x[915]    c202      -3
    x[916]    c274_1    1
    x[916]    c1294     1
    x[916]    c31       1
    x[916]    c202      -3
    x[917]    c275_1    1
    x[917]    c1295     1
    x[917]    c31       1
    x[917]    c202      -3
    x[918]    c271_1    1
    x[918]    c1296     1
    x[918]    c31       1
    x[918]    c202      -2
    x[919]    c272_1    1
    x[919]    c1297     1
    x[919]    c31       1
    x[919]    c202      -2
    x[920]    c273_1    1
    x[920]    c1298     1
    x[920]    c31       1
    x[920]    c202      -2
    x[921]    c274_1    1
    x[921]    c1299     1
    x[921]    c31       1
    x[921]    c202      -2
    x[922]    c275_1    1
    x[922]    c1300     1
    x[922]    c31       1
    x[922]    c202      -2
    x[923]    c271_1    1
    x[923]    c1301     1
    x[923]    c31       1
    x[923]    c202      -1
    x[924]    c272_1    1
    x[924]    c1302     1
    x[924]    c31       1
    x[924]    c202      -1
    x[925]    c273_1    1
    x[925]    c1303     1
    x[925]    c31       1
    x[925]    c202      -1
    x[926]    c274_1    1
    x[926]    c1304     1
    x[926]    c31       1
    x[926]    c202      -1
    x[927]    c275_1    1
    x[927]    c1305     1
    x[927]    c31       1
    x[927]    c202      -1
    x[928]    c276_1    1
    x[928]    c1306     1
    x[928]    c31       1
    x[928]    c202      -1
    x[929]    c277_1    1
    x[929]    c1307     1
    x[929]    c31       1
    x[929]    c202      -1
    x[930]    c278_1    1
    x[930]    c1308     1
    x[930]    c31       1
    x[930]    c202      -1
    x[931]    c279_1    1
    x[931]    c1309     1
    x[931]    c31       1
    x[931]    c202      -1
    x[932]    c280_1    1
    x[932]    c1310     1
    x[932]    c31       1
    x[932]    c202      -1
    x[933]    c276_1    1
    x[933]    c1311     1
    x[933]    c31       1
    x[933]    c202      -3
    x[934]    c277_1    1
    x[934]    c1312     1
    x[934]    c31       1
    x[934]    c202      -3
    x[935]    c278_1    1
    x[935]    c1313     1
    x[935]    c31       1
    x[935]    c202      -3
    x[936]    c279_1    1
    x[936]    c1314     1
    x[936]    c31       1
    x[936]    c202      -3
    x[937]    c280_1    1
    x[937]    c1315     1
    x[937]    c31       1
    x[937]    c202      -3
    x[938]    c276_1    1
    x[938]    c1316     1
    x[938]    c31       1
    x[938]    c202      -2
    x[939]    c277_1    1
    x[939]    c1317     1
    x[939]    c31       1
    x[939]    c202      -2
    x[940]    c278_1    1
    x[940]    c1318     1
    x[940]    c31       1
    x[940]    c202      -2
    x[941]    c279_1    1
    x[941]    c1319     1
    x[941]    c31       1
    x[941]    c202      -2
    x[942]    c280_1    1
    x[942]    c1320     1
    x[942]    c31       1
    x[942]    c202      -2
    x[943]    c281_1    1
    x[943]    c1321     1
    x[943]    c31       1
    x[943]    c202      -1
    x[944]    c282_1    1
    x[944]    c1322     1
    x[944]    c31       1
    x[944]    c202      -1
    x[945]    c283_1    1
    x[945]    c1323     1
    x[945]    c31       1
    x[945]    c202      -1
    x[946]    c284_1    1
    x[946]    c1324     1
    x[946]    c31       1
    x[946]    c202      -1
    x[947]    c285_1    1
    x[947]    c1325     1
    x[947]    c31       1
    x[947]    c202      -1
    x[948]    c281_1    1
    x[948]    c1326     1
    x[948]    c31       1
    x[948]    c202      -2
    x[949]    c282_1    1
    x[949]    c1327     1
    x[949]    c31       1
    x[949]    c202      -2
    x[950]    c283_1    1
    x[950]    c1328     1
    x[950]    c31       1
    x[950]    c202      -2
    x[951]    c284_1    1
    x[951]    c1329     1
    x[951]    c31       1
    x[951]    c202      -2
    x[952]    c285_1    1
    x[952]    c1330     1
    x[952]    c31       1
    x[952]    c202      -2
    x[953]    c281_1    1
    x[953]    c1331     1
    x[953]    c31       1
    x[953]    c202      -3
    x[954]    c282_1    1
    x[954]    c1332     1
    x[954]    c31       1
    x[954]    c202      -3
    x[955]    c283_1    1
    x[955]    c1333     1
    x[955]    c31       1
    x[955]    c202      -3
    x[956]    c284_1    1
    x[956]    c1334     1
    x[956]    c31       1
    x[956]    c202      -3
    x[957]    c285_1    1
    x[957]    c1335     1
    x[957]    c31       1
    x[957]    c202      -3
    x[958]    c286_1    1
    x[958]    c1336     1
    x[958]    c31       1
    x[958]    c202      -1
    x[959]    c287_1    1
    x[959]    c1337     1
    x[959]    c31       1
    x[959]    c202      -1
    x[960]    c288_1    1
    x[960]    c1338     1
    x[960]    c31       1
    x[960]    c202      -1
    x[961]    c289_1    1
    x[961]    c1339     1
    x[961]    c31       1
    x[961]    c202      -1
    x[962]    c290_1    1
    x[962]    c1340     1
    x[962]    c31       1
    x[962]    c202      -1
    x[963]    c286_1    1
    x[963]    c132      1
    x[963]    c449      -1
    x[963]    c452      -1
    x[964]    c287_1    1
    x[964]    c133      1
    x[964]    c455      -1
    x[964]    c458      -1
    x[965]    c288_1    1
    x[965]    c134      1
    x[965]    c461      -1
    x[965]    c464      -1
    x[966]    c289_1    1
    x[966]    c135      1
    x[966]    c467      -1
    x[966]    c470      -1
    x[967]    c290_1    1
    x[967]    c136      1
    x[967]    c473      -1
    x[967]    c476      -1
    x[968]    c286_1    1
    x[968]    c1341     1
    x[968]    c31       1
    x[968]    c202      -2
    x[969]    c287_1    1
    x[969]    c1342     1
    x[969]    c31       1
    x[969]    c202      -2
    x[970]    c288_1    1
    x[970]    c1343     1
    x[970]    c31       1
    x[970]    c202      -2
    x[971]    c289_1    1
    x[971]    c1344     1
    x[971]    c31       1
    x[971]    c202      -2
    x[972]    c290_1    1
    x[972]    c1345     1
    x[972]    c31       1
    x[972]    c202      -2
    x[973]    c286_1    1
    x[973]    c1346     1
    x[973]    c31       1
    x[973]    c202      -3
    x[974]    c287_1    1
    x[974]    c1347     1
    x[974]    c31       1
    x[974]    c202      -3
    x[975]    c288_1    1
    x[975]    c1348     1
    x[975]    c31       1
    x[975]    c202      -3
    x[976]    c289_1    1
    x[976]    c1349     1
    x[976]    c31       1
    x[976]    c202      -3
    x[977]    c290_1    1
    x[977]    c1350     1
    x[977]    c31       1
    x[977]    c202      -3
    x[978]    c291_1    1
    x[978]    c1351     1
    x[978]    c31       1
    x[978]    c202      -2
    x[979]    c292_1    1
    x[979]    c1352     1
    x[979]    c31       1
    x[979]    c202      -2
    x[980]    c293_1    1
    x[980]    c1353     1
    x[980]    c31       1
    x[980]    c202      -2
    x[981]    c294_1    1
    x[981]    c1354     1
    x[981]    c31       1
    x[981]    c202      -2
    x[982]    c295_1    1
    x[982]    c1355     1
    x[982]    c31       1
    x[982]    c202      -2
    x[983]    c291_1    1
    x[983]    c1356     1
    x[983]    c31       1
    x[983]    c202      -1
    x[984]    c292_1    1
    x[984]    c1357     1
    x[984]    c31       1
    x[984]    c202      -1
    x[985]    c293_1    1
    x[985]    c1358     1
    x[985]    c31       1
    x[985]    c202      -1
    x[986]    c294_1    1
    x[986]    c1359     1
    x[986]    c31       1
    x[986]    c202      -1
    x[987]    c295_1    1
    x[987]    c1360     1
    x[987]    c31       1
    x[987]    c202      -1
    x[988]    c291_1    1
    x[988]    c1361     1
    x[988]    c31       1
    x[988]    c202      -3
    x[989]    c292_1    1
    x[989]    c1362     1
    x[989]    c31       1
    x[989]    c202      -3
    x[990]    c293_1    1
    x[990]    c1363     1
    x[990]    c31       1
    x[990]    c202      -3
    x[991]    c294_1    1
    x[991]    c1364     1
    x[991]    c31       1
    x[991]    c202      -3
    x[992]    c295_1    1
    x[992]    c1365     1
    x[992]    c31       1
    x[992]    c202      -3
    x[993]    c296_1    1
    x[993]    c1366     1
    x[993]    c31       1
    x[993]    c202      -1
    x[994]    c297_1    1
    x[994]    c1367     1
    x[994]    c31       1
    x[994]    c202      -1
    x[995]    c298_1    1
    x[995]    c1368     1
    x[995]    c31       1
    x[995]    c202      -1
    x[996]    c299_1    1
    x[996]    c1369     1
    x[996]    c31       1
    x[996]    c202      -1
    x[997]    c300_1    1
    x[997]    c1370     1
    x[997]    c31       1
    x[997]    c202      -1
    x[998]    c296_1    1
    x[998]    c1371     1
    x[998]    c31       1
    x[998]    c202      -2
    x[999]    c297_1    1
    x[999]    c1372     1
    x[999]    c31       1
    x[999]    c202      -2
    x[1000]   c298_1    1
    x[1000]   c1373     1
    x[1000]   c31       1
    x[1000]   c202      -2
    x[1001]   c299_1    1
    x[1001]   c1374     1
    x[1001]   c31       1
    x[1001]   c202      -2
    x[1002]   c300_1    1
    x[1002]   c1375     1
    x[1002]   c31       1
    x[1002]   c202      -2
    x[1003]   c296_1    1
    x[1003]   c1376     1
    x[1003]   c31       1
    x[1003]   c202      -3
    x[1004]   c297_1    1
    x[1004]   c1377     1
    x[1004]   c31       1
    x[1004]   c202      -3
    x[1005]   c298_1    1
    x[1005]   c1378     1
    x[1005]   c31       1
    x[1005]   c202      -3
    x[1006]   c299_1    1
    x[1006]   c1379     1
    x[1006]   c31       1
    x[1006]   c202      -3
    x[1007]   c300_1    1
    x[1007]   c1380     1
    x[1007]   c31       1
    x[1007]   c202      -3
    x[1008]   c301_1    1
    x[1008]   c1381     1
    x[1008]   c31       1
    x[1008]   c202      -2
    x[1009]   c302_1    1
    x[1009]   c1382     1
    x[1009]   c31       1
    x[1009]   c202      -2
    x[1010]   c303_1    1
    x[1010]   c1383     1
    x[1010]   c31       1
    x[1010]   c202      -2
    x[1011]   c304_1    1
    x[1011]   c1384     1
    x[1011]   c31       1
    x[1011]   c202      -2
    x[1012]   c305_1    1
    x[1012]   c1385     1
    x[1012]   c31       1
    x[1012]   c202      -2
    x[1013]   c301_1    1
    x[1013]   c1386     1
    x[1013]   c31       1
    x[1013]   c202      -1
    x[1014]   c302_1    1
    x[1014]   c1387     1
    x[1014]   c31       1
    x[1014]   c202      -1
    x[1015]   c303_1    1
    x[1015]   c1388     1
    x[1015]   c31       1
    x[1015]   c202      -1
    x[1016]   c304_1    1
    x[1016]   c1389     1
    x[1016]   c31       1
    x[1016]   c202      -1
    x[1017]   c305_1    1
    x[1017]   c1390     1
    x[1017]   c31       1
    x[1017]   c202      -1
    x[1018]   c301_1    1
    x[1018]   c1391     1
    x[1018]   c31       1
    x[1018]   c202      -3
    x[1019]   c302_1    1
    x[1019]   c1392     1
    x[1019]   c31       1
    x[1019]   c202      -3
    x[1020]   c303_1    1
    x[1020]   c1393     1
    x[1020]   c31       1
    x[1020]   c202      -3
    x[1021]   c304_1    1
    x[1021]   c1394     1
    x[1021]   c31       1
    x[1021]   c202      -3
    x[1022]   c305_1    1
    x[1022]   c1395     1
    x[1022]   c31       1
    x[1022]   c202      -3
    x[1023]   c306_1    1
    x[1023]   c1396     1
    x[1023]   c31       1
    x[1023]   c202      -3
    x[1024]   c307_1    1
    x[1024]   c1397     1
    x[1024]   c31       1
    x[1024]   c202      -3
    x[1025]   c308_1    1
    x[1025]   c1398     1
    x[1025]   c31       1
    x[1025]   c202      -3
    x[1026]   c309_1    1
    x[1026]   c1399     1
    x[1026]   c31       1
    x[1026]   c202      -3
    x[1027]   c310_1    1
    x[1027]   c1400     1
    x[1027]   c31       1
    x[1027]   c202      -3
    x[1028]   c306_1    1
    x[1028]   c1401     1
    x[1028]   c31       1
    x[1028]   c202      -1
    x[1029]   c307_1    1
    x[1029]   c1402     1
    x[1029]   c31       1
    x[1029]   c202      -1
    x[1030]   c308_1    1
    x[1030]   c1403     1
    x[1030]   c31       1
    x[1030]   c202      -1
    x[1031]   c309_1    1
    x[1031]   c1404     1
    x[1031]   c31       1
    x[1031]   c202      -1
    x[1032]   c310_1    1
    x[1032]   c1405     1
    x[1032]   c31       1
    x[1032]   c202      -1
    x[1033]   c306_1    1
    x[1033]   c1406     1
    x[1033]   c31       1
    x[1033]   c202      -2
    x[1034]   c307_1    1
    x[1034]   c1407     1
    x[1034]   c31       1
    x[1034]   c202      -2
    x[1035]   c308_1    1
    x[1035]   c1408     1
    x[1035]   c31       1
    x[1035]   c202      -2
    x[1036]   c309_1    1
    x[1036]   c1409     1
    x[1036]   c31       1
    x[1036]   c202      -2
    x[1037]   c310_1    1
    x[1037]   c1410     1
    x[1037]   c31       1
    x[1037]   c202      -2
    x[1038]   c311_1    1
    x[1038]   c1411     1
    x[1038]   c31       1
    x[1038]   c202      -3
    x[1039]   c312_1    1
    x[1039]   c1412     1
    x[1039]   c31       1
    x[1039]   c202      -3
    x[1040]   c313_1    1
    x[1040]   c1413     1
    x[1040]   c31       1
    x[1040]   c202      -3
    x[1041]   c314_1    1
    x[1041]   c1414     1
    x[1041]   c31       1
    x[1041]   c202      -3
    x[1042]   c315_1    1
    x[1042]   c1415     1
    x[1042]   c31       1
    x[1042]   c202      -3
    x[1043]   c311_1    1
    x[1043]   c1416     1
    x[1043]   c31       1
    x[1043]   c202      -1
    x[1044]   c312_1    1
    x[1044]   c1417     1
    x[1044]   c31       1
    x[1044]   c202      -1
    x[1045]   c313_1    1
    x[1045]   c1418     1
    x[1045]   c31       1
    x[1045]   c202      -1
    x[1046]   c314_1    1
    x[1046]   c1419     1
    x[1046]   c31       1
    x[1046]   c202      -1
    x[1047]   c315_1    1
    x[1047]   c1420     1
    x[1047]   c31       1
    x[1047]   c202      -1
    x[1048]   c311_1    1
    x[1048]   c1421     1
    x[1048]   c31       1
    x[1048]   c202      -2
    x[1049]   c312_1    1
    x[1049]   c1422     1
    x[1049]   c31       1
    x[1049]   c202      -2
    x[1050]   c313_1    1
    x[1050]   c1423     1
    x[1050]   c31       1
    x[1050]   c202      -2
    x[1051]   c314_1    1
    x[1051]   c1424     1
    x[1051]   c31       1
    x[1051]   c202      -2
    x[1052]   c315_1    1
    x[1052]   c1425     1
    x[1052]   c31       1
    x[1052]   c202      -2
    x[1053]   c316_1    1
    x[1053]   c137      1
    x[1053]   c609      -1
    x[1053]   c611      -1
    x[1054]   c317_1    1
    x[1054]   c138      1
    x[1054]   c613      -1
    x[1054]   c615      -1
    x[1055]   c318_1    1
    x[1055]   c139      1
    x[1055]   c617      -1
    x[1055]   c619      -1
    x[1056]   c319_1    1
    x[1056]   c140      1
    x[1056]   c621      -1
    x[1056]   c623      -1
    x[1057]   c320_1    1
    x[1057]   c141      1
    x[1057]   c625      -1
    x[1057]   c627      -1
    x[1058]   c316_1    1
    x[1058]   c1426     1
    x[1058]   c31       1
    x[1058]   c202      -3
    x[1059]   c317_1    1
    x[1059]   c1427     1
    x[1059]   c31       1
    x[1059]   c202      -3
    x[1060]   c318_1    1
    x[1060]   c1428     1
    x[1060]   c31       1
    x[1060]   c202      -3
    x[1061]   c319_1    1
    x[1061]   c1429     1
    x[1061]   c31       1
    x[1061]   c202      -3
    x[1062]   c320_1    1
    x[1062]   c1430     1
    x[1062]   c31       1
    x[1062]   c202      -3
    x[1063]   c316_1    1
    x[1063]   c1431     1
    x[1063]   c31       1
    x[1063]   c202      -2
    x[1064]   c317_1    1
    x[1064]   c1432     1
    x[1064]   c31       1
    x[1064]   c202      -2
    x[1065]   c318_1    1
    x[1065]   c1433     1
    x[1065]   c31       1
    x[1065]   c202      -2
    x[1066]   c319_1    1
    x[1066]   c1434     1
    x[1066]   c31       1
    x[1066]   c202      -2
    x[1067]   c320_1    1
    x[1067]   c1435     1
    x[1067]   c31       1
    x[1067]   c202      -2
    x[1068]   c316_1    1
    x[1068]   c1436     1
    x[1068]   c31       1
    x[1068]   c202      -1
    x[1069]   c317_1    1
    x[1069]   c1437     1
    x[1069]   c31       1
    x[1069]   c202      -1
    x[1070]   c318_1    1
    x[1070]   c1438     1
    x[1070]   c31       1
    x[1070]   c202      -1
    x[1071]   c319_1    1
    x[1071]   c1439     1
    x[1071]   c31       1
    x[1071]   c202      -1
    x[1072]   c320_1    1
    x[1072]   c1440     1
    x[1072]   c31       1
    x[1072]   c202      -1
    x[1073]   c321_1    1
    x[1073]   c1441     1
    x[1073]   c31       1
    x[1073]   c202      -1
    x[1074]   c322_1    1
    x[1074]   c1442     1
    x[1074]   c31       1
    x[1074]   c202      -1
    x[1075]   c323_1    1
    x[1075]   c1443     1
    x[1075]   c31       1
    x[1075]   c202      -1
    x[1076]   c324_1    1
    x[1076]   c1444     1
    x[1076]   c31       1
    x[1076]   c202      -1
    x[1077]   c325_1    1
    x[1077]   c1445     1
    x[1077]   c31       1
    x[1077]   c202      -1
    x[1078]   c321_1    1
    x[1078]   c142      1
    x[1078]   c366      -1
    x[1078]   c370      -1
    x[1079]   c322_1    1
    x[1079]   c143      1
    x[1079]   c374      -1
    x[1079]   c378      -1
    x[1080]   c323_1    1
    x[1080]   c144      1
    x[1080]   c382      -1
    x[1080]   c386      -1
    x[1081]   c324_1    1
    x[1081]   c145      1
    x[1081]   c390      -1
    x[1081]   c394      -1
    x[1082]   c325_1    1
    x[1082]   c146      1
    x[1082]   c398      -1
    x[1082]   c402      -1
    x[1083]   c321_1    1
    x[1083]   c1446     1
    x[1083]   c31       1
    x[1083]   c202      -2
    x[1084]   c322_1    1
    x[1084]   c1447     1
    x[1084]   c31       1
    x[1084]   c202      -2
    x[1085]   c323_1    1
    x[1085]   c1448     1
    x[1085]   c31       1
    x[1085]   c202      -2
    x[1086]   c324_1    1
    x[1086]   c1449     1
    x[1086]   c31       1
    x[1086]   c202      -2
    x[1087]   c325_1    1
    x[1087]   c1450     1
    x[1087]   c31       1
    x[1087]   c202      -2
    x[1088]   c321_1    1
    x[1088]   c1451     1
    x[1088]   c31       1
    x[1088]   c202      -3
    x[1089]   c322_1    1
    x[1089]   c1452     1
    x[1089]   c31       1
    x[1089]   c202      -3
    x[1090]   c323_1    1
    x[1090]   c1453     1
    x[1090]   c31       1
    x[1090]   c202      -3
    x[1091]   c324_1    1
    x[1091]   c1454     1
    x[1091]   c31       1
    x[1091]   c202      -3
    x[1092]   c325_1    1
    x[1092]   c1455     1
    x[1092]   c31       1
    x[1092]   c202      -3
    x[1093]   c326_1    1
    x[1093]   c1456     1
    x[1093]   c31       1
    x[1093]   c202      -2
    x[1094]   c327_1    1
    x[1094]   c1457     1
    x[1094]   c31       1
    x[1094]   c202      -2
    x[1095]   c328_1    1
    x[1095]   c1458     1
    x[1095]   c31       1
    x[1095]   c202      -2
    x[1096]   c329_1    1
    x[1096]   c1459     1
    x[1096]   c31       1
    x[1096]   c202      -2
    x[1097]   c330_1    1
    x[1097]   c1460     1
    x[1097]   c31       1
    x[1097]   c202      -2
    x[1098]   c326_1    1
    x[1098]   c1461     1
    x[1098]   c31       1
    x[1098]   c202      -1
    x[1099]   c327_1    1
    x[1099]   c1462     1
    x[1099]   c31       1
    x[1099]   c202      -1
    x[1100]   c328_1    1
    x[1100]   c1463     1
    x[1100]   c31       1
    x[1100]   c202      -1
    x[1101]   c329_1    1
    x[1101]   c1464     1
    x[1101]   c31       1
    x[1101]   c202      -1
    x[1102]   c330_1    1
    x[1102]   c1465     1
    x[1102]   c31       1
    x[1102]   c202      -1
    x[1103]   c326_1    1
    x[1103]   c147      1
    x[1103]   c757      -1
    x[1103]   c763      -1
    x[1103]   c767      -1
    x[1104]   c327_1    1
    x[1104]   c148      1
    x[1104]   c825      -1
    x[1104]   c831      -1
    x[1104]   c835      -1
    x[1105]   c328_1    1
    x[1105]   c149      1
    x[1105]   c874      -1
    x[1105]   c880      -1
    x[1105]   c884      -1
    x[1106]   c329_1    1
    x[1106]   c150      1
    x[1107]   c330_1    1
    x[1107]   c151      1
    x[1108]   c326_1    1
    x[1108]   c1466     1
    x[1108]   c31       1
    x[1108]   c202      -3
    x[1109]   c327_1    1
    x[1109]   c1467     1
    x[1109]   c31       1
    x[1109]   c202      -3
    x[1110]   c328_1    1
    x[1110]   c1468     1
    x[1110]   c31       1
    x[1110]   c202      -3
    x[1111]   c329_1    1
    x[1111]   c1469     1
    x[1111]   c31       1
    x[1111]   c202      -3
    x[1112]   c330_1    1
    x[1112]   c1470     1
    x[1112]   c31       1
    x[1112]   c202      -3
    x[1113]   c331_1    1
    x[1113]   c1471     1
    x[1113]   c31       1
    x[1113]   c202      -3
    x[1114]   c332_1    1
    x[1114]   c1472     1
    x[1114]   c31       1
    x[1114]   c202      -3
    x[1115]   c333_1    1
    x[1115]   c1473     1
    x[1115]   c31       1
    x[1115]   c202      -3
    x[1116]   c334_1    1
    x[1116]   c1474     1
    x[1116]   c31       1
    x[1116]   c202      -3
    x[1117]   c335_1    1
    x[1117]   c1475     1
    x[1117]   c31       1
    x[1117]   c202      -3
    x[1118]   c331_1    1
    x[1118]   c1476     1
    x[1118]   c31       1
    x[1118]   c202      -2
    x[1119]   c332_1    1
    x[1119]   c1477     1
    x[1119]   c31       1
    x[1119]   c202      -2
    x[1120]   c333_1    1
    x[1120]   c1478     1
    x[1120]   c31       1
    x[1120]   c202      -2
    x[1121]   c334_1    1
    x[1121]   c1479     1
    x[1121]   c31       1
    x[1121]   c202      -2
    x[1122]   c335_1    1
    x[1122]   c1480     1
    x[1122]   c31       1
    x[1122]   c202      -2
    x[1123]   c331_1    1
    x[1123]   c1481     1
    x[1123]   c31       1
    x[1123]   c202      -1
    x[1124]   c332_1    1
    x[1124]   c1482     1
    x[1124]   c31       1
    x[1124]   c202      -1
    x[1125]   c333_1    1
    x[1125]   c1483     1
    x[1125]   c31       1
    x[1125]   c202      -1
    x[1126]   c334_1    1
    x[1126]   c1484     1
    x[1126]   c31       1
    x[1126]   c202      -1
    x[1127]   c335_1    1
    x[1127]   c1485     1
    x[1127]   c31       1
    x[1127]   c202      -1
    x[1128]   c336_1    1
    x[1128]   c1486     1
    x[1128]   c31       1
    x[1128]   c202      -3
    x[1129]   c337_1    1
    x[1129]   c1487     1
    x[1129]   c31       1
    x[1129]   c202      -3
    x[1130]   c338_1    1
    x[1130]   c1488     1
    x[1130]   c31       1
    x[1130]   c202      -3
    x[1131]   c339_1    1
    x[1131]   c1489     1
    x[1131]   c31       1
    x[1131]   c202      -3
    x[1132]   c340_1    1
    x[1132]   c1490     1
    x[1132]   c31       1
    x[1132]   c202      -3
    x[1133]   c336_1    1
    x[1133]   c1491     1
    x[1133]   c31       1
    x[1133]   c202      -2
    x[1134]   c337_1    1
    x[1134]   c1492     1
    x[1134]   c31       1
    x[1134]   c202      -2
    x[1135]   c338_1    1
    x[1135]   c1493     1
    x[1135]   c31       1
    x[1135]   c202      -2
    x[1136]   c339_1    1
    x[1136]   c1494     1
    x[1136]   c31       1
    x[1136]   c202      -2
    x[1137]   c340_1    1
    x[1137]   c1495     1
    x[1137]   c31       1
    x[1137]   c202      -2
    x[1138]   c336_1    1
    x[1138]   c1496     1
    x[1138]   c31       1
    x[1138]   c202      -1
    x[1139]   c337_1    1
    x[1139]   c1497     1
    x[1139]   c31       1
    x[1139]   c202      -1
    x[1140]   c338_1    1
    x[1140]   c1498     1
    x[1140]   c31       1
    x[1140]   c202      -1
    x[1141]   c339_1    1
    x[1141]   c1499     1
    x[1141]   c31       1
    x[1141]   c202      -1
    x[1142]   c340_1    1
    x[1142]   c1500     1
    x[1142]   c31       1
    x[1142]   c202      -1
    x[1143]   c341_1    1
    x[1143]   c1501     1
    x[1143]   c31       1
    x[1143]   c202      -3
    x[1144]   c342_1    1
    x[1144]   c1502     1
    x[1144]   c31       1
    x[1144]   c202      -3
    x[1145]   c343_1    1
    x[1145]   c1503     1
    x[1145]   c31       1
    x[1145]   c202      -3
    x[1146]   c344_1    1
    x[1146]   c1504     1
    x[1146]   c31       1
    x[1146]   c202      -3
    x[1147]   c345_1    1
    x[1147]   c1505     1
    x[1147]   c31       1
    x[1147]   c202      -3
    x[1148]   c341_1    1
    x[1148]   c1506     1
    x[1148]   c31       1
    x[1148]   c202      -1
    x[1149]   c342_1    1
    x[1149]   c1507     1
    x[1149]   c31       1
    x[1149]   c202      -1
    x[1150]   c343_1    1
    x[1150]   c1508     1
    x[1150]   c31       1
    x[1150]   c202      -1
    x[1151]   c344_1    1
    x[1151]   c1509     1
    x[1151]   c31       1
    x[1151]   c202      -1
    x[1152]   c345_1    1
    x[1152]   c1510     1
    x[1152]   c31       1
    x[1152]   c202      -1
    x[1153]   c341_1    1
    x[1153]   c1511     1
    x[1153]   c31       1
    x[1153]   c202      -2
    x[1154]   c342_1    1
    x[1154]   c1512     1
    x[1154]   c31       1
    x[1154]   c202      -2
    x[1155]   c343_1    1
    x[1155]   c1513     1
    x[1155]   c31       1
    x[1155]   c202      -2
    x[1156]   c344_1    1
    x[1156]   c1514     1
    x[1156]   c31       1
    x[1156]   c202      -2
    x[1157]   c345_1    1
    x[1157]   c1515     1
    x[1157]   c31       1
    x[1157]   c202      -2
    x[1158]   c341_1    1
    x[1158]   c152      1
    x[1158]   c528      -1
    x[1158]   c530      -1
    x[1159]   c342_1    1
    x[1159]   c153      1
    x[1159]   c532      -1
    x[1159]   c534      -1
    x[1160]   c343_1    1
    x[1160]   c154      1
    x[1160]   c536      -1
    x[1160]   c538      -1
    x[1161]   c344_1    1
    x[1161]   c155      1
    x[1161]   c540      -1
    x[1161]   c542      -1
    x[1162]   c345_1    1
    x[1162]   c156      1
    x[1162]   c544      -1
    x[1162]   c546      -1
    x[1163]   c341_1    1
    x[1163]   c157      1
    x[1163]   c588      -1
    x[1163]   c590      -1
    x[1164]   c342_1    1
    x[1164]   c158      1
    x[1164]   c592      -1
    x[1164]   c594      -1
    x[1165]   c343_1    1
    x[1165]   c159      1
    x[1165]   c596      -1
    x[1165]   c598      -1
    x[1166]   c344_1    1
    x[1166]   c160      1
    x[1166]   c600      -1
    x[1166]   c602      -1
    x[1167]   c345_1    1
    x[1167]   c161      1
    x[1167]   c604      -1
    x[1167]   c606      -1
    x[1168]   c346_1    1
    x[1168]   c1516     1
    x[1168]   c31       1
    x[1168]   c202      -3
    x[1169]   c347_1    1
    x[1169]   c1517     1
    x[1169]   c31       1
    x[1169]   c202      -3
    x[1170]   c348_1    1
    x[1170]   c1518     1
    x[1170]   c31       1
    x[1170]   c202      -3
    x[1171]   c349_1    1
    x[1171]   c1519     1
    x[1171]   c31       1
    x[1171]   c202      -3
    x[1172]   c350_1    1
    x[1172]   c1520     1
    x[1172]   c31       1
    x[1172]   c202      -3
    x[1173]   c346_1    1
    x[1173]   c1521     1
    x[1173]   c31       1
    x[1173]   c202      -2
    x[1174]   c347_1    1
    x[1174]   c1522     1
    x[1174]   c31       1
    x[1174]   c202      -2
    x[1175]   c348_1    1
    x[1175]   c1523     1
    x[1175]   c31       1
    x[1175]   c202      -2
    x[1176]   c349_1    1
    x[1176]   c1524     1
    x[1176]   c31       1
    x[1176]   c202      -2
    x[1177]   c350_1    1
    x[1177]   c1525     1
    x[1177]   c31       1
    x[1177]   c202      -2
    x[1178]   c346_1    1
    x[1178]   c1526     1
    x[1178]   c31       1
    x[1178]   c202      -1
    x[1179]   c347_1    1
    x[1179]   c1527     1
    x[1179]   c31       1
    x[1179]   c202      -1
    x[1180]   c348_1    1
    x[1180]   c1528     1
    x[1180]   c31       1
    x[1180]   c202      -1
    x[1181]   c349_1    1
    x[1181]   c1529     1
    x[1181]   c31       1
    x[1181]   c202      -1
    x[1182]   c350_1    1
    x[1182]   c1530     1
    x[1182]   c31       1
    x[1182]   c202      -1
    x[1183]   c351_1    1
    x[1183]   c1531     1
    x[1183]   c31       1
    x[1183]   c202      -3
    x[1184]   c352_1    1
    x[1184]   c1532     1
    x[1184]   c31       1
    x[1184]   c202      -3
    x[1185]   c353_1    1
    x[1185]   c1533     1
    x[1185]   c31       1
    x[1185]   c202      -3
    x[1186]   c354_1    1
    x[1186]   c1534     1
    x[1186]   c31       1
    x[1186]   c202      -3
    x[1187]   c355_1    1
    x[1187]   c1535     1
    x[1187]   c31       1
    x[1187]   c202      -3
    x[1188]   c351_1    1
    x[1188]   c1536     1
    x[1188]   c31       1
    x[1188]   c202      -1
    x[1189]   c352_1    1
    x[1189]   c1537     1
    x[1189]   c31       1
    x[1189]   c202      -1
    x[1190]   c353_1    1
    x[1190]   c1538     1
    x[1190]   c31       1
    x[1190]   c202      -1
    x[1191]   c354_1    1
    x[1191]   c1539     1
    x[1191]   c31       1
    x[1191]   c202      -1
    x[1192]   c355_1    1
    x[1192]   c1540     1
    x[1192]   c31       1
    x[1192]   c202      -1
    x[1193]   c351_1    1
    x[1193]   c1541     1
    x[1193]   c31       1
    x[1193]   c202      -2
    x[1194]   c352_1    1
    x[1194]   c1542     1
    x[1194]   c31       1
    x[1194]   c202      -2
    x[1195]   c353_1    1
    x[1195]   c1543     1
    x[1195]   c31       1
    x[1195]   c202      -2
    x[1196]   c354_1    1
    x[1196]   c1544     1
    x[1196]   c31       1
    x[1196]   c202      -2
    x[1197]   c355_1    1
    x[1197]   c1545     1
    x[1197]   c31       1
    x[1197]   c202      -2
    x[1198]   c356_1    1
    x[1198]   c1546     1
    x[1198]   c31       1
    x[1198]   c202      -2
    x[1199]   c357_1    1
    x[1199]   c1547     1
    x[1199]   c31       1
    x[1199]   c202      -2
    x[1200]   c358_1    1
    x[1200]   c1548     1
    x[1200]   c31       1
    x[1200]   c202      -2
    x[1201]   c359_1    1
    x[1201]   c1549     1
    x[1201]   c31       1
    x[1201]   c202      -2
    x[1202]   c360_1    1
    x[1202]   c1550     1
    x[1202]   c31       1
    x[1202]   c202      -2
    x[1203]   c356_1    1
    x[1203]   c1551     1
    x[1203]   c31       1
    x[1203]   c202      -3
    x[1204]   c357_1    1
    x[1204]   c1552     1
    x[1204]   c31       1
    x[1204]   c202      -3
    x[1205]   c358_1    1
    x[1205]   c1553     1
    x[1205]   c31       1
    x[1205]   c202      -3
    x[1206]   c359_1    1
    x[1206]   c1554     1
    x[1206]   c31       1
    x[1206]   c202      -3
    x[1207]   c360_1    1
    x[1207]   c1555     1
    x[1207]   c31       1
    x[1207]   c202      -3
    x[1208]   c356_1    1
    x[1208]   c1556     1
    x[1208]   c31       1
    x[1208]   c202      -1
    x[1209]   c357_1    1
    x[1209]   c1557     1
    x[1209]   c31       1
    x[1209]   c202      -1
    x[1210]   c358_1    1
    x[1210]   c1558     1
    x[1210]   c31       1
    x[1210]   c202      -1
    x[1211]   c359_1    1
    x[1211]   c1559     1
    x[1211]   c31       1
    x[1211]   c202      -1
    x[1212]   c360_1    1
    x[1212]   c1560     1
    x[1212]   c31       1
    x[1212]   c202      -1
    x[1213]   c361_1    1
    x[1213]   c1561     1
    x[1213]   c31       1
    x[1213]   c202      -1
    x[1214]   c362_1    1
    x[1214]   c1562     1
    x[1214]   c31       1
    x[1214]   c202      -1
    x[1215]   c363_1    1
    x[1215]   c1563     1
    x[1215]   c31       1
    x[1215]   c202      -1
    x[1216]   c364_1    1
    x[1216]   c1564     1
    x[1216]   c31       1
    x[1216]   c202      -1
    x[1217]   c365_1    1
    x[1217]   c1565     1
    x[1217]   c31       1
    x[1217]   c202      -1
    x[1218]   c361_1    1
    x[1218]   c1566     1
    x[1218]   c31       1
    x[1218]   c202      -2
    x[1219]   c362_1    1
    x[1219]   c1567     1
    x[1219]   c31       1
    x[1219]   c202      -2
    x[1220]   c363_1    1
    x[1220]   c1568     1
    x[1220]   c31       1
    x[1220]   c202      -2
    x[1221]   c364_1    1
    x[1221]   c1569     1
    x[1221]   c31       1
    x[1221]   c202      -2
    x[1222]   c365_1    1
    x[1222]   c1570     1
    x[1222]   c31       1
    x[1222]   c202      -2
    x[1223]   c361_1    1
    x[1223]   c1571     1
    x[1223]   c31       1
    x[1223]   c202      -3
    x[1224]   c362_1    1
    x[1224]   c1572     1
    x[1224]   c31       1
    x[1224]   c202      -3
    x[1225]   c363_1    1
    x[1225]   c1573     1
    x[1225]   c31       1
    x[1225]   c202      -3
    x[1226]   c364_1    1
    x[1226]   c1574     1
    x[1226]   c31       1
    x[1226]   c202      -3
    x[1227]   c365_1    1
    x[1227]   c1575     1
    x[1227]   c31       1
    x[1227]   c202      -3
    x[1228]   c361_1    1
    x[1228]   c162      1
    x[1228]   c558      -1
    x[1228]   c560      -1
    x[1229]   c362_1    1
    x[1229]   c163      1
    x[1229]   c562      -1
    x[1229]   c564      -1
    x[1230]   c363_1    1
    x[1230]   c164      1
    x[1230]   c566      -1
    x[1230]   c568      -1
    x[1231]   c364_1    1
    x[1231]   c165      1
    x[1231]   c570      -1
    x[1231]   c572      -1
    x[1232]   c365_1    1
    x[1232]   c166      1
    x[1232]   c574      -1
    x[1232]   c576      -1
    x[1233]   c366_1    1
    x[1233]   c1576     1
    x[1233]   c31       1
    x[1233]   c202      -3
    x[1234]   c367_1    1
    x[1234]   c1577     1
    x[1234]   c31       1
    x[1234]   c202      -3
    x[1235]   c368_1    1
    x[1235]   c1578     1
    x[1235]   c31       1
    x[1235]   c202      -3
    x[1236]   c369_1    1
    x[1236]   c1579     1
    x[1236]   c31       1
    x[1236]   c202      -3
    x[1237]   c370_1    1
    x[1237]   c1580     1
    x[1237]   c31       1
    x[1237]   c202      -3
    x[1238]   c366_1    1
    x[1238]   c1581     1
    x[1238]   c31       1
    x[1238]   c202      -1
    x[1239]   c367_1    1
    x[1239]   c1582     1
    x[1239]   c31       1
    x[1239]   c202      -1
    x[1240]   c368_1    1
    x[1240]   c1583     1
    x[1240]   c31       1
    x[1240]   c202      -1
    x[1241]   c369_1    1
    x[1241]   c1584     1
    x[1241]   c31       1
    x[1241]   c202      -1
    x[1242]   c370_1    1
    x[1242]   c1585     1
    x[1242]   c31       1
    x[1242]   c202      -1
    x[1243]   c366_1    1
    x[1243]   c1586     1
    x[1243]   c31       1
    x[1243]   c202      -2
    x[1244]   c367_1    1
    x[1244]   c1587     1
    x[1244]   c31       1
    x[1244]   c202      -2
    x[1245]   c368_1    1
    x[1245]   c1588     1
    x[1245]   c31       1
    x[1245]   c202      -2
    x[1246]   c369_1    1
    x[1246]   c1589     1
    x[1246]   c31       1
    x[1246]   c202      -2
    x[1247]   c370_1    1
    x[1247]   c1590     1
    x[1247]   c31       1
    x[1247]   c202      -2
    x[1248]   c371_1    1
    x[1248]   c1591     1
    x[1248]   c31       1
    x[1248]   c202      -1
    x[1249]   c372_1    1
    x[1249]   c1592     1
    x[1249]   c31       1
    x[1249]   c202      -1
    x[1250]   c373_1    1
    x[1250]   c1593     1
    x[1250]   c31       1
    x[1250]   c202      -1
    x[1251]   c374_1    1
    x[1251]   c1594     1
    x[1251]   c31       1
    x[1251]   c202      -1
    x[1252]   c375_1    1
    x[1252]   c1595     1
    x[1252]   c31       1
    x[1252]   c202      -1
    x[1253]   c371_1    1
    x[1253]   c1596     1
    x[1253]   c31       1
    x[1253]   c202      -3
    x[1254]   c372_1    1
    x[1254]   c1597     1
    x[1254]   c31       1
    x[1254]   c202      -3
    x[1255]   c373_1    1
    x[1255]   c1598     1
    x[1255]   c31       1
    x[1255]   c202      -3
    x[1256]   c374_1    1
    x[1256]   c1599     1
    x[1256]   c31       1
    x[1256]   c202      -3
    x[1257]   c375_1    1
    x[1257]   c1600     1
    x[1257]   c31       1
    x[1257]   c202      -3
    x[1258]   c371_1    1
    x[1258]   c167      1
    x[1258]   c249      -1
    x[1258]   c251      -1
    x[1258]   c254      -1
    x[1259]   c372_1    1
    x[1259]   c168      1
    x[1259]   c257      -1
    x[1259]   c260      -1
    x[1260]   c373_1    1
    x[1260]   c169      1
    x[1260]   c263      -1
    x[1260]   c268      -1
    x[1261]   c374_1    1
    x[1261]   c170      1
    x[1261]   c271      -1
    x[1261]   c274      -1
    x[1262]   c375_1    1
    x[1262]   c171      1
    x[1262]   c277      -1
    x[1262]   c280      -1
    x[1263]   c371_1    1
    x[1263]   c1601     1
    x[1263]   c31       1
    x[1263]   c202      -2
    x[1264]   c372_1    1
    x[1264]   c1602     1
    x[1264]   c31       1
    x[1264]   c202      -2
    x[1265]   c373_1    1
    x[1265]   c1603     1
    x[1265]   c31       1
    x[1265]   c202      -2
    x[1266]   c374_1    1
    x[1266]   c1604     1
    x[1266]   c31       1
    x[1266]   c202      -2
    x[1267]   c375_1    1
    x[1267]   c1605     1
    x[1267]   c31       1
    x[1267]   c202      -2
    x[1268]   c376_1    1
    x[1268]   c1606     1
    x[1268]   c31       1
    x[1268]   c202      -3
    x[1269]   c377_1    1
    x[1269]   c1607     1
    x[1269]   c31       1
    x[1269]   c202      -3
    x[1270]   c378_1    1
    x[1270]   c1608     1
    x[1270]   c31       1
    x[1270]   c202      -3
    x[1271]   c379_1    1
    x[1271]   c1609     1
    x[1271]   c31       1
    x[1271]   c202      -3
    x[1272]   c380_1    1
    x[1272]   c1610     1
    x[1272]   c31       1
    x[1272]   c202      -3
    x[1273]   c376_1    1
    x[1273]   c1611     1
    x[1273]   c31       1
    x[1273]   c202      -2
    x[1274]   c377_1    1
    x[1274]   c1612     1
    x[1274]   c31       1
    x[1274]   c202      -2
    x[1275]   c378_1    1
    x[1275]   c1613     1
    x[1275]   c31       1
    x[1275]   c202      -2
    x[1276]   c379_1    1
    x[1276]   c1614     1
    x[1276]   c31       1
    x[1276]   c202      -2
    x[1277]   c380_1    1
    x[1277]   c1615     1
    x[1277]   c31       1
    x[1277]   c202      -2
    x[1278]   c376_1    1
    x[1278]   c1616     1
    x[1278]   c31       1
    x[1278]   c202      -1
    x[1279]   c377_1    1
    x[1279]   c1617     1
    x[1279]   c31       1
    x[1279]   c202      -1
    x[1280]   c378_1    1
    x[1280]   c1618     1
    x[1280]   c31       1
    x[1280]   c202      -1
    x[1281]   c379_1    1
    x[1281]   c1619     1
    x[1281]   c31       1
    x[1281]   c202      -1
    x[1282]   c380_1    1
    x[1282]   c1620     1
    x[1282]   c31       1
    x[1282]   c202      -1
    x[1283]   c381_1    1
    x[1283]   c1621     1
    x[1283]   c31       1
    x[1283]   c202      -1
    x[1284]   c382_1    1
    x[1284]   c1622     1
    x[1284]   c31       1
    x[1284]   c202      -1
    x[1285]   c383_1    1
    x[1285]   c1623     1
    x[1285]   c31       1
    x[1285]   c202      -1
    x[1286]   c384_1    1
    x[1286]   c1624     1
    x[1286]   c31       1
    x[1286]   c202      -1
    x[1287]   c385_1    1
    x[1287]   c1625     1
    x[1287]   c31       1
    x[1287]   c202      -1
    x[1288]   c381_1    1
    x[1288]   c1626     1
    x[1288]   c31       1
    x[1288]   c202      -3
    x[1289]   c382_1    1
    x[1289]   c1627     1
    x[1289]   c31       1
    x[1289]   c202      -3
    x[1290]   c383_1    1
    x[1290]   c1628     1
    x[1290]   c31       1
    x[1290]   c202      -3
    x[1291]   c384_1    1
    x[1291]   c1629     1
    x[1291]   c31       1
    x[1291]   c202      -3
    x[1292]   c385_1    1
    x[1292]   c1630     1
    x[1292]   c31       1
    x[1292]   c202      -3
    x[1293]   c381_1    1
    x[1293]   c1631     1
    x[1293]   c31       1
    x[1293]   c202      -2
    x[1294]   c382_1    1
    x[1294]   c1632     1
    x[1294]   c31       1
    x[1294]   c202      -2
    x[1295]   c383_1    1
    x[1295]   c1633     1
    x[1295]   c31       1
    x[1295]   c202      -2
    x[1296]   c384_1    1
    x[1296]   c1634     1
    x[1296]   c31       1
    x[1296]   c202      -2
    x[1297]   c385_1    1
    x[1297]   c1635     1
    x[1297]   c31       1
    x[1297]   c202      -2
    x[1298]   c386_1    1
    x[1298]   c1636     1
    x[1298]   c31       1
    x[1298]   c202      -3
    x[1299]   c387_1    1
    x[1299]   c1637     1
    x[1299]   c31       1
    x[1299]   c202      -3
    x[1300]   c388_1    1
    x[1300]   c1638     1
    x[1300]   c31       1
    x[1300]   c202      -3
    x[1301]   c389_1    1
    x[1301]   c1639     1
    x[1301]   c31       1
    x[1301]   c202      -3
    x[1302]   c390_1    1
    x[1302]   c1640     1
    x[1302]   c31       1
    x[1302]   c202      -3
    x[1303]   c386_1    1
    x[1303]   c1641     1
    x[1303]   c31       1
    x[1303]   c202      -2
    x[1304]   c387_1    1
    x[1304]   c1642     1
    x[1304]   c31       1
    x[1304]   c202      -2
    x[1305]   c388_1    1
    x[1305]   c1643     1
    x[1305]   c31       1
    x[1305]   c202      -2
    x[1306]   c389_1    1
    x[1306]   c1644     1
    x[1306]   c31       1
    x[1306]   c202      -2
    x[1307]   c390_1    1
    x[1307]   c1645     1
    x[1307]   c31       1
    x[1307]   c202      -2
    x[1308]   c386_1    1
    x[1308]   c1646     1
    x[1308]   c31       1
    x[1308]   c202      -1
    x[1309]   c387_1    1
    x[1309]   c1647     1
    x[1309]   c31       1
    x[1309]   c202      -1
    x[1310]   c388_1    1
    x[1310]   c1648     1
    x[1310]   c31       1
    x[1310]   c202      -1
    x[1311]   c389_1    1
    x[1311]   c1649     1
    x[1311]   c31       1
    x[1311]   c202      -1
    x[1312]   c390_1    1
    x[1312]   c1650     1
    x[1312]   c31       1
    x[1312]   c202      -1
    x[1313]   c391_1    1
    x[1313]   c1651     1
    x[1313]   c31       1
    x[1313]   c202      -3
    x[1314]   c392_1    1
    x[1314]   c1652     1
    x[1314]   c31       1
    x[1314]   c202      -3
    x[1315]   c393_1    1
    x[1315]   c1653     1
    x[1315]   c31       1
    x[1315]   c202      -3
    x[1316]   c394_1    1
    x[1316]   c1654     1
    x[1316]   c31       1
    x[1316]   c202      -3
    x[1317]   c395_1    1
    x[1317]   c1655     1
    x[1317]   c31       1
    x[1317]   c202      -3
    x[1318]   c391_1    1
    x[1318]   c1656     1
    x[1318]   c31       1
    x[1318]   c202      -1
    x[1319]   c392_1    1
    x[1319]   c1657     1
    x[1319]   c31       1
    x[1319]   c202      -1
    x[1320]   c393_1    1
    x[1320]   c1658     1
    x[1320]   c31       1
    x[1320]   c202      -1
    x[1321]   c394_1    1
    x[1321]   c1659     1
    x[1321]   c31       1
    x[1321]   c202      -1
    x[1322]   c395_1    1
    x[1322]   c1660     1
    x[1322]   c31       1
    x[1322]   c202      -1
    x[1323]   c391_1    1
    x[1323]   c1661     1
    x[1323]   c31       1
    x[1323]   c202      -2
    x[1324]   c392_1    1
    x[1324]   c1662     1
    x[1324]   c31       1
    x[1324]   c202      -2
    x[1325]   c393_1    1
    x[1325]   c1663     1
    x[1325]   c31       1
    x[1325]   c202      -2
    x[1326]   c394_1    1
    x[1326]   c1664     1
    x[1326]   c31       1
    x[1326]   c202      -2
    x[1327]   c395_1    1
    x[1327]   c1665     1
    x[1327]   c31       1
    x[1327]   c202      -2
    x[1328]   c396_1    1
    x[1328]   c172      1
    x[1328]   c207      -1
    x[1328]   c211      -1
    x[1329]   c397_1    1
    x[1329]   c173      1
    x[1329]   c215      -1
    x[1329]   c219      -1
    x[1330]   c398_1    1
    x[1330]   c174      1
    x[1330]   c223      -1
    x[1330]   c229      -1
    x[1331]   c399_1    1
    x[1331]   c175      1
    x[1331]   c233      -1
    x[1331]   c237      -1
    x[1332]   c400_1    1
    x[1332]   c176      1
    x[1332]   c241      -1
    x[1332]   c245      -1
    x[1333]   c396_1    1
    x[1333]   c1666     1
    x[1333]   c31       1
    x[1333]   c202      -1
    x[1334]   c397_1    1
    x[1334]   c1667     1
    x[1334]   c31       1
    x[1334]   c202      -1
    x[1335]   c398_1    1
    x[1335]   c1668     1
    x[1335]   c31       1
    x[1335]   c202      -1
    x[1336]   c399_1    1
    x[1336]   c1669     1
    x[1336]   c31       1
    x[1336]   c202      -1
    x[1337]   c400_1    1
    x[1337]   c1670     1
    x[1337]   c31       1
    x[1337]   c202      -1
    x[1338]   c396_1    1
    x[1338]   c1671     1
    x[1338]   c31       1
    x[1338]   c202      -2
    x[1339]   c397_1    1
    x[1339]   c1672     1
    x[1339]   c31       1
    x[1339]   c202      -2
    x[1340]   c398_1    1
    x[1340]   c1673     1
    x[1340]   c31       1
    x[1340]   c202      -2
    x[1341]   c399_1    1
    x[1341]   c1674     1
    x[1341]   c31       1
    x[1341]   c202      -2
    x[1342]   c400_1    1
    x[1342]   c1675     1
    x[1342]   c31       1
    x[1342]   c202      -2
    x[1343]   c396_1    1
    x[1343]   c1676     1
    x[1343]   c31       1
    x[1343]   c202      -3
    x[1344]   c397_1    1
    x[1344]   c1677     1
    x[1344]   c31       1
    x[1344]   c202      -3
    x[1345]   c398_1    1
    x[1345]   c1678     1
    x[1345]   c31       1
    x[1345]   c202      -3
    x[1346]   c399_1    1
    x[1346]   c1679     1
    x[1346]   c31       1
    x[1346]   c202      -3
    x[1347]   c400_1    1
    x[1347]   c1680     1
    x[1347]   c31       1
    x[1347]   c202      -3
    x[1348]   c401_1    1
    x[1348]   c1681     1
    x[1348]   c31       1
    x[1348]   c202      -1
    x[1349]   c402_1    1
    x[1349]   c1682     1
    x[1349]   c31       1
    x[1349]   c202      -1
    x[1350]   c403_1    1
    x[1350]   c1683     1
    x[1350]   c31       1
    x[1350]   c202      -1
    x[1351]   c404_1    1
    x[1351]   c1684     1
    x[1351]   c31       1
    x[1351]   c202      -1
    x[1352]   c405_1    1
    x[1352]   c1685     1
    x[1352]   c31       1
    x[1352]   c202      -1
    x[1353]   c401_1    1
    x[1353]   c1686     1
    x[1353]   c31       1
    x[1353]   c202      -2
    x[1354]   c402_1    1
    x[1354]   c1687     1
    x[1354]   c31       1
    x[1354]   c202      -2
    x[1355]   c403_1    1
    x[1355]   c1688     1
    x[1355]   c31       1
    x[1355]   c202      -2
    x[1356]   c404_1    1
    x[1356]   c1689     1
    x[1356]   c31       1
    x[1356]   c202      -2
    x[1357]   c405_1    1
    x[1357]   c1690     1
    x[1357]   c31       1
    x[1357]   c202      -2
    x[1358]   c401_1    1
    x[1358]   c1691     1
    x[1358]   c31       1
    x[1358]   c202      -3
    x[1359]   c402_1    1
    x[1359]   c1692     1
    x[1359]   c31       1
    x[1359]   c202      -3
    x[1360]   c403_1    1
    x[1360]   c1693     1
    x[1360]   c31       1
    x[1360]   c202      -3
    x[1361]   c404_1    1
    x[1361]   c1694     1
    x[1361]   c31       1
    x[1361]   c202      -3
    x[1362]   c405_1    1
    x[1362]   c1695     1
    x[1362]   c31       1
    x[1362]   c202      -3
    x[1363]   c406_1    1
    x[1363]   c177      1
    x[1363]   c285      -1
    x[1363]   c289      -1
    x[1364]   c407_1    1
    x[1364]   c178      1
    x[1364]   c293      -1
    x[1364]   c297      -1
    x[1365]   c408_1    1
    x[1365]   c179      1
    x[1365]   c301      -1
    x[1365]   c307      -1
    x[1366]   c409_1    1
    x[1366]   c180      1
    x[1366]   c311      -1
    x[1366]   c315      -1
    x[1367]   c410_1    1
    x[1367]   c181      1
    x[1367]   c319      -1
    x[1367]   c323      -1
    x[1368]   c406_1    1
    x[1368]   c1696     1
    x[1368]   c31       1
    x[1368]   c202      -2
    x[1369]   c407_1    1
    x[1369]   c1697     1
    x[1369]   c31       1
    x[1369]   c202      -2
    x[1370]   c408_1    1
    x[1370]   c1698     1
    x[1370]   c31       1
    x[1370]   c202      -2
    x[1371]   c409_1    1
    x[1371]   c1699     1
    x[1371]   c31       1
    x[1371]   c202      -2
    x[1372]   c410_1    1
    x[1372]   c1700     1
    x[1372]   c31       1
    x[1372]   c202      -2
    x[1373]   c406_1    1
    x[1373]   c1701     1
    x[1373]   c31       1
    x[1373]   c202      -3
    x[1374]   c407_1    1
    x[1374]   c1702     1
    x[1374]   c31       1
    x[1374]   c202      -3
    x[1375]   c408_1    1
    x[1375]   c1703     1
    x[1375]   c31       1
    x[1375]   c202      -3
    x[1376]   c409_1    1
    x[1376]   c1704     1
    x[1376]   c31       1
    x[1376]   c202      -3
    x[1377]   c410_1    1
    x[1377]   c1705     1
    x[1377]   c31       1
    x[1377]   c202      -3
    x[1378]   c406_1    1
    x[1378]   c1706     1
    x[1378]   c31       1
    x[1378]   c202      -1
    x[1379]   c407_1    1
    x[1379]   c1707     1
    x[1379]   c31       1
    x[1379]   c202      -1
    x[1380]   c408_1    1
    x[1380]   c1708     1
    x[1380]   c31       1
    x[1380]   c202      -1
    x[1381]   c409_1    1
    x[1381]   c1709     1
    x[1381]   c31       1
    x[1381]   c202      -1
    x[1382]   c410_1    1
    x[1382]   c1710     1
    x[1382]   c31       1
    x[1382]   c202      -1
    x[1383]   c411_1    1
    x[1383]   c1711     1
    x[1383]   c31       1
    x[1383]   c202      -3
    x[1384]   c412_1    1
    x[1384]   c1712     1
    x[1384]   c31       1
    x[1384]   c202      -3
    x[1385]   c413_1    1
    x[1385]   c1713     1
    x[1385]   c31       1
    x[1385]   c202      -3
    x[1386]   c414_1    1
    x[1386]   c1714     1
    x[1386]   c31       1
    x[1386]   c202      -3
    x[1387]   c415_1    1
    x[1387]   c1715     1
    x[1387]   c31       1
    x[1387]   c202      -3
    x[1388]   c411_1    1
    x[1388]   c1716     1
    x[1388]   c31       1
    x[1388]   c202      -2
    x[1389]   c412_1    1
    x[1389]   c1717     1
    x[1389]   c31       1
    x[1389]   c202      -2
    x[1390]   c413_1    1
    x[1390]   c1718     1
    x[1390]   c31       1
    x[1390]   c202      -2
    x[1391]   c414_1    1
    x[1391]   c1719     1
    x[1391]   c31       1
    x[1391]   c202      -2
    x[1392]   c415_1    1
    x[1392]   c1720     1
    x[1392]   c31       1
    x[1392]   c202      -2
    x[1393]   c411_1    1
    x[1393]   c1721     1
    x[1393]   c31       1
    x[1393]   c202      -1
    x[1394]   c412_1    1
    x[1394]   c1722     1
    x[1394]   c31       1
    x[1394]   c202      -1
    x[1395]   c413_1    1
    x[1395]   c1723     1
    x[1395]   c31       1
    x[1395]   c202      -1
    x[1396]   c414_1    1
    x[1396]   c1724     1
    x[1396]   c31       1
    x[1396]   c202      -1
    x[1397]   c415_1    1
    x[1397]   c1725     1
    x[1397]   c31       1
    x[1397]   c202      -1
    x[1398]   c416_1    1
    x[1398]   c1726     1
    x[1398]   c31       1
    x[1398]   c202      -1
    x[1399]   c417_1    1
    x[1399]   c1727     1
    x[1399]   c31       1
    x[1399]   c202      -1
    x[1400]   c418_1    1
    x[1400]   c1728     1
    x[1400]   c31       1
    x[1400]   c202      -1
    x[1401]   c419_1    1
    x[1401]   c1729     1
    x[1401]   c31       1
    x[1401]   c202      -1
    x[1402]   c420_1    1
    x[1402]   c1730     1
    x[1402]   c31       1
    x[1402]   c202      -1
    x[1403]   c416_1    1
    x[1403]   c1731     1
    x[1403]   c31       1
    x[1403]   c202      -2
    x[1404]   c417_1    1
    x[1404]   c1732     1
    x[1404]   c31       1
    x[1404]   c202      -2
    x[1405]   c418_1    1
    x[1405]   c1733     1
    x[1405]   c31       1
    x[1405]   c202      -2
    x[1406]   c419_1    1
    x[1406]   c1734     1
    x[1406]   c31       1
    x[1406]   c202      -2
    x[1407]   c420_1    1
    x[1407]   c1735     1
    x[1407]   c31       1
    x[1407]   c202      -2
    x[1408]   c416_1    1
    x[1408]   c1736     1
    x[1408]   c31       1
    x[1408]   c202      -3
    x[1409]   c417_1    1
    x[1409]   c1737     1
    x[1409]   c31       1
    x[1409]   c202      -3
    x[1410]   c418_1    1
    x[1410]   c1738     1
    x[1410]   c31       1
    x[1410]   c202      -3
    x[1411]   c419_1    1
    x[1411]   c1739     1
    x[1411]   c31       1
    x[1411]   c202      -3
    x[1412]   c420_1    1
    x[1412]   c1740     1
    x[1412]   c31       1
    x[1412]   c202      -3
    x[1413]   c421_1    1
    x[1413]   c1741     1
    x[1413]   c31       1
    x[1413]   c202      -3
    x[1414]   c422_1    1
    x[1414]   c1742     1
    x[1414]   c31       1
    x[1414]   c202      -3
    x[1415]   c423_1    1
    x[1415]   c1743     1
    x[1415]   c31       1
    x[1415]   c202      -3
    x[1416]   c424_1    1
    x[1416]   c1744     1
    x[1416]   c31       1
    x[1416]   c202      -3
    x[1417]   c425_1    1
    x[1417]   c1745     1
    x[1417]   c31       1
    x[1417]   c202      -3
    x[1418]   c421_1    1
    x[1418]   c1746     1
    x[1418]   c31       1
    x[1418]   c202      -1
    x[1419]   c422_1    1
    x[1419]   c1747     1
    x[1419]   c31       1
    x[1419]   c202      -1
    x[1420]   c423_1    1
    x[1420]   c1748     1
    x[1420]   c31       1
    x[1420]   c202      -1
    x[1421]   c424_1    1
    x[1421]   c1749     1
    x[1421]   c31       1
    x[1421]   c202      -1
    x[1422]   c425_1    1
    x[1422]   c1750     1
    x[1422]   c31       1
    x[1422]   c202      -1
    x[1423]   c421_1    1
    x[1423]   c1751     1
    x[1423]   c31       1
    x[1423]   c202      -2
    x[1424]   c422_1    1
    x[1424]   c1752     1
    x[1424]   c31       1
    x[1424]   c202      -2
    x[1425]   c423_1    1
    x[1425]   c1753     1
    x[1425]   c31       1
    x[1425]   c202      -2
    x[1426]   c424_1    1
    x[1426]   c1754     1
    x[1426]   c31       1
    x[1426]   c202      -2
    x[1427]   c425_1    1
    x[1427]   c1755     1
    x[1427]   c31       1
    x[1427]   c202      -2
    x[1428]   c426_1    1
    x[1428]   c1756     1
    x[1428]   c31       1
    x[1428]   c202      -1
    x[1429]   c427_1    1
    x[1429]   c1757     1
    x[1429]   c31       1
    x[1429]   c202      -1
    x[1430]   c428_1    1
    x[1430]   c1758     1
    x[1430]   c31       1
    x[1430]   c202      -1
    x[1431]   c429_1    1
    x[1431]   c1759     1
    x[1431]   c31       1
    x[1431]   c202      -1
    x[1432]   c430_1    1
    x[1432]   c1760     1
    x[1432]   c31       1
    x[1432]   c202      -1
    x[1433]   c426_1    1
    x[1433]   c1761     1
    x[1433]   c31       1
    x[1433]   c202      -2
    x[1434]   c427_1    1
    x[1434]   c1762     1
    x[1434]   c31       1
    x[1434]   c202      -2
    x[1435]   c428_1    1
    x[1435]   c1763     1
    x[1435]   c31       1
    x[1435]   c202      -2
    x[1436]   c429_1    1
    x[1436]   c1764     1
    x[1436]   c31       1
    x[1436]   c202      -2
    x[1437]   c430_1    1
    x[1437]   c1765     1
    x[1437]   c31       1
    x[1437]   c202      -2
    x[1438]   c426_1    1
    x[1438]   c182      1
    x[1438]   c773      -1
    x[1438]   c779      -1
    x[1439]   c427_1    1
    x[1439]   c183      1
    x[1439]   c782      -1
    x[1439]   c790      -1
    x[1440]   c428_1    1
    x[1440]   c184      1
    x[1440]   c793      -1
    x[1440]   c796      -1
    x[1441]   c429_1    1
    x[1441]   c185      1
    x[1441]   c799      -1
    x[1441]   c802      -1
    x[1442]   c430_1    1
    x[1442]   c186      1
    x[1442]   c805      -1
    x[1442]   c808      -1
    x[1443]   c426_1    1
    x[1443]   c1766     1
    x[1443]   c31       1
    x[1443]   c202      -3
    x[1444]   c427_1    1
    x[1444]   c1767     1
    x[1444]   c31       1
    x[1444]   c202      -3
    x[1445]   c428_1    1
    x[1445]   c1768     1
    x[1445]   c31       1
    x[1445]   c202      -3
    x[1446]   c429_1    1
    x[1446]   c1769     1
    x[1446]   c31       1
    x[1446]   c202      -3
    x[1447]   c430_1    1
    x[1447]   c1770     1
    x[1447]   c31       1
    x[1447]   c202      -3
    x[1448]   c431_1    1
    x[1448]   c1771     1
    x[1448]   c31       1
    x[1448]   c202      -1
    x[1449]   c432_1    1
    x[1449]   c1772     1
    x[1449]   c31       1
    x[1449]   c202      -1
    x[1450]   c433_1    1
    x[1450]   c1773     1
    x[1450]   c31       1
    x[1450]   c202      -1
    x[1451]   c434_1    1
    x[1451]   c1774     1
    x[1451]   c31       1
    x[1451]   c202      -1
    x[1452]   c435_1    1
    x[1452]   c1775     1
    x[1452]   c31       1
    x[1452]   c202      -1
    x[1453]   c431_1    1
    x[1453]   c1776     1
    x[1453]   c31       1
    x[1453]   c202      -2
    x[1454]   c432_1    1
    x[1454]   c1777     1
    x[1454]   c31       1
    x[1454]   c202      -2
    x[1455]   c433_1    1
    x[1455]   c1778     1
    x[1455]   c31       1
    x[1455]   c202      -2
    x[1456]   c434_1    1
    x[1456]   c1779     1
    x[1456]   c31       1
    x[1456]   c202      -2
    x[1457]   c435_1    1
    x[1457]   c1780     1
    x[1457]   c31       1
    x[1457]   c202      -2
    x[1458]   c431_1    1
    x[1458]   c1781     1
    x[1458]   c31       1
    x[1458]   c202      -3
    x[1459]   c432_1    1
    x[1459]   c1782     1
    x[1459]   c31       1
    x[1459]   c202      -3
    x[1460]   c433_1    1
    x[1460]   c1783     1
    x[1460]   c31       1
    x[1460]   c202      -3
    x[1461]   c434_1    1
    x[1461]   c1784     1
    x[1461]   c31       1
    x[1461]   c202      -3
    x[1462]   c435_1    1
    x[1462]   c1785     1
    x[1462]   c31       1
    x[1462]   c202      -3
    x[1463]   c436_1    1
    x[1463]   c1786     1
    x[1463]   c31       1
    x[1463]   c202      -1
    x[1464]   c437_1    1
    x[1464]   c1787     1
    x[1464]   c31       1
    x[1464]   c202      -1
    x[1465]   c438_1    1
    x[1465]   c1788     1
    x[1465]   c31       1
    x[1465]   c202      -1
    x[1466]   c439_1    1
    x[1466]   c1789     1
    x[1466]   c31       1
    x[1466]   c202      -1
    x[1467]   c440_1    1
    x[1467]   c1790     1
    x[1467]   c31       1
    x[1467]   c202      -1
    x[1468]   c436_1    1
    x[1468]   c1791     1
    x[1468]   c31       1
    x[1468]   c202      -2
    x[1469]   c437_1    1
    x[1469]   c1792     1
    x[1469]   c31       1
    x[1469]   c202      -2
    x[1470]   c438_1    1
    x[1470]   c1793     1
    x[1470]   c31       1
    x[1470]   c202      -2
    x[1471]   c439_1    1
    x[1471]   c1794     1
    x[1471]   c31       1
    x[1471]   c202      -2
    x[1472]   c440_1    1
    x[1472]   c1795     1
    x[1472]   c31       1
    x[1472]   c202      -2
    x[1473]   c436_1    1
    x[1473]   c1796     1
    x[1473]   c31       1
    x[1473]   c202      -3
    x[1474]   c437_1    1
    x[1474]   c1797     1
    x[1474]   c31       1
    x[1474]   c202      -3
    x[1475]   c438_1    1
    x[1475]   c1798     1
    x[1475]   c31       1
    x[1475]   c202      -3
    x[1476]   c439_1    1
    x[1476]   c1799     1
    x[1476]   c31       1
    x[1476]   c202      -3
    x[1477]   c440_1    1
    x[1477]   c1800     1
    x[1477]   c31       1
    x[1477]   c202      -3
    x[1478]   c436_1    1
    x[1478]   c187      1
    x[1478]   c367      -1
    x[1478]   c371      -1
    x[1479]   c437_1    1
    x[1479]   c188      1
    x[1479]   c375      -1
    x[1479]   c379      -1
    x[1480]   c438_1    1
    x[1480]   c189      1
    x[1480]   c383      -1
    x[1480]   c387      -1
    x[1481]   c439_1    1
    x[1481]   c190      1
    x[1481]   c391      -1
    x[1481]   c395      -1
    x[1482]   c440_1    1
    x[1482]   c191      1
    x[1482]   c399      -1
    x[1482]   c403      -1
    x[1483]   c441_1    1
    x[1483]   c1801     1
    x[1483]   c31       1
    x[1483]   c202      -1
    x[1484]   c442_1    1
    x[1484]   c1802     1
    x[1484]   c31       1
    x[1484]   c202      -1
    x[1485]   c443_1    1
    x[1485]   c1803     1
    x[1485]   c31       1
    x[1485]   c202      -1
    x[1486]   c444_1    1
    x[1486]   c1804     1
    x[1486]   c31       1
    x[1486]   c202      -1
    x[1487]   c445_1    1
    x[1487]   c1805     1
    x[1487]   c31       1
    x[1487]   c202      -1
    x[1488]   c441_1    1
    x[1488]   c1806     1
    x[1488]   c31       1
    x[1488]   c202      -2
    x[1489]   c442_1    1
    x[1489]   c1807     1
    x[1489]   c31       1
    x[1489]   c202      -2
    x[1490]   c443_1    1
    x[1490]   c1808     1
    x[1490]   c31       1
    x[1490]   c202      -2
    x[1491]   c444_1    1
    x[1491]   c1809     1
    x[1491]   c31       1
    x[1491]   c202      -2
    x[1492]   c445_1    1
    x[1492]   c1810     1
    x[1492]   c31       1
    x[1492]   c202      -2
    x[1493]   c441_1    1
    x[1493]   c1811     1
    x[1493]   c31       1
    x[1493]   c202      -3
    x[1494]   c442_1    1
    x[1494]   c1812     1
    x[1494]   c31       1
    x[1494]   c202      -3
    x[1495]   c443_1    1
    x[1495]   c1813     1
    x[1495]   c31       1
    x[1495]   c202      -3
    x[1496]   c444_1    1
    x[1496]   c1814     1
    x[1496]   c31       1
    x[1496]   c202      -3
    x[1497]   c445_1    1
    x[1497]   c1815     1
    x[1497]   c31       1
    x[1497]   c202      -3
    x[1498]   c441_1    1
    x[1498]   c192      1
    x[1498]   c631      -1
    x[1498]   c633      -1
    x[1498]   c637      -1
    x[1499]   c442_1    1
    x[1499]   c193      1
    x[1499]   c641      -1
    x[1499]   c645      -1
    x[1500]   c443_1    1
    x[1500]   c194      1
    x[1500]   c649      -1
    x[1500]   c653      -1
    x[1501]   c444_1    1
    x[1501]   c195      1
    x[1501]   c657      -1
    x[1501]   c661      -1
    x[1502]   c445_1    1
    x[1502]   c196      1
    x[1502]   c665      -1
    x[1502]   c669      -1
    x[1503]   c446_1    1
    x[1503]   c1816     1
    x[1503]   c31       1
    x[1503]   c202      -3
    x[1504]   c447_1    1
    x[1504]   c1817     1
    x[1504]   c31       1
    x[1504]   c202      -3
    x[1505]   c448_1    1
    x[1505]   c1818     1
    x[1505]   c31       1
    x[1505]   c202      -3
    x[1506]   c449_1    1
    x[1506]   c1819     1
    x[1506]   c31       1
    x[1506]   c202      -3
    x[1507]   c450_1    1
    x[1507]   c1820     1
    x[1507]   c31       1
    x[1507]   c202      -3
    x[1508]   c446_1    1
    x[1508]   c1821     1
    x[1508]   c31       1
    x[1508]   c202      -1
    x[1509]   c447_1    1
    x[1509]   c1822     1
    x[1509]   c31       1
    x[1509]   c202      -1
    x[1510]   c448_1    1
    x[1510]   c1823     1
    x[1510]   c31       1
    x[1510]   c202      -1
    x[1511]   c449_1    1
    x[1511]   c1824     1
    x[1511]   c31       1
    x[1511]   c202      -1
    x[1512]   c450_1    1
    x[1512]   c1825     1
    x[1512]   c31       1
    x[1512]   c202      -1
    x[1513]   c446_1    1
    x[1513]   c1826     1
    x[1513]   c31       1
    x[1513]   c202      -2
    x[1514]   c447_1    1
    x[1514]   c1827     1
    x[1514]   c31       1
    x[1514]   c202      -2
    x[1515]   c448_1    1
    x[1515]   c1828     1
    x[1515]   c31       1
    x[1515]   c202      -2
    x[1516]   c449_1    1
    x[1516]   c1829     1
    x[1516]   c31       1
    x[1516]   c202      -2
    x[1517]   c450_1    1
    x[1517]   c1830     1
    x[1517]   c31       1
    x[1517]   c202      -2
    x[1518]   c451_1    1
    x[1518]   c1831     1
    x[1518]   c31       1
    x[1518]   c202      -3
    x[1519]   c452_1    1
    x[1519]   c1832     1
    x[1519]   c31       1
    x[1519]   c202      -3
    x[1520]   c453_1    1
    x[1520]   c1833     1
    x[1520]   c31       1
    x[1520]   c202      -3
    x[1521]   c454_1    1
    x[1521]   c1834     1
    x[1521]   c31       1
    x[1521]   c202      -3
    x[1522]   c455_1    1
    x[1522]   c1835     1
    x[1522]   c31       1
    x[1522]   c202      -3
    x[1523]   c451_1    1
    x[1523]   c1836     1
    x[1523]   c31       1
    x[1523]   c202      -2
    x[1524]   c452_1    1
    x[1524]   c1837     1
    x[1524]   c31       1
    x[1524]   c202      -2
    x[1525]   c453_1    1
    x[1525]   c1838     1
    x[1525]   c31       1
    x[1525]   c202      -2
    x[1526]   c454_1    1
    x[1526]   c1839     1
    x[1526]   c31       1
    x[1526]   c202      -2
    x[1527]   c455_1    1
    x[1527]   c1840     1
    x[1527]   c31       1
    x[1527]   c202      -2
    x[1528]   c451_1    1
    x[1528]   c1841     1
    x[1528]   c31       1
    x[1528]   c202      -1
    x[1529]   c452_1    1
    x[1529]   c1842     1
    x[1529]   c31       1
    x[1529]   c202      -1
    x[1530]   c453_1    1
    x[1530]   c1843     1
    x[1530]   c31       1
    x[1530]   c202      -1
    x[1531]   c454_1    1
    x[1531]   c1844     1
    x[1531]   c31       1
    x[1531]   c202      -1
    x[1532]   c455_1    1
    x[1532]   c1845     1
    x[1532]   c31       1
    x[1532]   c202      -1
    x[1533]   c456_1    1
    x[1533]   c197      1
    x[1533]   c208      -1
    x[1533]   c212      -1
    x[1534]   c457_1    1
    x[1534]   c198      1
    x[1534]   c216      -1
    x[1534]   c220      -1
    x[1535]   c458_1    1
    x[1535]   c199      1
    x[1535]   c224      -1
    x[1535]   c226      -1
    x[1535]   c230      -1
    x[1536]   c459_1    1
    x[1536]   c200      1
    x[1536]   c234      -1
    x[1536]   c238      -1
    x[1537]   c460_1    1
    x[1537]   c201      1
    x[1537]   c242      -1
    x[1537]   c246      -1
    x[1538]   c456_1    1
    x[1538]   c1846     1
    x[1538]   c31       1
    x[1538]   c202      -1
    x[1539]   c457_1    1
    x[1539]   c1847     1
    x[1539]   c31       1
    x[1539]   c202      -1
    x[1540]   c458_1    1
    x[1540]   c1848     1
    x[1540]   c31       1
    x[1540]   c202      -1
    x[1541]   c459_1    1
    x[1541]   c1849     1
    x[1541]   c31       1
    x[1541]   c202      -1
    x[1542]   c460_1    1
    x[1542]   c1850     1
    x[1542]   c31       1
    x[1542]   c202      -1
    x[1543]   c456_1    1
    x[1543]   c1851     1
    x[1543]   c31       1
    x[1543]   c202      -2
    x[1544]   c457_1    1
    x[1544]   c1852     1
    x[1544]   c31       1
    x[1544]   c202      -2
    x[1545]   c458_1    1
    x[1545]   c1853     1
    x[1545]   c31       1
    x[1545]   c202      -2
    x[1546]   c459_1    1
    x[1546]   c1854     1
    x[1546]   c31       1
    x[1546]   c202      -2
    x[1547]   c460_1    1
    x[1547]   c1855     1
    x[1547]   c31       1
    x[1547]   c202      -2
    x[1548]   c456_1    1
    x[1548]   c1856     1
    x[1548]   c31       1
    x[1548]   c202      -3
    x[1549]   c457_1    1
    x[1549]   c1857     1
    x[1549]   c31       1
    x[1549]   c202      -3
    x[1550]   c458_1    1
    x[1550]   c1858     1
    x[1550]   c31       1
    x[1550]   c202      -3
    x[1551]   c459_1    1
    x[1551]   c1859     1
    x[1551]   c31       1
    x[1551]   c202      -3
    x[1552]   c460_1    1
    x[1552]   c1860     1
    x[1552]   c31       1
    x[1552]   c202      -3
    x[1553]   c461_1    1
    x[1553]   c1861     1
    x[1553]   c31       1
    x[1553]   c202      -2
    x[1554]   c462_1    1
    x[1554]   c1862     1
    x[1554]   c31       1
    x[1554]   c202      -2
    x[1555]   c463_1    1
    x[1555]   c1863     1
    x[1555]   c31       1
    x[1555]   c202      -2
    x[1556]   c464_1    1
    x[1556]   c1864     1
    x[1556]   c31       1
    x[1556]   c202      -2
    x[1557]   c465_1    1
    x[1557]   c1865     1
    x[1557]   c31       1
    x[1557]   c202      -2
    x[1558]   c461_1    1
    x[1558]   c1866     1
    x[1558]   c31       1
    x[1558]   c202      -1
    x[1559]   c462_1    1
    x[1559]   c1867     1
    x[1559]   c31       1
    x[1559]   c202      -1
    x[1560]   c463_1    1
    x[1560]   c1868     1
    x[1560]   c31       1
    x[1560]   c202      -1
    x[1561]   c464_1    1
    x[1561]   c1869     1
    x[1561]   c31       1
    x[1561]   c202      -1
    x[1562]   c465_1    1
    x[1562]   c1870     1
    x[1562]   c31       1
    x[1562]   c202      -1
    x[1563]   c461_1    1
    x[1563]   c1871     1
    x[1563]   c31       1
    x[1563]   c202      -3
    x[1564]   c462_1    1
    x[1564]   c1872     1
    x[1564]   c31       1
    x[1564]   c202      -3
    x[1565]   c463_1    1
    x[1565]   c1873     1
    x[1565]   c31       1
    x[1565]   c202      -3
    x[1566]   c464_1    1
    x[1566]   c1874     1
    x[1566]   c31       1
    x[1566]   c202      -3
    x[1567]   c465_1    1
    x[1567]   c1875     1
    x[1567]   c31       1
    x[1567]   c202      -3
    x[1568]   c466_1    1
    x[1568]   c1876     1
    x[1568]   c31       1
    x[1568]   c202      -2
    x[1569]   c467_1    1
    x[1569]   c1877     1
    x[1569]   c31       1
    x[1569]   c202      -2
    x[1570]   c468_1    1
    x[1570]   c1878     1
    x[1570]   c31       1
    x[1570]   c202      -2
    x[1571]   c469_1    1
    x[1571]   c1879     1
    x[1571]   c31       1
    x[1571]   c202      -2
    x[1572]   c470_1    1
    x[1572]   c1880     1
    x[1572]   c31       1
    x[1572]   c202      -2
    x[1573]   c466_1    1
    x[1573]   c1881     1
    x[1573]   c31       1
    x[1573]   c202      -1
    x[1574]   c467_1    1
    x[1574]   c1882     1
    x[1574]   c31       1
    x[1574]   c202      -1
    x[1575]   c468_1    1
    x[1575]   c1883     1
    x[1575]   c31       1
    x[1575]   c202      -1
    x[1576]   c469_1    1
    x[1576]   c1884     1
    x[1576]   c31       1
    x[1576]   c202      -1
    x[1577]   c470_1    1
    x[1577]   c1885     1
    x[1577]   c31       1
    x[1577]   c202      -1
    x[1578]   c466_1    1
    x[1578]   c1886     1
    x[1578]   c31       1
    x[1578]   c202      -3
    x[1579]   c467_1    1
    x[1579]   c1887     1
    x[1579]   c31       1
    x[1579]   c202      -3
    x[1580]   c468_1    1
    x[1580]   c1888     1
    x[1580]   c31       1
    x[1580]   c202      -3
    x[1581]   c469_1    1
    x[1581]   c1889     1
    x[1581]   c31       1
    x[1581]   c202      -3
    x[1582]   c470_1    1
    x[1582]   c1890     1
    x[1582]   c31       1
    x[1582]   c202      -3
    x[1583]   c471_1    1
    x[1583]   c1891     1
    x[1583]   c31       1
    x[1583]   c202      -3
    x[1584]   c472_1    1
    x[1584]   c1892     1
    x[1584]   c31       1
    x[1584]   c202      -3
    x[1585]   c473_1    1
    x[1585]   c1893     1
    x[1585]   c31       1
    x[1585]   c202      -3
    x[1586]   c474_1    1
    x[1586]   c1894     1
    x[1586]   c31       1
    x[1586]   c202      -3
    x[1587]   c475_1    1
    x[1587]   c1895     1
    x[1587]   c31       1
    x[1587]   c202      -3
    x[1588]   c471_1    1
    x[1588]   c1896     1
    x[1588]   c31       1
    x[1588]   c202      -1
    x[1589]   c472_1    1
    x[1589]   c1897     1
    x[1589]   c31       1
    x[1589]   c202      -1
    x[1590]   c473_1    1
    x[1590]   c1898     1
    x[1590]   c31       1
    x[1590]   c202      -1
    x[1591]   c474_1    1
    x[1591]   c1899     1
    x[1591]   c31       1
    x[1591]   c202      -1
    x[1592]   c475_1    1
    x[1592]   c1900     1
    x[1592]   c31       1
    x[1592]   c202      -1
    x[1593]   c471_1    1
    x[1593]   c1901     1
    x[1593]   c31       1
    x[1593]   c202      -2
    x[1594]   c472_1    1
    x[1594]   c1902     1
    x[1594]   c31       1
    x[1594]   c202      -2
    x[1595]   c473_1    1
    x[1595]   c1903     1
    x[1595]   c31       1
    x[1595]   c202      -2
    x[1596]   c474_1    1
    x[1596]   c1904     1
    x[1596]   c31       1
    x[1596]   c202      -2
    x[1597]   c475_1    1
    x[1597]   c1905     1
    x[1597]   c31       1
    x[1597]   c202      -2
    x[1598]   c476_1    1
    x[1598]   c481_1    -1
    x[1598]   c496_1    -1
    x[1598]   c526_1    -1
    x[1598]   c556_1    -1
    x[1598]   c631_1    -1
    x[1598]   c766_1    -1
    x[1598]   c946_1    -1
    x[1598]   c1036     -1
    x[1598]   c1141     -1
    x[1598]   c1156     -1
    x[1598]   c1186     -1
    x[1598]   c1411     -1
    x[1598]   c1771     -1
    x[1598]   c1801     -1
    x[1598]   c1816     -1
    x[1598]   c1876     -1
    x[1598]   c1        1
    x[1598]   c122      -1
    x[1598]   c172      -1
    x[1598]   c197      -1
    x[1598]   c202      -1
    x[1598]   c206      1
    x[1598]   c207      1
    x[1598]   c208      1
    x[1598]   c210      1
    x[1598]   c211      1
    x[1598]   c212      1
    x[1599]   c477_1    1
    x[1599]   c482_1    -1
    x[1599]   c497_1    -1
    x[1599]   c527_1    -1
    x[1599]   c557_1    -1
    x[1599]   c632_1    -1
    x[1599]   c767_1    -1
    x[1599]   c947      -1
    x[1599]   c1037     -1
    x[1599]   c1142     -1
    x[1599]   c1157     -1
    x[1599]   c1187     -1
    x[1599]   c1412     -1
    x[1599]   c1772     -1
    x[1599]   c1802     -1
    x[1599]   c1817     -1
    x[1599]   c1877     -1
    x[1599]   c1        1
    x[1599]   c123      -1
    x[1599]   c173      -1
    x[1599]   c198      -1
    x[1599]   c202      -2
    x[1599]   c214      1
    x[1599]   c215      1
    x[1599]   c216      1
    x[1599]   c218      1
    x[1599]   c219      1
    x[1599]   c220      1
    x[1600]   c478_1    1
    x[1600]   c483_1    -1
    x[1600]   c498_1    -1
    x[1600]   c528_1    -1
    x[1600]   c558_1    -1
    x[1600]   c633_1    -1
    x[1600]   c768_1    -1
    x[1600]   c948      -1
    x[1600]   c1038     -1
    x[1600]   c1143     -1
    x[1600]   c1158     -1
    x[1600]   c1188     -1
    x[1600]   c1413     -1
    x[1600]   c1773     -1
    x[1600]   c1803     -1
    x[1600]   c1818     -1
    x[1600]   c1878     -1
    x[1600]   c1        1
    x[1600]   c124      -1
    x[1600]   c174      -1
    x[1600]   c199      -1
    x[1600]   c202      -3
    x[1600]   c222      1
    x[1600]   c223      1
    x[1600]   c224      1
    x[1600]   c226      1
    x[1600]   c228      1
    x[1600]   c229      1
    x[1600]   c230      1
    x[1601]   c479_1    1
    x[1601]   c484_1    -1
    x[1601]   c499_1    -1
    x[1601]   c529_1    -1
    x[1601]   c559_1    -1
    x[1601]   c634_1    -1
    x[1601]   c769_1    -1
    x[1601]   c949      -1
    x[1601]   c1039     -1
    x[1601]   c1144     -1
    x[1601]   c1159     -1
    x[1601]   c1189     -1
    x[1601]   c1414     -1
    x[1601]   c1774     -1
    x[1601]   c1804     -1
    x[1601]   c1819     -1
    x[1601]   c1879     -1
    x[1601]   c1        1
    x[1601]   c125      -1
    x[1601]   c175      -1
    x[1601]   c200      -1
    x[1601]   c202      -4
    x[1601]   c232      1
    x[1601]   c233      1
    x[1601]   c234      1
    x[1601]   c236      1
    x[1601]   c237      1
    x[1601]   c238      1
    x[1602]   c480_1    1
    x[1602]   c485_1    -1
    x[1602]   c500_1    -1
    x[1602]   c530_1    -1
    x[1602]   c560_1    -1
    x[1602]   c635_1    -1
    x[1602]   c770_1    -1
    x[1602]   c950      -1
    x[1602]   c1040     -1
    x[1602]   c1145     -1
    x[1602]   c1160     -1
    x[1602]   c1190     -1
    x[1602]   c1415     -1
    x[1602]   c1775     -1
    x[1602]   c1805     -1
    x[1602]   c1820     -1
    x[1602]   c1880     -1
    x[1602]   c1        1
    x[1602]   c126      -1
    x[1602]   c176      -1
    x[1602]   c201      -1
    x[1602]   c202      -5
    x[1602]   c240      1
    x[1602]   c241      1
    x[1602]   c242      1
    x[1602]   c244      1
    x[1602]   c245      1
    x[1602]   c246      1
    x[1603]   c476_1    1
    x[1603]   c486_1    -1
    x[1603]   c531_1    -1
    x[1603]   c541_1    -1
    x[1603]   c616_1    -1
    x[1603]   c646_1    -1
    x[1603]   c706_1    -1
    x[1603]   c771_1    -1
    x[1603]   c796_1    -1
    x[1603]   c856_1    -1
    x[1603]   c901_1    -1
    x[1603]   c916_1    -1
    x[1603]   c951      -1
    x[1603]   c991      -1
    x[1603]   c1006     -1
    x[1603]   c1146     -1
    x[1603]   c1171     -1
    x[1603]   c1201     -1
    x[1603]   c1246     -1
    x[1603]   c1261     -1
    x[1603]   c1291     -1
    x[1603]   c1306     -1
    x[1603]   c1336     -1
    x[1603]   c1366     -1
    x[1603]   c1396     -1
    x[1603]   c1516     -1
    x[1603]   c1546     -1
    x[1603]   c1636     -1
    x[1603]   c1711     -1
    x[1603]   c1726     -1
    x[1603]   c1806     -1
    x[1603]   c2        1
    x[1603]   c67       -1
    x[1603]   c87       -1
    x[1603]   c177      -1
    x[1603]   c202      -2
    x[1603]   c283      1
    x[1603]   c284      1
    x[1603]   c285      1
    x[1603]   c287      1
    x[1603]   c288      1
    x[1603]   c289      1
    x[1604]   c477_1    1
    x[1604]   c487_1    -1
    x[1604]   c532_1    -1
    x[1604]   c542_1    -1
    x[1604]   c617_1    -1
    x[1604]   c647_1    -1
    x[1604]   c707_1    -1
    x[1604]   c772_1    -1
    x[1604]   c797_1    -1
    x[1604]   c857_1    -1
    x[1604]   c902_1    -1
    x[1604]   c917_1    -1
    x[1604]   c952      -1
    x[1604]   c992      -1
    x[1604]   c1007     -1
    x[1604]   c1147     -1
    x[1604]   c1172     -1
    x[1604]   c1202     -1
    x[1604]   c1247     -1
    x[1604]   c1262     -1
    x[1604]   c1292     -1
    x[1604]   c1307     -1
    x[1604]   c1337     -1
    x[1604]   c1367     -1
    x[1604]   c1397     -1
    x[1604]   c1517     -1
    x[1604]   c1547     -1
    x[1604]   c1637     -1
    x[1604]   c1712     -1
    x[1604]   c1727     -1
    x[1604]   c1807     -1
    x[1604]   c2        1
    x[1604]   c68       -1
    x[1604]   c88       -1
    x[1604]   c178      -1
    x[1604]   c202      -4
    x[1604]   c291      1
    x[1604]   c292      1
    x[1604]   c293      1
    x[1604]   c295      1
    x[1604]   c296      1
    x[1604]   c297      1
    x[1605]   c478_1    1
    x[1605]   c488_1    -1
    x[1605]   c533_1    -1
    x[1605]   c543_1    -1
    x[1605]   c618_1    -1
    x[1605]   c648_1    -1
    x[1605]   c708_1    -1
    x[1605]   c773_1    -1
    x[1605]   c798_1    -1
    x[1605]   c858_1    -1
    x[1605]   c903_1    -1
    x[1605]   c918_1    -1
    x[1605]   c953      -1
    x[1605]   c993      -1
    x[1605]   c1008     -1
    x[1605]   c1148     -1
    x[1605]   c1173     -1
    x[1605]   c1203     -1
    x[1605]   c1248     -1
    x[1605]   c1263     -1
    x[1605]   c1293     -1
    x[1605]   c1308     -1
    x[1605]   c1338     -1
    x[1605]   c1368     -1
    x[1605]   c1398     -1
    x[1605]   c1518     -1
    x[1605]   c1548     -1
    x[1605]   c1638     -1
    x[1605]   c1713     -1
    x[1605]   c1728     -1
    x[1605]   c1808     -1
    x[1605]   c2        1
    x[1605]   c69       -1
    x[1605]   c89       -1
    x[1605]   c179      -1
    x[1605]   c202      -6
    x[1605]   c299      1
    x[1605]   c300      1
    x[1605]   c301      1
    x[1605]   c303      1
    x[1605]   c305      1
    x[1605]   c306      1
    x[1605]   c307      1
    x[1606]   c479_1    1
    x[1606]   c489_1    -1
    x[1606]   c534_1    -1
    x[1606]   c544_1    -1
    x[1606]   c619_1    -1
    x[1606]   c649_1    -1
    x[1606]   c709_1    -1
    x[1606]   c774_1    -1
    x[1606]   c799_1    -1
    x[1606]   c859_1    -1
    x[1606]   c904_1    -1
    x[1606]   c919_1    -1
    x[1606]   c954      -1
    x[1606]   c994      -1
    x[1606]   c1009     -1
    x[1606]   c1149     -1
    x[1606]   c1174     -1
    x[1606]   c1204     -1
    x[1606]   c1249     -1
    x[1606]   c1264     -1
    x[1606]   c1294     -1
    x[1606]   c1309     -1
    x[1606]   c1339     -1
    x[1606]   c1369     -1
    x[1606]   c1399     -1
    x[1606]   c1519     -1
    x[1606]   c1549     -1
    x[1606]   c1639     -1
    x[1606]   c1714     -1
    x[1606]   c1729     -1
    x[1606]   c1809     -1
    x[1606]   c2        1
    x[1606]   c70       -1
    x[1606]   c90       -1
    x[1606]   c180      -1
    x[1606]   c202      -8
    x[1606]   c309      1
    x[1606]   c310      1
    x[1606]   c311      1
    x[1606]   c313      1
    x[1606]   c314      1
    x[1606]   c315      1
    x[1607]   c480_1    1
    x[1607]   c490_1    -1
    x[1607]   c535_1    -1
    x[1607]   c545_1    -1
    x[1607]   c620_1    -1
    x[1607]   c650_1    -1
    x[1607]   c710_1    -1
    x[1607]   c775_1    -1
    x[1607]   c800_1    -1
    x[1607]   c860_1    -1
    x[1607]   c905_1    -1
    x[1607]   c920_1    -1
    x[1607]   c955      -1
    x[1607]   c995      -1
    x[1607]   c1010     -1
    x[1607]   c1150     -1
    x[1607]   c1175     -1
    x[1607]   c1205     -1
    x[1607]   c1250     -1
    x[1607]   c1265     -1
    x[1607]   c1295     -1
    x[1607]   c1310     -1
    x[1607]   c1340     -1
    x[1607]   c1370     -1
    x[1607]   c1400     -1
    x[1607]   c1520     -1
    x[1607]   c1550     -1
    x[1607]   c1640     -1
    x[1607]   c1715     -1
    x[1607]   c1730     -1
    x[1607]   c1810     -1
    x[1607]   c2        1
    x[1607]   c71       -1
    x[1607]   c91       -1
    x[1607]   c181      -1
    x[1607]   c202      -10
    x[1607]   c317      1
    x[1607]   c318      1
    x[1607]   c319      1
    x[1607]   c321      1
    x[1607]   c322      1
    x[1607]   c323      1
    x[1608]   c476_1    1
    x[1608]   c546_1    -1
    x[1608]   c736_1    -1
    x[1608]   c811_1    -1
    x[1608]   c906_1    -1
    x[1608]   c921_1    -1
    x[1608]   c996      -1
    x[1608]   c1021     -1
    x[1608]   c1051     -1
    x[1608]   c1096     -1
    x[1608]   c1176     -1
    x[1608]   c1216     -1
    x[1608]   c1471     -1
    x[1608]   c1521     -1
    x[1608]   c1561     -1
    x[1608]   c1591     -1
    x[1608]   c1641     -1
    x[1608]   c1681     -1
    x[1608]   c1756     -1
    x[1608]   c1811     -1
    x[1608]   c1846     -1
    x[1608]   c1891     -1
    x[1608]   c3        1
    x[1608]   c92       -1
    x[1608]   c202      -3
    x[1608]   c345      1
    x[1608]   c347      1
    x[1609]   c477_1    1
    x[1609]   c547_1    -1
    x[1609]   c737_1    -1
    x[1609]   c812_1    -1
    x[1609]   c907_1    -1
    x[1609]   c922_1    -1
    x[1609]   c997      -1
    x[1609]   c1022     -1
    x[1609]   c1052     -1
    x[1609]   c1097     -1
    x[1609]   c1177     -1
    x[1609]   c1217     -1
    x[1609]   c1472     -1
    x[1609]   c1522     -1
    x[1609]   c1562     -1
    x[1609]   c1592     -1
    x[1609]   c1642     -1
    x[1609]   c1682     -1
    x[1609]   c1757     -1
    x[1609]   c1812     -1
    x[1609]   c1847     -1
    x[1609]   c1892     -1
    x[1609]   c3        1
    x[1609]   c93       -1
    x[1609]   c202      -6
    x[1609]   c349      1
    x[1609]   c351      1
    x[1610]   c478_1    1
    x[1610]   c548_1    -1
    x[1610]   c738_1    -1
    x[1610]   c813_1    -1
    x[1610]   c908_1    -1
    x[1610]   c923_1    -1
    x[1610]   c998      -1
    x[1610]   c1023     -1
    x[1610]   c1053     -1
    x[1610]   c1098     -1
    x[1610]   c1178     -1
    x[1610]   c1218     -1
    x[1610]   c1473     -1
    x[1610]   c1523     -1
    x[1610]   c1563     -1
    x[1610]   c1593     -1
    x[1610]   c1643     -1
    x[1610]   c1683     -1
    x[1610]   c1758     -1
    x[1610]   c1813     -1
    x[1610]   c1848     -1
    x[1610]   c1893     -1
    x[1610]   c3        1
    x[1610]   c94       -1
    x[1610]   c202      -9
    x[1610]   c353      1
    x[1610]   c355      1
    x[1611]   c479_1    1
    x[1611]   c549_1    -1
    x[1611]   c739_1    -1
    x[1611]   c814_1    -1
    x[1611]   c909_1    -1
    x[1611]   c924_1    -1
    x[1611]   c999      -1
    x[1611]   c1024     -1
    x[1611]   c1054     -1
    x[1611]   c1099     -1
    x[1611]   c1179     -1
    x[1611]   c1219     -1
    x[1611]   c1474     -1
    x[1611]   c1524     -1
    x[1611]   c1564     -1
    x[1611]   c1594     -1
    x[1611]   c1644     -1
    x[1611]   c1684     -1
    x[1611]   c1759     -1
    x[1611]   c1814     -1
    x[1611]   c1849     -1
    x[1611]   c1894     -1
    x[1611]   c3        1
    x[1611]   c95       -1
    x[1611]   c202      -12
    x[1611]   c357      1
    x[1611]   c359      1
    x[1612]   c480_1    1
    x[1612]   c550_1    -1
    x[1612]   c740_1    -1
    x[1612]   c815_1    -1
    x[1612]   c910_1    -1
    x[1612]   c925_1    -1
    x[1612]   c1000     -1
    x[1612]   c1025     -1
    x[1612]   c1055     -1
    x[1612]   c1100     -1
    x[1612]   c1180     -1
    x[1612]   c1220     -1
    x[1612]   c1475     -1
    x[1612]   c1525     -1
    x[1612]   c1565     -1
    x[1612]   c1595     -1
    x[1612]   c1645     -1
    x[1612]   c1685     -1
    x[1612]   c1760     -1
    x[1612]   c1815     -1
    x[1612]   c1850     -1
    x[1612]   c1895     -1
    x[1612]   c3        1
    x[1612]   c96       -1
    x[1612]   c202      -15
    x[1612]   c361      1
    x[1612]   c363      1
    x[1613]   c476_1    1
    x[1613]   c1531     -1
    x[1613]   c4        1
    x[1613]   c127      -1
    x[1613]   c202      -4
    x[1613]   c406      1
    x[1613]   c408      1
    x[1614]   c477_1    1
    x[1614]   c1532     -1
    x[1614]   c4        1
    x[1614]   c128      -1
    x[1614]   c202      -8
    x[1614]   c410      1
    x[1614]   c412      1
    x[1615]   c478_1    1
    x[1615]   c1533     -1
    x[1615]   c4        1
    x[1615]   c129      -1
    x[1615]   c202      -12
    x[1615]   c414      1
    x[1615]   c416      1
    x[1616]   c479_1    1
    x[1616]   c1534     -1
    x[1616]   c4        1
    x[1616]   c130      -1
    x[1616]   c202      -16
    x[1616]   c418      1
    x[1616]   c420      1
    x[1617]   c480_1    1
    x[1617]   c1535     -1
    x[1617]   c4        1
    x[1617]   c131      -1
    x[1617]   c202      -20
    x[1617]   c422      1
    x[1617]   c424      1
    x[1618]   c476_1    1
    x[1618]   c491_1    -1
    x[1618]   c511_1    -1
    x[1618]   c601_1    -1
    x[1618]   c636_1    -1
    x[1618]   c651_1    -1
    x[1618]   c661_1    -1
    x[1618]   c776_1    -1
    x[1618]   c816_1    -1
    x[1618]   c871_1    -1
    x[1618]   c1111     -1
    x[1618]   c1501     -1
    x[1618]   c1551     -1
    x[1618]   c1666     -1
    x[1618]   c1696     -1
    x[1618]   c1731     -1
    x[1618]   c1831     -1
    x[1618]   c5        1
    x[1618]   c112      -1
    x[1618]   c132      -1
    x[1618]   c202      -5
    x[1618]   c448      1
    x[1618]   c449      1
    x[1618]   c451      1
    x[1618]   c452      1
    x[1619]   c477_1    1
    x[1619]   c492_1    -1
    x[1619]   c512_1    -1
    x[1619]   c602_1    -1
    x[1619]   c637_1    -1
    x[1619]   c652_1    -1
    x[1619]   c662_1    -1
    x[1619]   c777_1    -1
    x[1619]   c817_1    -1
    x[1619]   c872_1    -1
    x[1619]   c1112     -1
    x[1619]   c1502     -1
    x[1619]   c1552     -1
    x[1619]   c1667     -1
    x[1619]   c1697     -1
    x[1619]   c1732     -1
    x[1619]   c1832     -1
    x[1619]   c5        1
    x[1619]   c113      -1
    x[1619]   c133      -1
    x[1619]   c202      -10
    x[1619]   c454      1
    x[1619]   c455      1
    x[1619]   c457      1
    x[1619]   c458      1
    x[1620]   c478_1    1
    x[1620]   c493_1    -1
    x[1620]   c513_1    -1
    x[1620]   c603_1    -1
    x[1620]   c638_1    -1
    x[1620]   c653_1    -1
    x[1620]   c663_1    -1
    x[1620]   c778_1    -1
    x[1620]   c818_1    -1
    x[1620]   c873_1    -1
    x[1620]   c1113     -1
    x[1620]   c1503     -1
    x[1620]   c1553     -1
    x[1620]   c1668     -1
    x[1620]   c1698     -1
    x[1620]   c1733     -1
    x[1620]   c1833     -1
    x[1620]   c5        1
    x[1620]   c114      -1
    x[1620]   c134      -1
    x[1620]   c202      -15
    x[1620]   c460      1
    x[1620]   c461      1
    x[1620]   c463      1
    x[1620]   c464      1
    x[1621]   c479_1    1
    x[1621]   c494_1    -1
    x[1621]   c514_1    -1
    x[1621]   c604_1    -1
    x[1621]   c639_1    -1
    x[1621]   c654_1    -1
    x[1621]   c664_1    -1
    x[1621]   c779_1    -1
    x[1621]   c819_1    -1
    x[1621]   c874_1    -1
    x[1621]   c1114     -1
    x[1621]   c1504     -1
    x[1621]   c1554     -1
    x[1621]   c1669     -1
    x[1621]   c1699     -1
    x[1621]   c1734     -1
    x[1621]   c1834     -1
    x[1621]   c5        1
    x[1621]   c115      -1
    x[1621]   c135      -1
    x[1621]   c202      -20
    x[1621]   c466      1
    x[1621]   c467      1
    x[1621]   c469      1
    x[1621]   c470      1
    x[1622]   c480_1    1
    x[1622]   c495_1    -1
    x[1622]   c515_1    -1
    x[1622]   c605_1    -1
    x[1622]   c640_1    -1
    x[1622]   c655_1    -1
    x[1622]   c665_1    -1
    x[1622]   c780_1    -1
    x[1622]   c820_1    -1
    x[1622]   c875_1    -1
    x[1622]   c1115     -1
    x[1622]   c1505     -1
    x[1622]   c1555     -1
    x[1622]   c1670     -1
    x[1622]   c1700     -1
    x[1622]   c1735     -1
    x[1622]   c1835     -1
    x[1622]   c5        1
    x[1622]   c116      -1
    x[1622]   c136      -1
    x[1622]   c202      -25
    x[1622]   c472      1
    x[1622]   c473      1
    x[1622]   c475      1
    x[1622]   c476      1
    x[1623]   c476_1    1
    x[1623]   c606_1    -1
    x[1623]   c1001     -1
    x[1623]   c1066     -1
    x[1623]   c1576     -1
    x[1623]   c1651     -1
    x[1623]   c1776     -1
    x[1623]   c6        1
    x[1623]   c202      -6
    x[1624]   c477_1    1
    x[1624]   c607_1    -1
    x[1624]   c1002     -1
    x[1624]   c1067     -1
    x[1624]   c1577     -1
    x[1624]   c1652     -1
    x[1624]   c1777     -1
    x[1624]   c6        1
    x[1624]   c202      -12
    x[1625]   c478_1    1
    x[1625]   c608_1    -1
    x[1625]   c1003     -1
    x[1625]   c1068     -1
    x[1625]   c1578     -1
    x[1625]   c1653     -1
    x[1625]   c1778     -1
    x[1625]   c6        1
    x[1625]   c202      -18
    x[1626]   c479_1    1
    x[1626]   c609_1    -1
    x[1626]   c1004     -1
    x[1626]   c1069     -1
    x[1626]   c1579     -1
    x[1626]   c1654     -1
    x[1626]   c1779     -1
    x[1626]   c6        1
    x[1626]   c202      -24
    x[1627]   c480_1    1
    x[1627]   c610_1    -1
    x[1627]   c1005     -1
    x[1627]   c1070     -1
    x[1627]   c1580     -1
    x[1627]   c1655     -1
    x[1627]   c1780     -1
    x[1627]   c6        1
    x[1627]   c202      -30
    x[1628]   c476_1    1
    x[1628]   c656_1    -1
    x[1628]   c721_1    -1
    x[1628]   c741_1    -1
    x[1628]   c751_1    -1
    x[1628]   c801_1    -1
    x[1628]   c1026     -1
    x[1628]   c1071     -1
    x[1628]   c1101     -1
    x[1628]   c1251     -1
    x[1628]   c1401     -1
    x[1628]   c1506     -1
    x[1628]   c1566     -1
    x[1628]   c1716     -1
    x[1628]   c1736     -1
    x[1628]   c1761     -1
    x[1628]   c1781     -1
    x[1628]   c1861     -1
    x[1628]   c7        1
    x[1628]   c202      -7
    x[1629]   c477_1    1
    x[1629]   c657_1    -1
    x[1629]   c722_1    -1
    x[1629]   c742_1    -1
    x[1629]   c752_1    -1
    x[1629]   c802_1    -1
    x[1629]   c1027     -1
    x[1629]   c1072     -1
    x[1629]   c1102     -1
    x[1629]   c1252     -1
    x[1629]   c1402     -1
    x[1629]   c1507     -1
    x[1629]   c1567     -1
    x[1629]   c1717     -1
    x[1629]   c1737     -1
    x[1629]   c1762     -1
    x[1629]   c1782     -1
    x[1629]   c1862     -1
    x[1629]   c7        1
    x[1629]   c202      -14
    x[1630]   c478_1    1
    x[1630]   c658_1    -1
    x[1630]   c723_1    -1
    x[1630]   c743_1    -1
    x[1630]   c753_1    -1
    x[1630]   c803_1    -1
    x[1630]   c1028     -1
    x[1630]   c1073     -1
    x[1630]   c1103     -1
    x[1630]   c1253     -1
    x[1630]   c1403     -1
    x[1630]   c1508     -1
    x[1630]   c1568     -1
    x[1630]   c1718     -1
    x[1630]   c1738     -1
    x[1630]   c1763     -1
    x[1630]   c1783     -1
    x[1630]   c1863     -1
    x[1630]   c7        1
    x[1630]   c202      -21
    x[1631]   c479_1    1
    x[1631]   c659_1    -1
    x[1631]   c724_1    -1
    x[1631]   c744_1    -1
    x[1631]   c754_1    -1
    x[1631]   c804_1    -1
    x[1631]   c1029     -1
    x[1631]   c1074     -1
    x[1631]   c1104     -1
    x[1631]   c1254     -1
    x[1631]   c1404     -1
    x[1631]   c1509     -1
    x[1631]   c1569     -1
    x[1631]   c1719     -1
    x[1631]   c1739     -1
    x[1631]   c1764     -1
    x[1631]   c1784     -1
    x[1631]   c1864     -1
    x[1631]   c7        1
    x[1631]   c202      -28
    x[1632]   c480_1    1
    x[1632]   c660_1    -1
    x[1632]   c725_1    -1
    x[1632]   c745_1    -1
    x[1632]   c755_1    -1
    x[1632]   c805_1    -1
    x[1632]   c1030     -1
    x[1632]   c1075     -1
    x[1632]   c1105     -1
    x[1632]   c1255     -1
    x[1632]   c1405     -1
    x[1632]   c1510     -1
    x[1632]   c1570     -1
    x[1632]   c1720     -1
    x[1632]   c1740     -1
    x[1632]   c1765     -1
    x[1632]   c1785     -1
    x[1632]   c1865     -1
    x[1632]   c7        1
    x[1632]   c202      -35
    x[1633]   c476_1    1
    x[1633]   c561_1    -1
    x[1633]   c676_1    -1
    x[1633]   c956      -1
    x[1633]   c1126     -1
    x[1633]   c1511     -1
    x[1633]   c1571     -1
    x[1633]   c1866     -1
    x[1633]   c8        1
    x[1633]   c202      -8
    x[1634]   c477_1    1
    x[1634]   c562_1    -1
    x[1634]   c677_1    -1
    x[1634]   c957      -1
    x[1634]   c1127     -1
    x[1634]   c1512     -1
    x[1634]   c1572     -1
    x[1634]   c1867     -1
    x[1634]   c8        1
    x[1634]   c202      -16
    x[1635]   c478_1    1
    x[1635]   c563_1    -1
    x[1635]   c678_1    -1
    x[1635]   c958      -1
    x[1635]   c1128     -1
    x[1635]   c1513     -1
    x[1635]   c1573     -1
    x[1635]   c1868     -1
    x[1635]   c8        1
    x[1635]   c202      -24
    x[1636]   c479_1    1
    x[1636]   c564_1    -1
    x[1636]   c679_1    -1
    x[1636]   c959      -1
    x[1636]   c1129     -1
    x[1636]   c1514     -1
    x[1636]   c1574     -1
    x[1636]   c1869     -1
    x[1636]   c8        1
    x[1636]   c202      -32
    x[1637]   c480_1    1
    x[1637]   c565_1    -1
    x[1637]   c680_1    -1
    x[1637]   c960      -1
    x[1637]   c1130     -1
    x[1637]   c1515     -1
    x[1637]   c1575     -1
    x[1637]   c1870     -1
    x[1637]   c8        1
    x[1637]   c202      -40
    x[1638]   c476_1    1
    x[1638]   c691_1    -1
    x[1638]   c756_1    -1
    x[1638]   c1056     -1
    x[1638]   c1256     -1
    x[1638]   c1476     -1
    x[1638]   c1606     -1
    x[1638]   c1701     -1
    x[1638]   c9        1
    x[1638]   c202      -9
    x[1639]   c477_1    1
    x[1639]   c692_1    -1
    x[1639]   c757_1    -1
    x[1639]   c1057     -1
    x[1639]   c1257     -1
    x[1639]   c1477     -1
    x[1639]   c1607     -1
    x[1639]   c1702     -1
    x[1639]   c9        1
    x[1639]   c202      -18
    x[1640]   c478_1    1
    x[1640]   c693_1    -1
    x[1640]   c758_1    -1
    x[1640]   c1058     -1
    x[1640]   c1258     -1
    x[1640]   c1478     -1
    x[1640]   c1608     -1
    x[1640]   c1703     -1
    x[1640]   c9        1
    x[1640]   c202      -27
    x[1641]   c479_1    1
    x[1641]   c694_1    -1
    x[1641]   c759_1    -1
    x[1641]   c1059     -1
    x[1641]   c1259     -1
    x[1641]   c1479     -1
    x[1641]   c1609     -1
    x[1641]   c1704     -1
    x[1641]   c9        1
    x[1641]   c202      -36
    x[1642]   c480_1    1
    x[1642]   c695_1    -1
    x[1642]   c760_1    -1
    x[1642]   c1060     -1
    x[1642]   c1260     -1
    x[1642]   c1480     -1
    x[1642]   c1610     -1
    x[1642]   c1705     -1
    x[1642]   c9        1
    x[1642]   c202      -45
    x[1643]   c476_1    1
    x[1643]   c501_1    -1
    x[1643]   c586_1    -1
    x[1643]   c926_1    -1
    x[1643]   c1221     -1
    x[1643]   c1276     -1
    x[1643]   c1351     -1
    x[1643]   c1456     -1
    x[1643]   c1486     -1
    x[1643]   c1536     -1
    x[1643]   c1596     -1
    x[1643]   c1786     -1
    x[1643]   c1896     -1
    x[1643]   c10       1
    x[1643]   c137      -1
    x[1643]   c202      -10
    x[1643]   c609      1
    x[1643]   c611      1
    x[1644]   c477_1    1
    x[1644]   c502_1    -1
    x[1644]   c587_1    -1
    x[1644]   c927_1    -1
    x[1644]   c1222     -1
    x[1644]   c1277     -1
    x[1644]   c1352     -1
    x[1644]   c1457     -1
    x[1644]   c1487     -1
    x[1644]   c1537     -1
    x[1644]   c1597     -1
    x[1644]   c1787     -1
    x[1644]   c1897     -1
    x[1644]   c10       1
    x[1644]   c138      -1
    x[1644]   c202      -20
    x[1644]   c613      1
    x[1644]   c615      1
    x[1645]   c478_1    1
    x[1645]   c503_1    -1
    x[1645]   c588_1    -1
    x[1645]   c928_1    -1
    x[1645]   c1223     -1
    x[1645]   c1278     -1
    x[1645]   c1353     -1
    x[1645]   c1458     -1
    x[1645]   c1488     -1
    x[1645]   c1538     -1
    x[1645]   c1598     -1
    x[1645]   c1788     -1
    x[1645]   c1898     -1
    x[1645]   c10       1
    x[1645]   c139      -1
    x[1645]   c202      -30
    x[1645]   c617      1
    x[1645]   c619      1
    x[1646]   c479_1    1
    x[1646]   c504_1    -1
    x[1646]   c589_1    -1
    x[1646]   c929_1    -1
    x[1646]   c1224     -1
    x[1646]   c1279     -1
    x[1646]   c1354     -1
    x[1646]   c1459     -1
    x[1646]   c1489     -1
    x[1646]   c1539     -1
    x[1646]   c1599     -1
    x[1646]   c1789     -1
    x[1646]   c1899     -1
    x[1646]   c10       1
    x[1646]   c140      -1
    x[1646]   c202      -40
    x[1646]   c621      1
    x[1646]   c623      1
    x[1647]   c480_1    1
    x[1647]   c505_1    -1
    x[1647]   c590_1    -1
    x[1647]   c930_1    -1
    x[1647]   c1225     -1
    x[1647]   c1280     -1
    x[1647]   c1355     -1
    x[1647]   c1460     -1
    x[1647]   c1490     -1
    x[1647]   c1540     -1
    x[1647]   c1600     -1
    x[1647]   c1790     -1
    x[1647]   c1900     -1
    x[1647]   c10       1
    x[1647]   c141      -1
    x[1647]   c202      -50
    x[1647]   c625      1
    x[1647]   c627      1
    x[1648]   c476_1    1
    x[1648]   c696_1    -1
    x[1648]   c781_1    -1
    x[1648]   c931_1    -1
    x[1648]   c1226     -1
    x[1648]   c1296     -1
    x[1648]   c1371     -1
    x[1648]   c1491     -1
    x[1648]   c1526     -1
    x[1648]   c1541     -1
    x[1648]   c1791     -1
    x[1648]   c11       1
    x[1648]   c97       -1
    x[1648]   c202      -11
    x[1648]   c672      1
    x[1648]   c674      1
    x[1649]   c477_1    1
    x[1649]   c697_1    -1
    x[1649]   c782_1    -1
    x[1649]   c932_1    -1
    x[1649]   c1227     -1
    x[1649]   c1297     -1
    x[1649]   c1372     -1
    x[1649]   c1492     -1
    x[1649]   c1527     -1
    x[1649]   c1542     -1
    x[1649]   c1792     -1
    x[1649]   c11       1
    x[1649]   c98       -1
    x[1649]   c202      -22
    x[1649]   c676      1
    x[1649]   c678      1
    x[1649]   c680      1
    x[1650]   c478_1    1
    x[1650]   c698_1    -1
    x[1650]   c783_1    -1
    x[1650]   c933_1    -1
    x[1650]   c1228     -1
    x[1650]   c1298     -1
    x[1650]   c1373     -1
    x[1650]   c1493     -1
    x[1650]   c1528     -1
    x[1650]   c1543     -1
    x[1650]   c1793     -1
    x[1650]   c11       1
    x[1650]   c99       -1
    x[1650]   c202      -33
    x[1650]   c682      1
    x[1650]   c684      1
    x[1651]   c479_1    1
    x[1651]   c699_1    -1
    x[1651]   c784_1    -1
    x[1651]   c934_1    -1
    x[1651]   c1229     -1
    x[1651]   c1299     -1
    x[1651]   c1374     -1
    x[1651]   c1494     -1
    x[1651]   c1529     -1
    x[1651]   c1544     -1
    x[1651]   c1794     -1
    x[1651]   c11       1
    x[1651]   c100      -1
    x[1651]   c202      -44
    x[1651]   c686      1
    x[1651]   c688      1
    x[1652]   c480_1    1
    x[1652]   c700_1    -1
    x[1652]   c785_1    -1
    x[1652]   c935_1    -1
    x[1652]   c1230     -1
    x[1652]   c1300     -1
    x[1652]   c1375     -1
    x[1652]   c1495     -1
    x[1652]   c1530     -1
    x[1652]   c1545     -1
    x[1652]   c1795     -1
    x[1652]   c11       1
    x[1652]   c101      -1
    x[1652]   c202      -55
    x[1652]   c690      1
    x[1652]   c692      1
    x[1653]   c476_1    1
    x[1653]   c571_1    -1
    x[1653]   c621_1    -1
    x[1653]   c666_1    -1
    x[1653]   c761_1    -1
    x[1653]   c826_1    -1
    x[1653]   c976      -1
    x[1653]   c1341     -1
    x[1653]   c1836     -1
    x[1653]   c12       1
    x[1653]   c202      -12
    x[1654]   c477_1    1
    x[1654]   c572_1    -1
    x[1654]   c622_1    -1
    x[1654]   c667_1    -1
    x[1654]   c762_1    -1
    x[1654]   c827_1    -1
    x[1654]   c977      -1
    x[1654]   c1342     -1
    x[1654]   c1837     -1
    x[1654]   c12       1
    x[1654]   c202      -24
    x[1655]   c478_1    1
    x[1655]   c573_1    -1
    x[1655]   c623_1    -1
    x[1655]   c668_1    -1
    x[1655]   c763_1    -1
    x[1655]   c828_1    -1
    x[1655]   c978      -1
    x[1655]   c1343     -1
    x[1655]   c1838     -1
    x[1655]   c12       1
    x[1655]   c202      -36
    x[1656]   c479_1    1
    x[1656]   c574_1    -1
    x[1656]   c624_1    -1
    x[1656]   c669_1    -1
    x[1656]   c764_1    -1
    x[1656]   c829_1    -1
    x[1656]   c979      -1
    x[1656]   c1344     -1
    x[1656]   c1839     -1
    x[1656]   c12       1
    x[1656]   c202      -48
    x[1656]   c840      -1
    x[1656]   c888      -1
    x[1656]   c901      -1
    x[1656]   c920      -1
    x[1656]   c934      -1
    x[1657]   c480_1    1
    x[1657]   c575_1    -1
    x[1657]   c625_1    -1
    x[1657]   c670_1    -1
    x[1657]   c765_1    -1
    x[1657]   c830_1    -1
    x[1657]   c980      -1
    x[1657]   c1345     -1
    x[1657]   c1840     -1
    x[1657]   c12       1
    x[1657]   c202      -60
    x[1657]   c841      -1
    x[1657]   c843      -1
    x[1657]   c889      -1
    x[1657]   c902      -1
    x[1657]   c921      -1
    x[1657]   c935      -1
    x[1658]   c476_1    1
    x[1658]   c876_1    -1
    x[1658]   c936_1    -1
    x[1658]   c1426     -1
    x[1658]   c1906     1
    x[1658]   c1907     1
    x[1658]   c1908     1
    x[1658]   c1909     1
    x[1658]   c13       1
    x[1658]   c202      -13
    x[1659]   c477_1    1
    x[1659]   c877_1    -1
    x[1659]   c937_1    -1
    x[1659]   c1427     -1
    x[1659]   c1906     1
    x[1659]   c13       1
    x[1659]   c202      -26
    x[1660]   c478_1    1
    x[1660]   c878_1    -1
    x[1660]   c938_1    -1
    x[1660]   c1428     -1
    x[1660]   c1907     1
    x[1660]   c13       1
    x[1660]   c202      -39
    x[1661]   c479_1    1
    x[1661]   c879_1    -1
    x[1661]   c939_1    -1
    x[1661]   c1429     -1
    x[1661]   c1908     1
    x[1661]   c13       1
    x[1661]   c202      -52
    x[1662]   c480_1    1
    x[1662]   c880_1    -1
    x[1662]   c940_1    -1
    x[1662]   c1430     -1
    x[1662]   c1909     1
    x[1662]   c13       1
    x[1662]   c202      -65
    x[1663]   c476_1    1
    x[1663]   c861_1    -1
    x[1663]   c1011     -1
    x[1663]   c1181     -1
    x[1663]   c1431     -1
    x[1663]   c1496     -1
    x[1663]   c1910     1
    x[1663]   c1911     1
    x[1663]   c1912     1
    x[1663]   c1913     1
    x[1663]   c14       1
    x[1663]   c37       -1
    x[1663]   c182      -1
    x[1663]   c202      -14
    x[1663]   c772      1
    x[1663]   c773      1
    x[1663]   c778      1
    x[1663]   c779      1
    x[1664]   c477_1    1
    x[1664]   c862_1    -1
    x[1664]   c1012     -1
    x[1664]   c1182     -1
    x[1664]   c1432     -1
    x[1664]   c1497     -1
    x[1664]   c1910     1
    x[1664]   c14       1
    x[1664]   c38       -1
    x[1664]   c183      -1
    x[1664]   c202      -28
    x[1664]   c781      1
    x[1664]   c782      1
    x[1664]   c787      1
    x[1664]   c789      1
    x[1664]   c790      1
    x[1665]   c478_1    1
    x[1665]   c863_1    -1
    x[1665]   c1013     -1
    x[1665]   c1183     -1
    x[1665]   c1433     -1
    x[1665]   c1498     -1
    x[1665]   c1911     1
    x[1665]   c14       1
    x[1665]   c39       -1
    x[1665]   c184      -1
    x[1665]   c202      -42
    x[1665]   c792      1
    x[1665]   c793      1
    x[1665]   c795      1
    x[1665]   c796      1
    x[1666]   c479_1    1
    x[1666]   c864_1    -1
    x[1666]   c1014     -1
    x[1666]   c1184     -1
    x[1666]   c1434     -1
    x[1666]   c1499     -1
    x[1666]   c1912     1
    x[1666]   c14       1
    x[1666]   c40       -1
    x[1666]   c185      -1
    x[1666]   c202      -56
    x[1666]   c798      1
    x[1666]   c799      1
    x[1666]   c801      1
    x[1666]   c802      1
    x[1667]   c480_1    1
    x[1667]   c865_1    -1
    x[1667]   c1015     -1
    x[1667]   c1185     -1
    x[1667]   c1435     -1
    x[1667]   c1500     -1
    x[1667]   c1913     1
    x[1667]   c14       1
    x[1667]   c41       -1
    x[1667]   c186      -1
    x[1667]   c202      -70
    x[1667]   c804      1
    x[1667]   c805      1
    x[1667]   c807      1
    x[1667]   c808      1
    x[1668]   c476_1    1
    x[1668]   c866_1    -1
    x[1668]   c961      -1
    x[1668]   c1914     1
    x[1668]   c1915     1
    x[1668]   c15       1
    x[1668]   c202      -15
    x[1669]   c477_1    1
    x[1669]   c867_1    -1
    x[1669]   c962      -1
    x[1669]   c1916     1
    x[1669]   c15       1
    x[1669]   c202      -30
    x[1670]   c478_1    1
    x[1670]   c868_1    -1
    x[1670]   c963      -1
    x[1670]   c1916     1
    x[1670]   c15       1
    x[1670]   c202      -45
    x[1671]   c479_1    1
    x[1671]   c869_1    -1
    x[1671]   c964      -1
    x[1671]   c1914     1
    x[1671]   c15       1
    x[1671]   c202      -60
    x[1672]   c480_1    1
    x[1672]   c870_1    -1
    x[1672]   c965      -1
    x[1672]   c1915     1
    x[1672]   c15       1
    x[1672]   c202      -75
    x[1673]   c476_1    1
    x[1673]   c566_1    -1
    x[1673]   c591_1    -1
    x[1673]   c626_1    -1
    x[1673]   c726_1    -1
    x[1673]   c1081     -1
    x[1673]   c1161     -1
    x[1673]   c1301     -1
    x[1673]   c1416     -1
    x[1673]   c1766     -1
    x[1673]   c1821     -1
    x[1673]   c1881     -1
    x[1673]   c1917     1
    x[1673]   c1918     1
    x[1673]   c1919     1
    x[1673]   c1920     1
    x[1673]   c16       1
    x[1673]   c57       -1
    x[1673]   c202      -16
    x[1673]   c891      1
    x[1673]   c896      1
    x[1673]   c898      1
    x[1674]   c477_1    1
    x[1674]   c567_1    -1
    x[1674]   c592_1    -1
    x[1674]   c627_1    -1
    x[1674]   c727_1    -1
    x[1674]   c1082     -1
    x[1674]   c1162     -1
    x[1674]   c1302     -1
    x[1674]   c1417     -1
    x[1674]   c1767     -1
    x[1674]   c1822     -1
    x[1674]   c1882     -1
    x[1674]   c1917     1
    x[1674]   c16       1
    x[1674]   c58       -1
    x[1674]   c202      -32
    x[1674]   c900      1
    x[1674]   c905      1
    x[1675]   c478_1    1
    x[1675]   c568_1    -1
    x[1675]   c593_1    -1
    x[1675]   c628_1    -1
    x[1675]   c728_1    -1
    x[1675]   c1083     -1
    x[1675]   c1163     -1
    x[1675]   c1303     -1
    x[1675]   c1418     -1
    x[1675]   c1768     -1
    x[1675]   c1823     -1
    x[1675]   c1883     -1
    x[1675]   c1918     1
    x[1675]   c16       1
    x[1675]   c59       -1
    x[1675]   c202      -48
    x[1675]   c907      1
    x[1675]   c909      1
    x[1676]   c479_1    1
    x[1676]   c569_1    -1
    x[1676]   c594_1    -1
    x[1676]   c629_1    -1
    x[1676]   c729_1    -1
    x[1676]   c1084     -1
    x[1676]   c1164     -1
    x[1676]   c1304     -1
    x[1676]   c1419     -1
    x[1676]   c1769     -1
    x[1676]   c1824     -1
    x[1676]   c1884     -1
    x[1676]   c1919     1
    x[1676]   c16       1
    x[1676]   c60       -1
    x[1676]   c202      -64
    x[1676]   c911      1
    x[1676]   c913      1
    x[1677]   c480_1    1
    x[1677]   c570_1    -1
    x[1677]   c595_1    -1
    x[1677]   c630_1    -1
    x[1677]   c730_1    -1
    x[1677]   c1085     -1
    x[1677]   c1165     -1
    x[1677]   c1305     -1
    x[1677]   c1420     -1
    x[1677]   c1770     -1
    x[1677]   c1825     -1
    x[1677]   c1885     -1
    x[1677]   c1920     1
    x[1677]   c16       1
    x[1677]   c61       -1
    x[1677]   c202      -80
    x[1677]   c915      1
    x[1677]   c917      1
    x[1678]   c476_1    1
    x[1678]   c881_1    -1
    x[1678]   c1381     -1
    x[1678]   c1421     -1
    x[1678]   c1826     -1
    x[1678]   c1921     1
    x[1678]   c1922     1
    x[1678]   c1923     1
    x[1678]   c17       1
    x[1678]   c62       -1
    x[1678]   c202      -17
    x[1678]   c923      1
    x[1678]   c927      1
    x[1679]   c477_1    1
    x[1679]   c882_1    -1
    x[1679]   c1382     -1
    x[1679]   c1422     -1
    x[1679]   c1827     -1
    x[1679]   c1921     1
    x[1679]   c17       1
    x[1679]   c63       -1
    x[1679]   c202      -34
    x[1679]   c929      1
    x[1679]   c931      1
    x[1680]   c478_1    1
    x[1680]   c883_1    -1
    x[1680]   c1383     -1
    x[1680]   c1423     -1
    x[1680]   c1828     -1
    x[1680]   c17       1
    x[1680]   c64       -1
    x[1680]   c202      -51
    x[1680]   c933      1
    x[1680]   c937      1
    x[1681]   c479_1    1
    x[1681]   c884_1    -1
    x[1681]   c1384     -1
    x[1681]   c1424     -1
    x[1681]   c1829     -1
    x[1681]   c1922     1
    x[1681]   c17       1
    x[1681]   c65       -1
    x[1681]   c202      -68
    x[1681]   c939      1
    x[1681]   c941      1
    x[1682]   c480_1    1
    x[1682]   c885_1    -1
    x[1682]   c1385     -1
    x[1682]   c1425     -1
    x[1682]   c1830     -1
    x[1682]   c1923     1
    x[1682]   c17       1
    x[1682]   c66       -1
    x[1682]   c202      -85
    x[1682]   c943      1
    x[1682]   c945      1
    x[1683]   c476_1    1
    x[1683]   c711_1    -1
    x[1683]   c821_1    -1
    x[1683]   c981      -1
    x[1683]   c1686     -1
    x[1683]   c1796     -1
    x[1683]   c18       1
    x[1683]   c102      -1
    x[1683]   c167      -1
    x[1683]   c202      -18
    x[1683]   c248      1
    x[1683]   c249      1
    x[1683]   c251      1
    x[1683]   c253      1
    x[1683]   c254      1
    x[1684]   c477_1    1
    x[1684]   c712_1    -1
    x[1684]   c822_1    -1
    x[1684]   c982      -1
    x[1684]   c1687     -1
    x[1684]   c1797     -1
    x[1684]   c18       1
    x[1684]   c103      -1
    x[1684]   c168      -1
    x[1684]   c202      -36
    x[1684]   c256      1
    x[1684]   c257      1
    x[1684]   c259      1
    x[1684]   c260      1
    x[1685]   c478_1    1
    x[1685]   c713_1    -1
    x[1685]   c823_1    -1
    x[1685]   c983      -1
    x[1685]   c1688     -1
    x[1685]   c1798     -1
    x[1685]   c18       1
    x[1685]   c104      -1
    x[1685]   c169      -1
    x[1685]   c202      -54
    x[1685]   c262      1
    x[1685]   c263      1
    x[1685]   c265      1
    x[1685]   c267      1
    x[1685]   c268      1
    x[1686]   c479_1    1
    x[1686]   c714_1    -1
    x[1686]   c824_1    -1
    x[1686]   c984      -1
    x[1686]   c1689     -1
    x[1686]   c1799     -1
    x[1686]   c18       1
    x[1686]   c105      -1
    x[1686]   c170      -1
    x[1686]   c202      -72
    x[1686]   c270      1
    x[1686]   c271      1
    x[1686]   c273      1
    x[1686]   c274      1
    x[1687]   c480_1    1
    x[1687]   c715_1    -1
    x[1687]   c825_1    -1
    x[1687]   c985      -1
    x[1687]   c1690     -1
    x[1687]   c1800     -1
    x[1687]   c18       1
    x[1687]   c106      -1
    x[1687]   c171      -1
    x[1687]   c202      -90
    x[1687]   c276      1
    x[1687]   c277      1
    x[1687]   c279      1
    x[1687]   c280      1
    x[1688]   c476_1    1
    x[1688]   c716_1    -1
    x[1688]   c1086     -1
    x[1688]   c1441     -1
    x[1688]   c1611     -1
    x[1688]   c1741     -1
    x[1688]   c19       1
    x[1688]   c77       -1
    x[1688]   c202      -19
    x[1688]   c325      1
    x[1688]   c327      1
    x[1689]   c477_1    1
    x[1689]   c717_1    -1
    x[1689]   c1087     -1
    x[1689]   c1442     -1
    x[1689]   c1612     -1
    x[1689]   c1742     -1
    x[1689]   c19       1
    x[1689]   c78       -1
    x[1689]   c202      -38
    x[1689]   c329      1
    x[1689]   c331      1
    x[1690]   c478_1    1
    x[1690]   c718_1    -1
    x[1690]   c1088     -1
    x[1690]   c1443     -1
    x[1690]   c1613     -1
    x[1690]   c1743     -1
    x[1690]   c19       1
    x[1690]   c79       -1
    x[1690]   c202      -57
    x[1690]   c333      1
    x[1690]   c335      1
    x[1691]   c479_1    1
    x[1691]   c719_1    -1
    x[1691]   c1089     -1
    x[1691]   c1444     -1
    x[1691]   c1614     -1
    x[1691]   c1744     -1
    x[1691]   c19       1
    x[1691]   c80       -1
    x[1691]   c202      -76
    x[1691]   c337      1
    x[1691]   c339      1
    x[1692]   c480_1    1
    x[1692]   c720_1    -1
    x[1692]   c1090     -1
    x[1692]   c1445     -1
    x[1692]   c1615     -1
    x[1692]   c1745     -1
    x[1692]   c19       1
    x[1692]   c81       -1
    x[1692]   c202      -95
    x[1692]   c341      1
    x[1692]   c343      1
    x[1693]   c476_1    1
    x[1693]   c731_1    -1
    x[1693]   c746_1    -1
    x[1693]   c786_1    -1
    x[1693]   c831_1    -1
    x[1693]   c886_1    -1
    x[1693]   c986      -1
    x[1693]   c1166     -1
    x[1693]   c1231     -1
    x[1693]   c1346     -1
    x[1693]   c1356     -1
    x[1693]   c1376     -1
    x[1693]   c1646     -1
    x[1693]   c20       1
    x[1693]   c82       -1
    x[1693]   c142      -1
    x[1693]   c187      -1
    x[1693]   c202      -20
    x[1693]   c365      1
    x[1693]   c366      1
    x[1693]   c367      1
    x[1693]   c369      1
    x[1693]   c370      1
    x[1693]   c371      1
    x[1694]   c477_1    1
    x[1694]   c732_1    -1
    x[1694]   c747_1    -1
    x[1694]   c787_1    -1
    x[1694]   c832_1    -1
    x[1694]   c887_1    -1
    x[1694]   c987      -1
    x[1694]   c1167     -1
    x[1694]   c1232     -1
    x[1694]   c1347     -1
    x[1694]   c1357     -1
    x[1694]   c1377     -1
    x[1694]   c1647     -1
    x[1694]   c20       1
    x[1694]   c83       -1
    x[1694]   c143      -1
    x[1694]   c188      -1
    x[1694]   c202      -40
    x[1694]   c373      1
    x[1694]   c374      1
    x[1694]   c375      1
    x[1694]   c377      1
    x[1694]   c378      1
    x[1694]   c379      1
    x[1695]   c478_1    1
    x[1695]   c733_1    -1
    x[1695]   c748_1    -1
    x[1695]   c788_1    -1
    x[1695]   c833_1    -1
    x[1695]   c888_1    -1
    x[1695]   c988      -1
    x[1695]   c1168     -1
    x[1695]   c1233     -1
    x[1695]   c1348     -1
    x[1695]   c1358     -1
    x[1695]   c1378     -1
    x[1695]   c1648     -1
    x[1695]   c20       1
    x[1695]   c84       -1
    x[1695]   c144      -1
    x[1695]   c189      -1
    x[1695]   c202      -60
    x[1695]   c381      1
    x[1695]   c382      1
    x[1695]   c383      1
    x[1695]   c385      1
    x[1695]   c386      1
    x[1695]   c387      1
    x[1696]   c479_1    1
    x[1696]   c734_1    -1
    x[1696]   c749_1    -1
    x[1696]   c789_1    -1
    x[1696]   c834_1    -1
    x[1696]   c889_1    -1
    x[1696]   c989      -1
    x[1696]   c1169     -1
    x[1696]   c1234     -1
    x[1696]   c1349     -1
    x[1696]   c1359     -1
    x[1696]   c1379     -1
    x[1696]   c1649     -1
    x[1696]   c20       1
    x[1696]   c85       -1
    x[1696]   c145      -1
    x[1696]   c190      -1
    x[1696]   c202      -80
    x[1696]   c389      1
    x[1696]   c390      1
    x[1696]   c391      1
    x[1696]   c393      1
    x[1696]   c394      1
    x[1696]   c395      1
    x[1697]   c480_1    1
    x[1697]   c735_1    -1
    x[1697]   c750_1    -1
    x[1697]   c790_1    -1
    x[1697]   c835_1    -1
    x[1697]   c890_1    -1
    x[1697]   c990      -1
    x[1697]   c1170     -1
    x[1697]   c1235     -1
    x[1697]   c1350     -1
    x[1697]   c1360     -1
    x[1697]   c1380     -1
    x[1697]   c1650     -1
    x[1697]   c20       1
    x[1697]   c86       -1
    x[1697]   c146      -1
    x[1697]   c191      -1
    x[1697]   c202      -100
    x[1697]   c397      1
    x[1697]   c398      1
    x[1697]   c399      1
    x[1697]   c401      1
    x[1697]   c402      1
    x[1697]   c403      1
    x[1698]   c476_1    1
    x[1698]   c576_1    -1
    x[1698]   c681_1    -1
    x[1698]   c701_1    -1
    x[1698]   c1031     -1
    x[1698]   c1361     -1
    x[1698]   c1446     -1
    x[1698]   c1601     -1
    x[1698]   c1851     -1
    x[1698]   c21       1
    x[1698]   c107      -1
    x[1698]   c202      -21
    x[1698]   c426      1
    x[1698]   c428      1
    x[1698]   c430      1
    x[1699]   c477_1    1
    x[1699]   c577_1    -1
    x[1699]   c682_1    -1
    x[1699]   c702_1    -1
    x[1699]   c1032     -1
    x[1699]   c1362     -1
    x[1699]   c1447     -1
    x[1699]   c1602     -1
    x[1699]   c1852     -1
    x[1699]   c21       1
    x[1699]   c108      -1
    x[1699]   c202      -42
    x[1699]   c432      1
    x[1699]   c434      1
    x[1700]   c478_1    1
    x[1700]   c578_1    -1
    x[1700]   c683_1    -1
    x[1700]   c703_1    -1
    x[1700]   c1033     -1
    x[1700]   c1363     -1
    x[1700]   c1448     -1
    x[1700]   c1603     -1
    x[1700]   c1853     -1
    x[1700]   c21       1
    x[1700]   c109      -1
    x[1700]   c202      -63
    x[1700]   c436      1
    x[1700]   c438      1
    x[1701]   c479_1    1
    x[1701]   c579_1    -1
    x[1701]   c684_1    -1
    x[1701]   c704_1    -1
    x[1701]   c1034     -1
    x[1701]   c1364     -1
    x[1701]   c1449     -1
    x[1701]   c1604     -1
    x[1701]   c1854     -1
    x[1701]   c21       1
    x[1701]   c110      -1
    x[1701]   c202      -84
    x[1701]   c440      1
    x[1701]   c442      1
    x[1702]   c480_1    1
    x[1702]   c580_1    -1
    x[1702]   c685_1    -1
    x[1702]   c705_1    -1
    x[1702]   c1035     -1
    x[1702]   c1365     -1
    x[1702]   c1450     -1
    x[1702]   c1605     -1
    x[1702]   c1855     -1
    x[1702]   c21       1
    x[1702]   c111      -1
    x[1702]   c202      -105
    x[1702]   c444      1
    x[1702]   c446      1
    x[1703]   c476_1    1
    x[1703]   c671_1    -1
    x[1703]   c941_1    -1
    x[1703]   c966      -1
    x[1703]   c1321     -1
    x[1703]   c22       1
    x[1703]   c47       -1
    x[1703]   c202      -22
    x[1703]   c478      1
    x[1703]   c480      1
    x[1704]   c477_1    1
    x[1704]   c672_1    -1
    x[1704]   c942_1    -1
    x[1704]   c967      -1
    x[1704]   c1322     -1
    x[1704]   c22       1
    x[1704]   c48       -1
    x[1704]   c202      -44
    x[1704]   c482      1
    x[1704]   c484      1
    x[1705]   c478_1    1
    x[1705]   c673_1    -1
    x[1705]   c943_1    -1
    x[1705]   c968      -1
    x[1705]   c1323     -1
    x[1705]   c22       1
    x[1705]   c49       -1
    x[1705]   c202      -66
    x[1705]   c486      1
    x[1705]   c488      1
    x[1706]   c479_1    1
    x[1706]   c674_1    -1
    x[1706]   c944_1    -1
    x[1706]   c969      -1
    x[1706]   c1324     -1
    x[1706]   c22       1
    x[1706]   c50       -1
    x[1706]   c202      -88
    x[1706]   c490      1
    x[1706]   c492      1
    x[1707]   c480_1    1
    x[1707]   c675_1    -1
    x[1707]   c945_1    -1
    x[1707]   c970      -1
    x[1707]   c1325     -1
    x[1707]   c22       1
    x[1707]   c51       -1
    x[1707]   c202      -110
    x[1707]   c494      1
    x[1707]   c496      1
    x[1708]   c476_1    1
    x[1708]   c971      -1
    x[1708]   c1236     -1
    x[1708]   c1691     -1
    x[1708]   c23       1
    x[1708]   c202      -23
    x[1709]   c477_1    1
    x[1709]   c972      -1
    x[1709]   c1237     -1
    x[1709]   c1692     -1
    x[1709]   c23       1
    x[1709]   c202      -46
    x[1710]   c478_1    1
    x[1710]   c973      -1
    x[1710]   c1238     -1
    x[1710]   c1693     -1
    x[1710]   c23       1
    x[1710]   c202      -69
    x[1711]   c479_1    1
    x[1711]   c974      -1
    x[1711]   c1239     -1
    x[1711]   c1694     -1
    x[1711]   c23       1
    x[1711]   c202      -92
    x[1712]   c480_1    1
    x[1712]   c975      -1
    x[1712]   c1240     -1
    x[1712]   c1695     -1
    x[1712]   c23       1
    x[1712]   c202      -115
    x[1713]   c476_1    1
    x[1713]   c611_1    -1
    x[1713]   c806_1    -1
    x[1713]   c1016     -1
    x[1713]   c1041     -1
    x[1713]   c1076     -1
    x[1713]   c1106     -1
    x[1713]   c1116     -1
    x[1713]   c1131     -1
    x[1713]   c1326     -1
    x[1713]   c1386     -1
    x[1713]   c1436     -1
    x[1713]   c1671     -1
    x[1713]   c1706     -1
    x[1713]   c1746     -1
    x[1713]   c1841     -1
    x[1713]   c24       1
    x[1713]   c52       -1
    x[1713]   c202      -24
    x[1713]   c742      1
    x[1713]   c751      1
    x[1713]   c755      1
    x[1714]   c477_1    1
    x[1714]   c612_1    -1
    x[1714]   c807_1    -1
    x[1714]   c1017     -1
    x[1714]   c1042     -1
    x[1714]   c1077     -1
    x[1714]   c1107     -1
    x[1714]   c1117     -1
    x[1714]   c1132     -1
    x[1714]   c1327     -1
    x[1714]   c1387     -1
    x[1714]   c1437     -1
    x[1714]   c1672     -1
    x[1714]   c1707     -1
    x[1714]   c1747     -1
    x[1714]   c1842     -1
    x[1714]   c24       1
    x[1714]   c53       -1
    x[1714]   c202      -48
    x[1714]   c810      1
    x[1714]   c819      1
    x[1714]   c823      1
    x[1715]   c478_1    1
    x[1715]   c613_1    -1
    x[1715]   c808_1    -1
    x[1715]   c1018     -1
    x[1715]   c1043     -1
    x[1715]   c1078     -1
    x[1715]   c1108     -1
    x[1715]   c1118     -1
    x[1715]   c1133     -1
    x[1715]   c1328     -1
    x[1715]   c1388     -1
    x[1715]   c1438     -1
    x[1715]   c1673     -1
    x[1715]   c1708     -1
    x[1715]   c1748     -1
    x[1715]   c1843     -1
    x[1715]   c24       1
    x[1715]   c54       -1
    x[1715]   c202      -72
    x[1715]   c859      1
    x[1715]   c868      1
    x[1715]   c872      1
    x[1716]   c479_1    1
    x[1716]   c614_1    -1
    x[1716]   c809_1    -1
    x[1716]   c1019     -1
    x[1716]   c1044     -1
    x[1716]   c1079     -1
    x[1716]   c1109     -1
    x[1716]   c1119     -1
    x[1716]   c1134     -1
    x[1716]   c1329     -1
    x[1716]   c1389     -1
    x[1716]   c1439     -1
    x[1716]   c1674     -1
    x[1716]   c1709     -1
    x[1716]   c1749     -1
    x[1716]   c1844     -1
    x[1716]   c24       1
    x[1716]   c55       -1
    x[1716]   c202      -96
    x[1716]   c727      -1
    x[1716]   c744      -1
    x[1716]   c749      -1
    x[1716]   c753      -1
    x[1716]   c758      -1
    x[1716]   c784      -1
    x[1716]   c812      -1
    x[1716]   c815      -1
    x[1716]   c821      -1
    x[1716]   c826      -1
    x[1716]   c851      -1
    x[1716]   c861      -1
    x[1716]   c866      -1
    x[1716]   c870      -1
    x[1716]   c875      -1
    x[1717]   c480_1    1
    x[1717]   c615_1    -1
    x[1717]   c810_1    -1
    x[1717]   c1020     -1
    x[1717]   c1045     -1
    x[1717]   c1080     -1
    x[1717]   c1110     -1
    x[1717]   c1120     -1
    x[1717]   c1135     -1
    x[1717]   c1330     -1
    x[1717]   c1390     -1
    x[1717]   c1440     -1
    x[1717]   c1675     -1
    x[1717]   c1710     -1
    x[1717]   c1750     -1
    x[1717]   c1845     -1
    x[1717]   c24       1
    x[1717]   c56       -1
    x[1717]   c202      -120
    x[1717]   c728      -1
    x[1717]   c745      -1
    x[1717]   c750      -1
    x[1717]   c754      -1
    x[1717]   c759      -1
    x[1717]   c785      -1
    x[1717]   c813      -1
    x[1717]   c816      -1
    x[1717]   c822      -1
    x[1717]   c827      -1
    x[1717]   c852      -1
    x[1717]   c862      -1
    x[1717]   c867      -1
    x[1717]   c871      -1
    x[1717]   c876      -1
    x[1718]   c476_1    1
    x[1718]   c516_1    -1
    x[1718]   c581_1    -1
    x[1718]   c836_1    -1
    x[1718]   c1061     -1
    x[1718]   c1206     -1
    x[1718]   c1311     -1
    x[1718]   c1391     -1
    x[1718]   c1406     -1
    x[1718]   c1461     -1
    x[1718]   c1621     -1
    x[1718]   c1751     -1
    x[1718]   c1886     -1
    x[1718]   c25       1
    x[1718]   c152      -1
    x[1718]   c202      -25
    x[1718]   c528      1
    x[1718]   c530      1
    x[1719]   c477_1    1
    x[1719]   c517_1    -1
    x[1719]   c582_1    -1
    x[1719]   c837_1    -1
    x[1719]   c1062     -1
    x[1719]   c1207     -1
    x[1719]   c1312     -1
    x[1719]   c1392     -1
    x[1719]   c1407     -1
    x[1719]   c1462     -1
    x[1719]   c1622     -1
    x[1719]   c1752     -1
    x[1719]   c1887     -1
    x[1719]   c25       1
    x[1719]   c153      -1
    x[1719]   c202      -50
    x[1719]   c532      1
    x[1719]   c534      1
    x[1720]   c478_1    1
    x[1720]   c518_1    -1
    x[1720]   c583_1    -1
    x[1720]   c838_1    -1
    x[1720]   c1063     -1
    x[1720]   c1208     -1
    x[1720]   c1313     -1
    x[1720]   c1393     -1
    x[1720]   c1408     -1
    x[1720]   c1463     -1
    x[1720]   c1623     -1
    x[1720]   c1753     -1
    x[1720]   c1888     -1
    x[1720]   c25       1
    x[1720]   c154      -1
    x[1720]   c202      -75
    x[1720]   c536      1
    x[1720]   c538      1
    x[1721]   c479_1    1
    x[1721]   c519_1    -1
    x[1721]   c584_1    -1
    x[1721]   c839_1    -1
    x[1721]   c1064     -1
    x[1721]   c1209     -1
    x[1721]   c1314     -1
    x[1721]   c1394     -1
    x[1721]   c1409     -1
    x[1721]   c1464     -1
    x[1721]   c1624     -1
    x[1721]   c1754     -1
    x[1721]   c1889     -1
    x[1721]   c25       1
    x[1721]   c155      -1
    x[1721]   c202      -100
    x[1721]   c540      1
    x[1721]   c542      1
    x[1722]   c480_1    1
    x[1722]   c520_1    -1
    x[1722]   c585_1    -1
    x[1722]   c840_1    -1
    x[1722]   c1065     -1
    x[1722]   c1210     -1
    x[1722]   c1315     -1
    x[1722]   c1395     -1
    x[1722]   c1410     -1
    x[1722]   c1465     -1
    x[1722]   c1625     -1
    x[1722]   c1755     -1
    x[1722]   c1890     -1
    x[1722]   c25       1
    x[1722]   c156      -1
    x[1722]   c202      -125
    x[1722]   c544      1
    x[1722]   c546      1
    x[1723]   c476_1    1
    x[1723]   c551_1    -1
    x[1723]   c841_1    -1
    x[1723]   c891_1    -1
    x[1723]   c1091     -1
    x[1723]   c1136     -1
    x[1723]   c1316     -1
    x[1723]   c1331     -1
    x[1723]   c1856     -1
    x[1723]   c26       1
    x[1723]   c147      -1
    x[1723]   c202      -26
    x[1723]   c757      1
    x[1723]   c763      1
    x[1723]   c767      1
    x[1724]   c477_1    1
    x[1724]   c552_1    -1
    x[1724]   c842_1    -1
    x[1724]   c892_1    -1
    x[1724]   c1092     -1
    x[1724]   c1137     -1
    x[1724]   c1317     -1
    x[1724]   c1332     -1
    x[1724]   c1857     -1
    x[1724]   c26       1
    x[1724]   c148      -1
    x[1724]   c202      -52
    x[1724]   c825      1
    x[1724]   c831      1
    x[1724]   c835      1
    x[1725]   c478_1    1
    x[1725]   c553_1    -1
    x[1725]   c843_1    -1
    x[1725]   c893_1    -1
    x[1725]   c1093     -1
    x[1725]   c1138     -1
    x[1725]   c1318     -1
    x[1725]   c1333     -1
    x[1725]   c1858     -1
    x[1725]   c26       1
    x[1725]   c149      -1
    x[1725]   c202      -78
    x[1725]   c874      1
    x[1725]   c880      1
    x[1725]   c884      1
    x[1726]   c479_1    1
    x[1726]   c554_1    -1
    x[1726]   c844_1    -1
    x[1726]   c894_1    -1
    x[1726]   c1094     -1
    x[1726]   c1139     -1
    x[1726]   c1319     -1
    x[1726]   c1334     -1
    x[1726]   c1859     -1
    x[1726]   c26       1
    x[1726]   c150      -1
    x[1726]   c202      -104
    x[1726]   c746      -1
    x[1726]   c761      -1
    x[1726]   c765      -1
    x[1726]   c817      -1
    x[1726]   c829      -1
    x[1726]   c833      -1
    x[1726]   c863      -1
    x[1726]   c878      -1
    x[1726]   c882      -1
    x[1727]   c480_1    1
    x[1727]   c555_1    -1
    x[1727]   c845_1    -1
    x[1727]   c895_1    -1
    x[1727]   c1095     -1
    x[1727]   c1140     -1
    x[1727]   c1320     -1
    x[1727]   c1335     -1
    x[1727]   c1860     -1
    x[1727]   c26       1
    x[1727]   c151      -1
    x[1727]   c202      -130
    x[1727]   c747      -1
    x[1727]   c762      -1
    x[1727]   c766      -1
    x[1727]   c818      -1
    x[1727]   c830      -1
    x[1727]   c834      -1
    x[1727]   c864      -1
    x[1727]   c879      -1
    x[1727]   c883      -1
    x[1728]   c476_1    1
    x[1728]   c1626     -1
    x[1728]   c27       1
    x[1728]   c162      -1
    x[1728]   c202      -27
    x[1728]   c558      1
    x[1728]   c560      1
    x[1729]   c477_1    1
    x[1729]   c1627     -1
    x[1729]   c27       1
    x[1729]   c163      -1
    x[1729]   c202      -54
    x[1729]   c562      1
    x[1729]   c564      1
    x[1730]   c478_1    1
    x[1730]   c1628     -1
    x[1730]   c27       1
    x[1730]   c164      -1
    x[1730]   c202      -81
    x[1730]   c566      1
    x[1730]   c568      1
    x[1731]   c479_1    1
    x[1731]   c1629     -1
    x[1731]   c27       1
    x[1731]   c165      -1
    x[1731]   c202      -108
    x[1731]   c570      1
    x[1731]   c572      1
    x[1732]   c480_1    1
    x[1732]   c1630     -1
    x[1732]   c27       1
    x[1732]   c166      -1
    x[1732]   c202      -135
    x[1732]   c574      1
    x[1732]   c576      1
    x[1733]   c476_1    1
    x[1733]   c521_1    -1
    x[1733]   c896_1    -1
    x[1733]   c1191     -1
    x[1733]   c1466     -1
    x[1733]   c1616     -1
    x[1733]   c28       1
    x[1733]   c157      -1
    x[1733]   c202      -28
    x[1733]   c588      1
    x[1733]   c590      1
    x[1734]   c477_1    1
    x[1734]   c522_1    -1
    x[1734]   c897_1    -1
    x[1734]   c1192     -1
    x[1734]   c1467     -1
    x[1734]   c1617     -1
    x[1734]   c28       1
    x[1734]   c158      -1
    x[1734]   c202      -56
    x[1734]   c592      1
    x[1734]   c594      1
    x[1735]   c478_1    1
    x[1735]   c523_1    -1
    x[1735]   c898_1    -1
    x[1735]   c1193     -1
    x[1735]   c1468     -1
    x[1735]   c1618     -1
    x[1735]   c28       1
    x[1735]   c159      -1
    x[1735]   c202      -84
    x[1735]   c596      1
    x[1735]   c598      1
    x[1736]   c479_1    1
    x[1736]   c524_1    -1
    x[1736]   c899_1    -1
    x[1736]   c1194     -1
    x[1736]   c1469     -1
    x[1736]   c1619     -1
    x[1736]   c28       1
    x[1736]   c160      -1
    x[1736]   c202      -112
    x[1736]   c600      1
    x[1736]   c602      1
    x[1737]   c480_1    1
    x[1737]   c525_1    -1
    x[1737]   c900_1    -1
    x[1737]   c1195     -1
    x[1737]   c1470     -1
    x[1737]   c1620     -1
    x[1737]   c28       1
    x[1737]   c161      -1
    x[1737]   c202      -140
    x[1737]   c604      1
    x[1737]   c606      1
    x[1738]   c476_1    1
    x[1738]   c536_1    -1
    x[1738]   c596_1    -1
    x[1738]   c846_1    -1
    x[1738]   c1196     -1
    x[1738]   c1266     -1
    x[1738]   c1281     -1
    x[1738]   c1581     -1
    x[1738]   c1631     -1
    x[1738]   c1656     -1
    x[1738]   c1676     -1
    x[1738]   c1901     -1
    x[1738]   c29       1
    x[1738]   c32       -1
    x[1738]   c117      -1
    x[1738]   c192      -1
    x[1738]   c202      -29
    x[1738]   c629      1
    x[1738]   c630      1
    x[1738]   c631      1
    x[1738]   c633      1
    x[1738]   c635      1
    x[1738]   c636      1
    x[1738]   c637      1
    x[1739]   c477_1    1
    x[1739]   c537_1    -1
    x[1739]   c597_1    -1
    x[1739]   c847_1    -1
    x[1739]   c1197     -1
    x[1739]   c1267     -1
    x[1739]   c1282     -1
    x[1739]   c1582     -1
    x[1739]   c1632     -1
    x[1739]   c1657     -1
    x[1739]   c1677     -1
    x[1739]   c1902     -1
    x[1739]   c29       1
    x[1739]   c33       -1
    x[1739]   c118      -1
    x[1739]   c193      -1
    x[1739]   c202      -58
    x[1739]   c639      1
    x[1739]   c640      1
    x[1739]   c641      1
    x[1739]   c643      1
    x[1739]   c644      1
    x[1739]   c645      1
    x[1740]   c478_1    1
    x[1740]   c538_1    -1
    x[1740]   c598_1    -1
    x[1740]   c848_1    -1
    x[1740]   c1198     -1
    x[1740]   c1268     -1
    x[1740]   c1283     -1
    x[1740]   c1583     -1
    x[1740]   c1633     -1
    x[1740]   c1658     -1
    x[1740]   c1678     -1
    x[1740]   c1903     -1
    x[1740]   c29       1
    x[1740]   c34       -1
    x[1740]   c119      -1
    x[1740]   c194      -1
    x[1740]   c202      -87
    x[1740]   c647      1
    x[1740]   c648      1
    x[1740]   c649      1
    x[1740]   c651      1
    x[1740]   c652      1
    x[1740]   c653      1
    x[1741]   c479_1    1
    x[1741]   c539_1    -1
    x[1741]   c599_1    -1
    x[1741]   c849_1    -1
    x[1741]   c1199     -1
    x[1741]   c1269     -1
    x[1741]   c1284     -1
    x[1741]   c1584     -1
    x[1741]   c1634     -1
    x[1741]   c1659     -1
    x[1741]   c1679     -1
    x[1741]   c1904     -1
    x[1741]   c29       1
    x[1741]   c35       -1
    x[1741]   c120      -1
    x[1741]   c195      -1
    x[1741]   c202      -116
    x[1741]   c655      1
    x[1741]   c656      1
    x[1741]   c657      1
    x[1741]   c659      1
    x[1741]   c660      1
    x[1741]   c661      1
    x[1742]   c480_1    1
    x[1742]   c540_1    -1
    x[1742]   c600_1    -1
    x[1742]   c850_1    -1
    x[1742]   c1200     -1
    x[1742]   c1270     -1
    x[1742]   c1285     -1
    x[1742]   c1585     -1
    x[1742]   c1635     -1
    x[1742]   c1660     -1
    x[1742]   c1680     -1
    x[1742]   c1905     -1
    x[1742]   c29       1
    x[1742]   c36       -1
    x[1742]   c121      -1
    x[1742]   c196      -1
    x[1742]   c202      -145
    x[1742]   c663      1
    x[1742]   c664      1
    x[1742]   c665      1
    x[1742]   c667      1
    x[1742]   c668      1
    x[1742]   c669      1
    x[1743]   c476_1    1
    x[1743]   c506_1    -1
    x[1743]   c641_1    -1
    x[1743]   c686_1    -1
    x[1743]   c791_1    -1
    x[1743]   c851_1    -1
    x[1743]   c911_1    -1
    x[1743]   c1046     -1
    x[1743]   c1121     -1
    x[1743]   c1151     -1
    x[1743]   c1211     -1
    x[1743]   c1241     -1
    x[1743]   c1271     -1
    x[1743]   c1286     -1
    x[1743]   c1451     -1
    x[1743]   c1481     -1
    x[1743]   c1556     -1
    x[1743]   c1586     -1
    x[1743]   c1661     -1
    x[1743]   c1721     -1
    x[1743]   c1871     -1
    x[1743]   c30       1
    x[1743]   c42       -1
    x[1743]   c72       -1
    x[1743]   c202      -30
    x[1743]   c694      1
    x[1743]   c695      1
    x[1743]   c697      1
    x[1743]   c698      1
    x[1744]   c477_1    1
    x[1744]   c507_1    -1
    x[1744]   c642_1    -1
    x[1744]   c687_1    -1
    x[1744]   c792_1    -1
    x[1744]   c852_1    -1
    x[1744]   c912_1    -1
    x[1744]   c1047     -1
    x[1744]   c1122     -1
    x[1744]   c1152     -1
    x[1744]   c1212     -1
    x[1744]   c1242     -1
    x[1744]   c1272     -1
    x[1744]   c1287     -1
    x[1744]   c1452     -1
    x[1744]   c1482     -1
    x[1744]   c1557     -1
    x[1744]   c1587     -1
    x[1744]   c1662     -1
    x[1744]   c1722     -1
    x[1744]   c1872     -1
    x[1744]   c30       1
    x[1744]   c43       -1
    x[1744]   c73       -1
    x[1744]   c202      -60
    x[1744]   c700      1
    x[1744]   c701      1
    x[1744]   c703      1
    x[1744]   c704      1
    x[1745]   c478_1    1
    x[1745]   c508_1    -1
    x[1745]   c643_1    -1
    x[1745]   c688_1    -1
    x[1745]   c793_1    -1
    x[1745]   c853_1    -1
    x[1745]   c913_1    -1
    x[1745]   c1048     -1
    x[1745]   c1123     -1
    x[1745]   c1153     -1
    x[1745]   c1213     -1
    x[1745]   c1243     -1
    x[1745]   c1273     -1
    x[1745]   c1288     -1
    x[1745]   c1453     -1
    x[1745]   c1483     -1
    x[1745]   c1558     -1
    x[1745]   c1588     -1
    x[1745]   c1663     -1
    x[1745]   c1723     -1
    x[1745]   c1873     -1
    x[1745]   c30       1
    x[1745]   c44       -1
    x[1745]   c74       -1
    x[1745]   c202      -90
    x[1745]   c706      1
    x[1745]   c707      1
    x[1745]   c709      1
    x[1745]   c710      1
    x[1746]   c479_1    1
    x[1746]   c509_1    -1
    x[1746]   c644_1    -1
    x[1746]   c689_1    -1
    x[1746]   c794_1    -1
    x[1746]   c854_1    -1
    x[1746]   c914_1    -1
    x[1746]   c1049     -1
    x[1746]   c1124     -1
    x[1746]   c1154     -1
    x[1746]   c1214     -1
    x[1746]   c1244     -1
    x[1746]   c1274     -1
    x[1746]   c1289     -1
    x[1746]   c1454     -1
    x[1746]   c1484     -1
    x[1746]   c1559     -1
    x[1746]   c1589     -1
    x[1746]   c1664     -1
    x[1746]   c1724     -1
    x[1746]   c1874     -1
    x[1746]   c30       1
    x[1746]   c45       -1
    x[1746]   c75       -1
    x[1746]   c202      -120
    x[1746]   c712      1
    x[1746]   c713      1
    x[1746]   c715      1
    x[1746]   c716      1
    x[1747]   c480_1    1
    x[1747]   c510_1    -1
    x[1747]   c645_1    -1
    x[1747]   c690_1    -1
    x[1747]   c795_1    -1
    x[1747]   c855_1    -1
    x[1747]   c915_1    -1
    x[1747]   c1050     -1
    x[1747]   c1125     -1
    x[1747]   c1155     -1
    x[1747]   c1215     -1
    x[1747]   c1245     -1
    x[1747]   c1275     -1
    x[1747]   c1290     -1
    x[1747]   c1455     -1
    x[1747]   c1485     -1
    x[1747]   c1560     -1
    x[1747]   c1590     -1
    x[1747]   c1665     -1
    x[1747]   c1725     -1
    x[1747]   c1875     -1
    x[1747]   c30       1
    x[1747]   c46       -1
    x[1747]   c76       -1
    x[1747]   c202      -150
    x[1747]   c718      1
    x[1747]   c719      1
    x[1747]   c721      1
    x[1747]   c722      1
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1_1      1
    rhs       c2_1      1
    rhs       c3_1      1
    rhs       c4_1      1
    rhs       c5_1      1
    rhs       c6_1      1
    rhs       c7_1      1
    rhs       c8_1      1
    rhs       c9_1      1
    rhs       c10_1     1
    rhs       c11_1     1
    rhs       c12_1     1
    rhs       c13_1     1
    rhs       c14_1     1
    rhs       c15_1     1
    rhs       c16_1     1
    rhs       c17_1     1
    rhs       c18_1     1
    rhs       c19_1     1
    rhs       c20_1     1
    rhs       c21_1     1
    rhs       c22_1     1
    rhs       c23_1     1
    rhs       c24_1     1
    rhs       c25_1     1
    rhs       c26_1     1
    rhs       c27_1     1
    rhs       c28_1     1
    rhs       c29_1     1
    rhs       c30_1     1
    rhs       c31_1     1
    rhs       c32_1     1
    rhs       c33_1     1
    rhs       c34_1     1
    rhs       c35_1     1
    rhs       c36_1     1
    rhs       c37_1     1
    rhs       c38_1     1
    rhs       c39_1     1
    rhs       c40_1     1
    rhs       c41_1     1
    rhs       c42_1     1
    rhs       c43_1     1
    rhs       c44_1     1
    rhs       c45_1     1
    rhs       c46_1     1
    rhs       c47_1     1
    rhs       c48_1     1
    rhs       c49_1     1
    rhs       c50_1     1
    rhs       c51_1     1
    rhs       c52_1     1
    rhs       c53_1     1
    rhs       c54_1     1
    rhs       c55_1     1
    rhs       c56_1     1
    rhs       c57_1     1
    rhs       c58_1     1
    rhs       c59_1     1
    rhs       c60_1     1
    rhs       c61_1     1
    rhs       c62_1     1
    rhs       c63_1     1
    rhs       c64_1     1
    rhs       c65_1     1
    rhs       c66_1     1
    rhs       c67_1     1
    rhs       c68_1     1
    rhs       c69_1     1
    rhs       c70_1     1
    rhs       c71_1     1
    rhs       c72_1     1
    rhs       c73_1     1
    rhs       c74_1     1
    rhs       c75_1     1
    rhs       c76_1     1
    rhs       c77_1     1
    rhs       c78_1     1
    rhs       c79_1     1
    rhs       c80_1     1
    rhs       c81_1     1
    rhs       c82_1     1
    rhs       c83_1     1
    rhs       c84_1     1
    rhs       c85_1     1
    rhs       c86_1     1
    rhs       c87_1     1
    rhs       c88_1     1
    rhs       c89_1     1
    rhs       c90_1     1
    rhs       c91_1     1
    rhs       c92_1     1
    rhs       c93_1     1
    rhs       c94_1     1
    rhs       c95_1     1
    rhs       c96_1     1
    rhs       c97_1     1
    rhs       c98_1     1
    rhs       c99_1     1
    rhs       c100_1    1
    rhs       c101_1    1
    rhs       c102_1    1
    rhs       c103_1    1
    rhs       c104_1    1
    rhs       c105_1    1
    rhs       c106_1    1
    rhs       c107_1    1
    rhs       c108_1    1
    rhs       c109_1    1
    rhs       c110_1    1
    rhs       c111_1    1
    rhs       c112_1    1
    rhs       c113_1    1
    rhs       c114_1    1
    rhs       c115_1    1
    rhs       c116_1    1
    rhs       c117_1    1
    rhs       c118_1    1
    rhs       c119_1    1
    rhs       c120_1    1
    rhs       c121_1    1
    rhs       c122_1    1
    rhs       c123_1    1
    rhs       c124_1    1
    rhs       c125_1    1
    rhs       c126_1    1
    rhs       c127_1    1
    rhs       c128_1    1
    rhs       c129_1    1
    rhs       c130_1    1
    rhs       c131_1    1
    rhs       c132_1    1
    rhs       c133_1    1
    rhs       c134_1    1
    rhs       c135_1    1
    rhs       c136_1    1
    rhs       c137_1    1
    rhs       c138_1    1
    rhs       c139_1    1
    rhs       c140_1    1
    rhs       c141_1    1
    rhs       c142_1    1
    rhs       c143_1    1
    rhs       c144_1    1
    rhs       c145_1    1
    rhs       c146_1    1
    rhs       c147_1    1
    rhs       c148_1    1
    rhs       c149_1    1
    rhs       c150_1    1
    rhs       c151_1    1
    rhs       c152_1    1
    rhs       c153_1    1
    rhs       c154_1    1
    rhs       c155_1    1
    rhs       c156_1    1
    rhs       c157_1    1
    rhs       c158_1    1
    rhs       c159_1    1
    rhs       c160_1    1
    rhs       c161_1    1
    rhs       c162_1    1
    rhs       c163_1    1
    rhs       c164_1    1
    rhs       c165_1    1
    rhs       c166_1    1
    rhs       c167_1    1
    rhs       c168_1    1
    rhs       c169_1    1
    rhs       c170_1    1
    rhs       c171_1    1
    rhs       c172_1    1
    rhs       c173_1    1
    rhs       c174_1    1
    rhs       c175_1    1
    rhs       c176_1    1
    rhs       c177_1    1
    rhs       c178_1    1
    rhs       c179_1    1
    rhs       c180_1    1
    rhs       c181_1    1
    rhs       c182_1    1
    rhs       c183_1    1
    rhs       c184_1    1
    rhs       c185_1    1
    rhs       c186_1    1
    rhs       c187_1    1
    rhs       c188_1    1
    rhs       c189_1    1
    rhs       c190_1    1
    rhs       c191_1    1
    rhs       c192_1    1
    rhs       c193_1    1
    rhs       c194_1    1
    rhs       c195_1    1
    rhs       c196_1    1
    rhs       c197_1    1
    rhs       c198_1    1
    rhs       c199_1    1
    rhs       c200_1    1
    rhs       c201_1    1
    rhs       c202_1    1
    rhs       c203_1    1
    rhs       c204_1    1
    rhs       c205_1    1
    rhs       c206_1    1
    rhs       c207_1    1
    rhs       c208_1    1
    rhs       c209_1    1
    rhs       c210_1    1
    rhs       c211_1    1
    rhs       c212_1    1
    rhs       c213_1    1
    rhs       c214_1    1
    rhs       c215_1    1
    rhs       c216_1    1
    rhs       c217_1    1
    rhs       c218_1    1
    rhs       c219_1    1
    rhs       c220_1    1
    rhs       c221_1    1
    rhs       c222_1    1
    rhs       c223_1    1
    rhs       c224_1    1
    rhs       c225_1    1
    rhs       c226_1    1
    rhs       c227_1    1
    rhs       c228_1    1
    rhs       c229_1    1
    rhs       c230_1    1
    rhs       c231_1    1
    rhs       c232_1    1
    rhs       c233_1    1
    rhs       c234_1    1
    rhs       c235_1    1
    rhs       c236_1    1
    rhs       c237_1    1
    rhs       c238_1    1
    rhs       c239_1    1
    rhs       c240_1    1
    rhs       c241_1    1
    rhs       c242_1    1
    rhs       c243_1    1
    rhs       c244_1    1
    rhs       c245_1    1
    rhs       c246_1    1
    rhs       c247_1    1
    rhs       c248_1    1
    rhs       c249_1    1
    rhs       c250_1    1
    rhs       c251_1    1
    rhs       c252_1    1
    rhs       c253_1    1
    rhs       c254_1    1
    rhs       c255_1    1
    rhs       c256_1    1
    rhs       c257_1    1
    rhs       c258_1    1
    rhs       c259_1    1
    rhs       c260_1    1
    rhs       c261_1    1
    rhs       c262_1    1
    rhs       c263_1    1
    rhs       c264_1    1
    rhs       c265_1    1
    rhs       c266_1    1
    rhs       c267_1    1
    rhs       c268_1    1
    rhs       c269_1    1
    rhs       c270_1    1
    rhs       c271_1    1
    rhs       c272_1    1
    rhs       c273_1    1
    rhs       c274_1    1
    rhs       c275_1    1
    rhs       c276_1    1
    rhs       c277_1    1
    rhs       c278_1    1
    rhs       c279_1    1
    rhs       c280_1    1
    rhs       c281_1    1
    rhs       c282_1    1
    rhs       c283_1    1
    rhs       c284_1    1
    rhs       c285_1    1
    rhs       c286_1    1
    rhs       c287_1    1
    rhs       c288_1    1
    rhs       c289_1    1
    rhs       c290_1    1
    rhs       c291_1    1
    rhs       c292_1    1
    rhs       c293_1    1
    rhs       c294_1    1
    rhs       c295_1    1
    rhs       c296_1    1
    rhs       c297_1    1
    rhs       c298_1    1
    rhs       c299_1    1
    rhs       c300_1    1
    rhs       c301_1    1
    rhs       c302_1    1
    rhs       c303_1    1
    rhs       c304_1    1
    rhs       c305_1    1
    rhs       c306_1    1
    rhs       c307_1    1
    rhs       c308_1    1
    rhs       c309_1    1
    rhs       c310_1    1
    rhs       c311_1    1
    rhs       c312_1    1
    rhs       c313_1    1
    rhs       c314_1    1
    rhs       c315_1    1
    rhs       c316_1    1
    rhs       c317_1    1
    rhs       c318_1    1
    rhs       c319_1    1
    rhs       c320_1    1
    rhs       c321_1    1
    rhs       c322_1    1
    rhs       c323_1    1
    rhs       c324_1    1
    rhs       c325_1    1
    rhs       c326_1    1
    rhs       c327_1    1
    rhs       c328_1    1
    rhs       c329_1    1
    rhs       c330_1    1
    rhs       c331_1    1
    rhs       c332_1    1
    rhs       c333_1    1
    rhs       c334_1    1
    rhs       c335_1    1
    rhs       c336_1    1
    rhs       c337_1    1
    rhs       c338_1    1
    rhs       c339_1    1
    rhs       c340_1    1
    rhs       c341_1    1
    rhs       c342_1    1
    rhs       c343_1    1
    rhs       c344_1    1
    rhs       c345_1    1
    rhs       c346_1    1
    rhs       c347_1    1
    rhs       c348_1    1
    rhs       c349_1    1
    rhs       c350_1    1
    rhs       c351_1    1
    rhs       c352_1    1
    rhs       c353_1    1
    rhs       c354_1    1
    rhs       c355_1    1
    rhs       c356_1    1
    rhs       c357_1    1
    rhs       c358_1    1
    rhs       c359_1    1
    rhs       c360_1    1
    rhs       c361_1    1
    rhs       c362_1    1
    rhs       c363_1    1
    rhs       c364_1    1
    rhs       c365_1    1
    rhs       c366_1    1
    rhs       c367_1    1
    rhs       c368_1    1
    rhs       c369_1    1
    rhs       c370_1    1
    rhs       c371_1    1
    rhs       c372_1    1
    rhs       c373_1    1
    rhs       c374_1    1
    rhs       c375_1    1
    rhs       c376_1    1
    rhs       c377_1    1
    rhs       c378_1    1
    rhs       c379_1    1
    rhs       c380_1    1
    rhs       c381_1    1
    rhs       c382_1    1
    rhs       c383_1    1
    rhs       c384_1    1
    rhs       c385_1    1
    rhs       c386_1    1
    rhs       c387_1    1
    rhs       c388_1    1
    rhs       c389_1    1
    rhs       c390_1    1
    rhs       c391_1    1
    rhs       c392_1    1
    rhs       c393_1    1
    rhs       c394_1    1
    rhs       c395_1    1
    rhs       c396_1    1
    rhs       c397_1    1
    rhs       c398_1    1
    rhs       c399_1    1
    rhs       c400_1    1
    rhs       c401_1    1
    rhs       c402_1    1
    rhs       c403_1    1
    rhs       c404_1    1
    rhs       c405_1    1
    rhs       c406_1    1
    rhs       c407_1    1
    rhs       c408_1    1
    rhs       c409_1    1
    rhs       c410_1    1
    rhs       c411_1    1
    rhs       c412_1    1
    rhs       c413_1    1
    rhs       c414_1    1
    rhs       c415_1    1
    rhs       c416_1    1
    rhs       c417_1    1
    rhs       c418_1    1
    rhs       c419_1    1
    rhs       c420_1    1
    rhs       c421_1    1
    rhs       c422_1    1
    rhs       c423_1    1
    rhs       c424_1    1
    rhs       c425_1    1
    rhs       c426_1    1
    rhs       c427_1    1
    rhs       c428_1    1
    rhs       c429_1    1
    rhs       c430_1    1
    rhs       c431_1    1
    rhs       c432_1    1
    rhs       c433_1    1
    rhs       c434_1    1
    rhs       c435_1    1
    rhs       c436_1    1
    rhs       c437_1    1
    rhs       c438_1    1
    rhs       c439_1    1
    rhs       c440_1    1
    rhs       c441_1    1
    rhs       c442_1    1
    rhs       c443_1    1
    rhs       c444_1    1
    rhs       c445_1    1
    rhs       c446_1    1
    rhs       c447_1    1
    rhs       c448_1    1
    rhs       c449_1    1
    rhs       c450_1    1
    rhs       c451_1    1
    rhs       c452_1    1
    rhs       c453_1    1
    rhs       c454_1    1
    rhs       c455_1    1
    rhs       c456_1    1
    rhs       c457_1    1
    rhs       c458_1    1
    rhs       c459_1    1
    rhs       c460_1    1
    rhs       c461_1    1
    rhs       c462_1    1
    rhs       c463_1    1
    rhs       c464_1    1
    rhs       c465_1    1
    rhs       c466_1    1
    rhs       c467_1    1
    rhs       c468_1    1
    rhs       c469_1    1
    rhs       c470_1    1
    rhs       c471_1    1
    rhs       c472_1    1
    rhs       c473_1    1
    rhs       c474_1    1
    rhs       c475_1    1
    rhs       c476_1    6
    rhs       c477_1    6
    rhs       c478_1    6
    rhs       c479_1    6
    rhs       c480_1    6
    rhs       c481_1    0
    rhs       c482_1    0
    rhs       c483_1    0
    rhs       c484_1    0
    rhs       c485_1    0
    rhs       c486_1    0
    rhs       c487_1    0
    rhs       c488_1    0
    rhs       c489_1    0
    rhs       c490_1    0
    rhs       c491_1    0
    rhs       c492_1    0
    rhs       c493_1    0
    rhs       c494_1    0
    rhs       c495_1    0
    rhs       c496_1    0
    rhs       c497_1    0
    rhs       c498_1    0
    rhs       c499_1    0
    rhs       c500_1    0
    rhs       c501_1    0
    rhs       c502_1    0
    rhs       c503_1    0
    rhs       c504_1    0
    rhs       c505_1    0
    rhs       c506_1    0
    rhs       c507_1    0
    rhs       c508_1    0
    rhs       c509_1    0
    rhs       c510_1    0
    rhs       c511_1    0
    rhs       c512_1    0
    rhs       c513_1    0
    rhs       c514_1    0
    rhs       c515_1    0
    rhs       c516_1    0
    rhs       c517_1    0
    rhs       c518_1    0
    rhs       c519_1    0
    rhs       c520_1    0
    rhs       c521_1    0
    rhs       c522_1    0
    rhs       c523_1    0
    rhs       c524_1    0
    rhs       c525_1    0
    rhs       c526_1    0
    rhs       c527_1    0
    rhs       c528_1    0
    rhs       c529_1    0
    rhs       c530_1    0
    rhs       c531_1    0
    rhs       c532_1    0
    rhs       c533_1    0
    rhs       c534_1    0
    rhs       c535_1    0
    rhs       c536_1    0
    rhs       c537_1    0
    rhs       c538_1    0
    rhs       c539_1    0
    rhs       c540_1    0
    rhs       c541_1    0
    rhs       c542_1    0
    rhs       c543_1    0
    rhs       c544_1    0
    rhs       c545_1    0
    rhs       c546_1    0
    rhs       c547_1    0
    rhs       c548_1    0
    rhs       c549_1    0
    rhs       c550_1    0
    rhs       c551_1    0
    rhs       c552_1    0
    rhs       c553_1    0
    rhs       c554_1    0
    rhs       c555_1    0
    rhs       c556_1    0
    rhs       c557_1    0
    rhs       c558_1    0
    rhs       c559_1    0
    rhs       c560_1    0
    rhs       c561_1    0
    rhs       c562_1    0
    rhs       c563_1    0
    rhs       c564_1    0
    rhs       c565_1    0
    rhs       c566_1    0
    rhs       c567_1    0
    rhs       c568_1    0
    rhs       c569_1    0
    rhs       c570_1    0
    rhs       c571_1    0
    rhs       c572_1    0
    rhs       c573_1    0
    rhs       c574_1    0
    rhs       c575_1    0
    rhs       c576_1    0
    rhs       c577_1    0
    rhs       c578_1    0
    rhs       c579_1    0
    rhs       c580_1    0
    rhs       c581_1    0
    rhs       c582_1    0
    rhs       c583_1    0
    rhs       c584_1    0
    rhs       c585_1    0
    rhs       c586_1    0
    rhs       c587_1    0
    rhs       c588_1    0
    rhs       c589_1    0
    rhs       c590_1    0
    rhs       c591_1    0
    rhs       c592_1    0
    rhs       c593_1    0
    rhs       c594_1    0
    rhs       c595_1    0
    rhs       c596_1    0
    rhs       c597_1    0
    rhs       c598_1    0
    rhs       c599_1    0
    rhs       c600_1    0
    rhs       c601_1    0
    rhs       c602_1    0
    rhs       c603_1    0
    rhs       c604_1    0
    rhs       c605_1    0
    rhs       c606_1    0
    rhs       c607_1    0
    rhs       c608_1    0
    rhs       c609_1    0
    rhs       c610_1    0
    rhs       c611_1    0
    rhs       c612_1    0
    rhs       c613_1    0
    rhs       c614_1    0
    rhs       c615_1    0
    rhs       c616_1    0
    rhs       c617_1    0
    rhs       c618_1    0
    rhs       c619_1    0
    rhs       c620_1    0
    rhs       c621_1    0
    rhs       c622_1    0
    rhs       c623_1    0
    rhs       c624_1    0
    rhs       c625_1    0
    rhs       c626_1    0
    rhs       c627_1    0
    rhs       c628_1    0
    rhs       c629_1    0
    rhs       c630_1    0
    rhs       c631_1    0
    rhs       c632_1    0
    rhs       c633_1    0
    rhs       c634_1    0
    rhs       c635_1    0
    rhs       c636_1    0
    rhs       c637_1    0
    rhs       c638_1    0
    rhs       c639_1    0
    rhs       c640_1    0
    rhs       c641_1    0
    rhs       c642_1    0
    rhs       c643_1    0
    rhs       c644_1    0
    rhs       c645_1    0
    rhs       c646_1    0
    rhs       c647_1    0
    rhs       c648_1    0
    rhs       c649_1    0
    rhs       c650_1    0
    rhs       c651_1    0
    rhs       c652_1    0
    rhs       c653_1    0
    rhs       c654_1    0
    rhs       c655_1    0
    rhs       c656_1    0
    rhs       c657_1    0
    rhs       c658_1    0
    rhs       c659_1    0
    rhs       c660_1    0
    rhs       c661_1    0
    rhs       c662_1    0
    rhs       c663_1    0
    rhs       c664_1    0
    rhs       c665_1    0
    rhs       c666_1    0
    rhs       c667_1    0
    rhs       c668_1    0
    rhs       c669_1    0
    rhs       c670_1    0
    rhs       c671_1    0
    rhs       c672_1    0
    rhs       c673_1    0
    rhs       c674_1    0
    rhs       c675_1    0
    rhs       c676_1    0
    rhs       c677_1    0
    rhs       c678_1    0
    rhs       c679_1    0
    rhs       c680_1    0
    rhs       c681_1    0
    rhs       c682_1    0
    rhs       c683_1    0
    rhs       c684_1    0
    rhs       c685_1    0
    rhs       c686_1    0
    rhs       c687_1    0
    rhs       c688_1    0
    rhs       c689_1    0
    rhs       c690_1    0
    rhs       c691_1    0
    rhs       c692_1    0
    rhs       c693_1    0
    rhs       c694_1    0
    rhs       c695_1    0
    rhs       c696_1    0
    rhs       c697_1    0
    rhs       c698_1    0
    rhs       c699_1    0
    rhs       c700_1    0
    rhs       c701_1    0
    rhs       c702_1    0
    rhs       c703_1    0
    rhs       c704_1    0
    rhs       c705_1    0
    rhs       c706_1    0
    rhs       c707_1    0
    rhs       c708_1    0
    rhs       c709_1    0
    rhs       c710_1    0
    rhs       c711_1    0
    rhs       c712_1    0
    rhs       c713_1    0
    rhs       c714_1    0
    rhs       c715_1    0
    rhs       c716_1    0
    rhs       c717_1    0
    rhs       c718_1    0
    rhs       c719_1    0
    rhs       c720_1    0
    rhs       c721_1    0
    rhs       c722_1    0
    rhs       c723_1    0
    rhs       c724_1    0
    rhs       c725_1    0
    rhs       c726_1    0
    rhs       c727_1    0
    rhs       c728_1    0
    rhs       c729_1    0
    rhs       c730_1    0
    rhs       c731_1    0
    rhs       c732_1    0
    rhs       c733_1    0
    rhs       c734_1    0
    rhs       c735_1    0
    rhs       c736_1    0
    rhs       c737_1    0
    rhs       c738_1    0
    rhs       c739_1    0
    rhs       c740_1    0
    rhs       c741_1    0
    rhs       c742_1    0
    rhs       c743_1    0
    rhs       c744_1    0
    rhs       c745_1    0
    rhs       c746_1    0
    rhs       c747_1    0
    rhs       c748_1    0
    rhs       c749_1    0
    rhs       c750_1    0
    rhs       c751_1    0
    rhs       c752_1    0
    rhs       c753_1    0
    rhs       c754_1    0
    rhs       c755_1    0
    rhs       c756_1    0
    rhs       c757_1    0
    rhs       c758_1    0
    rhs       c759_1    0
    rhs       c760_1    0
    rhs       c761_1    0
    rhs       c762_1    0
    rhs       c763_1    0
    rhs       c764_1    0
    rhs       c765_1    0
    rhs       c766_1    0
    rhs       c767_1    0
    rhs       c768_1    0
    rhs       c769_1    0
    rhs       c770_1    0
    rhs       c771_1    0
    rhs       c772_1    0
    rhs       c773_1    0
    rhs       c774_1    0
    rhs       c775_1    0
    rhs       c776_1    0
    rhs       c777_1    0
    rhs       c778_1    0
    rhs       c779_1    0
    rhs       c780_1    0
    rhs       c781_1    0
    rhs       c782_1    0
    rhs       c783_1    0
    rhs       c784_1    0
    rhs       c785_1    0
    rhs       c786_1    0
    rhs       c787_1    0
    rhs       c788_1    0
    rhs       c789_1    0
    rhs       c790_1    0
    rhs       c791_1    0
    rhs       c792_1    0
    rhs       c793_1    0
    rhs       c794_1    0
    rhs       c795_1    0
    rhs       c796_1    0
    rhs       c797_1    0
    rhs       c798_1    0
    rhs       c799_1    0
    rhs       c800_1    0
    rhs       c801_1    0
    rhs       c802_1    0
    rhs       c803_1    0
    rhs       c804_1    0
    rhs       c805_1    0
    rhs       c806_1    0
    rhs       c807_1    0
    rhs       c808_1    0
    rhs       c809_1    0
    rhs       c810_1    0
    rhs       c811_1    0
    rhs       c812_1    0
    rhs       c813_1    0
    rhs       c814_1    0
    rhs       c815_1    0
    rhs       c816_1    0
    rhs       c817_1    0
    rhs       c818_1    0
    rhs       c819_1    0
    rhs       c820_1    0
    rhs       c821_1    0
    rhs       c822_1    0
    rhs       c823_1    0
    rhs       c824_1    0
    rhs       c825_1    0
    rhs       c826_1    0
    rhs       c827_1    0
    rhs       c828_1    0
    rhs       c829_1    0
    rhs       c830_1    0
    rhs       c831_1    0
    rhs       c832_1    0
    rhs       c833_1    0
    rhs       c834_1    0
    rhs       c835_1    0
    rhs       c836_1    0
    rhs       c837_1    0
    rhs       c838_1    0
    rhs       c839_1    0
    rhs       c840_1    0
    rhs       c841_1    0
    rhs       c842_1    0
    rhs       c843_1    0
    rhs       c844_1    0
    rhs       c845_1    0
    rhs       c846_1    0
    rhs       c847_1    0
    rhs       c848_1    0
    rhs       c849_1    0
    rhs       c850_1    0
    rhs       c851_1    0
    rhs       c852_1    0
    rhs       c853_1    0
    rhs       c854_1    0
    rhs       c855_1    0
    rhs       c856_1    0
    rhs       c857_1    0
    rhs       c858_1    0
    rhs       c859_1    0
    rhs       c860_1    0
    rhs       c861_1    0
    rhs       c862_1    0
    rhs       c863_1    0
    rhs       c864_1    0
    rhs       c865_1    0
    rhs       c866_1    0
    rhs       c867_1    0
    rhs       c868_1    0
    rhs       c869_1    0
    rhs       c870_1    0
    rhs       c871_1    0
    rhs       c872_1    0
    rhs       c873_1    0
    rhs       c874_1    0
    rhs       c875_1    0
    rhs       c876_1    0
    rhs       c877_1    0
    rhs       c878_1    0
    rhs       c879_1    0
    rhs       c880_1    0
    rhs       c881_1    0
    rhs       c882_1    0
    rhs       c883_1    0
    rhs       c884_1    0
    rhs       c885_1    0
    rhs       c886_1    0
    rhs       c887_1    0
    rhs       c888_1    0
    rhs       c889_1    0
    rhs       c890_1    0
    rhs       c891_1    0
    rhs       c892_1    0
    rhs       c893_1    0
    rhs       c894_1    0
    rhs       c895_1    0
    rhs       c896_1    0
    rhs       c897_1    0
    rhs       c898_1    0
    rhs       c899_1    0
    rhs       c900_1    0
    rhs       c901_1    0
    rhs       c902_1    0
    rhs       c903_1    0
    rhs       c904_1    0
    rhs       c905_1    0
    rhs       c906_1    0
    rhs       c907_1    0
    rhs       c908_1    0
    rhs       c909_1    0
    rhs       c910_1    0
    rhs       c911_1    0
    rhs       c912_1    0
    rhs       c913_1    0
    rhs       c914_1    0
    rhs       c915_1    0
    rhs       c916_1    0
    rhs       c917_1    0
    rhs       c918_1    0
    rhs       c919_1    0
    rhs       c920_1    0
    rhs       c921_1    0
    rhs       c922_1    0
    rhs       c923_1    0
    rhs       c924_1    0
    rhs       c925_1    0
    rhs       c926_1    0
    rhs       c927_1    0
    rhs       c928_1    0
    rhs       c929_1    0
    rhs       c930_1    0
    rhs       c931_1    0
    rhs       c932_1    0
    rhs       c933_1    0
    rhs       c934_1    0
    rhs       c935_1    0
    rhs       c936_1    0
    rhs       c937_1    0
    rhs       c938_1    0
    rhs       c939_1    0
    rhs       c940_1    0
    rhs       c941_1    0
    rhs       c942_1    0
    rhs       c943_1    0
    rhs       c944_1    0
    rhs       c945_1    0
    rhs       c946_1    0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     0
    rhs       c1207     0
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     0
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     0
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     0
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     0
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     0
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     0
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     0
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     0
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     0
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     0
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     0
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     0
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     0
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     0
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     0
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     0
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     1
    rhs       c1907     1
    rhs       c1908     1
    rhs       c1909     1
    rhs       c1910     1
    rhs       c1911     1
    rhs       c1912     1
    rhs       c1913     1
    rhs       c1914     1
    rhs       c1915     1
    rhs       c1916     1
    rhs       c1917     1
    rhs       c1918     1
    rhs       c1919     1
    rhs       c1920     1
    rhs       c1921     1
    rhs       c1922     1
    rhs       c1923     1
    rhs       c1        1
    rhs       c2        1
    rhs       c3        1
    rhs       c4        1
    rhs       c5        1
    rhs       c6        1
    rhs       c7        1
    rhs       c8        1
    rhs       c9        1
    rhs       c10       1
    rhs       c11       1
    rhs       c12       1
    rhs       c13       1
    rhs       c14       1
    rhs       c15       1
    rhs       c16       1
    rhs       c17       1
    rhs       c18       1
    rhs       c19       1
    rhs       c20       1
    rhs       c21       1
    rhs       c22       1
    rhs       c23       1
    rhs       c24       1
    rhs       c25       1
    rhs       c26       1
    rhs       c27       1
    rhs       c28       1
    rhs       c29       1
    rhs       c30       1
    rhs       c31       475
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      0
    rhs       c262      0
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      0
    rhs       c275      0
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      0
    rhs       c289      0
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      0
    rhs       c299      0
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      0
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      0
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      0
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
RANGES
BOUNDS
 FR bounds    x[1]
 FR bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 BV bounds    x[75]
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 BV bounds    x[80]
 FX bounds    x[81]     0
 FX bounds    x[82]     0
 BV bounds    x[83]
 BV bounds    x[84]
 BV bounds    x[85]
 BV bounds    x[86]
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 BV bounds    x[90]
 BV bounds    x[91]
 BV bounds    x[92]
 BV bounds    x[93]
 BV bounds    x[94]
 BV bounds    x[95]
 BV bounds    x[96]
 BV bounds    x[97]
 BV bounds    x[98]
 BV bounds    x[99]
 BV bounds    x[100]
 FX bounds    x[101]    0
 FX bounds    x[102]    0
 BV bounds    x[103]
 BV bounds    x[104]
 BV bounds    x[105]
 BV bounds    x[106]
 BV bounds    x[107]
 BV bounds    x[108]
 BV bounds    x[109]
 BV bounds    x[110]
 BV bounds    x[111]
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 BV bounds    x[119]
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 BV bounds    x[127]
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 BV bounds    x[135]
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 FX bounds    x[146]    0
 FX bounds    x[147]    0
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 FX bounds    x[161]    0
 FX bounds    x[162]    0
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 BV bounds    x[168]
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 BV bounds    x[178]
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 BV bounds    x[182]
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 BV bounds    x[188]
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 BV bounds    x[198]
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 FX bounds    x[211]    0
 FX bounds    x[212]    0
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 FX bounds    x[221]    0
 FX bounds    x[222]    0
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 BV bounds    x[248]
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 BV bounds    x[260]
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 BV bounds    x[272]
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 BV bounds    x[284]
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 FX bounds    x[326]    0
 FX bounds    x[327]    0
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 BV bounds    x[332]
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 BV bounds    x[341]
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 BV bounds    x[369]
 BV bounds    x[370]
 FX bounds    x[371]    0
 FX bounds    x[372]    0
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 FX bounds    x[391]    0
 FX bounds    x[392]    0
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 FX bounds    x[411]    0
 FX bounds    x[412]    0
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 BV bounds    x[422]
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 BV bounds    x[457]
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 FX bounds    x[461]    0
 FX bounds    x[462]    0
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 BV bounds    x[467]
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 BV bounds    x[499]
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 BV bounds    x[510]
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 BV bounds    x[552]
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 FX bounds    x[571]    0
 FX bounds    x[572]    0
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 BV bounds    x[588]
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 FX bounds    x[616]    0
 FX bounds    x[617]    0
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 BV bounds    x[640]
 FX bounds    x[641]    0
 FX bounds    x[642]    0
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 BV bounds    x[668]
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 FX bounds    x[676]    0
 FX bounds    x[677]    0
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 FX bounds    x[691]    0
 FX bounds    x[692]    0
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 FX bounds    x[711]    0
 FX bounds    x[712]    0
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 FX bounds    x[721]    0
 FX bounds    x[722]    0
 BV bounds    x[723]
 BV bounds    x[724]
 BV bounds    x[725]
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 FX bounds    x[736]    0
 FX bounds    x[737]    0
 BV bounds    x[738]
 BV bounds    x[739]
 BV bounds    x[740]
 FX bounds    x[741]    0
 FX bounds    x[742]    0
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 BV bounds    x[816]
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 BV bounds    x[822]
 BV bounds    x[823]
 BV bounds    x[824]
 BV bounds    x[825]
 BV bounds    x[826]
 BV bounds    x[827]
 BV bounds    x[828]
 BV bounds    x[829]
 BV bounds    x[830]
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 BV bounds    x[904]
 BV bounds    x[905]
 BV bounds    x[906]
 BV bounds    x[907]
 BV bounds    x[908]
 BV bounds    x[909]
 BV bounds    x[910]
 BV bounds    x[911]
 BV bounds    x[912]
 BV bounds    x[913]
 BV bounds    x[914]
 BV bounds    x[915]
 BV bounds    x[916]
 BV bounds    x[917]
 BV bounds    x[918]
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 FX bounds    x[941]    0
 FX bounds    x[942]    0
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 FX bounds    x[951]    0
 FX bounds    x[952]    0
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 FX bounds    x[956]    0
 FX bounds    x[957]    0
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 FX bounds    x[971]    0
 FX bounds    x[972]    0
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 BV bounds    x[989]
 BV bounds    x[990]
 BV bounds    x[991]
 BV bounds    x[992]
 BV bounds    x[993]
 BV bounds    x[994]
 BV bounds    x[995]
 BV bounds    x[996]
 BV bounds    x[997]
 BV bounds    x[998]
 BV bounds    x[999]
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 BV bounds    x[1003]
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 FX bounds    x[1016]   0
 FX bounds    x[1017]   0
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 FX bounds    x[1071]   0
 FX bounds    x[1072]   0
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 BV bounds    x[1082]
 BV bounds    x[1083]
 BV bounds    x[1084]
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 FX bounds    x[1096]   0
 FX bounds    x[1097]   0
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 FX bounds    x[1101]   0
 FX bounds    x[1102]   0
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 FX bounds    x[1106]   0
 FX bounds    x[1107]   0
 BV bounds    x[1108]
 BV bounds    x[1109]
 BV bounds    x[1110]
 FX bounds    x[1111]   0
 FX bounds    x[1112]   0
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 BV bounds    x[1150]
 BV bounds    x[1151]
 BV bounds    x[1152]
 BV bounds    x[1153]
 BV bounds    x[1154]
 BV bounds    x[1155]
 BV bounds    x[1156]
 BV bounds    x[1157]
 BV bounds    x[1158]
 BV bounds    x[1159]
 BV bounds    x[1160]
 BV bounds    x[1161]
 BV bounds    x[1162]
 BV bounds    x[1163]
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 BV bounds    x[1167]
 BV bounds    x[1168]
 BV bounds    x[1169]
 BV bounds    x[1170]
 BV bounds    x[1171]
 BV bounds    x[1172]
 BV bounds    x[1173]
 BV bounds    x[1174]
 BV bounds    x[1175]
 BV bounds    x[1176]
 BV bounds    x[1177]
 BV bounds    x[1178]
 BV bounds    x[1179]
 BV bounds    x[1180]
 BV bounds    x[1181]
 BV bounds    x[1182]
 BV bounds    x[1183]
 BV bounds    x[1184]
 BV bounds    x[1185]
 BV bounds    x[1186]
 BV bounds    x[1187]
 BV bounds    x[1188]
 BV bounds    x[1189]
 BV bounds    x[1190]
 BV bounds    x[1191]
 BV bounds    x[1192]
 BV bounds    x[1193]
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 BV bounds    x[1197]
 BV bounds    x[1198]
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 BV bounds    x[1203]
 BV bounds    x[1204]
 BV bounds    x[1205]
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 BV bounds    x[1209]
 BV bounds    x[1210]
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 BV bounds    x[1217]
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 BV bounds    x[1229]
 BV bounds    x[1230]
 BV bounds    x[1231]
 BV bounds    x[1232]
 BV bounds    x[1233]
 BV bounds    x[1234]
 BV bounds    x[1235]
 BV bounds    x[1236]
 BV bounds    x[1237]
 BV bounds    x[1238]
 BV bounds    x[1239]
 BV bounds    x[1240]
 BV bounds    x[1241]
 BV bounds    x[1242]
 BV bounds    x[1243]
 BV bounds    x[1244]
 BV bounds    x[1245]
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 BV bounds    x[1249]
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 BV bounds    x[1260]
 BV bounds    x[1261]
 BV bounds    x[1262]
 BV bounds    x[1263]
 BV bounds    x[1264]
 BV bounds    x[1265]
 BV bounds    x[1266]
 BV bounds    x[1267]
 BV bounds    x[1268]
 BV bounds    x[1269]
 BV bounds    x[1270]
 BV bounds    x[1271]
 BV bounds    x[1272]
 BV bounds    x[1273]
 BV bounds    x[1274]
 BV bounds    x[1275]
 BV bounds    x[1276]
 BV bounds    x[1277]
 BV bounds    x[1278]
 BV bounds    x[1279]
 BV bounds    x[1280]
 BV bounds    x[1281]
 BV bounds    x[1282]
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 BV bounds    x[1293]
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 BV bounds    x[1311]
 BV bounds    x[1312]
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 BV bounds    x[1317]
 BV bounds    x[1318]
 BV bounds    x[1319]
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 BV bounds    x[1323]
 BV bounds    x[1324]
 BV bounds    x[1325]
 BV bounds    x[1326]
 BV bounds    x[1327]
 BV bounds    x[1328]
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 BV bounds    x[1336]
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 FX bounds    x[1341]   0
 FX bounds    x[1342]   0
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 BV bounds    x[1353]
 BV bounds    x[1354]
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 BV bounds    x[1359]
 BV bounds    x[1360]
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 BV bounds    x[1364]
 BV bounds    x[1365]
 BV bounds    x[1366]
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 FX bounds    x[1381]   0
 FX bounds    x[1382]   0
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 BV bounds    x[1401]
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 BV bounds    x[1409]
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 FX bounds    x[1421]   0
 FX bounds    x[1422]   0
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 BV bounds    x[1442]
 BV bounds    x[1443]
 BV bounds    x[1444]
 BV bounds    x[1445]
 BV bounds    x[1446]
 BV bounds    x[1447]
 BV bounds    x[1448]
 BV bounds    x[1449]
 BV bounds    x[1450]
 BV bounds    x[1451]
 BV bounds    x[1452]
 BV bounds    x[1453]
 BV bounds    x[1454]
 BV bounds    x[1455]
 BV bounds    x[1456]
 BV bounds    x[1457]
 BV bounds    x[1458]
 BV bounds    x[1459]
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 BV bounds    x[1478]
 BV bounds    x[1479]
 BV bounds    x[1480]
 BV bounds    x[1481]
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 BV bounds    x[1485]
 BV bounds    x[1486]
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 BV bounds    x[1491]
 BV bounds    x[1492]
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 BV bounds    x[1515]
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 BV bounds    x[1521]
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 FX bounds    x[1526]   0
 FX bounds    x[1527]   0
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 FX bounds    x[1531]   0
 FX bounds    x[1532]   0
 BV bounds    x[1533]
 BV bounds    x[1534]
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 BV bounds    x[1539]
 BV bounds    x[1540]
 BV bounds    x[1541]
 BV bounds    x[1542]
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 BV bounds    x[1550]
 FX bounds    x[1551]   0
 FX bounds    x[1552]   0
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 BV bounds    x[1566]
 BV bounds    x[1567]
 BV bounds    x[1568]
 BV bounds    x[1569]
 BV bounds    x[1570]
 BV bounds    x[1571]
 BV bounds    x[1572]
 BV bounds    x[1573]
 BV bounds    x[1574]
 BV bounds    x[1575]
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 BV bounds    x[1580]
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 BV bounds    x[1586]
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 BV bounds    x[1592]
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 BV bounds    x[1599]
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 BV bounds    x[1605]
 BV bounds    x[1606]
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 BV bounds    x[1611]
 BV bounds    x[1612]
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 BV bounds    x[1616]
 BV bounds    x[1617]
 BV bounds    x[1618]
 BV bounds    x[1619]
 BV bounds    x[1620]
 BV bounds    x[1621]
 BV bounds    x[1622]
 BV bounds    x[1623]
 BV bounds    x[1624]
 BV bounds    x[1625]
 BV bounds    x[1626]
 BV bounds    x[1627]
 BV bounds    x[1628]
 BV bounds    x[1629]
 BV bounds    x[1630]
 BV bounds    x[1631]
 BV bounds    x[1632]
 BV bounds    x[1633]
 BV bounds    x[1634]
 BV bounds    x[1635]
 BV bounds    x[1636]
 BV bounds    x[1637]
 BV bounds    x[1638]
 BV bounds    x[1639]
 BV bounds    x[1640]
 BV bounds    x[1641]
 BV bounds    x[1642]
 BV bounds    x[1643]
 BV bounds    x[1644]
 BV bounds    x[1645]
 BV bounds    x[1646]
 BV bounds    x[1647]
 BV bounds    x[1648]
 BV bounds    x[1649]
 BV bounds    x[1650]
 BV bounds    x[1651]
 BV bounds    x[1652]
 BV bounds    x[1653]
 BV bounds    x[1654]
 BV bounds    x[1655]
 FX bounds    x[1656]   0
 FX bounds    x[1657]   0
 BV bounds    x[1658]
 BV bounds    x[1659]
 BV bounds    x[1660]
 BV bounds    x[1661]
 BV bounds    x[1662]
 BV bounds    x[1663]
 BV bounds    x[1664]
 BV bounds    x[1665]
 BV bounds    x[1666]
 BV bounds    x[1667]
 BV bounds    x[1668]
 BV bounds    x[1669]
 BV bounds    x[1670]
 BV bounds    x[1671]
 BV bounds    x[1672]
 BV bounds    x[1673]
 BV bounds    x[1674]
 BV bounds    x[1675]
 BV bounds    x[1676]
 BV bounds    x[1677]
 BV bounds    x[1678]
 BV bounds    x[1679]
 BV bounds    x[1680]
 BV bounds    x[1681]
 BV bounds    x[1682]
 BV bounds    x[1683]
 BV bounds    x[1684]
 BV bounds    x[1685]
 BV bounds    x[1686]
 BV bounds    x[1687]
 BV bounds    x[1688]
 BV bounds    x[1689]
 BV bounds    x[1690]
 BV bounds    x[1691]
 BV bounds    x[1692]
 BV bounds    x[1693]
 BV bounds    x[1694]
 BV bounds    x[1695]
 BV bounds    x[1696]
 BV bounds    x[1697]
 BV bounds    x[1698]
 BV bounds    x[1699]
 BV bounds    x[1700]
 BV bounds    x[1701]
 BV bounds    x[1702]
 BV bounds    x[1703]
 BV bounds    x[1704]
 BV bounds    x[1705]
 BV bounds    x[1706]
 BV bounds    x[1707]
 BV bounds    x[1708]
 BV bounds    x[1709]
 BV bounds    x[1710]
 BV bounds    x[1711]
 BV bounds    x[1712]
 BV bounds    x[1713]
 BV bounds    x[1714]
 BV bounds    x[1715]
 FX bounds    x[1716]   0
 FX bounds    x[1717]   0
 BV bounds    x[1718]
 BV bounds    x[1719]
 BV bounds    x[1720]
 BV bounds    x[1721]
 BV bounds    x[1722]
 BV bounds    x[1723]
 BV bounds    x[1724]
 BV bounds    x[1725]
 FX bounds    x[1726]   0
 FX bounds    x[1727]   0
 BV bounds    x[1728]
 BV bounds    x[1729]
 BV bounds    x[1730]
 BV bounds    x[1731]
 BV bounds    x[1732]
 BV bounds    x[1733]
 BV bounds    x[1734]
 BV bounds    x[1735]
 BV bounds    x[1736]
 BV bounds    x[1737]
 BV bounds    x[1738]
 BV bounds    x[1739]
 BV bounds    x[1740]
 BV bounds    x[1741]
 BV bounds    x[1742]
 BV bounds    x[1743]
 BV bounds    x[1744]
 BV bounds    x[1745]
 BV bounds    x[1746]
 BV bounds    x[1747]
ENDATA
