NAME
ROWS
 N  OBJ
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
COLUMNS
    x[1]      c1        1
    x[1]      OBJ       1
    x[2]      c1        1
    x[2]      OBJ       -1
    x[3]      c2        1
    x[3]      OBJ       1
    x[4]      c2        1
    x[4]      OBJ       -1
    x[5]      c3        1
    x[5]      OBJ       1
    x[6]      c3        1
    x[6]      OBJ       -1
    x[7]      c4        1
    x[7]      OBJ       1
    x[8]      c4        1
    x[8]      OBJ       -1
    x[9]      c5        1
    x[9]      OBJ       1
    x[10]     c5        1
    x[10]     OBJ       -1
    x[11]     c6        1
    x[11]     OBJ       1
    x[12]     c6        1
    x[12]     OBJ       -1
    x[13]     c7        1
    x[13]     OBJ       1
    x[14]     c7        1
    x[14]     OBJ       -1
    MARKER    'MARKER'                 'INTORG'
    x[15]     c1        74
    x[15]     c2        20
    x[15]     c3        85
    x[15]     c4        13
    x[15]     c5        35
    x[15]     c6        86
    x[15]     c7        41
    x[16]     c1        49
    x[16]     c2        7
    x[16]     c3        47
    x[16]     c4        71
    x[16]     c5        61
    x[16]     c6        8
    x[16]     c7        64
    x[17]     c1        12
    x[17]     c2        68
    x[17]     c3        67
    x[17]     c4        78
    x[17]     c5        66
    x[17]     c6        44
    x[17]     c7        82
    x[18]     c1        93
    x[18]     c2        69
    x[18]     c3        59
    x[18]     c4        84
    x[18]     c5        78
    x[18]     c6        96
    x[18]     c7        24
    x[19]     c1        56
    x[19]     c2        95
    x[19]     c3        84
    x[19]     c4        56
    x[19]     c5        46
    x[19]     c6        64
    x[19]     c7        48
    x[20]     c1        16
    x[20]     c2        64
    x[20]     c3        59
    x[20]     c4        66
    x[20]     c5        89
    x[20]     c6        65
    x[20]     c7        41
    x[21]     c1        39
    x[21]     c2        76
    x[21]     c3        19
    x[21]     c4        8
    x[21]     c5        61
    x[21]     c6        68
    x[21]     c7        29
    x[22]     c1        77
    x[22]     c2        12
    x[22]     c3        8
    x[22]     c4        68
    x[22]     c5        25
    x[22]     c6        53
    x[22]     c7        93
    x[23]     c1        56
    x[23]     c2        45
    x[23]     c3        50
    x[23]     c4        48
    x[23]     c5        55
    x[23]     c6        19
    x[23]     c7        64
    x[24]     c1        73
    x[24]     c2        43
    x[24]     c3        66
    x[24]     c4        28
    x[24]     c5        16
    x[24]     c6        33
    x[24]     c7        39
    x[25]     c1        1
    x[25]     c2        83
    x[25]     c3        5
    x[25]     c4        33
    x[25]     c5        81
    x[25]     c6        28
    x[25]     c7        92
    x[26]     c1        3
    x[26]     c2        15
    x[26]     c3        51
    x[26]     c4        34
    x[26]     c5        35
    x[26]     c6        42
    x[26]     c7        86
    x[27]     c1        68
    x[27]     c2        90
    x[27]     c3        51
    x[27]     c4        8
    x[27]     c5        96
    x[27]     c6        72
    x[27]     c7        64
    x[28]     c1        61
    x[28]     c2        10
    x[28]     c3        64
    x[28]     c4        99
    x[28]     c5        23
    x[28]     c6        39
    x[28]     c7        45
    x[29]     c1        8
    x[29]     c2        96
    x[29]     c3        64
    x[29]     c4        80
    x[29]     c5        83
    x[29]     c6        5
    x[29]     c7        87
    x[30]     c1        55
    x[30]     c2        98
    x[30]     c3        53
    x[30]     c4        74
    x[30]     c5        39
    x[30]     c6        77
    x[30]     c7        34
    x[31]     c1        18
    x[31]     c2        53
    x[31]     c3        61
    x[31]     c4        2
    x[31]     c5        14
    x[31]     c6        37
    x[31]     c7        39
    x[32]     c1        21
    x[32]     c2        1
    x[32]     c3        45
    x[32]     c4        10
    x[32]     c5        53
    x[32]     c6        89
    x[32]     c7        88
    x[33]     c1        57
    x[33]     c2        2
    x[33]     c3        3
    x[33]     c4        96
    x[33]     c5        23
    x[33]     c6        7
    x[33]     c7        99
    x[34]     c1        98
    x[34]     c2        58
    x[34]     c3        76
    x[34]     c4        41
    x[34]     c5        23
    x[34]     c6        78
    x[34]     c7        63
    x[35]     c1        58
    x[35]     c2        24
    x[35]     c3        17
    x[35]     c4        98
    x[35]     c5        93
    x[35]     c6        10
    x[35]     c7        85
    x[36]     c1        57
    x[36]     c2        90
    x[36]     c3        54
    x[36]     c4        74
    x[36]     c5        38
    x[36]     c6        78
    x[36]     c7        48
    x[37]     c1        46
    x[37]     c2        29
    x[37]     c3        13
    x[37]     c4        39
    x[37]     c5        15
    x[37]     c6        10
    x[37]     c7        83
    x[38]     c1        72
    x[38]     c2        57
    x[38]     c3        89
    x[38]     c4        91
    x[38]     c5        20
    x[38]     c6        96
    x[38]     c7        88
    x[39]     c1        6
    x[39]     c2        19
    x[39]     c3        68
    x[39]     c4        85
    x[39]     c5        19
    x[39]     c6        55
    x[39]     c7        85
    x[40]     c1        16
    x[40]     c2        73
    x[40]     c3        57
    x[40]     c4        95
    x[40]     c5        28
    x[40]     c6        1
    x[40]     c7        5
    x[41]     c1        76
    x[41]     c2        89
    x[41]     c3        4
    x[41]     c4        96
    x[41]     c5        79
    x[41]     c6        64
    x[41]     c7        14
    x[42]     c1        21
    x[42]     c2        31
    x[42]     c3        24
    x[42]     c4        1
    x[42]     c5        51
    x[42]     c6        61
    x[42]     c7        31
    x[43]     c1        78
    x[43]     c2        12
    x[43]     c3        96
    x[43]     c4        80
    x[43]     c5        24
    x[43]     c6        63
    x[43]     c7        12
    x[44]     c1        18
    x[44]     c2        34
    x[44]     c3        81
    x[44]     c4        90
    x[44]     c5        6
    x[44]     c6        90
    x[44]     c7        93
    x[45]     c1        11
    x[45]     c2        67
    x[45]     c3        36
    x[45]     c4        97
    x[45]     c5        3
    x[45]     c6        22
    x[45]     c7        55
    x[46]     c1        58
    x[46]     c2        48
    x[46]     c3        54
    x[46]     c4        36
    x[46]     c5        47
    x[46]     c6        78
    x[46]     c7        1
    x[47]     c1        59
    x[47]     c2        11
    x[47]     c3        3
    x[47]     c4        7
    x[47]     c5        61
    x[47]     c6        92
    x[47]     c7        2
    x[48]     c1        25
    x[48]     c2        22
    x[48]     c3        82
    x[48]     c4        69
    x[48]     c5        60
    x[48]     c6        25
    x[48]     c7        22
    x[49]     c1        32
    x[49]     c2        36
    x[49]     c3        33
    x[49]     c4        9
    x[49]     c5        71
    x[49]     c6        24
    x[49]     c7        93
    x[50]     c1        14
    x[50]     c2        78
    x[50]     c3        88
    x[50]     c4        9
    x[50]     c5        63
    x[50]     c6        65
    x[50]     c7        49
    x[51]     c1        16
    x[51]     c2        75
    x[51]     c3        1
    x[51]     c4        93
    x[51]     c5        26
    x[51]     c6        6
    x[51]     c7        35
    x[52]     c1        3
    x[52]     c2        52
    x[52]     c3        29
    x[52]     c4        94
    x[52]     c5        66
    x[52]     c6        68
    x[52]     c7        25
    x[53]     c1        60
    x[53]     c2        95
    x[53]     c3        4
    x[53]     c4        44
    x[53]     c5        71
    x[53]     c6        66
    x[53]     c7        39
    x[54]     c1        12
    x[54]     c2        57
    x[54]     c3        48
    x[54]     c4        36
    x[54]     c5        63
    x[54]     c6        66
    x[54]     c7        1
    x[55]     c1        7
    x[55]     c2        62
    x[55]     c3        51
    x[55]     c4        71
    x[55]     c5        56
    x[55]     c6        1
    x[55]     c7        77
    x[56]     c1        42
    x[56]     c2        94
    x[56]     c3        14
    x[56]     c4        37
    x[56]     c5        32
    x[56]     c6        67
    x[56]     c7        43
    x[57]     c1        98
    x[57]     c2        10
    x[57]     c3        86
    x[57]     c4        72
    x[57]     c5        39
    x[57]     c6        78
    x[57]     c7        7
    x[58]     c1        34
    x[58]     c2        42
    x[58]     c3        64
    x[58]     c4        38
    x[58]     c5        31
    x[58]     c6        21
    x[58]     c7        42
    x[59]     c1        33
    x[59]     c2        89
    x[59]     c3        73
    x[59]     c4        74
    x[59]     c5        64
    x[59]     c6        47
    x[59]     c7        36
    x[60]     c1        16
    x[60]     c2        11
    x[60]     c3        78
    x[60]     c4        89
    x[60]     c5        89
    x[60]     c6        17
    x[60]     c7        63
    x[61]     c1        97
    x[61]     c2        77
    x[61]     c3        45
    x[61]     c4        37
    x[61]     c5        62
    x[61]     c6        89
    x[61]     c7        5
    x[62]     c1        63
    x[62]     c2        85
    x[62]     c3        65
    x[62]     c4        24
    x[62]     c5        68
    x[62]     c6        77
    x[62]     c7        8
    x[63]     c1        66
    x[63]     c2        30
    x[63]     c3        30
    x[63]     c4        88
    x[63]     c5        59
    x[63]     c6        88
    x[63]     c7        43
    x[64]     c1        28
    x[64]     c2        82
    x[64]     c3        52
    x[64]     c4        77
    x[64]     c5        71
    x[64]     c6        54
    x[64]     c7        18
    x[65]     c1        57
    x[65]     c2        20
    x[65]     c3        6
    x[65]     c4        61
    x[65]     c5        48
    x[65]     c6        10
    x[65]     c7        60
    x[66]     c1        19
    x[66]     c2        52
    x[66]     c3        78
    x[66]     c4        80
    x[66]     c5        76
    x[66]     c6        87
    x[66]     c7        47
    x[67]     c1        74
    x[67]     c2        78
    x[67]     c3        9
    x[67]     c4        2
    x[67]     c5        96
    x[67]     c6        88
    x[67]     c7        47
    x[68]     c1        44
    x[68]     c2        6
    x[68]     c3        19
    x[68]     c4        60
    x[68]     c5        74
    x[68]     c6        80
    x[68]     c7        46
    x[69]     c1        45
    x[69]     c2        57
    x[69]     c3        87
    x[69]     c4        87
    x[69]     c5        61
    x[69]     c6        76
    x[69]     c7        45
    x[70]     c1        49
    x[70]     c2        65
    x[70]     c3        73
    x[70]     c4        80
    x[70]     c5        21
    x[70]     c6        9
    x[70]     c7        38
    x[71]     c1        76
    x[71]     c2        79
    x[71]     c3        10
    x[71]     c4        74
    x[71]     c5        46
    x[71]     c6        83
    x[71]     c7        9
    x[72]     c1        74
    x[72]     c2        83
    x[72]     c3        87
    x[72]     c4        42
    x[72]     c5        18
    x[72]     c6        95
    x[72]     c7        37
    x[73]     c1        9
    x[73]     c2        16
    x[73]     c3        33
    x[73]     c4        2
    x[73]     c5        23
    x[73]     c6        86
    x[73]     c7        8
    x[74]     c1        44
    x[74]     c2        67
    x[74]     c3        1
    x[74]     c4        37
    x[74]     c5        24
    x[74]     c6        24
    x[74]     c7        82
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1        1324
    rhs       c2        1554
    rhs       c3        1429
    rhs       c4        1686
    rhs       c5        1482
    rhs       c6        1613
    rhs       c7        1424
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      1324
 FX bounds    x[2]      0
 LO bounds    x[3]      0
 UP bounds    x[3]      1554
 FX bounds    x[4]      0
 LO bounds    x[5]      0
 UP bounds    x[5]      1429
 FX bounds    x[6]      0
 LO bounds    x[7]      0
 UP bounds    x[7]      1686
 FX bounds    x[8]      0
 LO bounds    x[9]      0
 UP bounds    x[9]      1482
 FX bounds    x[10]     0
 LO bounds    x[11]     0
 UP bounds    x[11]     1613
 FX bounds    x[12]     0
 LO bounds    x[13]     0
 UP bounds    x[13]     1424
 FX bounds    x[14]     0
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
ENDATA
