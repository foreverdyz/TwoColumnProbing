NAME
ROWS
 N  OBJ
 L  c1_2
 L  c2_2
 L  c3_2
 L  c4_2
 L  c5_2
 L  c6_2
 L  c7_2
 L  c8_2
 L  c9_2
 L  c10_2
 L  c11_2
 L  c12_2
 L  c13_2
 L  c14_2
 L  c15_2
 L  c16_2
 L  c17_2
 L  c18_2
 L  c19_2
 L  c20_2
 L  c21_2
 L  c22_2
 L  c23_2
 L  c24_2
 L  c25_2
 L  c26_2
 L  c27_2
 L  c28_2
 L  c29_2
 L  c30_2
 L  c31_2
 L  c32_2
 L  c33_2
 L  c34_2
 L  c35_2
 L  c36_2
 L  c37_2
 L  c38_2
 L  c39_2
 L  c40_2
 L  c41_2
 L  c42_2
 L  c43_2
 L  c44_2
 L  c45_2
 L  c46_2
 L  c47_2
 L  c48_2
 L  c49_2
 L  c50_2
 L  c51_1
 L  c52_1
 L  c53_1
 L  c54_1
 L  c55_1
 L  c56_1
 L  c57_1
 L  c58_1
 L  c59_1
 L  c60_1
 L  c61_1
 L  c62_1
 L  c63_1
 L  c64_1
 L  c65_1
 L  c66_1
 L  c67_1
 L  c68_1
 L  c69_1
 L  c70_1
 L  c71_1
 L  c72_1
 L  c73_1
 L  c74_1
 G  c1_1
 G  c2_1
 G  c3_1
 G  c4_1
 G  c5_1
 G  c6_1
 G  c7_1
 G  c8_1
 G  c9_1
 G  c10_1
 G  c11_1
 G  c12_1
 G  c13_1
 G  c14_1
 G  c15_1
 G  c16_1
 G  c17_1
 G  c18_1
 G  c19_1
 G  c20_1
 G  c21_1
 G  c22_1
 G  c23_1
 G  c24_1
 G  c25_1
 G  c26_1
 G  c27_1
 G  c28_1
 G  c29_1
 G  c30_1
 G  c31_1
 G  c32_1
 G  c33_1
 G  c34_1
 G  c35_1
 G  c36_1
 G  c37_1
 G  c38_1
 G  c39_1
 G  c40_1
 G  c41_1
 G  c42_1
 G  c43_1
 G  c44_1
 G  c45_1
 G  c46_1
 G  c47_1
 G  c48_1
 G  c49_1
 G  c50_1
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
 E  c625
 E  c626
 E  c627
 E  c628
 E  c629
 E  c630
 E  c631
 E  c632
 E  c633
 E  c634
 E  c635
 E  c636
 E  c637
 E  c638
 E  c639
 E  c640
 E  c641
 E  c642
 E  c643
 E  c644
 E  c645
 E  c646
 E  c647
 E  c648
 E  c649
 E  c650
 E  c651
 E  c652
 E  c653
 E  c654
 E  c655
 E  c656
 E  c657
 E  c658
 E  c659
 E  c660
 E  c661
 E  c662
 E  c663
 E  c664
 E  c665
 E  c666
 E  c667
 E  c668
 E  c669
 E  c670
 E  c671
 E  c672
 E  c673
 E  c674
 E  c675
 E  c676
 E  c677
 E  c678
 E  c679
 E  c680
 E  c681
 E  c682
 E  c683
 E  c684
 E  c685
 E  c686
 E  c687
 E  c688
 E  c689
 E  c690
 E  c691
 E  c692
 E  c693
 E  c694
 E  c695
 E  c696
 E  c697
 E  c698
 E  c699
 E  c700
 E  c701
 E  c702
 E  c703
 E  c704
 E  c705
 E  c706
 E  c707
 E  c708
 E  c709
 E  c710
 E  c711
 E  c712
 E  c713
 E  c714
 E  c715
 E  c716
 E  c717
 E  c718
 E  c719
 E  c720
 E  c721
 E  c722
 E  c723
 E  c724
 E  c725
 E  c726
 E  c727
 E  c728
 E  c729
 E  c730
 E  c731
 E  c732
 E  c733
 E  c734
 E  c735
 E  c736
 E  c737
 E  c738
 E  c739
 E  c740
 E  c741
 E  c742
 E  c743
 E  c744
 E  c745
 E  c746
 E  c747
 E  c748
 E  c749
 E  c750
 E  c751
 E  c752
 E  c753
 E  c754
 E  c755
 E  c756
 E  c757
 E  c758
 E  c759
 E  c760
 E  c761
 E  c762
 E  c763
 E  c764
 E  c765
 E  c766
 E  c767
 E  c768
 E  c769
 E  c770
 E  c771
 E  c772
 E  c773
 E  c774
 E  c775
 E  c776
 E  c777
 E  c778
 E  c779
 E  c780
 E  c781
 E  c782
 E  c783
 E  c784
 E  c785
 E  c786
 E  c787
 E  c788
 E  c789
 E  c790
 E  c791
 E  c792
 E  c793
 E  c794
 E  c795
 E  c796
 E  c797
 E  c798
 E  c799
 E  c800
 E  c801
 E  c802
 E  c803
 E  c804
 E  c805
 E  c806
 E  c807
 E  c808
 E  c809
 E  c810
 E  c811
 E  c812
 E  c813
 E  c814
 E  c815
 E  c816
 E  c817
 E  c818
 E  c819
 E  c820
 E  c821
 E  c822
 E  c823
 E  c824
 E  c825
 E  c826
 E  c827
 E  c828
 E  c829
 E  c830
 E  c831
 E  c832
 E  c833
 E  c834
 E  c835
 E  c836
 E  c837
 E  c838
 E  c839
 E  c840
 E  c841
 E  c842
 E  c843
 E  c844
 E  c845
 E  c846
 E  c847
 E  c848
 E  c849
 E  c850
 E  c851
 E  c852
 E  c853
 E  c854
 E  c855
 E  c856
 E  c857
 E  c858
 E  c859
 E  c860
 E  c861
 E  c862
 E  c863
 E  c864
 E  c865
 E  c866
 E  c867
 E  c868
 E  c869
 E  c870
 E  c871
 E  c872
 E  c873
 E  c874
 E  c875
 E  c876
 E  c877
 E  c878
 E  c879
 E  c880
 E  c881
 E  c882
 E  c883
 E  c884
 E  c885
 E  c886
 E  c887
 E  c888
 E  c889
 E  c890
 E  c891
 E  c892
 E  c893
 E  c894
 E  c895
 E  c896
 E  c897
 E  c898
 E  c899
 E  c900
 E  c901
 E  c902
 E  c903
 E  c904
 E  c905
 E  c906
 E  c907
 E  c908
 E  c909
 E  c910
 E  c911
 E  c912
 E  c913
 E  c914
 E  c915
 E  c916
 E  c917
 E  c918
 E  c919
 E  c920
 E  c921
 E  c922
 E  c923
 E  c924
 E  c925
 E  c926
 E  c927
 E  c928
 E  c929
 E  c930
 E  c931
 E  c932
 E  c933
 E  c934
 E  c935
 E  c936
 E  c937
 E  c938
 E  c939
 E  c940
 E  c941
 E  c942
 E  c943
 E  c944
 E  c945
 E  c946
 E  c947
 E  c948
 E  c949
 E  c950
 E  c951
 E  c952
 E  c953
 E  c954
 E  c955
 E  c956
 E  c957
 E  c958
 E  c959
 E  c960
 E  c961
 E  c962
 E  c963
 E  c964
 E  c965
 E  c966
 E  c967
 E  c968
 E  c969
 E  c970
 E  c971
 E  c972
 E  c973
 E  c974
 E  c975
 E  c976
 E  c977
 E  c978
 E  c979
 E  c980
 E  c981
 E  c982
 E  c983
 E  c984
 E  c985
 E  c986
 E  c987
 E  c988
 E  c989
 E  c990
 E  c991
 E  c992
 E  c993
 E  c994
 E  c995
 E  c996
 E  c997
 E  c998
 E  c999
 E  c1000
 E  c1001
 E  c1002
 E  c1003
 E  c1004
 E  c1005
 E  c1006
 E  c1007
 E  c1008
 E  c1009
 E  c1010
 E  c1011
 E  c1012
 E  c1013
 E  c1014
 E  c1015
 E  c1016
 E  c1017
 E  c1018
 E  c1019
 E  c1020
 E  c1021
 E  c1022
 E  c1023
 E  c1024
 E  c1025
 E  c1026
 E  c1027
 E  c1028
 E  c1029
 E  c1030
 E  c1031
 E  c1032
 E  c1033
 E  c1034
 E  c1035
 E  c1036
 E  c1037
 E  c1038
 E  c1039
 E  c1040
 E  c1041
 E  c1042
 E  c1043
 E  c1044
 E  c1045
 E  c1046
 E  c1047
 E  c1048
 E  c1049
 E  c1050
 E  c1051
 E  c1052
 E  c1053
 E  c1054
 E  c1055
 E  c1056
 E  c1057
 E  c1058
 E  c1059
 E  c1060
 E  c1061
 E  c1062
 E  c1063
 E  c1064
 E  c1065
 E  c1066
 E  c1067
 E  c1068
 E  c1069
 E  c1070
 E  c1071
 E  c1072
 E  c1073
 E  c1074
 E  c1075
 E  c1076
 E  c1077
 E  c1078
 E  c1079
 E  c1080
 E  c1081
 E  c1082
 E  c1083
 E  c1084
 E  c1085
 E  c1086
 E  c1087
 E  c1088
 E  c1089
 E  c1090
 E  c1091
 E  c1092
 E  c1093
 E  c1094
 E  c1095
 E  c1096
 E  c1097
 E  c1098
 E  c1099
 E  c1100
 E  c1101
 E  c1102
 E  c1103
 E  c1104
 E  c1105
 E  c1106
 E  c1107
 E  c1108
 E  c1109
 E  c1110
 E  c1111
 E  c1112
 E  c1113
 E  c1114
 E  c1115
 E  c1116
 E  c1117
 E  c1118
 E  c1119
 E  c1120
 E  c1121
 E  c1122
 E  c1123
 E  c1124
 E  c1125
 E  c1126
 E  c1127
 E  c1128
 E  c1129
 E  c1130
 E  c1131
 E  c1132
 E  c1133
 E  c1134
 E  c1135
 E  c1136
 E  c1137
 E  c1138
 E  c1139
 E  c1140
 E  c1141
 E  c1142
 E  c1143
 E  c1144
 E  c1145
 E  c1146
 E  c1147
 E  c1148
 E  c1149
 E  c1150
 E  c1151
 E  c1152
 E  c1153
 E  c1154
 E  c1155
 E  c1156
 E  c1157
 E  c1158
 E  c1159
 E  c1160
 E  c1161
 E  c1162
 E  c1163
 E  c1164
 E  c1165
 E  c1166
 E  c1167
 E  c1168
 E  c1169
 E  c1170
 E  c1171
 E  c1172
 E  c1173
 E  c1174
 E  c1175
 E  c1176
 E  c1177
 E  c1178
 E  c1179
 E  c1180
 E  c1181
 E  c1182
 E  c1183
 E  c1184
 E  c1185
 E  c1186
 E  c1187
 E  c1188
 E  c1189
 E  c1190
 E  c1191
 E  c1192
 E  c1193
 E  c1194
 E  c1195
 E  c1196
 E  c1197
 E  c1198
 E  c1199
 E  c1200
 E  c1201
 E  c1202
 E  c1203
 E  c1204
 E  c1205
 E  c1206
 E  c1207
 E  c1208
 E  c1209
 E  c1210
 E  c1211
 E  c1212
 E  c1213
 E  c1214
 E  c1215
 E  c1216
 E  c1217
 E  c1218
 E  c1219
 E  c1220
 E  c1221
 E  c1222
 E  c1223
 E  c1224
 E  c1225
 E  c1226
 E  c1227
 E  c1228
 E  c1229
 E  c1230
 E  c1231
 E  c1232
 E  c1233
 E  c1234
 E  c1235
 E  c1236
 E  c1237
 E  c1238
 E  c1239
 E  c1240
 E  c1241
 E  c1242
 E  c1243
 E  c1244
 E  c1245
 E  c1246
 E  c1247
 E  c1248
 E  c1249
 E  c1250
 E  c1251
 E  c1252
 E  c1253
 E  c1254
 E  c1255
 E  c1256
 E  c1257
 E  c1258
 E  c1259
 E  c1260
 E  c1261
 E  c1262
 E  c1263
 E  c1264
 E  c1265
 E  c1266
 E  c1267
 E  c1268
 E  c1269
 E  c1270
 E  c1271
 E  c1272
 E  c1273
 E  c1274
 E  c1275
 E  c1276
 E  c1277
 E  c1278
 E  c1279
 E  c1280
 E  c1281
 E  c1282
 E  c1283
 E  c1284
 E  c1285
 E  c1286
 E  c1287
 E  c1288
 E  c1289
 E  c1290
 E  c1291
 E  c1292
 E  c1293
 E  c1294
 E  c1295
 E  c1296
 E  c1297
 E  c1298
 E  c1299
 E  c1300
 E  c1301
 E  c1302
 E  c1303
 E  c1304
 E  c1305
 E  c1306
 E  c1307
 E  c1308
 E  c1309
 E  c1310
 E  c1311
 E  c1312
 E  c1313
 E  c1314
 E  c1315
 E  c1316
 E  c1317
 E  c1318
 E  c1319
 E  c1320
 E  c1321
 E  c1322
 E  c1323
 E  c1324
 E  c1325
 E  c1326
 E  c1327
 E  c1328
 E  c1329
 E  c1330
 E  c1331
 E  c1332
 E  c1333
 E  c1334
 E  c1335
 E  c1336
 E  c1337
 E  c1338
 E  c1339
 E  c1340
 E  c1341
 E  c1342
 E  c1343
 E  c1344
 E  c1345
 E  c1346
 E  c1347
 E  c1348
 E  c1349
 E  c1350
 E  c1351
 E  c1352
 E  c1353
 E  c1354
 E  c1355
 E  c1356
 E  c1357
 E  c1358
 E  c1359
 E  c1360
 E  c1361
 E  c1362
 E  c1363
 E  c1364
 E  c1365
 E  c1366
 E  c1367
 E  c1368
 E  c1369
 E  c1370
 E  c1371
 E  c1372
 E  c1373
 E  c1374
 E  c1375
 E  c1376
 E  c1377
 E  c1378
 E  c1379
 E  c1380
 E  c1381
 E  c1382
 E  c1383
 E  c1384
 E  c1385
 E  c1386
 E  c1387
 E  c1388
 E  c1389
 E  c1390
 E  c1391
 E  c1392
 E  c1393
 E  c1394
 E  c1395
 E  c1396
 E  c1397
 E  c1398
 E  c1399
 E  c1400
 E  c1401
 E  c1402
 E  c1403
 E  c1404
 E  c1405
 E  c1406
 E  c1407
 E  c1408
 E  c1409
 E  c1410
 E  c1411
 E  c1412
 E  c1413
 E  c1414
 E  c1415
 E  c1416
 E  c1417
 E  c1418
 E  c1419
 E  c1420
 E  c1421
 E  c1422
 E  c1423
 E  c1424
 E  c1425
 E  c1426
 E  c1427
 E  c1428
 E  c1429
 E  c1430
 E  c1431
 E  c1432
 E  c1433
 E  c1434
 E  c1435
 E  c1436
 E  c1437
 E  c1438
 E  c1439
 E  c1440
 E  c1441
 E  c1442
 E  c1443
 E  c1444
 E  c1445
 E  c1446
 E  c1447
 E  c1448
 E  c1449
 E  c1450
 E  c1451
 E  c1452
 E  c1453
 E  c1454
 E  c1455
 E  c1456
 E  c1457
 E  c1458
 E  c1459
 E  c1460
 E  c1461
 E  c1462
 E  c1463
 E  c1464
 E  c1465
 E  c1466
 E  c1467
 E  c1468
 E  c1469
 E  c1470
 E  c1471
 E  c1472
 E  c1473
 E  c1474
 E  c1475
 E  c1476
 E  c1477
 E  c1478
 E  c1479
 E  c1480
 E  c1481
 E  c1482
 E  c1483
 E  c1484
 E  c1485
 E  c1486
 E  c1487
 E  c1488
 E  c1489
 E  c1490
 E  c1491
 E  c1492
 E  c1493
 E  c1494
 E  c1495
 E  c1496
 E  c1497
 E  c1498
 E  c1499
 E  c1500
 E  c1501
 E  c1502
 E  c1503
 E  c1504
 E  c1505
 E  c1506
 E  c1507
 E  c1508
 E  c1509
 E  c1510
 E  c1511
 E  c1512
 E  c1513
 E  c1514
 E  c1515
 E  c1516
 E  c1517
 E  c1518
 E  c1519
 E  c1520
 E  c1521
 E  c1522
 E  c1523
 E  c1524
 E  c1525
 E  c1526
 E  c1527
 E  c1528
 E  c1529
 E  c1530
 E  c1531
 E  c1532
 E  c1533
 E  c1534
 E  c1535
 E  c1536
 E  c1537
 E  c1538
 E  c1539
 E  c1540
 E  c1541
 E  c1542
 E  c1543
 E  c1544
 E  c1545
 E  c1546
 E  c1547
 E  c1548
 E  c1549
 E  c1550
 E  c1551
 E  c1552
 E  c1553
 E  c1554
 E  c1555
 E  c1556
 E  c1557
 E  c1558
 E  c1559
 E  c1560
 E  c1561
 E  c1562
 E  c1563
 E  c1564
 E  c1565
 E  c1566
 E  c1567
 E  c1568
 E  c1569
 E  c1570
 E  c1571
 E  c1572
 E  c1573
 E  c1574
 E  c1575
 E  c1576
 E  c1577
 E  c1578
 E  c1579
 E  c1580
 E  c1581
 E  c1582
 E  c1583
 E  c1584
 E  c1585
 E  c1586
 E  c1587
 E  c1588
 E  c1589
 E  c1590
 E  c1591
 E  c1592
 E  c1593
 E  c1594
 E  c1595
 E  c1596
 E  c1597
 E  c1598
 E  c1599
 E  c1600
 E  c1601
 E  c1602
 E  c1603
 E  c1604
 E  c1605
 E  c1606
 E  c1607
 E  c1608
 E  c1609
 E  c1610
 E  c1611
 E  c1612
 E  c1613
 E  c1614
 E  c1615
 E  c1616
 E  c1617
 E  c1618
 E  c1619
 E  c1620
 E  c1621
 E  c1622
 E  c1623
 E  c1624
 E  c1625
 E  c1626
 E  c1627
 E  c1628
 E  c1629
 E  c1630
 E  c1631
 E  c1632
 E  c1633
 E  c1634
 E  c1635
 E  c1636
 E  c1637
 E  c1638
 E  c1639
 E  c1640
 E  c1641
 E  c1642
 E  c1643
 E  c1644
 E  c1645
 E  c1646
 E  c1647
 E  c1648
 E  c1649
 E  c1650
 E  c1651
 E  c1652
 E  c1653
 E  c1654
 E  c1655
 E  c1656
 E  c1657
 E  c1658
 E  c1659
 E  c1660
 E  c1661
 E  c1662
 E  c1663
 E  c1664
 E  c1665
 E  c1666
 E  c1667
 E  c1668
 E  c1669
 E  c1670
 E  c1671
 E  c1672
 E  c1673
 E  c1674
 E  c1675
 E  c1676
 E  c1677
 E  c1678
 E  c1679
 E  c1680
 E  c1681
 E  c1682
 E  c1683
 E  c1684
 E  c1685
 E  c1686
 E  c1687
 E  c1688
 E  c1689
 E  c1690
 E  c1691
 E  c1692
 E  c1693
 E  c1694
 E  c1695
 E  c1696
 E  c1697
 E  c1698
 E  c1699
 E  c1700
 E  c1701
 E  c1702
 E  c1703
 E  c1704
 E  c1705
 E  c1706
 E  c1707
 E  c1708
 E  c1709
 E  c1710
 E  c1711
 E  c1712
 E  c1713
 E  c1714
 E  c1715
 E  c1716
 E  c1717
 E  c1718
 E  c1719
 E  c1720
 E  c1721
 E  c1722
 E  c1723
 E  c1724
 E  c1725
 E  c1726
 E  c1727
 E  c1728
 E  c1729
 E  c1730
 E  c1731
 E  c1732
 E  c1733
 E  c1734
 E  c1735
 E  c1736
 E  c1737
 E  c1738
 E  c1739
 E  c1740
 E  c1741
 E  c1742
 E  c1743
 E  c1744
 E  c1745
 E  c1746
 E  c1747
 E  c1748
 E  c1749
 E  c1750
 E  c1751
 E  c1752
 E  c1753
 E  c1754
 E  c1755
 E  c1756
 E  c1757
 E  c1758
 E  c1759
 E  c1760
 E  c1761
 E  c1762
 E  c1763
 E  c1764
 E  c1765
 E  c1766
 E  c1767
 E  c1768
 E  c1769
 E  c1770
 E  c1771
 E  c1772
 E  c1773
 E  c1774
 E  c1775
 E  c1776
 E  c1777
 E  c1778
 E  c1779
 E  c1780
 E  c1781
 E  c1782
 E  c1783
 E  c1784
 E  c1785
 E  c1786
 E  c1787
 E  c1788
 E  c1789
 E  c1790
 E  c1791
 E  c1792
 E  c1793
 E  c1794
 E  c1795
 E  c1796
 E  c1797
 E  c1798
 E  c1799
 E  c1800
 E  c1801
 E  c1802
 E  c1803
 E  c1804
 E  c1805
 E  c1806
 E  c1807
 E  c1808
 E  c1809
 E  c1810
 E  c1811
 E  c1812
 E  c1813
 E  c1814
 E  c1815
 E  c1816
 E  c1817
 E  c1818
 E  c1819
 E  c1820
 E  c1821
 E  c1822
 E  c1823
 E  c1824
 E  c1825
 E  c1826
 E  c1827
 E  c1828
 E  c1829
 E  c1830
 E  c1831
 E  c1832
 E  c1833
 E  c1834
 E  c1835
 E  c1836
 E  c1837
 E  c1838
 E  c1839
 E  c1840
 E  c1841
 E  c1842
 E  c1843
 E  c1844
 E  c1845
 E  c1846
 E  c1847
 E  c1848
 E  c1849
 E  c1850
 E  c1851
 E  c1852
 E  c1853
 E  c1854
 E  c1855
 E  c1856
 E  c1857
 E  c1858
 E  c1859
 E  c1860
 E  c1861
 E  c1862
 E  c1863
 E  c1864
 E  c1865
 E  c1866
 E  c1867
 E  c1868
 E  c1869
 E  c1870
 E  c1871
 E  c1872
 E  c1873
 E  c1874
 E  c1875
 E  c1876
 E  c1877
 E  c1878
 E  c1879
 E  c1880
 E  c1881
 E  c1882
 E  c1883
 E  c1884
 E  c1885
 E  c1886
 E  c1887
 E  c1888
 E  c1889
 E  c1890
 E  c1891
 E  c1892
 E  c1893
 E  c1894
 E  c1895
 E  c1896
 E  c1897
 E  c1898
 E  c1899
 E  c1900
 E  c1901
 E  c1902
 E  c1903
 E  c1904
 E  c1905
 E  c1906
 E  c1907
 E  c1908
 E  c1909
 E  c1910
 E  c1911
 E  c1912
 E  c1913
 E  c1914
 E  c1915
 E  c1916
 E  c1917
 E  c1918
 E  c1919
 E  c1920
 E  c1921
 E  c1922
 E  c1923
 E  c1924
 E  c1925
 E  c1926
 E  c1927
 E  c1928
 E  c1929
 E  c1930
 E  c1931
 E  c1932
 E  c1933
 E  c1934
 E  c1935
 E  c1936
 E  c1937
 E  c1938
 E  c1939
 E  c1940
 E  c1941
 E  c1942
 E  c1943
 E  c1944
 E  c1945
 E  c1946
 E  c1947
 E  c1948
 E  c1949
 E  c1950
 E  c1951
 E  c1952
 E  c1953
 E  c1954
 E  c1955
 E  c1956
 E  c1957
 E  c1958
 E  c1959
 E  c1960
 E  c1961
 E  c1962
 E  c1963
 E  c1964
 E  c1965
 E  c1966
 E  c1967
 E  c1968
 E  c1969
 E  c1970
 E  c1971
 E  c1972
 E  c1973
 E  c1974
 E  c1975
 E  c1976
 E  c1977
 E  c1978
 E  c1979
 E  c1980
COLUMNS
    x[1]      c1_1      1
    x[1]      OBJ       1
    x[2]      c2_1      1
    x[2]      OBJ       1
    x[3]      c3_1      1
    x[3]      OBJ       1
    x[4]      c4_1      1
    x[4]      OBJ       1
    x[5]      c5_1      1
    x[5]      OBJ       1
    x[6]      c6_1      1
    x[6]      OBJ       1
    x[7]      c7_1      1
    x[7]      OBJ       1
    x[8]      c8_1      1
    x[8]      OBJ       1
    x[9]      c9_1      1
    x[9]      OBJ       1
    x[10]     c10_1     1
    x[10]     OBJ       1
    x[11]     c11_1     1
    x[11]     OBJ       1
    x[12]     c12_1     1
    x[12]     OBJ       1
    x[13]     c13_1     1
    x[13]     OBJ       1
    x[14]     c14_1     1
    x[14]     OBJ       1
    x[15]     c15_1     1
    x[15]     OBJ       1
    x[16]     c16_1     1
    x[16]     OBJ       1
    x[17]     c17_1     1
    x[17]     OBJ       1
    x[18]     c18_1     1
    x[18]     OBJ       1
    x[19]     c19_1     1
    x[19]     OBJ       1
    x[20]     c20_1     1
    x[20]     OBJ       1
    x[21]     c21_1     1
    x[21]     OBJ       1
    x[22]     c22_1     1
    x[22]     OBJ       1
    x[23]     c23_1     1
    x[23]     OBJ       1
    x[24]     c24_1     1
    x[24]     OBJ       1
    x[25]     c25_1     1
    x[25]     OBJ       1
    x[26]     c26_1     1
    x[26]     OBJ       1
    x[27]     c27_1     1
    x[27]     OBJ       1
    x[28]     c28_1     1
    x[28]     OBJ       1
    x[29]     c29_1     1
    x[29]     OBJ       1
    x[30]     c30_1     1
    x[30]     OBJ       1
    x[31]     c31_1     1
    x[31]     OBJ       1
    x[32]     c32_1     1
    x[32]     OBJ       1
    x[33]     c33_1     1
    x[33]     OBJ       1
    x[34]     c34_1     1
    x[34]     OBJ       1
    x[35]     c35_1     1
    x[35]     OBJ       1
    x[36]     c36_1     1
    x[36]     OBJ       1
    x[37]     c37_1     1
    x[37]     OBJ       1
    x[38]     c38_1     1
    x[38]     OBJ       1
    x[39]     c39_1     1
    x[39]     OBJ       1
    x[40]     c40_1     1
    x[40]     OBJ       1
    x[41]     c41_1     1
    x[41]     OBJ       1
    x[42]     c42_1     1
    x[42]     OBJ       1
    x[43]     c43_1     1
    x[43]     OBJ       1
    x[44]     c44_1     1
    x[44]     OBJ       1
    x[45]     c45_1     1
    x[45]     OBJ       1
    x[46]     c46_1     1
    x[46]     OBJ       1
    x[47]     c47_1     1
    x[47]     OBJ       1
    x[48]     c48_1     1
    x[48]     OBJ       1
    x[49]     c49_1     1
    x[49]     OBJ       1
    x[50]     c50_1     1
    x[50]     OBJ       1
    x[51]     c1        1
    x[51]     c2        -1
    x[52]     c2        1
    x[52]     c3        -1
    x[53]     c3        1
    x[53]     c4        -1
    x[53]     c1522     -1
    x[53]     c1527     -1
    x[53]     c1530     -1
    x[53]     c1532     -1
    x[53]     c1534     -1
    x[53]     c1537     -1
    x[53]     c1540     -1
    x[53]     c1542     -1
    x[53]     c1544     -1
    x[53]     c1547     -1
    x[53]     c1550     -1
    x[53]     c1552     -1
    x[53]     c1554     -1
    x[53]     c1557     -1
    x[53]     c1560     -1
    x[53]     c1562     -1
    x[53]     c1564     -1
    x[53]     c1567     -1
    x[53]     c1570     -1
    x[53]     c1572     -1
    x[53]     c1574     -1
    x[53]     c1577     -1
    x[53]     c1580     -1
    x[53]     c1582     -1
    x[53]     c1584     -1
    x[53]     c1587     -1
    x[53]     c1590     -1
    x[53]     c1592     -1
    x[53]     c1594     -1
    x[53]     c1597     -1
    x[53]     c1600     -1
    x[53]     c1602     -1
    x[53]     c1604     -1
    x[53]     c1607     -1
    x[53]     c1610     -1
    x[53]     c1612     -1
    x[53]     c1614     -1
    x[53]     c1617     -1
    x[53]     c1620     -1
    x[53]     c1622     -1
    x[53]     c1625     -1
    x[53]     c1628     -1
    x[53]     c1630     -1
    x[53]     c1633     -1
    x[53]     c1636     -1
    x[53]     c1638     -1
    x[53]     c1641     -1
    x[53]     c1644     -1
    x[53]     c1647     -1
    x[53]     c1650     -1
    x[53]     c1653     -1
    x[53]     c1656     -1
    x[53]     c1659     -1
    x[53]     c1662     -1
    x[53]     c1665     -1
    x[53]     c1668     -1
    x[53]     c1671     -1
    x[53]     c1674     -1
    x[53]     c1677     -1
    x[53]     c1680     -1
    x[53]     c1683     -1
    x[53]     c1686     -1
    x[53]     c1689     -1
    x[53]     c1692     -1
    x[53]     c1695     -1
    x[53]     c1698     -1
    x[53]     c1701     -1
    x[53]     c1704     -1
    x[53]     c1707     -1
    x[53]     c1710     -1
    x[53]     c1712     -1
    x[53]     c1715     -1
    x[53]     c1718     -1
    x[53]     c1721     -1
    x[53]     c1724     -1
    x[53]     c1727     -1
    x[53]     c1730     -1
    x[53]     c1733     -1
    x[53]     c1736     -1
    x[53]     c1739     -1
    x[53]     c1742     -1
    x[53]     c1745     -1
    x[53]     c1748     -1
    x[53]     c1751     -1
    x[53]     c1754     -1
    x[53]     c1757     -1
    x[53]     c1760     -1
    x[53]     c1762     -1
    x[53]     c1765     -1
    x[53]     c1767     -1
    x[53]     c1770     -1
    x[53]     c1772     -1
    x[53]     c1775     -1
    x[53]     c1777     -1
    x[53]     c1780     -1
    x[53]     c1782     -1
    x[53]     c1785     -1
    x[53]     c1787     -1
    x[53]     c1790     -1
    x[53]     c1793     -1
    x[53]     c1796     -1
    x[53]     c1799     -1
    x[53]     c1802     -1
    x[53]     c1805     -1
    MARKER    'MARKER'                 'INTORG'
    x[54]     c4        -2
    x[54]     c28       2
    x[54]     c226      -3
    x[54]     c276      1
    x[54]     c1524     2
    x[54]     c1526     2
    MARKER    'MARKER'                 'INTEND'
    x[55]     c4        1
    x[55]     c5        -1
    x[55]     c1524     -1
    x[55]     c1526     -1
    MARKER    'MARKER'                 'INTORG'
    x[56]     c5        -4
    x[56]     c21       4
    x[56]     c235      -4
    x[56]     c285      1
    x[57]     c5        -2
    x[57]     c29       2
    x[57]     c226      -4
    x[57]     c276      1
    x[58]     c5        -5
    x[58]     c38       5
    x[58]     c215      -4
    x[58]     c265      1
    MARKER    'MARKER'                 'INTEND'
    x[59]     c5        1
    x[59]     c6        -1
    MARKER    'MARKER'                 'INTORG'
    x[60]     c6        -4
    x[60]     c22       4
    x[60]     c235      -5
    x[60]     c285      1
    x[61]     c6        -2
    x[61]     c30       2
    x[61]     c226      -5
    x[61]     c276      1
    x[62]     c6        -5
    x[62]     c39       5
    x[62]     c215      -5
    x[62]     c265      1
    MARKER    'MARKER'                 'INTEND'
    x[63]     c6        1
    x[63]     c7        -1
    MARKER    'MARKER'                 'INTORG'
    x[64]     c7        -4
    x[64]     c23       4
    x[64]     c235      -6
    x[64]     c285      1
    x[65]     c7        -2
    x[65]     c31       2
    x[65]     c226      -6
    x[65]     c276      1
    x[66]     c7        -5
    x[66]     c40       5
    x[66]     c215      -6
    x[66]     c265      1
    MARKER    'MARKER'                 'INTEND'
    x[67]     c7        1
    x[67]     c8        -1
    MARKER    'MARKER'                 'INTORG'
    x[68]     c8        -4
    x[68]     c24       4
    x[68]     c235      -7
    x[68]     c285      1
    x[69]     c8        -2
    x[69]     c32       2
    x[69]     c226      -7
    x[69]     c276      1
    x[70]     c8        -5
    x[70]     c41       5
    x[70]     c215      -7
    x[70]     c265      1
    MARKER    'MARKER'                 'INTEND'
    x[71]     c8        1
    x[71]     c9        -1
    MARKER    'MARKER'                 'INTORG'
    x[72]     c9        -4
    x[72]     c25       4
    x[72]     c235      -8
    x[72]     c285      1
    x[73]     c9        -2
    x[73]     c33       2
    x[73]     c226      -8
    x[73]     c276      1
    x[74]     c9        -5
    x[74]     c42       5
    x[74]     c215      -8
    x[74]     c265      1
    MARKER    'MARKER'                 'INTEND'
    x[75]     c9        1
    x[75]     c10       -1
    MARKER    'MARKER'                 'INTORG'
    x[76]     c10       -4
    x[76]     c26       4
    x[76]     c235      -9
    x[76]     c285      1
    x[77]     c10       -2
    x[77]     c34       2
    x[77]     c226      -9
    x[77]     c276      1
    x[78]     c10       -5
    x[78]     c43       5
    x[78]     c215      -9
    x[78]     c265      1
    x[79]     c10       -4
    x[79]     c14       4
    x[79]     c211      -9
    x[79]     c261      1
    MARKER    'MARKER'                 'INTEND'
    x[80]     c10       1
    x[80]     c11       -1
    MARKER    'MARKER'                 'INTORG'
    x[81]     c11       -4
    x[81]     c27       4
    x[81]     c235      -10
    x[81]     c285      1
    x[82]     c11       -2
    x[82]     c35       2
    x[82]     c226      -10
    x[82]     c276      1
    x[83]     c11       -5
    x[83]     c44       5
    x[83]     c215      -10
    x[83]     c265      1
    x[84]     c11       -4
    x[84]     c15       4
    x[84]     c211      -10
    x[84]     c261      1
    MARKER    'MARKER'                 'INTEND'
    x[85]     c11       1
    x[85]     c12       -1
    MARKER    'MARKER'                 'INTORG'
    x[86]     c12       -4
    x[86]     c28       4
    x[86]     c235      -11
    x[86]     c285      1
    x[87]     c12       -2
    x[87]     c36       2
    x[87]     c226      -11
    x[87]     c276      1
    x[88]     c12       -5
    x[88]     c45       5
    x[88]     c215      -11
    x[88]     c265      1
    x[89]     c12       -4
    x[89]     c16       4
    x[89]     c211      -11
    x[89]     c261      1
    MARKER    'MARKER'                 'INTEND'
    x[90]     c12       1
    x[90]     c13       -1
    MARKER    'MARKER'                 'INTORG'
    x[91]     c13       -1
    x[91]     c46       1
    x[91]     c243      -12
    x[91]     c293      1
    x[92]     c13       -4
    x[92]     c29       4
    x[92]     c235      -12
    x[92]     c285      1
    x[93]     c13       -2
    x[93]     c37       2
    x[93]     c226      -12
    x[93]     c276      1
    x[94]     c13       -5
    x[94]     c46       5
    x[94]     c215      -12
    x[94]     c265      1
    x[95]     c13       -4
    x[95]     c17       4
    x[95]     c211      -12
    x[95]     c261      1
    MARKER    'MARKER'                 'INTEND'
    x[96]     c13       1
    x[96]     c14       -1
    MARKER    'MARKER'                 'INTORG'
    x[97]     c14       -1
    x[97]     c47       1
    x[97]     c243      -13
    x[97]     c293      1
    x[98]     c14       -4
    x[98]     c30       4
    x[98]     c235      -13
    x[98]     c285      1
    x[99]     c14       -2
    x[99]     c38       2
    x[99]     c226      -13
    x[99]     c276      1
    x[100]    c14       -3
    x[100]    c33       3
    x[100]    c220      -13
    x[100]    c270      1
    x[101]    c14       -5
    x[101]    c47       5
    x[101]    c215      -13
    x[101]    c265      1
    x[102]    c14       -4
    x[102]    c18       4
    x[102]    c211      -13
    x[102]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[103]    c14       1
    x[103]    c15       -1
    MARKER    'MARKER'                 'INTORG'
    x[104]    c15       -1
    x[104]    c48       1
    x[104]    c243      -14
    x[104]    c293      1
    x[105]    c15       -5
    x[105]    c62       5
    x[105]    c238      -14
    x[105]    c288      1
    x[106]    c15       -4
    x[106]    c31       4
    x[106]    c235      -14
    x[106]    c285      1
    x[107]    c15       -2
    x[107]    c39       2
    x[107]    c226      -14
    x[107]    c276      1
    x[108]    c15       -3
    x[108]    c34       3
    x[108]    c220      -14
    x[108]    c270      1
    x[109]    c15       -5
    x[109]    c48       5
    x[109]    c215      -14
    x[109]    c265      1
    x[110]    c15       -4
    x[110]    c19       4
    x[110]    c211      -14
    x[110]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[111]    c15       1
    x[111]    c16       -1
    MARKER    'MARKER'                 'INTORG'
    x[112]    c16       -1
    x[112]    c49       1
    x[112]    c243      -15
    x[112]    c293      1
    x[113]    c16       -5
    x[113]    c63       5
    x[113]    c238      -15
    x[113]    c288      1
    x[114]    c16       -4
    x[114]    c32       4
    x[114]    c235      -15
    x[114]    c285      1
    x[115]    c16       -2
    x[115]    c40       2
    x[115]    c226      -15
    x[115]    c276      1
    x[116]    c16       -3
    x[116]    c35       3
    x[116]    c220      -15
    x[116]    c270      1
    x[117]    c16       -5
    x[117]    c49       5
    x[117]    c215      -15
    x[117]    c265      1
    x[118]    c16       -4
    x[118]    c20       4
    x[118]    c211      -15
    x[118]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[119]    c16       1
    x[119]    c17       -1
    MARKER    'MARKER'                 'INTORG'
    x[120]    c17       -1
    x[120]    c50       1
    x[120]    c243      -16
    x[120]    c293      1
    x[121]    c17       -5
    x[121]    c64       5
    x[121]    c238      -16
    x[121]    c288      1
    x[122]    c17       -4
    x[122]    c33       4
    x[122]    c235      -16
    x[122]    c285      1
    x[123]    c17       -2
    x[123]    c41       2
    x[123]    c226      -16
    x[123]    c276      1
    x[124]    c17       -3
    x[124]    c36       3
    x[124]    c220      -16
    x[124]    c270      1
    x[125]    c17       -5
    x[125]    c50       5
    x[125]    c215      -16
    x[125]    c265      1
    x[126]    c17       -4
    x[126]    c21       4
    x[126]    c211      -16
    x[126]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[127]    c17       1
    x[127]    c18       -1
    MARKER    'MARKER'                 'INTORG'
    x[128]    c18       -1
    x[128]    c51       1
    x[128]    c243      -17
    x[128]    c293      1
    x[129]    c18       -5
    x[129]    c65       5
    x[129]    c238      -17
    x[129]    c288      1
    x[130]    c18       -4
    x[130]    c34       4
    x[130]    c235      -17
    x[130]    c285      1
    x[131]    c18       -2
    x[131]    c42       2
    x[131]    c226      -17
    x[131]    c276      1
    x[132]    c18       -3
    x[132]    c37       3
    x[132]    c220      -17
    x[132]    c270      1
    x[133]    c18       -5
    x[133]    c51       5
    x[133]    c215      -17
    x[133]    c265      1
    x[134]    c18       -4
    x[134]    c22       4
    x[134]    c211      -17
    x[134]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[135]    c18       1
    x[135]    c19       -1
    MARKER    'MARKER'                 'INTORG'
    x[136]    c19       -1
    x[136]    c52       1
    x[136]    c243      -18
    x[136]    c293      1
    x[137]    c19       -5
    x[137]    c66       5
    x[137]    c238      -18
    x[137]    c288      1
    x[138]    c19       -4
    x[138]    c35       4
    x[138]    c235      -18
    x[138]    c285      1
    x[139]    c19       -2
    x[139]    c43       2
    x[139]    c226      -18
    x[139]    c276      1
    x[140]    c19       -3
    x[140]    c38       3
    x[140]    c220      -18
    x[140]    c270      1
    x[141]    c19       -5
    x[141]    c52       5
    x[141]    c215      -18
    x[141]    c265      1
    x[142]    c19       -4
    x[142]    c23       4
    x[142]    c211      -18
    x[142]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[143]    c19       1
    x[143]    c20       -1
    MARKER    'MARKER'                 'INTORG'
    x[144]    c20       -1
    x[144]    c53       1
    x[144]    c243      -19
    x[144]    c293      1
    x[145]    c20       -5
    x[145]    c67       5
    x[145]    c238      -19
    x[145]    c288      1
    x[146]    c20       -4
    x[146]    c36       4
    x[146]    c235      -19
    x[146]    c285      1
    x[147]    c20       -2
    x[147]    c44       2
    x[147]    c226      -19
    x[147]    c276      1
    x[148]    c20       -3
    x[148]    c39       3
    x[148]    c220      -19
    x[148]    c270      1
    x[149]    c20       -5
    x[149]    c53       5
    x[149]    c215      -19
    x[149]    c265      1
    x[150]    c20       -4
    x[150]    c24       4
    x[150]    c211      -19
    x[150]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[151]    c20       1
    x[151]    c21       -1
    MARKER    'MARKER'                 'INTORG'
    x[152]    c21       -1
    x[152]    c54       1
    x[152]    c243      -20
    x[152]    c293      1
    x[153]    c21       -5
    x[153]    c68       5
    x[153]    c238      -20
    x[153]    c288      1
    x[154]    c21       -4
    x[154]    c37       4
    x[154]    c235      -20
    x[154]    c285      1
    x[155]    c21       -2
    x[155]    c45       2
    x[155]    c226      -20
    x[155]    c276      1
    x[156]    c21       -3
    x[156]    c40       3
    x[156]    c220      -20
    x[156]    c270      1
    x[157]    c21       -5
    x[157]    c54       5
    x[157]    c215      -20
    x[157]    c265      1
    x[158]    c21       -4
    x[158]    c25       4
    x[158]    c211      -20
    x[158]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[159]    c21       1
    x[159]    c22       -1
    MARKER    'MARKER'                 'INTORG'
    x[160]    c22       -1
    x[160]    c55       1
    x[160]    c243      -21
    x[160]    c293      1
    x[161]    c22       -5
    x[161]    c69       5
    x[161]    c238      -21
    x[161]    c288      1
    x[162]    c22       -4
    x[162]    c38       4
    x[162]    c235      -21
    x[162]    c285      1
    x[163]    c22       -2
    x[163]    c46       2
    x[163]    c226      -21
    x[163]    c276      1
    x[164]    c22       -2
    x[164]    c44       2
    x[164]    c223      -21
    x[164]    c273      1
    x[165]    c22       -3
    x[165]    c41       3
    x[165]    c220      -21
    x[165]    c270      1
    x[166]    c22       -5
    x[166]    c55       5
    x[166]    c215      -21
    x[166]    c265      1
    x[167]    c22       -4
    x[167]    c26       4
    x[167]    c211      -21
    x[167]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[168]    c22       1
    x[168]    c23       -1
    MARKER    'MARKER'                 'INTORG'
    x[169]    c23       -1
    x[169]    c56       1
    x[169]    c243      -22
    x[169]    c293      1
    x[170]    c23       -5
    x[170]    c70       5
    x[170]    c238      -22
    x[170]    c288      1
    x[171]    c23       -4
    x[171]    c40       4
    x[171]    c237      -22
    x[171]    c287      1
    x[172]    c23       -4
    x[172]    c39       4
    x[172]    c235      -22
    x[172]    c285      1
    x[173]    c23       -2
    x[173]    c47       2
    x[173]    c226      -22
    x[173]    c276      1
    x[174]    c23       -2
    x[174]    c45       2
    x[174]    c223      -22
    x[174]    c273      1
    x[175]    c23       -3
    x[175]    c42       3
    x[175]    c220      -22
    x[175]    c270      1
    x[176]    c23       -5
    x[176]    c56       5
    x[176]    c215      -22
    x[176]    c265      1
    x[177]    c23       -4
    x[177]    c27       4
    x[177]    c211      -22
    x[177]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[178]    c23       1
    x[178]    c24       -1
    MARKER    'MARKER'                 'INTORG'
    x[179]    c24       -1
    x[179]    c57       1
    x[179]    c243      -23
    x[179]    c293      1
    x[180]    c24       -5
    x[180]    c71       5
    x[180]    c238      -23
    x[180]    c288      1
    x[181]    c24       -4
    x[181]    c41       4
    x[181]    c237      -23
    x[181]    c287      1
    x[182]    c24       -4
    x[182]    c40       4
    x[182]    c235      -23
    x[182]    c285      1
    x[183]    c24       -2
    x[183]    c48       2
    x[183]    c226      -23
    x[183]    c276      1
    x[184]    c24       -2
    x[184]    c46       2
    x[184]    c223      -23
    x[184]    c273      1
    x[185]    c24       -3
    x[185]    c43       3
    x[185]    c220      -23
    x[185]    c270      1
    x[186]    c24       -5
    x[186]    c57       5
    x[186]    c215      -23
    x[186]    c265      1
    x[187]    c24       -4
    x[187]    c28       4
    x[187]    c211      -23
    x[187]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[188]    c24       1
    x[188]    c25       -1
    MARKER    'MARKER'                 'INTORG'
    x[189]    c25       -1
    x[189]    c58       1
    x[189]    c243      -24
    x[189]    c293      1
    x[190]    c25       -5
    x[190]    c72       5
    x[190]    c238      -24
    x[190]    c288      1
    x[191]    c25       -4
    x[191]    c42       4
    x[191]    c237      -24
    x[191]    c287      1
    x[192]    c25       -4
    x[192]    c41       4
    x[192]    c235      -24
    x[192]    c285      1
    x[193]    c25       -2
    x[193]    c49       2
    x[193]    c226      -24
    x[193]    c276      1
    x[194]    c25       -2
    x[194]    c47       2
    x[194]    c223      -24
    x[194]    c273      1
    x[195]    c25       -3
    x[195]    c44       3
    x[195]    c220      -24
    x[195]    c270      1
    x[196]    c25       -5
    x[196]    c58       5
    x[196]    c215      -24
    x[196]    c265      1
    x[197]    c25       -4
    x[197]    c29       4
    x[197]    c211      -24
    x[197]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[198]    c25       1
    x[198]    c26       -1
    MARKER    'MARKER'                 'INTORG'
    x[199]    c26       -1
    x[199]    c59       1
    x[199]    c243      -25
    x[199]    c293      1
    x[200]    c26       -5
    x[200]    c73       5
    x[200]    c238      -25
    x[200]    c288      1
    x[201]    c26       -4
    x[201]    c43       4
    x[201]    c237      -25
    x[201]    c287      1
    x[202]    c26       -4
    x[202]    c42       4
    x[202]    c235      -25
    x[202]    c285      1
    x[203]    c26       -2
    x[203]    c50       2
    x[203]    c226      -25
    x[203]    c276      1
    x[204]    c26       -2
    x[204]    c48       2
    x[204]    c223      -25
    x[204]    c273      1
    x[205]    c26       -3
    x[205]    c45       3
    x[205]    c220      -25
    x[205]    c270      1
    x[206]    c26       -5
    x[206]    c59       5
    x[206]    c215      -25
    x[206]    c265      1
    x[207]    c26       -4
    x[207]    c30       4
    x[207]    c211      -25
    x[207]    c261      1
    MARKER    'MARKER'                 'INTEND'
    x[208]    c26       1
    x[208]    c27       -1
    MARKER    'MARKER'                 'INTORG'
    x[209]    c27       -3
    x[209]    c67       3
    x[209]    c247      -26
    x[209]    c297      1
    x[210]    c27       -1
    x[210]    c60       1
    x[210]    c243      -26
    x[210]    c293      1
    x[211]    c27       -5
    x[211]    c74       5
    x[211]    c238      -26
    x[211]    c288      1
    x[212]    c27       -4
    x[212]    c44       4
    x[212]    c237      -26
    x[212]    c287      1
    x[213]    c27       -4
    x[213]    c43       4
    x[213]    c235      -26
    x[213]    c285      1
    x[214]    c27       -2
    x[214]    c51       2
    x[214]    c226      -26
    x[214]    c276      1
    x[215]    c27       -2
    x[215]    c49       2
    x[215]    c223      -26
    x[215]    c273      1
    x[216]    c27       -3
    x[216]    c46       3
    x[216]    c220      -26
    x[216]    c270      1
    x[217]    c27       -5
    x[217]    c60       5
    x[217]    c215      -26
    x[217]    c265      1
    MARKER    'MARKER'                 'INTEND'
    x[218]    c27       1
    x[218]    c28       -1
    MARKER    'MARKER'                 'INTORG'
    x[219]    c28       -3
    x[219]    c68       3
    x[219]    c247      -27
    x[219]    c297      1
    x[220]    c28       -1
    x[220]    c61       1
    x[220]    c243      -27
    x[220]    c293      1
    x[221]    c28       -5
    x[221]    c75       5
    x[221]    c238      -27
    x[221]    c288      1
    x[222]    c28       -4
    x[222]    c45       4
    x[222]    c237      -27
    x[222]    c287      1
    x[223]    c28       -4
    x[223]    c44       4
    x[223]    c235      -27
    x[223]    c285      1
    x[224]    c28       -2
    x[224]    c52       2
    x[224]    c226      -27
    x[224]    c276      1
    x[225]    c28       -2
    x[225]    c50       2
    x[225]    c223      -27
    x[225]    c273      1
    x[226]    c28       -3
    x[226]    c47       3
    x[226]    c220      -27
    x[226]    c270      1
    x[227]    c28       -5
    x[227]    c61       5
    x[227]    c215      -27
    x[227]    c265      1
    MARKER    'MARKER'                 'INTEND'
    x[228]    c28       1
    x[228]    c29       -1
    MARKER    'MARKER'                 'INTORG'
    x[229]    c29       -3
    x[229]    c69       3
    x[229]    c247      -28
    x[229]    c297      1
    x[230]    c29       -1
    x[230]    c62       1
    x[230]    c243      -28
    x[230]    c293      1
    x[231]    c29       -5
    x[231]    c76       5
    x[231]    c238      -28
    x[231]    c288      1
    x[232]    c29       -4
    x[232]    c46       4
    x[232]    c237      -28
    x[232]    c287      1
    x[233]    c29       -4
    x[233]    c45       4
    x[233]    c235      -28
    x[233]    c285      1
    x[234]    c29       -2
    x[234]    c53       2
    x[234]    c226      -28
    x[234]    c276      1
    x[235]    c29       -2
    x[235]    c51       2
    x[235]    c223      -28
    x[235]    c273      1
    x[236]    c29       -3
    x[236]    c48       3
    x[236]    c220      -28
    x[236]    c270      1
    x[237]    c29       -5
    x[237]    c62       5
    x[237]    c215      -28
    x[237]    c265      1
    MARKER    'MARKER'                 'INTEND'
    x[238]    c29       1
    x[238]    c30       -1
    MARKER    'MARKER'                 'INTORG'
    x[239]    c30       -3
    x[239]    c70       3
    x[239]    c247      -29
    x[239]    c297      1
    x[240]    c30       -1
    x[240]    c63       1
    x[240]    c243      -29
    x[240]    c293      1
    x[241]    c30       -5
    x[241]    c77       5
    x[241]    c238      -29
    x[241]    c288      1
    x[242]    c30       -4
    x[242]    c47       4
    x[242]    c237      -29
    x[242]    c287      1
    x[243]    c30       -4
    x[243]    c46       4
    x[243]    c235      -29
    x[243]    c285      1
    x[244]    c30       -2
    x[244]    c54       2
    x[244]    c226      -29
    x[244]    c276      1
    x[245]    c30       -2
    x[245]    c52       2
    x[245]    c223      -29
    x[245]    c273      1
    x[246]    c30       -3
    x[246]    c49       3
    x[246]    c220      -29
    x[246]    c270      1
    x[247]    c30       -5
    x[247]    c63       5
    x[247]    c215      -29
    x[247]    c265      1
    MARKER    'MARKER'                 'INTEND'
    x[248]    c30       1
    x[248]    c31       -1
    MARKER    'MARKER'                 'INTORG'
    x[249]    c31       -3
    x[249]    c71       3
    x[249]    c247      -30
    x[249]    c297      1
    x[250]    c31       -1
    x[250]    c64       1
    x[250]    c243      -30
    x[250]    c293      1
    x[251]    c31       -3
    x[251]    c72       3
    x[251]    c241      -30
    x[251]    c291      1
    x[252]    c31       -5
    x[252]    c78       5
    x[252]    c238      -30
    x[252]    c288      1
    x[253]    c31       -4
    x[253]    c48       4
    x[253]    c237      -30
    x[253]    c287      1
    x[254]    c31       -4
    x[254]    c47       4
    x[254]    c235      -30
    x[254]    c285      1
    x[255]    c31       -2
    x[255]    c55       2
    x[255]    c226      -30
    x[255]    c276      1
    x[256]    c31       -2
    x[256]    c53       2
    x[256]    c223      -30
    x[256]    c273      1
    x[257]    c31       -3
    x[257]    c50       3
    x[257]    c220      -30
    x[257]    c270      1
    x[258]    c31       -5
    x[258]    c64       5
    x[258]    c215      -30
    x[258]    c265      1
    x[259]    c31       -5
    x[259]    c40       5
    x[259]    c212      -30
    x[259]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[260]    c31       1
    x[260]    c32       -1
    MARKER    'MARKER'                 'INTORG'
    x[261]    c32       -3
    x[261]    c72       3
    x[261]    c247      -31
    x[261]    c297      1
    x[262]    c32       -1
    x[262]    c65       1
    x[262]    c243      -31
    x[262]    c293      1
    x[263]    c32       -3
    x[263]    c73       3
    x[263]    c241      -31
    x[263]    c291      1
    x[264]    c32       -5
    x[264]    c79       5
    x[264]    c238      -31
    x[264]    c288      1
    x[265]    c32       -4
    x[265]    c49       4
    x[265]    c237      -31
    x[265]    c287      1
    x[266]    c32       -4
    x[266]    c45       4
    x[266]    c234      -31
    x[266]    c284      1
    x[267]    c32       -2
    x[267]    c56       2
    x[267]    c226      -31
    x[267]    c276      1
    x[268]    c32       -2
    x[268]    c54       2
    x[268]    c223      -31
    x[268]    c273      1
    x[269]    c32       -3
    x[269]    c51       3
    x[269]    c220      -31
    x[269]    c270      1
    x[270]    c32       -5
    x[270]    c65       5
    x[270]    c215      -31
    x[270]    c265      1
    x[271]    c32       -5
    x[271]    c41       5
    x[271]    c212      -31
    x[271]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[272]    c32       1
    x[272]    c33       -1
    MARKER    'MARKER'                 'INTORG'
    x[273]    c33       -3
    x[273]    c73       3
    x[273]    c247      -32
    x[273]    c297      1
    x[274]    c33       -1
    x[274]    c66       1
    x[274]    c243      -32
    x[274]    c293      1
    x[275]    c33       -3
    x[275]    c74       3
    x[275]    c241      -32
    x[275]    c291      1
    x[276]    c33       -5
    x[276]    c80       5
    x[276]    c238      -32
    x[276]    c288      1
    x[277]    c33       -4
    x[277]    c50       4
    x[277]    c237      -32
    x[277]    c287      1
    x[278]    c33       -4
    x[278]    c46       4
    x[278]    c234      -32
    x[278]    c284      1
    x[279]    c33       -2
    x[279]    c57       2
    x[279]    c226      -32
    x[279]    c276      1
    x[280]    c33       -2
    x[280]    c55       2
    x[280]    c223      -32
    x[280]    c273      1
    x[281]    c33       -3
    x[281]    c52       3
    x[281]    c220      -32
    x[281]    c270      1
    x[282]    c33       -5
    x[282]    c66       5
    x[282]    c215      -32
    x[282]    c265      1
    x[283]    c33       -5
    x[283]    c42       5
    x[283]    c212      -32
    x[283]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[284]    c33       1
    x[284]    c34       -1
    MARKER    'MARKER'                 'INTORG'
    x[285]    c34       -3
    x[285]    c74       3
    x[285]    c247      -33
    x[285]    c297      1
    x[286]    c34       -3
    x[286]    c75       3
    x[286]    c241      -33
    x[286]    c291      1
    x[287]    c34       -5
    x[287]    c81       5
    x[287]    c238      -33
    x[287]    c288      1
    x[288]    c34       -4
    x[288]    c51       4
    x[288]    c237      -33
    x[288]    c287      1
    x[289]    c34       -4
    x[289]    c47       4
    x[289]    c234      -33
    x[289]    c284      1
    x[290]    c34       -2
    x[290]    c58       2
    x[290]    c226      -33
    x[290]    c276      1
    x[291]    c34       -2
    x[291]    c56       2
    x[291]    c223      -33
    x[291]    c273      1
    x[292]    c34       -3
    x[292]    c53       3
    x[292]    c220      -33
    x[292]    c270      1
    x[293]    c34       -5
    x[293]    c67       5
    x[293]    c215      -33
    x[293]    c265      1
    x[294]    c34       -5
    x[294]    c43       5
    x[294]    c212      -33
    x[294]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[295]    c34       1
    x[295]    c35       -1
    MARKER    'MARKER'                 'INTORG'
    x[296]    c35       -3
    x[296]    c75       3
    x[296]    c247      -34
    x[296]    c297      1
    x[297]    c35       -3
    x[297]    c76       3
    x[297]    c241      -34
    x[297]    c291      1
    x[298]    c35       -5
    x[298]    c82       5
    x[298]    c238      -34
    x[298]    c288      1
    x[299]    c35       -4
    x[299]    c52       4
    x[299]    c237      -34
    x[299]    c287      1
    x[300]    c35       -4
    x[300]    c48       4
    x[300]    c234      -34
    x[300]    c284      1
    x[301]    c35       -2
    x[301]    c59       2
    x[301]    c226      -34
    x[301]    c276      1
    x[302]    c35       -2
    x[302]    c57       2
    x[302]    c223      -34
    x[302]    c273      1
    x[303]    c35       -3
    x[303]    c54       3
    x[303]    c220      -34
    x[303]    c270      1
    x[304]    c35       -5
    x[304]    c44       5
    x[304]    c212      -34
    x[304]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[305]    c35       1
    x[305]    c36       -1
    MARKER    'MARKER'                 'INTORG'
    x[306]    c36       -3
    x[306]    c76       3
    x[306]    c247      -35
    x[306]    c297      1
    x[307]    c36       -3
    x[307]    c77       3
    x[307]    c241      -35
    x[307]    c291      1
    x[308]    c36       -4
    x[308]    c53       4
    x[308]    c237      -35
    x[308]    c287      1
    x[309]    c36       -4
    x[309]    c49       4
    x[309]    c234      -35
    x[309]    c284      1
    x[310]    c36       -2
    x[310]    c60       2
    x[310]    c226      -35
    x[310]    c276      1
    x[311]    c36       -2
    x[311]    c58       2
    x[311]    c223      -35
    x[311]    c273      1
    x[312]    c36       -3
    x[312]    c55       3
    x[312]    c220      -35
    x[312]    c270      1
    x[313]    c36       -5
    x[313]    c45       5
    x[313]    c212      -35
    x[313]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[314]    c36       1
    x[314]    c37       -1
    MARKER    'MARKER'                 'INTORG'
    x[315]    c37       -3
    x[315]    c77       3
    x[315]    c247      -36
    x[315]    c297      1
    x[316]    c37       -3
    x[316]    c78       3
    x[316]    c241      -36
    x[316]    c291      1
    x[317]    c37       -4
    x[317]    c54       4
    x[317]    c237      -36
    x[317]    c287      1
    x[318]    c37       -4
    x[318]    c50       4
    x[318]    c234      -36
    x[318]    c284      1
    x[319]    c37       -2
    x[319]    c61       2
    x[319]    c226      -36
    x[319]    c276      1
    x[320]    c37       -2
    x[320]    c59       2
    x[320]    c223      -36
    x[320]    c273      1
    x[321]    c37       -3
    x[321]    c56       3
    x[321]    c220      -36
    x[321]    c270      1
    x[322]    c37       -5
    x[322]    c46       5
    x[322]    c212      -36
    x[322]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[323]    c37       1
    x[323]    c38       -1
    MARKER    'MARKER'                 'INTORG'
    x[324]    c38       -3
    x[324]    c78       3
    x[324]    c247      -37
    x[324]    c297      1
    x[325]    c38       -3
    x[325]    c79       3
    x[325]    c241      -37
    x[325]    c291      1
    x[326]    c38       -4
    x[326]    c55       4
    x[326]    c237      -37
    x[326]    c287      1
    x[327]    c38       -4
    x[327]    c51       4
    x[327]    c234      -37
    x[327]    c284      1
    x[328]    c38       -2
    x[328]    c62       2
    x[328]    c226      -37
    x[328]    c276      1
    x[329]    c38       -2
    x[329]    c60       2
    x[329]    c223      -37
    x[329]    c273      1
    x[330]    c38       -3
    x[330]    c57       3
    x[330]    c220      -37
    x[330]    c270      1
    x[331]    c38       -5
    x[331]    c47       5
    x[331]    c212      -37
    x[331]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[332]    c38       1
    x[332]    c39       -1
    MARKER    'MARKER'                 'INTORG'
    x[333]    c39       -3
    x[333]    c79       3
    x[333]    c247      -38
    x[333]    c297      1
    x[334]    c39       -3
    x[334]    c80       3
    x[334]    c241      -38
    x[334]    c291      1
    x[335]    c39       -4
    x[335]    c56       4
    x[335]    c237      -38
    x[335]    c287      1
    x[336]    c39       -4
    x[336]    c52       4
    x[336]    c234      -38
    x[336]    c284      1
    x[337]    c39       -2
    x[337]    c63       2
    x[337]    c226      -38
    x[337]    c276      1
    x[338]    c39       -2
    x[338]    c61       2
    x[338]    c223      -38
    x[338]    c273      1
    x[339]    c39       -3
    x[339]    c58       3
    x[339]    c220      -38
    x[339]    c270      1
    x[340]    c39       -5
    x[340]    c48       5
    x[340]    c212      -38
    x[340]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[341]    c39       1
    x[341]    c40       -1
    MARKER    'MARKER'                 'INTORG'
    x[342]    c40       -3
    x[342]    c80       3
    x[342]    c247      -39
    x[342]    c297      1
    x[343]    c40       -3
    x[343]    c81       3
    x[343]    c241      -39
    x[343]    c291      1
    x[344]    c40       -4
    x[344]    c57       4
    x[344]    c237      -39
    x[344]    c287      1
    x[345]    c40       -4
    x[345]    c53       4
    x[345]    c234      -39
    x[345]    c284      1
    x[346]    c40       -2
    x[346]    c64       2
    x[346]    c226      -39
    x[346]    c276      1
    x[347]    c40       -2
    x[347]    c62       2
    x[347]    c223      -39
    x[347]    c273      1
    x[348]    c40       -3
    x[348]    c59       3
    x[348]    c220      -39
    x[348]    c270      1
    x[349]    c40       -5
    x[349]    c49       5
    x[349]    c212      -39
    x[349]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[350]    c40       1
    x[350]    c41       -1
    MARKER    'MARKER'                 'INTORG'
    x[351]    c41       -3
    x[351]    c81       3
    x[351]    c247      -40
    x[351]    c297      1
    x[352]    c41       -3
    x[352]    c82       3
    x[352]    c241      -40
    x[352]    c291      1
    x[353]    c41       -4
    x[353]    c58       4
    x[353]    c237      -40
    x[353]    c287      1
    x[354]    c41       -4
    x[354]    c54       4
    x[354]    c234      -40
    x[354]    c284      1
    x[355]    c41       -2
    x[355]    c65       2
    x[355]    c226      -40
    x[355]    c276      1
    x[356]    c41       -2
    x[356]    c63       2
    x[356]    c223      -40
    x[356]    c273      1
    x[357]    c41       -3
    x[357]    c60       3
    x[357]    c220      -40
    x[357]    c270      1
    x[358]    c41       -5
    x[358]    c50       5
    x[358]    c212      -40
    x[358]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[359]    c41       1
    x[359]    c42       -1
    MARKER    'MARKER'                 'INTORG'
    x[360]    c42       -3
    x[360]    c82       3
    x[360]    c247      -41
    x[360]    c297      1
    x[361]    c42       -3
    x[361]    c83       3
    x[361]    c241      -41
    x[361]    c291      1
    x[362]    c42       -4
    x[362]    c59       4
    x[362]    c237      -41
    x[362]    c287      1
    x[363]    c42       -4
    x[363]    c55       4
    x[363]    c234      -41
    x[363]    c284      1
    x[364]    c42       -2
    x[364]    c66       2
    x[364]    c226      -41
    x[364]    c276      1
    x[365]    c42       -2
    x[365]    c64       2
    x[365]    c223      -41
    x[365]    c273      1
    x[366]    c42       -3
    x[366]    c61       3
    x[366]    c220      -41
    x[366]    c270      1
    x[367]    c42       -3
    x[367]    c78       3
    x[367]    c217      -41
    x[367]    c267      1
    x[368]    c42       -5
    x[368]    c51       5
    x[368]    c212      -41
    x[368]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[369]    c42       1
    x[369]    c43       -1
    MARKER    'MARKER'                 'INTORG'
    x[370]    c43       -3
    x[370]    c83       3
    x[370]    c247      -42
    x[370]    c297      1
    x[371]    c43       -3
    x[371]    c84       3
    x[371]    c241      -42
    x[371]    c291      1
    x[372]    c43       -4
    x[372]    c60       4
    x[372]    c237      -42
    x[372]    c287      1
    x[373]    c43       -4
    x[373]    c56       4
    x[373]    c234      -42
    x[373]    c284      1
    x[374]    c43       -2
    x[374]    c67       2
    x[374]    c226      -42
    x[374]    c276      1
    x[375]    c43       -2
    x[375]    c65       2
    x[375]    c223      -42
    x[375]    c273      1
    x[376]    c43       -3
    x[376]    c62       3
    x[376]    c220      -42
    x[376]    c270      1
    x[377]    c43       -3
    x[377]    c79       3
    x[377]    c217      -42
    x[377]    c267      1
    x[378]    c43       -5
    x[378]    c52       5
    x[378]    c212      -42
    x[378]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[379]    c43       1
    x[379]    c44       -1
    MARKER    'MARKER'                 'INTORG'
    x[380]    c44       -3
    x[380]    c84       3
    x[380]    c247      -43
    x[380]    c297      1
    x[381]    c44       -3
    x[381]    c85       3
    x[381]    c241      -43
    x[381]    c291      1
    x[382]    c44       -4
    x[382]    c61       4
    x[382]    c237      -43
    x[382]    c287      1
    x[383]    c44       -4
    x[383]    c57       4
    x[383]    c234      -43
    x[383]    c284      1
    x[384]    c44       -2
    x[384]    c68       2
    x[384]    c226      -43
    x[384]    c276      1
    x[385]    c44       -2
    x[385]    c66       2
    x[385]    c223      -43
    x[385]    c273      1
    x[386]    c44       -3
    x[386]    c63       3
    x[386]    c220      -43
    x[386]    c270      1
    x[387]    c44       -3
    x[387]    c80       3
    x[387]    c217      -43
    x[387]    c267      1
    x[388]    c44       -5
    x[388]    c53       5
    x[388]    c212      -43
    x[388]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[389]    c44       1
    x[389]    c45       -1
    MARKER    'MARKER'                 'INTORG'
    x[390]    c45       -3
    x[390]    c85       3
    x[390]    c247      -44
    x[390]    c297      1
    x[391]    c45       -3
    x[391]    c86       3
    x[391]    c241      -44
    x[391]    c291      1
    x[392]    c45       -4
    x[392]    c62       4
    x[392]    c237      -44
    x[392]    c287      1
    x[393]    c45       -4
    x[393]    c58       4
    x[393]    c234      -44
    x[393]    c284      1
    x[394]    c45       -2
    x[394]    c69       2
    x[394]    c226      -44
    x[394]    c276      1
    x[395]    c45       -2
    x[395]    c67       2
    x[395]    c223      -44
    x[395]    c273      1
    x[396]    c45       -3
    x[396]    c64       3
    x[396]    c220      -44
    x[396]    c270      1
    x[397]    c45       -3
    x[397]    c81       3
    x[397]    c217      -44
    x[397]    c267      1
    x[398]    c45       -5
    x[398]    c54       5
    x[398]    c212      -44
    x[398]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[399]    c45       1
    x[399]    c46       -1
    MARKER    'MARKER'                 'INTORG'
    x[400]    c46       -2
    x[400]    c62       2
    x[400]    c249      -45
    x[400]    c299      1
    x[401]    c46       -3
    x[401]    c86       3
    x[401]    c247      -45
    x[401]    c297      1
    x[402]    c46       -3
    x[402]    c87       3
    x[402]    c241      -45
    x[402]    c291      1
    x[403]    c46       -4
    x[403]    c63       4
    x[403]    c237      -45
    x[403]    c287      1
    x[404]    c46       -4
    x[404]    c59       4
    x[404]    c234      -45
    x[404]    c284      1
    x[405]    c46       -2
    x[405]    c70       2
    x[405]    c226      -45
    x[405]    c276      1
    x[406]    c46       -2
    x[406]    c68       2
    x[406]    c223      -45
    x[406]    c273      1
    x[407]    c46       -3
    x[407]    c65       3
    x[407]    c220      -45
    x[407]    c270      1
    x[408]    c46       -3
    x[408]    c82       3
    x[408]    c217      -45
    x[408]    c267      1
    x[409]    c46       -5
    x[409]    c55       5
    x[409]    c212      -45
    x[409]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[410]    c46       1
    x[410]    c47       -1
    MARKER    'MARKER'                 'INTORG'
    x[411]    c47       -2
    x[411]    c63       2
    x[411]    c249      -46
    x[411]    c299      1
    x[412]    c47       -3
    x[412]    c87       3
    x[412]    c247      -46
    x[412]    c297      1
    x[413]    c47       -3
    x[413]    c88       3
    x[413]    c241      -46
    x[413]    c291      1
    x[414]    c47       -4
    x[414]    c64       4
    x[414]    c237      -46
    x[414]    c287      1
    x[415]    c47       -4
    x[415]    c60       4
    x[415]    c234      -46
    x[415]    c284      1
    x[416]    c47       -2
    x[416]    c71       2
    x[416]    c226      -46
    x[416]    c276      1
    x[417]    c47       -2
    x[417]    c69       2
    x[417]    c223      -46
    x[417]    c273      1
    x[418]    c47       -3
    x[418]    c66       3
    x[418]    c220      -46
    x[418]    c270      1
    x[419]    c47       -3
    x[419]    c83       3
    x[419]    c217      -46
    x[419]    c267      1
    x[420]    c47       -2
    x[420]    c67       2
    x[420]    c216      -46
    x[420]    c266      1
    x[421]    c47       -5
    x[421]    c56       5
    x[421]    c212      -46
    x[421]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[422]    c47       1
    x[422]    c48       -1
    MARKER    'MARKER'                 'INTORG'
    x[423]    c48       -2
    x[423]    c64       2
    x[423]    c249      -47
    x[423]    c299      1
    x[424]    c48       -3
    x[424]    c88       3
    x[424]    c247      -47
    x[424]    c297      1
    x[425]    c48       -3
    x[425]    c89       3
    x[425]    c241      -47
    x[425]    c291      1
    x[426]    c48       -4
    x[426]    c65       4
    x[426]    c237      -47
    x[426]    c287      1
    x[427]    c48       -4
    x[427]    c61       4
    x[427]    c234      -47
    x[427]    c284      1
    x[428]    c48       -2
    x[428]    c72       2
    x[428]    c226      -47
    x[428]    c276      1
    x[429]    c48       -2
    x[429]    c70       2
    x[429]    c223      -47
    x[429]    c273      1
    x[430]    c48       -3
    x[430]    c67       3
    x[430]    c220      -47
    x[430]    c270      1
    x[431]    c48       -3
    x[431]    c84       3
    x[431]    c217      -47
    x[431]    c267      1
    x[432]    c48       -2
    x[432]    c68       2
    x[432]    c216      -47
    x[432]    c266      1
    x[433]    c48       -5
    x[433]    c57       5
    x[433]    c212      -47
    x[433]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[434]    c48       1
    x[434]    c49       -1
    MARKER    'MARKER'                 'INTORG'
    x[435]    c49       -2
    x[435]    c65       2
    x[435]    c249      -48
    x[435]    c299      1
    x[436]    c49       -3
    x[436]    c89       3
    x[436]    c247      -48
    x[436]    c297      1
    x[437]    c49       -3
    x[437]    c90       3
    x[437]    c241      -48
    x[437]    c291      1
    x[438]    c49       -4
    x[438]    c66       4
    x[438]    c237      -48
    x[438]    c287      1
    x[439]    c49       -4
    x[439]    c62       4
    x[439]    c234      -48
    x[439]    c284      1
    x[440]    c49       -2
    x[440]    c73       2
    x[440]    c226      -48
    x[440]    c276      1
    x[441]    c49       -1
    x[441]    c80       1
    x[441]    c225      -48
    x[441]    c275      1
    x[442]    c49       -3
    x[442]    c68       3
    x[442]    c220      -48
    x[442]    c270      1
    x[443]    c49       -3
    x[443]    c85       3
    x[443]    c217      -48
    x[443]    c267      1
    x[444]    c49       -2
    x[444]    c69       2
    x[444]    c216      -48
    x[444]    c266      1
    x[445]    c49       -5
    x[445]    c58       5
    x[445]    c212      -48
    x[445]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[446]    c49       1
    x[446]    c50       -1
    MARKER    'MARKER'                 'INTORG'
    x[447]    c50       -2
    x[447]    c66       2
    x[447]    c249      -49
    x[447]    c299      1
    x[448]    c50       -3
    x[448]    c90       3
    x[448]    c247      -49
    x[448]    c297      1
    x[449]    c50       -3
    x[449]    c91       3
    x[449]    c241      -49
    x[449]    c291      1
    x[450]    c50       -4
    x[450]    c67       4
    x[450]    c237      -49
    x[450]    c287      1
    x[451]    c50       -4
    x[451]    c63       4
    x[451]    c234      -49
    x[451]    c284      1
    x[452]    c50       -1
    x[452]    c81       1
    x[452]    c225      -49
    x[452]    c275      1
    x[453]    c50       -3
    x[453]    c69       3
    x[453]    c220      -49
    x[453]    c270      1
    x[454]    c50       -3
    x[454]    c86       3
    x[454]    c217      -49
    x[454]    c267      1
    x[455]    c50       -2
    x[455]    c70       2
    x[455]    c216      -49
    x[455]    c266      1
    x[456]    c50       -5
    x[456]    c59       5
    x[456]    c212      -49
    x[456]    c262      1
    MARKER    'MARKER'                 'INTEND'
    x[457]    c50       1
    x[457]    c51       -1
    MARKER    'MARKER'                 'INTORG'
    x[458]    c51       -2
    x[458]    c67       2
    x[458]    c249      -50
    x[458]    c299      1
    x[459]    c51       -3
    x[459]    c91       3
    x[459]    c247      -50
    x[459]    c297      1
    x[460]    c51       -3
    x[460]    c92       3
    x[460]    c241      -50
    x[460]    c291      1
    x[461]    c51       -4
    x[461]    c68       4
    x[461]    c237      -50
    x[461]    c287      1
    x[462]    c51       -4
    x[462]    c64       4
    x[462]    c234      -50
    x[462]    c284      1
    x[463]    c51       -1
    x[463]    c82       1
    x[463]    c225      -50
    x[463]    c275      1
    x[464]    c51       -3
    x[464]    c70       3
    x[464]    c220      -50
    x[464]    c270      1
    x[465]    c51       -3
    x[465]    c87       3
    x[465]    c217      -50
    x[465]    c267      1
    x[466]    c51       -2
    x[466]    c71       2
    x[466]    c216      -50
    x[466]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[467]    c51       1
    x[467]    c52       -1
    MARKER    'MARKER'                 'INTORG'
    x[468]    c52       -2
    x[468]    c68       2
    x[468]    c249      -51
    x[468]    c299      1
    x[469]    c52       -3
    x[469]    c92       3
    x[469]    c247      -51
    x[469]    c297      1
    x[470]    c52       -1
    x[470]    c61       1
    x[470]    c246      -51
    x[470]    c296      1
    x[471]    c52       -4
    x[471]    c69       4
    x[471]    c237      -51
    x[471]    c287      1
    x[472]    c52       -4
    x[472]    c65       4
    x[472]    c234      -51
    x[472]    c284      1
    x[473]    c52       -1
    x[473]    c83       1
    x[473]    c225      -51
    x[473]    c275      1
    x[474]    c52       -3
    x[474]    c71       3
    x[474]    c220      -51
    x[474]    c270      1
    x[475]    c52       -3
    x[475]    c88       3
    x[475]    c217      -51
    x[475]    c267      1
    x[476]    c52       -2
    x[476]    c72       2
    x[476]    c216      -51
    x[476]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[477]    c52       1
    x[477]    c53       -1
    MARKER    'MARKER'                 'INTORG'
    x[478]    c53       -2
    x[478]    c69       2
    x[478]    c249      -52
    x[478]    c299      1
    x[479]    c53       -3
    x[479]    c93       3
    x[479]    c247      -52
    x[479]    c297      1
    x[480]    c53       -1
    x[480]    c62       1
    x[480]    c246      -52
    x[480]    c296      1
    x[481]    c53       -4
    x[481]    c70       4
    x[481]    c237      -52
    x[481]    c287      1
    x[482]    c53       -4
    x[482]    c66       4
    x[482]    c234      -52
    x[482]    c284      1
    x[483]    c53       -1
    x[483]    c84       1
    x[483]    c225      -52
    x[483]    c275      1
    x[484]    c53       -4
    x[484]    c111      4
    x[484]    c224      -52
    x[484]    c274      1
    x[485]    c53       -3
    x[485]    c72       3
    x[485]    c220      -52
    x[485]    c270      1
    x[486]    c53       -3
    x[486]    c89       3
    x[486]    c217      -52
    x[486]    c267      1
    x[487]    c53       -2
    x[487]    c73       2
    x[487]    c216      -52
    x[487]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[488]    c53       1
    x[488]    c54       -1
    MARKER    'MARKER'                 'INTORG'
    x[489]    c54       -2
    x[489]    c70       2
    x[489]    c249      -53
    x[489]    c299      1
    x[490]    c54       -3
    x[490]    c94       3
    x[490]    c247      -53
    x[490]    c297      1
    x[491]    c54       -1
    x[491]    c63       1
    x[491]    c246      -53
    x[491]    c296      1
    x[492]    c54       -4
    x[492]    c71       4
    x[492]    c237      -53
    x[492]    c287      1
    x[493]    c54       -4
    x[493]    c67       4
    x[493]    c234      -53
    x[493]    c284      1
    x[494]    c54       -1
    x[494]    c85       1
    x[494]    c225      -53
    x[494]    c275      1
    x[495]    c54       -4
    x[495]    c112      4
    x[495]    c224      -53
    x[495]    c274      1
    x[496]    c54       -3
    x[496]    c73       3
    x[496]    c220      -53
    x[496]    c270      1
    x[497]    c54       -3
    x[497]    c90       3
    x[497]    c217      -53
    x[497]    c267      1
    x[498]    c54       -2
    x[498]    c74       2
    x[498]    c216      -53
    x[498]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[499]    c54       1
    x[499]    c55       -1
    MARKER    'MARKER'                 'INTORG'
    x[500]    c55       -2
    x[500]    c71       2
    x[500]    c249      -54
    x[500]    c299      1
    x[501]    c55       -3
    x[501]    c95       3
    x[501]    c247      -54
    x[501]    c297      1
    x[502]    c55       -1
    x[502]    c64       1
    x[502]    c246      -54
    x[502]    c296      1
    x[503]    c55       -4
    x[503]    c72       4
    x[503]    c237      -54
    x[503]    c287      1
    x[504]    c55       -4
    x[504]    c68       4
    x[504]    c234      -54
    x[504]    c284      1
    x[505]    c55       -1
    x[505]    c86       1
    x[505]    c225      -54
    x[505]    c275      1
    x[506]    c55       -4
    x[506]    c113      4
    x[506]    c224      -54
    x[506]    c274      1
    x[507]    c55       -3
    x[507]    c74       3
    x[507]    c220      -54
    x[507]    c270      1
    x[508]    c55       -3
    x[508]    c91       3
    x[508]    c217      -54
    x[508]    c267      1
    x[509]    c55       -2
    x[509]    c75       2
    x[509]    c216      -54
    x[509]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[510]    c55       1
    x[510]    c56       -1
    MARKER    'MARKER'                 'INTORG'
    x[511]    c56       -2
    x[511]    c72       2
    x[511]    c249      -55
    x[511]    c299      1
    x[512]    c56       -1
    x[512]    c65       1
    x[512]    c246      -55
    x[512]    c296      1
    x[513]    c56       -4
    x[513]    c73       4
    x[513]    c237      -55
    x[513]    c287      1
    x[514]    c56       -1
    x[514]    c87       1
    x[514]    c225      -55
    x[514]    c275      1
    x[515]    c56       -4
    x[515]    c114      4
    x[515]    c224      -55
    x[515]    c274      1
    x[516]    c56       -3
    x[516]    c75       3
    x[516]    c220      -55
    x[516]    c270      1
    x[517]    c56       -3
    x[517]    c92       3
    x[517]    c217      -55
    x[517]    c267      1
    x[518]    c56       -2
    x[518]    c76       2
    x[518]    c216      -55
    x[518]    c266      1
    MARKER    'MARKER'                 'INTEND'
    x[519]    c56       1
    x[519]    c57       -1
    MARKER    'MARKER'                 'INTORG'
    x[520]    c57       -2
    x[520]    c73       2
    x[520]    c249      -56
    x[520]    c299      1
    x[521]    c57       -1
    x[521]    c66       1
    x[521]    c246      -56
    x[521]    c296      1
    x[522]    c57       -4
    x[522]    c74       4
    x[522]    c237      -56
    x[522]    c287      1
    x[523]    c57       -1
    x[523]    c88       1
    x[523]    c225      -56
    x[523]    c275      1
    x[524]    c57       -4
    x[524]    c115      4
    x[524]    c224      -56
    x[524]    c274      1
    x[525]    c57       -3
    x[525]    c76       3
    x[525]    c220      -56
    x[525]    c270      1
    x[526]    c57       -3
    x[526]    c93       3
    x[526]    c217      -56
    x[526]    c267      1
    x[527]    c57       -2
    x[527]    c77       2
    x[527]    c216      -56
    x[527]    c266      1
    x[528]    c57       -5
    x[528]    c97       5
    x[528]    c208      -56
    x[528]    c258      1
    x[529]    c57       -4
    x[529]    c68       4
    x[529]    c204      -56
    x[529]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[530]    c57       1
    x[530]    c58       -1
    MARKER    'MARKER'                 'INTORG'
    x[531]    c58       -2
    x[531]    c74       2
    x[531]    c249      -57
    x[531]    c299      1
    x[532]    c58       -1
    x[532]    c67       1
    x[532]    c246      -57
    x[532]    c296      1
    x[533]    c58       -4
    x[533]    c75       4
    x[533]    c237      -57
    x[533]    c287      1
    x[534]    c58       -1
    x[534]    c89       1
    x[534]    c225      -57
    x[534]    c275      1
    x[535]    c58       -4
    x[535]    c116      4
    x[535]    c224      -57
    x[535]    c274      1
    x[536]    c58       -3
    x[536]    c77       3
    x[536]    c220      -57
    x[536]    c270      1
    x[537]    c58       -3
    x[537]    c94       3
    x[537]    c217      -57
    x[537]    c267      1
    x[538]    c58       -2
    x[538]    c78       2
    x[538]    c216      -57
    x[538]    c266      1
    x[539]    c58       -5
    x[539]    c98       5
    x[539]    c208      -57
    x[539]    c258      1
    x[540]    c58       -4
    x[540]    c69       4
    x[540]    c204      -57
    x[540]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[541]    c58       1
    x[541]    c59       -1
    MARKER    'MARKER'                 'INTORG'
    x[542]    c59       -2
    x[542]    c75       2
    x[542]    c249      -58
    x[542]    c299      1
    x[543]    c59       -1
    x[543]    c68       1
    x[543]    c246      -58
    x[543]    c296      1
    x[544]    c59       -4
    x[544]    c76       4
    x[544]    c237      -58
    x[544]    c287      1
    x[545]    c59       -1
    x[545]    c90       1
    x[545]    c225      -58
    x[545]    c275      1
    x[546]    c59       -4
    x[546]    c117      4
    x[546]    c224      -58
    x[546]    c274      1
    x[547]    c59       -3
    x[547]    c78       3
    x[547]    c220      -58
    x[547]    c270      1
    x[548]    c59       -3
    x[548]    c95       3
    x[548]    c217      -58
    x[548]    c267      1
    x[549]    c59       -2
    x[549]    c79       2
    x[549]    c216      -58
    x[549]    c266      1
    x[550]    c59       -5
    x[550]    c99       5
    x[550]    c208      -58
    x[550]    c258      1
    x[551]    c59       -4
    x[551]    c70       4
    x[551]    c204      -58
    x[551]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[552]    c59       1
    x[552]    c60       -1
    MARKER    'MARKER'                 'INTORG'
    x[553]    c60       -2
    x[553]    c76       2
    x[553]    c249      -59
    x[553]    c299      1
    x[554]    c60       -1
    x[554]    c69       1
    x[554]    c246      -59
    x[554]    c296      1
    x[555]    c60       -4
    x[555]    c77       4
    x[555]    c237      -59
    x[555]    c287      1
    x[556]    c60       -1
    x[556]    c91       1
    x[556]    c225      -59
    x[556]    c275      1
    x[557]    c60       -4
    x[557]    c118      4
    x[557]    c224      -59
    x[557]    c274      1
    x[558]    c60       -3
    x[558]    c79       3
    x[558]    c220      -59
    x[558]    c270      1
    x[559]    c60       -3
    x[559]    c96       3
    x[559]    c217      -59
    x[559]    c267      1
    x[560]    c60       -2
    x[560]    c80       2
    x[560]    c216      -59
    x[560]    c266      1
    x[561]    c60       -5
    x[561]    c100      5
    x[561]    c208      -59
    x[561]    c258      1
    x[562]    c60       -4
    x[562]    c71       4
    x[562]    c204      -59
    x[562]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[563]    c60       1
    x[563]    c61       -1
    MARKER    'MARKER'                 'INTORG'
    x[564]    c61       -2
    x[564]    c77       2
    x[564]    c249      -60
    x[564]    c299      1
    x[565]    c61       -1
    x[565]    c70       1
    x[565]    c246      -60
    x[565]    c296      1
    x[566]    c61       -2
    x[566]    c83       2
    x[566]    c245      -60
    x[566]    c295      1
    x[567]    c61       -4
    x[567]    c78       4
    x[567]    c237      -60
    x[567]    c287      1
    x[568]    c61       -1
    x[568]    c92       1
    x[568]    c225      -60
    x[568]    c275      1
    x[569]    c61       -4
    x[569]    c119      4
    x[569]    c224      -60
    x[569]    c274      1
    x[570]    c61       -3
    x[570]    c80       3
    x[570]    c220      -60
    x[570]    c270      1
    x[571]    c61       -3
    x[571]    c97       3
    x[571]    c217      -60
    x[571]    c267      1
    x[572]    c61       -2
    x[572]    c81       2
    x[572]    c216      -60
    x[572]    c266      1
    x[573]    c61       -5
    x[573]    c101      5
    x[573]    c208      -60
    x[573]    c258      1
    x[574]    c61       -4
    x[574]    c72       4
    x[574]    c204      -60
    x[574]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[575]    c61       1
    x[575]    c62       -1
    MARKER    'MARKER'                 'INTORG'
    x[576]    c62       -2
    x[576]    c78       2
    x[576]    c249      -61
    x[576]    c299      1
    x[577]    c62       -1
    x[577]    c71       1
    x[577]    c246      -61
    x[577]    c296      1
    x[578]    c62       -2
    x[578]    c84       2
    x[578]    c245      -61
    x[578]    c295      1
    x[579]    c62       -4
    x[579]    c79       4
    x[579]    c237      -61
    x[579]    c287      1
    x[580]    c62       -1
    x[580]    c93       1
    x[580]    c225      -61
    x[580]    c275      1
    x[581]    c62       -4
    x[581]    c120      4
    x[581]    c224      -61
    x[581]    c274      1
    x[582]    c53_1     1
    x[582]    c54_1     1
    x[582]    c55_1     1
    x[582]    c56_1     1
    x[582]    c57_1     1
    x[582]    c58_1     1
    x[582]    c59_1     1
    x[582]    c60_1     1
    x[582]    c61_1     1
    x[582]    c62_1     1
    x[582]    c63_1     1
    x[582]    c64_1     1
    x[582]    c65_1     1
    x[582]    c66_1     1
    x[582]    c67_1     1
    x[582]    c68_1     1
    x[582]    c69_1     1
    x[582]    c70_1     1
    x[582]    c71_1     1
    x[582]    c72_1     1
    x[582]    c73_1     1
    x[582]    c74_1     1
    x[582]    c62       -5
    x[582]    c100      5
    x[582]    c222      -61
    x[582]    c272      1
    x[583]    c62       -3
    x[583]    c81       3
    x[583]    c220      -61
    x[583]    c270      1
    x[584]    c62       -3
    x[584]    c98       3
    x[584]    c217      -61
    x[584]    c267      1
    x[585]    c62       -2
    x[585]    c82       2
    x[585]    c216      -61
    x[585]    c266      1
    x[586]    c62       -5
    x[586]    c102      5
    x[586]    c208      -61
    x[586]    c258      1
    x[587]    c62       -4
    x[587]    c73       4
    x[587]    c204      -61
    x[587]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[588]    c62       1
    x[588]    c63       -1
    MARKER    'MARKER'                 'INTORG'
    x[589]    c63       -2
    x[589]    c79       2
    x[589]    c249      -62
    x[589]    c299      1
    x[590]    c63       -1
    x[590]    c72       1
    x[590]    c246      -62
    x[590]    c296      1
    x[591]    c63       -2
    x[591]    c85       2
    x[591]    c245      -62
    x[591]    c295      1
    x[592]    c63       -4
    x[592]    c80       4
    x[592]    c237      -62
    x[592]    c287      1
    x[593]    c63       -1
    x[593]    c94       1
    x[593]    c225      -62
    x[593]    c275      1
    x[594]    c63       -4
    x[594]    c121      4
    x[594]    c224      -62
    x[594]    c274      1
    x[595]    c53_1     1
    x[595]    c63       -5
    x[595]    c101      5
    x[595]    c222      -62
    x[595]    c272      1
    x[596]    c63       -3
    x[596]    c82       3
    x[596]    c220      -62
    x[596]    c270      1
    x[597]    c63       -3
    x[597]    c99       3
    x[597]    c217      -62
    x[597]    c267      1
    x[598]    c63       -2
    x[598]    c83       2
    x[598]    c216      -62
    x[598]    c266      1
    x[599]    c63       -5
    x[599]    c103      5
    x[599]    c208      -62
    x[599]    c258      1
    x[600]    c63       -4
    x[600]    c74       4
    x[600]    c204      -62
    x[600]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[601]    c63       1
    x[601]    c64       -1
    MARKER    'MARKER'                 'INTORG'
    x[602]    c64       -2
    x[602]    c80       2
    x[602]    c249      -63
    x[602]    c299      1
    x[603]    c64       -1
    x[603]    c73       1
    x[603]    c246      -63
    x[603]    c296      1
    x[604]    c64       -2
    x[604]    c86       2
    x[604]    c245      -63
    x[604]    c295      1
    x[605]    c64       -4
    x[605]    c81       4
    x[605]    c237      -63
    x[605]    c287      1
    x[606]    c64       -1
    x[606]    c95       1
    x[606]    c225      -63
    x[606]    c275      1
    x[607]    c64       -4
    x[607]    c122      4
    x[607]    c224      -63
    x[607]    c274      1
    x[608]    c54_1     1
    x[608]    c64       -5
    x[608]    c102      5
    x[608]    c222      -63
    x[608]    c272      1
    x[609]    c64       -3
    x[609]    c83       3
    x[609]    c220      -63
    x[609]    c270      1
    x[610]    c64       -3
    x[610]    c100      3
    x[610]    c217      -63
    x[610]    c267      1
    x[611]    c64       -2
    x[611]    c84       2
    x[611]    c216      -63
    x[611]    c266      1
    x[612]    c64       -5
    x[612]    c104      5
    x[612]    c208      -63
    x[612]    c258      1
    x[613]    c64       -4
    x[613]    c75       4
    x[613]    c204      -63
    x[613]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[614]    c64       1
    x[614]    c65       -1
    MARKER    'MARKER'                 'INTORG'
    x[615]    c65       -2
    x[615]    c81       2
    x[615]    c249      -64
    x[615]    c299      1
    x[616]    c65       -1
    x[616]    c74       1
    x[616]    c246      -64
    x[616]    c296      1
    x[617]    c65       -2
    x[617]    c87       2
    x[617]    c245      -64
    x[617]    c295      1
    x[618]    c65       -4
    x[618]    c82       4
    x[618]    c237      -64
    x[618]    c287      1
    x[619]    c65       -1
    x[619]    c96       1
    x[619]    c225      -64
    x[619]    c275      1
    x[620]    c65       -4
    x[620]    c123      4
    x[620]    c224      -64
    x[620]    c274      1
    x[621]    c55_1     1
    x[621]    c65       -5
    x[621]    c103      5
    x[621]    c222      -64
    x[621]    c272      1
    x[622]    c65       -3
    x[622]    c84       3
    x[622]    c220      -64
    x[622]    c270      1
    x[623]    c65       -3
    x[623]    c101      3
    x[623]    c217      -64
    x[623]    c267      1
    x[624]    c65       -2
    x[624]    c85       2
    x[624]    c216      -64
    x[624]    c266      1
    x[625]    c65       -5
    x[625]    c105      5
    x[625]    c208      -64
    x[625]    c258      1
    x[626]    c65       -4
    x[626]    c76       4
    x[626]    c204      -64
    x[626]    c254      1
    MARKER    'MARKER'                 'INTEND'
    x[627]    c65       1
    x[627]    c66       -1
    MARKER    'MARKER'                 'INTORG'
    x[628]    c66       -2
    x[628]    c82       2
    x[628]    c249      -65
    x[628]    c299      1
    x[629]    c66       -2
    x[629]    c88       2
    x[629]    c245      -65
    x[629]    c295      1
    x[630]    c66       -4
    x[630]    c83       4
    x[630]    c237      -65
    x[630]    c287      1
    x[631]    c66       -1
    x[631]    c97       1
    x[631]    c225      -65
    x[631]    c275      1
    x[632]    c66       -4
    x[632]    c124      4
    x[632]    c224      -65
    x[632]    c274      1
    x[633]    c56_1     1
    x[633]    c66       -5
    x[633]    c104      5
    x[633]    c222      -65
    x[633]    c272      1
    x[634]    c66       -3
    x[634]    c85       3
    x[634]    c220      -65
    x[634]    c270      1
    x[635]    c66       -3
    x[635]    c102      3
    x[635]    c217      -65
    x[635]    c267      1
    x[636]    c66       -2
    x[636]    c86       2
    x[636]    c216      -65
    x[636]    c266      1
    x[637]    c66       -5
    x[637]    c106      5
    x[637]    c208      -65
    x[637]    c258      1
    x[638]    c66       -4
    x[638]    c77       4
    x[638]    c204      -65
    x[638]    c254      1
    x[639]    c66       -1
    x[639]    c89       1
    x[639]    c203      -65
    x[639]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[640]    c66       1
    x[640]    c67       -1
    MARKER    'MARKER'                 'INTORG'
    x[641]    c67       -2
    x[641]    c83       2
    x[641]    c249      -66
    x[641]    c299      1
    x[642]    c67       -2
    x[642]    c89       2
    x[642]    c245      -66
    x[642]    c295      1
    x[643]    c67       -4
    x[643]    c84       4
    x[643]    c237      -66
    x[643]    c287      1
    x[644]    c27_2     1
    x[644]    c46_2     1
    x[644]    c47_2     1
    x[644]    c48_2     1
    x[644]    c49_2     1
    x[644]    c50_2     1
    x[644]    c51_1     1
    x[644]    c52_1     1
    x[644]    c67       -5
    x[644]    c93       5
    x[644]    c232      -66
    x[644]    c282      1
    x[645]    c67       -1
    x[645]    c98       1
    x[645]    c225      -66
    x[645]    c275      1
    x[646]    c67       -4
    x[646]    c125      4
    x[646]    c224      -66
    x[646]    c274      1
    x[647]    c57_1     1
    x[647]    c67       -5
    x[647]    c105      5
    x[647]    c222      -66
    x[647]    c272      1
    x[648]    c67       -3
    x[648]    c86       3
    x[648]    c220      -66
    x[648]    c270      1
    x[649]    c67       -3
    x[649]    c103      3
    x[649]    c217      -66
    x[649]    c267      1
    x[650]    c67       -2
    x[650]    c87       2
    x[650]    c216      -66
    x[650]    c266      1
    x[651]    c67       -5
    x[651]    c107      5
    x[651]    c208      -66
    x[651]    c258      1
    x[652]    c67       -4
    x[652]    c78       4
    x[652]    c204      -66
    x[652]    c254      1
    x[653]    c67       -1
    x[653]    c90       1
    x[653]    c203      -66
    x[653]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[654]    c67       1
    x[654]    c68       -1
    MARKER    'MARKER'                 'INTORG'
    x[655]    c68       -2
    x[655]    c84       2
    x[655]    c249      -67
    x[655]    c299      1
    x[656]    c68       -2
    x[656]    c90       2
    x[656]    c245      -67
    x[656]    c295      1
    x[657]    c68       -4
    x[657]    c85       4
    x[657]    c237      -67
    x[657]    c287      1
    x[658]    c28_2     1
    x[658]    c68       -5
    x[658]    c94       5
    x[658]    c232      -67
    x[658]    c282      1
    x[659]    c68       -1
    x[659]    c99       1
    x[659]    c225      -67
    x[659]    c275      1
    x[660]    c68       -4
    x[660]    c126      4
    x[660]    c224      -67
    x[660]    c274      1
    x[661]    c58_1     1
    x[661]    c68       -5
    x[661]    c106      5
    x[661]    c222      -67
    x[661]    c272      1
    x[662]    c68       -3
    x[662]    c87       3
    x[662]    c220      -67
    x[662]    c270      1
    x[663]    c68       -3
    x[663]    c104      3
    x[663]    c217      -67
    x[663]    c267      1
    x[664]    c68       -2
    x[664]    c88       2
    x[664]    c216      -67
    x[664]    c266      1
    x[665]    c68       -5
    x[665]    c108      5
    x[665]    c208      -67
    x[665]    c258      1
    x[666]    c68       -4
    x[666]    c79       4
    x[666]    c204      -67
    x[666]    c254      1
    x[667]    c68       -1
    x[667]    c91       1
    x[667]    c203      -67
    x[667]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[668]    c68       1
    x[668]    c69       -1
    MARKER    'MARKER'                 'INTORG'
    x[669]    c69       -2
    x[669]    c85       2
    x[669]    c249      -68
    x[669]    c299      1
    x[670]    c69       -2
    x[670]    c91       2
    x[670]    c245      -68
    x[670]    c295      1
    x[671]    c69       -4
    x[671]    c86       4
    x[671]    c237      -68
    x[671]    c287      1
    x[672]    c29_2     1
    x[672]    c69       -5
    x[672]    c95       5
    x[672]    c232      -68
    x[672]    c282      1
    x[673]    c69       -1
    x[673]    c100      1
    x[673]    c225      -68
    x[673]    c275      1
    x[674]    c69       -4
    x[674]    c127      4
    x[674]    c224      -68
    x[674]    c274      1
    x[675]    c59_1     1
    x[675]    c69       -5
    x[675]    c107      5
    x[675]    c222      -68
    x[675]    c272      1
    x[676]    c69       -3
    x[676]    c88       3
    x[676]    c220      -68
    x[676]    c270      1
    x[677]    c69       -3
    x[677]    c104      3
    x[677]    c219      -68
    x[677]    c269      1
    x[678]    c69       -3
    x[678]    c105      3
    x[678]    c217      -68
    x[678]    c267      1
    x[679]    c69       -2
    x[679]    c89       2
    x[679]    c216      -68
    x[679]    c266      1
    x[680]    c69       -5
    x[680]    c109      5
    x[680]    c208      -68
    x[680]    c258      1
    x[681]    c69       -4
    x[681]    c80       4
    x[681]    c204      -68
    x[681]    c254      1
    x[682]    c69       -1
    x[682]    c92       1
    x[682]    c203      -68
    x[682]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[683]    c69       1
    x[683]    c70       -1
    MARKER    'MARKER'                 'INTORG'
    x[684]    c70       -2
    x[684]    c86       2
    x[684]    c249      -69
    x[684]    c299      1
    x[685]    c70       -2
    x[685]    c92       2
    x[685]    c245      -69
    x[685]    c295      1
    x[686]    c70       -4
    x[686]    c87       4
    x[686]    c237      -69
    x[686]    c287      1
    x[687]    c30_2     1
    x[687]    c70       -5
    x[687]    c96       5
    x[687]    c232      -69
    x[687]    c282      1
    x[688]    c70       -1
    x[688]    c101      1
    x[688]    c225      -69
    x[688]    c275      1
    x[689]    c70       -4
    x[689]    c128      4
    x[689]    c224      -69
    x[689]    c274      1
    x[690]    c60_1     1
    x[690]    c70       -5
    x[690]    c108      5
    x[690]    c222      -69
    x[690]    c272      1
    x[691]    c70       -3
    x[691]    c89       3
    x[691]    c220      -69
    x[691]    c270      1
    x[692]    c70       -3
    x[692]    c105      3
    x[692]    c219      -69
    x[692]    c269      1
    x[693]    c70       -3
    x[693]    c106      3
    x[693]    c217      -69
    x[693]    c267      1
    x[694]    c70       -2
    x[694]    c90       2
    x[694]    c216      -69
    x[694]    c266      1
    x[695]    c70       -5
    x[695]    c110      5
    x[695]    c208      -69
    x[695]    c258      1
    x[696]    c70       -4
    x[696]    c81       4
    x[696]    c204      -69
    x[696]    c254      1
    x[697]    c70       -1
    x[697]    c93       1
    x[697]    c203      -69
    x[697]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[698]    c70       1
    x[698]    c71       -1
    MARKER    'MARKER'                 'INTORG'
    x[699]    c71       -2
    x[699]    c87       2
    x[699]    c249      -70
    x[699]    c299      1
    x[700]    c71       -2
    x[700]    c93       2
    x[700]    c245      -70
    x[700]    c295      1
    x[701]    c71       -4
    x[701]    c88       4
    x[701]    c237      -70
    x[701]    c287      1
    x[702]    c31_2     1
    x[702]    c71       -5
    x[702]    c97       5
    x[702]    c232      -70
    x[702]    c282      1
    x[703]    c71       -1
    x[703]    c102      1
    x[703]    c225      -70
    x[703]    c275      1
    x[704]    c71       -4
    x[704]    c129      4
    x[704]    c224      -70
    x[704]    c274      1
    x[705]    c61_1     1
    x[705]    c71       -5
    x[705]    c109      5
    x[705]    c222      -70
    x[705]    c272      1
    x[706]    c71       -3
    x[706]    c90       3
    x[706]    c220      -70
    x[706]    c270      1
    x[707]    c71       -3
    x[707]    c106      3
    x[707]    c219      -70
    x[707]    c269      1
    x[708]    c71       -3
    x[708]    c107      3
    x[708]    c217      -70
    x[708]    c267      1
    x[709]    c71       -2
    x[709]    c91       2
    x[709]    c216      -70
    x[709]    c266      1
    x[710]    c71       -5
    x[710]    c111      5
    x[710]    c208      -70
    x[710]    c258      1
    x[711]    c71       -1
    x[711]    c94       1
    x[711]    c203      -70
    x[711]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[712]    c71       1
    x[712]    c72       -1
    MARKER    'MARKER'                 'INTORG'
    x[713]    c72       -2
    x[713]    c88       2
    x[713]    c249      -71
    x[713]    c299      1
    x[714]    c72       -2
    x[714]    c94       2
    x[714]    c245      -71
    x[714]    c295      1
    x[715]    c72       -4
    x[715]    c89       4
    x[715]    c237      -71
    x[715]    c287      1
    x[716]    c32_2     1
    x[716]    c72       -5
    x[716]    c98       5
    x[716]    c232      -71
    x[716]    c282      1
    x[717]    c72       -1
    x[717]    c103      1
    x[717]    c225      -71
    x[717]    c275      1
    x[718]    c72       -4
    x[718]    c130      4
    x[718]    c224      -71
    x[718]    c274      1
    x[719]    c62_1     1
    x[719]    c72       -5
    x[719]    c110      5
    x[719]    c222      -71
    x[719]    c272      1
    x[720]    c72       -3
    x[720]    c91       3
    x[720]    c220      -71
    x[720]    c270      1
    x[721]    c72       -3
    x[721]    c107      3
    x[721]    c219      -71
    x[721]    c269      1
    x[722]    c72       -2
    x[722]    c92       2
    x[722]    c216      -71
    x[722]    c266      1
    x[723]    c72       -5
    x[723]    c112      5
    x[723]    c208      -71
    x[723]    c258      1
    x[724]    c72       -1
    x[724]    c95       1
    x[724]    c203      -71
    x[724]    c253      1
    MARKER    'MARKER'                 'INTEND'
    x[725]    c72       1
    x[725]    c73       -1
    MARKER    'MARKER'                 'INTORG'
    x[726]    c73       -2
    x[726]    c89       2
    x[726]    c249      -72
    x[726]    c299      1
    x[727]    c73       -2
    x[727]    c95       2
    x[727]    c245      -72
    x[727]    c295      1
    x[728]    c73       -4
    x[728]    c117      4
    x[728]    c242      -72
    x[728]    c292      1
    x[729]    c73       -4
    x[729]    c90       4
    x[729]    c237      -72
    x[729]    c287      1
    x[730]    c33_2     1
    x[730]    c73       -5
    x[730]    c99       5
    x[730]    c232      -72
    x[730]    c282      1
    x[731]    c73       -1
    x[731]    c104      1
    x[731]    c225      -72
    x[731]    c275      1
    x[732]    c73       -4
    x[732]    c131      4
    x[732]    c224      -72
    x[732]    c274      1
    x[733]    c63_1     1
    x[733]    c73       -5
    x[733]    c111      5
    x[733]    c222      -72
    x[733]    c272      1
    x[734]    c73       -3
    x[734]    c92       3
    x[734]    c220      -72
    x[734]    c270      1
    x[735]    c73       -3
    x[735]    c108      3
    x[735]    c219      -72
    x[735]    c269      1
    x[736]    c73       -2
    x[736]    c93       2
    x[736]    c216      -72
    x[736]    c266      1
    x[737]    c73       -3
    x[737]    c117      3
    x[737]    c210      -72
    x[737]    c260      1
    x[738]    c73       -5
    x[738]    c113      5
    x[738]    c208      -72
    x[738]    c258      1
    x[739]    c73       -1
    x[739]    c96       1
    x[739]    c203      -72
    x[739]    c253      1
    x[740]    c73       -2
    x[740]    c114      2
    x[740]    c202      -72
    x[740]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[741]    c73       1
    x[741]    c74       -1
    MARKER    'MARKER'                 'INTORG'
    x[742]    c74       -2
    x[742]    c90       2
    x[742]    c249      -73
    x[742]    c299      1
    x[743]    c74       -2
    x[743]    c96       2
    x[743]    c245      -73
    x[743]    c295      1
    x[744]    c74       -4
    x[744]    c118      4
    x[744]    c242      -73
    x[744]    c292      1
    x[745]    c74       -4
    x[745]    c91       4
    x[745]    c237      -73
    x[745]    c287      1
    x[746]    c34_2     1
    x[746]    c74       -5
    x[746]    c100      5
    x[746]    c232      -73
    x[746]    c282      1
    x[747]    c74       -1
    x[747]    c105      1
    x[747]    c225      -73
    x[747]    c275      1
    x[748]    c74       -4
    x[748]    c132      4
    x[748]    c224      -73
    x[748]    c274      1
    x[749]    c64_1     1
    x[749]    c74       -5
    x[749]    c112      5
    x[749]    c222      -73
    x[749]    c272      1
    x[750]    c74       -3
    x[750]    c93       3
    x[750]    c220      -73
    x[750]    c270      1
    x[751]    c74       -3
    x[751]    c109      3
    x[751]    c219      -73
    x[751]    c269      1
    x[752]    c74       -2
    x[752]    c94       2
    x[752]    c216      -73
    x[752]    c266      1
    x[753]    c74       -3
    x[753]    c118      3
    x[753]    c210      -73
    x[753]    c260      1
    x[754]    c74       -5
    x[754]    c114      5
    x[754]    c208      -73
    x[754]    c258      1
    x[755]    c74       -1
    x[755]    c97       1
    x[755]    c203      -73
    x[755]    c253      1
    x[756]    c74       -2
    x[756]    c115      2
    x[756]    c202      -73
    x[756]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[757]    c74       1
    x[757]    c75       -1
    MARKER    'MARKER'                 'INTORG'
    x[758]    c75       -2
    x[758]    c91       2
    x[758]    c249      -74
    x[758]    c299      1
    x[759]    c75       -2
    x[759]    c97       2
    x[759]    c245      -74
    x[759]    c295      1
    x[760]    c75       -4
    x[760]    c119      4
    x[760]    c242      -74
    x[760]    c292      1
    x[761]    c75       -4
    x[761]    c92       4
    x[761]    c237      -74
    x[761]    c287      1
    x[762]    c75       -1
    x[762]    c83       1
    x[762]    c236      -74
    x[762]    c286      1
    x[763]    c35_2     1
    x[763]    c75       -5
    x[763]    c101      5
    x[763]    c232      -74
    x[763]    c282      1
    x[764]    c75       -1
    x[764]    c106      1
    x[764]    c225      -74
    x[764]    c275      1
    x[765]    c75       -4
    x[765]    c133      4
    x[765]    c224      -74
    x[765]    c274      1
    x[766]    c65_1     1
    x[766]    c75       -5
    x[766]    c113      5
    x[766]    c222      -74
    x[766]    c272      1
    x[767]    c75       -3
    x[767]    c110      3
    x[767]    c219      -74
    x[767]    c269      1
    x[768]    c75       -2
    x[768]    c95       2
    x[768]    c216      -74
    x[768]    c266      1
    x[769]    c75       -3
    x[769]    c119      3
    x[769]    c210      -74
    x[769]    c260      1
    x[770]    c75       -5
    x[770]    c115      5
    x[770]    c208      -74
    x[770]    c258      1
    x[771]    c75       -1
    x[771]    c98       1
    x[771]    c203      -74
    x[771]    c253      1
    x[772]    c75       -2
    x[772]    c116      2
    x[772]    c202      -74
    x[772]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[773]    c75       1
    x[773]    c76       -1
    MARKER    'MARKER'                 'INTORG'
    x[774]    c76       -2
    x[774]    c92       2
    x[774]    c249      -75
    x[774]    c299      1
    x[775]    c76       -2
    x[775]    c98       2
    x[775]    c245      -75
    x[775]    c295      1
    x[776]    c76       -4
    x[776]    c120      4
    x[776]    c242      -75
    x[776]    c292      1
    x[777]    c76       -4
    x[777]    c93       4
    x[777]    c237      -75
    x[777]    c287      1
    x[778]    c76       -1
    x[778]    c84       1
    x[778]    c236      -75
    x[778]    c286      1
    x[779]    c36_2     1
    x[779]    c76       -5
    x[779]    c102      5
    x[779]    c232      -75
    x[779]    c282      1
    x[780]    c76       -1
    x[780]    c107      1
    x[780]    c225      -75
    x[780]    c275      1
    x[781]    c66_1     1
    x[781]    c76       -5
    x[781]    c114      5
    x[781]    c222      -75
    x[781]    c272      1
    x[782]    c76       -3
    x[782]    c111      3
    x[782]    c219      -75
    x[782]    c269      1
    x[783]    c76       -2
    x[783]    c96       2
    x[783]    c216      -75
    x[783]    c266      1
    x[784]    c76       -3
    x[784]    c120      3
    x[784]    c210      -75
    x[784]    c260      1
    x[785]    c76       -5
    x[785]    c116      5
    x[785]    c208      -75
    x[785]    c258      1
    x[786]    c76       -1
    x[786]    c99       1
    x[786]    c203      -75
    x[786]    c253      1
    x[787]    c76       -2
    x[787]    c117      2
    x[787]    c202      -75
    x[787]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[788]    c76       1
    x[788]    c77       -1
    MARKER    'MARKER'                 'INTORG'
    x[789]    c77       -2
    x[789]    c93       2
    x[789]    c249      -76
    x[789]    c299      1
    x[790]    c77       -2
    x[790]    c99       2
    x[790]    c245      -76
    x[790]    c295      1
    x[791]    c77       -4
    x[791]    c121      4
    x[791]    c242      -76
    x[791]    c292      1
    x[792]    c77       -1
    x[792]    c85       1
    x[792]    c236      -76
    x[792]    c286      1
    x[793]    c37_2     1
    x[793]    c77       -5
    x[793]    c103      5
    x[793]    c232      -76
    x[793]    c282      1
    x[794]    c77       -1
    x[794]    c108      1
    x[794]    c225      -76
    x[794]    c275      1
    x[795]    c67_1     1
    x[795]    c77       -5
    x[795]    c115      5
    x[795]    c222      -76
    x[795]    c272      1
    x[796]    c77       -3
    x[796]    c112      3
    x[796]    c219      -76
    x[796]    c269      1
    x[797]    c77       -2
    x[797]    c97       2
    x[797]    c216      -76
    x[797]    c266      1
    x[798]    c77       -3
    x[798]    c121      3
    x[798]    c210      -76
    x[798]    c260      1
    x[799]    c77       -5
    x[799]    c117      5
    x[799]    c208      -76
    x[799]    c258      1
    x[800]    c77       -1
    x[800]    c100      1
    x[800]    c203      -76
    x[800]    c253      1
    x[801]    c77       -2
    x[801]    c118      2
    x[801]    c202      -76
    x[801]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[802]    c77       1
    x[802]    c78       -1
    MARKER    'MARKER'                 'INTORG'
    x[803]    c78       -2
    x[803]    c94       2
    x[803]    c249      -77
    x[803]    c299      1
    x[804]    c78       -2
    x[804]    c100      2
    x[804]    c245      -77
    x[804]    c295      1
    x[805]    c78       -4
    x[805]    c122      4
    x[805]    c242      -77
    x[805]    c292      1
    x[806]    c78       -1
    x[806]    c86       1
    x[806]    c236      -77
    x[806]    c286      1
    x[807]    c38_2     1
    x[807]    c78       -5
    x[807]    c104      5
    x[807]    c232      -77
    x[807]    c282      1
    x[808]    c78       -1
    x[808]    c109      1
    x[808]    c225      -77
    x[808]    c275      1
    x[809]    c68_1     1
    x[809]    c78       -5
    x[809]    c116      5
    x[809]    c222      -77
    x[809]    c272      1
    x[810]    c78       -3
    x[810]    c113      3
    x[810]    c219      -77
    x[810]    c269      1
    x[811]    c78       -2
    x[811]    c98       2
    x[811]    c216      -77
    x[811]    c266      1
    x[812]    c78       -3
    x[812]    c122      3
    x[812]    c210      -77
    x[812]    c260      1
    x[813]    c78       -5
    x[813]    c118      5
    x[813]    c208      -77
    x[813]    c258      1
    x[814]    c78       -1
    x[814]    c101      1
    x[814]    c203      -77
    x[814]    c253      1
    x[815]    c78       -2
    x[815]    c119      2
    x[815]    c202      -77
    x[815]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[816]    c78       1
    x[816]    c79       -1
    MARKER    'MARKER'                 'INTORG'
    x[817]    c79       -2
    x[817]    c95       2
    x[817]    c249      -78
    x[817]    c299      1
    x[818]    c79       -2
    x[818]    c101      2
    x[818]    c245      -78
    x[818]    c295      1
    x[819]    c79       -4
    x[819]    c123      4
    x[819]    c242      -78
    x[819]    c292      1
    x[820]    c79       -1
    x[820]    c87       1
    x[820]    c236      -78
    x[820]    c286      1
    x[821]    c39_2     1
    x[821]    c79       -5
    x[821]    c105      5
    x[821]    c232      -78
    x[821]    c282      1
    x[822]    c79       -1
    x[822]    c110      1
    x[822]    c225      -78
    x[822]    c275      1
    x[823]    c69_1     1
    x[823]    c79       -5
    x[823]    c117      5
    x[823]    c222      -78
    x[823]    c272      1
    x[824]    c79       -3
    x[824]    c114      3
    x[824]    c219      -78
    x[824]    c269      1
    x[825]    c79       -2
    x[825]    c99       2
    x[825]    c216      -78
    x[825]    c266      1
    x[826]    c79       -3
    x[826]    c123      3
    x[826]    c210      -78
    x[826]    c260      1
    x[827]    c79       -5
    x[827]    c119      5
    x[827]    c208      -78
    x[827]    c258      1
    x[828]    c79       -1
    x[828]    c102      1
    x[828]    c203      -78
    x[828]    c253      1
    x[829]    c79       -2
    x[829]    c120      2
    x[829]    c202      -78
    x[829]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[830]    c79       1
    x[830]    c80       -1
    MARKER    'MARKER'                 'INTORG'
    x[831]    c80       -2
    x[831]    c96       2
    x[831]    c249      -79
    x[831]    c299      1
    x[832]    c80       -2
    x[832]    c102      2
    x[832]    c245      -79
    x[832]    c295      1
    x[833]    c80       -4
    x[833]    c124      4
    x[833]    c242      -79
    x[833]    c292      1
    x[834]    c80       -1
    x[834]    c88       1
    x[834]    c236      -79
    x[834]    c286      1
    x[835]    c40_2     1
    x[835]    c80       -5
    x[835]    c106      5
    x[835]    c232      -79
    x[835]    c282      1
    x[836]    c80       -1
    x[836]    c112      1
    x[836]    c227      -79
    x[836]    c277      1
    x[837]    c80       -1
    x[837]    c111      1
    x[837]    c225      -79
    x[837]    c275      1
    x[838]    c70_1     1
    x[838]    c80       -5
    x[838]    c118      5
    x[838]    c222      -79
    x[838]    c272      1
    x[839]    c80       -3
    x[839]    c115      3
    x[839]    c219      -79
    x[839]    c269      1
    x[840]    c80       -2
    x[840]    c100      2
    x[840]    c216      -79
    x[840]    c266      1
    x[841]    c80       -3
    x[841]    c124      3
    x[841]    c210      -79
    x[841]    c260      1
    x[842]    c80       -5
    x[842]    c120      5
    x[842]    c208      -79
    x[842]    c258      1
    x[843]    c80       -1
    x[843]    c103      1
    x[843]    c203      -79
    x[843]    c253      1
    x[844]    c80       -2
    x[844]    c121      2
    x[844]    c202      -79
    x[844]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[845]    c80       1
    x[845]    c81       -1
    MARKER    'MARKER'                 'INTORG'
    x[846]    c81       -2
    x[846]    c98       2
    x[846]    c251      -80
    x[846]    c301      1
    x[847]    c81       -2
    x[847]    c97       2
    x[847]    c249      -80
    x[847]    c299      1
    x[848]    c81       -2
    x[848]    c103      2
    x[848]    c245      -80
    x[848]    c295      1
    x[849]    c81       -4
    x[849]    c125      4
    x[849]    c242      -80
    x[849]    c292      1
    x[850]    c81       -1
    x[850]    c89       1
    x[850]    c236      -80
    x[850]    c286      1
    x[851]    c41_2     1
    x[851]    c81       -5
    x[851]    c107      5
    x[851]    c232      -80
    x[851]    c282      1
    x[852]    c81       -1
    x[852]    c113      1
    x[852]    c227      -80
    x[852]    c277      1
    x[853]    c81       -1
    x[853]    c112      1
    x[853]    c225      -80
    x[853]    c275      1
    x[854]    c71_1     1
    x[854]    c81       -5
    x[854]    c119      5
    x[854]    c222      -80
    x[854]    c272      1
    x[855]    c81       -3
    x[855]    c116      3
    x[855]    c219      -80
    x[855]    c269      1
    x[856]    c81       -2
    x[856]    c101      2
    x[856]    c216      -80
    x[856]    c266      1
    x[857]    c81       -3
    x[857]    c125      3
    x[857]    c210      -80
    x[857]    c260      1
    x[858]    c81       -5
    x[858]    c121      5
    x[858]    c208      -80
    x[858]    c258      1
    x[859]    c81       -1
    x[859]    c104      1
    x[859]    c203      -80
    x[859]    c253      1
    x[860]    c81       -2
    x[860]    c122      2
    x[860]    c202      -80
    x[860]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[861]    c81       1
    x[861]    c82       -1
    MARKER    'MARKER'                 'INTORG'
    x[862]    c82       -2
    x[862]    c99       2
    x[862]    c251      -81
    x[862]    c301      1
    x[863]    c82       -2
    x[863]    c98       2
    x[863]    c249      -81
    x[863]    c299      1
    x[864]    c82       -2
    x[864]    c104      2
    x[864]    c245      -81
    x[864]    c295      1
    x[865]    c82       -4
    x[865]    c126      4
    x[865]    c242      -81
    x[865]    c292      1
    x[866]    c82       -1
    x[866]    c90       1
    x[866]    c236      -81
    x[866]    c286      1
    x[867]    c42_2     1
    x[867]    c82       -5
    x[867]    c108      5
    x[867]    c232      -81
    x[867]    c282      1
    x[868]    c82       -1
    x[868]    c114      1
    x[868]    c227      -81
    x[868]    c277      1
    x[869]    c72_1     1
    x[869]    c82       -5
    x[869]    c120      5
    x[869]    c222      -81
    x[869]    c272      1
    x[870]    c82       -3
    x[870]    c117      3
    x[870]    c219      -81
    x[870]    c269      1
    x[871]    c82       -2
    x[871]    c102      2
    x[871]    c216      -81
    x[871]    c266      1
    x[872]    c82       -3
    x[872]    c126      3
    x[872]    c210      -81
    x[872]    c260      1
    x[873]    c82       -5
    x[873]    c122      5
    x[873]    c208      -81
    x[873]    c258      1
    x[874]    c82       -1
    x[874]    c105      1
    x[874]    c203      -81
    x[874]    c253      1
    x[875]    c82       -2
    x[875]    c123      2
    x[875]    c202      -81
    x[875]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[876]    c82       1
    x[876]    c83       -1
    MARKER    'MARKER'                 'INTORG'
    x[877]    c83       -2
    x[877]    c100      2
    x[877]    c251      -82
    x[877]    c301      1
    x[878]    c83       -2
    x[878]    c99       2
    x[878]    c249      -82
    x[878]    c299      1
    x[879]    c83       -2
    x[879]    c105      2
    x[879]    c245      -82
    x[879]    c295      1
    x[880]    c83       -4
    x[880]    c127      4
    x[880]    c242      -82
    x[880]    c292      1
    x[881]    c83       -1
    x[881]    c91       1
    x[881]    c236      -82
    x[881]    c286      1
    x[882]    c43_2     1
    x[882]    c83       -5
    x[882]    c109      5
    x[882]    c232      -82
    x[882]    c282      1
    x[883]    c83       -1
    x[883]    c115      1
    x[883]    c227      -82
    x[883]    c277      1
    x[884]    c73_1     1
    x[884]    c83       -5
    x[884]    c121      5
    x[884]    c222      -82
    x[884]    c272      1
    x[885]    c83       -3
    x[885]    c118      3
    x[885]    c219      -82
    x[885]    c269      1
    x[886]    c83       -2
    x[886]    c103      2
    x[886]    c216      -82
    x[886]    c266      1
    x[887]    c83       -3
    x[887]    c127      3
    x[887]    c210      -82
    x[887]    c260      1
    x[888]    c83       -5
    x[888]    c123      5
    x[888]    c208      -82
    x[888]    c258      1
    x[889]    c83       -1
    x[889]    c106      1
    x[889]    c203      -82
    x[889]    c253      1
    x[890]    c83       -2
    x[890]    c124      2
    x[890]    c202      -82
    x[890]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[891]    c83       1
    x[891]    c84       -1
    MARKER    'MARKER'                 'INTORG'
    x[892]    c84       -2
    x[892]    c101      2
    x[892]    c251      -83
    x[892]    c301      1
    x[893]    c84       -2
    x[893]    c100      2
    x[893]    c249      -83
    x[893]    c299      1
    x[894]    c84       -2
    x[894]    c106      2
    x[894]    c245      -83
    x[894]    c295      1
    x[895]    c84       -4
    x[895]    c128      4
    x[895]    c242      -83
    x[895]    c292      1
    x[896]    c84       -1
    x[896]    c92       1
    x[896]    c236      -83
    x[896]    c286      1
    x[897]    c44_2     1
    x[897]    c84       -5
    x[897]    c110      5
    x[897]    c232      -83
    x[897]    c282      1
    x[898]    c84       -1
    x[898]    c116      1
    x[898]    c227      -83
    x[898]    c277      1
    x[899]    c74_1     1
    x[899]    c84       -5
    x[899]    c122      5
    x[899]    c222      -83
    x[899]    c272      1
    x[900]    c84       -3
    x[900]    c119      3
    x[900]    c219      -83
    x[900]    c269      1
    x[901]    c84       -2
    x[901]    c104      2
    x[901]    c216      -83
    x[901]    c266      1
    x[902]    c84       -3
    x[902]    c128      3
    x[902]    c210      -83
    x[902]    c260      1
    x[903]    c84       -5
    x[903]    c124      5
    x[903]    c208      -83
    x[903]    c258      1
    x[904]    c84       -1
    x[904]    c107      1
    x[904]    c203      -83
    x[904]    c253      1
    x[905]    c84       -2
    x[905]    c125      2
    x[905]    c202      -83
    x[905]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[906]    c84       1
    x[906]    c85       -1
    MARKER    'MARKER'                 'INTORG'
    x[907]    c85       -2
    x[907]    c102      2
    x[907]    c251      -84
    x[907]    c301      1
    x[908]    c85       -2
    x[908]    c101      2
    x[908]    c249      -84
    x[908]    c299      1
    x[909]    c85       -2
    x[909]    c107      2
    x[909]    c245      -84
    x[909]    c295      1
    x[910]    c85       -4
    x[910]    c129      4
    x[910]    c242      -84
    x[910]    c292      1
    x[911]    c85       -1
    x[911]    c93       1
    x[911]    c236      -84
    x[911]    c286      1
    x[912]    c45_2     1
    x[912]    c85       -5
    x[912]    c111      5
    x[912]    c232      -84
    x[912]    c282      1
    x[913]    c85       -1
    x[913]    c117      1
    x[913]    c227      -84
    x[913]    c277      1
    x[914]    c85       -3
    x[914]    c120      3
    x[914]    c219      -84
    x[914]    c269      1
    x[915]    c85       -2
    x[915]    c105      2
    x[915]    c216      -84
    x[915]    c266      1
    x[916]    c85       -3
    x[916]    c129      3
    x[916]    c210      -84
    x[916]    c260      1
    x[917]    c85       -5
    x[917]    c125      5
    x[917]    c208      -84
    x[917]    c258      1
    x[918]    c85       -1
    x[918]    c108      1
    x[918]    c203      -84
    x[918]    c253      1
    x[919]    c85       -2
    x[919]    c126      2
    x[919]    c202      -84
    x[919]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[920]    c85       1
    x[920]    c86       -1
    MARKER    'MARKER'                 'INTORG'
    x[921]    c86       -2
    x[921]    c103      2
    x[921]    c251      -85
    x[921]    c301      1
    x[922]    c86       -2
    x[922]    c102      2
    x[922]    c249      -85
    x[922]    c299      1
    x[923]    c86       -2
    x[923]    c108      2
    x[923]    c245      -85
    x[923]    c295      1
    x[924]    c86       -4
    x[924]    c130      4
    x[924]    c242      -85
    x[924]    c292      1
    x[925]    c86       -1
    x[925]    c94       1
    x[925]    c236      -85
    x[925]    c286      1
    x[926]    c46_2     1
    x[926]    c86       -5
    x[926]    c112      5
    x[926]    c232      -85
    x[926]    c282      1
    x[927]    c86       -1
    x[927]    c118      1
    x[927]    c227      -85
    x[927]    c277      1
    x[928]    c86       -3
    x[928]    c121      3
    x[928]    c219      -85
    x[928]    c269      1
    x[929]    c86       -2
    x[929]    c106      2
    x[929]    c216      -85
    x[929]    c266      1
    x[930]    c86       -3
    x[930]    c130      3
    x[930]    c210      -85
    x[930]    c260      1
    x[931]    c86       -5
    x[931]    c126      5
    x[931]    c208      -85
    x[931]    c258      1
    x[932]    c86       -1
    x[932]    c109      1
    x[932]    c203      -85
    x[932]    c253      1
    x[933]    c86       -2
    x[933]    c127      2
    x[933]    c202      -85
    x[933]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[934]    c86       1
    x[934]    c87       -1
    MARKER    'MARKER'                 'INTORG'
    x[935]    c87       -2
    x[935]    c104      2
    x[935]    c251      -86
    x[935]    c301      1
    x[936]    c87       -2
    x[936]    c103      2
    x[936]    c249      -86
    x[936]    c299      1
    x[937]    c87       -2
    x[937]    c109      2
    x[937]    c245      -86
    x[937]    c295      1
    x[938]    c87       -4
    x[938]    c131      4
    x[938]    c242      -86
    x[938]    c292      1
    x[939]    c87       -1
    x[939]    c95       1
    x[939]    c236      -86
    x[939]    c286      1
    x[940]    c47_2     1
    x[940]    c87       -5
    x[940]    c113      5
    x[940]    c232      -86
    x[940]    c282      1
    x[941]    c87       -4
    x[941]    c114      4
    x[941]    c231      -86
    x[941]    c281      1
    x[942]    c87       -1
    x[942]    c119      1
    x[942]    c227      -86
    x[942]    c277      1
    x[943]    c87       -3
    x[943]    c122      3
    x[943]    c219      -86
    x[943]    c269      1
    x[944]    c87       -2
    x[944]    c107      2
    x[944]    c216      -86
    x[944]    c266      1
    x[945]    c87       -3
    x[945]    c131      3
    x[945]    c210      -86
    x[945]    c260      1
    x[946]    c87       -5
    x[946]    c127      5
    x[946]    c208      -86
    x[946]    c258      1
    x[947]    c87       -1
    x[947]    c110      1
    x[947]    c203      -86
    x[947]    c253      1
    x[948]    c87       -2
    x[948]    c128      2
    x[948]    c202      -86
    x[948]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[949]    c87       1
    x[949]    c88       -1
    MARKER    'MARKER'                 'INTORG'
    x[950]    c88       -2
    x[950]    c105      2
    x[950]    c251      -87
    x[950]    c301      1
    x[951]    c88       -2
    x[951]    c104      2
    x[951]    c249      -87
    x[951]    c299      1
    x[952]    c88       -2
    x[952]    c110      2
    x[952]    c245      -87
    x[952]    c295      1
    x[953]    c88       -4
    x[953]    c132      4
    x[953]    c242      -87
    x[953]    c292      1
    x[954]    c88       -1
    x[954]    c96       1
    x[954]    c236      -87
    x[954]    c286      1
    x[955]    c48_2     1
    x[955]    c88       -5
    x[955]    c114      5
    x[955]    c232      -87
    x[955]    c282      1
    x[956]    c88       -4
    x[956]    c115      4
    x[956]    c231      -87
    x[956]    c281      1
    x[957]    c88       -1
    x[957]    c120      1
    x[957]    c227      -87
    x[957]    c277      1
    x[958]    c88       -3
    x[958]    c123      3
    x[958]    c219      -87
    x[958]    c269      1
    x[959]    c88       -2
    x[959]    c108      2
    x[959]    c216      -87
    x[959]    c266      1
    x[960]    c88       -3
    x[960]    c132      3
    x[960]    c210      -87
    x[960]    c260      1
    x[961]    c88       -1
    x[961]    c111      1
    x[961]    c203      -87
    x[961]    c253      1
    x[962]    c88       -2
    x[962]    c129      2
    x[962]    c202      -87
    x[962]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[963]    c88       1
    x[963]    c89       -1
    MARKER    'MARKER'                 'INTORG'
    x[964]    c89       -2
    x[964]    c106      2
    x[964]    c251      -88
    x[964]    c301      1
    x[965]    c89       -2
    x[965]    c105      2
    x[965]    c249      -88
    x[965]    c299      1
    x[966]    c89       -2
    x[966]    c111      2
    x[966]    c245      -88
    x[966]    c295      1
    x[967]    c89       -4
    x[967]    c133      4
    x[967]    c242      -88
    x[967]    c292      1
    x[968]    c49_2     1
    x[968]    c89       -5
    x[968]    c115      5
    x[968]    c232      -88
    x[968]    c282      1
    x[969]    c89       -4
    x[969]    c116      4
    x[969]    c231      -88
    x[969]    c281      1
    x[970]    c89       -1
    x[970]    c121      1
    x[970]    c227      -88
    x[970]    c277      1
    x[971]    c89       -3
    x[971]    c124      3
    x[971]    c219      -88
    x[971]    c269      1
    x[972]    c89       -2
    x[972]    c109      2
    x[972]    c216      -88
    x[972]    c266      1
    x[973]    c89       -3
    x[973]    c133      3
    x[973]    c210      -88
    x[973]    c260      1
    x[974]    c89       -1
    x[974]    c112      1
    x[974]    c203      -88
    x[974]    c253      1
    x[975]    c89       -2
    x[975]    c130      2
    x[975]    c202      -88
    x[975]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[976]    c89       1
    x[976]    c90       -1
    MARKER    'MARKER'                 'INTORG'
    x[977]    c90       -2
    x[977]    c107      2
    x[977]    c251      -89
    x[977]    c301      1
    x[978]    c90       -2
    x[978]    c106      2
    x[978]    c249      -89
    x[978]    c299      1
    x[979]    c90       -2
    x[979]    c112      2
    x[979]    c245      -89
    x[979]    c295      1
    x[980]    c90       -4
    x[980]    c134      4
    x[980]    c242      -89
    x[980]    c292      1
    x[981]    c50_2     1
    x[981]    c90       -5
    x[981]    c116      5
    x[981]    c232      -89
    x[981]    c282      1
    x[982]    c90       -4
    x[982]    c117      4
    x[982]    c231      -89
    x[982]    c281      1
    x[983]    c90       -1
    x[983]    c122      1
    x[983]    c227      -89
    x[983]    c277      1
    x[984]    c90       -3
    x[984]    c125      3
    x[984]    c219      -89
    x[984]    c269      1
    x[985]    c90       -2
    x[985]    c110      2
    x[985]    c216      -89
    x[985]    c266      1
    x[986]    c90       -3
    x[986]    c134      3
    x[986]    c210      -89
    x[986]    c260      1
    x[987]    c90       -1
    x[987]    c113      1
    x[987]    c203      -89
    x[987]    c253      1
    x[988]    c90       -2
    x[988]    c131      2
    x[988]    c202      -89
    x[988]    c252      1
    MARKER    'MARKER'                 'INTEND'
    x[989]    c90       1
    x[989]    c91       -1
    MARKER    'MARKER'                 'INTORG'
    x[990]    c91       -2
    x[990]    c108      2
    x[990]    c251      -90
    x[990]    c301      1
    x[991]    c91       -2
    x[991]    c107      2
    x[991]    c249      -90
    x[991]    c299      1
    x[992]    c91       -2
    x[992]    c113      2
    x[992]    c245      -90
    x[992]    c295      1
    x[993]    c91       -4
    x[993]    c135      4
    x[993]    c242      -90
    x[993]    c292      1
    x[994]    c91       -4
    x[994]    c100      4
    x[994]    c240      -90
    x[994]    c290      1
    x[995]    c51_1     1
    x[995]    c91       -5
    x[995]    c117      5
    x[995]    c232      -90
    x[995]    c282      1
    x[996]    c91       -4
    x[996]    c118      4
    x[996]    c231      -90
    x[996]    c281      1
    x[997]    c91       -1
    x[997]    c123      1
    x[997]    c227      -90
    x[997]    c277      1
    x[998]    c91       -3
    x[998]    c126      3
    x[998]    c219      -90
    x[998]    c269      1
    x[999]    c91       -2
    x[999]    c111      2
    x[999]    c216      -90
    x[999]    c266      1
    x[1000]   c91       -3
    x[1000]   c135      3
    x[1000]   c210      -90
    x[1000]   c260      1
    x[1001]   c91       -1
    x[1001]   c114      1
    x[1001]   c203      -90
    x[1001]   c253      1
    x[1002]   c91       -2
    x[1002]   c132      2
    x[1002]   c202      -90
    x[1002]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1003]   c91       1
    x[1003]   c92       -1
    MARKER    'MARKER'                 'INTORG'
    x[1004]   c92       -2
    x[1004]   c109      2
    x[1004]   c251      -91
    x[1004]   c301      1
    x[1005]   c92       -2
    x[1005]   c108      2
    x[1005]   c249      -91
    x[1005]   c299      1
    x[1006]   c92       -2
    x[1006]   c114      2
    x[1006]   c245      -91
    x[1006]   c295      1
    x[1007]   c92       -4
    x[1007]   c136      4
    x[1007]   c242      -91
    x[1007]   c292      1
    x[1008]   c92       -4
    x[1008]   c101      4
    x[1008]   c240      -91
    x[1008]   c290      1
    x[1009]   c52_1     1
    x[1009]   c92       -5
    x[1009]   c118      5
    x[1009]   c232      -91
    x[1009]   c282      1
    x[1010]   c92       -4
    x[1010]   c119      4
    x[1010]   c231      -91
    x[1010]   c281      1
    x[1011]   c92       -1
    x[1011]   c124      1
    x[1011]   c227      -91
    x[1011]   c277      1
    x[1012]   c92       -3
    x[1012]   c127      3
    x[1012]   c219      -91
    x[1012]   c269      1
    x[1013]   c92       -2
    x[1013]   c112      2
    x[1013]   c216      -91
    x[1013]   c266      1
    x[1014]   c92       -3
    x[1014]   c136      3
    x[1014]   c210      -91
    x[1014]   c260      1
    x[1015]   c92       -1
    x[1015]   c115      1
    x[1015]   c203      -91
    x[1015]   c253      1
    x[1016]   c92       -2
    x[1016]   c133      2
    x[1016]   c202      -91
    x[1016]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1017]   c92       1
    x[1017]   c93       -1
    MARKER    'MARKER'                 'INTORG'
    x[1018]   c93       -2
    x[1018]   c110      2
    x[1018]   c251      -92
    x[1018]   c301      1
    x[1019]   c93       -2
    x[1019]   c109      2
    x[1019]   c249      -92
    x[1019]   c299      1
    x[1020]   c93       -2
    x[1020]   c115      2
    x[1020]   c245      -92
    x[1020]   c295      1
    x[1021]   c93       -4
    x[1021]   c137      4
    x[1021]   c242      -92
    x[1021]   c292      1
    x[1022]   c93       -4
    x[1022]   c102      4
    x[1022]   c240      -92
    x[1022]   c290      1
    x[1023]   c27_2     1
    x[1023]   c93       -5
    x[1023]   c119      5
    x[1023]   c232      -92
    x[1023]   c282      1
    x[1024]   c93       -4
    x[1024]   c120      4
    x[1024]   c231      -92
    x[1024]   c281      1
    x[1025]   c93       -1
    x[1025]   c125      1
    x[1025]   c227      -92
    x[1025]   c277      1
    x[1026]   c93       -3
    x[1026]   c128      3
    x[1026]   c219      -92
    x[1026]   c269      1
    x[1027]   c93       -2
    x[1027]   c113      2
    x[1027]   c216      -92
    x[1027]   c266      1
    x[1028]   c93       -3
    x[1028]   c137      3
    x[1028]   c210      -92
    x[1028]   c260      1
    x[1029]   c93       -1
    x[1029]   c116      1
    x[1029]   c203      -92
    x[1029]   c253      1
    x[1030]   c93       -2
    x[1030]   c134      2
    x[1030]   c202      -92
    x[1030]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1031]   c93       1
    x[1031]   c94       -1
    MARKER    'MARKER'                 'INTORG'
    x[1032]   c94       -2
    x[1032]   c111      2
    x[1032]   c251      -93
    x[1032]   c301      1
    x[1033]   c94       -2
    x[1033]   c110      2
    x[1033]   c249      -93
    x[1033]   c299      1
    x[1034]   c94       -2
    x[1034]   c116      2
    x[1034]   c245      -93
    x[1034]   c295      1
    x[1035]   c94       -4
    x[1035]   c138      4
    x[1035]   c242      -93
    x[1035]   c292      1
    x[1036]   c94       -4
    x[1036]   c103      4
    x[1036]   c240      -93
    x[1036]   c290      1
    x[1037]   c28_2     1
    x[1037]   c94       -5
    x[1037]   c120      5
    x[1037]   c232      -93
    x[1037]   c282      1
    x[1038]   c94       -4
    x[1038]   c121      4
    x[1038]   c231      -93
    x[1038]   c281      1
    x[1039]   c94       -1
    x[1039]   c126      1
    x[1039]   c227      -93
    x[1039]   c277      1
    x[1040]   c94       -2
    x[1040]   c114      2
    x[1040]   c216      -93
    x[1040]   c266      1
    x[1041]   c94       -3
    x[1041]   c138      3
    x[1041]   c210      -93
    x[1041]   c260      1
    x[1042]   c94       -1
    x[1042]   c117      1
    x[1042]   c203      -93
    x[1042]   c253      1
    x[1043]   c94       -2
    x[1043]   c135      2
    x[1043]   c202      -93
    x[1043]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1044]   c94       1
    x[1044]   c95       -1
    MARKER    'MARKER'                 'INTORG'
    x[1045]   c95       -2
    x[1045]   c112      2
    x[1045]   c251      -94
    x[1045]   c301      1
    x[1046]   c95       -2
    x[1046]   c111      2
    x[1046]   c249      -94
    x[1046]   c299      1
    x[1047]   c95       -2
    x[1047]   c117      2
    x[1047]   c245      -94
    x[1047]   c295      1
    x[1048]   c95       -4
    x[1048]   c139      4
    x[1048]   c242      -94
    x[1048]   c292      1
    x[1049]   c95       -4
    x[1049]   c104      4
    x[1049]   c240      -94
    x[1049]   c290      1
    x[1050]   c29_2     1
    x[1050]   c95       -5
    x[1050]   c121      5
    x[1050]   c232      -94
    x[1050]   c282      1
    x[1051]   c95       -4
    x[1051]   c122      4
    x[1051]   c231      -94
    x[1051]   c281      1
    x[1052]   c95       -1
    x[1052]   c127      1
    x[1052]   c227      -94
    x[1052]   c277      1
    x[1053]   c95       -2
    x[1053]   c115      2
    x[1053]   c216      -94
    x[1053]   c266      1
    x[1054]   c95       -3
    x[1054]   c139      3
    x[1054]   c210      -94
    x[1054]   c260      1
    x[1055]   c95       -1
    x[1055]   c118      1
    x[1055]   c203      -94
    x[1055]   c253      1
    x[1056]   c95       -2
    x[1056]   c136      2
    x[1056]   c202      -94
    x[1056]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1057]   c95       1
    x[1057]   c96       -1
    MARKER    'MARKER'                 'INTORG'
    x[1058]   c96       -2
    x[1058]   c113      2
    x[1058]   c251      -95
    x[1058]   c301      1
    x[1059]   c96       -2
    x[1059]   c112      2
    x[1059]   c249      -95
    x[1059]   c299      1
    x[1060]   c96       -2
    x[1060]   c118      2
    x[1060]   c245      -95
    x[1060]   c295      1
    x[1061]   c96       -4
    x[1061]   c140      4
    x[1061]   c242      -95
    x[1061]   c292      1
    x[1062]   c96       -4
    x[1062]   c105      4
    x[1062]   c240      -95
    x[1062]   c290      1
    x[1063]   c30_2     1
    x[1063]   c96       -5
    x[1063]   c122      5
    x[1063]   c232      -95
    x[1063]   c282      1
    x[1064]   c96       -4
    x[1064]   c123      4
    x[1064]   c231      -95
    x[1064]   c281      1
    x[1065]   c96       -1
    x[1065]   c128      1
    x[1065]   c228      -95
    x[1065]   c278      1
    x[1066]   c96       -1
    x[1066]   c128      1
    x[1066]   c227      -95
    x[1066]   c277      1
    x[1067]   c96       -2
    x[1067]   c116      2
    x[1067]   c216      -95
    x[1067]   c266      1
    x[1068]   c96       -3
    x[1068]   c140      3
    x[1068]   c210      -95
    x[1068]   c260      1
    x[1069]   c96       -1
    x[1069]   c119      1
    x[1069]   c203      -95
    x[1069]   c253      1
    x[1070]   c96       -2
    x[1070]   c137      2
    x[1070]   c202      -95
    x[1070]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1071]   c96       1
    x[1071]   c97       -1
    MARKER    'MARKER'                 'INTORG'
    x[1072]   c97       -2
    x[1072]   c114      2
    x[1072]   c251      -96
    x[1072]   c301      1
    x[1073]   c97       -2
    x[1073]   c113      2
    x[1073]   c249      -96
    x[1073]   c299      1
    x[1074]   c97       -2
    x[1074]   c119      2
    x[1074]   c245      -96
    x[1074]   c295      1
    x[1075]   c97       -4
    x[1075]   c106      4
    x[1075]   c240      -96
    x[1075]   c290      1
    x[1076]   c31_2     1
    x[1076]   c97       -5
    x[1076]   c123      5
    x[1076]   c232      -96
    x[1076]   c282      1
    x[1077]   c97       -4
    x[1077]   c124      4
    x[1077]   c231      -96
    x[1077]   c281      1
    x[1078]   c97       -1
    x[1078]   c129      1
    x[1078]   c228      -96
    x[1078]   c278      1
    x[1079]   c97       -1
    x[1079]   c129      1
    x[1079]   c227      -96
    x[1079]   c277      1
    x[1080]   c97       -2
    x[1080]   c117      2
    x[1080]   c216      -96
    x[1080]   c266      1
    x[1081]   c97       -3
    x[1081]   c141      3
    x[1081]   c210      -96
    x[1081]   c260      1
    x[1082]   c97       -1
    x[1082]   c120      1
    x[1082]   c203      -96
    x[1082]   c253      1
    x[1083]   c97       -2
    x[1083]   c138      2
    x[1083]   c202      -96
    x[1083]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1084]   c97       1
    x[1084]   c98       -1
    MARKER    'MARKER'                 'INTORG'
    x[1085]   c98       -2
    x[1085]   c115      2
    x[1085]   c251      -97
    x[1085]   c301      1
    x[1086]   c98       -2
    x[1086]   c114      2
    x[1086]   c249      -97
    x[1086]   c299      1
    x[1087]   c98       -2
    x[1087]   c120      2
    x[1087]   c245      -97
    x[1087]   c295      1
    x[1088]   c98       -4
    x[1088]   c107      4
    x[1088]   c240      -97
    x[1088]   c290      1
    x[1089]   c32_2     1
    x[1089]   c98       -5
    x[1089]   c124      5
    x[1089]   c232      -97
    x[1089]   c282      1
    x[1090]   c98       -4
    x[1090]   c125      4
    x[1090]   c231      -97
    x[1090]   c281      1
    x[1091]   c98       -1
    x[1091]   c130      1
    x[1091]   c228      -97
    x[1091]   c278      1
    x[1092]   c98       -1
    x[1092]   c130      1
    x[1092]   c227      -97
    x[1092]   c277      1
    x[1093]   c98       -2
    x[1093]   c118      2
    x[1093]   c216      -97
    x[1093]   c266      1
    x[1094]   c98       -3
    x[1094]   c142      3
    x[1094]   c210      -97
    x[1094]   c260      1
    x[1095]   c98       -1
    x[1095]   c121      1
    x[1095]   c203      -97
    x[1095]   c253      1
    x[1096]   c98       -2
    x[1096]   c139      2
    x[1096]   c202      -97
    x[1096]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1097]   c98       1
    x[1097]   c99       -1
    MARKER    'MARKER'                 'INTORG'
    x[1098]   c99       -2
    x[1098]   c116      2
    x[1098]   c251      -98
    x[1098]   c301      1
    x[1099]   c99       -2
    x[1099]   c115      2
    x[1099]   c249      -98
    x[1099]   c299      1
    x[1100]   c99       -2
    x[1100]   c121      2
    x[1100]   c245      -98
    x[1100]   c295      1
    x[1101]   c99       -4
    x[1101]   c108      4
    x[1101]   c240      -98
    x[1101]   c290      1
    x[1102]   c33_2     1
    x[1102]   c99       -5
    x[1102]   c125      5
    x[1102]   c232      -98
    x[1102]   c282      1
    x[1103]   c99       -4
    x[1103]   c126      4
    x[1103]   c231      -98
    x[1103]   c281      1
    x[1104]   c99       -1
    x[1104]   c131      1
    x[1104]   c228      -98
    x[1104]   c278      1
    x[1105]   c99       -1
    x[1105]   c131      1
    x[1105]   c227      -98
    x[1105]   c277      1
    x[1106]   c99       -2
    x[1106]   c119      2
    x[1106]   c216      -98
    x[1106]   c266      1
    x[1107]   c99       -3
    x[1107]   c143      3
    x[1107]   c210      -98
    x[1107]   c260      1
    x[1108]   c99       -1
    x[1108]   c122      1
    x[1108]   c203      -98
    x[1108]   c253      1
    x[1109]   c99       -2
    x[1109]   c140      2
    x[1109]   c202      -98
    x[1109]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1110]   c99       1
    x[1110]   c100      -1
    MARKER    'MARKER'                 'INTORG'
    x[1111]   c100      -2
    x[1111]   c117      2
    x[1111]   c251      -99
    x[1111]   c301      1
    x[1112]   c100      -2
    x[1112]   c116      2
    x[1112]   c249      -99
    x[1112]   c299      1
    x[1113]   c100      -2
    x[1113]   c122      2
    x[1113]   c245      -99
    x[1113]   c295      1
    x[1114]   c100      -4
    x[1114]   c109      4
    x[1114]   c240      -99
    x[1114]   c290      1
    x[1115]   c34_2     1
    x[1115]   c100      -5
    x[1115]   c126      5
    x[1115]   c232      -99
    x[1115]   c282      1
    x[1116]   c100      -4
    x[1116]   c127      4
    x[1116]   c231      -99
    x[1116]   c281      1
    x[1117]   c100      -1
    x[1117]   c132      1
    x[1117]   c228      -99
    x[1117]   c278      1
    x[1118]   c100      -1
    x[1118]   c132      1
    x[1118]   c227      -99
    x[1118]   c277      1
    x[1119]   c100      -3
    x[1119]   c144      3
    x[1119]   c210      -99
    x[1119]   c260      1
    x[1120]   c100      -1
    x[1120]   c123      1
    x[1120]   c203      -99
    x[1120]   c253      1
    x[1121]   c100      -2
    x[1121]   c141      2
    x[1121]   c202      -99
    x[1121]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1122]   c100      1
    x[1122]   c101      -1
    MARKER    'MARKER'                 'INTORG'
    x[1123]   c101      -2
    x[1123]   c118      2
    x[1123]   c251      -100
    x[1123]   c301      1
    x[1124]   c101      -2
    x[1124]   c117      2
    x[1124]   c249      -100
    x[1124]   c299      1
    x[1125]   c101      -2
    x[1125]   c123      2
    x[1125]   c245      -100
    x[1125]   c295      1
    x[1126]   c101      -4
    x[1126]   c110      4
    x[1126]   c240      -100
    x[1126]   c290      1
    x[1127]   c35_2     1
    x[1127]   c101      -5
    x[1127]   c127      5
    x[1127]   c232      -100
    x[1127]   c282      1
    x[1128]   c101      -4
    x[1128]   c128      4
    x[1128]   c231      -100
    x[1128]   c281      1
    x[1129]   c101      -1
    x[1129]   c133      1
    x[1129]   c228      -100
    x[1129]   c278      1
    x[1130]   c101      -1
    x[1130]   c133      1
    x[1130]   c227      -100
    x[1130]   c277      1
    x[1131]   c101      -3
    x[1131]   c145      3
    x[1131]   c210      -100
    x[1131]   c260      1
    x[1132]   c101      -1
    x[1132]   c124      1
    x[1132]   c203      -100
    x[1132]   c253      1
    x[1133]   c101      -2
    x[1133]   c142      2
    x[1133]   c202      -100
    x[1133]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1134]   c101      1
    x[1134]   c102      -1
    MARKER    'MARKER'                 'INTORG'
    x[1135]   c102      -2
    x[1135]   c119      2
    x[1135]   c251      -101
    x[1135]   c301      1
    x[1136]   c102      -2
    x[1136]   c118      2
    x[1136]   c249      -101
    x[1136]   c299      1
    x[1137]   c102      -2
    x[1137]   c124      2
    x[1137]   c245      -101
    x[1137]   c295      1
    x[1138]   c102      -4
    x[1138]   c111      4
    x[1138]   c240      -101
    x[1138]   c290      1
    x[1139]   c36_2     1
    x[1139]   c102      -5
    x[1139]   c128      5
    x[1139]   c232      -101
    x[1139]   c282      1
    x[1140]   c102      -4
    x[1140]   c129      4
    x[1140]   c231      -101
    x[1140]   c281      1
    x[1141]   c102      -1
    x[1141]   c134      1
    x[1141]   c228      -101
    x[1141]   c278      1
    x[1142]   c102      -1
    x[1142]   c134      1
    x[1142]   c227      -101
    x[1142]   c277      1
    x[1143]   c102      -3
    x[1143]   c146      3
    x[1143]   c210      -101
    x[1143]   c260      1
    x[1144]   c102      -1
    x[1144]   c125      1
    x[1144]   c203      -101
    x[1144]   c253      1
    x[1145]   c102      -2
    x[1145]   c143      2
    x[1145]   c202      -101
    x[1145]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1146]   c102      1
    x[1146]   c103      -1
    MARKER    'MARKER'                 'INTORG'
    x[1147]   c103      -2
    x[1147]   c120      2
    x[1147]   c251      -102
    x[1147]   c301      1
    x[1148]   c103      -2
    x[1148]   c119      2
    x[1148]   c249      -102
    x[1148]   c299      1
    x[1149]   c103      -2
    x[1149]   c125      2
    x[1149]   c245      -102
    x[1149]   c295      1
    x[1150]   c103      -4
    x[1150]   c112      4
    x[1150]   c240      -102
    x[1150]   c290      1
    x[1151]   c37_2     1
    x[1151]   c103      -5
    x[1151]   c129      5
    x[1151]   c232      -102
    x[1151]   c282      1
    x[1152]   c103      -4
    x[1152]   c130      4
    x[1152]   c231      -102
    x[1152]   c281      1
    x[1153]   c103      -1
    x[1153]   c135      1
    x[1153]   c228      -102
    x[1153]   c278      1
    x[1154]   c103      -1
    x[1154]   c135      1
    x[1154]   c227      -102
    x[1154]   c277      1
    x[1155]   c103      -3
    x[1155]   c147      3
    x[1155]   c210      -102
    x[1155]   c260      1
    x[1156]   c103      -1
    x[1156]   c126      1
    x[1156]   c203      -102
    x[1156]   c253      1
    x[1157]   c103      -2
    x[1157]   c144      2
    x[1157]   c202      -102
    x[1157]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1158]   c103      1
    x[1158]   c104      -1
    MARKER    'MARKER'                 'INTORG'
    x[1159]   c104      -2
    x[1159]   c121      2
    x[1159]   c251      -103
    x[1159]   c301      1
    x[1160]   c104      -2
    x[1160]   c120      2
    x[1160]   c249      -103
    x[1160]   c299      1
    x[1161]   c104      -2
    x[1161]   c126      2
    x[1161]   c245      -103
    x[1161]   c295      1
    x[1162]   c104      -4
    x[1162]   c113      4
    x[1162]   c240      -103
    x[1162]   c290      1
    x[1163]   c38_2     1
    x[1163]   c104      -5
    x[1163]   c130      5
    x[1163]   c232      -103
    x[1163]   c282      1
    x[1164]   c104      -4
    x[1164]   c131      4
    x[1164]   c231      -103
    x[1164]   c281      1
    x[1165]   c104      -1
    x[1165]   c136      1
    x[1165]   c228      -103
    x[1165]   c278      1
    x[1166]   c104      -1
    x[1166]   c136      1
    x[1166]   c227      -103
    x[1166]   c277      1
    x[1167]   c104      -3
    x[1167]   c148      3
    x[1167]   c210      -103
    x[1167]   c260      1
    x[1168]   c104      -1
    x[1168]   c127      1
    x[1168]   c203      -103
    x[1168]   c253      1
    x[1169]   c104      -2
    x[1169]   c145      2
    x[1169]   c202      -103
    x[1169]   c252      1
    MARKER    'MARKER'                 'INTEND'
    x[1170]   c104      1
    x[1170]   c105      -1
    MARKER    'MARKER'                 'INTORG'
    x[1171]   c105      -2
    x[1171]   c122      2
    x[1171]   c251      -104
    x[1171]   c301      1
    x[1172]   c105      -2
    x[1172]   c121      2
    x[1172]   c249      -104
    x[1172]   c299      1
    x[1173]   c105      -2
    x[1173]   c127      2
    x[1173]   c245      -104
    x[1173]   c295      1
    x[1174]   c105      -4
    x[1174]   c114      4
    x[1174]   c240      -104
    x[1174]   c290      1
    x[1175]   c39_2     1
    x[1175]   c105      -5
    x[1175]   c131      5
    x[1175]   c232      -104
    x[1175]   c282      1
    x[1176]   c105      -4
    x[1176]   c132      4
    x[1176]   c231      -104
    x[1176]   c281      1
    x[1177]   c105      -1
    x[1177]   c137      1
    x[1177]   c228      -104
    x[1177]   c278      1
    x[1178]   c105      -1
    x[1178]   c137      1
    x[1178]   c227      -104
    x[1178]   c277      1
    x[1179]   c105      -3
    x[1179]   c149      3
    x[1179]   c210      -104
    x[1179]   c260      1
    x[1180]   c105      -3
    x[1180]   c159      3
    x[1180]   c209      -104
    x[1180]   c259      1
    x[1181]   c105      -1
    x[1181]   c128      1
    x[1181]   c203      -104
    x[1181]   c253      1
    MARKER    'MARKER'                 'INTEND'
    x[1182]   c105      1
    x[1182]   c106      -1
    MARKER    'MARKER'                 'INTORG'
    x[1183]   c106      -2
    x[1183]   c123      2
    x[1183]   c251      -105
    x[1183]   c301      1
    x[1184]   c106      -2
    x[1184]   c122      2
    x[1184]   c249      -105
    x[1184]   c299      1
    x[1185]   c106      -2
    x[1185]   c128      2
    x[1185]   c245      -105
    x[1185]   c295      1
    x[1186]   c106      -4
    x[1186]   c115      4
    x[1186]   c240      -105
    x[1186]   c290      1
    x[1187]   c40_2     1
    x[1187]   c106      -5
    x[1187]   c132      5
    x[1187]   c232      -105
    x[1187]   c282      1
    x[1188]   c106      -4
    x[1188]   c133      4
    x[1188]   c231      -105
    x[1188]   c281      1
    x[1189]   c106      -1
    x[1189]   c138      1
    x[1189]   c228      -105
    x[1189]   c278      1
    x[1190]   c106      -1
    x[1190]   c138      1
    x[1190]   c227      -105
    x[1190]   c277      1
    x[1191]   c106      -3
    x[1191]   c160      3
    x[1191]   c209      -105
    x[1191]   c259      1
    x[1192]   c106      -1
    x[1192]   c129      1
    x[1192]   c203      -105
    x[1192]   c253      1
    MARKER    'MARKER'                 'INTEND'
    x[1193]   c106      1
    x[1193]   c107      -1
    MARKER    'MARKER'                 'INTORG'
    x[1194]   c107      -2
    x[1194]   c124      2
    x[1194]   c251      -106
    x[1194]   c301      1
    x[1195]   c107      -2
    x[1195]   c123      2
    x[1195]   c249      -106
    x[1195]   c299      1
    x[1196]   c107      -2
    x[1196]   c129      2
    x[1196]   c245      -106
    x[1196]   c295      1
    x[1197]   c107      -4
    x[1197]   c116      4
    x[1197]   c240      -106
    x[1197]   c290      1
    x[1198]   c41_2     1
    x[1198]   c107      -5
    x[1198]   c133      5
    x[1198]   c232      -106
    x[1198]   c282      1
    x[1199]   c107      -4
    x[1199]   c134      4
    x[1199]   c231      -106
    x[1199]   c281      1
    x[1200]   c107      -1
    x[1200]   c139      1
    x[1200]   c228      -106
    x[1200]   c278      1
    x[1201]   c107      -1
    x[1201]   c139      1
    x[1201]   c227      -106
    x[1201]   c277      1
    x[1202]   c107      -3
    x[1202]   c161      3
    x[1202]   c209      -106
    x[1202]   c259      1
    x[1203]   c1_2      1
    x[1203]   c16_2     1
    x[1203]   c17_2     1
    x[1203]   c18_2     1
    x[1203]   c19_2     1
    x[1203]   c20_2     1
    x[1203]   c21_2     1
    x[1203]   c22_2     1
    x[1203]   c23_2     1
    x[1203]   c24_2     1
    x[1203]   c25_2     1
    x[1203]   c26_2     1
    x[1203]   c107      -3
    x[1203]   c140      3
    x[1203]   c205      -106
    x[1203]   c255      1
    x[1204]   c107      -1
    x[1204]   c130      1
    x[1204]   c203      -106
    x[1204]   c253      1
    MARKER    'MARKER'                 'INTEND'
    x[1205]   c107      1
    x[1205]   c108      -1
    MARKER    'MARKER'                 'INTORG'
    x[1206]   c108      -2
    x[1206]   c125      2
    x[1206]   c251      -107
    x[1206]   c301      1
    x[1207]   c108      -2
    x[1207]   c124      2
    x[1207]   c249      -107
    x[1207]   c299      1
    x[1208]   c108      -2
    x[1208]   c130      2
    x[1208]   c245      -107
    x[1208]   c295      1
    x[1209]   c108      -4
    x[1209]   c117      4
    x[1209]   c240      -107
    x[1209]   c290      1
    x[1210]   c42_2     1
    x[1210]   c108      -5
    x[1210]   c134      5
    x[1210]   c232      -107
    x[1210]   c282      1
    x[1211]   c108      -4
    x[1211]   c135      4
    x[1211]   c231      -107
    x[1211]   c281      1
    x[1212]   c108      -1
    x[1212]   c140      1
    x[1212]   c228      -107
    x[1212]   c278      1
    x[1213]   c108      -1
    x[1213]   c140      1
    x[1213]   c227      -107
    x[1213]   c277      1
    x[1214]   c108      -3
    x[1214]   c162      3
    x[1214]   c209      -107
    x[1214]   c259      1
    x[1215]   c2_2      1
    x[1215]   c108      -3
    x[1215]   c141      3
    x[1215]   c205      -107
    x[1215]   c255      1
    x[1216]   c108      -1
    x[1216]   c131      1
    x[1216]   c203      -107
    x[1216]   c253      1
    MARKER    'MARKER'                 'INTEND'
    x[1217]   c108      1
    x[1217]   c109      -1
    MARKER    'MARKER'                 'INTORG'
    x[1218]   c109      -2
    x[1218]   c126      2
    x[1218]   c251      -108
    x[1218]   c301      1
    x[1219]   c109      -2
    x[1219]   c125      2
    x[1219]   c249      -108
    x[1219]   c299      1
    x[1220]   c109      -2
    x[1220]   c131      2
    x[1220]   c245      -108
    x[1220]   c295      1
    x[1221]   c109      -4
    x[1221]   c118      4
    x[1221]   c240      -108
    x[1221]   c290      1
    x[1222]   c43_2     1
    x[1222]   c109      -5
    x[1222]   c135      5
    x[1222]   c232      -108
    x[1222]   c282      1
    x[1223]   c109      -4
    x[1223]   c136      4
    x[1223]   c231      -108
    x[1223]   c281      1
    x[1224]   c109      -1
    x[1224]   c141      1
    x[1224]   c228      -108
    x[1224]   c278      1
    x[1225]   c109      -1
    x[1225]   c141      1
    x[1225]   c227      -108
    x[1225]   c277      1
    x[1226]   c109      -3
    x[1226]   c163      3
    x[1226]   c209      -108
    x[1226]   c259      1
    x[1227]   c3_2      1
    x[1227]   c109      -3
    x[1227]   c142      3
    x[1227]   c205      -108
    x[1227]   c255      1
    x[1228]   c109      -1
    x[1228]   c132      1
    x[1228]   c203      -108
    x[1228]   c253      1
    MARKER    'MARKER'                 'INTEND'
    x[1229]   c109      1
    x[1229]   c110      -1
    MARKER    'MARKER'                 'INTORG'
    x[1230]   c110      -2
    x[1230]   c127      2
    x[1230]   c251      -109
    x[1230]   c301      1
    x[1231]   c110      -2
    x[1231]   c132      2
    x[1231]   c245      -109
    x[1231]   c295      1
    x[1232]   c110      -4
    x[1232]   c119      4
    x[1232]   c240      -109
    x[1232]   c290      1
    x[1233]   c44_2     1
    x[1233]   c110      -5
    x[1233]   c136      5
    x[1233]   c232      -109
    x[1233]   c282      1
    x[1234]   c110      -4
    x[1234]   c137      4
    x[1234]   c231      -109
    x[1234]   c281      1
    x[1235]   c110      -1
    x[1235]   c142      1
    x[1235]   c228      -109
    x[1235]   c278      1
    x[1236]   c110      -1
    x[1236]   c142      1
    x[1236]   c227      -109
    x[1236]   c277      1
    x[1237]   c110      -3
    x[1237]   c164      3
    x[1237]   c209      -109
    x[1237]   c259      1
    x[1238]   c4_2      1
    x[1238]   c110      -3
    x[1238]   c143      3
    x[1238]   c205      -109
    x[1238]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1239]   c110      1
    x[1239]   c111      -1
    MARKER    'MARKER'                 'INTORG'
    x[1240]   c111      -2
    x[1240]   c128      2
    x[1240]   c251      -110
    x[1240]   c301      1
    x[1241]   c111      -2
    x[1241]   c133      2
    x[1241]   c245      -110
    x[1241]   c295      1
    x[1242]   c111      -4
    x[1242]   c120      4
    x[1242]   c240      -110
    x[1242]   c290      1
    x[1243]   c45_2     1
    x[1243]   c111      -5
    x[1243]   c137      5
    x[1243]   c232      -110
    x[1243]   c282      1
    x[1244]   c111      -4
    x[1244]   c138      4
    x[1244]   c231      -110
    x[1244]   c281      1
    x[1245]   c111      -1
    x[1245]   c143      1
    x[1245]   c228      -110
    x[1245]   c278      1
    x[1246]   c111      -1
    x[1246]   c143      1
    x[1246]   c227      -110
    x[1246]   c277      1
    x[1247]   c111      -3
    x[1247]   c165      3
    x[1247]   c209      -110
    x[1247]   c259      1
    x[1248]   c5_2      1
    x[1248]   c111      -3
    x[1248]   c144      3
    x[1248]   c205      -110
    x[1248]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1249]   c111      1
    x[1249]   c112      -1
    MARKER    'MARKER'                 'INTORG'
    x[1250]   c112      -2
    x[1250]   c129      2
    x[1250]   c251      -111
    x[1250]   c301      1
    x[1251]   c112      -4
    x[1251]   c130      4
    x[1251]   c248      -111
    x[1251]   c298      1
    x[1252]   c112      -2
    x[1252]   c134      2
    x[1252]   c245      -111
    x[1252]   c295      1
    x[1253]   c112      -4
    x[1253]   c121      4
    x[1253]   c240      -111
    x[1253]   c290      1
    x[1254]   c112      -4
    x[1254]   c139      4
    x[1254]   c231      -111
    x[1254]   c281      1
    x[1255]   c112      -1
    x[1255]   c144      1
    x[1255]   c228      -111
    x[1255]   c278      1
    x[1256]   c112      -1
    x[1256]   c144      1
    x[1256]   c227      -111
    x[1256]   c277      1
    x[1257]   c112      -3
    x[1257]   c166      3
    x[1257]   c209      -111
    x[1257]   c259      1
    x[1258]   c112      -4
    x[1258]   c135      4
    x[1258]   c207      -111
    x[1258]   c257      1
    x[1259]   c6_2      1
    x[1259]   c112      -3
    x[1259]   c145      3
    x[1259]   c205      -111
    x[1259]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1260]   c112      1
    x[1260]   c113      -1
    MARKER    'MARKER'                 'INTORG'
    x[1261]   c113      -2
    x[1261]   c130      2
    x[1261]   c251      -112
    x[1261]   c301      1
    x[1262]   c113      -4
    x[1262]   c131      4
    x[1262]   c248      -112
    x[1262]   c298      1
    x[1263]   c113      -2
    x[1263]   c135      2
    x[1263]   c245      -112
    x[1263]   c295      1
    x[1264]   c113      -4
    x[1264]   c122      4
    x[1264]   c240      -112
    x[1264]   c290      1
    x[1265]   c113      -4
    x[1265]   c140      4
    x[1265]   c231      -112
    x[1265]   c281      1
    x[1266]   c113      -1
    x[1266]   c145      1
    x[1266]   c228      -112
    x[1266]   c278      1
    x[1267]   c113      -1
    x[1267]   c145      1
    x[1267]   c227      -112
    x[1267]   c277      1
    x[1268]   c113      -3
    x[1268]   c167      3
    x[1268]   c209      -112
    x[1268]   c259      1
    x[1269]   c113      -4
    x[1269]   c136      4
    x[1269]   c207      -112
    x[1269]   c257      1
    x[1270]   c7_2      1
    x[1270]   c113      -3
    x[1270]   c146      3
    x[1270]   c205      -112
    x[1270]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1271]   c113      1
    x[1271]   c114      -1
    MARKER    'MARKER'                 'INTORG'
    x[1272]   c114      -2
    x[1272]   c131      2
    x[1272]   c251      -113
    x[1272]   c301      1
    x[1273]   c114      -4
    x[1273]   c132      4
    x[1273]   c248      -113
    x[1273]   c298      1
    x[1274]   c114      -2
    x[1274]   c136      2
    x[1274]   c245      -113
    x[1274]   c295      1
    x[1275]   c114      -4
    x[1275]   c123      4
    x[1275]   c240      -113
    x[1275]   c290      1
    x[1276]   c114      -4
    x[1276]   c141      4
    x[1276]   c231      -113
    x[1276]   c281      1
    x[1277]   c114      -1
    x[1277]   c146      1
    x[1277]   c228      -113
    x[1277]   c278      1
    x[1278]   c114      -1
    x[1278]   c146      1
    x[1278]   c227      -113
    x[1278]   c277      1
    x[1279]   c114      -3
    x[1279]   c168      3
    x[1279]   c209      -113
    x[1279]   c259      1
    x[1280]   c114      -4
    x[1280]   c137      4
    x[1280]   c207      -113
    x[1280]   c257      1
    x[1281]   c8_2      1
    x[1281]   c114      -3
    x[1281]   c147      3
    x[1281]   c205      -113
    x[1281]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1282]   c114      1
    x[1282]   c115      -1
    MARKER    'MARKER'                 'INTORG'
    x[1283]   c115      -2
    x[1283]   c132      2
    x[1283]   c251      -114
    x[1283]   c301      1
    x[1284]   c115      -4
    x[1284]   c133      4
    x[1284]   c248      -114
    x[1284]   c298      1
    x[1285]   c115      -2
    x[1285]   c137      2
    x[1285]   c245      -114
    x[1285]   c295      1
    x[1286]   c115      -4
    x[1286]   c124      4
    x[1286]   c240      -114
    x[1286]   c290      1
    x[1287]   c115      -4
    x[1287]   c142      4
    x[1287]   c231      -114
    x[1287]   c281      1
    x[1288]   c115      -1
    x[1288]   c147      1
    x[1288]   c228      -114
    x[1288]   c278      1
    x[1289]   c115      -1
    x[1289]   c147      1
    x[1289]   c227      -114
    x[1289]   c277      1
    x[1290]   c115      -3
    x[1290]   c169      3
    x[1290]   c209      -114
    x[1290]   c259      1
    x[1291]   c115      -4
    x[1291]   c138      4
    x[1291]   c207      -114
    x[1291]   c257      1
    x[1292]   c9_2      1
    x[1292]   c115      -3
    x[1292]   c148      3
    x[1292]   c205      -114
    x[1292]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1293]   c115      1
    x[1293]   c116      -1
    MARKER    'MARKER'                 'INTORG'
    x[1294]   c116      -2
    x[1294]   c133      2
    x[1294]   c251      -115
    x[1294]   c301      1
    x[1295]   c116      -4
    x[1295]   c134      4
    x[1295]   c248      -115
    x[1295]   c298      1
    x[1296]   c116      -2
    x[1296]   c138      2
    x[1296]   c245      -115
    x[1296]   c295      1
    x[1297]   c116      -4
    x[1297]   c143      4
    x[1297]   c231      -115
    x[1297]   c281      1
    x[1298]   c116      -1
    x[1298]   c148      1
    x[1298]   c228      -115
    x[1298]   c278      1
    x[1299]   c116      -1
    x[1299]   c148      1
    x[1299]   c227      -115
    x[1299]   c277      1
    x[1300]   c116      -3
    x[1300]   c170      3
    x[1300]   c209      -115
    x[1300]   c259      1
    x[1301]   c116      -4
    x[1301]   c139      4
    x[1301]   c207      -115
    x[1301]   c257      1
    x[1302]   c10_2     1
    x[1302]   c116      -3
    x[1302]   c149      3
    x[1302]   c205      -115
    x[1302]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1303]   c116      1
    x[1303]   c117      -1
    MARKER    'MARKER'                 'INTORG'
    x[1304]   c117      -2
    x[1304]   c134      2
    x[1304]   c251      -116
    x[1304]   c301      1
    x[1305]   c117      -4
    x[1305]   c135      4
    x[1305]   c248      -116
    x[1305]   c298      1
    x[1306]   c117      -4
    x[1306]   c144      4
    x[1306]   c231      -116
    x[1306]   c281      1
    x[1307]   c117      -1
    x[1307]   c149      1
    x[1307]   c228      -116
    x[1307]   c278      1
    x[1308]   c117      -3
    x[1308]   c171      3
    x[1308]   c209      -116
    x[1308]   c259      1
    x[1309]   c117      -4
    x[1309]   c140      4
    x[1309]   c207      -116
    x[1309]   c257      1
    x[1310]   c11_2     1
    x[1310]   c117      -3
    x[1310]   c150      3
    x[1310]   c205      -116
    x[1310]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1311]   c117      1
    x[1311]   c118      -1
    MARKER    'MARKER'                 'INTORG'
    x[1312]   c118      -2
    x[1312]   c135      2
    x[1312]   c251      -117
    x[1312]   c301      1
    x[1313]   c118      -4
    x[1313]   c136      4
    x[1313]   c248      -117
    x[1313]   c298      1
    x[1314]   c118      -4
    x[1314]   c145      4
    x[1314]   c231      -117
    x[1314]   c281      1
    x[1315]   c118      -1
    x[1315]   c150      1
    x[1315]   c228      -117
    x[1315]   c278      1
    x[1316]   c118      -3
    x[1316]   c172      3
    x[1316]   c209      -117
    x[1316]   c259      1
    x[1317]   c118      -4
    x[1317]   c141      4
    x[1317]   c207      -117
    x[1317]   c257      1
    x[1318]   c12_2     1
    x[1318]   c118      -3
    x[1318]   c151      3
    x[1318]   c205      -117
    x[1318]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1319]   c118      1
    x[1319]   c119      -1
    MARKER    'MARKER'                 'INTORG'
    x[1320]   c119      -2
    x[1320]   c136      2
    x[1320]   c251      -118
    x[1320]   c301      1
    x[1321]   c119      -4
    x[1321]   c146      4
    x[1321]   c231      -118
    x[1321]   c281      1
    x[1322]   c119      -3
    x[1322]   c154      3
    x[1322]   c229      -118
    x[1322]   c279      1
    x[1323]   c119      -1
    x[1323]   c151      1
    x[1323]   c228      -118
    x[1323]   c278      1
    x[1324]   c119      -3
    x[1324]   c173      3
    x[1324]   c209      -118
    x[1324]   c259      1
    x[1325]   c119      -4
    x[1325]   c142      4
    x[1325]   c207      -118
    x[1325]   c257      1
    x[1326]   c13_2     1
    x[1326]   c119      -3
    x[1326]   c152      3
    x[1326]   c205      -118
    x[1326]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1327]   c119      1
    x[1327]   c120      -1
    MARKER    'MARKER'                 'INTORG'
    x[1328]   c120      -2
    x[1328]   c137      2
    x[1328]   c251      -119
    x[1328]   c301      1
    x[1329]   c120      -3
    x[1329]   c130      3
    x[1329]   c250      -119
    x[1329]   c300      1
    x[1330]   c120      -4
    x[1330]   c147      4
    x[1330]   c231      -119
    x[1330]   c281      1
    x[1331]   c120      -3
    x[1331]   c155      3
    x[1331]   c229      -119
    x[1331]   c279      1
    x[1332]   c120      -1
    x[1332]   c152      1
    x[1332]   c228      -119
    x[1332]   c278      1
    x[1333]   c120      -3
    x[1333]   c174      3
    x[1333]   c209      -119
    x[1333]   c259      1
    x[1334]   c120      -4
    x[1334]   c143      4
    x[1334]   c207      -119
    x[1334]   c257      1
    x[1335]   c14_2     1
    x[1335]   c120      -3
    x[1335]   c153      3
    x[1335]   c205      -119
    x[1335]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1336]   c120      1
    x[1336]   c121      -1
    MARKER    'MARKER'                 'INTORG'
    x[1337]   c121      -2
    x[1337]   c138      2
    x[1337]   c251      -120
    x[1337]   c301      1
    x[1338]   c121      -3
    x[1338]   c131      3
    x[1338]   c250      -120
    x[1338]   c300      1
    x[1339]   c121      -4
    x[1339]   c148      4
    x[1339]   c231      -120
    x[1339]   c281      1
    x[1340]   c121      -3
    x[1340]   c156      3
    x[1340]   c229      -120
    x[1340]   c279      1
    x[1341]   c121      -1
    x[1341]   c153      1
    x[1341]   c228      -120
    x[1341]   c278      1
    x[1342]   c121      -3
    x[1342]   c175      3
    x[1342]   c209      -120
    x[1342]   c259      1
    x[1343]   c121      -4
    x[1343]   c144      4
    x[1343]   c207      -120
    x[1343]   c257      1
    x[1344]   c15_2     1
    x[1344]   c121      -3
    x[1344]   c154      3
    x[1344]   c205      -120
    x[1344]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1345]   c121      1
    x[1345]   c122      -1
    MARKER    'MARKER'                 'INTORG'
    x[1346]   c122      -2
    x[1346]   c139      2
    x[1346]   c251      -121
    x[1346]   c301      1
    x[1347]   c122      -3
    x[1347]   c132      3
    x[1347]   c250      -121
    x[1347]   c300      1
    x[1348]   c122      -4
    x[1348]   c149      4
    x[1348]   c231      -121
    x[1348]   c281      1
    x[1349]   c122      -3
    x[1349]   c157      3
    x[1349]   c229      -121
    x[1349]   c279      1
    x[1350]   c122      -1
    x[1350]   c154      1
    x[1350]   c228      -121
    x[1350]   c278      1
    x[1351]   c122      -3
    x[1351]   c176      3
    x[1351]   c209      -121
    x[1351]   c259      1
    x[1352]   c122      -4
    x[1352]   c145      4
    x[1352]   c207      -121
    x[1352]   c257      1
    x[1353]   c16_2     1
    x[1353]   c122      -3
    x[1353]   c155      3
    x[1353]   c205      -121
    x[1353]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1354]   c122      1
    x[1354]   c123      -1
    MARKER    'MARKER'                 'INTORG'
    x[1355]   c123      -2
    x[1355]   c140      2
    x[1355]   c251      -122
    x[1355]   c301      1
    x[1356]   c123      -3
    x[1356]   c133      3
    x[1356]   c250      -122
    x[1356]   c300      1
    x[1357]   c123      -4
    x[1357]   c150      4
    x[1357]   c231      -122
    x[1357]   c281      1
    x[1358]   c123      -3
    x[1358]   c158      3
    x[1358]   c229      -122
    x[1358]   c279      1
    x[1359]   c123      -1
    x[1359]   c155      1
    x[1359]   c228      -122
    x[1359]   c278      1
    x[1360]   c123      -5
    x[1360]   c147      5
    x[1360]   c221      -122
    x[1360]   c271      1
    x[1361]   c123      -3
    x[1361]   c177      3
    x[1361]   c209      -122
    x[1361]   c259      1
    x[1362]   c123      -4
    x[1362]   c146      4
    x[1362]   c207      -122
    x[1362]   c257      1
    x[1363]   c17_2     1
    x[1363]   c123      -3
    x[1363]   c156      3
    x[1363]   c205      -122
    x[1363]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1364]   c123      1
    x[1364]   c124      -1
    MARKER    'MARKER'                 'INTORG'
    x[1365]   c124      -2
    x[1365]   c141      2
    x[1365]   c251      -123
    x[1365]   c301      1
    x[1366]   c124      -3
    x[1366]   c134      3
    x[1366]   c250      -123
    x[1366]   c300      1
    x[1367]   c124      -4
    x[1367]   c151      4
    x[1367]   c231      -123
    x[1367]   c281      1
    x[1368]   c124      -3
    x[1368]   c159      3
    x[1368]   c229      -123
    x[1368]   c279      1
    x[1369]   c124      -1
    x[1369]   c156      1
    x[1369]   c228      -123
    x[1369]   c278      1
    x[1370]   c124      -5
    x[1370]   c148      5
    x[1370]   c221      -123
    x[1370]   c271      1
    x[1371]   c124      -3
    x[1371]   c178      3
    x[1371]   c209      -123
    x[1371]   c259      1
    x[1372]   c124      -4
    x[1372]   c147      4
    x[1372]   c207      -123
    x[1372]   c257      1
    x[1373]   c18_2     1
    x[1373]   c124      -3
    x[1373]   c157      3
    x[1373]   c205      -123
    x[1373]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1374]   c124      1
    x[1374]   c125      -1
    MARKER    'MARKER'                 'INTORG'
    x[1375]   c125      -2
    x[1375]   c142      2
    x[1375]   c251      -124
    x[1375]   c301      1
    x[1376]   c125      -3
    x[1376]   c135      3
    x[1376]   c250      -124
    x[1376]   c300      1
    x[1377]   c125      -4
    x[1377]   c152      4
    x[1377]   c231      -124
    x[1377]   c281      1
    x[1378]   c125      -3
    x[1378]   c160      3
    x[1378]   c229      -124
    x[1378]   c279      1
    x[1379]   c125      -1
    x[1379]   c157      1
    x[1379]   c228      -124
    x[1379]   c278      1
    x[1380]   c125      -5
    x[1380]   c149      5
    x[1380]   c221      -124
    x[1380]   c271      1
    x[1381]   c125      -3
    x[1381]   c179      3
    x[1381]   c209      -124
    x[1381]   c259      1
    x[1382]   c125      -4
    x[1382]   c148      4
    x[1382]   c207      -124
    x[1382]   c257      1
    x[1383]   c19_2     1
    x[1383]   c125      -3
    x[1383]   c158      3
    x[1383]   c205      -124
    x[1383]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1384]   c125      1
    x[1384]   c126      -1
    MARKER    'MARKER'                 'INTORG'
    x[1385]   c126      -2
    x[1385]   c143      2
    x[1385]   c251      -125
    x[1385]   c301      1
    x[1386]   c126      -3
    x[1386]   c136      3
    x[1386]   c250      -125
    x[1386]   c300      1
    x[1387]   c126      -3
    x[1387]   c161      3
    x[1387]   c229      -125
    x[1387]   c279      1
    x[1388]   c126      -1
    x[1388]   c158      1
    x[1388]   c228      -125
    x[1388]   c278      1
    x[1389]   c126      -5
    x[1389]   c150      5
    x[1389]   c221      -125
    x[1389]   c271      1
    x[1390]   c126      -3
    x[1390]   c180      3
    x[1390]   c209      -125
    x[1390]   c259      1
    x[1391]   c126      -4
    x[1391]   c149      4
    x[1391]   c207      -125
    x[1391]   c257      1
    x[1392]   c20_2     1
    x[1392]   c126      -3
    x[1392]   c159      3
    x[1392]   c205      -125
    x[1392]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1393]   c126      1
    x[1393]   c127      -1
    MARKER    'MARKER'                 'INTORG'
    x[1394]   c127      -2
    x[1394]   c144      2
    x[1394]   c251      -126
    x[1394]   c301      1
    x[1395]   c127      -3
    x[1395]   c137      3
    x[1395]   c250      -126
    x[1395]   c300      1
    x[1396]   c127      -3
    x[1396]   c162      3
    x[1396]   c229      -126
    x[1396]   c279      1
    x[1397]   c127      -1
    x[1397]   c159      1
    x[1397]   c228      -126
    x[1397]   c278      1
    x[1398]   c127      -5
    x[1398]   c151      5
    x[1398]   c221      -126
    x[1398]   c271      1
    x[1399]   c127      -4
    x[1399]   c150      4
    x[1399]   c207      -126
    x[1399]   c257      1
    x[1400]   c21_2     1
    x[1400]   c127      -3
    x[1400]   c160      3
    x[1400]   c205      -126
    x[1400]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1401]   c127      1
    x[1401]   c128      -1
    MARKER    'MARKER'                 'INTORG'
    x[1402]   c128      -2
    x[1402]   c145      2
    x[1402]   c251      -127
    x[1402]   c301      1
    x[1403]   c128      -3
    x[1403]   c138      3
    x[1403]   c250      -127
    x[1403]   c300      1
    x[1404]   c128      -3
    x[1404]   c163      3
    x[1404]   c229      -127
    x[1404]   c279      1
    x[1405]   c128      -1
    x[1405]   c160      1
    x[1405]   c228      -127
    x[1405]   c278      1
    x[1406]   c128      -5
    x[1406]   c152      5
    x[1406]   c221      -127
    x[1406]   c271      1
    x[1407]   c128      -4
    x[1407]   c151      4
    x[1407]   c207      -127
    x[1407]   c257      1
    x[1408]   c22_2     1
    x[1408]   c128      -3
    x[1408]   c161      3
    x[1408]   c205      -127
    x[1408]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1409]   c128      1
    x[1409]   c129      -1
    MARKER    'MARKER'                 'INTORG'
    x[1410]   c129      -2
    x[1410]   c146      2
    x[1410]   c251      -128
    x[1410]   c301      1
    x[1411]   c129      -3
    x[1411]   c139      3
    x[1411]   c250      -128
    x[1411]   c300      1
    x[1412]   c129      -3
    x[1412]   c164      3
    x[1412]   c229      -128
    x[1412]   c279      1
    x[1413]   c129      -1
    x[1413]   c161      1
    x[1413]   c228      -128
    x[1413]   c278      1
    x[1414]   c129      -5
    x[1414]   c153      5
    x[1414]   c221      -128
    x[1414]   c271      1
    x[1415]   c129      -4
    x[1415]   c152      4
    x[1415]   c207      -128
    x[1415]   c257      1
    x[1416]   c23_2     1
    x[1416]   c129      -3
    x[1416]   c162      3
    x[1416]   c205      -128
    x[1416]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1417]   c129      1
    x[1417]   c130      -1
    MARKER    'MARKER'                 'INTORG'
    x[1418]   c130      -2
    x[1418]   c147      2
    x[1418]   c251      -129
    x[1418]   c301      1
    x[1419]   c130      -3
    x[1419]   c140      3
    x[1419]   c250      -129
    x[1419]   c300      1
    x[1420]   c130      -3
    x[1420]   c165      3
    x[1420]   c229      -129
    x[1420]   c279      1
    x[1421]   c130      -1
    x[1421]   c162      1
    x[1421]   c228      -129
    x[1421]   c278      1
    x[1422]   c130      -5
    x[1422]   c154      5
    x[1422]   c221      -129
    x[1422]   c271      1
    x[1423]   c130      -4
    x[1423]   c153      4
    x[1423]   c207      -129
    x[1423]   c257      1
    x[1424]   c130      -3
    x[1424]   c163      3
    x[1424]   c205      -129
    x[1424]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1425]   c130      1
    x[1425]   c131      -1
    MARKER    'MARKER'                 'INTORG'
    x[1426]   c131      -2
    x[1426]   c148      2
    x[1426]   c251      -130
    x[1426]   c301      1
    x[1427]   c131      -3
    x[1427]   c141      3
    x[1427]   c250      -130
    x[1427]   c300      1
    x[1428]   c131      -3
    x[1428]   c166      3
    x[1428]   c229      -130
    x[1428]   c279      1
    x[1429]   c131      -1
    x[1429]   c163      1
    x[1429]   c228      -130
    x[1429]   c278      1
    x[1430]   c131      -5
    x[1430]   c155      5
    x[1430]   c221      -130
    x[1430]   c271      1
    x[1431]   c131      -4
    x[1431]   c154      4
    x[1431]   c207      -130
    x[1431]   c257      1
    x[1432]   c131      -3
    x[1432]   c164      3
    x[1432]   c205      -130
    x[1432]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1433]   c131      1
    x[1433]   c132      -1
    MARKER    'MARKER'                 'INTORG'
    x[1434]   c132      -3
    x[1434]   c142      3
    x[1434]   c250      -131
    x[1434]   c300      1
    x[1435]   c132      -3
    x[1435]   c167      3
    x[1435]   c229      -131
    x[1435]   c279      1
    x[1436]   c132      -1
    x[1436]   c164      1
    x[1436]   c228      -131
    x[1436]   c278      1
    x[1437]   c132      -5
    x[1437]   c156      5
    x[1437]   c221      -131
    x[1437]   c271      1
    x[1438]   c132      -4
    x[1438]   c155      4
    x[1438]   c207      -131
    x[1438]   c257      1
    x[1439]   c132      -3
    x[1439]   c165      3
    x[1439]   c205      -131
    x[1439]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1440]   c132      1
    x[1440]   c133      -1
    MARKER    'MARKER'                 'INTORG'
    x[1441]   c133      -3
    x[1441]   c143      3
    x[1441]   c250      -132
    x[1441]   c300      1
    x[1442]   c133      -3
    x[1442]   c168      3
    x[1442]   c229      -132
    x[1442]   c279      1
    x[1443]   c133      -1
    x[1443]   c165      1
    x[1443]   c228      -132
    x[1443]   c278      1
    x[1444]   c133      -5
    x[1444]   c157      5
    x[1444]   c221      -132
    x[1444]   c271      1
    x[1445]   c133      -4
    x[1445]   c156      4
    x[1445]   c207      -132
    x[1445]   c257      1
    x[1446]   c133      -3
    x[1446]   c166      3
    x[1446]   c205      -132
    x[1446]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1447]   c133      1
    x[1447]   c134      -1
    MARKER    'MARKER'                 'INTORG'
    x[1448]   c134      -3
    x[1448]   c144      3
    x[1448]   c250      -133
    x[1448]   c300      1
    x[1449]   c134      -3
    x[1449]   c169      3
    x[1449]   c229      -133
    x[1449]   c279      1
    x[1450]   c134      -1
    x[1450]   c166      1
    x[1450]   c228      -133
    x[1450]   c278      1
    x[1451]   c134      -4
    x[1451]   c157      4
    x[1451]   c207      -133
    x[1451]   c257      1
    x[1452]   c134      -3
    x[1452]   c167      3
    x[1452]   c205      -133
    x[1452]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1453]   c134      1
    x[1453]   c135      -1
    MARKER    'MARKER'                 'INTORG'
    x[1454]   c135      -3
    x[1454]   c145      3
    x[1454]   c250      -134
    x[1454]   c300      1
    x[1455]   c135      -3
    x[1455]   c170      3
    x[1455]   c229      -134
    x[1455]   c279      1
    x[1456]   c135      -1
    x[1456]   c167      1
    x[1456]   c228      -134
    x[1456]   c278      1
    x[1457]   c135      -4
    x[1457]   c158      4
    x[1457]   c207      -134
    x[1457]   c257      1
    x[1458]   c135      -3
    x[1458]   c168      3
    x[1458]   c205      -134
    x[1458]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1459]   c135      1
    x[1459]   c136      -1
    MARKER    'MARKER'                 'INTORG'
    x[1460]   c136      -3
    x[1460]   c146      3
    x[1460]   c250      -135
    x[1460]   c300      1
    x[1461]   c136      -5
    x[1461]   c140      5
    x[1461]   c233      -135
    x[1461]   c283      1
    x[1462]   c136      -1
    x[1462]   c168      1
    x[1462]   c228      -135
    x[1462]   c278      1
    x[1463]   c136      -4
    x[1463]   c159      4
    x[1463]   c207      -135
    x[1463]   c257      1
    x[1464]   c136      -3
    x[1464]   c169      3
    x[1464]   c205      -135
    x[1464]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1465]   c136      1
    x[1465]   c137      -1
    MARKER    'MARKER'                 'INTORG'
    x[1466]   c137      -3
    x[1466]   c147      3
    x[1466]   c250      -136
    x[1466]   c300      1
    x[1467]   c137      -5
    x[1467]   c141      5
    x[1467]   c233      -136
    x[1467]   c283      1
    x[1468]   c137      -1
    x[1468]   c169      1
    x[1468]   c228      -136
    x[1468]   c278      1
    x[1469]   c137      -4
    x[1469]   c160      4
    x[1469]   c207      -136
    x[1469]   c257      1
    x[1470]   c24_2     1
    x[1470]   c137      -3
    x[1470]   c170      3
    x[1470]   c205      -136
    x[1470]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1471]   c137      1
    x[1471]   c138      -1
    MARKER    'MARKER'                 'INTORG'
    x[1472]   c138      -3
    x[1472]   c148      3
    x[1472]   c250      -137
    x[1472]   c300      1
    x[1473]   c138      -5
    x[1473]   c142      5
    x[1473]   c233      -137
    x[1473]   c283      1
    x[1474]   c138      -4
    x[1474]   c161      4
    x[1474]   c207      -137
    x[1474]   c257      1
    x[1475]   c25_2     1
    x[1475]   c138      -3
    x[1475]   c171      3
    x[1475]   c205      -137
    x[1475]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1476]   c138      1
    x[1476]   c139      -1
    MARKER    'MARKER'                 'INTORG'
    x[1477]   c139      -3
    x[1477]   c149      3
    x[1477]   c250      -138
    x[1477]   c300      1
    x[1478]   c139      -5
    x[1478]   c143      5
    x[1478]   c233      -138
    x[1478]   c283      1
    x[1479]   c139      -4
    x[1479]   c162      4
    x[1479]   c207      -138
    x[1479]   c257      1
    x[1480]   c26_2     1
    x[1480]   c139      -3
    x[1480]   c172      3
    x[1480]   c205      -138
    x[1480]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1481]   c139      1
    x[1481]   c140      -1
    MARKER    'MARKER'                 'INTORG'
    x[1482]   c140      -3
    x[1482]   c150      3
    x[1482]   c250      -139
    x[1482]   c300      1
    x[1483]   c140      -5
    x[1483]   c144      5
    x[1483]   c233      -139
    x[1483]   c283      1
    x[1484]   c140      -4
    x[1484]   c163      4
    x[1484]   c207      -139
    x[1484]   c257      1
    x[1485]   c1_2      1
    x[1485]   c140      -3
    x[1485]   c173      3
    x[1485]   c205      -139
    x[1485]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1486]   c140      1
    x[1486]   c141      -1
    MARKER    'MARKER'                 'INTORG'
    x[1487]   c141      -3
    x[1487]   c151      3
    x[1487]   c250      -140
    x[1487]   c300      1
    x[1488]   c141      -5
    x[1488]   c145      5
    x[1488]   c233      -140
    x[1488]   c283      1
    x[1489]   c141      -4
    x[1489]   c164      4
    x[1489]   c207      -140
    x[1489]   c257      1
    x[1490]   c2_2      1
    x[1490]   c141      -3
    x[1490]   c174      3
    x[1490]   c205      -140
    x[1490]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1491]   c141      1
    x[1491]   c142      -1
    MARKER    'MARKER'                 'INTORG'
    x[1492]   c142      -3
    x[1492]   c152      3
    x[1492]   c250      -141
    x[1492]   c300      1
    x[1493]   c142      -5
    x[1493]   c146      5
    x[1493]   c233      -141
    x[1493]   c283      1
    x[1494]   c142      -4
    x[1494]   c165      4
    x[1494]   c207      -141
    x[1494]   c257      1
    x[1495]   c3_2      1
    x[1495]   c142      -3
    x[1495]   c175      3
    x[1495]   c205      -141
    x[1495]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1496]   c142      1
    x[1496]   c143      -1
    MARKER    'MARKER'                 'INTORG'
    x[1497]   c143      -3
    x[1497]   c153      3
    x[1497]   c250      -142
    x[1497]   c300      1
    x[1498]   c143      -5
    x[1498]   c147      5
    x[1498]   c233      -142
    x[1498]   c283      1
    x[1499]   c143      -4
    x[1499]   c166      4
    x[1499]   c207      -142
    x[1499]   c257      1
    x[1500]   c4_2      1
    x[1500]   c143      -3
    x[1500]   c176      3
    x[1500]   c205      -142
    x[1500]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1501]   c143      1
    x[1501]   c144      -1
    MARKER    'MARKER'                 'INTORG'
    x[1502]   c144      -3
    x[1502]   c154      3
    x[1502]   c250      -143
    x[1502]   c300      1
    x[1503]   c144      -5
    x[1503]   c148      5
    x[1503]   c233      -143
    x[1503]   c283      1
    x[1504]   c144      -5
    x[1504]   c160      5
    x[1504]   c218      -143
    x[1504]   c268      1
    x[1505]   c144      -1
    x[1505]   c168      1
    x[1505]   c214      -143
    x[1505]   c264      1
    x[1506]   c144      -4
    x[1506]   c167      4
    x[1506]   c207      -143
    x[1506]   c257      1
    x[1507]   c5_2      1
    x[1507]   c144      -3
    x[1507]   c177      3
    x[1507]   c205      -143
    x[1507]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1508]   c144      1
    x[1508]   c145      -1
    MARKER    'MARKER'                 'INTORG'
    x[1509]   c145      -3
    x[1509]   c155      3
    x[1509]   c250      -144
    x[1509]   c300      1
    x[1510]   c145      -5
    x[1510]   c149      5
    x[1510]   c233      -144
    x[1510]   c283      1
    x[1511]   c145      -5
    x[1511]   c161      5
    x[1511]   c218      -144
    x[1511]   c268      1
    x[1512]   c145      -1
    x[1512]   c169      1
    x[1512]   c214      -144
    x[1512]   c264      1
    x[1513]   c145      -4
    x[1513]   c168      4
    x[1513]   c207      -144
    x[1513]   c257      1
    x[1514]   c6_2      1
    x[1514]   c145      -3
    x[1514]   c178      3
    x[1514]   c205      -144
    x[1514]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1515]   c145      1
    x[1515]   c146      -1
    MARKER    'MARKER'                 'INTORG'
    x[1516]   c146      -5
    x[1516]   c150      5
    x[1516]   c233      -145
    x[1516]   c283      1
    x[1517]   c146      -5
    x[1517]   c162      5
    x[1517]   c218      -145
    x[1517]   c268      1
    x[1518]   c146      -1
    x[1518]   c170      1
    x[1518]   c214      -145
    x[1518]   c264      1
    x[1519]   c146      -4
    x[1519]   c169      4
    x[1519]   c207      -145
    x[1519]   c257      1
    x[1520]   c7_2      1
    x[1520]   c146      -3
    x[1520]   c179      3
    x[1520]   c205      -145
    x[1520]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1521]   c146      1
    x[1521]   c147      -1
    MARKER    'MARKER'                 'INTORG'
    x[1522]   c147      -5
    x[1522]   c151      5
    x[1522]   c233      -146
    x[1522]   c283      1
    x[1523]   c147      -5
    x[1523]   c163      5
    x[1523]   c218      -146
    x[1523]   c268      1
    x[1524]   c147      -1
    x[1524]   c171      1
    x[1524]   c214      -146
    x[1524]   c264      1
    x[1525]   c147      -4
    x[1525]   c170      4
    x[1525]   c207      -146
    x[1525]   c257      1
    x[1526]   c8_2      1
    x[1526]   c147      -3
    x[1526]   c180      3
    x[1526]   c205      -146
    x[1526]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1527]   c147      1
    x[1527]   c148      -1
    MARKER    'MARKER'                 'INTORG'
    x[1528]   c148      -5
    x[1528]   c152      5
    x[1528]   c233      -147
    x[1528]   c283      1
    x[1529]   c148      -5
    x[1529]   c164      5
    x[1529]   c218      -147
    x[1529]   c268      1
    x[1530]   c148      -1
    x[1530]   c172      1
    x[1530]   c214      -147
    x[1530]   c264      1
    x[1531]   c148      -4
    x[1531]   c171      4
    x[1531]   c207      -147
    x[1531]   c257      1
    x[1532]   c148      -5
    x[1532]   c165      5
    x[1532]   c206      -147
    x[1532]   c256      1
    x[1533]   c9_2      1
    x[1533]   c148      -3
    x[1533]   c181      3
    x[1533]   c205      -147
    x[1533]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1534]   c148      1
    x[1534]   c149      -1
    MARKER    'MARKER'                 'INTORG'
    x[1535]   c149      -5
    x[1535]   c171      5
    x[1535]   c239      -148
    x[1535]   c289      1
    x[1536]   c149      -5
    x[1536]   c153      5
    x[1536]   c233      -148
    x[1536]   c283      1
    x[1537]   c149      -5
    x[1537]   c165      5
    x[1537]   c218      -148
    x[1537]   c268      1
    x[1538]   c149      -1
    x[1538]   c173      1
    x[1538]   c214      -148
    x[1538]   c264      1
    x[1539]   c149      -4
    x[1539]   c172      4
    x[1539]   c207      -148
    x[1539]   c257      1
    x[1540]   c149      -5
    x[1540]   c166      5
    x[1540]   c206      -148
    x[1540]   c256      1
    x[1541]   c10_2     1
    x[1541]   c149      -3
    x[1541]   c182      3
    x[1541]   c205      -148
    x[1541]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1542]   c149      1
    x[1542]   c150      -1
    MARKER    'MARKER'                 'INTORG'
    x[1543]   c150      -5
    x[1543]   c172      5
    x[1543]   c239      -149
    x[1543]   c289      1
    x[1544]   c150      -5
    x[1544]   c154      5
    x[1544]   c233      -149
    x[1544]   c283      1
    x[1545]   c150      -5
    x[1545]   c166      5
    x[1545]   c218      -149
    x[1545]   c268      1
    x[1546]   c150      -1
    x[1546]   c174      1
    x[1546]   c214      -149
    x[1546]   c264      1
    x[1547]   c150      -4
    x[1547]   c173      4
    x[1547]   c207      -149
    x[1547]   c257      1
    x[1548]   c150      -5
    x[1548]   c167      5
    x[1548]   c206      -149
    x[1548]   c256      1
    x[1549]   c11_2     1
    x[1549]   c150      -3
    x[1549]   c183      3
    x[1549]   c205      -149
    x[1549]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1550]   c150      1
    x[1550]   c151      -1
    MARKER    'MARKER'                 'INTORG'
    x[1551]   c151      -5
    x[1551]   c173      5
    x[1551]   c239      -150
    x[1551]   c289      1
    x[1552]   c151      -5
    x[1552]   c155      5
    x[1552]   c233      -150
    x[1552]   c283      1
    x[1553]   c151      -5
    x[1553]   c167      5
    x[1553]   c218      -150
    x[1553]   c268      1
    x[1554]   c151      -1
    x[1554]   c175      1
    x[1554]   c214      -150
    x[1554]   c264      1
    x[1555]   c151      -4
    x[1555]   c174      4
    x[1555]   c207      -150
    x[1555]   c257      1
    x[1556]   c151      -5
    x[1556]   c168      5
    x[1556]   c206      -150
    x[1556]   c256      1
    x[1557]   c12_2     1
    x[1557]   c151      -3
    x[1557]   c184      3
    x[1557]   c205      -150
    x[1557]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1558]   c151      1
    x[1558]   c152      -1
    MARKER    'MARKER'                 'INTORG'
    x[1559]   c152      -5
    x[1559]   c174      5
    x[1559]   c239      -151
    x[1559]   c289      1
    x[1560]   c152      -5
    x[1560]   c156      5
    x[1560]   c233      -151
    x[1560]   c283      1
    x[1561]   c152      -5
    x[1561]   c168      5
    x[1561]   c218      -151
    x[1561]   c268      1
    x[1562]   c152      -1
    x[1562]   c176      1
    x[1562]   c214      -151
    x[1562]   c264      1
    x[1563]   c152      -4
    x[1563]   c175      4
    x[1563]   c207      -151
    x[1563]   c257      1
    x[1564]   c152      -5
    x[1564]   c169      5
    x[1564]   c206      -151
    x[1564]   c256      1
    x[1565]   c13_2     1
    x[1565]   c152      -3
    x[1565]   c185      3
    x[1565]   c205      -151
    x[1565]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1566]   c152      1
    x[1566]   c153      -1
    MARKER    'MARKER'                 'INTORG'
    x[1567]   c153      -5
    x[1567]   c175      5
    x[1567]   c239      -152
    x[1567]   c289      1
    x[1568]   c153      -5
    x[1568]   c169      5
    x[1568]   c218      -152
    x[1568]   c268      1
    x[1569]   c153      -1
    x[1569]   c177      1
    x[1569]   c214      -152
    x[1569]   c264      1
    x[1570]   c153      -4
    x[1570]   c176      4
    x[1570]   c207      -152
    x[1570]   c257      1
    x[1571]   c153      -5
    x[1571]   c170      5
    x[1571]   c206      -152
    x[1571]   c256      1
    x[1572]   c14_2     1
    x[1572]   c153      -3
    x[1572]   c186      3
    x[1572]   c205      -152
    x[1572]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1573]   c153      1
    x[1573]   c154      -1
    MARKER    'MARKER'                 'INTORG'
    x[1574]   c154      -5
    x[1574]   c176      5
    x[1574]   c239      -153
    x[1574]   c289      1
    x[1575]   c154      -5
    x[1575]   c170      5
    x[1575]   c218      -153
    x[1575]   c268      1
    x[1576]   c154      -1
    x[1576]   c178      1
    x[1576]   c214      -153
    x[1576]   c264      1
    x[1577]   c154      -4
    x[1577]   c177      4
    x[1577]   c207      -153
    x[1577]   c257      1
    x[1578]   c154      -5
    x[1578]   c171      5
    x[1578]   c206      -153
    x[1578]   c256      1
    x[1579]   c15_2     1
    x[1579]   c154      -3
    x[1579]   c187      3
    x[1579]   c205      -153
    x[1579]   c255      1
    MARKER    'MARKER'                 'INTEND'
    x[1580]   c154      1
    x[1580]   c155      -1
    MARKER    'MARKER'                 'INTORG'
    x[1581]   c155      -5
    x[1581]   c177      5
    x[1581]   c239      -154
    x[1581]   c289      1
    x[1582]   c155      -5
    x[1582]   c171      5
    x[1582]   c218      -154
    x[1582]   c268      1
    x[1583]   c155      -1
    x[1583]   c179      1
    x[1583]   c214      -154
    x[1583]   c264      1
    x[1584]   c155      -4
    x[1584]   c178      4
    x[1584]   c207      -154
    x[1584]   c257      1
    x[1585]   c155      -5
    x[1585]   c172      5
    x[1585]   c206      -154
    x[1585]   c256      1
    MARKER    'MARKER'                 'INTEND'
    x[1586]   c155      1
    x[1586]   c156      -1
    MARKER    'MARKER'                 'INTORG'
    x[1587]   c156      -5
    x[1587]   c178      5
    x[1587]   c239      -155
    x[1587]   c289      1
    x[1588]   c156      -5
    x[1588]   c172      5
    x[1588]   c218      -155
    x[1588]   c268      1
    x[1589]   c156      -1
    x[1589]   c180      1
    x[1589]   c214      -155
    x[1589]   c264      1
    x[1590]   c156      -4
    x[1590]   c179      4
    x[1590]   c207      -155
    x[1590]   c257      1
    x[1591]   c156      -5
    x[1591]   c173      5
    x[1591]   c206      -155
    x[1591]   c256      1
    MARKER    'MARKER'                 'INTEND'
    x[1592]   c156      1
    x[1592]   c157      -1
    MARKER    'MARKER'                 'INTORG'
    x[1593]   c157      -2
    x[1593]   c175      2
    x[1593]   c244      -156
    x[1593]   c294      1
    x[1594]   c157      -5
    x[1594]   c179      5
    x[1594]   c239      -156
    x[1594]   c289      1
    x[1595]   c157      -5
    x[1595]   c173      5
    x[1595]   c218      -156
    x[1595]   c268      1
    x[1596]   c157      -1
    x[1596]   c181      1
    x[1596]   c214      -156
    x[1596]   c264      1
    x[1597]   c157      -4
    x[1597]   c180      4
    x[1597]   c207      -156
    x[1597]   c257      1
    x[1598]   c157      -5
    x[1598]   c174      5
    x[1598]   c206      -156
    x[1598]   c256      1
    MARKER    'MARKER'                 'INTEND'
    x[1599]   c157      1
    x[1599]   c158      -1
    MARKER    'MARKER'                 'INTORG'
    x[1600]   c158      -2
    x[1600]   c176      2
    x[1600]   c244      -157
    x[1600]   c294      1
    x[1601]   c158      -5
    x[1601]   c174      5
    x[1601]   c218      -157
    x[1601]   c268      1
    x[1602]   c158      -1
    x[1602]   c182      1
    x[1602]   c214      -157
    x[1602]   c264      1
    x[1603]   c158      -3
    x[1603]   c187      3
    x[1603]   c213      -157
    x[1603]   c263      1
    x[1604]   c158      -4
    x[1604]   c181      4
    x[1604]   c207      -157
    x[1604]   c257      1
    MARKER    'MARKER'                 'INTEND'
    x[1605]   c158      1
    x[1605]   c159      -1
    MARKER    'MARKER'                 'INTORG'
    x[1606]   c159      -2
    x[1606]   c177      2
    x[1606]   c244      -158
    x[1606]   c294      1
    x[1607]   c159      -5
    x[1607]   c175      5
    x[1607]   c218      -158
    x[1607]   c268      1
    x[1608]   c159      -1
    x[1608]   c183      1
    x[1608]   c214      -158
    x[1608]   c264      1
    x[1609]   c159      -3
    x[1609]   c188      3
    x[1609]   c213      -158
    x[1609]   c263      1
    x[1610]   c159      -4
    x[1610]   c182      4
    x[1610]   c207      -158
    x[1610]   c257      1
    MARKER    'MARKER'                 'INTEND'
    x[1611]   c159      1
    x[1611]   c160      -1
    MARKER    'MARKER'                 'INTORG'
    x[1612]   c160      -2
    x[1612]   c178      2
    x[1612]   c244      -159
    x[1612]   c294      1
    x[1613]   c160      -5
    x[1613]   c176      5
    x[1613]   c218      -159
    x[1613]   c268      1
    x[1614]   c160      -1
    x[1614]   c184      1
    x[1614]   c214      -159
    x[1614]   c264      1
    x[1615]   c160      -3
    x[1615]   c189      3
    x[1615]   c213      -159
    x[1615]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1616]   c160      1
    x[1616]   c161      -1
    MARKER    'MARKER'                 'INTORG'
    x[1617]   c161      -2
    x[1617]   c179      2
    x[1617]   c244      -160
    x[1617]   c294      1
    x[1618]   c161      -5
    x[1618]   c177      5
    x[1618]   c218      -160
    x[1618]   c268      1
    x[1619]   c161      -1
    x[1619]   c185      1
    x[1619]   c214      -160
    x[1619]   c264      1
    x[1620]   c161      -3
    x[1620]   c190      3
    x[1620]   c213      -160
    x[1620]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1621]   c161      1
    x[1621]   c162      -1
    MARKER    'MARKER'                 'INTORG'
    x[1622]   c162      -2
    x[1622]   c180      2
    x[1622]   c244      -161
    x[1622]   c294      1
    x[1623]   c162      -5
    x[1623]   c178      5
    x[1623]   c218      -161
    x[1623]   c268      1
    x[1624]   c162      -1
    x[1624]   c186      1
    x[1624]   c214      -161
    x[1624]   c264      1
    x[1625]   c162      -3
    x[1625]   c191      3
    x[1625]   c213      -161
    x[1625]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1626]   c162      1
    x[1626]   c163      -1
    MARKER    'MARKER'                 'INTORG'
    x[1627]   c163      -2
    x[1627]   c181      2
    x[1627]   c244      -162
    x[1627]   c294      1
    x[1628]   c163      -5
    x[1628]   c179      5
    x[1628]   c218      -162
    x[1628]   c268      1
    x[1629]   c163      -1
    x[1629]   c187      1
    x[1629]   c214      -162
    x[1629]   c264      1
    x[1630]   c163      -3
    x[1630]   c192      3
    x[1630]   c213      -162
    x[1630]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1631]   c163      1
    x[1631]   c164      -1
    MARKER    'MARKER'                 'INTORG'
    x[1632]   c164      -2
    x[1632]   c182      2
    x[1632]   c244      -163
    x[1632]   c294      1
    x[1633]   c164      -5
    x[1633]   c180      5
    x[1633]   c218      -163
    x[1633]   c268      1
    x[1634]   c164      -3
    x[1634]   c193      3
    x[1634]   c213      -163
    x[1634]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1635]   c164      1
    x[1635]   c165      -1
    MARKER    'MARKER'                 'INTORG'
    x[1636]   c165      -2
    x[1636]   c183      2
    x[1636]   c244      -164
    x[1636]   c294      1
    x[1637]   c165      -5
    x[1637]   c181      5
    x[1637]   c218      -164
    x[1637]   c268      1
    x[1638]   c165      -3
    x[1638]   c194      3
    x[1638]   c213      -164
    x[1638]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1639]   c165      1
    x[1639]   c166      -1
    MARKER    'MARKER'                 'INTORG'
    x[1640]   c166      -2
    x[1640]   c184      2
    x[1640]   c244      -165
    x[1640]   c294      1
    x[1641]   c166      -5
    x[1641]   c182      5
    x[1641]   c218      -165
    x[1641]   c268      1
    x[1642]   c166      -3
    x[1642]   c195      3
    x[1642]   c213      -165
    x[1642]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1643]   c166      1
    x[1643]   c167      -1
    MARKER    'MARKER'                 'INTORG'
    x[1644]   c167      -2
    x[1644]   c185      2
    x[1644]   c244      -166
    x[1644]   c294      1
    x[1645]   c167      -5
    x[1645]   c183      5
    x[1645]   c218      -166
    x[1645]   c268      1
    x[1646]   c167      -3
    x[1646]   c196      3
    x[1646]   c213      -166
    x[1646]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1647]   c167      1
    x[1647]   c168      -1
    MARKER    'MARKER'                 'INTORG'
    x[1648]   c168      -2
    x[1648]   c186      2
    x[1648]   c244      -167
    x[1648]   c294      1
    x[1649]   c168      -5
    x[1649]   c184      5
    x[1649]   c218      -167
    x[1649]   c268      1
    x[1650]   c168      -3
    x[1650]   c197      3
    x[1650]   c213      -167
    x[1650]   c263      1
    MARKER    'MARKER'                 'INTEND'
    x[1651]   c168      1
    x[1651]   c169      -1
    MARKER    'MARKER'                 'INTORG'
    x[1652]   c169      -2
    x[1652]   c187      2
    x[1652]   c244      -168
    x[1652]   c294      1
    x[1653]   c169      -5
    x[1653]   c185      5
    x[1653]   c218      -168
    x[1653]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1654]   c169      1
    x[1654]   c170      -1
    MARKER    'MARKER'                 'INTORG'
    x[1655]   c170      -2
    x[1655]   c188      2
    x[1655]   c244      -169
    x[1655]   c294      1
    x[1656]   c170      -5
    x[1656]   c186      5
    x[1656]   c218      -169
    x[1656]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1657]   c170      1
    x[1657]   c171      -1
    MARKER    'MARKER'                 'INTORG'
    x[1658]   c171      -2
    x[1658]   c189      2
    x[1658]   c244      -170
    x[1658]   c294      1
    x[1659]   c171      -5
    x[1659]   c187      5
    x[1659]   c218      -170
    x[1659]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1660]   c171      1
    x[1660]   c172      -1
    MARKER    'MARKER'                 'INTORG'
    x[1661]   c172      -2
    x[1661]   c190      2
    x[1661]   c244      -171
    x[1661]   c294      1
    x[1662]   c172      -5
    x[1662]   c188      5
    x[1662]   c218      -171
    x[1662]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1663]   c172      1
    x[1663]   c173      -1
    MARKER    'MARKER'                 'INTORG'
    x[1664]   c173      -5
    x[1664]   c189      5
    x[1664]   c218      -172
    x[1664]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1665]   c173      1
    x[1665]   c174      -1
    MARKER    'MARKER'                 'INTORG'
    x[1666]   c174      -5
    x[1666]   c190      5
    x[1666]   c218      -173
    x[1666]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1667]   c174      1
    x[1667]   c175      -1
    MARKER    'MARKER'                 'INTORG'
    x[1668]   c175      -3
    x[1668]   c189      3
    x[1668]   c230      -174
    x[1668]   c280      1
    x[1669]   c175      -5
    x[1669]   c191      5
    x[1669]   c218      -174
    x[1669]   c268      1
    MARKER    'MARKER'                 'INTEND'
    x[1670]   c175      1
    x[1670]   c176      -1
    MARKER    'MARKER'                 'INTORG'
    x[1671]   c176      -3
    x[1671]   c190      3
    x[1671]   c230      -175
    x[1671]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1672]   c176      1
    x[1672]   c177      -1
    MARKER    'MARKER'                 'INTORG'
    x[1673]   c177      -3
    x[1673]   c191      3
    x[1673]   c230      -176
    x[1673]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1674]   c177      1
    x[1674]   c178      -1
    MARKER    'MARKER'                 'INTORG'
    x[1675]   c178      -3
    x[1675]   c192      3
    x[1675]   c230      -177
    x[1675]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1676]   c178      1
    x[1676]   c179      -1
    MARKER    'MARKER'                 'INTORG'
    x[1677]   c179      -3
    x[1677]   c193      3
    x[1677]   c230      -178
    x[1677]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1678]   c179      1
    x[1678]   c180      -1
    MARKER    'MARKER'                 'INTORG'
    x[1679]   c180      -3
    x[1679]   c194      3
    x[1679]   c230      -179
    x[1679]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1680]   c180      1
    x[1680]   c181      -1
    MARKER    'MARKER'                 'INTORG'
    x[1681]   c181      -3
    x[1681]   c195      3
    x[1681]   c230      -180
    x[1681]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1682]   c181      1
    x[1682]   c182      -1
    MARKER    'MARKER'                 'INTORG'
    x[1683]   c182      -3
    x[1683]   c196      3
    x[1683]   c230      -181
    x[1683]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1684]   c182      1
    x[1684]   c183      -1
    MARKER    'MARKER'                 'INTORG'
    x[1685]   c183      -3
    x[1685]   c197      3
    x[1685]   c230      -182
    x[1685]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1686]   c183      1
    x[1686]   c184      -1
    MARKER    'MARKER'                 'INTORG'
    x[1687]   c184      -3
    x[1687]   c198      3
    x[1687]   c230      -183
    x[1687]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1688]   c184      1
    x[1688]   c185      -1
    MARKER    'MARKER'                 'INTORG'
    x[1689]   c185      -3
    x[1689]   c199      3
    x[1689]   c230      -184
    x[1689]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1690]   c185      1
    x[1690]   c186      -1
    MARKER    'MARKER'                 'INTORG'
    x[1691]   c186      -3
    x[1691]   c200      3
    x[1691]   c230      -185
    x[1691]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1692]   c186      1
    x[1692]   c187      -1
    MARKER    'MARKER'                 'INTORG'
    x[1693]   c187      -3
    x[1693]   c201      3
    x[1693]   c230      -186
    x[1693]   c280      1
    MARKER    'MARKER'                 'INTEND'
    x[1694]   c187      1
    x[1694]   c188      -1
    x[1695]   c188      1
    x[1695]   c189      -1
    x[1696]   c189      1
    x[1696]   c190      -1
    x[1697]   c190      1
    x[1697]   c191      -1
    x[1698]   c191      1
    x[1698]   c192      -1
    x[1699]   c192      1
    x[1699]   c193      -1
    x[1700]   c193      1
    x[1700]   c194      -1
    x[1701]   c194      1
    x[1701]   c195      -1
    x[1702]   c195      1
    x[1702]   c196      -1
    x[1703]   c196      1
    x[1703]   c197      -1
    x[1704]   c197      1
    x[1704]   c198      -1
    x[1705]   c198      1
    x[1705]   c199      -1
    x[1706]   c199      1
    x[1706]   c200      -1
    x[1707]   c200      1
    x[1707]   c201      -1
    x[1708]   c201      1
    x[1709]   c1_1      -1
    x[1709]   c202      1
    x[1710]   c2_1      -1
    x[1710]   c203      1
    x[1711]   c3_1      -1
    x[1711]   c204      1
    x[1712]   c4_1      -1
    x[1712]   c205      1
    x[1713]   c5_1      -1
    x[1713]   c206      1
    x[1714]   c6_1      -1
    x[1714]   c207      1
    x[1715]   c7_1      -1
    x[1715]   c208      1
    x[1716]   c8_1      -1
    x[1716]   c209      1
    x[1717]   c9_1      -1
    x[1717]   c210      1
    x[1718]   c10_1     -1
    x[1718]   c211      1
    x[1719]   c11_1     -1
    x[1719]   c212      1
    x[1720]   c12_1     -1
    x[1720]   c213      1
    x[1721]   c13_1     -1
    x[1721]   c214      1
    x[1722]   c14_1     -1
    x[1722]   c215      1
    x[1723]   c15_1     -1
    x[1723]   c216      1
    x[1724]   c16_1     -1
    x[1724]   c217      1
    x[1725]   c17_1     -1
    x[1725]   c218      1
    x[1726]   c18_1     -1
    x[1726]   c219      1
    x[1727]   c19_1     -1
    x[1727]   c220      1
    x[1728]   c20_1     -1
    x[1728]   c221      1
    x[1729]   c21_1     -1
    x[1729]   c222      1
    x[1730]   c22_1     -1
    x[1730]   c223      1
    x[1731]   c23_1     -1
    x[1731]   c224      1
    x[1732]   c24_1     -1
    x[1732]   c225      1
    x[1733]   c25_1     -1
    x[1733]   c226      1
    x[1734]   c26_1     -1
    x[1734]   c227      1
    x[1735]   c27_1     -1
    x[1735]   c228      1
    x[1736]   c28_1     -1
    x[1736]   c229      1
    x[1737]   c29_1     -1
    x[1737]   c230      1
    x[1738]   c30_1     -1
    x[1738]   c231      1
    x[1739]   c31_1     -1
    x[1739]   c232      1
    x[1740]   c32_1     -1
    x[1740]   c233      1
    x[1741]   c33_1     -1
    x[1741]   c234      1
    x[1742]   c34_1     -1
    x[1742]   c235      1
    x[1743]   c35_1     -1
    x[1743]   c236      1
    x[1744]   c36_1     -1
    x[1744]   c237      1
    x[1745]   c37_1     -1
    x[1745]   c238      1
    x[1746]   c38_1     -1
    x[1746]   c239      1
    x[1747]   c39_1     -1
    x[1747]   c240      1
    x[1748]   c40_1     -1
    x[1748]   c241      1
    x[1749]   c41_1     -1
    x[1749]   c242      1
    x[1750]   c42_1     -1
    x[1750]   c243      1
    x[1751]   c43_1     -1
    x[1751]   c244      1
    x[1752]   c44_1     -1
    x[1752]   c245      1
    x[1753]   c45_1     -1
    x[1753]   c246      1
    x[1754]   c46_1     -1
    x[1754]   c247      1
    x[1755]   c47_1     -1
    x[1755]   c248      1
    x[1756]   c48_1     -1
    x[1756]   c249      1
    x[1757]   c49_1     -1
    x[1757]   c250      1
    x[1758]   c50_1     -1
    x[1758]   c251      1
RHS
    rhs       c1_2      1
    rhs       c2_2      1
    rhs       c3_2      1
    rhs       c4_2      1
    rhs       c5_2      1
    rhs       c6_2      1
    rhs       c7_2      1
    rhs       c8_2      1
    rhs       c9_2      1
    rhs       c10_2     1
    rhs       c11_2     1
    rhs       c12_2     1
    rhs       c13_2     1
    rhs       c14_2     1
    rhs       c15_2     1
    rhs       c16_2     1
    rhs       c17_2     1
    rhs       c18_2     1
    rhs       c19_2     1
    rhs       c20_2     1
    rhs       c21_2     1
    rhs       c22_2     1
    rhs       c23_2     1
    rhs       c24_2     1
    rhs       c25_2     1
    rhs       c26_2     1
    rhs       c27_2     1
    rhs       c28_2     1
    rhs       c29_2     1
    rhs       c30_2     1
    rhs       c31_2     1
    rhs       c32_2     1
    rhs       c33_2     1
    rhs       c34_2     1
    rhs       c35_2     1
    rhs       c36_2     1
    rhs       c37_2     1
    rhs       c38_2     1
    rhs       c39_2     1
    rhs       c40_2     1
    rhs       c41_2     1
    rhs       c42_2     1
    rhs       c43_2     1
    rhs       c44_2     1
    rhs       c45_2     1
    rhs       c46_2     1
    rhs       c47_2     1
    rhs       c48_2     1
    rhs       c49_2     1
    rhs       c50_2     1
    rhs       c51_1     1
    rhs       c52_1     1
    rhs       c53_1     1
    rhs       c54_1     1
    rhs       c55_1     1
    rhs       c56_1     1
    rhs       c57_1     1
    rhs       c58_1     1
    rhs       c59_1     1
    rhs       c60_1     1
    rhs       c61_1     1
    rhs       c62_1     1
    rhs       c63_1     1
    rhs       c64_1     1
    rhs       c65_1     1
    rhs       c66_1     1
    rhs       c67_1     1
    rhs       c68_1     1
    rhs       c69_1     1
    rhs       c70_1     1
    rhs       c71_1     1
    rhs       c72_1     1
    rhs       c73_1     1
    rhs       c74_1     1
    rhs       c1_1      -72
    rhs       c2_1      -65
    rhs       c3_1      -56
    rhs       c4_1      -106
    rhs       c5_1      -147
    rhs       c6_1      -111
    rhs       c7_1      -56
    rhs       c8_1      -104
    rhs       c9_1      -72
    rhs       c10_1     -9
    rhs       c11_1     -30
    rhs       c12_1     -157
    rhs       c13_1     -143
    rhs       c14_1     -4
    rhs       c15_1     -46
    rhs       c16_1     -41
    rhs       c17_1     -143
    rhs       c18_1     -68
    rhs       c19_1     -13
    rhs       c20_1     -122
    rhs       c21_1     -61
    rhs       c22_1     -21
    rhs       c23_1     -52
    rhs       c24_1     -48
    rhs       c25_1     -3
    rhs       c26_1     -79
    rhs       c27_1     -95
    rhs       c28_1     -118
    rhs       c29_1     -174
    rhs       c30_1     -86
    rhs       c31_1     -66
    rhs       c32_1     -135
    rhs       c33_1     -31
    rhs       c34_1     -4
    rhs       c35_1     -74
    rhs       c36_1     -22
    rhs       c37_1     -14
    rhs       c38_1     -148
    rhs       c39_1     -90
    rhs       c40_1     -30
    rhs       c41_1     -72
    rhs       c42_1     -12
    rhs       c43_1     -156
    rhs       c44_1     -60
    rhs       c45_1     -51
    rhs       c46_1     -26
    rhs       c47_1     -111
    rhs       c48_1     -45
    rhs       c49_1     -119
    rhs       c50_1     -80
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      1
    rhs       c253      1
    rhs       c254      1
    rhs       c255      1
    rhs       c256      1
    rhs       c257      1
    rhs       c258      1
    rhs       c259      1
    rhs       c260      1
    rhs       c261      1
    rhs       c262      1
    rhs       c263      1
    rhs       c264      1
    rhs       c265      1
    rhs       c266      1
    rhs       c267      1
    rhs       c268      1
    rhs       c269      1
    rhs       c270      1
    rhs       c271      1
    rhs       c272      1
    rhs       c273      1
    rhs       c274      1
    rhs       c275      1
    rhs       c276      1
    rhs       c277      1
    rhs       c278      1
    rhs       c279      1
    rhs       c280      1
    rhs       c281      1
    rhs       c282      1
    rhs       c283      1
    rhs       c284      1
    rhs       c285      1
    rhs       c286      1
    rhs       c287      1
    rhs       c288      1
    rhs       c289      1
    rhs       c290      1
    rhs       c291      1
    rhs       c292      1
    rhs       c293      1
    rhs       c294      1
    rhs       c295      1
    rhs       c296      1
    rhs       c297      1
    rhs       c298      1
    rhs       c299      1
    rhs       c300      1
    rhs       c301      1
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      0
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      0
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      0
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     0
    rhs       c1207     0
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     0
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     0
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     0
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     0
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     0
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     0
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     0
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     0
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     0
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     0
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     0
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     0
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     0
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     0
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     0
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     0
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      31
 LO bounds    x[2]      0
 UP bounds    x[2]      43
 LO bounds    x[3]      0
 UP bounds    x[3]      13
 LO bounds    x[4]      0
 UP bounds    x[4]      47
 LO bounds    x[5]      0
 UP bounds    x[5]      9
 LO bounds    x[6]      0
 UP bounds    x[6]      47
 LO bounds    x[7]      0
 UP bounds    x[7]      30
 LO bounds    x[8]      0
 UP bounds    x[8]      21
 LO bounds    x[9]      0
 UP bounds    x[9]      32
 LO bounds    x[10]     0
 UP bounds    x[10]     16
 LO bounds    x[11]     0
 UP bounds    x[11]     19
 LO bounds    x[12]     0
 UP bounds    x[12]     10
 LO bounds    x[13]     0
 UP bounds    x[13]     19
 LO bounds    x[14]     0
 UP bounds    x[14]     29
 LO bounds    x[15]     0
 UP bounds    x[15]     52
 LO bounds    x[16]     0
 UP bounds    x[16]     29
 LO bounds    x[17]     0
 UP bounds    x[17]     31
 LO bounds    x[18]     0
 UP bounds    x[18]     24
 LO bounds    x[19]     0
 UP bounds    x[19]     60
 LO bounds    x[20]     0
 UP bounds    x[20]     10
 LO bounds    x[21]     0
 UP bounds    x[21]     22
 LO bounds    x[22]     0
 UP bounds    x[22]     26
 LO bounds    x[23]     0
 UP bounds    x[23]     22
 LO bounds    x[24]     0
 UP bounds    x[24]     32
 LO bounds    x[25]     0
 UP bounds    x[25]     45
 LO bounds    x[26]     0
 UP bounds    x[26]     36
 LO bounds    x[27]     0
 UP bounds    x[27]     41
 LO bounds    x[28]     0
 UP bounds    x[28]     16
 LO bounds    x[29]     0
 UP bounds    x[29]     12
 LO bounds    x[30]     0
 UP bounds    x[30]     38
 LO bounds    x[31]     0
 UP bounds    x[31]     44
 LO bounds    x[32]     0
 UP bounds    x[32]     16
 LO bounds    x[33]     0
 UP bounds    x[33]     23
 LO bounds    x[34]     0
 UP bounds    x[34]     26
 LO bounds    x[35]     0
 UP bounds    x[35]     13
 LO bounds    x[36]     0
 UP bounds    x[36]     53
 LO bounds    x[37]     0
 UP bounds    x[37]     20
 LO bounds    x[38]     0
 UP bounds    x[38]     8
 LO bounds    x[39]     0
 UP bounds    x[39]     24
 LO bounds    x[40]     0
 UP bounds    x[40]     20
 LO bounds    x[41]     0
 UP bounds    x[41]     23
 LO bounds    x[42]     0
 UP bounds    x[42]     20
 LO bounds    x[43]     0
 UP bounds    x[43]     15
 LO bounds    x[44]     0
 UP bounds    x[44]     55
 LO bounds    x[45]     0
 UP bounds    x[45]     13
 LO bounds    x[46]     0
 UP bounds    x[46]     28
 LO bounds    x[47]     0
 UP bounds    x[47]     6
 LO bounds    x[48]     0
 UP bounds    x[48]     63
 LO bounds    x[49]     0
 UP bounds    x[49]     25
 LO bounds    x[50]     0
 UP bounds    x[50]     50
 FX bounds    x[51]     0
 FX bounds    x[52]     0
 FX bounds    x[53]     0
 BV bounds    x[54]
 LO bounds    x[55]     0
 UP bounds    x[55]     2
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 LO bounds    x[59]     0
 UP bounds    x[59]     11
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 LO bounds    x[63]     0
 UP bounds    x[63]     15
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 LO bounds    x[67]     0
 UP bounds    x[67]     21
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 LO bounds    x[71]     0
 UP bounds    x[71]     25
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 LO bounds    x[75]     0
 UP bounds    x[75]     25
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 LO bounds    x[80]     0
 UP bounds    x[80]     25
 BV bounds    x[81]
 BV bounds    x[82]
 BV bounds    x[83]
 BV bounds    x[84]
 LO bounds    x[85]     0
 UP bounds    x[85]     25
 BV bounds    x[86]
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 LO bounds    x[90]     0
 UP bounds    x[90]     25
 BV bounds    x[91]
 BV bounds    x[92]
 BV bounds    x[93]
 BV bounds    x[94]
 BV bounds    x[95]
 LO bounds    x[96]     0
 UP bounds    x[96]     25
 BV bounds    x[97]
 BV bounds    x[98]
 BV bounds    x[99]
 BV bounds    x[100]
 BV bounds    x[101]
 BV bounds    x[102]
 LO bounds    x[103]    0
 UP bounds    x[103]    25
 BV bounds    x[104]
 BV bounds    x[105]
 BV bounds    x[106]
 BV bounds    x[107]
 BV bounds    x[108]
 BV bounds    x[109]
 BV bounds    x[110]
 LO bounds    x[111]    0
 UP bounds    x[111]    25
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 LO bounds    x[119]    0
 UP bounds    x[119]    25
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 LO bounds    x[127]    0
 UP bounds    x[127]    25
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 LO bounds    x[135]    0
 UP bounds    x[135]    25
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 LO bounds    x[143]    0
 UP bounds    x[143]    25
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 LO bounds    x[151]    0
 UP bounds    x[151]    25
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 LO bounds    x[159]    0
 UP bounds    x[159]    25
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 LO bounds    x[168]    0
 UP bounds    x[168]    25
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 LO bounds    x[178]    0
 UP bounds    x[178]    25
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 BV bounds    x[182]
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 LO bounds    x[188]    0
 UP bounds    x[188]    25
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 LO bounds    x[198]    0
 UP bounds    x[198]    25
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 LO bounds    x[208]    0
 UP bounds    x[208]    25
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 LO bounds    x[218]    0
 UP bounds    x[218]    25
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 LO bounds    x[228]    0
 UP bounds    x[228]    25
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 LO bounds    x[238]    0
 UP bounds    x[238]    25
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 LO bounds    x[248]    0
 UP bounds    x[248]    25
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 LO bounds    x[260]    0
 UP bounds    x[260]    25
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 LO bounds    x[272]    0
 UP bounds    x[272]    25
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 LO bounds    x[284]    0
 UP bounds    x[284]    25
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 LO bounds    x[295]    0
 UP bounds    x[295]    25
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 LO bounds    x[305]    0
 UP bounds    x[305]    25
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 LO bounds    x[314]    0
 UP bounds    x[314]    25
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 LO bounds    x[323]    0
 UP bounds    x[323]    25
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 LO bounds    x[332]    0
 UP bounds    x[332]    25
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 LO bounds    x[341]    0
 UP bounds    x[341]    25
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 LO bounds    x[350]    0
 UP bounds    x[350]    25
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 LO bounds    x[359]    0
 UP bounds    x[359]    25
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 LO bounds    x[369]    0
 UP bounds    x[369]    25
 BV bounds    x[370]
 BV bounds    x[371]
 BV bounds    x[372]
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 LO bounds    x[379]    0
 UP bounds    x[379]    25
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 LO bounds    x[389]    0
 UP bounds    x[389]    25
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 LO bounds    x[399]    0
 UP bounds    x[399]    25
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 LO bounds    x[410]    0
 UP bounds    x[410]    25
 BV bounds    x[411]
 BV bounds    x[412]
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 LO bounds    x[422]    0
 UP bounds    x[422]    25
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 LO bounds    x[434]    0
 UP bounds    x[434]    25
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 LO bounds    x[446]    0
 UP bounds    x[446]    25
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 LO bounds    x[457]    0
 UP bounds    x[457]    25
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 BV bounds    x[461]
 BV bounds    x[462]
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 LO bounds    x[467]    0
 UP bounds    x[467]    25
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 LO bounds    x[477]    0
 UP bounds    x[477]    25
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 LO bounds    x[488]    0
 UP bounds    x[488]    25
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 LO bounds    x[499]    0
 UP bounds    x[499]    25
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 LO bounds    x[510]    0
 UP bounds    x[510]    25
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 LO bounds    x[519]    0
 UP bounds    x[519]    25
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 LO bounds    x[530]    0
 UP bounds    x[530]    25
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 LO bounds    x[541]    0
 UP bounds    x[541]    25
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 LO bounds    x[552]    0
 UP bounds    x[552]    25
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 LO bounds    x[563]    0
 UP bounds    x[563]    25
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 LO bounds    x[575]    0
 UP bounds    x[575]    25
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 LO bounds    x[588]    0
 UP bounds    x[588]    25
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 LO bounds    x[601]    0
 UP bounds    x[601]    25
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 LO bounds    x[614]    0
 UP bounds    x[614]    25
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 LO bounds    x[627]    0
 UP bounds    x[627]    25
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 LO bounds    x[640]    0
 UP bounds    x[640]    25
 BV bounds    x[641]
 BV bounds    x[642]
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 LO bounds    x[654]    0
 UP bounds    x[654]    25
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 LO bounds    x[668]    0
 UP bounds    x[668]    25
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 LO bounds    x[683]    0
 UP bounds    x[683]    25
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 LO bounds    x[698]    0
 UP bounds    x[698]    25
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 LO bounds    x[712]    0
 UP bounds    x[712]    25
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 BV bounds    x[722]
 BV bounds    x[723]
 BV bounds    x[724]
 LO bounds    x[725]    0
 UP bounds    x[725]    25
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 BV bounds    x[736]
 BV bounds    x[737]
 BV bounds    x[738]
 BV bounds    x[739]
 BV bounds    x[740]
 LO bounds    x[741]    0
 UP bounds    x[741]    25
 BV bounds    x[742]
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 LO bounds    x[757]    0
 UP bounds    x[757]    25
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 LO bounds    x[773]    0
 UP bounds    x[773]    25
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 LO bounds    x[788]    0
 UP bounds    x[788]    25
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 LO bounds    x[802]    0
 UP bounds    x[802]    25
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 LO bounds    x[816]    0
 UP bounds    x[816]    25
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 BV bounds    x[822]
 BV bounds    x[823]
 BV bounds    x[824]
 BV bounds    x[825]
 BV bounds    x[826]
 BV bounds    x[827]
 BV bounds    x[828]
 BV bounds    x[829]
 LO bounds    x[830]    0
 UP bounds    x[830]    25
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 LO bounds    x[845]    0
 UP bounds    x[845]    25
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 LO bounds    x[861]    0
 UP bounds    x[861]    25
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 LO bounds    x[876]    0
 UP bounds    x[876]    25
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 LO bounds    x[891]    0
 UP bounds    x[891]    25
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 BV bounds    x[904]
 BV bounds    x[905]
 LO bounds    x[906]    0
 UP bounds    x[906]    25
 BV bounds    x[907]
 BV bounds    x[908]
 BV bounds    x[909]
 BV bounds    x[910]
 BV bounds    x[911]
 BV bounds    x[912]
 BV bounds    x[913]
 BV bounds    x[914]
 BV bounds    x[915]
 BV bounds    x[916]
 BV bounds    x[917]
 BV bounds    x[918]
 BV bounds    x[919]
 LO bounds    x[920]    0
 UP bounds    x[920]    25
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 LO bounds    x[934]    0
 UP bounds    x[934]    25
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 LO bounds    x[949]    0
 UP bounds    x[949]    25
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 LO bounds    x[963]    0
 UP bounds    x[963]    25
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 LO bounds    x[976]    0
 UP bounds    x[976]    25
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 LO bounds    x[989]    0
 UP bounds    x[989]    25
 BV bounds    x[990]
 BV bounds    x[991]
 BV bounds    x[992]
 BV bounds    x[993]
 BV bounds    x[994]
 BV bounds    x[995]
 BV bounds    x[996]
 BV bounds    x[997]
 BV bounds    x[998]
 BV bounds    x[999]
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 LO bounds    x[1003]   0
 UP bounds    x[1003]   25
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 LO bounds    x[1017]   0
 UP bounds    x[1017]   25
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 LO bounds    x[1031]   0
 UP bounds    x[1031]   25
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 LO bounds    x[1044]   0
 UP bounds    x[1044]   25
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 LO bounds    x[1057]   0
 UP bounds    x[1057]   25
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 LO bounds    x[1071]   0
 UP bounds    x[1071]   25
 BV bounds    x[1072]
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 BV bounds    x[1082]
 BV bounds    x[1083]
 LO bounds    x[1084]   0
 UP bounds    x[1084]   25
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 BV bounds    x[1096]
 LO bounds    x[1097]   0
 UP bounds    x[1097]   25
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 BV bounds    x[1101]
 BV bounds    x[1102]
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 BV bounds    x[1107]
 BV bounds    x[1108]
 BV bounds    x[1109]
 LO bounds    x[1110]   0
 UP bounds    x[1110]   25
 BV bounds    x[1111]
 BV bounds    x[1112]
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 LO bounds    x[1122]   0
 UP bounds    x[1122]   25
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 LO bounds    x[1134]   0
 UP bounds    x[1134]   25
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 LO bounds    x[1146]   0
 UP bounds    x[1146]   25
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 BV bounds    x[1150]
 BV bounds    x[1151]
 BV bounds    x[1152]
 BV bounds    x[1153]
 BV bounds    x[1154]
 BV bounds    x[1155]
 BV bounds    x[1156]
 BV bounds    x[1157]
 LO bounds    x[1158]   0
 UP bounds    x[1158]   25
 BV bounds    x[1159]
 BV bounds    x[1160]
 BV bounds    x[1161]
 BV bounds    x[1162]
 BV bounds    x[1163]
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 BV bounds    x[1167]
 BV bounds    x[1168]
 BV bounds    x[1169]
 LO bounds    x[1170]   0
 UP bounds    x[1170]   25
 BV bounds    x[1171]
 BV bounds    x[1172]
 BV bounds    x[1173]
 BV bounds    x[1174]
 BV bounds    x[1175]
 BV bounds    x[1176]
 BV bounds    x[1177]
 BV bounds    x[1178]
 BV bounds    x[1179]
 BV bounds    x[1180]
 BV bounds    x[1181]
 LO bounds    x[1182]   0
 UP bounds    x[1182]   25
 BV bounds    x[1183]
 BV bounds    x[1184]
 BV bounds    x[1185]
 BV bounds    x[1186]
 BV bounds    x[1187]
 BV bounds    x[1188]
 BV bounds    x[1189]
 BV bounds    x[1190]
 BV bounds    x[1191]
 BV bounds    x[1192]
 LO bounds    x[1193]   0
 UP bounds    x[1193]   25
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 BV bounds    x[1197]
 BV bounds    x[1198]
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 BV bounds    x[1203]
 BV bounds    x[1204]
 LO bounds    x[1205]   0
 UP bounds    x[1205]   25
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 BV bounds    x[1209]
 BV bounds    x[1210]
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 LO bounds    x[1217]   0
 UP bounds    x[1217]   25
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 LO bounds    x[1229]   0
 UP bounds    x[1229]   25
 BV bounds    x[1230]
 BV bounds    x[1231]
 BV bounds    x[1232]
 BV bounds    x[1233]
 BV bounds    x[1234]
 BV bounds    x[1235]
 BV bounds    x[1236]
 BV bounds    x[1237]
 BV bounds    x[1238]
 LO bounds    x[1239]   0
 UP bounds    x[1239]   25
 BV bounds    x[1240]
 BV bounds    x[1241]
 BV bounds    x[1242]
 BV bounds    x[1243]
 BV bounds    x[1244]
 BV bounds    x[1245]
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 LO bounds    x[1249]   0
 UP bounds    x[1249]   25
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 LO bounds    x[1260]   0
 UP bounds    x[1260]   25
 BV bounds    x[1261]
 BV bounds    x[1262]
 BV bounds    x[1263]
 BV bounds    x[1264]
 BV bounds    x[1265]
 BV bounds    x[1266]
 BV bounds    x[1267]
 BV bounds    x[1268]
 BV bounds    x[1269]
 BV bounds    x[1270]
 LO bounds    x[1271]   0
 UP bounds    x[1271]   25
 BV bounds    x[1272]
 BV bounds    x[1273]
 BV bounds    x[1274]
 BV bounds    x[1275]
 BV bounds    x[1276]
 BV bounds    x[1277]
 BV bounds    x[1278]
 BV bounds    x[1279]
 BV bounds    x[1280]
 BV bounds    x[1281]
 LO bounds    x[1282]   0
 UP bounds    x[1282]   25
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 LO bounds    x[1293]   0
 UP bounds    x[1293]   25
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 LO bounds    x[1303]   0
 UP bounds    x[1303]   25
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 LO bounds    x[1311]   0
 UP bounds    x[1311]   25
 BV bounds    x[1312]
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 BV bounds    x[1317]
 BV bounds    x[1318]
 LO bounds    x[1319]   0
 UP bounds    x[1319]   25
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 BV bounds    x[1323]
 BV bounds    x[1324]
 BV bounds    x[1325]
 BV bounds    x[1326]
 LO bounds    x[1327]   0
 UP bounds    x[1327]   25
 BV bounds    x[1328]
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 LO bounds    x[1336]   0
 UP bounds    x[1336]   25
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 BV bounds    x[1341]
 BV bounds    x[1342]
 BV bounds    x[1343]
 BV bounds    x[1344]
 LO bounds    x[1345]   0
 UP bounds    x[1345]   25
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 BV bounds    x[1353]
 LO bounds    x[1354]   0
 UP bounds    x[1354]   25
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 BV bounds    x[1359]
 BV bounds    x[1360]
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 LO bounds    x[1364]   0
 UP bounds    x[1364]   25
 BV bounds    x[1365]
 BV bounds    x[1366]
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 LO bounds    x[1374]   0
 UP bounds    x[1374]   25
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 LO bounds    x[1384]   0
 UP bounds    x[1384]   25
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 LO bounds    x[1393]   0
 UP bounds    x[1393]   25
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 LO bounds    x[1401]   0
 UP bounds    x[1401]   25
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 LO bounds    x[1409]   0
 UP bounds    x[1409]   25
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 LO bounds    x[1417]   0
 UP bounds    x[1417]   25
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 LO bounds    x[1425]   0
 UP bounds    x[1425]   25
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 LO bounds    x[1433]   0
 UP bounds    x[1433]   25
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 LO bounds    x[1440]   0
 UP bounds    x[1440]   25
 BV bounds    x[1441]
 BV bounds    x[1442]
 BV bounds    x[1443]
 BV bounds    x[1444]
 BV bounds    x[1445]
 BV bounds    x[1446]
 LO bounds    x[1447]   0
 UP bounds    x[1447]   25
 BV bounds    x[1448]
 BV bounds    x[1449]
 BV bounds    x[1450]
 BV bounds    x[1451]
 BV bounds    x[1452]
 LO bounds    x[1453]   0
 UP bounds    x[1453]   25
 BV bounds    x[1454]
 BV bounds    x[1455]
 BV bounds    x[1456]
 BV bounds    x[1457]
 BV bounds    x[1458]
 LO bounds    x[1459]   0
 UP bounds    x[1459]   25
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 LO bounds    x[1465]   0
 UP bounds    x[1465]   25
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 LO bounds    x[1471]   0
 UP bounds    x[1471]   25
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 LO bounds    x[1476]   0
 UP bounds    x[1476]   25
 BV bounds    x[1477]
 BV bounds    x[1478]
 BV bounds    x[1479]
 BV bounds    x[1480]
 LO bounds    x[1481]   0
 UP bounds    x[1481]   25
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 BV bounds    x[1485]
 LO bounds    x[1486]   0
 UP bounds    x[1486]   25
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 LO bounds    x[1491]   0
 UP bounds    x[1491]   25
 BV bounds    x[1492]
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 LO bounds    x[1496]   0
 UP bounds    x[1496]   25
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 LO bounds    x[1501]   0
 UP bounds    x[1501]   25
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 LO bounds    x[1508]   0
 UP bounds    x[1508]   25
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 LO bounds    x[1515]   0
 UP bounds    x[1515]   25
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 LO bounds    x[1521]   0
 UP bounds    x[1521]   25
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 LO bounds    x[1527]   0
 UP bounds    x[1527]   25
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 BV bounds    x[1532]
 BV bounds    x[1533]
 LO bounds    x[1534]   0
 UP bounds    x[1534]   25
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 BV bounds    x[1539]
 BV bounds    x[1540]
 BV bounds    x[1541]
 LO bounds    x[1542]   0
 UP bounds    x[1542]   25
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 LO bounds    x[1550]   0
 UP bounds    x[1550]   25
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 LO bounds    x[1558]   0
 UP bounds    x[1558]   25
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 LO bounds    x[1566]   0
 UP bounds    x[1566]   25
 BV bounds    x[1567]
 BV bounds    x[1568]
 BV bounds    x[1569]
 BV bounds    x[1570]
 BV bounds    x[1571]
 BV bounds    x[1572]
 LO bounds    x[1573]   0
 UP bounds    x[1573]   25
 BV bounds    x[1574]
 BV bounds    x[1575]
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 LO bounds    x[1580]   0
 UP bounds    x[1580]   25
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 LO bounds    x[1586]   0
 UP bounds    x[1586]   25
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 LO bounds    x[1592]   0
 UP bounds    x[1592]   25
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 LO bounds    x[1599]   0
 UP bounds    x[1599]   25
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 LO bounds    x[1605]   0
 UP bounds    x[1605]   25
 BV bounds    x[1606]
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 LO bounds    x[1611]   0
 UP bounds    x[1611]   25
 BV bounds    x[1612]
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 LO bounds    x[1616]   0
 UP bounds    x[1616]   25
 BV bounds    x[1617]
 BV bounds    x[1618]
 BV bounds    x[1619]
 BV bounds    x[1620]
 LO bounds    x[1621]   0
 UP bounds    x[1621]   25
 BV bounds    x[1622]
 BV bounds    x[1623]
 BV bounds    x[1624]
 BV bounds    x[1625]
 LO bounds    x[1626]   0
 UP bounds    x[1626]   25
 BV bounds    x[1627]
 BV bounds    x[1628]
 BV bounds    x[1629]
 BV bounds    x[1630]
 LO bounds    x[1631]   0
 UP bounds    x[1631]   25
 BV bounds    x[1632]
 BV bounds    x[1633]
 BV bounds    x[1634]
 LO bounds    x[1635]   0
 UP bounds    x[1635]   25
 BV bounds    x[1636]
 BV bounds    x[1637]
 BV bounds    x[1638]
 LO bounds    x[1639]   0
 UP bounds    x[1639]   25
 BV bounds    x[1640]
 BV bounds    x[1641]
 BV bounds    x[1642]
 LO bounds    x[1643]   0
 UP bounds    x[1643]   25
 BV bounds    x[1644]
 BV bounds    x[1645]
 BV bounds    x[1646]
 LO bounds    x[1647]   0
 UP bounds    x[1647]   25
 BV bounds    x[1648]
 BV bounds    x[1649]
 BV bounds    x[1650]
 LO bounds    x[1651]   0
 UP bounds    x[1651]   25
 BV bounds    x[1652]
 BV bounds    x[1653]
 LO bounds    x[1654]   0
 UP bounds    x[1654]   25
 BV bounds    x[1655]
 BV bounds    x[1656]
 LO bounds    x[1657]   0
 UP bounds    x[1657]   25
 BV bounds    x[1658]
 BV bounds    x[1659]
 LO bounds    x[1660]   0
 UP bounds    x[1660]   25
 BV bounds    x[1661]
 BV bounds    x[1662]
 LO bounds    x[1663]   0
 UP bounds    x[1663]   25
 BV bounds    x[1664]
 LO bounds    x[1665]   0
 UP bounds    x[1665]   25
 BV bounds    x[1666]
 LO bounds    x[1667]   0
 UP bounds    x[1667]   25
 BV bounds    x[1668]
 BV bounds    x[1669]
 LO bounds    x[1670]   0
 UP bounds    x[1670]   25
 BV bounds    x[1671]
 LO bounds    x[1672]   0
 UP bounds    x[1672]   25
 BV bounds    x[1673]
 LO bounds    x[1674]   0
 UP bounds    x[1674]   25
 BV bounds    x[1675]
 LO bounds    x[1676]   0
 UP bounds    x[1676]   25
 BV bounds    x[1677]
 LO bounds    x[1678]   0
 UP bounds    x[1678]   25
 BV bounds    x[1679]
 LO bounds    x[1680]   0
 UP bounds    x[1680]   25
 BV bounds    x[1681]
 LO bounds    x[1682]   0
 UP bounds    x[1682]   25
 BV bounds    x[1683]
 LO bounds    x[1684]   0
 UP bounds    x[1684]   25
 BV bounds    x[1685]
 LO bounds    x[1686]   0
 UP bounds    x[1686]   25
 BV bounds    x[1687]
 LO bounds    x[1688]   0
 UP bounds    x[1688]   25
 BV bounds    x[1689]
 LO bounds    x[1690]   0
 UP bounds    x[1690]   25
 BV bounds    x[1691]
 LO bounds    x[1692]   0
 UP bounds    x[1692]   25
 BV bounds    x[1693]
 LO bounds    x[1694]   0
 UP bounds    x[1694]   25
 LO bounds    x[1695]   0
 UP bounds    x[1695]   25
 LO bounds    x[1696]   0
 UP bounds    x[1696]   25
 LO bounds    x[1697]   0
 UP bounds    x[1697]   25
 LO bounds    x[1698]   0
 UP bounds    x[1698]   25
 LO bounds    x[1699]   0
 UP bounds    x[1699]   25
 LO bounds    x[1700]   0
 UP bounds    x[1700]   25
 LO bounds    x[1701]   0
 UP bounds    x[1701]   25
 LO bounds    x[1702]   0
 UP bounds    x[1702]   25
 LO bounds    x[1703]   0
 UP bounds    x[1703]   25
 LO bounds    x[1704]   0
 UP bounds    x[1704]   25
 LO bounds    x[1705]   0
 UP bounds    x[1705]   25
 LO bounds    x[1706]   0
 UP bounds    x[1706]   25
 LO bounds    x[1707]   0
 UP bounds    x[1707]   25
 LO bounds    x[1708]   0
 UP bounds    x[1708]   25
 LO bounds    x[1709]   72
 UP bounds    x[1709]   103
 LO bounds    x[1710]   65
 UP bounds    x[1710]   108
 LO bounds    x[1711]   56
 UP bounds    x[1711]   69
 LO bounds    x[1712]   106
 UP bounds    x[1712]   153
 LO bounds    x[1713]   147
 UP bounds    x[1713]   156
 LO bounds    x[1714]   111
 UP bounds    x[1714]   158
 LO bounds    x[1715]   56
 UP bounds    x[1715]   86
 LO bounds    x[1716]   104
 UP bounds    x[1716]   125
 LO bounds    x[1717]   72
 UP bounds    x[1717]   104
 LO bounds    x[1718]   9
 UP bounds    x[1718]   25
 LO bounds    x[1719]   30
 UP bounds    x[1719]   49
 LO bounds    x[1720]   157
 UP bounds    x[1720]   167
 LO bounds    x[1721]   143
 UP bounds    x[1721]   162
 LO bounds    x[1722]   4
 UP bounds    x[1722]   33
 LO bounds    x[1723]   46
 UP bounds    x[1723]   98
 LO bounds    x[1724]   41
 UP bounds    x[1724]   70
 LO bounds    x[1725]   143
 UP bounds    x[1725]   174
 LO bounds    x[1726]   68
 UP bounds    x[1726]   92
 LO bounds    x[1727]   13
 UP bounds    x[1727]   73
 LO bounds    x[1728]   122
 UP bounds    x[1728]   132
 LO bounds    x[1729]   61
 UP bounds    x[1729]   83
 LO bounds    x[1730]   21
 UP bounds    x[1730]   47
 LO bounds    x[1731]   52
 UP bounds    x[1731]   74
 LO bounds    x[1732]   48
 UP bounds    x[1732]   80
 LO bounds    x[1733]   3
 UP bounds    x[1733]   48
 LO bounds    x[1734]   79
 UP bounds    x[1734]   115
 LO bounds    x[1735]   95
 UP bounds    x[1735]   136
 LO bounds    x[1736]   118
 UP bounds    x[1736]   134
 LO bounds    x[1737]   174
 UP bounds    x[1737]   186
 LO bounds    x[1738]   86
 UP bounds    x[1738]   124
 LO bounds    x[1739]   66
 UP bounds    x[1739]   110
 LO bounds    x[1740]   135
 UP bounds    x[1740]   151
 LO bounds    x[1741]   31
 UP bounds    x[1741]   54
 LO bounds    x[1742]   4
 UP bounds    x[1742]   30
 LO bounds    x[1743]   74
 UP bounds    x[1743]   87
 LO bounds    x[1744]   22
 UP bounds    x[1744]   75
 LO bounds    x[1745]   14
 UP bounds    x[1745]   34
 LO bounds    x[1746]   148
 UP bounds    x[1746]   156
 LO bounds    x[1747]   90
 UP bounds    x[1747]   114
 LO bounds    x[1748]   30
 UP bounds    x[1748]   50
 LO bounds    x[1749]   72
 UP bounds    x[1749]   95
 LO bounds    x[1750]   12
 UP bounds    x[1750]   32
 LO bounds    x[1751]   156
 UP bounds    x[1751]   171
 LO bounds    x[1752]   60
 UP bounds    x[1752]   115
 LO bounds    x[1753]   51
 UP bounds    x[1753]   64
 LO bounds    x[1754]   26
 UP bounds    x[1754]   54
 LO bounds    x[1755]   111
 UP bounds    x[1755]   117
 LO bounds    x[1756]   45
 UP bounds    x[1756]   108
 LO bounds    x[1757]   119
 UP bounds    x[1757]   144
 LO bounds    x[1758]   80
 UP bounds    x[1758]   130
ENDATA
