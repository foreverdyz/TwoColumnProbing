NAME
ROWS
 N  OBJ
 L  c1_1
 L  c2_1
 L  c3_1
 L  c4_1
 L  c5_1
 L  c6_1
 L  c7_1
 L  c8_1
 L  c9_1
 L  c10_1
 L  c11_1
 L  c12_1
 L  c13_1
 L  c14_1
 L  c15_1
 L  c16_1
 L  c17_1
 L  c18_1
 L  c19_1
 L  c20_1
 L  c21_1
 L  c22_1
 L  c23_1
 L  c24_1
 L  c25_1
 L  c26_1
 L  c27_1
 L  c28_1
 L  c29_1
 L  c30_1
 L  c31_1
 L  c32_1
 L  c33_1
 L  c34_1
 L  c35_1
 L  c36_1
 L  c37_1
 L  c38_1
 L  c39_1
 L  c40_1
 L  c41_1
 L  c42_1
 L  c43_1
 L  c44_1
 L  c45_1
 L  c46_1
 L  c47_1
 L  c48_1
 L  c49_1
 L  c50_1
 L  c51_1
 L  c52_1
 L  c53_1
 L  c54_1
 L  c55_1
 L  c56_1
 L  c57_1
 L  c58_1
 L  c59_1
 L  c60_1
 L  c61_1
 L  c62_1
 L  c63_1
 L  c64_1
 L  c65_1
 L  c66_1
 L  c67_1
 L  c68_1
 L  c69_1
 L  c70_1
 L  c71_1
 L  c72_1
 L  c73_1
 L  c74_1
 L  c75_1
 L  c76_1
 L  c77_1
 L  c78_1
 L  c79_1
 L  c80_1
 L  c81_1
 L  c82_1
 L  c83_1
 L  c84_1
 L  c85_1
 L  c86_1
 L  c87_1
 L  c88_1
 L  c89_1
 L  c90_1
 L  c91_1
 L  c92_1
 L  c93_1
 L  c94_1
 L  c95_1
 L  c96_1
 L  c97_1
 L  c98_1
 L  c99_1
 L  c100_1
 L  c101_1
 L  c102_1
 L  c103_1
 L  c104_1
 L  c105_1
 L  c106_1
 L  c107_1
 L  c108_1
 L  c109_1
 L  c110_1
 L  c111_1
 L  c112_1
 L  c113_1
 L  c114_1
 L  c115_1
 L  c116_1
 L  c117_1
 L  c118_1
 L  c119_1
 L  c120_1
 L  c121_1
 L  c122_1
 L  c123_1
 L  c124_1
 L  c125_1
 L  c126_1
 L  c127_1
 L  c128_1
 L  c129_1
 L  c130_1
 L  c131_1
 L  c132_1
 L  c133_1
 L  c134_1
 L  c135_1
 L  c136_1
 L  c137_1
 L  c138_1
 L  c139_1
 L  c140_1
 L  c141_1
 L  c142_1
 L  c143_1
 L  c144_1
 L  c145_1
 L  c146_1
 L  c147_1
 L  c148_1
 L  c149_1
 L  c150_1
 L  c151_1
 L  c152_1
 L  c153_1
 L  c154_1
 L  c155_1
 L  c156_1
 L  c157_1
 L  c158_1
 L  c159_1
 L  c160_1
 L  c161_1
 L  c162_1
 L  c163_1
 L  c164_1
 L  c165_1
 L  c166_1
 L  c167_1
 L  c168_1
 L  c169_1
 L  c170_1
 L  c171_1
 L  c172_1
 L  c173_1
 L  c174_1
 L  c175_1
 L  c176_1
 L  c177_1
 L  c178_1
 L  c179_1
 L  c180_1
 L  c181_1
 L  c182_1
 L  c183_1
 L  c184_1
 L  c185_1
 L  c186_1
 L  c187_1
 L  c188_1
 L  c189_1
 L  c190_1
 L  c191_1
 L  c192_1
 L  c193_1
 L  c194_1
 L  c195_1
 L  c196_1
 L  c197_1
 L  c198_1
 L  c199_1
 L  c200_1
 L  c201_1
 L  c202_1
 L  c203_1
 L  c204_1
 L  c205_1
 L  c206_1
 L  c207_1
 L  c208_1
 L  c209_1
 L  c210_1
 L  c211_1
 L  c212_1
 L  c213_1
 L  c214_1
 L  c215_1
 L  c216_1
 L  c217_1
 L  c218_1
 L  c219_1
 L  c220_1
 L  c221_1
 L  c222_1
 L  c223_1
 L  c224_1
 L  c225_1
 L  c226_1
 L  c227_1
 L  c228_1
 L  c229_1
 L  c230_1
 L  c231_1
 L  c232_1
 L  c233_1
 L  c234_1
 L  c235_1
 L  c236_1
 L  c237_1
 L  c238_1
 L  c239_1
 L  c240_1
 L  c241_1
 L  c242_1
 L  c243_1
 L  c244_1
 L  c245_1
 L  c246_1
 L  c247_1
 L  c248_1
 L  c249_1
 L  c250_1
 L  c251_1
 L  c252_1
 L  c253_1
 L  c254_1
 L  c255_1
 L  c256_1
 L  c257_1
 L  c258_1
 L  c259_1
 L  c260_1
 L  c261_1
 L  c262_1
 L  c263_1
 L  c264_1
 L  c265_1
 L  c266_1
 L  c267_1
 L  c268_1
 L  c269_1
 L  c270_1
 L  c271_1
 L  c272_1
 L  c273_1
 L  c274_1
 L  c275_1
 L  c276_1
 L  c277_1
 L  c278_1
 L  c279_1
 L  c280_1
 L  c281_1
 L  c282_1
 L  c283_1
 L  c284_1
 L  c285_1
 L  c286_1
 L  c287_1
 L  c288_1
 L  c289_1
 L  c290_1
 L  c291_1
 L  c292_1
 L  c293_1
 L  c294_1
 L  c295_1
 L  c296_1
 L  c297_1
 L  c298_1
 L  c299_1
 L  c300_1
 L  c301_1
 L  c302_1
 L  c303_1
 L  c304_1
 L  c305_1
 L  c306_1
 L  c307_1
 L  c308_1
 L  c309_1
 L  c310_1
 L  c311_1
 L  c312_1
 L  c313_1
 L  c314_1
 L  c315_1
 L  c316_1
 L  c317_1
 L  c318_1
 L  c319_1
 L  c320_1
 L  c321_1
 L  c322_1
 L  c323_1
 L  c324_1
 L  c325_1
 L  c326_1
 L  c327_1
 L  c328_1
 L  c329_1
 L  c330_1
 L  c331_1
 L  c332_1
 L  c333_1
 L  c334_1
 L  c335_1
 L  c336_1
 L  c337_1
 L  c338_1
 L  c339_1
 L  c340_1
 L  c341_1
 L  c342_1
 L  c343_1
 L  c344_1
 L  c345_1
 L  c346_1
 L  c347_1
 L  c348_1
 L  c349_1
 L  c350_1
 L  c351_1
 L  c352_1
 L  c353_1
 L  c354_1
 L  c355_1
 L  c356_1
 L  c357_1
 L  c358_1
 L  c359_1
 L  c360_1
 L  c361_1
 L  c362_1
 L  c363_1
 L  c364_1
 L  c365_1
 L  c366_1
 L  c367_1
 L  c368_1
 L  c369_1
 L  c370_1
 L  c371_1
 L  c372_1
 L  c373_1
 L  c374_1
 L  c375_1
 L  c376_1
 L  c377_1
 L  c378_1
 L  c379_1
 L  c380_1
 L  c381_1
 L  c382_1
 L  c383_1
 L  c384_1
 L  c385_1
 L  c386_1
 L  c387_1
 L  c388_1
 L  c389_1
 L  c390_1
 L  c391_1
 L  c392_1
 L  c393_1
 L  c394_1
 L  c395_1
 L  c396_1
 L  c397_1
 L  c398_1
 L  c399_1
 L  c400_1
 L  c401_1
 L  c402_1
 L  c403_1
 L  c404_1
 L  c405_1
 L  c406_1
 L  c407_1
 L  c408_1
 L  c409_1
 L  c410_1
 L  c411_1
 L  c412_1
 L  c413_1
 L  c414_1
 L  c415_1
 L  c416_1
 L  c417_1
 L  c418_1
 L  c419_1
 L  c420_1
 L  c421_1
 L  c422_1
 L  c423_1
 L  c424_1
 L  c425_1
 L  c426_1
 L  c427_1
 L  c428_1
 L  c429_1
 L  c430_1
 L  c431_1
 L  c432_1
 L  c433_1
 L  c434_1
 L  c435_1
 L  c436_1
 L  c437_1
 L  c438_1
 L  c439_1
 L  c440_1
 L  c441_1
 L  c442_1
 L  c443_1
 L  c444_1
 L  c445_1
 L  c446_1
 L  c447_1
 L  c448_1
 L  c449_1
 L  c450_1
 L  c451_1
 L  c452_1
 L  c453_1
 L  c454_1
 L  c455_1
 L  c456_1
 L  c457_1
 L  c458_1
 L  c459_1
 L  c460_1
 L  c461_1
 L  c462_1
 L  c463_1
 L  c464_1
 L  c465_1
 L  c466_1
 L  c467_1
 L  c468_1
 L  c469_1
 L  c470_1
 L  c471_1
 L  c472_1
 L  c473_1
 L  c474_1
 L  c475_1
 L  c476_1
 L  c477_1
 L  c478_1
 L  c479_1
 L  c480_1
 L  c481_1
 L  c482_1
 L  c483_1
 L  c484_1
 L  c485_1
 L  c486_1
 L  c487_1
 L  c488_1
 L  c489_1
 L  c490_1
 L  c491_1
 L  c492_1
 L  c493_1
 L  c494_1
 L  c495_1
 L  c496_1
 L  c497_1
 L  c498_1
 L  c499_1
 L  c500_1
 L  c501_1
 L  c502_1
 L  c503_1
 L  c504_1
 L  c505_1
 L  c506_1
 L  c507_1
 L  c508_1
 L  c509_1
 L  c510_1
 L  c511_1
 L  c512_1
 L  c513_1
 L  c514_1
 L  c515_1
 L  c516_1
 L  c517_1
 L  c518_1
 L  c519_1
 L  c520_1
 L  c521_1
 L  c522_1
 L  c523_1
 L  c524_1
 L  c525_1
 L  c526_1
 L  c527_1
 L  c528_1
 L  c529_1
 L  c530_1
 L  c531_1
 L  c532_1
 L  c533_1
 L  c534_1
 L  c535_1
 L  c536_1
 L  c537_1
 L  c538_1
 L  c539_1
 L  c540_1
 L  c541_1
 L  c542_1
 L  c543_1
 L  c544_1
 L  c545_1
 L  c546_1
 L  c547_1
 L  c548_1
 L  c549_1
 L  c550_1
 L  c551_1
 L  c552_1
 L  c553_1
 L  c554_1
 L  c555_1
 L  c556_1
 L  c557_1
 L  c558_1
 L  c559_1
 L  c560_1
 L  c561_1
 L  c562_1
 L  c563_1
 L  c564_1
 L  c565_1
 L  c566_1
 L  c567_1
 L  c568_1
 L  c569_1
 L  c570_1
 L  c571_1
 L  c572_1
 L  c573_1
 L  c574_1
 L  c575_1
 L  c576_1
 L  c577_1
 L  c578_1
 L  c579_1
 L  c580_1
 L  c581_1
 L  c582_1
 L  c583_1
 L  c584_1
 L  c585_1
 L  c586_1
 L  c587_1
 L  c588_1
 L  c589_1
 L  c590_1
 L  c591_1
 L  c592_1
 L  c593_1
 L  c594_1
 L  c595_1
 L  c596_1
 L  c597_1
 L  c598_1
 L  c599_1
 L  c600_1
 L  c601_1
 L  c602_1
 L  c603_1
 L  c604_1
 L  c605_1
 L  c606_1
 L  c607_1
 L  c608_1
 L  c609_1
 L  c610_1
 L  c611_1
 L  c612_1
 L  c613_1
 L  c614_1
 L  c615_1
 L  c616_1
 L  c617_1
 L  c618_1
 L  c619_1
 L  c620_1
 L  c621_1
 L  c622_1
 L  c623_1
 L  c624_1
 L  c625
 L  c626
 L  c627
 L  c628
 L  c629
 L  c630
 L  c631
 L  c632
 L  c633
 L  c634
 L  c635
 L  c636
 L  c637
 L  c638
 L  c639
 L  c640
 L  c641
 L  c642
 L  c643
 L  c644
 L  c645
 L  c646
 L  c647
 L  c648
 L  c649
 L  c650
 L  c651
 L  c652
 L  c653
 L  c654
 L  c655
 L  c656
 L  c657
 L  c658
 L  c659
 L  c660
 L  c661
 L  c662
 L  c663
 L  c664
 L  c665
 L  c666
 L  c667
 L  c668
 L  c669
 L  c670
 L  c671
 L  c672
 L  c673
 L  c674
 L  c675
 L  c676
 L  c677
 L  c678
 L  c679
 L  c680
 L  c681
 L  c682
 L  c683
 L  c684
 L  c685
 L  c686
 L  c687
 L  c688
 L  c689
 L  c690
 L  c691
 L  c692
 L  c693
 L  c694
 L  c695
 L  c696
 L  c697
 L  c698
 L  c699
 L  c700
 L  c701
 L  c702
 L  c703
 L  c704
 L  c705
 L  c706
 L  c707
 L  c708
 L  c709
 L  c710
 L  c711
 L  c712
 L  c713
 L  c714
 L  c715
 L  c716
 L  c717
 L  c718
 L  c719
 L  c720
 L  c721
 L  c722
 L  c723
 L  c724
 L  c725
 L  c726
 L  c727
 L  c728
 L  c729
 L  c730
 L  c731
 L  c732
 L  c733
 L  c734
 L  c735
 L  c736
 L  c737
 L  c738
 L  c739
 L  c740
 L  c741
 L  c742
 L  c743
 L  c744
 L  c745
 L  c746
 L  c747
 L  c748
 L  c749
 L  c750
 L  c751
 L  c752
 L  c753
 L  c754
 L  c755
 L  c756
 L  c757
 L  c758
 L  c759
 L  c760
 L  c761
 L  c762
 L  c763
 L  c764
 L  c765
 L  c766
 L  c767
 L  c768
 L  c769
 L  c770
 L  c771
 L  c772
 L  c773
 L  c774
 L  c775
 L  c776
 L  c777
 L  c778
 L  c779
 L  c780
 L  c781
 L  c782
 L  c783
 L  c784
 L  c785
 L  c786
 L  c787
 L  c788
 L  c789
 L  c790
 L  c791
 L  c792
 L  c793
 L  c794
 L  c795
 L  c796
 L  c797
 L  c798
 L  c799
 L  c800
 L  c801
 L  c802
 L  c803
 L  c804
 L  c805
 L  c806
 L  c807
 L  c808
 L  c809
 L  c810
 L  c811
 L  c812
 L  c813
 L  c814
 L  c815
 L  c816
 L  c817
 L  c818
 L  c819
 L  c820
 L  c821
 L  c822
 L  c823
 L  c824
 L  c825
 L  c826
 L  c827
 L  c828
 L  c829
 L  c830
 L  c831
 L  c832
 L  c833
 L  c834
 L  c835
 L  c836
 L  c837
 L  c838
 L  c839
 L  c840
 L  c841
 L  c842
 L  c843
 L  c844
 L  c845
 L  c846
 L  c847
 L  c848
 L  c849
 L  c850
 L  c851
 L  c852
 L  c853
 L  c854
 L  c855
 L  c856
 L  c857
 L  c858
 L  c859
 L  c860
 L  c861
 L  c862
 L  c863
 L  c864
 L  c865
 L  c866
 L  c867
 L  c868
 L  c869
 L  c870
 L  c871
 L  c872
 L  c873
 L  c874
 L  c875
 L  c876
 L  c877
 L  c878
 L  c879
 L  c880
 L  c881
 L  c882
 L  c883
 L  c884
 L  c885
 L  c886
 L  c887
 L  c888
 L  c889
 L  c890
 L  c891
 L  c892
 L  c893
 L  c894
 L  c895
 L  c896
 L  c897
 L  c898
 L  c899
 L  c900
 L  c901
 L  c902
 L  c903
 L  c904
 L  c905
 L  c906
 L  c907
 L  c908
 L  c909
 L  c910
 L  c911
 L  c912
 L  c913
 L  c914
 L  c915
 L  c916
 L  c917
 L  c918
 L  c919
 L  c920
 L  c921
 L  c922
 L  c923
 L  c924
 L  c925
 L  c926
 L  c927
 L  c928
 L  c929
 L  c930
 L  c931
 L  c932
 L  c933
 L  c934
 L  c935
 L  c936
 L  c937
 L  c938
 L  c939
 L  c940
 L  c941
 L  c942
 L  c943
 L  c944
 L  c945
 L  c946
 L  c947
 L  c948
 L  c949
 L  c950
 L  c951
 L  c952
 L  c953
 L  c954
 L  c955
 L  c956
 L  c957
 L  c958
 L  c959
 L  c960
 L  c961
 L  c962
 L  c963
 L  c964
 L  c965
 L  c966
 L  c967
 L  c968
 L  c969
 L  c970
 L  c971
 L  c972
 L  c973
 L  c974
 L  c975
 L  c976
 L  c977
 L  c978
 L  c979
 L  c980
 L  c981
 L  c982
 L  c983
 L  c984
 L  c985
 L  c986
 L  c987
 L  c988
 L  c989
 L  c990
 L  c991
 L  c992
 L  c993
 L  c994
 L  c995
 L  c996
 L  c997
 L  c998
 L  c999
 L  c1000
 L  c1001
 L  c1002
 L  c1003
 L  c1004
 L  c1005
 L  c1006
 L  c1007
 L  c1008
 L  c1009
 L  c1010
 L  c1011
 L  c1012
 L  c1013
 L  c1014
 L  c1015
 L  c1016
 L  c1017
 L  c1018
 L  c1019
 L  c1020
 L  c1021
 L  c1022
 L  c1023
 L  c1024
 L  c1025
 L  c1026
 L  c1027
 L  c1028
 L  c1029
 L  c1030
 L  c1031
 L  c1032
 L  c1033
 L  c1034
 L  c1035
 L  c1036
 L  c1037
 L  c1038
 L  c1039
 L  c1040
 L  c1041
 L  c1042
 L  c1043
 L  c1044
 L  c1045
 L  c1046
 L  c1047
 L  c1048
 L  c1049
 L  c1050
 L  c1051
 L  c1052
 L  c1053
 L  c1054
 L  c1055
 L  c1056
 L  c1057
 L  c1058
 L  c1059
 L  c1060
 L  c1061
 L  c1062
 L  c1063
 L  c1064
 L  c1065
 L  c1066
 L  c1067
 L  c1068
 L  c1069
 L  c1070
 L  c1071
 L  c1072
 L  c1073
 L  c1074
 L  c1075
 L  c1076
 L  c1077
 L  c1078
 L  c1079
 L  c1080
 L  c1081
 L  c1082
 L  c1083
 L  c1084
 L  c1085
 L  c1086
 L  c1087
 L  c1088
 L  c1089
 L  c1090
 L  c1091
 L  c1092
 L  c1093
 L  c1094
 L  c1095
 L  c1096
 L  c1097
 L  c1098
 L  c1099
 L  c1100
 L  c1101
 L  c1102
 L  c1103
 L  c1104
 L  c1105
 L  c1106
 L  c1107
 L  c1108
 L  c1109
 L  c1110
 L  c1111
 L  c1112
 L  c1113
 L  c1114
 L  c1115
 L  c1116
 L  c1117
 L  c1118
 L  c1119
 L  c1120
 L  c1121
 L  c1122
 L  c1123
 L  c1124
 L  c1125
 L  c1126
 L  c1127
 L  c1128
 L  c1129
 L  c1130
 L  c1131
 L  c1132
 L  c1133
 L  c1134
 L  c1135
 L  c1136
 L  c1137
 L  c1138
 L  c1139
 L  c1140
 L  c1141
 L  c1142
 L  c1143
 L  c1144
 L  c1145
 L  c1146
 L  c1147
 L  c1148
 L  c1149
 L  c1150
 L  c1151
 L  c1152
 L  c1153
 L  c1154
 L  c1155
 L  c1156
 L  c1157
 L  c1158
 L  c1159
 L  c1160
 L  c1161
 L  c1162
 L  c1163
 L  c1164
 L  c1165
 L  c1166
 L  c1167
 L  c1168
 L  c1169
 L  c1170
 L  c1171
 L  c1172
 L  c1173
 L  c1174
 L  c1175
 L  c1176
 L  c1177
 L  c1178
 L  c1179
 L  c1180
 L  c1181
 L  c1182
 L  c1183
 L  c1184
 L  c1185
 L  c1186
 L  c1187
 L  c1188
 L  c1189
 L  c1190
 L  c1191
 L  c1192
 L  c1193
 L  c1194
 L  c1195
 L  c1196
 L  c1197
 L  c1198
 L  c1199
 L  c1200
 L  c1201
 L  c1202
 L  c1203
 L  c1204
 L  c1205
 L  c1206
 L  c1207
 L  c1208
 L  c1209
 L  c1210
 L  c1211
 L  c1212
 L  c1213
 L  c1214
 L  c1215
 L  c1216
 L  c1217
 L  c1218
 L  c1219
 L  c1220
 L  c1221
 L  c1222
 L  c1223
 L  c1224
 L  c1225
 L  c1226
 L  c1227
 L  c1228
 L  c1229
 L  c1230
 L  c1231
 L  c1232
 L  c1233
 L  c1234
 L  c1235
 L  c1236
 L  c1237
 L  c1238
 L  c1239
 L  c1240
 L  c1241
 L  c1242
 L  c1243
 L  c1244
 L  c1245
 L  c1246
 L  c1247
 L  c1248
 L  c1249
 L  c1250
 L  c1251
 L  c1252
 L  c1253
 L  c1254
 L  c1255
 L  c1256
 L  c1257
 L  c1258
 L  c1259
 L  c1260
 L  c1261
 L  c1262
 L  c1263
 L  c1264
 L  c1265
 L  c1266
 L  c1267
 L  c1268
 L  c1269
 L  c1270
 L  c1271
 L  c1272
 L  c1273
 L  c1274
 L  c1275
 L  c1276
 L  c1277
 L  c1278
 L  c1279
 L  c1280
 L  c1281
 L  c1282
 L  c1283
 L  c1284
 L  c1285
 L  c1286
 L  c1287
 L  c1288
 L  c1289
 L  c1290
 L  c1291
 L  c1292
 L  c1293
 L  c1294
 L  c1295
 L  c1296
 L  c1297
 L  c1298
 L  c1299
 L  c1300
 L  c1301
 L  c1302
 L  c1303
 L  c1304
 L  c1305
 L  c1306
 L  c1307
 L  c1308
 L  c1309
 L  c1310
 L  c1311
 L  c1312
 L  c1313
 L  c1314
 L  c1315
 L  c1316
 L  c1317
 L  c1318
 L  c1319
 L  c1320
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
COLUMNS
    x[1]      c1_1      1
    x[1]      c1        1
    x[1]      OBJ       8
    x[2]      c2_1      1
    x[2]      c2        1
    x[2]      OBJ       8
    x[3]      c3_1      1
    x[3]      c3        1
    x[3]      OBJ       9
    x[4]      c4_1      1
    x[4]      c4        1
    x[4]      OBJ       1
    x[5]      c5_1      1
    x[5]      c5        1
    x[5]      OBJ       3
    x[6]      c6_1      1
    x[6]      c6        1
    x[6]      OBJ       1
    x[7]      c7_1      1
    x[7]      c7        1
    x[7]      OBJ       5
    x[8]      c8_1      1
    x[8]      c8        1
    x[8]      OBJ       3
    x[9]      c9_1      1
    x[9]      c9        1
    x[9]      OBJ       8
    x[10]     c10_1     1
    x[10]     c10       1
    x[10]     OBJ       4
    x[11]     c11_1     1
    x[11]     c11       1
    x[11]     OBJ       9
    x[12]     c12_1     1
    x[12]     c12       1
    x[12]     OBJ       2
    x[13]     c13_1     1
    x[13]     c13       1
    x[13]     OBJ       6
    x[14]     c14_1     1
    x[14]     c14       1
    x[14]     OBJ       3
    x[15]     c15_1     1
    x[15]     c15       1
    x[15]     OBJ       6
    x[16]     c16_1     1
    x[16]     c16       1
    x[16]     OBJ       1
    x[17]     c17_1     1
    x[17]     c17       1
    x[17]     OBJ       8
    x[18]     c18_1     1
    x[18]     c18       1
    x[18]     OBJ       5
    x[19]     c19_1     1
    x[19]     c19       1
    x[19]     OBJ       7
    x[20]     c20_1     1
    x[20]     c20       1
    x[20]     OBJ       3
    x[21]     c21_1     1
    x[21]     c21       1
    x[21]     OBJ       4
    x[22]     c22_1     1
    x[22]     c22       1
    x[22]     OBJ       9
    x[23]     c23_1     1
    x[23]     c23       1
    x[23]     OBJ       4
    x[24]     c24_1     1
    x[24]     c24       1
    x[24]     OBJ       6
    x[25]     c25_1     1
    x[25]     c25       1
    x[25]     OBJ       7
    x[26]     c26_1     1
    x[26]     c26       1
    x[26]     OBJ       3
    x[27]     c27_1     1
    x[27]     c27       1
    x[27]     OBJ       9
    x[28]     c28_1     1
    x[28]     c28       1
    x[28]     OBJ       7
    x[29]     c29_1     1
    x[29]     c29       1
    x[29]     OBJ       2
    x[30]     c30_1     1
    x[30]     c30       1
    x[30]     OBJ       5
    x[31]     c31_1     1
    x[31]     c31       1
    x[31]     OBJ       6
    x[32]     c32_1     1
    x[32]     c32       1
    x[32]     OBJ       7
    x[33]     c33_1     1
    x[33]     c33       1
    x[33]     OBJ       5
    x[34]     c34_1     1
    x[34]     c34       1
    x[34]     OBJ       8
    x[35]     c35_1     1
    x[35]     c35       1
    x[35]     OBJ       3
    x[36]     c36_1     1
    x[36]     c36       1
    x[36]     OBJ       4
    x[37]     c37_1     1
    x[37]     c37       1
    x[37]     OBJ       6
    x[38]     c38_1     1
    x[38]     c38       1
    x[38]     OBJ       4
    x[39]     c39_1     1
    x[39]     c39       1
    x[39]     OBJ       2
    x[40]     c40_1     1
    x[40]     c40       1
    x[40]     OBJ       2
    x[41]     c41_1     1
    x[41]     c41       1
    x[41]     OBJ       2
    x[42]     c42_1     1
    x[42]     c42       1
    x[42]     OBJ       4
    x[43]     c43_1     1
    x[43]     c43       1
    x[43]     OBJ       9
    x[44]     c44_1     1
    x[44]     c44       1
    x[44]     OBJ       7
    x[45]     c45_1     1
    x[45]     c45       1
    x[45]     OBJ       6
    x[46]     c46_1     1
    x[46]     c46       1
    x[46]     OBJ       4
    x[47]     c47_1     1
    x[47]     c47       1
    x[47]     OBJ       7
    x[48]     c48_1     1
    x[48]     c48       1
    x[48]     OBJ       9
    x[49]     c49_1     1
    x[49]     c49       1
    x[49]     OBJ       9
    x[50]     c50_1     1
    x[50]     c50       1
    x[50]     OBJ       2
    x[51]     c51_1     1
    x[51]     c51       1
    x[51]     OBJ       6
    x[52]     c52_1     1
    x[52]     c52       1
    x[52]     OBJ       1
    x[53]     c53_1     1
    x[53]     c53       1
    x[53]     OBJ       9
    x[54]     c54_1     1
    x[54]     c54       1
    x[54]     OBJ       7
    x[55]     c55_1     1
    x[55]     c55       1
    x[55]     OBJ       8
    x[56]     c56_1     1
    x[56]     c56       1
    x[56]     OBJ       3
    x[57]     c57_1     1
    x[57]     c57       1
    x[57]     OBJ       3
    x[58]     c58_1     1
    x[58]     c58       1
    x[58]     OBJ       6
    x[59]     c59_1     1
    x[59]     c59       1
    x[59]     OBJ       8
    x[60]     c60_1     1
    x[60]     c60       1
    x[60]     OBJ       6
    x[61]     c61_1     1
    x[61]     c61       1
    x[61]     OBJ       4
    x[62]     c62_1     1
    x[62]     c62       1
    x[62]     OBJ       2
    x[63]     c63_1     1
    x[63]     c63       1
    x[63]     OBJ       9
    x[64]     c64_1     1
    x[64]     c64       1
    x[64]     OBJ       4
    x[65]     c65_1     1
    x[65]     c65       1
    x[65]     OBJ       4
    x[66]     c66_1     1
    x[66]     c66       1
    x[66]     OBJ       5
    x[67]     c67_1     1
    x[67]     c67       1
    x[67]     OBJ       1
    x[68]     c68_1     1
    x[68]     c68       1
    x[68]     OBJ       6
    x[69]     c69_1     1
    x[69]     c69       1
    x[69]     OBJ       5
    x[70]     c70_1     1
    x[70]     c70       1
    x[70]     OBJ       1
    x[71]     c71_1     1
    x[71]     c71       1
    x[71]     OBJ       3
    x[72]     c72_1     1
    x[72]     c72       1
    x[72]     OBJ       1
    x[73]     c73_1     1
    x[73]     c73       1
    x[73]     OBJ       5
    x[74]     c74_1     1
    x[74]     c74       1
    x[74]     OBJ       1
    x[75]     c75_1     1
    x[75]     c75       1
    x[75]     OBJ       3
    x[76]     c76_1     1
    x[76]     c76       1
    x[76]     OBJ       2
    x[77]     c77_1     1
    x[77]     c77       1
    x[77]     OBJ       6
    x[78]     c78_1     1
    x[78]     c78       1
    x[78]     OBJ       6
    x[79]     c79_1     1
    x[79]     c79       1
    x[79]     OBJ       4
    x[80]     c80_1     1
    x[80]     c80       1
    x[80]     OBJ       7
    x[81]     c81_1     1
    x[81]     c81       1
    x[81]     OBJ       4
    x[82]     c82_1     1
    x[82]     c82       1
    x[82]     OBJ       4
    x[83]     c83_1     1
    x[83]     c83       1
    x[83]     OBJ       5
    x[84]     c84_1     1
    x[84]     c84       1
    x[84]     OBJ       7
    x[85]     c85_1     1
    x[85]     c85       1
    x[85]     OBJ       4
    x[86]     c86_1     1
    x[86]     c86       1
    x[86]     OBJ       8
    x[87]     c87_1     1
    x[87]     c87       1
    x[87]     OBJ       3
    x[88]     c88_1     1
    x[88]     c88       1
    x[88]     OBJ       3
    x[89]     c89_1     1
    x[89]     c89       1
    x[89]     OBJ       5
    x[90]     c90_1     1
    x[90]     c90       1
    x[90]     OBJ       6
    x[91]     c91_1     1
    x[91]     c91       1
    x[91]     OBJ       8
    x[92]     c92_1     1
    x[92]     c92       1
    x[92]     OBJ       7
    x[93]     c93_1     1
    x[93]     c93       1
    x[93]     OBJ       8
    x[94]     c94_1     1
    x[94]     c94       1
    x[94]     OBJ       1
    x[95]     c95_1     1
    x[95]     c95       1
    x[95]     OBJ       4
    x[96]     c96_1     1
    x[96]     c96       1
    x[96]     OBJ       9
    x[97]     c97_1     1
    x[97]     c97       1
    x[97]     OBJ       5
    x[98]     c98_1     1
    x[98]     c98       1
    x[98]     OBJ       2
    x[99]     c99_1     1
    x[99]     c99       1
    x[99]     OBJ       5
    x[100]    c100_1    1
    x[100]    c100      1
    x[100]    OBJ       8
    x[101]    c101_1    1
    x[101]    c101      1
    x[101]    OBJ       9
    x[102]    c102_1    1
    x[102]    c102      1
    x[102]    OBJ       8
    x[103]    c103_1    1
    x[103]    c103      1
    x[103]    OBJ       4
    x[104]    c104_1    1
    x[104]    c104      1
    x[104]    OBJ       2
    x[105]    c105_1    1
    x[105]    c105      1
    x[105]    OBJ       8
    x[106]    c106_1    1
    x[106]    c106      1
    x[106]    OBJ       8
    x[107]    c107_1    1
    x[107]    c107      1
    x[107]    OBJ       6
    x[108]    c108_1    1
    x[108]    c108      1
    x[108]    OBJ       7
    x[109]    c109_1    1
    x[109]    c109      1
    x[109]    OBJ       1
    x[110]    c110_1    1
    x[110]    c110      1
    x[110]    OBJ       4
    x[111]    c111_1    1
    x[111]    c111      1
    x[111]    OBJ       4
    x[112]    c112_1    1
    x[112]    c112      1
    x[112]    OBJ       5
    x[113]    c113_1    1
    x[113]    c113      1
    x[113]    OBJ       2
    x[114]    c114_1    1
    x[114]    c114      1
    x[114]    OBJ       2
    x[115]    c115_1    1
    x[115]    c115      1
    x[115]    OBJ       9
    x[116]    c116_1    1
    x[116]    c116      1
    x[116]    OBJ       4
    x[117]    c117_1    1
    x[117]    c117      1
    x[117]    OBJ       1
    x[118]    c118_1    1
    x[118]    c118      1
    x[118]    OBJ       5
    x[119]    c119_1    1
    x[119]    c119      1
    x[119]    OBJ       2
    x[120]    c120_1    1
    x[120]    c120      1
    x[120]    OBJ       1
    x[121]    c121_1    1
    x[121]    c121      1
    x[121]    OBJ       8
    x[122]    c122_1    1
    x[122]    c122      1
    x[122]    OBJ       7
    x[123]    c123_1    1
    x[123]    c123      1
    x[123]    OBJ       3
    x[124]    c124_1    1
    x[124]    c124      1
    x[124]    OBJ       2
    x[125]    c125_1    1
    x[125]    c125      1
    x[125]    OBJ       2
    x[126]    c126_1    1
    x[126]    c126      1
    x[126]    OBJ       3
    x[127]    c127_1    1
    x[127]    c127      1
    x[127]    OBJ       8
    x[128]    c128_1    1
    x[128]    c128      1
    x[128]    OBJ       5
    x[129]    c129_1    1
    x[129]    c129      1
    x[129]    OBJ       9
    x[130]    c130_1    1
    x[130]    c130      1
    x[130]    OBJ       8
    x[131]    c131_1    1
    x[131]    c131      1
    x[131]    OBJ       7
    x[132]    c132_1    1
    x[132]    c132      1
    x[132]    OBJ       8
    x[133]    c133_1    1
    x[133]    c133      1
    x[133]    OBJ       2
    x[134]    c134_1    1
    x[134]    c134      1
    x[134]    OBJ       9
    x[135]    c135_1    1
    x[135]    c135      1
    x[135]    OBJ       6
    x[136]    c136_1    1
    x[136]    c136      1
    x[136]    OBJ       9
    x[137]    c137_1    1
    x[137]    c137      1
    x[137]    OBJ       2
    x[138]    c138_1    1
    x[138]    c138      1
    x[138]    OBJ       1
    x[139]    c139_1    1
    x[139]    c139      1
    x[139]    OBJ       2
    x[140]    c140_1    1
    x[140]    c140      1
    x[140]    OBJ       8
    x[141]    c141_1    1
    x[141]    c141      1
    x[141]    OBJ       4
    x[142]    c142_1    1
    x[142]    c142      1
    x[142]    OBJ       3
    x[143]    c143_1    1
    x[143]    c143      1
    x[143]    OBJ       5
    x[144]    c144_1    1
    x[144]    c144      1
    x[144]    OBJ       9
    x[145]    c145_1    1
    x[145]    c145      1
    x[145]    OBJ       6
    x[146]    c146_1    1
    x[146]    c146      1
    x[146]    OBJ       6
    x[147]    c147_1    1
    x[147]    c147      1
    x[147]    OBJ       5
    x[148]    c148_1    1
    x[148]    c148      1
    x[148]    OBJ       7
    x[149]    c149_1    1
    x[149]    c149      1
    x[149]    OBJ       9
    x[150]    c150_1    1
    x[150]    c150      1
    x[150]    OBJ       7
    x[151]    c151_1    1
    x[151]    c151      1
    x[151]    OBJ       8
    x[152]    c152_1    1
    x[152]    c152      1
    x[152]    OBJ       7
    x[153]    c153_1    1
    x[153]    c153      1
    x[153]    OBJ       8
    x[154]    c154_1    1
    x[154]    c154      1
    x[154]    OBJ       6
    x[155]    c155_1    1
    x[155]    c155      1
    x[155]    OBJ       8
    x[156]    c156_1    1
    x[156]    c156      1
    x[156]    OBJ       6
    x[157]    c157_1    1
    x[157]    c157      1
    x[157]    OBJ       4
    x[158]    c158_1    1
    x[158]    c158      1
    x[158]    OBJ       5
    x[159]    c159_1    1
    x[159]    c159      1
    x[159]    OBJ       4
    x[160]    c160_1    1
    x[160]    c160      1
    x[160]    OBJ       4
    x[161]    c161_1    1
    x[161]    c161      1
    x[161]    OBJ       1
    x[162]    c162_1    1
    x[162]    c162      1
    x[162]    OBJ       1
    x[163]    c163_1    1
    x[163]    c163      1
    x[163]    OBJ       9
    x[164]    c164_1    1
    x[164]    c164      1
    x[164]    OBJ       6
    x[165]    c165_1    1
    x[165]    c165      1
    x[165]    OBJ       7
    x[166]    c166_1    1
    x[166]    c166      1
    x[166]    OBJ       1
    x[167]    c167_1    1
    x[167]    c167      1
    x[167]    OBJ       3
    x[168]    c168_1    1
    x[168]    c168      1
    x[168]    OBJ       8
    x[169]    c169_1    1
    x[169]    c169      1
    x[169]    OBJ       3
    x[170]    c170_1    1
    x[170]    c170      1
    x[170]    OBJ       4
    x[171]    c171_1    1
    x[171]    c171      1
    x[171]    OBJ       5
    x[172]    c172_1    1
    x[172]    c172      1
    x[172]    OBJ       2
    x[173]    c173_1    1
    x[173]    c173      1
    x[173]    OBJ       2
    x[174]    c174_1    1
    x[174]    c174      1
    x[174]    OBJ       9
    x[175]    c175_1    1
    x[175]    c175      1
    x[175]    OBJ       6
    x[176]    c176_1    1
    x[176]    c176      1
    x[176]    OBJ       6
    x[177]    c177_1    1
    x[177]    c177      1
    x[177]    OBJ       2
    x[178]    c178_1    1
    x[178]    c178      1
    x[178]    OBJ       3
    x[179]    c179_1    1
    x[179]    c179      1
    x[179]    OBJ       8
    x[180]    c180_1    1
    x[180]    c180      1
    x[180]    OBJ       9
    x[181]    c181_1    1
    x[181]    c181      1
    x[181]    OBJ       2
    x[182]    c182_1    1
    x[182]    c182      1
    x[182]    OBJ       2
    x[183]    c183_1    1
    x[183]    c183      1
    x[183]    OBJ       4
    x[184]    c184_1    1
    x[184]    c184      1
    x[184]    OBJ       2
    x[185]    c185_1    1
    x[185]    c185      1
    x[185]    OBJ       1
    x[186]    c186_1    1
    x[186]    c186      1
    x[186]    OBJ       3
    x[187]    c187_1    1
    x[187]    c187      1
    x[187]    OBJ       2
    x[188]    c188_1    1
    x[188]    c188      1
    x[188]    OBJ       8
    x[189]    c189_1    1
    x[189]    c189      1
    x[189]    OBJ       8
    x[190]    c190_1    1
    x[190]    c190      1
    x[190]    OBJ       7
    x[191]    c191_1    1
    x[191]    c191      1
    x[191]    OBJ       7
    x[192]    c192_1    1
    x[192]    c192      1
    x[192]    OBJ       2
    x[193]    c193_1    1
    x[193]    c193      1
    x[193]    OBJ       9
    x[194]    c194_1    1
    x[194]    c194      1
    x[194]    OBJ       6
    x[195]    c195_1    1
    x[195]    c195      1
    x[195]    OBJ       8
    x[196]    c196_1    1
    x[196]    c196      1
    x[196]    OBJ       9
    x[197]    c197_1    1
    x[197]    c197      1
    x[197]    OBJ       5
    x[198]    c198_1    1
    x[198]    c198      1
    x[198]    OBJ       3
    x[199]    c199_1    1
    x[199]    c199      1
    x[199]    OBJ       1
    x[200]    c200_1    1
    x[200]    c200      1
    x[200]    OBJ       1
    x[201]    c201_1    1
    x[201]    c201      1
    x[201]    OBJ       8
    x[202]    c202_1    1
    x[202]    c202      1
    x[202]    OBJ       8
    x[203]    c203_1    1
    x[203]    c203      1
    x[203]    OBJ       9
    x[204]    c204_1    1
    x[204]    c204      1
    x[204]    OBJ       8
    x[205]    c205_1    1
    x[205]    c205      1
    x[205]    OBJ       2
    x[206]    c206_1    1
    x[206]    c206      1
    x[206]    OBJ       7
    x[207]    c207_1    1
    x[207]    c207      1
    x[207]    OBJ       1
    x[208]    c208_1    1
    x[208]    c208      1
    x[208]    OBJ       3
    x[209]    c209_1    1
    x[209]    c209      1
    x[209]    OBJ       4
    x[210]    c210_1    1
    x[210]    c210      1
    x[210]    OBJ       6
    x[211]    c211_1    1
    x[211]    c211      1
    x[211]    OBJ       3
    x[212]    c212_1    1
    x[212]    c212      1
    x[212]    OBJ       2
    x[213]    c213_1    1
    x[213]    c213      1
    x[213]    OBJ       8
    x[214]    c214_1    1
    x[214]    c214      1
    x[214]    OBJ       1
    x[215]    c215_1    1
    x[215]    c215      1
    x[215]    OBJ       5
    x[216]    c216_1    1
    x[216]    c216      1
    x[216]    OBJ       7
    x[217]    c217_1    1
    x[217]    c217      1
    x[217]    OBJ       4
    x[218]    c218_1    1
    x[218]    c218      1
    x[218]    OBJ       4
    x[219]    c219_1    1
    x[219]    c219      1
    x[219]    OBJ       8
    x[220]    c220_1    1
    x[220]    c220      1
    x[220]    OBJ       7
    x[221]    c221_1    1
    x[221]    c221      1
    x[221]    OBJ       7
    x[222]    c222_1    1
    x[222]    c222      1
    x[222]    OBJ       6
    x[223]    c223_1    1
    x[223]    c223      1
    x[223]    OBJ       8
    x[224]    c224_1    1
    x[224]    c224      1
    x[224]    OBJ       7
    x[225]    c225_1    1
    x[225]    c225      1
    x[225]    OBJ       3
    x[226]    c226_1    1
    x[226]    c226      1
    x[226]    OBJ       2
    x[227]    c227_1    1
    x[227]    c227      1
    x[227]    OBJ       4
    x[228]    c228_1    1
    x[228]    c228      1
    x[228]    OBJ       5
    x[229]    c229_1    1
    x[229]    c229      1
    x[229]    OBJ       3
    x[230]    c230_1    1
    x[230]    c230      1
    x[230]    OBJ       2
    x[231]    c231_1    1
    x[231]    c231      1
    x[231]    OBJ       4
    x[232]    c232_1    1
    x[232]    c232      1
    x[232]    OBJ       3
    x[233]    c233_1    1
    x[233]    c233      1
    x[233]    OBJ       4
    x[234]    c234_1    1
    x[234]    c234      1
    x[234]    OBJ       9
    x[235]    c235_1    1
    x[235]    c235      1
    x[235]    OBJ       3
    x[236]    c236_1    1
    x[236]    c236      1
    x[236]    OBJ       5
    x[237]    c237_1    1
    x[237]    c237      1
    x[237]    OBJ       5
    x[238]    c238_1    1
    x[238]    c238      1
    x[238]    OBJ       2
    x[239]    c239_1    1
    x[239]    c239      1
    x[239]    OBJ       1
    x[240]    c240_1    1
    x[240]    c240      1
    x[240]    OBJ       3
    x[241]    c241_1    1
    x[241]    c241      1
    x[241]    OBJ       8
    x[242]    c242_1    1
    x[242]    c242      1
    x[242]    OBJ       4
    x[243]    c243_1    1
    x[243]    c243      1
    x[243]    OBJ       7
    x[244]    c244_1    1
    x[244]    c244      1
    x[244]    OBJ       9
    x[245]    c245_1    1
    x[245]    c245      1
    x[245]    OBJ       7
    x[246]    c246_1    1
    x[246]    c246      1
    x[246]    OBJ       2
    x[247]    c247_1    1
    x[247]    c247      1
    x[247]    OBJ       6
    x[248]    c248_1    1
    x[248]    c248      1
    x[248]    OBJ       6
    x[249]    c249_1    1
    x[249]    c249      1
    x[249]    OBJ       2
    x[250]    c250_1    1
    x[250]    c250      1
    x[250]    OBJ       4
    x[251]    c251_1    1
    x[251]    c251      1
    x[251]    OBJ       9
    x[252]    c252_1    1
    x[252]    c252      1
    x[252]    OBJ       8
    x[253]    c253_1    1
    x[253]    c253      1
    x[253]    OBJ       1
    x[254]    c254_1    1
    x[254]    c254      1
    x[254]    OBJ       7
    x[255]    c255_1    1
    x[255]    c255      1
    x[255]    OBJ       5
    x[256]    c256_1    1
    x[256]    c256      1
    x[256]    OBJ       1
    x[257]    c257_1    1
    x[257]    c257      1
    x[257]    OBJ       4
    x[258]    c258_1    1
    x[258]    c258      1
    x[258]    OBJ       7
    x[259]    c259_1    1
    x[259]    c259      1
    x[259]    OBJ       8
    x[260]    c260_1    1
    x[260]    c260      1
    x[260]    OBJ       1
    x[261]    c261_1    1
    x[261]    c261      1
    x[261]    OBJ       9
    x[262]    c262_1    1
    x[262]    c262      1
    x[262]    OBJ       8
    x[263]    c263_1    1
    x[263]    c263      1
    x[263]    OBJ       1
    x[264]    c264_1    1
    x[264]    c264      1
    x[264]    OBJ       7
    x[265]    c265_1    1
    x[265]    c265      1
    x[265]    OBJ       2
    x[266]    c266_1    1
    x[266]    c266      1
    x[266]    OBJ       8
    x[267]    c267_1    1
    x[267]    c267      1
    x[267]    OBJ       9
    x[268]    c268_1    1
    x[268]    c268      1
    x[268]    OBJ       8
    x[269]    c269_1    1
    x[269]    c269      1
    x[269]    OBJ       6
    x[270]    c270_1    1
    x[270]    c270      1
    x[270]    OBJ       7
    x[271]    c271_1    1
    x[271]    c271      1
    x[271]    OBJ       3
    x[272]    c272_1    1
    x[272]    c272      1
    x[272]    OBJ       3
    x[273]    c273_1    1
    x[273]    c273      1
    x[273]    OBJ       9
    x[274]    c274_1    1
    x[274]    c274      1
    x[274]    OBJ       1
    x[275]    c275_1    1
    x[275]    c275      1
    x[275]    OBJ       1
    x[276]    c276_1    1
    x[276]    c276      1
    x[276]    OBJ       3
    x[277]    c277_1    1
    x[277]    c277      1
    x[277]    OBJ       4
    x[278]    c278_1    1
    x[278]    c278      1
    x[278]    OBJ       3
    x[279]    c279_1    1
    x[279]    c279      1
    x[279]    OBJ       2
    x[280]    c280_1    1
    x[280]    c280      1
    x[280]    OBJ       2
    x[281]    c281_1    1
    x[281]    c281      1
    x[281]    OBJ       9
    x[282]    c282_1    1
    x[282]    c282      1
    x[282]    OBJ       4
    x[283]    c283_1    1
    x[283]    c283      1
    x[283]    OBJ       8
    x[284]    c284_1    1
    x[284]    c284      1
    x[284]    OBJ       5
    x[285]    c285_1    1
    x[285]    c285      1
    x[285]    OBJ       7
    x[286]    c286_1    1
    x[286]    c286      1
    x[286]    OBJ       3
    x[287]    c287_1    1
    x[287]    c287      1
    x[287]    OBJ       6
    x[288]    c288_1    1
    x[288]    c288      1
    x[288]    OBJ       8
    x[289]    c289_1    1
    x[289]    c289      1
    x[289]    OBJ       5
    x[290]    c290_1    1
    x[290]    c290      1
    x[290]    OBJ       8
    x[291]    c291_1    1
    x[291]    c291      1
    x[291]    OBJ       8
    x[292]    c292_1    1
    x[292]    c292      1
    x[292]    OBJ       3
    x[293]    c293_1    1
    x[293]    c293      1
    x[293]    OBJ       3
    x[294]    c294_1    1
    x[294]    c294      1
    x[294]    OBJ       6
    x[295]    c295_1    1
    x[295]    c295      1
    x[295]    OBJ       2
    x[296]    c296_1    1
    x[296]    c296      1
    x[296]    OBJ       9
    x[297]    c297_1    1
    x[297]    c297      1
    x[297]    OBJ       7
    x[298]    c298_1    1
    x[298]    c298      1
    x[298]    OBJ       7
    x[299]    c299_1    1
    x[299]    c299      1
    x[299]    OBJ       7
    x[300]    c300_1    1
    x[300]    c300      1
    x[300]    OBJ       5
    x[301]    c301_1    1
    x[301]    c301      1
    x[301]    OBJ       1
    x[302]    c302_1    1
    x[302]    c302      1
    x[302]    OBJ       4
    x[303]    c303_1    1
    x[303]    c303      1
    x[303]    OBJ       5
    x[304]    c304_1    1
    x[304]    c304      1
    x[304]    OBJ       5
    x[305]    c305_1    1
    x[305]    c305      1
    x[305]    OBJ       7
    x[306]    c306_1    1
    x[306]    c306      1
    x[306]    OBJ       1
    x[307]    c307_1    1
    x[307]    c307      1
    x[307]    OBJ       6
    x[308]    c308_1    1
    x[308]    c308      1
    x[308]    OBJ       4
    x[309]    c309_1    1
    x[309]    c309      1
    x[309]    OBJ       5
    x[310]    c310_1    1
    x[310]    c310      1
    x[310]    OBJ       7
    x[311]    c311_1    1
    x[311]    c311      1
    x[311]    OBJ       6
    x[312]    c312_1    1
    x[312]    c312      1
    x[312]    OBJ       1
    x[313]    c313_1    1
    x[313]    c313      1
    x[313]    OBJ       4
    x[314]    c314_1    1
    x[314]    c314      1
    x[314]    OBJ       4
    x[315]    c315_1    1
    x[315]    c315      1
    x[315]    OBJ       9
    x[316]    c316_1    1
    x[316]    c316      1
    x[316]    OBJ       8
    x[317]    c317_1    1
    x[317]    c317      1
    x[317]    OBJ       8
    x[318]    c318_1    1
    x[318]    c318      1
    x[318]    OBJ       4
    x[319]    c319_1    1
    x[319]    c319      1
    x[319]    OBJ       4
    x[320]    c320_1    1
    x[320]    c320      1
    x[320]    OBJ       5
    x[321]    c321_1    1
    x[321]    c321      1
    x[321]    OBJ       9
    x[322]    c322_1    1
    x[322]    c322      1
    x[322]    OBJ       7
    x[323]    c323_1    1
    x[323]    c323      1
    x[323]    OBJ       9
    x[324]    c324_1    1
    x[324]    c324      1
    x[324]    OBJ       5
    x[325]    c325_1    1
    x[325]    c325      1
    x[325]    OBJ       2
    x[326]    c326_1    1
    x[326]    c326      1
    x[326]    OBJ       5
    x[327]    c327_1    1
    x[327]    c327      1
    x[327]    OBJ       2
    x[328]    c328_1    1
    x[328]    c328      1
    x[328]    OBJ       1
    x[329]    c329_1    1
    x[329]    c329      1
    x[329]    OBJ       8
    x[330]    c330_1    1
    x[330]    c330      1
    x[330]    OBJ       2
    x[331]    c331_1    1
    x[331]    c331      1
    x[331]    OBJ       6
    x[332]    c332_1    1
    x[332]    c332      1
    x[332]    OBJ       4
    x[333]    c333_1    1
    x[333]    c333      1
    x[333]    OBJ       6
    x[334]    c334_1    1
    x[334]    c334      1
    x[334]    OBJ       6
    x[335]    c335_1    1
    x[335]    c335      1
    x[335]    OBJ       3
    x[336]    c336_1    1
    x[336]    c336      1
    x[336]    OBJ       2
    x[337]    c337_1    1
    x[337]    c337      1
    x[337]    OBJ       5
    x[338]    c338_1    1
    x[338]    c338      1
    x[338]    OBJ       5
    x[339]    c339_1    1
    x[339]    c339      1
    x[339]    OBJ       9
    x[340]    c340_1    1
    x[340]    c340      1
    x[340]    OBJ       7
    x[341]    c341_1    1
    x[341]    c341      1
    x[341]    OBJ       2
    x[342]    c342_1    1
    x[342]    c342      1
    x[342]    OBJ       2
    x[343]    c343_1    1
    x[343]    c343      1
    x[343]    OBJ       9
    x[344]    c344_1    1
    x[344]    c344      1
    x[344]    OBJ       2
    x[345]    c345_1    1
    x[345]    c345      1
    x[345]    OBJ       1
    x[346]    c346_1    1
    x[346]    c346      1
    x[346]    OBJ       6
    x[347]    c347_1    1
    x[347]    c347      1
    x[347]    OBJ       4
    x[348]    c348_1    1
    x[348]    c348      1
    x[348]    OBJ       6
    x[349]    c349_1    1
    x[349]    c349      1
    x[349]    OBJ       6
    x[350]    c350_1    1
    x[350]    c350      1
    x[350]    OBJ       6
    x[351]    c351_1    1
    x[351]    c351      1
    x[351]    OBJ       9
    x[352]    c352_1    1
    x[352]    c352      1
    x[352]    OBJ       4
    x[353]    c353_1    1
    x[353]    c353      1
    x[353]    OBJ       6
    x[354]    c354_1    1
    x[354]    c354      1
    x[354]    OBJ       1
    x[355]    c355_1    1
    x[355]    c355      1
    x[355]    OBJ       3
    x[356]    c356_1    1
    x[356]    c356      1
    x[356]    OBJ       1
    x[357]    c357_1    1
    x[357]    c357      1
    x[357]    OBJ       7
    x[358]    c358_1    1
    x[358]    c358      1
    x[358]    OBJ       5
    x[359]    c359_1    1
    x[359]    c359      1
    x[359]    OBJ       1
    x[360]    c360_1    1
    x[360]    c360      1
    x[360]    OBJ       9
    x[361]    c361_1    1
    x[361]    c361      1
    x[361]    OBJ       5
    x[362]    c362_1    1
    x[362]    c362      1
    x[362]    OBJ       6
    x[363]    c363_1    1
    x[363]    c363      1
    x[363]    OBJ       7
    x[364]    c364_1    1
    x[364]    c364      1
    x[364]    OBJ       3
    x[365]    c365_1    1
    x[365]    c365      1
    x[365]    OBJ       5
    x[366]    c366_1    1
    x[366]    c366      1
    x[366]    OBJ       2
    x[367]    c367_1    1
    x[367]    c367      1
    x[367]    OBJ       5
    x[368]    c368_1    1
    x[368]    c368      1
    x[368]    OBJ       3
    x[369]    c369_1    1
    x[369]    c369      1
    x[369]    OBJ       1
    x[370]    c370_1    1
    x[370]    c370      1
    x[370]    OBJ       7
    x[371]    c371_1    1
    x[371]    c371      1
    x[371]    OBJ       5
    x[372]    c372_1    1
    x[372]    c372      1
    x[372]    OBJ       2
    x[373]    c373_1    1
    x[373]    c373      1
    x[373]    OBJ       3
    x[374]    c374_1    1
    x[374]    c374      1
    x[374]    OBJ       1
    x[375]    c375_1    1
    x[375]    c375      1
    x[375]    OBJ       2
    x[376]    c376_1    1
    x[376]    c376      1
    x[376]    OBJ       9
    x[377]    c377_1    1
    x[377]    c377      1
    x[377]    OBJ       3
    x[378]    c378_1    1
    x[378]    c378      1
    x[378]    OBJ       9
    x[379]    c379_1    1
    x[379]    c379      1
    x[379]    OBJ       9
    x[380]    c380_1    1
    x[380]    c380      1
    x[380]    OBJ       2
    x[381]    c381_1    1
    x[381]    c381      1
    x[381]    OBJ       7
    x[382]    c382_1    1
    x[382]    c382      1
    x[382]    OBJ       9
    x[383]    c383_1    1
    x[383]    c383      1
    x[383]    OBJ       3
    x[384]    c384_1    1
    x[384]    c384      1
    x[384]    OBJ       5
    x[385]    c385_1    1
    x[385]    c385      1
    x[385]    OBJ       2
    x[386]    c386_1    1
    x[386]    c386      1
    x[386]    OBJ       5
    x[387]    c387_1    1
    x[387]    c387      1
    x[387]    OBJ       7
    x[388]    c388_1    1
    x[388]    c388      1
    x[388]    OBJ       9
    x[389]    c389_1    1
    x[389]    c389      1
    x[389]    OBJ       5
    x[390]    c390_1    1
    x[390]    c390      1
    x[390]    OBJ       7
    x[391]    c391_1    1
    x[391]    c391      1
    x[391]    OBJ       5
    x[392]    c392_1    1
    x[392]    c392      1
    x[392]    OBJ       1
    x[393]    c393_1    1
    x[393]    c393      1
    x[393]    OBJ       3
    x[394]    c394_1    1
    x[394]    c394      1
    x[394]    OBJ       9
    x[395]    c395_1    1
    x[395]    c395      1
    x[395]    OBJ       4
    x[396]    c396_1    1
    x[396]    c396      1
    x[396]    OBJ       3
    x[397]    c397_1    1
    x[397]    c397      1
    x[397]    OBJ       7
    x[398]    c398_1    1
    x[398]    c398      1
    x[398]    OBJ       1
    x[399]    c399_1    1
    x[399]    c399      1
    x[399]    OBJ       6
    x[400]    c400_1    1
    x[400]    c400      1
    x[400]    OBJ       7
    x[401]    c401_1    1
    x[401]    c401      1
    x[401]    OBJ       8
    x[402]    c402_1    1
    x[402]    c402      1
    x[402]    OBJ       8
    x[403]    c403_1    1
    x[403]    c403      1
    x[403]    OBJ       8
    x[404]    c404_1    1
    x[404]    c404      1
    x[404]    OBJ       7
    x[405]    c405_1    1
    x[405]    c405      1
    x[405]    OBJ       5
    x[406]    c406_1    1
    x[406]    c406      1
    x[406]    OBJ       5
    x[407]    c407_1    1
    x[407]    c407      1
    x[407]    OBJ       7
    x[408]    c408_1    1
    x[408]    c408      1
    x[408]    OBJ       2
    x[409]    c409_1    1
    x[409]    c409      1
    x[409]    OBJ       5
    x[410]    c410_1    1
    x[410]    c410      1
    x[410]    OBJ       7
    x[411]    c411_1    1
    x[411]    c411      1
    x[411]    OBJ       3
    x[412]    c412_1    1
    x[412]    c412      1
    x[412]    OBJ       3
    x[413]    c413_1    1
    x[413]    c413      1
    x[413]    OBJ       8
    x[414]    c414_1    1
    x[414]    c414      1
    x[414]    OBJ       9
    x[415]    c415_1    1
    x[415]    c415      1
    x[415]    OBJ       8
    x[416]    c416_1    1
    x[416]    c416      1
    x[416]    OBJ       8
    x[417]    c417_1    1
    x[417]    c417      1
    x[417]    OBJ       8
    x[418]    c418_1    1
    x[418]    c418      1
    x[418]    OBJ       5
    x[419]    c419_1    1
    x[419]    c419      1
    x[419]    OBJ       7
    x[420]    c420_1    1
    x[420]    c420      1
    x[420]    OBJ       4
    x[421]    c421_1    1
    x[421]    c421      1
    x[421]    OBJ       8
    x[422]    c422_1    1
    x[422]    c422      1
    x[422]    OBJ       6
    x[423]    c423_1    1
    x[423]    c423      1
    x[423]    OBJ       2
    x[424]    c424_1    1
    x[424]    c424      1
    x[424]    OBJ       4
    x[425]    c425_1    1
    x[425]    c425      1
    x[425]    OBJ       2
    x[426]    c426_1    1
    x[426]    c426      1
    x[426]    OBJ       3
    x[427]    c427_1    1
    x[427]    c427      1
    x[427]    OBJ       1
    x[428]    c428_1    1
    x[428]    c428      1
    x[428]    OBJ       9
    x[429]    c429_1    1
    x[429]    c429      1
    x[429]    OBJ       1
    x[430]    c430_1    1
    x[430]    c430      1
    x[430]    OBJ       2
    x[431]    c431_1    1
    x[431]    c431      1
    x[431]    OBJ       2
    x[432]    c432_1    1
    x[432]    c432      1
    x[432]    OBJ       8
    x[433]    c433_1    1
    x[433]    c433      1
    x[433]    OBJ       3
    x[434]    c434_1    1
    x[434]    c434      1
    x[434]    OBJ       9
    x[435]    c435_1    1
    x[435]    c435      1
    x[435]    OBJ       7
    x[436]    c436_1    1
    x[436]    c436      1
    x[436]    OBJ       9
    x[437]    c437_1    1
    x[437]    c437      1
    x[437]    OBJ       2
    x[438]    c438_1    1
    x[438]    c438      1
    x[438]    OBJ       3
    x[439]    c439_1    1
    x[439]    c439      1
    x[439]    OBJ       6
    x[440]    c440_1    1
    x[440]    c440      1
    x[440]    OBJ       8
    x[441]    c441_1    1
    x[441]    c441      1
    x[441]    OBJ       1
    x[442]    c442_1    1
    x[442]    c442      1
    x[442]    OBJ       1
    x[443]    c443_1    1
    x[443]    c443      1
    x[443]    OBJ       8
    x[444]    c444_1    1
    x[444]    c444      1
    x[444]    OBJ       4
    x[445]    c445_1    1
    x[445]    c445      1
    x[445]    OBJ       6
    x[446]    c446_1    1
    x[446]    c446      1
    x[446]    OBJ       5
    x[447]    c447_1    1
    x[447]    c447      1
    x[447]    OBJ       3
    x[448]    c448_1    1
    x[448]    c448      1
    x[448]    OBJ       7
    x[449]    c449_1    1
    x[449]    c449      1
    x[449]    OBJ       7
    x[450]    c450_1    1
    x[450]    c450      1
    x[450]    OBJ       6
    x[451]    c451_1    1
    x[451]    c451      1
    x[451]    OBJ       3
    x[452]    c452_1    1
    x[452]    c452      1
    x[452]    OBJ       4
    x[453]    c453_1    1
    x[453]    c453      1
    x[453]    OBJ       7
    x[454]    c454_1    1
    x[454]    c454      1
    x[454]    OBJ       1
    x[455]    c455_1    1
    x[455]    c455      1
    x[455]    OBJ       3
    x[456]    c456_1    1
    x[456]    c456      1
    x[456]    OBJ       4
    x[457]    c457_1    1
    x[457]    c457      1
    x[457]    OBJ       6
    x[458]    c458_1    1
    x[458]    c458      1
    x[458]    OBJ       3
    x[459]    c459_1    1
    x[459]    c459      1
    x[459]    OBJ       8
    x[460]    c460_1    1
    x[460]    c460      1
    x[460]    OBJ       4
    x[461]    c461_1    1
    x[461]    c461      1
    x[461]    OBJ       5
    x[462]    c462_1    1
    x[462]    c462      1
    x[462]    OBJ       5
    x[463]    c463_1    1
    x[463]    c463      1
    x[463]    OBJ       1
    x[464]    c464_1    1
    x[464]    c464      1
    x[464]    OBJ       8
    x[465]    c465_1    1
    x[465]    c465      1
    x[465]    OBJ       4
    x[466]    c466_1    1
    x[466]    c466      1
    x[466]    OBJ       8
    x[467]    c467_1    1
    x[467]    c467      1
    x[467]    OBJ       1
    x[468]    c468_1    1
    x[468]    c468      1
    x[468]    OBJ       5
    x[469]    c469_1    1
    x[469]    c469      1
    x[469]    OBJ       5
    x[470]    c470_1    1
    x[470]    c470      1
    x[470]    OBJ       6
    x[471]    c471_1    1
    x[471]    c471      1
    x[471]    OBJ       1
    x[472]    c472_1    1
    x[472]    c472      1
    x[472]    OBJ       9
    x[473]    c473_1    1
    x[473]    c473      1
    x[473]    OBJ       3
    x[474]    c474_1    1
    x[474]    c474      1
    x[474]    OBJ       2
    x[475]    c475_1    1
    x[475]    c475      1
    x[475]    OBJ       4
    x[476]    c476_1    1
    x[476]    c476      1
    x[476]    OBJ       1
    x[477]    c477_1    1
    x[477]    c477      1
    x[477]    OBJ       9
    x[478]    c478_1    1
    x[478]    c478      1
    x[478]    OBJ       2
    x[479]    c479_1    1
    x[479]    c479      1
    x[479]    OBJ       1
    x[480]    c480_1    1
    x[480]    c480      1
    x[480]    OBJ       3
    x[481]    c481_1    1
    x[481]    c481      1
    x[481]    OBJ       6
    x[482]    c482_1    1
    x[482]    c482      1
    x[482]    OBJ       1
    x[483]    c483_1    1
    x[483]    c483      1
    x[483]    OBJ       1
    x[484]    c484_1    1
    x[484]    c484      1
    x[484]    OBJ       3
    x[485]    c485_1    1
    x[485]    c485      1
    x[485]    OBJ       1
    x[486]    c486_1    1
    x[486]    c486      1
    x[486]    OBJ       3
    x[487]    c487_1    1
    x[487]    c487      1
    x[487]    OBJ       4
    x[488]    c488_1    1
    x[488]    c488      1
    x[488]    OBJ       5
    x[489]    c489_1    1
    x[489]    c489      1
    x[489]    OBJ       7
    x[490]    c490_1    1
    x[490]    c490      1
    x[490]    OBJ       5
    x[491]    c491_1    1
    x[491]    c491      1
    x[491]    OBJ       4
    x[492]    c492_1    1
    x[492]    c492      1
    x[492]    OBJ       1
    x[493]    c493_1    1
    x[493]    c493      1
    x[493]    OBJ       3
    x[494]    c494_1    1
    x[494]    c494      1
    x[494]    OBJ       3
    x[495]    c495_1    1
    x[495]    c495      1
    x[495]    OBJ       5
    x[496]    c496_1    1
    x[496]    c496      1
    x[496]    OBJ       1
    x[497]    c497_1    1
    x[497]    c497      1
    x[497]    OBJ       1
    x[498]    c498_1    1
    x[498]    c498      1
    x[498]    OBJ       4
    x[499]    c499_1    1
    x[499]    c499      1
    x[499]    OBJ       6
    x[500]    c500_1    1
    x[500]    c500      1
    x[500]    OBJ       9
    x[501]    c501_1    1
    x[501]    c501      1
    x[501]    OBJ       8
    x[502]    c502_1    1
    x[502]    c502      1
    x[502]    OBJ       1
    x[503]    c503_1    1
    x[503]    c503      1
    x[503]    OBJ       3
    x[504]    c504_1    1
    x[504]    c504      1
    x[504]    OBJ       1
    x[505]    c505_1    1
    x[505]    c505      1
    x[505]    OBJ       5
    x[506]    c506_1    1
    x[506]    c506      1
    x[506]    OBJ       4
    x[507]    c507_1    1
    x[507]    c507      1
    x[507]    OBJ       7
    x[508]    c508_1    1
    x[508]    c508      1
    x[508]    OBJ       1
    x[509]    c509_1    1
    x[509]    c509      1
    x[509]    OBJ       7
    x[510]    c510_1    1
    x[510]    c510      1
    x[510]    OBJ       8
    x[511]    c511_1    1
    x[511]    c511      1
    x[511]    OBJ       1
    x[512]    c512_1    1
    x[512]    c512      1
    x[512]    OBJ       1
    x[513]    c513_1    1
    x[513]    c513      1
    x[513]    OBJ       8
    x[514]    c514_1    1
    x[514]    c514      1
    x[514]    OBJ       6
    x[515]    c515_1    1
    x[515]    c515      1
    x[515]    OBJ       9
    x[516]    c516_1    1
    x[516]    c516      1
    x[516]    OBJ       6
    x[517]    c517_1    1
    x[517]    c517      1
    x[517]    OBJ       8
    x[518]    c518_1    1
    x[518]    c518      1
    x[518]    OBJ       1
    x[519]    c519_1    1
    x[519]    c519      1
    x[519]    OBJ       9
    x[520]    c520_1    1
    x[520]    c520      1
    x[520]    OBJ       1
    x[521]    c521_1    1
    x[521]    c521      1
    x[521]    OBJ       5
    x[522]    c522_1    1
    x[522]    c522      1
    x[522]    OBJ       8
    x[523]    c523_1    1
    x[523]    c523      1
    x[523]    OBJ       8
    x[524]    c524_1    1
    x[524]    c524      1
    x[524]    OBJ       1
    x[525]    c525_1    1
    x[525]    c525      1
    x[525]    OBJ       6
    x[526]    c526_1    1
    x[526]    c526      1
    x[526]    OBJ       7
    x[527]    c527_1    1
    x[527]    c527      1
    x[527]    OBJ       7
    x[528]    c528_1    1
    x[528]    c528      1
    x[528]    OBJ       2
    x[529]    c529_1    1
    x[529]    c529      1
    x[529]    OBJ       2
    x[530]    c530_1    1
    x[530]    c530      1
    x[530]    OBJ       6
    x[531]    c531_1    1
    x[531]    c531      1
    x[531]    OBJ       8
    x[532]    c532_1    1
    x[532]    c532      1
    x[532]    OBJ       7
    x[533]    c533_1    1
    x[533]    c533      1
    x[533]    OBJ       1
    x[534]    c534_1    1
    x[534]    c534      1
    x[534]    OBJ       2
    x[535]    c535_1    1
    x[535]    c535      1
    x[535]    OBJ       1
    x[536]    c536_1    1
    x[536]    c536      1
    x[536]    OBJ       3
    x[537]    c537_1    1
    x[537]    c537      1
    x[537]    OBJ       6
    x[538]    c538_1    1
    x[538]    c538      1
    x[538]    OBJ       4
    x[539]    c539_1    1
    x[539]    c539      1
    x[539]    OBJ       5
    x[540]    c540_1    1
    x[540]    c540      1
    x[540]    OBJ       2
    x[541]    c541_1    1
    x[541]    c541      1
    x[541]    OBJ       3
    x[542]    c542_1    1
    x[542]    c542      1
    x[542]    OBJ       7
    x[543]    c543_1    1
    x[543]    c543      1
    x[543]    OBJ       3
    x[544]    c544_1    1
    x[544]    c544      1
    x[544]    OBJ       1
    x[545]    c545_1    1
    x[545]    c545      1
    x[545]    OBJ       1
    x[546]    c546_1    1
    x[546]    c546      1
    x[546]    OBJ       6
    x[547]    c547_1    1
    x[547]    c547      1
    x[547]    OBJ       8
    x[548]    c548_1    1
    x[548]    c548      1
    x[548]    OBJ       4
    x[549]    c549_1    1
    x[549]    c549      1
    x[549]    OBJ       7
    x[550]    c550_1    1
    x[550]    c550      1
    x[550]    OBJ       1
    x[551]    c551_1    1
    x[551]    c551      1
    x[551]    OBJ       2
    x[552]    c552_1    1
    x[552]    c552      1
    x[552]    OBJ       5
    x[553]    c553_1    1
    x[553]    c553      1
    x[553]    OBJ       3
    x[554]    c554_1    1
    x[554]    c554      1
    x[554]    OBJ       9
    x[555]    c555_1    1
    x[555]    c555      1
    x[555]    OBJ       2
    x[556]    c556_1    1
    x[556]    c556      1
    x[556]    OBJ       4
    x[557]    c557_1    1
    x[557]    c557      1
    x[557]    OBJ       1
    x[558]    c558_1    1
    x[558]    c558      1
    x[558]    OBJ       4
    x[559]    c559_1    1
    x[559]    c559      1
    x[559]    OBJ       3
    x[560]    c560_1    1
    x[560]    c560      1
    x[560]    OBJ       1
    x[561]    c561_1    1
    x[561]    c561      1
    x[561]    OBJ       4
    x[562]    c562_1    1
    x[562]    c562      1
    x[562]    OBJ       1
    x[563]    c563_1    1
    x[563]    c563      1
    x[563]    OBJ       6
    x[564]    c564_1    1
    x[564]    c564      1
    x[564]    OBJ       5
    x[565]    c565_1    1
    x[565]    c565      1
    x[565]    OBJ       3
    x[566]    c566_1    1
    x[566]    c566      1
    x[566]    OBJ       1
    x[567]    c567_1    1
    x[567]    c567      1
    x[567]    OBJ       7
    x[568]    c568_1    1
    x[568]    c568      1
    x[568]    OBJ       4
    x[569]    c569_1    1
    x[569]    c569      1
    x[569]    OBJ       7
    x[570]    c570_1    1
    x[570]    c570      1
    x[570]    OBJ       4
    x[571]    c571_1    1
    x[571]    c571      1
    x[571]    OBJ       3
    x[572]    c572_1    1
    x[572]    c572      1
    x[572]    OBJ       9
    x[573]    c573_1    1
    x[573]    c573      1
    x[573]    OBJ       5
    x[574]    c574_1    1
    x[574]    c574      1
    x[574]    OBJ       1
    x[575]    c575_1    1
    x[575]    c575      1
    x[575]    OBJ       2
    x[576]    c576_1    1
    x[576]    c576      1
    x[576]    OBJ       4
    x[577]    c577_1    1
    x[577]    c577      1
    x[577]    OBJ       1
    x[578]    c578_1    1
    x[578]    c578      1
    x[578]    OBJ       7
    x[579]    c579_1    1
    x[579]    c579      1
    x[579]    OBJ       3
    x[580]    c580_1    1
    x[580]    c580      1
    x[580]    OBJ       3
    x[581]    c581_1    1
    x[581]    c581      1
    x[581]    OBJ       2
    x[582]    c582_1    1
    x[582]    c582      1
    x[582]    OBJ       8
    x[583]    c583_1    1
    x[583]    c583      1
    x[583]    OBJ       9
    x[584]    c584_1    1
    x[584]    c584      1
    x[584]    OBJ       3
    x[585]    c585_1    1
    x[585]    c585      1
    x[585]    OBJ       8
    x[586]    c586_1    1
    x[586]    c586      1
    x[586]    OBJ       5
    x[587]    c587_1    1
    x[587]    c587      1
    x[587]    OBJ       4
    x[588]    c588_1    1
    x[588]    c588      1
    x[588]    OBJ       2
    x[589]    c589_1    1
    x[589]    c589      1
    x[589]    OBJ       8
    x[590]    c590_1    1
    x[590]    c590      1
    x[590]    OBJ       8
    x[591]    c591_1    1
    x[591]    c591      1
    x[591]    OBJ       1
    x[592]    c592_1    1
    x[592]    c592      1
    x[592]    OBJ       8
    x[593]    c593_1    1
    x[593]    c593      1
    x[593]    OBJ       5
    x[594]    c594_1    1
    x[594]    c594      1
    x[594]    OBJ       1
    x[595]    c595_1    1
    x[595]    c595      1
    x[595]    OBJ       6
    x[596]    c596_1    1
    x[596]    c596      1
    x[596]    OBJ       7
    x[597]    c597_1    1
    x[597]    c597      1
    x[597]    OBJ       6
    x[598]    c598_1    1
    x[598]    c598      1
    x[598]    OBJ       9
    x[599]    c599_1    1
    x[599]    c599      1
    x[599]    OBJ       6
    x[600]    c600_1    1
    x[600]    c600      1
    x[600]    OBJ       4
    x[601]    c601_1    1
    x[601]    c1        1
    x[601]    c2        -1
    x[601]    OBJ       1
    x[602]    c602_1    1
    x[602]    c2        1
    x[602]    c3        -1
    x[602]    OBJ       1
    x[603]    c603_1    1
    x[603]    c3        1
    x[603]    c4        -1
    x[603]    OBJ       1
    x[604]    c604_1    1
    x[604]    c4        1
    x[604]    c5        -1
    x[604]    OBJ       1
    x[605]    c605_1    1
    x[605]    c5        1
    x[605]    c6        -1
    x[605]    OBJ       1
    x[606]    c606_1    1
    x[606]    c6        1
    x[606]    c7        -1
    x[606]    OBJ       1
    x[607]    c607_1    1
    x[607]    c7        1
    x[607]    c8        -1
    x[607]    OBJ       1
    x[608]    c608_1    1
    x[608]    c8        1
    x[608]    c9        -1
    x[608]    OBJ       1
    x[609]    c609_1    1
    x[609]    c9        1
    x[609]    c10       -1
    x[609]    OBJ       1
    x[610]    c610_1    1
    x[610]    c10       1
    x[610]    c11       -1
    x[610]    OBJ       1
    x[611]    c611_1    1
    x[611]    c11       1
    x[611]    c12       -1
    x[611]    OBJ       1
    x[612]    c612_1    1
    x[612]    c12       1
    x[612]    c13       -1
    x[612]    OBJ       1
    x[613]    c613_1    1
    x[613]    c13       1
    x[613]    c14       -1
    x[613]    OBJ       1
    x[614]    c614_1    1
    x[614]    c14       1
    x[614]    c15       -1
    x[614]    OBJ       1
    x[615]    c615_1    1
    x[615]    c15       1
    x[615]    c16       -1
    x[615]    OBJ       1
    x[616]    c616_1    1
    x[616]    c16       1
    x[616]    c17       -1
    x[616]    OBJ       1
    x[617]    c617_1    1
    x[617]    c17       1
    x[617]    c18       -1
    x[617]    OBJ       1
    x[618]    c618_1    1
    x[618]    c18       1
    x[618]    c19       -1
    x[618]    OBJ       1
    x[619]    c619_1    1
    x[619]    c19       1
    x[619]    c20       -1
    x[619]    OBJ       1
    x[620]    c620_1    1
    x[620]    c20       1
    x[620]    c21       -1
    x[620]    OBJ       1
    x[621]    c621_1    1
    x[621]    c21       1
    x[621]    c22       -1
    x[621]    OBJ       1
    x[622]    c622_1    1
    x[622]    c22       1
    x[622]    c23       -1
    x[622]    OBJ       1
    x[623]    c623_1    1
    x[623]    c23       1
    x[623]    c24       -1
    x[623]    OBJ       1
    x[624]    c624_1    1
    x[624]    c24       1
    x[624]    c25       -1
    x[624]    OBJ       1
    x[625]    c625      1
    x[625]    c25       1
    x[625]    c26       -1
    x[625]    OBJ       1
    x[626]    c626      1
    x[626]    c26       1
    x[626]    c27       -1
    x[626]    OBJ       1
    x[627]    c627      1
    x[627]    c27       1
    x[627]    c28       -1
    x[627]    OBJ       1
    x[628]    c628      1
    x[628]    c28       1
    x[628]    c29       -1
    x[628]    OBJ       1
    x[629]    c629      1
    x[629]    c29       1
    x[629]    c30       -1
    x[629]    OBJ       1
    x[630]    c630      1
    x[630]    c30       1
    x[630]    c31       -1
    x[630]    OBJ       1
    x[631]    c631      1
    x[631]    c31       1
    x[631]    c32       -1
    x[631]    OBJ       1
    x[632]    c632      1
    x[632]    c32       1
    x[632]    c33       -1
    x[632]    OBJ       1
    x[633]    c633      1
    x[633]    c33       1
    x[633]    c34       -1
    x[633]    OBJ       1
    x[634]    c634      1
    x[634]    c34       1
    x[634]    c35       -1
    x[634]    OBJ       1
    x[635]    c635      1
    x[635]    c35       1
    x[635]    c36       -1
    x[635]    OBJ       1
    x[636]    c636      1
    x[636]    c36       1
    x[636]    c37       -1
    x[636]    OBJ       1
    x[637]    c637      1
    x[637]    c37       1
    x[637]    c38       -1
    x[637]    OBJ       1
    x[638]    c638      1
    x[638]    c38       1
    x[638]    c39       -1
    x[638]    OBJ       1
    x[639]    c639      1
    x[639]    c39       1
    x[639]    c40       -1
    x[639]    OBJ       1
    x[640]    c640      1
    x[640]    c40       1
    x[640]    c41       -1
    x[640]    OBJ       1
    x[641]    c641      1
    x[641]    c41       1
    x[641]    c42       -1
    x[641]    OBJ       1
    x[642]    c642      1
    x[642]    c42       1
    x[642]    c43       -1
    x[642]    OBJ       1
    x[643]    c643      1
    x[643]    c43       1
    x[643]    c44       -1
    x[643]    OBJ       1
    x[644]    c644      1
    x[644]    c44       1
    x[644]    c45       -1
    x[644]    OBJ       1
    x[645]    c645      1
    x[645]    c45       1
    x[645]    c46       -1
    x[645]    OBJ       1
    x[646]    c646      1
    x[646]    c46       1
    x[646]    c47       -1
    x[646]    OBJ       1
    x[647]    c647      1
    x[647]    c47       1
    x[647]    c48       -1
    x[647]    OBJ       1
    x[648]    c648      1
    x[648]    c48       1
    x[648]    c49       -1
    x[648]    OBJ       1
    x[649]    c649      1
    x[649]    c49       1
    x[649]    c50       -1
    x[649]    OBJ       1
    x[650]    c650      1
    x[650]    c50       1
    x[650]    c51       -1
    x[650]    OBJ       1
    x[651]    c651      1
    x[651]    c51       1
    x[651]    c52       -1
    x[651]    OBJ       1
    x[652]    c652      1
    x[652]    c52       1
    x[652]    c53       -1
    x[652]    OBJ       1
    x[653]    c653      1
    x[653]    c53       1
    x[653]    c54       -1
    x[653]    OBJ       1
    x[654]    c654      1
    x[654]    c54       1
    x[654]    c55       -1
    x[654]    OBJ       1
    x[655]    c655      1
    x[655]    c55       1
    x[655]    c56       -1
    x[655]    OBJ       1
    x[656]    c656      1
    x[656]    c56       1
    x[656]    c57       -1
    x[656]    OBJ       1
    x[657]    c657      1
    x[657]    c57       1
    x[657]    c58       -1
    x[657]    OBJ       1
    x[658]    c658      1
    x[658]    c58       1
    x[658]    c59       -1
    x[658]    OBJ       1
    x[659]    c659      1
    x[659]    c59       1
    x[659]    c60       -1
    x[659]    OBJ       1
    x[660]    c660      1
    x[660]    c60       1
    x[660]    c61       -1
    x[660]    OBJ       1
    x[661]    c661      1
    x[661]    c61       1
    x[661]    c62       -1
    x[661]    OBJ       1
    x[662]    c662      1
    x[662]    c62       1
    x[662]    c63       -1
    x[662]    OBJ       1
    x[663]    c663      1
    x[663]    c63       1
    x[663]    c64       -1
    x[663]    OBJ       1
    x[664]    c664      1
    x[664]    c64       1
    x[664]    c65       -1
    x[664]    OBJ       1
    x[665]    c665      1
    x[665]    c65       1
    x[665]    c66       -1
    x[665]    OBJ       1
    x[666]    c666      1
    x[666]    c66       1
    x[666]    c67       -1
    x[666]    OBJ       1
    x[667]    c667      1
    x[667]    c67       1
    x[667]    c68       -1
    x[667]    OBJ       1
    x[668]    c668      1
    x[668]    c68       1
    x[668]    c69       -1
    x[668]    OBJ       1
    x[669]    c669      1
    x[669]    c69       1
    x[669]    c70       -1
    x[669]    OBJ       1
    x[670]    c670      1
    x[670]    c70       1
    x[670]    c71       -1
    x[670]    OBJ       1
    x[671]    c671      1
    x[671]    c71       1
    x[671]    c72       -1
    x[671]    OBJ       1
    x[672]    c672      1
    x[672]    c72       1
    x[672]    c73       -1
    x[672]    OBJ       1
    x[673]    c673      1
    x[673]    c73       1
    x[673]    c74       -1
    x[673]    OBJ       1
    x[674]    c674      1
    x[674]    c74       1
    x[674]    c75       -1
    x[674]    OBJ       1
    x[675]    c675      1
    x[675]    c75       1
    x[675]    c76       -1
    x[675]    OBJ       1
    x[676]    c676      1
    x[676]    c76       1
    x[676]    c77       -1
    x[676]    OBJ       1
    x[677]    c677      1
    x[677]    c77       1
    x[677]    c78       -1
    x[677]    OBJ       1
    x[678]    c678      1
    x[678]    c78       1
    x[678]    c79       -1
    x[678]    OBJ       1
    x[679]    c679      1
    x[679]    c79       1
    x[679]    c80       -1
    x[679]    OBJ       1
    x[680]    c680      1
    x[680]    c80       1
    x[680]    c81       -1
    x[680]    OBJ       1
    x[681]    c681      1
    x[681]    c81       1
    x[681]    c82       -1
    x[681]    OBJ       1
    x[682]    c682      1
    x[682]    c82       1
    x[682]    c83       -1
    x[682]    OBJ       1
    x[683]    c683      1
    x[683]    c83       1
    x[683]    c84       -1
    x[683]    OBJ       1
    x[684]    c684      1
    x[684]    c84       1
    x[684]    c85       -1
    x[684]    OBJ       1
    x[685]    c685      1
    x[685]    c85       1
    x[685]    c86       -1
    x[685]    OBJ       1
    x[686]    c686      1
    x[686]    c86       1
    x[686]    c87       -1
    x[686]    OBJ       1
    x[687]    c687      1
    x[687]    c87       1
    x[687]    c88       -1
    x[687]    OBJ       1
    x[688]    c688      1
    x[688]    c88       1
    x[688]    c89       -1
    x[688]    OBJ       1
    x[689]    c689      1
    x[689]    c89       1
    x[689]    c90       -1
    x[689]    OBJ       1
    x[690]    c690      1
    x[690]    c90       1
    x[690]    c91       -1
    x[690]    OBJ       1
    x[691]    c691      1
    x[691]    c91       1
    x[691]    c92       -1
    x[691]    OBJ       1
    x[692]    c692      1
    x[692]    c92       1
    x[692]    c93       -1
    x[692]    OBJ       1
    x[693]    c693      1
    x[693]    c93       1
    x[693]    c94       -1
    x[693]    OBJ       1
    x[694]    c694      1
    x[694]    c94       1
    x[694]    c95       -1
    x[694]    OBJ       1
    x[695]    c695      1
    x[695]    c95       1
    x[695]    c96       -1
    x[695]    OBJ       1
    x[696]    c696      1
    x[696]    c96       1
    x[696]    c97       -1
    x[696]    OBJ       1
    x[697]    c697      1
    x[697]    c97       1
    x[697]    c98       -1
    x[697]    OBJ       1
    x[698]    c698      1
    x[698]    c98       1
    x[698]    c99       -1
    x[698]    OBJ       1
    x[699]    c699      1
    x[699]    c99       1
    x[699]    c100      -1
    x[699]    OBJ       1
    x[700]    c700      1
    x[700]    c100      1
    x[700]    c101      -1
    x[700]    OBJ       1
    x[701]    c701      1
    x[701]    c101      1
    x[701]    c102      -1
    x[701]    OBJ       1
    x[702]    c702      1
    x[702]    c102      1
    x[702]    c103      -1
    x[702]    OBJ       1
    x[703]    c703      1
    x[703]    c103      1
    x[703]    c104      -1
    x[703]    OBJ       1
    x[704]    c704      1
    x[704]    c104      1
    x[704]    c105      -1
    x[704]    OBJ       1
    x[705]    c705      1
    x[705]    c105      1
    x[705]    c106      -1
    x[705]    OBJ       1
    x[706]    c706      1
    x[706]    c106      1
    x[706]    c107      -1
    x[706]    OBJ       1
    x[707]    c707      1
    x[707]    c107      1
    x[707]    c108      -1
    x[707]    OBJ       1
    x[708]    c708      1
    x[708]    c108      1
    x[708]    c109      -1
    x[708]    OBJ       1
    x[709]    c709      1
    x[709]    c109      1
    x[709]    c110      -1
    x[709]    OBJ       1
    x[710]    c710      1
    x[710]    c110      1
    x[710]    c111      -1
    x[710]    OBJ       1
    x[711]    c711      1
    x[711]    c111      1
    x[711]    c112      -1
    x[711]    OBJ       1
    x[712]    c712      1
    x[712]    c112      1
    x[712]    c113      -1
    x[712]    OBJ       1
    x[713]    c713      1
    x[713]    c113      1
    x[713]    c114      -1
    x[713]    OBJ       1
    x[714]    c714      1
    x[714]    c114      1
    x[714]    c115      -1
    x[714]    OBJ       1
    x[715]    c715      1
    x[715]    c115      1
    x[715]    c116      -1
    x[715]    OBJ       1
    x[716]    c716      1
    x[716]    c116      1
    x[716]    c117      -1
    x[716]    OBJ       1
    x[717]    c717      1
    x[717]    c117      1
    x[717]    c118      -1
    x[717]    OBJ       1
    x[718]    c718      1
    x[718]    c118      1
    x[718]    c119      -1
    x[718]    OBJ       1
    x[719]    c719      1
    x[719]    c119      1
    x[719]    c120      -1
    x[719]    OBJ       1
    x[720]    c720      1
    x[720]    c121      1
    x[720]    c122      -1
    x[720]    OBJ       1
    x[721]    c721      1
    x[721]    c122      1
    x[721]    c123      -1
    x[721]    OBJ       1
    x[722]    c722      1
    x[722]    c123      1
    x[722]    c124      -1
    x[722]    OBJ       1
    x[723]    c723      1
    x[723]    c124      1
    x[723]    c125      -1
    x[723]    OBJ       1
    x[724]    c724      1
    x[724]    c125      1
    x[724]    c126      -1
    x[724]    OBJ       1
    x[725]    c725      1
    x[725]    c126      1
    x[725]    c127      -1
    x[725]    OBJ       1
    x[726]    c726      1
    x[726]    c127      1
    x[726]    c128      -1
    x[726]    OBJ       1
    x[727]    c727      1
    x[727]    c128      1
    x[727]    c129      -1
    x[727]    OBJ       1
    x[728]    c728      1
    x[728]    c129      1
    x[728]    c130      -1
    x[728]    OBJ       1
    x[729]    c729      1
    x[729]    c130      1
    x[729]    c131      -1
    x[729]    OBJ       1
    x[730]    c730      1
    x[730]    c131      1
    x[730]    c132      -1
    x[730]    OBJ       1
    x[731]    c731      1
    x[731]    c132      1
    x[731]    c133      -1
    x[731]    OBJ       1
    x[732]    c732      1
    x[732]    c133      1
    x[732]    c134      -1
    x[732]    OBJ       1
    x[733]    c733      1
    x[733]    c134      1
    x[733]    c135      -1
    x[733]    OBJ       1
    x[734]    c734      1
    x[734]    c135      1
    x[734]    c136      -1
    x[734]    OBJ       1
    x[735]    c735      1
    x[735]    c136      1
    x[735]    c137      -1
    x[735]    OBJ       1
    x[736]    c736      1
    x[736]    c137      1
    x[736]    c138      -1
    x[736]    OBJ       1
    x[737]    c737      1
    x[737]    c138      1
    x[737]    c139      -1
    x[737]    OBJ       1
    x[738]    c738      1
    x[738]    c139      1
    x[738]    c140      -1
    x[738]    OBJ       1
    x[739]    c739      1
    x[739]    c140      1
    x[739]    c141      -1
    x[739]    OBJ       1
    x[740]    c740      1
    x[740]    c141      1
    x[740]    c142      -1
    x[740]    OBJ       1
    x[741]    c741      1
    x[741]    c142      1
    x[741]    c143      -1
    x[741]    OBJ       1
    x[742]    c742      1
    x[742]    c143      1
    x[742]    c144      -1
    x[742]    OBJ       1
    x[743]    c743      1
    x[743]    c144      1
    x[743]    c145      -1
    x[743]    OBJ       1
    x[744]    c744      1
    x[744]    c145      1
    x[744]    c146      -1
    x[744]    OBJ       1
    x[745]    c745      1
    x[745]    c146      1
    x[745]    c147      -1
    x[745]    OBJ       1
    x[746]    c746      1
    x[746]    c147      1
    x[746]    c148      -1
    x[746]    OBJ       1
    x[747]    c747      1
    x[747]    c148      1
    x[747]    c149      -1
    x[747]    OBJ       1
    x[748]    c748      1
    x[748]    c149      1
    x[748]    c150      -1
    x[748]    OBJ       1
    x[749]    c749      1
    x[749]    c150      1
    x[749]    c151      -1
    x[749]    OBJ       1
    x[750]    c750      1
    x[750]    c151      1
    x[750]    c152      -1
    x[750]    OBJ       1
    x[751]    c751      1
    x[751]    c152      1
    x[751]    c153      -1
    x[751]    OBJ       1
    x[752]    c752      1
    x[752]    c153      1
    x[752]    c154      -1
    x[752]    OBJ       1
    x[753]    c753      1
    x[753]    c154      1
    x[753]    c155      -1
    x[753]    OBJ       1
    x[754]    c754      1
    x[754]    c155      1
    x[754]    c156      -1
    x[754]    OBJ       1
    x[755]    c755      1
    x[755]    c156      1
    x[755]    c157      -1
    x[755]    OBJ       1
    x[756]    c756      1
    x[756]    c157      1
    x[756]    c158      -1
    x[756]    OBJ       1
    x[757]    c757      1
    x[757]    c158      1
    x[757]    c159      -1
    x[757]    OBJ       1
    x[758]    c758      1
    x[758]    c159      1
    x[758]    c160      -1
    x[758]    OBJ       1
    x[759]    c759      1
    x[759]    c160      1
    x[759]    c161      -1
    x[759]    OBJ       1
    x[760]    c760      1
    x[760]    c161      1
    x[760]    c162      -1
    x[760]    OBJ       1
    x[761]    c761      1
    x[761]    c162      1
    x[761]    c163      -1
    x[761]    OBJ       1
    x[762]    c762      1
    x[762]    c163      1
    x[762]    c164      -1
    x[762]    OBJ       1
    x[763]    c763      1
    x[763]    c164      1
    x[763]    c165      -1
    x[763]    OBJ       1
    x[764]    c764      1
    x[764]    c165      1
    x[764]    c166      -1
    x[764]    OBJ       1
    x[765]    c765      1
    x[765]    c166      1
    x[765]    c167      -1
    x[765]    OBJ       1
    x[766]    c766      1
    x[766]    c167      1
    x[766]    c168      -1
    x[766]    OBJ       1
    x[767]    c767      1
    x[767]    c168      1
    x[767]    c169      -1
    x[767]    OBJ       1
    x[768]    c768      1
    x[768]    c169      1
    x[768]    c170      -1
    x[768]    OBJ       1
    x[769]    c769      1
    x[769]    c170      1
    x[769]    c171      -1
    x[769]    OBJ       1
    x[770]    c770      1
    x[770]    c171      1
    x[770]    c172      -1
    x[770]    OBJ       1
    x[771]    c771      1
    x[771]    c172      1
    x[771]    c173      -1
    x[771]    OBJ       1
    x[772]    c772      1
    x[772]    c173      1
    x[772]    c174      -1
    x[772]    OBJ       1
    x[773]    c773      1
    x[773]    c174      1
    x[773]    c175      -1
    x[773]    OBJ       1
    x[774]    c774      1
    x[774]    c175      1
    x[774]    c176      -1
    x[774]    OBJ       1
    x[775]    c775      1
    x[775]    c176      1
    x[775]    c177      -1
    x[775]    OBJ       1
    x[776]    c776      1
    x[776]    c177      1
    x[776]    c178      -1
    x[776]    OBJ       1
    x[777]    c777      1
    x[777]    c178      1
    x[777]    c179      -1
    x[777]    OBJ       1
    x[778]    c778      1
    x[778]    c179      1
    x[778]    c180      -1
    x[778]    OBJ       1
    x[779]    c779      1
    x[779]    c180      1
    x[779]    c181      -1
    x[779]    OBJ       1
    x[780]    c780      1
    x[780]    c181      1
    x[780]    c182      -1
    x[780]    OBJ       1
    x[781]    c781      1
    x[781]    c182      1
    x[781]    c183      -1
    x[781]    OBJ       1
    x[782]    c782      1
    x[782]    c183      1
    x[782]    c184      -1
    x[782]    OBJ       1
    x[783]    c783      1
    x[783]    c184      1
    x[783]    c185      -1
    x[783]    OBJ       1
    x[784]    c784      1
    x[784]    c185      1
    x[784]    c186      -1
    x[784]    OBJ       1
    x[785]    c785      1
    x[785]    c186      1
    x[785]    c187      -1
    x[785]    OBJ       1
    x[786]    c786      1
    x[786]    c187      1
    x[786]    c188      -1
    x[786]    OBJ       1
    x[787]    c787      1
    x[787]    c188      1
    x[787]    c189      -1
    x[787]    OBJ       1
    x[788]    c788      1
    x[788]    c189      1
    x[788]    c190      -1
    x[788]    OBJ       1
    x[789]    c789      1
    x[789]    c190      1
    x[789]    c191      -1
    x[789]    OBJ       1
    x[790]    c790      1
    x[790]    c191      1
    x[790]    c192      -1
    x[790]    OBJ       1
    x[791]    c791      1
    x[791]    c192      1
    x[791]    c193      -1
    x[791]    OBJ       1
    x[792]    c792      1
    x[792]    c193      1
    x[792]    c194      -1
    x[792]    OBJ       1
    x[793]    c793      1
    x[793]    c194      1
    x[793]    c195      -1
    x[793]    OBJ       1
    x[794]    c794      1
    x[794]    c195      1
    x[794]    c196      -1
    x[794]    OBJ       1
    x[795]    c795      1
    x[795]    c196      1
    x[795]    c197      -1
    x[795]    OBJ       1
    x[796]    c796      1
    x[796]    c197      1
    x[796]    c198      -1
    x[796]    OBJ       1
    x[797]    c797      1
    x[797]    c198      1
    x[797]    c199      -1
    x[797]    OBJ       1
    x[798]    c798      1
    x[798]    c199      1
    x[798]    c200      -1
    x[798]    OBJ       1
    x[799]    c799      1
    x[799]    c200      1
    x[799]    c201      -1
    x[799]    OBJ       1
    x[800]    c800      1
    x[800]    c201      1
    x[800]    c202      -1
    x[800]    OBJ       1
    x[801]    c801      1
    x[801]    c202      1
    x[801]    c203      -1
    x[801]    OBJ       1
    x[802]    c802      1
    x[802]    c203      1
    x[802]    c204      -1
    x[802]    OBJ       1
    x[803]    c803      1
    x[803]    c204      1
    x[803]    c205      -1
    x[803]    OBJ       1
    x[804]    c804      1
    x[804]    c205      1
    x[804]    c206      -1
    x[804]    OBJ       1
    x[805]    c805      1
    x[805]    c206      1
    x[805]    c207      -1
    x[805]    OBJ       1
    x[806]    c806      1
    x[806]    c207      1
    x[806]    c208      -1
    x[806]    OBJ       1
    x[807]    c807      1
    x[807]    c208      1
    x[807]    c209      -1
    x[807]    OBJ       1
    x[808]    c808      1
    x[808]    c209      1
    x[808]    c210      -1
    x[808]    OBJ       1
    x[809]    c809      1
    x[809]    c210      1
    x[809]    c211      -1
    x[809]    OBJ       1
    x[810]    c810      1
    x[810]    c211      1
    x[810]    c212      -1
    x[810]    OBJ       1
    x[811]    c811      1
    x[811]    c212      1
    x[811]    c213      -1
    x[811]    OBJ       1
    x[812]    c812      1
    x[812]    c213      1
    x[812]    c214      -1
    x[812]    OBJ       1
    x[813]    c813      1
    x[813]    c214      1
    x[813]    c215      -1
    x[813]    OBJ       1
    x[814]    c814      1
    x[814]    c215      1
    x[814]    c216      -1
    x[814]    OBJ       1
    x[815]    c815      1
    x[815]    c216      1
    x[815]    c217      -1
    x[815]    OBJ       1
    x[816]    c816      1
    x[816]    c217      1
    x[816]    c218      -1
    x[816]    OBJ       1
    x[817]    c817      1
    x[817]    c218      1
    x[817]    c219      -1
    x[817]    OBJ       1
    x[818]    c818      1
    x[818]    c219      1
    x[818]    c220      -1
    x[818]    OBJ       1
    x[819]    c819      1
    x[819]    c220      1
    x[819]    c221      -1
    x[819]    OBJ       1
    x[820]    c820      1
    x[820]    c221      1
    x[820]    c222      -1
    x[820]    OBJ       1
    x[821]    c821      1
    x[821]    c222      1
    x[821]    c223      -1
    x[821]    OBJ       1
    x[822]    c822      1
    x[822]    c223      1
    x[822]    c224      -1
    x[822]    OBJ       1
    x[823]    c823      1
    x[823]    c224      1
    x[823]    c225      -1
    x[823]    OBJ       1
    x[824]    c824      1
    x[824]    c225      1
    x[824]    c226      -1
    x[824]    OBJ       1
    x[825]    c825      1
    x[825]    c226      1
    x[825]    c227      -1
    x[825]    OBJ       1
    x[826]    c826      1
    x[826]    c227      1
    x[826]    c228      -1
    x[826]    OBJ       1
    x[827]    c827      1
    x[827]    c228      1
    x[827]    c229      -1
    x[827]    OBJ       1
    x[828]    c828      1
    x[828]    c229      1
    x[828]    c230      -1
    x[828]    OBJ       1
    x[829]    c829      1
    x[829]    c230      1
    x[829]    c231      -1
    x[829]    OBJ       1
    x[830]    c830      1
    x[830]    c231      1
    x[830]    c232      -1
    x[830]    OBJ       1
    x[831]    c831      1
    x[831]    c232      1
    x[831]    c233      -1
    x[831]    OBJ       1
    x[832]    c832      1
    x[832]    c233      1
    x[832]    c234      -1
    x[832]    OBJ       1
    x[833]    c833      1
    x[833]    c234      1
    x[833]    c235      -1
    x[833]    OBJ       1
    x[834]    c834      1
    x[834]    c235      1
    x[834]    c236      -1
    x[834]    OBJ       1
    x[835]    c835      1
    x[835]    c236      1
    x[835]    c237      -1
    x[835]    OBJ       1
    x[836]    c836      1
    x[836]    c237      1
    x[836]    c238      -1
    x[836]    OBJ       1
    x[837]    c837      1
    x[837]    c238      1
    x[837]    c239      -1
    x[837]    OBJ       1
    x[838]    c838      1
    x[838]    c239      1
    x[838]    c240      -1
    x[838]    OBJ       1
    x[839]    c839      1
    x[839]    c241      1
    x[839]    c242      -1
    x[839]    OBJ       1
    x[840]    c840      1
    x[840]    c242      1
    x[840]    c243      -1
    x[840]    OBJ       1
    x[841]    c841      1
    x[841]    c243      1
    x[841]    c244      -1
    x[841]    OBJ       1
    x[842]    c842      1
    x[842]    c244      1
    x[842]    c245      -1
    x[842]    OBJ       1
    x[843]    c843      1
    x[843]    c245      1
    x[843]    c246      -1
    x[843]    OBJ       1
    x[844]    c844      1
    x[844]    c246      1
    x[844]    c247      -1
    x[844]    OBJ       1
    x[845]    c845      1
    x[845]    c247      1
    x[845]    c248      -1
    x[845]    OBJ       1
    x[846]    c846      1
    x[846]    c248      1
    x[846]    c249      -1
    x[846]    OBJ       1
    x[847]    c847      1
    x[847]    c249      1
    x[847]    c250      -1
    x[847]    OBJ       1
    x[848]    c848      1
    x[848]    c250      1
    x[848]    c251      -1
    x[848]    OBJ       1
    x[849]    c849      1
    x[849]    c251      1
    x[849]    c252      -1
    x[849]    OBJ       1
    x[850]    c850      1
    x[850]    c252      1
    x[850]    c253      -1
    x[850]    OBJ       1
    x[851]    c851      1
    x[851]    c253      1
    x[851]    c254      -1
    x[851]    OBJ       1
    x[852]    c852      1
    x[852]    c254      1
    x[852]    c255      -1
    x[852]    OBJ       1
    x[853]    c853      1
    x[853]    c255      1
    x[853]    c256      -1
    x[853]    OBJ       1
    x[854]    c854      1
    x[854]    c256      1
    x[854]    c257      -1
    x[854]    OBJ       1
    x[855]    c855      1
    x[855]    c257      1
    x[855]    c258      -1
    x[855]    OBJ       1
    x[856]    c856      1
    x[856]    c258      1
    x[856]    c259      -1
    x[856]    OBJ       1
    x[857]    c857      1
    x[857]    c259      1
    x[857]    c260      -1
    x[857]    OBJ       1
    x[858]    c858      1
    x[858]    c260      1
    x[858]    c261      -1
    x[858]    OBJ       1
    x[859]    c859      1
    x[859]    c261      1
    x[859]    c262      -1
    x[859]    OBJ       1
    x[860]    c860      1
    x[860]    c262      1
    x[860]    c263      -1
    x[860]    OBJ       1
    x[861]    c861      1
    x[861]    c263      1
    x[861]    c264      -1
    x[861]    OBJ       1
    x[862]    c862      1
    x[862]    c264      1
    x[862]    c265      -1
    x[862]    OBJ       1
    x[863]    c863      1
    x[863]    c265      1
    x[863]    c266      -1
    x[863]    OBJ       1
    x[864]    c864      1
    x[864]    c266      1
    x[864]    c267      -1
    x[864]    OBJ       1
    x[865]    c865      1
    x[865]    c267      1
    x[865]    c268      -1
    x[865]    OBJ       1
    x[866]    c866      1
    x[866]    c268      1
    x[866]    c269      -1
    x[866]    OBJ       1
    x[867]    c867      1
    x[867]    c269      1
    x[867]    c270      -1
    x[867]    OBJ       1
    x[868]    c868      1
    x[868]    c270      1
    x[868]    c271      -1
    x[868]    OBJ       1
    x[869]    c869      1
    x[869]    c271      1
    x[869]    c272      -1
    x[869]    OBJ       1
    x[870]    c870      1
    x[870]    c272      1
    x[870]    c273      -1
    x[870]    OBJ       1
    x[871]    c871      1
    x[871]    c273      1
    x[871]    c274      -1
    x[871]    OBJ       1
    x[872]    c872      1
    x[872]    c274      1
    x[872]    c275      -1
    x[872]    OBJ       1
    x[873]    c873      1
    x[873]    c275      1
    x[873]    c276      -1
    x[873]    OBJ       1
    x[874]    c874      1
    x[874]    c276      1
    x[874]    c277      -1
    x[874]    OBJ       1
    x[875]    c875      1
    x[875]    c277      1
    x[875]    c278      -1
    x[875]    OBJ       1
    x[876]    c876      1
    x[876]    c278      1
    x[876]    c279      -1
    x[876]    OBJ       1
    x[877]    c877      1
    x[877]    c279      1
    x[877]    c280      -1
    x[877]    OBJ       1
    x[878]    c878      1
    x[878]    c280      1
    x[878]    c281      -1
    x[878]    OBJ       1
    x[879]    c879      1
    x[879]    c281      1
    x[879]    c282      -1
    x[879]    OBJ       1
    x[880]    c880      1
    x[880]    c282      1
    x[880]    c283      -1
    x[880]    OBJ       1
    x[881]    c881      1
    x[881]    c283      1
    x[881]    c284      -1
    x[881]    OBJ       1
    x[882]    c882      1
    x[882]    c284      1
    x[882]    c285      -1
    x[882]    OBJ       1
    x[883]    c883      1
    x[883]    c285      1
    x[883]    c286      -1
    x[883]    OBJ       1
    x[884]    c884      1
    x[884]    c286      1
    x[884]    c287      -1
    x[884]    OBJ       1
    x[885]    c885      1
    x[885]    c287      1
    x[885]    c288      -1
    x[885]    OBJ       1
    x[886]    c886      1
    x[886]    c288      1
    x[886]    c289      -1
    x[886]    OBJ       1
    x[887]    c887      1
    x[887]    c289      1
    x[887]    c290      -1
    x[887]    OBJ       1
    x[888]    c888      1
    x[888]    c290      1
    x[888]    c291      -1
    x[888]    OBJ       1
    x[889]    c889      1
    x[889]    c291      1
    x[889]    c292      -1
    x[889]    OBJ       1
    x[890]    c890      1
    x[890]    c292      1
    x[890]    c293      -1
    x[890]    OBJ       1
    x[891]    c891      1
    x[891]    c293      1
    x[891]    c294      -1
    x[891]    OBJ       1
    x[892]    c892      1
    x[892]    c294      1
    x[892]    c295      -1
    x[892]    OBJ       1
    x[893]    c893      1
    x[893]    c295      1
    x[893]    c296      -1
    x[893]    OBJ       1
    x[894]    c894      1
    x[894]    c296      1
    x[894]    c297      -1
    x[894]    OBJ       1
    x[895]    c895      1
    x[895]    c297      1
    x[895]    c298      -1
    x[895]    OBJ       1
    x[896]    c896      1
    x[896]    c298      1
    x[896]    c299      -1
    x[896]    OBJ       1
    x[897]    c897      1
    x[897]    c299      1
    x[897]    c300      -1
    x[897]    OBJ       1
    x[898]    c898      1
    x[898]    c300      1
    x[898]    c301      -1
    x[898]    OBJ       1
    x[899]    c899      1
    x[899]    c301      1
    x[899]    c302      -1
    x[899]    OBJ       1
    x[900]    c900      1
    x[900]    c302      1
    x[900]    c303      -1
    x[900]    OBJ       1
    x[901]    c901      1
    x[901]    c303      1
    x[901]    c304      -1
    x[901]    OBJ       1
    x[902]    c902      1
    x[902]    c304      1
    x[902]    c305      -1
    x[902]    OBJ       1
    x[903]    c903      1
    x[903]    c305      1
    x[903]    c306      -1
    x[903]    OBJ       1
    x[904]    c904      1
    x[904]    c306      1
    x[904]    c307      -1
    x[904]    OBJ       1
    x[905]    c905      1
    x[905]    c307      1
    x[905]    c308      -1
    x[905]    OBJ       1
    x[906]    c906      1
    x[906]    c308      1
    x[906]    c309      -1
    x[906]    OBJ       1
    x[907]    c907      1
    x[907]    c309      1
    x[907]    c310      -1
    x[907]    OBJ       1
    x[908]    c908      1
    x[908]    c310      1
    x[908]    c311      -1
    x[908]    OBJ       1
    x[909]    c909      1
    x[909]    c311      1
    x[909]    c312      -1
    x[909]    OBJ       1
    x[910]    c910      1
    x[910]    c312      1
    x[910]    c313      -1
    x[910]    OBJ       1
    x[911]    c911      1
    x[911]    c313      1
    x[911]    c314      -1
    x[911]    OBJ       1
    x[912]    c912      1
    x[912]    c314      1
    x[912]    c315      -1
    x[912]    OBJ       1
    x[913]    c913      1
    x[913]    c315      1
    x[913]    c316      -1
    x[913]    OBJ       1
    x[914]    c914      1
    x[914]    c316      1
    x[914]    c317      -1
    x[914]    OBJ       1
    x[915]    c915      1
    x[915]    c317      1
    x[915]    c318      -1
    x[915]    OBJ       1
    x[916]    c916      1
    x[916]    c318      1
    x[916]    c319      -1
    x[916]    OBJ       1
    x[917]    c917      1
    x[917]    c319      1
    x[917]    c320      -1
    x[917]    OBJ       1
    x[918]    c918      1
    x[918]    c320      1
    x[918]    c321      -1
    x[918]    OBJ       1
    x[919]    c919      1
    x[919]    c321      1
    x[919]    c322      -1
    x[919]    OBJ       1
    x[920]    c920      1
    x[920]    c322      1
    x[920]    c323      -1
    x[920]    OBJ       1
    x[921]    c921      1
    x[921]    c323      1
    x[921]    c324      -1
    x[921]    OBJ       1
    x[922]    c922      1
    x[922]    c324      1
    x[922]    c325      -1
    x[922]    OBJ       1
    x[923]    c923      1
    x[923]    c325      1
    x[923]    c326      -1
    x[923]    OBJ       1
    x[924]    c924      1
    x[924]    c326      1
    x[924]    c327      -1
    x[924]    OBJ       1
    x[925]    c925      1
    x[925]    c327      1
    x[925]    c328      -1
    x[925]    OBJ       1
    x[926]    c926      1
    x[926]    c328      1
    x[926]    c329      -1
    x[926]    OBJ       1
    x[927]    c927      1
    x[927]    c329      1
    x[927]    c330      -1
    x[927]    OBJ       1
    x[928]    c928      1
    x[928]    c330      1
    x[928]    c331      -1
    x[928]    OBJ       1
    x[929]    c929      1
    x[929]    c331      1
    x[929]    c332      -1
    x[929]    OBJ       1
    x[930]    c930      1
    x[930]    c332      1
    x[930]    c333      -1
    x[930]    OBJ       1
    x[931]    c931      1
    x[931]    c333      1
    x[931]    c334      -1
    x[931]    OBJ       1
    x[932]    c932      1
    x[932]    c334      1
    x[932]    c335      -1
    x[932]    OBJ       1
    x[933]    c933      1
    x[933]    c335      1
    x[933]    c336      -1
    x[933]    OBJ       1
    x[934]    c934      1
    x[934]    c336      1
    x[934]    c337      -1
    x[934]    OBJ       1
    x[935]    c935      1
    x[935]    c337      1
    x[935]    c338      -1
    x[935]    OBJ       1
    x[936]    c936      1
    x[936]    c338      1
    x[936]    c339      -1
    x[936]    OBJ       1
    x[937]    c937      1
    x[937]    c339      1
    x[937]    c340      -1
    x[937]    OBJ       1
    x[938]    c938      1
    x[938]    c340      1
    x[938]    c341      -1
    x[938]    OBJ       1
    x[939]    c939      1
    x[939]    c341      1
    x[939]    c342      -1
    x[939]    OBJ       1
    x[940]    c940      1
    x[940]    c342      1
    x[940]    c343      -1
    x[940]    OBJ       1
    x[941]    c941      1
    x[941]    c343      1
    x[941]    c344      -1
    x[941]    OBJ       1
    x[942]    c942      1
    x[942]    c344      1
    x[942]    c345      -1
    x[942]    OBJ       1
    x[943]    c943      1
    x[943]    c345      1
    x[943]    c346      -1
    x[943]    OBJ       1
    x[944]    c944      1
    x[944]    c346      1
    x[944]    c347      -1
    x[944]    OBJ       1
    x[945]    c945      1
    x[945]    c347      1
    x[945]    c348      -1
    x[945]    OBJ       1
    x[946]    c946      1
    x[946]    c348      1
    x[946]    c349      -1
    x[946]    OBJ       1
    x[947]    c947      1
    x[947]    c349      1
    x[947]    c350      -1
    x[947]    OBJ       1
    x[948]    c948      1
    x[948]    c350      1
    x[948]    c351      -1
    x[948]    OBJ       1
    x[949]    c949      1
    x[949]    c351      1
    x[949]    c352      -1
    x[949]    OBJ       1
    x[950]    c950      1
    x[950]    c352      1
    x[950]    c353      -1
    x[950]    OBJ       1
    x[951]    c951      1
    x[951]    c353      1
    x[951]    c354      -1
    x[951]    OBJ       1
    x[952]    c952      1
    x[952]    c354      1
    x[952]    c355      -1
    x[952]    OBJ       1
    x[953]    c953      1
    x[953]    c355      1
    x[953]    c356      -1
    x[953]    OBJ       1
    x[954]    c954      1
    x[954]    c356      1
    x[954]    c357      -1
    x[954]    OBJ       1
    x[955]    c955      1
    x[955]    c357      1
    x[955]    c358      -1
    x[955]    OBJ       1
    x[956]    c956      1
    x[956]    c358      1
    x[956]    c359      -1
    x[956]    OBJ       1
    x[957]    c957      1
    x[957]    c359      1
    x[957]    c360      -1
    x[957]    OBJ       1
    x[958]    c958      1
    x[958]    c361      1
    x[958]    c362      -1
    x[958]    OBJ       1
    x[959]    c959      1
    x[959]    c362      1
    x[959]    c363      -1
    x[959]    OBJ       1
    x[960]    c960      1
    x[960]    c363      1
    x[960]    c364      -1
    x[960]    OBJ       1
    x[961]    c961      1
    x[961]    c364      1
    x[961]    c365      -1
    x[961]    OBJ       1
    x[962]    c962      1
    x[962]    c365      1
    x[962]    c366      -1
    x[962]    OBJ       1
    x[963]    c963      1
    x[963]    c366      1
    x[963]    c367      -1
    x[963]    OBJ       1
    x[964]    c964      1
    x[964]    c367      1
    x[964]    c368      -1
    x[964]    OBJ       1
    x[965]    c965      1
    x[965]    c368      1
    x[965]    c369      -1
    x[965]    OBJ       1
    x[966]    c966      1
    x[966]    c369      1
    x[966]    c370      -1
    x[966]    OBJ       1
    x[967]    c967      1
    x[967]    c370      1
    x[967]    c371      -1
    x[967]    OBJ       1
    x[968]    c968      1
    x[968]    c371      1
    x[968]    c372      -1
    x[968]    OBJ       1
    x[969]    c969      1
    x[969]    c372      1
    x[969]    c373      -1
    x[969]    OBJ       1
    x[970]    c970      1
    x[970]    c373      1
    x[970]    c374      -1
    x[970]    OBJ       1
    x[971]    c971      1
    x[971]    c374      1
    x[971]    c375      -1
    x[971]    OBJ       1
    x[972]    c972      1
    x[972]    c375      1
    x[972]    c376      -1
    x[972]    OBJ       1
    x[973]    c973      1
    x[973]    c376      1
    x[973]    c377      -1
    x[973]    OBJ       1
    x[974]    c974      1
    x[974]    c377      1
    x[974]    c378      -1
    x[974]    OBJ       1
    x[975]    c975      1
    x[975]    c378      1
    x[975]    c379      -1
    x[975]    OBJ       1
    x[976]    c976      1
    x[976]    c379      1
    x[976]    c380      -1
    x[976]    OBJ       1
    x[977]    c977      1
    x[977]    c380      1
    x[977]    c381      -1
    x[977]    OBJ       1
    x[978]    c978      1
    x[978]    c381      1
    x[978]    c382      -1
    x[978]    OBJ       1
    x[979]    c979      1
    x[979]    c382      1
    x[979]    c383      -1
    x[979]    OBJ       1
    x[980]    c980      1
    x[980]    c383      1
    x[980]    c384      -1
    x[980]    OBJ       1
    x[981]    c981      1
    x[981]    c384      1
    x[981]    c385      -1
    x[981]    OBJ       1
    x[982]    c982      1
    x[982]    c385      1
    x[982]    c386      -1
    x[982]    OBJ       1
    x[983]    c983      1
    x[983]    c386      1
    x[983]    c387      -1
    x[983]    OBJ       1
    x[984]    c984      1
    x[984]    c387      1
    x[984]    c388      -1
    x[984]    OBJ       1
    x[985]    c985      1
    x[985]    c388      1
    x[985]    c389      -1
    x[985]    OBJ       1
    x[986]    c986      1
    x[986]    c389      1
    x[986]    c390      -1
    x[986]    OBJ       1
    x[987]    c987      1
    x[987]    c390      1
    x[987]    c391      -1
    x[987]    OBJ       1
    x[988]    c988      1
    x[988]    c391      1
    x[988]    c392      -1
    x[988]    OBJ       1
    x[989]    c989      1
    x[989]    c392      1
    x[989]    c393      -1
    x[989]    OBJ       1
    x[990]    c990      1
    x[990]    c393      1
    x[990]    c394      -1
    x[990]    OBJ       1
    x[991]    c991      1
    x[991]    c394      1
    x[991]    c395      -1
    x[991]    OBJ       1
    x[992]    c992      1
    x[992]    c395      1
    x[992]    c396      -1
    x[992]    OBJ       1
    x[993]    c993      1
    x[993]    c396      1
    x[993]    c397      -1
    x[993]    OBJ       1
    x[994]    c994      1
    x[994]    c397      1
    x[994]    c398      -1
    x[994]    OBJ       1
    x[995]    c995      1
    x[995]    c398      1
    x[995]    c399      -1
    x[995]    OBJ       1
    x[996]    c996      1
    x[996]    c399      1
    x[996]    c400      -1
    x[996]    OBJ       1
    x[997]    c997      1
    x[997]    c400      1
    x[997]    c401      -1
    x[997]    OBJ       1
    x[998]    c998      1
    x[998]    c401      1
    x[998]    c402      -1
    x[998]    OBJ       1
    x[999]    c999      1
    x[999]    c402      1
    x[999]    c403      -1
    x[999]    OBJ       1
    x[1000]   c1000     1
    x[1000]   c403      1
    x[1000]   c404      -1
    x[1000]   OBJ       1
    x[1001]   c1001     1
    x[1001]   c404      1
    x[1001]   c405      -1
    x[1001]   OBJ       1
    x[1002]   c1002     1
    x[1002]   c405      1
    x[1002]   c406      -1
    x[1002]   OBJ       1
    x[1003]   c1003     1
    x[1003]   c406      1
    x[1003]   c407      -1
    x[1003]   OBJ       1
    x[1004]   c1004     1
    x[1004]   c407      1
    x[1004]   c408      -1
    x[1004]   OBJ       1
    x[1005]   c1005     1
    x[1005]   c408      1
    x[1005]   c409      -1
    x[1005]   OBJ       1
    x[1006]   c1006     1
    x[1006]   c409      1
    x[1006]   c410      -1
    x[1006]   OBJ       1
    x[1007]   c1007     1
    x[1007]   c410      1
    x[1007]   c411      -1
    x[1007]   OBJ       1
    x[1008]   c1008     1
    x[1008]   c411      1
    x[1008]   c412      -1
    x[1008]   OBJ       1
    x[1009]   c1009     1
    x[1009]   c412      1
    x[1009]   c413      -1
    x[1009]   OBJ       1
    x[1010]   c1010     1
    x[1010]   c413      1
    x[1010]   c414      -1
    x[1010]   OBJ       1
    x[1011]   c1011     1
    x[1011]   c414      1
    x[1011]   c415      -1
    x[1011]   OBJ       1
    x[1012]   c1012     1
    x[1012]   c415      1
    x[1012]   c416      -1
    x[1012]   OBJ       1
    x[1013]   c1013     1
    x[1013]   c416      1
    x[1013]   c417      -1
    x[1013]   OBJ       1
    x[1014]   c1014     1
    x[1014]   c417      1
    x[1014]   c418      -1
    x[1014]   OBJ       1
    x[1015]   c1015     1
    x[1015]   c418      1
    x[1015]   c419      -1
    x[1015]   OBJ       1
    x[1016]   c1016     1
    x[1016]   c419      1
    x[1016]   c420      -1
    x[1016]   OBJ       1
    x[1017]   c1017     1
    x[1017]   c420      1
    x[1017]   c421      -1
    x[1017]   OBJ       1
    x[1018]   c1018     1
    x[1018]   c421      1
    x[1018]   c422      -1
    x[1018]   OBJ       1
    x[1019]   c1019     1
    x[1019]   c422      1
    x[1019]   c423      -1
    x[1019]   OBJ       1
    x[1020]   c1020     1
    x[1020]   c423      1
    x[1020]   c424      -1
    x[1020]   OBJ       1
    x[1021]   c1021     1
    x[1021]   c424      1
    x[1021]   c425      -1
    x[1021]   OBJ       1
    x[1022]   c1022     1
    x[1022]   c425      1
    x[1022]   c426      -1
    x[1022]   OBJ       1
    x[1023]   c1023     1
    x[1023]   c426      1
    x[1023]   c427      -1
    x[1023]   OBJ       1
    x[1024]   c1024     1
    x[1024]   c427      1
    x[1024]   c428      -1
    x[1024]   OBJ       1
    x[1025]   c1025     1
    x[1025]   c428      1
    x[1025]   c429      -1
    x[1025]   OBJ       1
    x[1026]   c1026     1
    x[1026]   c429      1
    x[1026]   c430      -1
    x[1026]   OBJ       1
    x[1027]   c1027     1
    x[1027]   c430      1
    x[1027]   c431      -1
    x[1027]   OBJ       1
    x[1028]   c1028     1
    x[1028]   c431      1
    x[1028]   c432      -1
    x[1028]   OBJ       1
    x[1029]   c1029     1
    x[1029]   c432      1
    x[1029]   c433      -1
    x[1029]   OBJ       1
    x[1030]   c1030     1
    x[1030]   c433      1
    x[1030]   c434      -1
    x[1030]   OBJ       1
    x[1031]   c1031     1
    x[1031]   c434      1
    x[1031]   c435      -1
    x[1031]   OBJ       1
    x[1032]   c1032     1
    x[1032]   c435      1
    x[1032]   c436      -1
    x[1032]   OBJ       1
    x[1033]   c1033     1
    x[1033]   c436      1
    x[1033]   c437      -1
    x[1033]   OBJ       1
    x[1034]   c1034     1
    x[1034]   c437      1
    x[1034]   c438      -1
    x[1034]   OBJ       1
    x[1035]   c1035     1
    x[1035]   c438      1
    x[1035]   c439      -1
    x[1035]   OBJ       1
    x[1036]   c1036     1
    x[1036]   c439      1
    x[1036]   c440      -1
    x[1036]   OBJ       1
    x[1037]   c1037     1
    x[1037]   c440      1
    x[1037]   c441      -1
    x[1037]   OBJ       1
    x[1038]   c1038     1
    x[1038]   c441      1
    x[1038]   c442      -1
    x[1038]   OBJ       1
    x[1039]   c1039     1
    x[1039]   c442      1
    x[1039]   c443      -1
    x[1039]   OBJ       1
    x[1040]   c1040     1
    x[1040]   c443      1
    x[1040]   c444      -1
    x[1040]   OBJ       1
    x[1041]   c1041     1
    x[1041]   c444      1
    x[1041]   c445      -1
    x[1041]   OBJ       1
    x[1042]   c1042     1
    x[1042]   c445      1
    x[1042]   c446      -1
    x[1042]   OBJ       1
    x[1043]   c1043     1
    x[1043]   c446      1
    x[1043]   c447      -1
    x[1043]   OBJ       1
    x[1044]   c1044     1
    x[1044]   c447      1
    x[1044]   c448      -1
    x[1044]   OBJ       1
    x[1045]   c1045     1
    x[1045]   c448      1
    x[1045]   c449      -1
    x[1045]   OBJ       1
    x[1046]   c1046     1
    x[1046]   c449      1
    x[1046]   c450      -1
    x[1046]   OBJ       1
    x[1047]   c1047     1
    x[1047]   c450      1
    x[1047]   c451      -1
    x[1047]   OBJ       1
    x[1048]   c1048     1
    x[1048]   c451      1
    x[1048]   c452      -1
    x[1048]   OBJ       1
    x[1049]   c1049     1
    x[1049]   c452      1
    x[1049]   c453      -1
    x[1049]   OBJ       1
    x[1050]   c1050     1
    x[1050]   c453      1
    x[1050]   c454      -1
    x[1050]   OBJ       1
    x[1051]   c1051     1
    x[1051]   c454      1
    x[1051]   c455      -1
    x[1051]   OBJ       1
    x[1052]   c1052     1
    x[1052]   c455      1
    x[1052]   c456      -1
    x[1052]   OBJ       1
    x[1053]   c1053     1
    x[1053]   c456      1
    x[1053]   c457      -1
    x[1053]   OBJ       1
    x[1054]   c1054     1
    x[1054]   c457      1
    x[1054]   c458      -1
    x[1054]   OBJ       1
    x[1055]   c1055     1
    x[1055]   c458      1
    x[1055]   c459      -1
    x[1055]   OBJ       1
    x[1056]   c1056     1
    x[1056]   c459      1
    x[1056]   c460      -1
    x[1056]   OBJ       1
    x[1057]   c1057     1
    x[1057]   c460      1
    x[1057]   c461      -1
    x[1057]   OBJ       1
    x[1058]   c1058     1
    x[1058]   c461      1
    x[1058]   c462      -1
    x[1058]   OBJ       1
    x[1059]   c1059     1
    x[1059]   c462      1
    x[1059]   c463      -1
    x[1059]   OBJ       1
    x[1060]   c1060     1
    x[1060]   c463      1
    x[1060]   c464      -1
    x[1060]   OBJ       1
    x[1061]   c1061     1
    x[1061]   c464      1
    x[1061]   c465      -1
    x[1061]   OBJ       1
    x[1062]   c1062     1
    x[1062]   c465      1
    x[1062]   c466      -1
    x[1062]   OBJ       1
    x[1063]   c1063     1
    x[1063]   c466      1
    x[1063]   c467      -1
    x[1063]   OBJ       1
    x[1064]   c1064     1
    x[1064]   c467      1
    x[1064]   c468      -1
    x[1064]   OBJ       1
    x[1065]   c1065     1
    x[1065]   c468      1
    x[1065]   c469      -1
    x[1065]   OBJ       1
    x[1066]   c1066     1
    x[1066]   c469      1
    x[1066]   c470      -1
    x[1066]   OBJ       1
    x[1067]   c1067     1
    x[1067]   c470      1
    x[1067]   c471      -1
    x[1067]   OBJ       1
    x[1068]   c1068     1
    x[1068]   c471      1
    x[1068]   c472      -1
    x[1068]   OBJ       1
    x[1069]   c1069     1
    x[1069]   c472      1
    x[1069]   c473      -1
    x[1069]   OBJ       1
    x[1070]   c1070     1
    x[1070]   c473      1
    x[1070]   c474      -1
    x[1070]   OBJ       1
    x[1071]   c1071     1
    x[1071]   c474      1
    x[1071]   c475      -1
    x[1071]   OBJ       1
    x[1072]   c1072     1
    x[1072]   c475      1
    x[1072]   c476      -1
    x[1072]   OBJ       1
    x[1073]   c1073     1
    x[1073]   c476      1
    x[1073]   c477      -1
    x[1073]   OBJ       1
    x[1074]   c1074     1
    x[1074]   c477      1
    x[1074]   c478      -1
    x[1074]   OBJ       1
    x[1075]   c1075     1
    x[1075]   c478      1
    x[1075]   c479      -1
    x[1075]   OBJ       1
    x[1076]   c1076     1
    x[1076]   c479      1
    x[1076]   c480      -1
    x[1076]   OBJ       1
    x[1077]   c1077     1
    x[1077]   c481      1
    x[1077]   c482      -1
    x[1077]   OBJ       1
    x[1078]   c1078     1
    x[1078]   c482      1
    x[1078]   c483      -1
    x[1078]   OBJ       1
    x[1079]   c1079     1
    x[1079]   c483      1
    x[1079]   c484      -1
    x[1079]   OBJ       1
    x[1080]   c1080     1
    x[1080]   c484      1
    x[1080]   c485      -1
    x[1080]   OBJ       1
    x[1081]   c1081     1
    x[1081]   c485      1
    x[1081]   c486      -1
    x[1081]   OBJ       1
    x[1082]   c1082     1
    x[1082]   c486      1
    x[1082]   c487      -1
    x[1082]   OBJ       1
    x[1083]   c1083     1
    x[1083]   c487      1
    x[1083]   c488      -1
    x[1083]   OBJ       1
    x[1084]   c1084     1
    x[1084]   c488      1
    x[1084]   c489      -1
    x[1084]   OBJ       1
    x[1085]   c1085     1
    x[1085]   c489      1
    x[1085]   c490      -1
    x[1085]   OBJ       1
    x[1086]   c1086     1
    x[1086]   c490      1
    x[1086]   c491      -1
    x[1086]   OBJ       1
    x[1087]   c1087     1
    x[1087]   c491      1
    x[1087]   c492      -1
    x[1087]   OBJ       1
    x[1088]   c1088     1
    x[1088]   c492      1
    x[1088]   c493      -1
    x[1088]   OBJ       1
    x[1089]   c1089     1
    x[1089]   c493      1
    x[1089]   c494      -1
    x[1089]   OBJ       1
    x[1090]   c1090     1
    x[1090]   c494      1
    x[1090]   c495      -1
    x[1090]   OBJ       1
    x[1091]   c1091     1
    x[1091]   c495      1
    x[1091]   c496      -1
    x[1091]   OBJ       1
    x[1092]   c1092     1
    x[1092]   c496      1
    x[1092]   c497      -1
    x[1092]   OBJ       1
    x[1093]   c1093     1
    x[1093]   c497      1
    x[1093]   c498      -1
    x[1093]   OBJ       1
    x[1094]   c1094     1
    x[1094]   c498      1
    x[1094]   c499      -1
    x[1094]   OBJ       1
    x[1095]   c1095     1
    x[1095]   c499      1
    x[1095]   c500      -1
    x[1095]   OBJ       1
    x[1096]   c1096     1
    x[1096]   c500      1
    x[1096]   c501      -1
    x[1096]   OBJ       1
    x[1097]   c1097     1
    x[1097]   c501      1
    x[1097]   c502      -1
    x[1097]   OBJ       1
    x[1098]   c1098     1
    x[1098]   c502      1
    x[1098]   c503      -1
    x[1098]   OBJ       1
    x[1099]   c1099     1
    x[1099]   c503      1
    x[1099]   c504      -1
    x[1099]   OBJ       1
    x[1100]   c1100     1
    x[1100]   c504      1
    x[1100]   c505      -1
    x[1100]   OBJ       1
    x[1101]   c1101     1
    x[1101]   c505      1
    x[1101]   c506      -1
    x[1101]   OBJ       1
    x[1102]   c1102     1
    x[1102]   c506      1
    x[1102]   c507      -1
    x[1102]   OBJ       1
    x[1103]   c1103     1
    x[1103]   c507      1
    x[1103]   c508      -1
    x[1103]   OBJ       1
    x[1104]   c1104     1
    x[1104]   c508      1
    x[1104]   c509      -1
    x[1104]   OBJ       1
    x[1105]   c1105     1
    x[1105]   c509      1
    x[1105]   c510      -1
    x[1105]   OBJ       1
    x[1106]   c1106     1
    x[1106]   c510      1
    x[1106]   c511      -1
    x[1106]   OBJ       1
    x[1107]   c1107     1
    x[1107]   c511      1
    x[1107]   c512      -1
    x[1107]   OBJ       1
    x[1108]   c1108     1
    x[1108]   c512      1
    x[1108]   c513      -1
    x[1108]   OBJ       1
    x[1109]   c1109     1
    x[1109]   c513      1
    x[1109]   c514      -1
    x[1109]   OBJ       1
    x[1110]   c1110     1
    x[1110]   c514      1
    x[1110]   c515      -1
    x[1110]   OBJ       1
    x[1111]   c1111     1
    x[1111]   c515      1
    x[1111]   c516      -1
    x[1111]   OBJ       1
    x[1112]   c1112     1
    x[1112]   c516      1
    x[1112]   c517      -1
    x[1112]   OBJ       1
    x[1113]   c1113     1
    x[1113]   c517      1
    x[1113]   c518      -1
    x[1113]   OBJ       1
    x[1114]   c1114     1
    x[1114]   c518      1
    x[1114]   c519      -1
    x[1114]   OBJ       1
    x[1115]   c1115     1
    x[1115]   c519      1
    x[1115]   c520      -1
    x[1115]   OBJ       1
    x[1116]   c1116     1
    x[1116]   c520      1
    x[1116]   c521      -1
    x[1116]   OBJ       1
    x[1117]   c1117     1
    x[1117]   c521      1
    x[1117]   c522      -1
    x[1117]   OBJ       1
    x[1118]   c1118     1
    x[1118]   c522      1
    x[1118]   c523      -1
    x[1118]   OBJ       1
    x[1119]   c1119     1
    x[1119]   c523      1
    x[1119]   c524      -1
    x[1119]   OBJ       1
    x[1120]   c1120     1
    x[1120]   c524      1
    x[1120]   c525      -1
    x[1120]   OBJ       1
    x[1121]   c1121     1
    x[1121]   c525      1
    x[1121]   c526      -1
    x[1121]   OBJ       1
    x[1122]   c1122     1
    x[1122]   c526      1
    x[1122]   c527      -1
    x[1122]   OBJ       1
    x[1123]   c1123     1
    x[1123]   c527      1
    x[1123]   c528      -1
    x[1123]   OBJ       1
    x[1124]   c1124     1
    x[1124]   c528      1
    x[1124]   c529      -1
    x[1124]   OBJ       1
    x[1125]   c1125     1
    x[1125]   c529      1
    x[1125]   c530      -1
    x[1125]   OBJ       1
    x[1126]   c1126     1
    x[1126]   c530      1
    x[1126]   c531      -1
    x[1126]   OBJ       1
    x[1127]   c1127     1
    x[1127]   c531      1
    x[1127]   c532      -1
    x[1127]   OBJ       1
    x[1128]   c1128     1
    x[1128]   c532      1
    x[1128]   c533      -1
    x[1128]   OBJ       1
    x[1129]   c1129     1
    x[1129]   c533      1
    x[1129]   c534      -1
    x[1129]   OBJ       1
    x[1130]   c1130     1
    x[1130]   c534      1
    x[1130]   c535      -1
    x[1130]   OBJ       1
    x[1131]   c1131     1
    x[1131]   c535      1
    x[1131]   c536      -1
    x[1131]   OBJ       1
    x[1132]   c1132     1
    x[1132]   c536      1
    x[1132]   c537      -1
    x[1132]   OBJ       1
    x[1133]   c1133     1
    x[1133]   c537      1
    x[1133]   c538      -1
    x[1133]   OBJ       1
    x[1134]   c1134     1
    x[1134]   c538      1
    x[1134]   c539      -1
    x[1134]   OBJ       1
    x[1135]   c1135     1
    x[1135]   c539      1
    x[1135]   c540      -1
    x[1135]   OBJ       1
    x[1136]   c1136     1
    x[1136]   c540      1
    x[1136]   c541      -1
    x[1136]   OBJ       1
    x[1137]   c1137     1
    x[1137]   c541      1
    x[1137]   c542      -1
    x[1137]   OBJ       1
    x[1138]   c1138     1
    x[1138]   c542      1
    x[1138]   c543      -1
    x[1138]   OBJ       1
    x[1139]   c1139     1
    x[1139]   c543      1
    x[1139]   c544      -1
    x[1139]   OBJ       1
    x[1140]   c1140     1
    x[1140]   c544      1
    x[1140]   c545      -1
    x[1140]   OBJ       1
    x[1141]   c1141     1
    x[1141]   c545      1
    x[1141]   c546      -1
    x[1141]   OBJ       1
    x[1142]   c1142     1
    x[1142]   c546      1
    x[1142]   c547      -1
    x[1142]   OBJ       1
    x[1143]   c1143     1
    x[1143]   c547      1
    x[1143]   c548      -1
    x[1143]   OBJ       1
    x[1144]   c1144     1
    x[1144]   c548      1
    x[1144]   c549      -1
    x[1144]   OBJ       1
    x[1145]   c1145     1
    x[1145]   c549      1
    x[1145]   c550      -1
    x[1145]   OBJ       1
    x[1146]   c1146     1
    x[1146]   c550      1
    x[1146]   c551      -1
    x[1146]   OBJ       1
    x[1147]   c1147     1
    x[1147]   c551      1
    x[1147]   c552      -1
    x[1147]   OBJ       1
    x[1148]   c1148     1
    x[1148]   c552      1
    x[1148]   c553      -1
    x[1148]   OBJ       1
    x[1149]   c1149     1
    x[1149]   c553      1
    x[1149]   c554      -1
    x[1149]   OBJ       1
    x[1150]   c1150     1
    x[1150]   c554      1
    x[1150]   c555      -1
    x[1150]   OBJ       1
    x[1151]   c1151     1
    x[1151]   c555      1
    x[1151]   c556      -1
    x[1151]   OBJ       1
    x[1152]   c1152     1
    x[1152]   c556      1
    x[1152]   c557      -1
    x[1152]   OBJ       1
    x[1153]   c1153     1
    x[1153]   c557      1
    x[1153]   c558      -1
    x[1153]   OBJ       1
    x[1154]   c1154     1
    x[1154]   c558      1
    x[1154]   c559      -1
    x[1154]   OBJ       1
    x[1155]   c1155     1
    x[1155]   c559      1
    x[1155]   c560      -1
    x[1155]   OBJ       1
    x[1156]   c1156     1
    x[1156]   c560      1
    x[1156]   c561      -1
    x[1156]   OBJ       1
    x[1157]   c1157     1
    x[1157]   c561      1
    x[1157]   c562      -1
    x[1157]   OBJ       1
    x[1158]   c1158     1
    x[1158]   c562      1
    x[1158]   c563      -1
    x[1158]   OBJ       1
    x[1159]   c1159     1
    x[1159]   c563      1
    x[1159]   c564      -1
    x[1159]   OBJ       1
    x[1160]   c1160     1
    x[1160]   c564      1
    x[1160]   c565      -1
    x[1160]   OBJ       1
    x[1161]   c1161     1
    x[1161]   c565      1
    x[1161]   c566      -1
    x[1161]   OBJ       1
    x[1162]   c1162     1
    x[1162]   c566      1
    x[1162]   c567      -1
    x[1162]   OBJ       1
    x[1163]   c1163     1
    x[1163]   c567      1
    x[1163]   c568      -1
    x[1163]   OBJ       1
    x[1164]   c1164     1
    x[1164]   c568      1
    x[1164]   c569      -1
    x[1164]   OBJ       1
    x[1165]   c1165     1
    x[1165]   c569      1
    x[1165]   c570      -1
    x[1165]   OBJ       1
    x[1166]   c1166     1
    x[1166]   c570      1
    x[1166]   c571      -1
    x[1166]   OBJ       1
    x[1167]   c1167     1
    x[1167]   c571      1
    x[1167]   c572      -1
    x[1167]   OBJ       1
    x[1168]   c1168     1
    x[1168]   c572      1
    x[1168]   c573      -1
    x[1168]   OBJ       1
    x[1169]   c1169     1
    x[1169]   c573      1
    x[1169]   c574      -1
    x[1169]   OBJ       1
    x[1170]   c1170     1
    x[1170]   c574      1
    x[1170]   c575      -1
    x[1170]   OBJ       1
    x[1171]   c1171     1
    x[1171]   c575      1
    x[1171]   c576      -1
    x[1171]   OBJ       1
    x[1172]   c1172     1
    x[1172]   c576      1
    x[1172]   c577      -1
    x[1172]   OBJ       1
    x[1173]   c1173     1
    x[1173]   c577      1
    x[1173]   c578      -1
    x[1173]   OBJ       1
    x[1174]   c1174     1
    x[1174]   c578      1
    x[1174]   c579      -1
    x[1174]   OBJ       1
    x[1175]   c1175     1
    x[1175]   c579      1
    x[1175]   c580      -1
    x[1175]   OBJ       1
    x[1176]   c1176     1
    x[1176]   c580      1
    x[1176]   c581      -1
    x[1176]   OBJ       1
    x[1177]   c1177     1
    x[1177]   c581      1
    x[1177]   c582      -1
    x[1177]   OBJ       1
    x[1178]   c1178     1
    x[1178]   c582      1
    x[1178]   c583      -1
    x[1178]   OBJ       1
    x[1179]   c1179     1
    x[1179]   c583      1
    x[1179]   c584      -1
    x[1179]   OBJ       1
    x[1180]   c1180     1
    x[1180]   c584      1
    x[1180]   c585      -1
    x[1180]   OBJ       1
    x[1181]   c1181     1
    x[1181]   c585      1
    x[1181]   c586      -1
    x[1181]   OBJ       1
    x[1182]   c1182     1
    x[1182]   c586      1
    x[1182]   c587      -1
    x[1182]   OBJ       1
    x[1183]   c1183     1
    x[1183]   c587      1
    x[1183]   c588      -1
    x[1183]   OBJ       1
    x[1184]   c1184     1
    x[1184]   c588      1
    x[1184]   c589      -1
    x[1184]   OBJ       1
    x[1185]   c1185     1
    x[1185]   c589      1
    x[1185]   c590      -1
    x[1185]   OBJ       1
    x[1186]   c1186     1
    x[1186]   c590      1
    x[1186]   c591      -1
    x[1186]   OBJ       1
    x[1187]   c1187     1
    x[1187]   c591      1
    x[1187]   c592      -1
    x[1187]   OBJ       1
    x[1188]   c1188     1
    x[1188]   c592      1
    x[1188]   c593      -1
    x[1188]   OBJ       1
    x[1189]   c1189     1
    x[1189]   c593      1
    x[1189]   c594      -1
    x[1189]   OBJ       1
    x[1190]   c1190     1
    x[1190]   c594      1
    x[1190]   c595      -1
    x[1190]   OBJ       1
    x[1191]   c1191     1
    x[1191]   c595      1
    x[1191]   c596      -1
    x[1191]   OBJ       1
    x[1192]   c1192     1
    x[1192]   c596      1
    x[1192]   c597      -1
    x[1192]   OBJ       1
    x[1193]   c1193     1
    x[1193]   c597      1
    x[1193]   c598      -1
    x[1193]   OBJ       1
    x[1194]   c1194     1
    x[1194]   c598      1
    x[1194]   c599      -1
    x[1194]   OBJ       1
    x[1195]   c1195     1
    x[1195]   c599      1
    x[1195]   c600      -1
    x[1195]   OBJ       1
    x[1196]   c1        -1
    x[1196]   c2        1
    x[1196]   OBJ       3
    x[1197]   c2        -1
    x[1197]   c3        1
    x[1197]   OBJ       2
    x[1198]   c3        -1
    x[1198]   c4        1
    x[1198]   OBJ       1
    x[1199]   c4        -1
    x[1199]   c5        1
    x[1199]   OBJ       5
    x[1200]   c5        -1
    x[1200]   c6        1
    x[1200]   OBJ       3
    x[1201]   c6        -1
    x[1201]   c7        1
    x[1201]   OBJ       5
    x[1202]   c7        -1
    x[1202]   c8        1
    x[1202]   OBJ       4
    x[1203]   c8        -1
    x[1203]   c9        1
    x[1203]   OBJ       1
    x[1204]   c9        -1
    x[1204]   c10       1
    x[1204]   OBJ       2
    x[1205]   c10       -1
    x[1205]   c11       1
    x[1205]   OBJ       4
    x[1206]   c11       -1
    x[1206]   c12       1
    x[1206]   OBJ       5
    x[1207]   c12       -1
    x[1207]   c13       1
    x[1207]   OBJ       1
    x[1208]   c13       -1
    x[1208]   c14       1
    x[1208]   OBJ       4
    x[1209]   c14       -1
    x[1209]   c15       1
    x[1209]   OBJ       4
    x[1210]   c15       -1
    x[1210]   c16       1
    x[1210]   OBJ       1
    x[1211]   c16       -1
    x[1211]   c17       1
    x[1211]   OBJ       5
    x[1212]   c17       -1
    x[1212]   c18       1
    x[1212]   OBJ       4
    x[1213]   c18       -1
    x[1213]   c19       1
    x[1213]   OBJ       2
    x[1214]   c19       -1
    x[1214]   c20       1
    x[1214]   OBJ       1
    x[1215]   c20       -1
    x[1215]   c21       1
    x[1215]   OBJ       4
    x[1216]   c21       -1
    x[1216]   c22       1
    x[1216]   OBJ       5
    x[1217]   c22       -1
    x[1217]   c23       1
    x[1217]   OBJ       4
    x[1218]   c23       -1
    x[1218]   c24       1
    x[1218]   OBJ       3
    x[1219]   c24       -1
    x[1219]   c25       1
    x[1219]   OBJ       4
    x[1220]   c25       -1
    x[1220]   c26       1
    x[1220]   OBJ       3
    x[1221]   c26       -1
    x[1221]   c27       1
    x[1221]   OBJ       1
    x[1222]   c27       -1
    x[1222]   c28       1
    x[1222]   OBJ       2
    x[1223]   c28       -1
    x[1223]   c29       1
    x[1223]   OBJ       1
    x[1224]   c29       -1
    x[1224]   c30       1
    x[1224]   OBJ       1
    x[1225]   c30       -1
    x[1225]   c31       1
    x[1225]   OBJ       4
    x[1226]   c31       -1
    x[1226]   c32       1
    x[1226]   OBJ       4
    x[1227]   c32       -1
    x[1227]   c33       1
    x[1227]   OBJ       3
    x[1228]   c33       -1
    x[1228]   c34       1
    x[1228]   OBJ       4
    x[1229]   c34       -1
    x[1229]   c35       1
    x[1229]   OBJ       4
    x[1230]   c35       -1
    x[1230]   c36       1
    x[1230]   OBJ       3
    x[1231]   c36       -1
    x[1231]   c37       1
    x[1231]   OBJ       3
    x[1232]   c37       -1
    x[1232]   c38       1
    x[1232]   OBJ       4
    x[1233]   c38       -1
    x[1233]   c39       1
    x[1233]   OBJ       5
    x[1234]   c39       -1
    x[1234]   c40       1
    x[1234]   OBJ       2
    x[1235]   c40       -1
    x[1235]   c41       1
    x[1235]   OBJ       5
    x[1236]   c41       -1
    x[1236]   c42       1
    x[1236]   OBJ       2
    x[1237]   c42       -1
    x[1237]   c43       1
    x[1237]   OBJ       2
    x[1238]   c43       -1
    x[1238]   c44       1
    x[1238]   OBJ       5
    x[1239]   c44       -1
    x[1239]   c45       1
    x[1239]   OBJ       2
    x[1240]   c45       -1
    x[1240]   c46       1
    x[1240]   OBJ       4
    x[1241]   c46       -1
    x[1241]   c47       1
    x[1241]   OBJ       4
    x[1242]   c47       -1
    x[1242]   c48       1
    x[1242]   OBJ       4
    x[1243]   c48       -1
    x[1243]   c49       1
    x[1243]   OBJ       5
    x[1244]   c49       -1
    x[1244]   c50       1
    x[1244]   OBJ       3
    x[1245]   c50       -1
    x[1245]   c51       1
    x[1245]   OBJ       2
    x[1246]   c51       -1
    x[1246]   c52       1
    x[1246]   OBJ       1
    x[1247]   c52       -1
    x[1247]   c53       1
    x[1247]   OBJ       2
    x[1248]   c53       -1
    x[1248]   c54       1
    x[1248]   OBJ       4
    x[1249]   c54       -1
    x[1249]   c55       1
    x[1249]   OBJ       4
    x[1250]   c55       -1
    x[1250]   c56       1
    x[1250]   OBJ       3
    x[1251]   c56       -1
    x[1251]   c57       1
    x[1251]   OBJ       5
    x[1252]   c57       -1
    x[1252]   c58       1
    x[1252]   OBJ       2
    x[1253]   c58       -1
    x[1253]   c59       1
    x[1253]   OBJ       5
    x[1254]   c59       -1
    x[1254]   c60       1
    x[1254]   OBJ       2
    x[1255]   c60       -1
    x[1255]   c61       1
    x[1255]   OBJ       2
    x[1256]   c61       -1
    x[1256]   c62       1
    x[1256]   OBJ       3
    x[1257]   c62       -1
    x[1257]   c63       1
    x[1257]   OBJ       1
    x[1258]   c63       -1
    x[1258]   c64       1
    x[1258]   OBJ       2
    x[1259]   c64       -1
    x[1259]   c65       1
    x[1259]   OBJ       1
    x[1260]   c65       -1
    x[1260]   c66       1
    x[1260]   OBJ       1
    x[1261]   c66       -1
    x[1261]   c67       1
    x[1261]   OBJ       4
    x[1262]   c67       -1
    x[1262]   c68       1
    x[1262]   OBJ       3
    x[1263]   c68       -1
    x[1263]   c69       1
    x[1263]   OBJ       1
    x[1264]   c69       -1
    x[1264]   c70       1
    x[1264]   OBJ       3
    x[1265]   c70       -1
    x[1265]   c71       1
    x[1265]   OBJ       2
    x[1266]   c71       -1
    x[1266]   c72       1
    x[1266]   OBJ       3
    x[1267]   c72       -1
    x[1267]   c73       1
    x[1267]   OBJ       1
    x[1268]   c73       -1
    x[1268]   c74       1
    x[1268]   OBJ       3
    x[1269]   c74       -1
    x[1269]   c75       1
    x[1269]   OBJ       3
    x[1270]   c75       -1
    x[1270]   c76       1
    x[1270]   OBJ       4
    x[1271]   c76       -1
    x[1271]   c77       1
    x[1271]   OBJ       1
    x[1272]   c77       -1
    x[1272]   c78       1
    x[1272]   OBJ       1
    x[1273]   c78       -1
    x[1273]   c79       1
    x[1273]   OBJ       3
    x[1274]   c79       -1
    x[1274]   c80       1
    x[1274]   OBJ       4
    x[1275]   c80       -1
    x[1275]   c81       1
    x[1275]   OBJ       5
    x[1276]   c81       -1
    x[1276]   c82       1
    x[1276]   OBJ       5
    x[1277]   c82       -1
    x[1277]   c83       1
    x[1277]   OBJ       5
    x[1278]   c83       -1
    x[1278]   c84       1
    x[1278]   OBJ       5
    x[1279]   c84       -1
    x[1279]   c85       1
    x[1279]   OBJ       5
    x[1280]   c85       -1
    x[1280]   c86       1
    x[1280]   OBJ       3
    x[1281]   c86       -1
    x[1281]   c87       1
    x[1281]   OBJ       4
    x[1282]   c87       -1
    x[1282]   c88       1
    x[1282]   OBJ       1
    x[1283]   c88       -1
    x[1283]   c89       1
    x[1283]   OBJ       4
    x[1284]   c89       -1
    x[1284]   c90       1
    x[1284]   OBJ       4
    x[1285]   c90       -1
    x[1285]   c91       1
    x[1285]   OBJ       5
    x[1286]   c91       -1
    x[1286]   c92       1
    x[1286]   OBJ       2
    x[1287]   c92       -1
    x[1287]   c93       1
    x[1287]   OBJ       1
    x[1288]   c93       -1
    x[1288]   c94       1
    x[1288]   OBJ       3
    x[1289]   c94       -1
    x[1289]   c95       1
    x[1289]   OBJ       2
    x[1290]   c95       -1
    x[1290]   c96       1
    x[1290]   OBJ       5
    x[1291]   c96       -1
    x[1291]   c97       1
    x[1291]   OBJ       4
    x[1292]   c97       -1
    x[1292]   c98       1
    x[1292]   OBJ       4
    x[1293]   c98       -1
    x[1293]   c99       1
    x[1293]   OBJ       5
    x[1294]   c99       -1
    x[1294]   c100      1
    x[1294]   OBJ       3
    x[1295]   c100      -1
    x[1295]   c101      1
    x[1295]   OBJ       1
    x[1296]   c101      -1
    x[1296]   c102      1
    x[1296]   OBJ       1
    x[1297]   c102      -1
    x[1297]   c103      1
    x[1297]   OBJ       3
    x[1298]   c103      -1
    x[1298]   c104      1
    x[1298]   OBJ       1
    x[1299]   c104      -1
    x[1299]   c105      1
    x[1299]   OBJ       5
    x[1300]   c105      -1
    x[1300]   c106      1
    x[1300]   OBJ       2
    x[1301]   c106      -1
    x[1301]   c107      1
    x[1301]   OBJ       5
    x[1302]   c107      -1
    x[1302]   c108      1
    x[1302]   OBJ       5
    x[1303]   c108      -1
    x[1303]   c109      1
    x[1303]   OBJ       3
    x[1304]   c109      -1
    x[1304]   c110      1
    x[1304]   OBJ       1
    x[1305]   c110      -1
    x[1305]   c111      1
    x[1305]   OBJ       4
    x[1306]   c111      -1
    x[1306]   c112      1
    x[1306]   OBJ       2
    x[1307]   c112      -1
    x[1307]   c113      1
    x[1307]   OBJ       3
    x[1308]   c113      -1
    x[1308]   c114      1
    x[1308]   OBJ       5
    x[1309]   c114      -1
    x[1309]   c115      1
    x[1309]   OBJ       5
    x[1310]   c115      -1
    x[1310]   c116      1
    x[1310]   OBJ       2
    x[1311]   c116      -1
    x[1311]   c117      1
    x[1311]   OBJ       4
    x[1312]   c117      -1
    x[1312]   c118      1
    x[1312]   OBJ       2
    x[1313]   c118      -1
    x[1313]   c119      1
    x[1313]   OBJ       3
    x[1314]   c119      -1
    x[1314]   c120      1
    x[1314]   OBJ       3
    x[1315]   c121      -1
    x[1315]   c122      1
    x[1315]   OBJ       4
    x[1316]   c122      -1
    x[1316]   c123      1
    x[1316]   OBJ       4
    x[1317]   c123      -1
    x[1317]   c124      1
    x[1317]   OBJ       4
    x[1318]   c124      -1
    x[1318]   c125      1
    x[1318]   OBJ       4
    x[1319]   c125      -1
    x[1319]   c126      1
    x[1319]   OBJ       1
    x[1320]   c126      -1
    x[1320]   c127      1
    x[1320]   OBJ       2
    x[1321]   c127      -1
    x[1321]   c128      1
    x[1321]   OBJ       5
    x[1322]   c128      -1
    x[1322]   c129      1
    x[1322]   OBJ       4
    x[1323]   c129      -1
    x[1323]   c130      1
    x[1323]   OBJ       4
    x[1324]   c130      -1
    x[1324]   c131      1
    x[1324]   OBJ       5
    x[1325]   c131      -1
    x[1325]   c132      1
    x[1325]   OBJ       2
    x[1326]   c132      -1
    x[1326]   c133      1
    x[1326]   OBJ       4
    x[1327]   c133      -1
    x[1327]   c134      1
    x[1327]   OBJ       1
    x[1328]   c134      -1
    x[1328]   c135      1
    x[1328]   OBJ       4
    x[1329]   c135      -1
    x[1329]   c136      1
    x[1329]   OBJ       4
    x[1330]   c136      -1
    x[1330]   c137      1
    x[1330]   OBJ       5
    x[1331]   c137      -1
    x[1331]   c138      1
    x[1331]   OBJ       2
    x[1332]   c138      -1
    x[1332]   c139      1
    x[1332]   OBJ       2
    x[1333]   c139      -1
    x[1333]   c140      1
    x[1333]   OBJ       5
    x[1334]   c140      -1
    x[1334]   c141      1
    x[1334]   OBJ       1
    x[1335]   c141      -1
    x[1335]   c142      1
    x[1335]   OBJ       2
    x[1336]   c142      -1
    x[1336]   c143      1
    x[1336]   OBJ       2
    x[1337]   c143      -1
    x[1337]   c144      1
    x[1337]   OBJ       3
    x[1338]   c144      -1
    x[1338]   c145      1
    x[1338]   OBJ       1
    x[1339]   c145      -1
    x[1339]   c146      1
    x[1339]   OBJ       2
    x[1340]   c146      -1
    x[1340]   c147      1
    x[1340]   OBJ       1
    x[1341]   c147      -1
    x[1341]   c148      1
    x[1341]   OBJ       5
    x[1342]   c148      -1
    x[1342]   c149      1
    x[1342]   OBJ       5
    x[1343]   c149      -1
    x[1343]   c150      1
    x[1343]   OBJ       3
    x[1344]   c150      -1
    x[1344]   c151      1
    x[1344]   OBJ       1
    x[1345]   c151      -1
    x[1345]   c152      1
    x[1345]   OBJ       3
    x[1346]   c152      -1
    x[1346]   c153      1
    x[1346]   OBJ       1
    x[1347]   c153      -1
    x[1347]   c154      1
    x[1347]   OBJ       4
    x[1348]   c154      -1
    x[1348]   c155      1
    x[1348]   OBJ       3
    x[1349]   c155      -1
    x[1349]   c156      1
    x[1349]   OBJ       4
    x[1350]   c156      -1
    x[1350]   c157      1
    x[1350]   OBJ       2
    x[1351]   c157      -1
    x[1351]   c158      1
    x[1351]   OBJ       1
    x[1352]   c158      -1
    x[1352]   c159      1
    x[1352]   OBJ       1
    x[1353]   c159      -1
    x[1353]   c160      1
    x[1353]   OBJ       5
    x[1354]   c160      -1
    x[1354]   c161      1
    x[1354]   OBJ       2
    x[1355]   c161      -1
    x[1355]   c162      1
    x[1355]   OBJ       5
    x[1356]   c162      -1
    x[1356]   c163      1
    x[1356]   OBJ       3
    x[1357]   c163      -1
    x[1357]   c164      1
    x[1357]   OBJ       1
    x[1358]   c164      -1
    x[1358]   c165      1
    x[1358]   OBJ       4
    x[1359]   c165      -1
    x[1359]   c166      1
    x[1359]   OBJ       1
    x[1360]   c166      -1
    x[1360]   c167      1
    x[1360]   OBJ       1
    x[1361]   c167      -1
    x[1361]   c168      1
    x[1361]   OBJ       2
    x[1362]   c168      -1
    x[1362]   c169      1
    x[1362]   OBJ       3
    x[1363]   c169      -1
    x[1363]   c170      1
    x[1363]   OBJ       3
    x[1364]   c170      -1
    x[1364]   c171      1
    x[1364]   OBJ       3
    x[1365]   c171      -1
    x[1365]   c172      1
    x[1365]   OBJ       5
    x[1366]   c172      -1
    x[1366]   c173      1
    x[1366]   OBJ       4
    x[1367]   c173      -1
    x[1367]   c174      1
    x[1367]   OBJ       1
    x[1368]   c174      -1
    x[1368]   c175      1
    x[1368]   OBJ       1
    x[1369]   c175      -1
    x[1369]   c176      1
    x[1369]   OBJ       2
    x[1370]   c176      -1
    x[1370]   c177      1
    x[1370]   OBJ       1
    x[1371]   c177      -1
    x[1371]   c178      1
    x[1371]   OBJ       3
    x[1372]   c178      -1
    x[1372]   c179      1
    x[1372]   OBJ       2
    x[1373]   c179      -1
    x[1373]   c180      1
    x[1373]   OBJ       4
    x[1374]   c180      -1
    x[1374]   c181      1
    x[1374]   OBJ       4
    x[1375]   c181      -1
    x[1375]   c182      1
    x[1375]   OBJ       4
    x[1376]   c182      -1
    x[1376]   c183      1
    x[1376]   OBJ       1
    x[1377]   c183      -1
    x[1377]   c184      1
    x[1377]   OBJ       1
    x[1378]   c184      -1
    x[1378]   c185      1
    x[1378]   OBJ       1
    x[1379]   c185      -1
    x[1379]   c186      1
    x[1379]   OBJ       4
    x[1380]   c186      -1
    x[1380]   c187      1
    x[1380]   OBJ       3
    x[1381]   c187      -1
    x[1381]   c188      1
    x[1381]   OBJ       1
    x[1382]   c188      -1
    x[1382]   c189      1
    x[1382]   OBJ       5
    x[1383]   c189      -1
    x[1383]   c190      1
    x[1383]   OBJ       3
    x[1384]   c190      -1
    x[1384]   c191      1
    x[1384]   OBJ       4
    x[1385]   c191      -1
    x[1385]   c192      1
    x[1385]   OBJ       3
    x[1386]   c192      -1
    x[1386]   c193      1
    x[1386]   OBJ       3
    x[1387]   c193      -1
    x[1387]   c194      1
    x[1387]   OBJ       2
    x[1388]   c194      -1
    x[1388]   c195      1
    x[1388]   OBJ       2
    x[1389]   c195      -1
    x[1389]   c196      1
    x[1389]   OBJ       3
    x[1390]   c196      -1
    x[1390]   c197      1
    x[1390]   OBJ       2
    x[1391]   c197      -1
    x[1391]   c198      1
    x[1391]   OBJ       5
    x[1392]   c198      -1
    x[1392]   c199      1
    x[1392]   OBJ       4
    x[1393]   c199      -1
    x[1393]   c200      1
    x[1393]   OBJ       1
    x[1394]   c200      -1
    x[1394]   c201      1
    x[1394]   OBJ       4
    x[1395]   c201      -1
    x[1395]   c202      1
    x[1395]   OBJ       5
    x[1396]   c202      -1
    x[1396]   c203      1
    x[1396]   OBJ       5
    x[1397]   c203      -1
    x[1397]   c204      1
    x[1397]   OBJ       5
    x[1398]   c204      -1
    x[1398]   c205      1
    x[1398]   OBJ       2
    x[1399]   c205      -1
    x[1399]   c206      1
    x[1399]   OBJ       2
    x[1400]   c206      -1
    x[1400]   c207      1
    x[1400]   OBJ       2
    x[1401]   c207      -1
    x[1401]   c208      1
    x[1401]   OBJ       1
    x[1402]   c208      -1
    x[1402]   c209      1
    x[1402]   OBJ       3
    x[1403]   c209      -1
    x[1403]   c210      1
    x[1403]   OBJ       3
    x[1404]   c210      -1
    x[1404]   c211      1
    x[1404]   OBJ       5
    x[1405]   c211      -1
    x[1405]   c212      1
    x[1405]   OBJ       1
    x[1406]   c212      -1
    x[1406]   c213      1
    x[1406]   OBJ       5
    x[1407]   c213      -1
    x[1407]   c214      1
    x[1407]   OBJ       4
    x[1408]   c214      -1
    x[1408]   c215      1
    x[1408]   OBJ       4
    x[1409]   c215      -1
    x[1409]   c216      1
    x[1409]   OBJ       5
    x[1410]   c216      -1
    x[1410]   c217      1
    x[1410]   OBJ       2
    x[1411]   c217      -1
    x[1411]   c218      1
    x[1411]   OBJ       1
    x[1412]   c218      -1
    x[1412]   c219      1
    x[1412]   OBJ       5
    x[1413]   c219      -1
    x[1413]   c220      1
    x[1413]   OBJ       2
    x[1414]   c220      -1
    x[1414]   c221      1
    x[1414]   OBJ       1
    x[1415]   c221      -1
    x[1415]   c222      1
    x[1415]   OBJ       3
    x[1416]   c222      -1
    x[1416]   c223      1
    x[1416]   OBJ       1
    x[1417]   c223      -1
    x[1417]   c224      1
    x[1417]   OBJ       4
    x[1418]   c224      -1
    x[1418]   c225      1
    x[1418]   OBJ       3
    x[1419]   c225      -1
    x[1419]   c226      1
    x[1419]   OBJ       3
    x[1420]   c226      -1
    x[1420]   c227      1
    x[1420]   OBJ       3
    x[1421]   c227      -1
    x[1421]   c228      1
    x[1421]   OBJ       2
    x[1422]   c228      -1
    x[1422]   c229      1
    x[1422]   OBJ       1
    x[1423]   c229      -1
    x[1423]   c230      1
    x[1423]   OBJ       1
    x[1424]   c230      -1
    x[1424]   c231      1
    x[1424]   OBJ       4
    x[1425]   c231      -1
    x[1425]   c232      1
    x[1425]   OBJ       1
    x[1426]   c232      -1
    x[1426]   c233      1
    x[1426]   OBJ       2
    x[1427]   c233      -1
    x[1427]   c234      1
    x[1427]   OBJ       4
    x[1428]   c234      -1
    x[1428]   c235      1
    x[1428]   OBJ       3
    x[1429]   c235      -1
    x[1429]   c236      1
    x[1429]   OBJ       5
    x[1430]   c236      -1
    x[1430]   c237      1
    x[1430]   OBJ       2
    x[1431]   c237      -1
    x[1431]   c238      1
    x[1431]   OBJ       3
    x[1432]   c238      -1
    x[1432]   c239      1
    x[1432]   OBJ       3
    x[1433]   c239      -1
    x[1433]   c240      1
    x[1433]   OBJ       3
    x[1434]   c241      -1
    x[1434]   c242      1
    x[1434]   OBJ       2
    x[1435]   c242      -1
    x[1435]   c243      1
    x[1435]   OBJ       2
    x[1436]   c243      -1
    x[1436]   c244      1
    x[1436]   OBJ       3
    x[1437]   c244      -1
    x[1437]   c245      1
    x[1437]   OBJ       2
    x[1438]   c245      -1
    x[1438]   c246      1
    x[1438]   OBJ       5
    x[1439]   c246      -1
    x[1439]   c247      1
    x[1439]   OBJ       4
    x[1440]   c247      -1
    x[1440]   c248      1
    x[1440]   OBJ       3
    x[1441]   c248      -1
    x[1441]   c249      1
    x[1441]   OBJ       5
    x[1442]   c249      -1
    x[1442]   c250      1
    x[1442]   OBJ       3
    x[1443]   c250      -1
    x[1443]   c251      1
    x[1443]   OBJ       4
    x[1444]   c251      -1
    x[1444]   c252      1
    x[1444]   OBJ       5
    x[1445]   c252      -1
    x[1445]   c253      1
    x[1445]   OBJ       3
    x[1446]   c253      -1
    x[1446]   c254      1
    x[1446]   OBJ       2
    x[1447]   c254      -1
    x[1447]   c255      1
    x[1447]   OBJ       2
    x[1448]   c255      -1
    x[1448]   c256      1
    x[1448]   OBJ       4
    x[1449]   c256      -1
    x[1449]   c257      1
    x[1449]   OBJ       2
    x[1450]   c257      -1
    x[1450]   c258      1
    x[1450]   OBJ       1
    x[1451]   c258      -1
    x[1451]   c259      1
    x[1451]   OBJ       5
    x[1452]   c259      -1
    x[1452]   c260      1
    x[1452]   OBJ       3
    x[1453]   c260      -1
    x[1453]   c261      1
    x[1453]   OBJ       5
    x[1454]   c261      -1
    x[1454]   c262      1
    x[1454]   OBJ       5
    x[1455]   c262      -1
    x[1455]   c263      1
    x[1455]   OBJ       5
    x[1456]   c263      -1
    x[1456]   c264      1
    x[1456]   OBJ       3
    x[1457]   c264      -1
    x[1457]   c265      1
    x[1457]   OBJ       3
    x[1458]   c265      -1
    x[1458]   c266      1
    x[1458]   OBJ       1
    x[1459]   c266      -1
    x[1459]   c267      1
    x[1459]   OBJ       5
    x[1460]   c267      -1
    x[1460]   c268      1
    x[1460]   OBJ       3
    x[1461]   c268      -1
    x[1461]   c269      1
    x[1461]   OBJ       1
    x[1462]   c269      -1
    x[1462]   c270      1
    x[1462]   OBJ       5
    x[1463]   c270      -1
    x[1463]   c271      1
    x[1463]   OBJ       5
    x[1464]   c271      -1
    x[1464]   c272      1
    x[1464]   OBJ       2
    x[1465]   c272      -1
    x[1465]   c273      1
    x[1465]   OBJ       1
    x[1466]   c273      -1
    x[1466]   c274      1
    x[1466]   OBJ       4
    x[1467]   c274      -1
    x[1467]   c275      1
    x[1467]   OBJ       2
    x[1468]   c275      -1
    x[1468]   c276      1
    x[1468]   OBJ       2
    x[1469]   c276      -1
    x[1469]   c277      1
    x[1469]   OBJ       1
    x[1470]   c277      -1
    x[1470]   c278      1
    x[1470]   OBJ       4
    x[1471]   c278      -1
    x[1471]   c279      1
    x[1471]   OBJ       2
    x[1472]   c279      -1
    x[1472]   c280      1
    x[1472]   OBJ       4
    x[1473]   c280      -1
    x[1473]   c281      1
    x[1473]   OBJ       2
    x[1474]   c281      -1
    x[1474]   c282      1
    x[1474]   OBJ       5
    x[1475]   c282      -1
    x[1475]   c283      1
    x[1475]   OBJ       5
    x[1476]   c283      -1
    x[1476]   c284      1
    x[1476]   OBJ       5
    x[1477]   c284      -1
    x[1477]   c285      1
    x[1477]   OBJ       1
    x[1478]   c285      -1
    x[1478]   c286      1
    x[1478]   OBJ       1
    x[1479]   c286      -1
    x[1479]   c287      1
    x[1479]   OBJ       5
    x[1480]   c287      -1
    x[1480]   c288      1
    x[1480]   OBJ       1
    x[1481]   c288      -1
    x[1481]   c289      1
    x[1481]   OBJ       2
    x[1482]   c289      -1
    x[1482]   c290      1
    x[1482]   OBJ       4
    x[1483]   c290      -1
    x[1483]   c291      1
    x[1483]   OBJ       3
    x[1484]   c291      -1
    x[1484]   c292      1
    x[1484]   OBJ       1
    x[1485]   c292      -1
    x[1485]   c293      1
    x[1485]   OBJ       4
    x[1486]   c293      -1
    x[1486]   c294      1
    x[1486]   OBJ       4
    x[1487]   c294      -1
    x[1487]   c295      1
    x[1487]   OBJ       3
    x[1488]   c295      -1
    x[1488]   c296      1
    x[1488]   OBJ       5
    x[1489]   c296      -1
    x[1489]   c297      1
    x[1489]   OBJ       5
    x[1490]   c297      -1
    x[1490]   c298      1
    x[1490]   OBJ       1
    x[1491]   c298      -1
    x[1491]   c299      1
    x[1491]   OBJ       4
    x[1492]   c299      -1
    x[1492]   c300      1
    x[1492]   OBJ       3
    x[1493]   c300      -1
    x[1493]   c301      1
    x[1493]   OBJ       5
    x[1494]   c301      -1
    x[1494]   c302      1
    x[1494]   OBJ       4
    x[1495]   c302      -1
    x[1495]   c303      1
    x[1495]   OBJ       1
    x[1496]   c303      -1
    x[1496]   c304      1
    x[1496]   OBJ       4
    x[1497]   c304      -1
    x[1497]   c305      1
    x[1497]   OBJ       4
    x[1498]   c305      -1
    x[1498]   c306      1
    x[1498]   OBJ       5
    x[1499]   c306      -1
    x[1499]   c307      1
    x[1499]   OBJ       4
    x[1500]   c307      -1
    x[1500]   c308      1
    x[1500]   OBJ       5
    x[1501]   c308      -1
    x[1501]   c309      1
    x[1501]   OBJ       1
    x[1502]   c309      -1
    x[1502]   c310      1
    x[1502]   OBJ       4
    x[1503]   c310      -1
    x[1503]   c311      1
    x[1503]   OBJ       3
    x[1504]   c311      -1
    x[1504]   c312      1
    x[1504]   OBJ       5
    x[1505]   c312      -1
    x[1505]   c313      1
    x[1505]   OBJ       1
    x[1506]   c313      -1
    x[1506]   c314      1
    x[1506]   OBJ       1
    x[1507]   c314      -1
    x[1507]   c315      1
    x[1507]   OBJ       4
    x[1508]   c315      -1
    x[1508]   c316      1
    x[1508]   OBJ       3
    x[1509]   c316      -1
    x[1509]   c317      1
    x[1509]   OBJ       1
    x[1510]   c317      -1
    x[1510]   c318      1
    x[1510]   OBJ       2
    x[1511]   c318      -1
    x[1511]   c319      1
    x[1511]   OBJ       4
    x[1512]   c319      -1
    x[1512]   c320      1
    x[1512]   OBJ       1
    x[1513]   c320      -1
    x[1513]   c321      1
    x[1513]   OBJ       5
    x[1514]   c321      -1
    x[1514]   c322      1
    x[1514]   OBJ       2
    x[1515]   c322      -1
    x[1515]   c323      1
    x[1515]   OBJ       1
    x[1516]   c323      -1
    x[1516]   c324      1
    x[1516]   OBJ       3
    x[1517]   c324      -1
    x[1517]   c325      1
    x[1517]   OBJ       3
    x[1518]   c325      -1
    x[1518]   c326      1
    x[1518]   OBJ       1
    x[1519]   c326      -1
    x[1519]   c327      1
    x[1519]   OBJ       4
    x[1520]   c327      -1
    x[1520]   c328      1
    x[1520]   OBJ       4
    x[1521]   c328      -1
    x[1521]   c329      1
    x[1521]   OBJ       3
    x[1522]   c329      -1
    x[1522]   c330      1
    x[1522]   OBJ       1
    x[1523]   c330      -1
    x[1523]   c331      1
    x[1523]   OBJ       2
    x[1524]   c331      -1
    x[1524]   c332      1
    x[1524]   OBJ       3
    x[1525]   c332      -1
    x[1525]   c333      1
    x[1525]   OBJ       1
    x[1526]   c333      -1
    x[1526]   c334      1
    x[1526]   OBJ       1
    x[1527]   c334      -1
    x[1527]   c335      1
    x[1527]   OBJ       1
    x[1528]   c335      -1
    x[1528]   c336      1
    x[1528]   OBJ       3
    x[1529]   c336      -1
    x[1529]   c337      1
    x[1529]   OBJ       3
    x[1530]   c337      -1
    x[1530]   c338      1
    x[1530]   OBJ       2
    x[1531]   c338      -1
    x[1531]   c339      1
    x[1531]   OBJ       4
    x[1532]   c339      -1
    x[1532]   c340      1
    x[1532]   OBJ       2
    x[1533]   c340      -1
    x[1533]   c341      1
    x[1533]   OBJ       3
    x[1534]   c341      -1
    x[1534]   c342      1
    x[1534]   OBJ       5
    x[1535]   c342      -1
    x[1535]   c343      1
    x[1535]   OBJ       3
    x[1536]   c343      -1
    x[1536]   c344      1
    x[1536]   OBJ       1
    x[1537]   c344      -1
    x[1537]   c345      1
    x[1537]   OBJ       4
    x[1538]   c345      -1
    x[1538]   c346      1
    x[1538]   OBJ       1
    x[1539]   c346      -1
    x[1539]   c347      1
    x[1539]   OBJ       3
    x[1540]   c347      -1
    x[1540]   c348      1
    x[1540]   OBJ       4
    x[1541]   c348      -1
    x[1541]   c349      1
    x[1541]   OBJ       5
    x[1542]   c349      -1
    x[1542]   c350      1
    x[1542]   OBJ       5
    x[1543]   c350      -1
    x[1543]   c351      1
    x[1543]   OBJ       1
    x[1544]   c351      -1
    x[1544]   c352      1
    x[1544]   OBJ       4
    x[1545]   c352      -1
    x[1545]   c353      1
    x[1545]   OBJ       4
    x[1546]   c353      -1
    x[1546]   c354      1
    x[1546]   OBJ       3
    x[1547]   c354      -1
    x[1547]   c355      1
    x[1547]   OBJ       3
    x[1548]   c355      -1
    x[1548]   c356      1
    x[1548]   OBJ       2
    x[1549]   c356      -1
    x[1549]   c357      1
    x[1549]   OBJ       5
    x[1550]   c357      -1
    x[1550]   c358      1
    x[1550]   OBJ       5
    x[1551]   c358      -1
    x[1551]   c359      1
    x[1551]   OBJ       3
    x[1552]   c359      -1
    x[1552]   c360      1
    x[1552]   OBJ       3
    x[1553]   c361      -1
    x[1553]   c362      1
    x[1553]   OBJ       1
    x[1554]   c362      -1
    x[1554]   c363      1
    x[1554]   OBJ       3
    x[1555]   c363      -1
    x[1555]   c364      1
    x[1555]   OBJ       1
    x[1556]   c364      -1
    x[1556]   c365      1
    x[1556]   OBJ       1
    x[1557]   c365      -1
    x[1557]   c366      1
    x[1557]   OBJ       3
    x[1558]   c366      -1
    x[1558]   c367      1
    x[1558]   OBJ       1
    x[1559]   c367      -1
    x[1559]   c368      1
    x[1559]   OBJ       3
    x[1560]   c368      -1
    x[1560]   c369      1
    x[1560]   OBJ       1
    x[1561]   c369      -1
    x[1561]   c370      1
    x[1561]   OBJ       3
    x[1562]   c370      -1
    x[1562]   c371      1
    x[1562]   OBJ       3
    x[1563]   c371      -1
    x[1563]   c372      1
    x[1563]   OBJ       5
    x[1564]   c372      -1
    x[1564]   c373      1
    x[1564]   OBJ       2
    x[1565]   c373      -1
    x[1565]   c374      1
    x[1565]   OBJ       5
    x[1566]   c374      -1
    x[1566]   c375      1
    x[1566]   OBJ       5
    x[1567]   c375      -1
    x[1567]   c376      1
    x[1567]   OBJ       5
    x[1568]   c376      -1
    x[1568]   c377      1
    x[1568]   OBJ       4
    x[1569]   c377      -1
    x[1569]   c378      1
    x[1569]   OBJ       5
    x[1570]   c378      -1
    x[1570]   c379      1
    x[1570]   OBJ       3
    x[1571]   c379      -1
    x[1571]   c380      1
    x[1571]   OBJ       3
    x[1572]   c380      -1
    x[1572]   c381      1
    x[1572]   OBJ       1
    x[1573]   c381      -1
    x[1573]   c382      1
    x[1573]   OBJ       3
    x[1574]   c382      -1
    x[1574]   c383      1
    x[1574]   OBJ       1
    x[1575]   c383      -1
    x[1575]   c384      1
    x[1575]   OBJ       1
    x[1576]   c384      -1
    x[1576]   c385      1
    x[1576]   OBJ       2
    x[1577]   c385      -1
    x[1577]   c386      1
    x[1577]   OBJ       2
    x[1578]   c386      -1
    x[1578]   c387      1
    x[1578]   OBJ       2
    x[1579]   c387      -1
    x[1579]   c388      1
    x[1579]   OBJ       5
    x[1580]   c388      -1
    x[1580]   c389      1
    x[1580]   OBJ       1
    x[1581]   c389      -1
    x[1581]   c390      1
    x[1581]   OBJ       2
    x[1582]   c390      -1
    x[1582]   c391      1
    x[1582]   OBJ       4
    x[1583]   c391      -1
    x[1583]   c392      1
    x[1583]   OBJ       3
    x[1584]   c392      -1
    x[1584]   c393      1
    x[1584]   OBJ       2
    x[1585]   c393      -1
    x[1585]   c394      1
    x[1585]   OBJ       1
    x[1586]   c394      -1
    x[1586]   c395      1
    x[1586]   OBJ       1
    x[1587]   c395      -1
    x[1587]   c396      1
    x[1587]   OBJ       3
    x[1588]   c396      -1
    x[1588]   c397      1
    x[1588]   OBJ       4
    x[1589]   c397      -1
    x[1589]   c398      1
    x[1589]   OBJ       1
    x[1590]   c398      -1
    x[1590]   c399      1
    x[1590]   OBJ       4
    x[1591]   c399      -1
    x[1591]   c400      1
    x[1591]   OBJ       4
    x[1592]   c400      -1
    x[1592]   c401      1
    x[1592]   OBJ       1
    x[1593]   c401      -1
    x[1593]   c402      1
    x[1593]   OBJ       5
    x[1594]   c402      -1
    x[1594]   c403      1
    x[1594]   OBJ       2
    x[1595]   c403      -1
    x[1595]   c404      1
    x[1595]   OBJ       4
    x[1596]   c404      -1
    x[1596]   c405      1
    x[1596]   OBJ       5
    x[1597]   c405      -1
    x[1597]   c406      1
    x[1597]   OBJ       4
    x[1598]   c406      -1
    x[1598]   c407      1
    x[1598]   OBJ       2
    x[1599]   c407      -1
    x[1599]   c408      1
    x[1599]   OBJ       4
    x[1600]   c408      -1
    x[1600]   c409      1
    x[1600]   OBJ       5
    x[1601]   c409      -1
    x[1601]   c410      1
    x[1601]   OBJ       3
    x[1602]   c410      -1
    x[1602]   c411      1
    x[1602]   OBJ       1
    x[1603]   c411      -1
    x[1603]   c412      1
    x[1603]   OBJ       4
    x[1604]   c412      -1
    x[1604]   c413      1
    x[1604]   OBJ       5
    x[1605]   c413      -1
    x[1605]   c414      1
    x[1605]   OBJ       1
    x[1606]   c414      -1
    x[1606]   c415      1
    x[1606]   OBJ       1
    x[1607]   c415      -1
    x[1607]   c416      1
    x[1607]   OBJ       1
    x[1608]   c416      -1
    x[1608]   c417      1
    x[1608]   OBJ       3
    x[1609]   c417      -1
    x[1609]   c418      1
    x[1609]   OBJ       4
    x[1610]   c418      -1
    x[1610]   c419      1
    x[1610]   OBJ       5
    x[1611]   c419      -1
    x[1611]   c420      1
    x[1611]   OBJ       4
    x[1612]   c420      -1
    x[1612]   c421      1
    x[1612]   OBJ       5
    x[1613]   c421      -1
    x[1613]   c422      1
    x[1613]   OBJ       2
    x[1614]   c422      -1
    x[1614]   c423      1
    x[1614]   OBJ       2
    x[1615]   c423      -1
    x[1615]   c424      1
    x[1615]   OBJ       2
    x[1616]   c424      -1
    x[1616]   c425      1
    x[1616]   OBJ       2
    x[1617]   c425      -1
    x[1617]   c426      1
    x[1617]   OBJ       2
    x[1618]   c426      -1
    x[1618]   c427      1
    x[1618]   OBJ       1
    x[1619]   c427      -1
    x[1619]   c428      1
    x[1619]   OBJ       4
    x[1620]   c428      -1
    x[1620]   c429      1
    x[1620]   OBJ       1
    x[1621]   c429      -1
    x[1621]   c430      1
    x[1621]   OBJ       1
    x[1622]   c430      -1
    x[1622]   c431      1
    x[1622]   OBJ       5
    x[1623]   c431      -1
    x[1623]   c432      1
    x[1623]   OBJ       1
    x[1624]   c432      -1
    x[1624]   c433      1
    x[1624]   OBJ       1
    x[1625]   c433      -1
    x[1625]   c434      1
    x[1625]   OBJ       5
    x[1626]   c434      -1
    x[1626]   c435      1
    x[1626]   OBJ       5
    x[1627]   c435      -1
    x[1627]   c436      1
    x[1627]   OBJ       1
    x[1628]   c436      -1
    x[1628]   c437      1
    x[1628]   OBJ       5
    x[1629]   c437      -1
    x[1629]   c438      1
    x[1629]   OBJ       5
    x[1630]   c438      -1
    x[1630]   c439      1
    x[1630]   OBJ       1
    x[1631]   c439      -1
    x[1631]   c440      1
    x[1631]   OBJ       5
    x[1632]   c440      -1
    x[1632]   c441      1
    x[1632]   OBJ       5
    x[1633]   c441      -1
    x[1633]   c442      1
    x[1633]   OBJ       5
    x[1634]   c442      -1
    x[1634]   c443      1
    x[1634]   OBJ       4
    x[1635]   c443      -1
    x[1635]   c444      1
    x[1635]   OBJ       2
    x[1636]   c444      -1
    x[1636]   c445      1
    x[1636]   OBJ       5
    x[1637]   c445      -1
    x[1637]   c446      1
    x[1637]   OBJ       2
    x[1638]   c446      -1
    x[1638]   c447      1
    x[1638]   OBJ       1
    x[1639]   c447      -1
    x[1639]   c448      1
    x[1639]   OBJ       4
    x[1640]   c448      -1
    x[1640]   c449      1
    x[1640]   OBJ       1
    x[1641]   c449      -1
    x[1641]   c450      1
    x[1641]   OBJ       2
    x[1642]   c450      -1
    x[1642]   c451      1
    x[1642]   OBJ       4
    x[1643]   c451      -1
    x[1643]   c452      1
    x[1643]   OBJ       5
    x[1644]   c452      -1
    x[1644]   c453      1
    x[1644]   OBJ       5
    x[1645]   c453      -1
    x[1645]   c454      1
    x[1645]   OBJ       5
    x[1646]   c454      -1
    x[1646]   c455      1
    x[1646]   OBJ       2
    x[1647]   c455      -1
    x[1647]   c456      1
    x[1647]   OBJ       4
    x[1648]   c456      -1
    x[1648]   c457      1
    x[1648]   OBJ       4
    x[1649]   c457      -1
    x[1649]   c458      1
    x[1649]   OBJ       1
    x[1650]   c458      -1
    x[1650]   c459      1
    x[1650]   OBJ       2
    x[1651]   c459      -1
    x[1651]   c460      1
    x[1651]   OBJ       2
    x[1652]   c460      -1
    x[1652]   c461      1
    x[1652]   OBJ       4
    x[1653]   c461      -1
    x[1653]   c462      1
    x[1653]   OBJ       2
    x[1654]   c462      -1
    x[1654]   c463      1
    x[1654]   OBJ       5
    x[1655]   c463      -1
    x[1655]   c464      1
    x[1655]   OBJ       5
    x[1656]   c464      -1
    x[1656]   c465      1
    x[1656]   OBJ       3
    x[1657]   c465      -1
    x[1657]   c466      1
    x[1657]   OBJ       5
    x[1658]   c466      -1
    x[1658]   c467      1
    x[1658]   OBJ       1
    x[1659]   c467      -1
    x[1659]   c468      1
    x[1659]   OBJ       1
    x[1660]   c468      -1
    x[1660]   c469      1
    x[1660]   OBJ       5
    x[1661]   c469      -1
    x[1661]   c470      1
    x[1661]   OBJ       5
    x[1662]   c470      -1
    x[1662]   c471      1
    x[1662]   OBJ       4
    x[1663]   c471      -1
    x[1663]   c472      1
    x[1663]   OBJ       5
    x[1664]   c472      -1
    x[1664]   c473      1
    x[1664]   OBJ       1
    x[1665]   c473      -1
    x[1665]   c474      1
    x[1665]   OBJ       5
    x[1666]   c474      -1
    x[1666]   c475      1
    x[1666]   OBJ       1
    x[1667]   c475      -1
    x[1667]   c476      1
    x[1667]   OBJ       1
    x[1668]   c476      -1
    x[1668]   c477      1
    x[1668]   OBJ       4
    x[1669]   c477      -1
    x[1669]   c478      1
    x[1669]   OBJ       5
    x[1670]   c478      -1
    x[1670]   c479      1
    x[1670]   OBJ       3
    x[1671]   c479      -1
    x[1671]   c480      1
    x[1671]   OBJ       5
    x[1672]   c481      -1
    x[1672]   c482      1
    x[1672]   OBJ       1
    x[1673]   c482      -1
    x[1673]   c483      1
    x[1673]   OBJ       3
    x[1674]   c483      -1
    x[1674]   c484      1
    x[1674]   OBJ       3
    x[1675]   c484      -1
    x[1675]   c485      1
    x[1675]   OBJ       3
    x[1676]   c485      -1
    x[1676]   c486      1
    x[1676]   OBJ       1
    x[1677]   c486      -1
    x[1677]   c487      1
    x[1677]   OBJ       3
    x[1678]   c487      -1
    x[1678]   c488      1
    x[1678]   OBJ       4
    x[1679]   c488      -1
    x[1679]   c489      1
    x[1679]   OBJ       4
    x[1680]   c489      -1
    x[1680]   c490      1
    x[1680]   OBJ       1
    x[1681]   c490      -1
    x[1681]   c491      1
    x[1681]   OBJ       4
    x[1682]   c491      -1
    x[1682]   c492      1
    x[1682]   OBJ       1
    x[1683]   c492      -1
    x[1683]   c493      1
    x[1683]   OBJ       3
    x[1684]   c493      -1
    x[1684]   c494      1
    x[1684]   OBJ       1
    x[1685]   c494      -1
    x[1685]   c495      1
    x[1685]   OBJ       1
    x[1686]   c495      -1
    x[1686]   c496      1
    x[1686]   OBJ       2
    x[1687]   c496      -1
    x[1687]   c497      1
    x[1687]   OBJ       2
    x[1688]   c497      -1
    x[1688]   c498      1
    x[1688]   OBJ       5
    x[1689]   c498      -1
    x[1689]   c499      1
    x[1689]   OBJ       5
    x[1690]   c499      -1
    x[1690]   c500      1
    x[1690]   OBJ       5
    x[1691]   c500      -1
    x[1691]   c501      1
    x[1691]   OBJ       5
    x[1692]   c501      -1
    x[1692]   c502      1
    x[1692]   OBJ       4
    x[1693]   c502      -1
    x[1693]   c503      1
    x[1693]   OBJ       3
    x[1694]   c503      -1
    x[1694]   c504      1
    x[1694]   OBJ       3
    x[1695]   c504      -1
    x[1695]   c505      1
    x[1695]   OBJ       3
    x[1696]   c505      -1
    x[1696]   c506      1
    x[1696]   OBJ       4
    x[1697]   c506      -1
    x[1697]   c507      1
    x[1697]   OBJ       3
    x[1698]   c507      -1
    x[1698]   c508      1
    x[1698]   OBJ       3
    x[1699]   c508      -1
    x[1699]   c509      1
    x[1699]   OBJ       1
    x[1700]   c509      -1
    x[1700]   c510      1
    x[1700]   OBJ       3
    x[1701]   c510      -1
    x[1701]   c511      1
    x[1701]   OBJ       4
    x[1702]   c511      -1
    x[1702]   c512      1
    x[1702]   OBJ       5
    x[1703]   c512      -1
    x[1703]   c513      1
    x[1703]   OBJ       4
    x[1704]   c513      -1
    x[1704]   c514      1
    x[1704]   OBJ       3
    x[1705]   c514      -1
    x[1705]   c515      1
    x[1705]   OBJ       1
    x[1706]   c515      -1
    x[1706]   c516      1
    x[1706]   OBJ       3
    x[1707]   c516      -1
    x[1707]   c517      1
    x[1707]   OBJ       1
    x[1708]   c517      -1
    x[1708]   c518      1
    x[1708]   OBJ       4
    x[1709]   c518      -1
    x[1709]   c519      1
    x[1709]   OBJ       1
    x[1710]   c519      -1
    x[1710]   c520      1
    x[1710]   OBJ       2
    x[1711]   c520      -1
    x[1711]   c521      1
    x[1711]   OBJ       1
    x[1712]   c521      -1
    x[1712]   c522      1
    x[1712]   OBJ       1
    x[1713]   c522      -1
    x[1713]   c523      1
    x[1713]   OBJ       4
    x[1714]   c523      -1
    x[1714]   c524      1
    x[1714]   OBJ       2
    x[1715]   c524      -1
    x[1715]   c525      1
    x[1715]   OBJ       2
    x[1716]   c525      -1
    x[1716]   c526      1
    x[1716]   OBJ       1
    x[1717]   c526      -1
    x[1717]   c527      1
    x[1717]   OBJ       1
    x[1718]   c527      -1
    x[1718]   c528      1
    x[1718]   OBJ       1
    x[1719]   c528      -1
    x[1719]   c529      1
    x[1719]   OBJ       5
    x[1720]   c529      -1
    x[1720]   c530      1
    x[1720]   OBJ       5
    x[1721]   c530      -1
    x[1721]   c531      1
    x[1721]   OBJ       1
    x[1722]   c531      -1
    x[1722]   c532      1
    x[1722]   OBJ       2
    x[1723]   c532      -1
    x[1723]   c533      1
    x[1723]   OBJ       3
    x[1724]   c533      -1
    x[1724]   c534      1
    x[1724]   OBJ       3
    x[1725]   c534      -1
    x[1725]   c535      1
    x[1725]   OBJ       5
    x[1726]   c535      -1
    x[1726]   c536      1
    x[1726]   OBJ       1
    x[1727]   c536      -1
    x[1727]   c537      1
    x[1727]   OBJ       5
    x[1728]   c537      -1
    x[1728]   c538      1
    x[1728]   OBJ       1
    x[1729]   c538      -1
    x[1729]   c539      1
    x[1729]   OBJ       2
    x[1730]   c539      -1
    x[1730]   c540      1
    x[1730]   OBJ       4
    x[1731]   c540      -1
    x[1731]   c541      1
    x[1731]   OBJ       4
    x[1732]   c541      -1
    x[1732]   c542      1
    x[1732]   OBJ       2
    x[1733]   c542      -1
    x[1733]   c543      1
    x[1733]   OBJ       4
    x[1734]   c543      -1
    x[1734]   c544      1
    x[1734]   OBJ       5
    x[1735]   c544      -1
    x[1735]   c545      1
    x[1735]   OBJ       3
    x[1736]   c545      -1
    x[1736]   c546      1
    x[1736]   OBJ       2
    x[1737]   c546      -1
    x[1737]   c547      1
    x[1737]   OBJ       3
    x[1738]   c547      -1
    x[1738]   c548      1
    x[1738]   OBJ       1
    x[1739]   c548      -1
    x[1739]   c549      1
    x[1739]   OBJ       3
    x[1740]   c549      -1
    x[1740]   c550      1
    x[1740]   OBJ       1
    x[1741]   c550      -1
    x[1741]   c551      1
    x[1741]   OBJ       2
    x[1742]   c551      -1
    x[1742]   c552      1
    x[1742]   OBJ       3
    x[1743]   c552      -1
    x[1743]   c553      1
    x[1743]   OBJ       5
    x[1744]   c553      -1
    x[1744]   c554      1
    x[1744]   OBJ       5
    x[1745]   c554      -1
    x[1745]   c555      1
    x[1745]   OBJ       2
    x[1746]   c555      -1
    x[1746]   c556      1
    x[1746]   OBJ       4
    x[1747]   c556      -1
    x[1747]   c557      1
    x[1747]   OBJ       3
    x[1748]   c557      -1
    x[1748]   c558      1
    x[1748]   OBJ       5
    x[1749]   c558      -1
    x[1749]   c559      1
    x[1749]   OBJ       3
    x[1750]   c559      -1
    x[1750]   c560      1
    x[1750]   OBJ       1
    x[1751]   c560      -1
    x[1751]   c561      1
    x[1751]   OBJ       1
    x[1752]   c561      -1
    x[1752]   c562      1
    x[1752]   OBJ       1
    x[1753]   c562      -1
    x[1753]   c563      1
    x[1753]   OBJ       4
    x[1754]   c563      -1
    x[1754]   c564      1
    x[1754]   OBJ       4
    x[1755]   c564      -1
    x[1755]   c565      1
    x[1755]   OBJ       5
    x[1756]   c565      -1
    x[1756]   c566      1
    x[1756]   OBJ       1
    x[1757]   c566      -1
    x[1757]   c567      1
    x[1757]   OBJ       2
    x[1758]   c567      -1
    x[1758]   c568      1
    x[1758]   OBJ       4
    x[1759]   c568      -1
    x[1759]   c569      1
    x[1759]   OBJ       1
    x[1760]   c569      -1
    x[1760]   c570      1
    x[1760]   OBJ       1
    x[1761]   c570      -1
    x[1761]   c571      1
    x[1761]   OBJ       5
    x[1762]   c571      -1
    x[1762]   c572      1
    x[1762]   OBJ       3
    x[1763]   c572      -1
    x[1763]   c573      1
    x[1763]   OBJ       3
    x[1764]   c573      -1
    x[1764]   c574      1
    x[1764]   OBJ       1
    x[1765]   c574      -1
    x[1765]   c575      1
    x[1765]   OBJ       3
    x[1766]   c575      -1
    x[1766]   c576      1
    x[1766]   OBJ       5
    x[1767]   c576      -1
    x[1767]   c577      1
    x[1767]   OBJ       2
    x[1768]   c577      -1
    x[1768]   c578      1
    x[1768]   OBJ       5
    x[1769]   c578      -1
    x[1769]   c579      1
    x[1769]   OBJ       5
    x[1770]   c579      -1
    x[1770]   c580      1
    x[1770]   OBJ       4
    x[1771]   c580      -1
    x[1771]   c581      1
    x[1771]   OBJ       5
    x[1772]   c581      -1
    x[1772]   c582      1
    x[1772]   OBJ       1
    x[1773]   c582      -1
    x[1773]   c583      1
    x[1773]   OBJ       2
    x[1774]   c583      -1
    x[1774]   c584      1
    x[1774]   OBJ       3
    x[1775]   c584      -1
    x[1775]   c585      1
    x[1775]   OBJ       3
    x[1776]   c585      -1
    x[1776]   c586      1
    x[1776]   OBJ       3
    x[1777]   c586      -1
    x[1777]   c587      1
    x[1777]   OBJ       3
    x[1778]   c587      -1
    x[1778]   c588      1
    x[1778]   OBJ       4
    x[1779]   c588      -1
    x[1779]   c589      1
    x[1779]   OBJ       2
    x[1780]   c589      -1
    x[1780]   c590      1
    x[1780]   OBJ       2
    x[1781]   c590      -1
    x[1781]   c591      1
    x[1781]   OBJ       5
    x[1782]   c591      -1
    x[1782]   c592      1
    x[1782]   OBJ       1
    x[1783]   c592      -1
    x[1783]   c593      1
    x[1783]   OBJ       1
    x[1784]   c593      -1
    x[1784]   c594      1
    x[1784]   OBJ       1
    x[1785]   c594      -1
    x[1785]   c595      1
    x[1785]   OBJ       1
    x[1786]   c595      -1
    x[1786]   c596      1
    x[1786]   OBJ       3
    x[1787]   c596      -1
    x[1787]   c597      1
    x[1787]   OBJ       4
    x[1788]   c597      -1
    x[1788]   c598      1
    x[1788]   OBJ       5
    x[1789]   c598      -1
    x[1789]   c599      1
    x[1789]   OBJ       4
    x[1790]   c599      -1
    x[1790]   c600      1
    x[1790]   OBJ       3
    MARKER    'MARKER'                 'INTORG'
    x[1791]   c1_1      -18298
    x[1791]   c1201     1
    x[1791]   OBJ       40000
    x[1792]   c2_1      -18298
    x[1792]   c1202     1
    x[1792]   OBJ       40000
    x[1793]   c3_1      -18298
    x[1793]   c1203     1
    x[1793]   OBJ       45000
    x[1794]   c4_1      -18298
    x[1794]   c1204     1
    x[1794]   OBJ       5000
    x[1795]   c5_1      -18298
    x[1795]   c1205     1
    x[1795]   OBJ       15000
    x[1796]   c6_1      -18298
    x[1796]   c1206     1
    x[1796]   OBJ       5000
    x[1797]   c7_1      -18298
    x[1797]   c1207     1
    x[1797]   OBJ       25000
    x[1798]   c8_1      -18298
    x[1798]   c1208     1
    x[1798]   OBJ       15000
    x[1799]   c9_1      -18298
    x[1799]   c1209     1
    x[1799]   OBJ       40000
    x[1800]   c10_1     -18298
    x[1800]   c1210     1
    x[1800]   OBJ       20000
    x[1801]   c11_1     -18298
    x[1801]   c1211     1
    x[1801]   OBJ       45000
    x[1802]   c12_1     -18298
    x[1802]   c1212     1
    x[1802]   OBJ       10000
    x[1803]   c13_1     -18298
    x[1803]   c1213     1
    x[1803]   OBJ       30000
    x[1804]   c14_1     -18298
    x[1804]   c1214     1
    x[1804]   OBJ       15000
    x[1805]   c15_1     -18298
    x[1805]   c1215     1
    x[1805]   OBJ       30000
    x[1806]   c16_1     -18298
    x[1806]   c1216     1
    x[1806]   OBJ       5000
    x[1807]   c17_1     -18298
    x[1807]   c1217     1
    x[1807]   OBJ       40000
    x[1808]   c18_1     -18298
    x[1808]   c1218     1
    x[1808]   OBJ       25000
    x[1809]   c19_1     -18298
    x[1809]   c1219     1
    x[1809]   OBJ       35000
    x[1810]   c20_1     -18298
    x[1810]   c1220     1
    x[1810]   OBJ       15000
    x[1811]   c21_1     -18298
    x[1811]   c1221     1
    x[1811]   OBJ       20000
    x[1812]   c22_1     -18298
    x[1812]   c1222     1
    x[1812]   OBJ       45000
    x[1813]   c23_1     -18298
    x[1813]   c1223     1
    x[1813]   OBJ       20000
    x[1814]   c24_1     -18298
    x[1814]   c1224     1
    x[1814]   OBJ       30000
    x[1815]   c25_1     -18298
    x[1815]   c1225     1
    x[1815]   OBJ       35000
    x[1816]   c26_1     -18298
    x[1816]   c1226     1
    x[1816]   OBJ       15000
    x[1817]   c27_1     -18298
    x[1817]   c1227     1
    x[1817]   OBJ       45000
    x[1818]   c28_1     -18298
    x[1818]   c1228     1
    x[1818]   OBJ       35000
    x[1819]   c29_1     -18298
    x[1819]   c1229     1
    x[1819]   OBJ       10000
    x[1820]   c30_1     -18298
    x[1820]   c1230     1
    x[1820]   OBJ       25000
    x[1821]   c31_1     -18298
    x[1821]   c1231     1
    x[1821]   OBJ       30000
    x[1822]   c32_1     -18298
    x[1822]   c1232     1
    x[1822]   OBJ       35000
    x[1823]   c33_1     -18298
    x[1823]   c1233     1
    x[1823]   OBJ       25000
    x[1824]   c34_1     -18298
    x[1824]   c1234     1
    x[1824]   OBJ       40000
    x[1825]   c35_1     -18298
    x[1825]   c1235     1
    x[1825]   OBJ       15000
    x[1826]   c36_1     -18298
    x[1826]   c1236     1
    x[1826]   OBJ       20000
    x[1827]   c37_1     -18298
    x[1827]   c1237     1
    x[1827]   OBJ       30000
    x[1828]   c38_1     -18298
    x[1828]   c1238     1
    x[1828]   OBJ       20000
    x[1829]   c39_1     -18298
    x[1829]   c1239     1
    x[1829]   OBJ       10000
    x[1830]   c40_1     -18298
    x[1830]   c1240     1
    x[1830]   OBJ       10000
    x[1831]   c41_1     -18298
    x[1831]   c1241     1
    x[1831]   OBJ       10000
    x[1832]   c42_1     -18298
    x[1832]   c1242     1
    x[1832]   OBJ       20000
    x[1833]   c43_1     -18298
    x[1833]   c1243     1
    x[1833]   OBJ       45000
    x[1834]   c44_1     -18298
    x[1834]   c1244     1
    x[1834]   OBJ       35000
    x[1835]   c45_1     -18298
    x[1835]   c1245     1
    x[1835]   OBJ       30000
    x[1836]   c46_1     -18298
    x[1836]   c1246     1
    x[1836]   OBJ       20000
    x[1837]   c47_1     -18298
    x[1837]   c1247     1
    x[1837]   OBJ       35000
    x[1838]   c48_1     -18298
    x[1838]   c1248     1
    x[1838]   OBJ       45000
    x[1839]   c49_1     -18298
    x[1839]   c1249     1
    x[1839]   OBJ       45000
    x[1840]   c50_1     -18298
    x[1840]   c1250     1
    x[1840]   OBJ       10000
    x[1841]   c51_1     -18298
    x[1841]   c1251     1
    x[1841]   OBJ       30000
    x[1842]   c52_1     -18298
    x[1842]   c1252     1
    x[1842]   OBJ       5000
    x[1843]   c53_1     -18298
    x[1843]   c1253     1
    x[1843]   OBJ       45000
    x[1844]   c54_1     -18298
    x[1844]   c1254     1
    x[1844]   OBJ       35000
    x[1845]   c55_1     -18298
    x[1845]   c1255     1
    x[1845]   OBJ       40000
    x[1846]   c56_1     -18298
    x[1846]   c1256     1
    x[1846]   OBJ       15000
    x[1847]   c57_1     -18298
    x[1847]   c1257     1
    x[1847]   OBJ       15000
    x[1848]   c58_1     -18298
    x[1848]   c1258     1
    x[1848]   OBJ       30000
    x[1849]   c59_1     -18298
    x[1849]   c1259     1
    x[1849]   OBJ       40000
    x[1850]   c60_1     -18298
    x[1850]   c1260     1
    x[1850]   OBJ       30000
    x[1851]   c61_1     -18298
    x[1851]   c1261     1
    x[1851]   OBJ       20000
    x[1852]   c62_1     -18298
    x[1852]   c1262     1
    x[1852]   OBJ       10000
    x[1853]   c63_1     -18298
    x[1853]   c1263     1
    x[1853]   OBJ       45000
    x[1854]   c64_1     -18298
    x[1854]   c1264     1
    x[1854]   OBJ       20000
    x[1855]   c65_1     -18298
    x[1855]   c1265     1
    x[1855]   OBJ       20000
    x[1856]   c66_1     -18298
    x[1856]   c1266     1
    x[1856]   OBJ       25000
    x[1857]   c67_1     -18298
    x[1857]   c1267     1
    x[1857]   OBJ       5000
    x[1858]   c68_1     -18298
    x[1858]   c1268     1
    x[1858]   OBJ       30000
    x[1859]   c69_1     -18298
    x[1859]   c1269     1
    x[1859]   OBJ       25000
    x[1860]   c70_1     -18298
    x[1860]   c1270     1
    x[1860]   OBJ       5000
    x[1861]   c71_1     -18298
    x[1861]   c1271     1
    x[1861]   OBJ       15000
    x[1862]   c72_1     -18298
    x[1862]   c1272     1
    x[1862]   OBJ       5000
    x[1863]   c73_1     -18298
    x[1863]   c1273     1
    x[1863]   OBJ       25000
    x[1864]   c74_1     -18298
    x[1864]   c1274     1
    x[1864]   OBJ       5000
    x[1865]   c75_1     -18298
    x[1865]   c1275     1
    x[1865]   OBJ       15000
    x[1866]   c76_1     -18298
    x[1866]   c1276     1
    x[1866]   OBJ       10000
    x[1867]   c77_1     -18298
    x[1867]   c1277     1
    x[1867]   OBJ       30000
    x[1868]   c78_1     -18298
    x[1868]   c1278     1
    x[1868]   OBJ       30000
    x[1869]   c79_1     -18298
    x[1869]   c1279     1
    x[1869]   OBJ       20000
    x[1870]   c80_1     -18298
    x[1870]   c1280     1
    x[1870]   OBJ       35000
    x[1871]   c81_1     -18298
    x[1871]   c1281     1
    x[1871]   OBJ       20000
    x[1872]   c82_1     -18298
    x[1872]   c1282     1
    x[1872]   OBJ       20000
    x[1873]   c83_1     -18298
    x[1873]   c1283     1
    x[1873]   OBJ       25000
    x[1874]   c84_1     -18298
    x[1874]   c1284     1
    x[1874]   OBJ       35000
    x[1875]   c85_1     -18298
    x[1875]   c1285     1
    x[1875]   OBJ       20000
    x[1876]   c86_1     -18298
    x[1876]   c1286     1
    x[1876]   OBJ       40000
    x[1877]   c87_1     -18298
    x[1877]   c1287     1
    x[1877]   OBJ       15000
    x[1878]   c88_1     -18298
    x[1878]   c1288     1
    x[1878]   OBJ       15000
    x[1879]   c89_1     -18298
    x[1879]   c1289     1
    x[1879]   OBJ       25000
    x[1880]   c90_1     -18298
    x[1880]   c1290     1
    x[1880]   OBJ       30000
    x[1881]   c91_1     -18298
    x[1881]   c1291     1
    x[1881]   OBJ       40000
    x[1882]   c92_1     -18298
    x[1882]   c1292     1
    x[1882]   OBJ       35000
    x[1883]   c93_1     -18298
    x[1883]   c1293     1
    x[1883]   OBJ       40000
    x[1884]   c94_1     -18298
    x[1884]   c1294     1
    x[1884]   OBJ       5000
    x[1885]   c95_1     -18298
    x[1885]   c1295     1
    x[1885]   OBJ       20000
    x[1886]   c96_1     -18298
    x[1886]   c1296     1
    x[1886]   OBJ       45000
    x[1887]   c97_1     -18298
    x[1887]   c1297     1
    x[1887]   OBJ       25000
    x[1888]   c98_1     -18298
    x[1888]   c1298     1
    x[1888]   OBJ       10000
    x[1889]   c99_1     -18298
    x[1889]   c1299     1
    x[1889]   OBJ       25000
    x[1890]   c100_1    -18298
    x[1890]   c1300     1
    x[1890]   OBJ       40000
    x[1891]   c101_1    -18298
    x[1891]   c1301     1
    x[1891]   OBJ       45000
    x[1892]   c102_1    -18298
    x[1892]   c1302     1
    x[1892]   OBJ       40000
    x[1893]   c103_1    -18298
    x[1893]   c1303     1
    x[1893]   OBJ       20000
    x[1894]   c104_1    -18298
    x[1894]   c1304     1
    x[1894]   OBJ       10000
    x[1895]   c105_1    -18298
    x[1895]   c1305     1
    x[1895]   OBJ       40000
    x[1896]   c106_1    -18298
    x[1896]   c1306     1
    x[1896]   OBJ       40000
    x[1897]   c107_1    -18298
    x[1897]   c1307     1
    x[1897]   OBJ       30000
    x[1898]   c108_1    -18298
    x[1898]   c1308     1
    x[1898]   OBJ       35000
    x[1899]   c109_1    -18298
    x[1899]   c1309     1
    x[1899]   OBJ       5000
    x[1900]   c110_1    -18298
    x[1900]   c1310     1
    x[1900]   OBJ       20000
    x[1901]   c111_1    -18298
    x[1901]   c1311     1
    x[1901]   OBJ       20000
    x[1902]   c112_1    -18298
    x[1902]   c1312     1
    x[1902]   OBJ       25000
    x[1903]   c113_1    -18298
    x[1903]   c1313     1
    x[1903]   OBJ       10000
    x[1904]   c114_1    -18298
    x[1904]   c1314     1
    x[1904]   OBJ       10000
    x[1905]   c115_1    -18298
    x[1905]   c1315     1
    x[1905]   OBJ       45000
    x[1906]   c116_1    -18298
    x[1906]   c1316     1
    x[1906]   OBJ       20000
    x[1907]   c117_1    -18298
    x[1907]   c1317     1
    x[1907]   OBJ       5000
    x[1908]   c118_1    -18298
    x[1908]   c1318     1
    x[1908]   OBJ       25000
    x[1909]   c119_1    -18298
    x[1909]   c1319     1
    x[1909]   OBJ       10000
    x[1910]   c120_1    -18298
    x[1910]   c1320     1
    x[1910]   OBJ       5000
    x[1911]   c121_1    -16531
    x[1911]   c1201     1
    x[1911]   OBJ       40000
    x[1912]   c122_1    -16531
    x[1912]   c1202     1
    x[1912]   OBJ       35000
    x[1913]   c123_1    -16531
    x[1913]   c1203     1
    x[1913]   OBJ       15000
    x[1914]   c124_1    -16531
    x[1914]   c1204     1
    x[1914]   OBJ       10000
    x[1915]   c125_1    -16531
    x[1915]   c1205     1
    x[1915]   OBJ       10000
    x[1916]   c126_1    -16531
    x[1916]   c1206     1
    x[1916]   OBJ       15000
    x[1917]   c127_1    -16531
    x[1917]   c1207     1
    x[1917]   OBJ       40000
    x[1918]   c128_1    -16531
    x[1918]   c1208     1
    x[1918]   OBJ       25000
    x[1919]   c129_1    -16531
    x[1919]   c1209     1
    x[1919]   OBJ       45000
    x[1920]   c130_1    -16531
    x[1920]   c1210     1
    x[1920]   OBJ       40000
    x[1921]   c131_1    -16531
    x[1921]   c1211     1
    x[1921]   OBJ       35000
    x[1922]   c132_1    -16531
    x[1922]   c1212     1
    x[1922]   OBJ       40000
    x[1923]   c133_1    -16531
    x[1923]   c1213     1
    x[1923]   OBJ       10000
    x[1924]   c134_1    -16531
    x[1924]   c1214     1
    x[1924]   OBJ       45000
    x[1925]   c135_1    -16531
    x[1925]   c1215     1
    x[1925]   OBJ       30000
    x[1926]   c136_1    -16531
    x[1926]   c1216     1
    x[1926]   OBJ       45000
    x[1927]   c137_1    -16531
    x[1927]   c1217     1
    x[1927]   OBJ       10000
    x[1928]   c138_1    -16531
    x[1928]   c1218     1
    x[1928]   OBJ       5000
    x[1929]   c139_1    -16531
    x[1929]   c1219     1
    x[1929]   OBJ       10000
    x[1930]   c140_1    -16531
    x[1930]   c1220     1
    x[1930]   OBJ       40000
    x[1931]   c141_1    -16531
    x[1931]   c1221     1
    x[1931]   OBJ       20000
    x[1932]   c142_1    -16531
    x[1932]   c1222     1
    x[1932]   OBJ       15000
    x[1933]   c143_1    -16531
    x[1933]   c1223     1
    x[1933]   OBJ       25000
    x[1934]   c144_1    -16531
    x[1934]   c1224     1
    x[1934]   OBJ       45000
    x[1935]   c145_1    -16531
    x[1935]   c1225     1
    x[1935]   OBJ       30000
    x[1936]   c146_1    -16531
    x[1936]   c1226     1
    x[1936]   OBJ       30000
    x[1937]   c147_1    -16531
    x[1937]   c1227     1
    x[1937]   OBJ       25000
    x[1938]   c148_1    -16531
    x[1938]   c1228     1
    x[1938]   OBJ       35000
    x[1939]   c149_1    -16531
    x[1939]   c1229     1
    x[1939]   OBJ       45000
    x[1940]   c150_1    -16531
    x[1940]   c1230     1
    x[1940]   OBJ       35000
    x[1941]   c151_1    -16531
    x[1941]   c1231     1
    x[1941]   OBJ       40000
    x[1942]   c152_1    -16531
    x[1942]   c1232     1
    x[1942]   OBJ       35000
    x[1943]   c153_1    -16531
    x[1943]   c1233     1
    x[1943]   OBJ       40000
    x[1944]   c154_1    -16531
    x[1944]   c1234     1
    x[1944]   OBJ       30000
    x[1945]   c155_1    -16531
    x[1945]   c1235     1
    x[1945]   OBJ       40000
    x[1946]   c156_1    -16531
    x[1946]   c1236     1
    x[1946]   OBJ       30000
    x[1947]   c157_1    -16531
    x[1947]   c1237     1
    x[1947]   OBJ       20000
    x[1948]   c158_1    -16531
    x[1948]   c1238     1
    x[1948]   OBJ       25000
    x[1949]   c159_1    -16531
    x[1949]   c1239     1
    x[1949]   OBJ       20000
    x[1950]   c160_1    -16531
    x[1950]   c1240     1
    x[1950]   OBJ       20000
    x[1951]   c161_1    -16531
    x[1951]   c1241     1
    x[1951]   OBJ       5000
    x[1952]   c162_1    -16531
    x[1952]   c1242     1
    x[1952]   OBJ       5000
    x[1953]   c163_1    -16531
    x[1953]   c1243     1
    x[1953]   OBJ       45000
    x[1954]   c164_1    -16531
    x[1954]   c1244     1
    x[1954]   OBJ       30000
    x[1955]   c165_1    -16531
    x[1955]   c1245     1
    x[1955]   OBJ       35000
    x[1956]   c166_1    -16531
    x[1956]   c1246     1
    x[1956]   OBJ       5000
    x[1957]   c167_1    -16531
    x[1957]   c1247     1
    x[1957]   OBJ       15000
    x[1958]   c168_1    -16531
    x[1958]   c1248     1
    x[1958]   OBJ       40000
    x[1959]   c169_1    -16531
    x[1959]   c1249     1
    x[1959]   OBJ       15000
    x[1960]   c170_1    -16531
    x[1960]   c1250     1
    x[1960]   OBJ       20000
    x[1961]   c171_1    -16531
    x[1961]   c1251     1
    x[1961]   OBJ       25000
    x[1962]   c172_1    -16531
    x[1962]   c1252     1
    x[1962]   OBJ       10000
    x[1963]   c173_1    -16531
    x[1963]   c1253     1
    x[1963]   OBJ       10000
    x[1964]   c174_1    -16531
    x[1964]   c1254     1
    x[1964]   OBJ       45000
    x[1965]   c175_1    -16531
    x[1965]   c1255     1
    x[1965]   OBJ       30000
    x[1966]   c176_1    -16531
    x[1966]   c1256     1
    x[1966]   OBJ       30000
    x[1967]   c177_1    -16531
    x[1967]   c1257     1
    x[1967]   OBJ       10000
    x[1968]   c178_1    -16531
    x[1968]   c1258     1
    x[1968]   OBJ       15000
    x[1969]   c179_1    -16531
    x[1969]   c1259     1
    x[1969]   OBJ       40000
    x[1970]   c180_1    -16531
    x[1970]   c1260     1
    x[1970]   OBJ       45000
    x[1971]   c181_1    -16531
    x[1971]   c1261     1
    x[1971]   OBJ       10000
    x[1972]   c182_1    -16531
    x[1972]   c1262     1
    x[1972]   OBJ       10000
    x[1973]   c183_1    -16531
    x[1973]   c1263     1
    x[1973]   OBJ       20000
    x[1974]   c184_1    -16531
    x[1974]   c1264     1
    x[1974]   OBJ       10000
    x[1975]   c185_1    -16531
    x[1975]   c1265     1
    x[1975]   OBJ       5000
    x[1976]   c186_1    -16531
    x[1976]   c1266     1
    x[1976]   OBJ       15000
    x[1977]   c187_1    -16531
    x[1977]   c1267     1
    x[1977]   OBJ       10000
    x[1978]   c188_1    -16531
    x[1978]   c1268     1
    x[1978]   OBJ       40000
    x[1979]   c189_1    -16531
    x[1979]   c1269     1
    x[1979]   OBJ       40000
    x[1980]   c190_1    -16531
    x[1980]   c1270     1
    x[1980]   OBJ       35000
    x[1981]   c191_1    -16531
    x[1981]   c1271     1
    x[1981]   OBJ       35000
    x[1982]   c192_1    -16531
    x[1982]   c1272     1
    x[1982]   OBJ       10000
    x[1983]   c193_1    -16531
    x[1983]   c1273     1
    x[1983]   OBJ       45000
    x[1984]   c194_1    -16531
    x[1984]   c1274     1
    x[1984]   OBJ       30000
    x[1985]   c195_1    -16531
    x[1985]   c1275     1
    x[1985]   OBJ       40000
    x[1986]   c196_1    -16531
    x[1986]   c1276     1
    x[1986]   OBJ       45000
    x[1987]   c197_1    -16531
    x[1987]   c1277     1
    x[1987]   OBJ       25000
    x[1988]   c198_1    -16531
    x[1988]   c1278     1
    x[1988]   OBJ       15000
    x[1989]   c199_1    -16531
    x[1989]   c1279     1
    x[1989]   OBJ       5000
    x[1990]   c200_1    -16531
    x[1990]   c1280     1
    x[1990]   OBJ       5000
    x[1991]   c201_1    -16531
    x[1991]   c1281     1
    x[1991]   OBJ       40000
    x[1992]   c202_1    -16531
    x[1992]   c1282     1
    x[1992]   OBJ       40000
    x[1993]   c203_1    -16531
    x[1993]   c1283     1
    x[1993]   OBJ       45000
    x[1994]   c204_1    -16531
    x[1994]   c1284     1
    x[1994]   OBJ       40000
    x[1995]   c205_1    -16531
    x[1995]   c1285     1
    x[1995]   OBJ       10000
    x[1996]   c206_1    -16531
    x[1996]   c1286     1
    x[1996]   OBJ       35000
    x[1997]   c207_1    -16531
    x[1997]   c1287     1
    x[1997]   OBJ       5000
    x[1998]   c208_1    -16531
    x[1998]   c1288     1
    x[1998]   OBJ       15000
    x[1999]   c209_1    -16531
    x[1999]   c1289     1
    x[1999]   OBJ       20000
    x[2000]   c210_1    -16531
    x[2000]   c1290     1
    x[2000]   OBJ       30000
    x[2001]   c211_1    -16531
    x[2001]   c1291     1
    x[2001]   OBJ       15000
    x[2002]   c212_1    -16531
    x[2002]   c1292     1
    x[2002]   OBJ       10000
    x[2003]   c213_1    -16531
    x[2003]   c1293     1
    x[2003]   OBJ       40000
    x[2004]   c214_1    -16531
    x[2004]   c1294     1
    x[2004]   OBJ       5000
    x[2005]   c215_1    -16531
    x[2005]   c1295     1
    x[2005]   OBJ       25000
    x[2006]   c216_1    -16531
    x[2006]   c1296     1
    x[2006]   OBJ       35000
    x[2007]   c217_1    -16531
    x[2007]   c1297     1
    x[2007]   OBJ       20000
    x[2008]   c218_1    -16531
    x[2008]   c1298     1
    x[2008]   OBJ       20000
    x[2009]   c219_1    -16531
    x[2009]   c1299     1
    x[2009]   OBJ       40000
    x[2010]   c220_1    -16531
    x[2010]   c1300     1
    x[2010]   OBJ       35000
    x[2011]   c221_1    -16531
    x[2011]   c1301     1
    x[2011]   OBJ       35000
    x[2012]   c222_1    -16531
    x[2012]   c1302     1
    x[2012]   OBJ       30000
    x[2013]   c223_1    -16531
    x[2013]   c1303     1
    x[2013]   OBJ       40000
    x[2014]   c224_1    -16531
    x[2014]   c1304     1
    x[2014]   OBJ       35000
    x[2015]   c225_1    -16531
    x[2015]   c1305     1
    x[2015]   OBJ       15000
    x[2016]   c226_1    -16531
    x[2016]   c1306     1
    x[2016]   OBJ       10000
    x[2017]   c227_1    -16531
    x[2017]   c1307     1
    x[2017]   OBJ       20000
    x[2018]   c228_1    -16531
    x[2018]   c1308     1
    x[2018]   OBJ       25000
    x[2019]   c229_1    -16531
    x[2019]   c1309     1
    x[2019]   OBJ       15000
    x[2020]   c230_1    -16531
    x[2020]   c1310     1
    x[2020]   OBJ       10000
    x[2021]   c231_1    -16531
    x[2021]   c1311     1
    x[2021]   OBJ       20000
    x[2022]   c232_1    -16531
    x[2022]   c1312     1
    x[2022]   OBJ       15000
    x[2023]   c233_1    -16531
    x[2023]   c1313     1
    x[2023]   OBJ       20000
    x[2024]   c234_1    -16531
    x[2024]   c1314     1
    x[2024]   OBJ       45000
    x[2025]   c235_1    -16531
    x[2025]   c1315     1
    x[2025]   OBJ       15000
    x[2026]   c236_1    -16531
    x[2026]   c1316     1
    x[2026]   OBJ       25000
    x[2027]   c237_1    -16531
    x[2027]   c1317     1
    x[2027]   OBJ       25000
    x[2028]   c238_1    -16531
    x[2028]   c1318     1
    x[2028]   OBJ       10000
    x[2029]   c239_1    -16531
    x[2029]   c1319     1
    x[2029]   OBJ       5000
    x[2030]   c240_1    -16531
    x[2030]   c1320     1
    x[2030]   OBJ       15000
    x[2031]   c241_1    -19386
    x[2031]   c1201     1
    x[2031]   OBJ       40000
    x[2032]   c242_1    -19386
    x[2032]   c1202     1
    x[2032]   OBJ       20000
    x[2033]   c243_1    -19386
    x[2033]   c1203     1
    x[2033]   OBJ       35000
    x[2034]   c244_1    -19386
    x[2034]   c1204     1
    x[2034]   OBJ       45000
    x[2035]   c245_1    -19386
    x[2035]   c1205     1
    x[2035]   OBJ       35000
    x[2036]   c246_1    -19386
    x[2036]   c1206     1
    x[2036]   OBJ       10000
    x[2037]   c247_1    -19386
    x[2037]   c1207     1
    x[2037]   OBJ       30000
    x[2038]   c248_1    -19386
    x[2038]   c1208     1
    x[2038]   OBJ       30000
    x[2039]   c249_1    -19386
    x[2039]   c1209     1
    x[2039]   OBJ       10000
    x[2040]   c250_1    -19386
    x[2040]   c1210     1
    x[2040]   OBJ       20000
    x[2041]   c251_1    -19386
    x[2041]   c1211     1
    x[2041]   OBJ       45000
    x[2042]   c252_1    -19386
    x[2042]   c1212     1
    x[2042]   OBJ       40000
    x[2043]   c253_1    -19386
    x[2043]   c1213     1
    x[2043]   OBJ       5000
    x[2044]   c254_1    -19386
    x[2044]   c1214     1
    x[2044]   OBJ       35000
    x[2045]   c255_1    -19386
    x[2045]   c1215     1
    x[2045]   OBJ       25000
    x[2046]   c256_1    -19386
    x[2046]   c1216     1
    x[2046]   OBJ       5000
    x[2047]   c257_1    -19386
    x[2047]   c1217     1
    x[2047]   OBJ       20000
    x[2048]   c258_1    -19386
    x[2048]   c1218     1
    x[2048]   OBJ       35000
    x[2049]   c259_1    -19386
    x[2049]   c1219     1
    x[2049]   OBJ       40000
    x[2050]   c260_1    -19386
    x[2050]   c1220     1
    x[2050]   OBJ       5000
    x[2051]   c261_1    -19386
    x[2051]   c1221     1
    x[2051]   OBJ       45000
    x[2052]   c262_1    -19386
    x[2052]   c1222     1
    x[2052]   OBJ       40000
    x[2053]   c263_1    -19386
    x[2053]   c1223     1
    x[2053]   OBJ       5000
    x[2054]   c264_1    -19386
    x[2054]   c1224     1
    x[2054]   OBJ       35000
    x[2055]   c265_1    -19386
    x[2055]   c1225     1
    x[2055]   OBJ       10000
    x[2056]   c266_1    -19386
    x[2056]   c1226     1
    x[2056]   OBJ       40000
    x[2057]   c267_1    -19386
    x[2057]   c1227     1
    x[2057]   OBJ       45000
    x[2058]   c268_1    -19386
    x[2058]   c1228     1
    x[2058]   OBJ       40000
    x[2059]   c269_1    -19386
    x[2059]   c1229     1
    x[2059]   OBJ       30000
    x[2060]   c270_1    -19386
    x[2060]   c1230     1
    x[2060]   OBJ       35000
    x[2061]   c271_1    -19386
    x[2061]   c1231     1
    x[2061]   OBJ       15000
    x[2062]   c272_1    -19386
    x[2062]   c1232     1
    x[2062]   OBJ       15000
    x[2063]   c273_1    -19386
    x[2063]   c1233     1
    x[2063]   OBJ       45000
    x[2064]   c274_1    -19386
    x[2064]   c1234     1
    x[2064]   OBJ       5000
    x[2065]   c275_1    -19386
    x[2065]   c1235     1
    x[2065]   OBJ       5000
    x[2066]   c276_1    -19386
    x[2066]   c1236     1
    x[2066]   OBJ       15000
    x[2067]   c277_1    -19386
    x[2067]   c1237     1
    x[2067]   OBJ       20000
    x[2068]   c278_1    -19386
    x[2068]   c1238     1
    x[2068]   OBJ       15000
    x[2069]   c279_1    -19386
    x[2069]   c1239     1
    x[2069]   OBJ       10000
    x[2070]   c280_1    -19386
    x[2070]   c1240     1
    x[2070]   OBJ       10000
    x[2071]   c281_1    -19386
    x[2071]   c1241     1
    x[2071]   OBJ       45000
    x[2072]   c282_1    -19386
    x[2072]   c1242     1
    x[2072]   OBJ       20000
    x[2073]   c283_1    -19386
    x[2073]   c1243     1
    x[2073]   OBJ       40000
    x[2074]   c284_1    -19386
    x[2074]   c1244     1
    x[2074]   OBJ       25000
    x[2075]   c285_1    -19386
    x[2075]   c1245     1
    x[2075]   OBJ       35000
    x[2076]   c286_1    -19386
    x[2076]   c1246     1
    x[2076]   OBJ       15000
    x[2077]   c287_1    -19386
    x[2077]   c1247     1
    x[2077]   OBJ       30000
    x[2078]   c288_1    -19386
    x[2078]   c1248     1
    x[2078]   OBJ       40000
    x[2079]   c289_1    -19386
    x[2079]   c1249     1
    x[2079]   OBJ       25000
    x[2080]   c290_1    -19386
    x[2080]   c1250     1
    x[2080]   OBJ       40000
    x[2081]   c291_1    -19386
    x[2081]   c1251     1
    x[2081]   OBJ       40000
    x[2082]   c292_1    -19386
    x[2082]   c1252     1
    x[2082]   OBJ       15000
    x[2083]   c293_1    -19386
    x[2083]   c1253     1
    x[2083]   OBJ       15000
    x[2084]   c294_1    -19386
    x[2084]   c1254     1
    x[2084]   OBJ       30000
    x[2085]   c295_1    -19386
    x[2085]   c1255     1
    x[2085]   OBJ       10000
    x[2086]   c296_1    -19386
    x[2086]   c1256     1
    x[2086]   OBJ       45000
    x[2087]   c297_1    -19386
    x[2087]   c1257     1
    x[2087]   OBJ       35000
    x[2088]   c298_1    -19386
    x[2088]   c1258     1
    x[2088]   OBJ       35000
    x[2089]   c299_1    -19386
    x[2089]   c1259     1
    x[2089]   OBJ       35000
    x[2090]   c300_1    -19386
    x[2090]   c1260     1
    x[2090]   OBJ       25000
    x[2091]   c301_1    -19386
    x[2091]   c1261     1
    x[2091]   OBJ       5000
    x[2092]   c302_1    -19386
    x[2092]   c1262     1
    x[2092]   OBJ       20000
    x[2093]   c303_1    -19386
    x[2093]   c1263     1
    x[2093]   OBJ       25000
    x[2094]   c304_1    -19386
    x[2094]   c1264     1
    x[2094]   OBJ       25000
    x[2095]   c305_1    -19386
    x[2095]   c1265     1
    x[2095]   OBJ       35000
    x[2096]   c306_1    -19386
    x[2096]   c1266     1
    x[2096]   OBJ       5000
    x[2097]   c307_1    -19386
    x[2097]   c1267     1
    x[2097]   OBJ       30000
    x[2098]   c308_1    -19386
    x[2098]   c1268     1
    x[2098]   OBJ       20000
    x[2099]   c309_1    -19386
    x[2099]   c1269     1
    x[2099]   OBJ       25000
    x[2100]   c310_1    -19386
    x[2100]   c1270     1
    x[2100]   OBJ       35000
    x[2101]   c311_1    -19386
    x[2101]   c1271     1
    x[2101]   OBJ       30000
    x[2102]   c312_1    -19386
    x[2102]   c1272     1
    x[2102]   OBJ       5000
    x[2103]   c313_1    -19386
    x[2103]   c1273     1
    x[2103]   OBJ       20000
    x[2104]   c314_1    -19386
    x[2104]   c1274     1
    x[2104]   OBJ       20000
    x[2105]   c315_1    -19386
    x[2105]   c1275     1
    x[2105]   OBJ       45000
    x[2106]   c316_1    -19386
    x[2106]   c1276     1
    x[2106]   OBJ       40000
    x[2107]   c317_1    -19386
    x[2107]   c1277     1
    x[2107]   OBJ       40000
    x[2108]   c318_1    -19386
    x[2108]   c1278     1
    x[2108]   OBJ       20000
    x[2109]   c319_1    -19386
    x[2109]   c1279     1
    x[2109]   OBJ       20000
    x[2110]   c320_1    -19386
    x[2110]   c1280     1
    x[2110]   OBJ       25000
    x[2111]   c321_1    -19386
    x[2111]   c1281     1
    x[2111]   OBJ       45000
    x[2112]   c322_1    -19386
    x[2112]   c1282     1
    x[2112]   OBJ       35000
    x[2113]   c323_1    -19386
    x[2113]   c1283     1
    x[2113]   OBJ       45000
    x[2114]   c324_1    -19386
    x[2114]   c1284     1
    x[2114]   OBJ       25000
    x[2115]   c325_1    -19386
    x[2115]   c1285     1
    x[2115]   OBJ       10000
    x[2116]   c326_1    -19386
    x[2116]   c1286     1
    x[2116]   OBJ       25000
    x[2117]   c327_1    -19386
    x[2117]   c1287     1
    x[2117]   OBJ       10000
    x[2118]   c328_1    -19386
    x[2118]   c1288     1
    x[2118]   OBJ       5000
    x[2119]   c329_1    -19386
    x[2119]   c1289     1
    x[2119]   OBJ       40000
    x[2120]   c330_1    -19386
    x[2120]   c1290     1
    x[2120]   OBJ       10000
    x[2121]   c331_1    -19386
    x[2121]   c1291     1
    x[2121]   OBJ       30000
    x[2122]   c332_1    -19386
    x[2122]   c1292     1
    x[2122]   OBJ       20000
    x[2123]   c333_1    -19386
    x[2123]   c1293     1
    x[2123]   OBJ       30000
    x[2124]   c334_1    -19386
    x[2124]   c1294     1
    x[2124]   OBJ       30000
    x[2125]   c335_1    -19386
    x[2125]   c1295     1
    x[2125]   OBJ       15000
    x[2126]   c336_1    -19386
    x[2126]   c1296     1
    x[2126]   OBJ       10000
    x[2127]   c337_1    -19386
    x[2127]   c1297     1
    x[2127]   OBJ       25000
    x[2128]   c338_1    -19386
    x[2128]   c1298     1
    x[2128]   OBJ       25000
    x[2129]   c339_1    -19386
    x[2129]   c1299     1
    x[2129]   OBJ       45000
    x[2130]   c340_1    -19386
    x[2130]   c1300     1
    x[2130]   OBJ       35000
    x[2131]   c341_1    -19386
    x[2131]   c1301     1
    x[2131]   OBJ       10000
    x[2132]   c342_1    -19386
    x[2132]   c1302     1
    x[2132]   OBJ       10000
    x[2133]   c343_1    -19386
    x[2133]   c1303     1
    x[2133]   OBJ       45000
    x[2134]   c344_1    -19386
    x[2134]   c1304     1
    x[2134]   OBJ       10000
    x[2135]   c345_1    -19386
    x[2135]   c1305     1
    x[2135]   OBJ       5000
    x[2136]   c346_1    -19386
    x[2136]   c1306     1
    x[2136]   OBJ       30000
    x[2137]   c347_1    -19386
    x[2137]   c1307     1
    x[2137]   OBJ       20000
    x[2138]   c348_1    -19386
    x[2138]   c1308     1
    x[2138]   OBJ       30000
    x[2139]   c349_1    -19386
    x[2139]   c1309     1
    x[2139]   OBJ       30000
    x[2140]   c350_1    -19386
    x[2140]   c1310     1
    x[2140]   OBJ       30000
    x[2141]   c351_1    -19386
    x[2141]   c1311     1
    x[2141]   OBJ       45000
    x[2142]   c352_1    -19386
    x[2142]   c1312     1
    x[2142]   OBJ       20000
    x[2143]   c353_1    -19386
    x[2143]   c1313     1
    x[2143]   OBJ       30000
    x[2144]   c354_1    -19386
    x[2144]   c1314     1
    x[2144]   OBJ       5000
    x[2145]   c355_1    -19386
    x[2145]   c1315     1
    x[2145]   OBJ       15000
    x[2146]   c356_1    -19386
    x[2146]   c1316     1
    x[2146]   OBJ       5000
    x[2147]   c357_1    -19386
    x[2147]   c1317     1
    x[2147]   OBJ       35000
    x[2148]   c358_1    -19386
    x[2148]   c1318     1
    x[2148]   OBJ       25000
    x[2149]   c359_1    -19386
    x[2149]   c1319     1
    x[2149]   OBJ       5000
    x[2150]   c360_1    -19386
    x[2150]   c1320     1
    x[2150]   OBJ       45000
    x[2151]   c361_1    -19269
    x[2151]   c1201     1
    x[2151]   OBJ       25000
    x[2152]   c362_1    -19269
    x[2152]   c1202     1
    x[2152]   OBJ       30000
    x[2153]   c363_1    -19269
    x[2153]   c1203     1
    x[2153]   OBJ       35000
    x[2154]   c364_1    -19269
    x[2154]   c1204     1
    x[2154]   OBJ       15000
    x[2155]   c365_1    -19269
    x[2155]   c1205     1
    x[2155]   OBJ       25000
    x[2156]   c366_1    -19269
    x[2156]   c1206     1
    x[2156]   OBJ       10000
    x[2157]   c367_1    -19269
    x[2157]   c1207     1
    x[2157]   OBJ       25000
    x[2158]   c368_1    -19269
    x[2158]   c1208     1
    x[2158]   OBJ       15000
    x[2159]   c369_1    -19269
    x[2159]   c1209     1
    x[2159]   OBJ       5000
    x[2160]   c370_1    -19269
    x[2160]   c1210     1
    x[2160]   OBJ       35000
    x[2161]   c371_1    -19269
    x[2161]   c1211     1
    x[2161]   OBJ       25000
    x[2162]   c372_1    -19269
    x[2162]   c1212     1
    x[2162]   OBJ       10000
    x[2163]   c373_1    -19269
    x[2163]   c1213     1
    x[2163]   OBJ       15000
    x[2164]   c374_1    -19269
    x[2164]   c1214     1
    x[2164]   OBJ       5000
    x[2165]   c375_1    -19269
    x[2165]   c1215     1
    x[2165]   OBJ       10000
    x[2166]   c376_1    -19269
    x[2166]   c1216     1
    x[2166]   OBJ       45000
    x[2167]   c377_1    -19269
    x[2167]   c1217     1
    x[2167]   OBJ       15000
    x[2168]   c378_1    -19269
    x[2168]   c1218     1
    x[2168]   OBJ       45000
    x[2169]   c379_1    -19269
    x[2169]   c1219     1
    x[2169]   OBJ       45000
    x[2170]   c380_1    -19269
    x[2170]   c1220     1
    x[2170]   OBJ       10000
    x[2171]   c381_1    -19269
    x[2171]   c1221     1
    x[2171]   OBJ       35000
    x[2172]   c382_1    -19269
    x[2172]   c1222     1
    x[2172]   OBJ       45000
    x[2173]   c383_1    -19269
    x[2173]   c1223     1
    x[2173]   OBJ       15000
    x[2174]   c384_1    -19269
    x[2174]   c1224     1
    x[2174]   OBJ       25000
    x[2175]   c385_1    -19269
    x[2175]   c1225     1
    x[2175]   OBJ       10000
    x[2176]   c386_1    -19269
    x[2176]   c1226     1
    x[2176]   OBJ       25000
    x[2177]   c387_1    -19269
    x[2177]   c1227     1
    x[2177]   OBJ       35000
    x[2178]   c388_1    -19269
    x[2178]   c1228     1
    x[2178]   OBJ       45000
    x[2179]   c389_1    -19269
    x[2179]   c1229     1
    x[2179]   OBJ       25000
    x[2180]   c390_1    -19269
    x[2180]   c1230     1
    x[2180]   OBJ       35000
    x[2181]   c391_1    -19269
    x[2181]   c1231     1
    x[2181]   OBJ       25000
    x[2182]   c392_1    -19269
    x[2182]   c1232     1
    x[2182]   OBJ       5000
    x[2183]   c393_1    -19269
    x[2183]   c1233     1
    x[2183]   OBJ       15000
    x[2184]   c394_1    -19269
    x[2184]   c1234     1
    x[2184]   OBJ       45000
    x[2185]   c395_1    -19269
    x[2185]   c1235     1
    x[2185]   OBJ       20000
    x[2186]   c396_1    -19269
    x[2186]   c1236     1
    x[2186]   OBJ       15000
    x[2187]   c397_1    -19269
    x[2187]   c1237     1
    x[2187]   OBJ       35000
    x[2188]   c398_1    -19269
    x[2188]   c1238     1
    x[2188]   OBJ       5000
    x[2189]   c399_1    -19269
    x[2189]   c1239     1
    x[2189]   OBJ       30000
    x[2190]   c400_1    -19269
    x[2190]   c1240     1
    x[2190]   OBJ       35000
    x[2191]   c401_1    -19269
    x[2191]   c1241     1
    x[2191]   OBJ       40000
    x[2192]   c402_1    -19269
    x[2192]   c1242     1
    x[2192]   OBJ       40000
    x[2193]   c403_1    -19269
    x[2193]   c1243     1
    x[2193]   OBJ       40000
    x[2194]   c404_1    -19269
    x[2194]   c1244     1
    x[2194]   OBJ       35000
    x[2195]   c405_1    -19269
    x[2195]   c1245     1
    x[2195]   OBJ       25000
    x[2196]   c406_1    -19269
    x[2196]   c1246     1
    x[2196]   OBJ       25000
    x[2197]   c407_1    -19269
    x[2197]   c1247     1
    x[2197]   OBJ       35000
    x[2198]   c408_1    -19269
    x[2198]   c1248     1
    x[2198]   OBJ       10000
    x[2199]   c409_1    -19269
    x[2199]   c1249     1
    x[2199]   OBJ       25000
    x[2200]   c410_1    -19269
    x[2200]   c1250     1
    x[2200]   OBJ       35000
    x[2201]   c411_1    -19269
    x[2201]   c1251     1
    x[2201]   OBJ       15000
    x[2202]   c412_1    -19269
    x[2202]   c1252     1
    x[2202]   OBJ       15000
    x[2203]   c413_1    -19269
    x[2203]   c1253     1
    x[2203]   OBJ       40000
    x[2204]   c414_1    -19269
    x[2204]   c1254     1
    x[2204]   OBJ       45000
    x[2205]   c415_1    -19269
    x[2205]   c1255     1
    x[2205]   OBJ       40000
    x[2206]   c416_1    -19269
    x[2206]   c1256     1
    x[2206]   OBJ       40000
    x[2207]   c417_1    -19269
    x[2207]   c1257     1
    x[2207]   OBJ       40000
    x[2208]   c418_1    -19269
    x[2208]   c1258     1
    x[2208]   OBJ       25000
    x[2209]   c419_1    -19269
    x[2209]   c1259     1
    x[2209]   OBJ       35000
    x[2210]   c420_1    -19269
    x[2210]   c1260     1
    x[2210]   OBJ       20000
    x[2211]   c421_1    -19269
    x[2211]   c1261     1
    x[2211]   OBJ       40000
    x[2212]   c422_1    -19269
    x[2212]   c1262     1
    x[2212]   OBJ       30000
    x[2213]   c423_1    -19269
    x[2213]   c1263     1
    x[2213]   OBJ       10000
    x[2214]   c424_1    -19269
    x[2214]   c1264     1
    x[2214]   OBJ       20000
    x[2215]   c425_1    -19269
    x[2215]   c1265     1
    x[2215]   OBJ       10000
    x[2216]   c426_1    -19269
    x[2216]   c1266     1
    x[2216]   OBJ       15000
    x[2217]   c427_1    -19269
    x[2217]   c1267     1
    x[2217]   OBJ       5000
    x[2218]   c428_1    -19269
    x[2218]   c1268     1
    x[2218]   OBJ       45000
    x[2219]   c429_1    -19269
    x[2219]   c1269     1
    x[2219]   OBJ       5000
    x[2220]   c430_1    -19269
    x[2220]   c1270     1
    x[2220]   OBJ       10000
    x[2221]   c431_1    -19269
    x[2221]   c1271     1
    x[2221]   OBJ       10000
    x[2222]   c432_1    -19269
    x[2222]   c1272     1
    x[2222]   OBJ       40000
    x[2223]   c433_1    -19269
    x[2223]   c1273     1
    x[2223]   OBJ       15000
    x[2224]   c434_1    -19269
    x[2224]   c1274     1
    x[2224]   OBJ       45000
    x[2225]   c435_1    -19269
    x[2225]   c1275     1
    x[2225]   OBJ       35000
    x[2226]   c436_1    -19269
    x[2226]   c1276     1
    x[2226]   OBJ       45000
    x[2227]   c437_1    -19269
    x[2227]   c1277     1
    x[2227]   OBJ       10000
    x[2228]   c438_1    -19269
    x[2228]   c1278     1
    x[2228]   OBJ       15000
    x[2229]   c439_1    -19269
    x[2229]   c1279     1
    x[2229]   OBJ       30000
    x[2230]   c440_1    -19269
    x[2230]   c1280     1
    x[2230]   OBJ       40000
    x[2231]   c441_1    -19269
    x[2231]   c1281     1
    x[2231]   OBJ       5000
    x[2232]   c442_1    -19269
    x[2232]   c1282     1
    x[2232]   OBJ       5000
    x[2233]   c443_1    -19269
    x[2233]   c1283     1
    x[2233]   OBJ       40000
    x[2234]   c444_1    -19269
    x[2234]   c1284     1
    x[2234]   OBJ       20000
    x[2235]   c445_1    -19269
    x[2235]   c1285     1
    x[2235]   OBJ       30000
    x[2236]   c446_1    -19269
    x[2236]   c1286     1
    x[2236]   OBJ       25000
    x[2237]   c447_1    -19269
    x[2237]   c1287     1
    x[2237]   OBJ       15000
    x[2238]   c448_1    -19269
    x[2238]   c1288     1
    x[2238]   OBJ       35000
    x[2239]   c449_1    -19269
    x[2239]   c1289     1
    x[2239]   OBJ       35000
    x[2240]   c450_1    -19269
    x[2240]   c1290     1
    x[2240]   OBJ       30000
    x[2241]   c451_1    -19269
    x[2241]   c1291     1
    x[2241]   OBJ       15000
    x[2242]   c452_1    -19269
    x[2242]   c1292     1
    x[2242]   OBJ       20000
    x[2243]   c453_1    -19269
    x[2243]   c1293     1
    x[2243]   OBJ       35000
    x[2244]   c454_1    -19269
    x[2244]   c1294     1
    x[2244]   OBJ       5000
    x[2245]   c455_1    -19269
    x[2245]   c1295     1
    x[2245]   OBJ       15000
    x[2246]   c456_1    -19269
    x[2246]   c1296     1
    x[2246]   OBJ       20000
    x[2247]   c457_1    -19269
    x[2247]   c1297     1
    x[2247]   OBJ       30000
    x[2248]   c458_1    -19269
    x[2248]   c1298     1
    x[2248]   OBJ       15000
    x[2249]   c459_1    -19269
    x[2249]   c1299     1
    x[2249]   OBJ       40000
    x[2250]   c460_1    -19269
    x[2250]   c1300     1
    x[2250]   OBJ       20000
    x[2251]   c461_1    -19269
    x[2251]   c1301     1
    x[2251]   OBJ       25000
    x[2252]   c462_1    -19269
    x[2252]   c1302     1
    x[2252]   OBJ       25000
    x[2253]   c463_1    -19269
    x[2253]   c1303     1
    x[2253]   OBJ       5000
    x[2254]   c464_1    -19269
    x[2254]   c1304     1
    x[2254]   OBJ       40000
    x[2255]   c465_1    -19269
    x[2255]   c1305     1
    x[2255]   OBJ       20000
    x[2256]   c466_1    -19269
    x[2256]   c1306     1
    x[2256]   OBJ       40000
    x[2257]   c467_1    -19269
    x[2257]   c1307     1
    x[2257]   OBJ       5000
    x[2258]   c468_1    -19269
    x[2258]   c1308     1
    x[2258]   OBJ       25000
    x[2259]   c469_1    -19269
    x[2259]   c1309     1
    x[2259]   OBJ       25000
    x[2260]   c470_1    -19269
    x[2260]   c1310     1
    x[2260]   OBJ       30000
    x[2261]   c471_1    -19269
    x[2261]   c1311     1
    x[2261]   OBJ       5000
    x[2262]   c472_1    -19269
    x[2262]   c1312     1
    x[2262]   OBJ       45000
    x[2263]   c473_1    -19269
    x[2263]   c1313     1
    x[2263]   OBJ       15000
    x[2264]   c474_1    -19269
    x[2264]   c1314     1
    x[2264]   OBJ       10000
    x[2265]   c475_1    -19269
    x[2265]   c1315     1
    x[2265]   OBJ       20000
    x[2266]   c476_1    -19269
    x[2266]   c1316     1
    x[2266]   OBJ       5000
    x[2267]   c477_1    -19269
    x[2267]   c1317     1
    x[2267]   OBJ       45000
    x[2268]   c478_1    -19269
    x[2268]   c1318     1
    x[2268]   OBJ       10000
    x[2269]   c479_1    -19269
    x[2269]   c1319     1
    x[2269]   OBJ       5000
    x[2270]   c480_1    -19269
    x[2270]   c1320     1
    x[2270]   OBJ       15000
    x[2271]   c481_1    -20019
    x[2271]   c1201     1
    x[2271]   OBJ       30000
    x[2272]   c482_1    -20019
    x[2272]   c1202     1
    x[2272]   OBJ       5000
    x[2273]   c483_1    -20019
    x[2273]   c1203     1
    x[2273]   OBJ       5000
    x[2274]   c484_1    -20019
    x[2274]   c1204     1
    x[2274]   OBJ       15000
    x[2275]   c485_1    -20019
    x[2275]   c1205     1
    x[2275]   OBJ       5000
    x[2276]   c486_1    -20019
    x[2276]   c1206     1
    x[2276]   OBJ       15000
    x[2277]   c487_1    -20019
    x[2277]   c1207     1
    x[2277]   OBJ       20000
    x[2278]   c488_1    -20019
    x[2278]   c1208     1
    x[2278]   OBJ       25000
    x[2279]   c489_1    -20019
    x[2279]   c1209     1
    x[2279]   OBJ       35000
    x[2280]   c490_1    -20019
    x[2280]   c1210     1
    x[2280]   OBJ       25000
    x[2281]   c491_1    -20019
    x[2281]   c1211     1
    x[2281]   OBJ       20000
    x[2282]   c492_1    -20019
    x[2282]   c1212     1
    x[2282]   OBJ       5000
    x[2283]   c493_1    -20019
    x[2283]   c1213     1
    x[2283]   OBJ       15000
    x[2284]   c494_1    -20019
    x[2284]   c1214     1
    x[2284]   OBJ       15000
    x[2285]   c495_1    -20019
    x[2285]   c1215     1
    x[2285]   OBJ       25000
    x[2286]   c496_1    -20019
    x[2286]   c1216     1
    x[2286]   OBJ       5000
    x[2287]   c497_1    -20019
    x[2287]   c1217     1
    x[2287]   OBJ       5000
    x[2288]   c498_1    -20019
    x[2288]   c1218     1
    x[2288]   OBJ       20000
    x[2289]   c499_1    -20019
    x[2289]   c1219     1
    x[2289]   OBJ       30000
    x[2290]   c500_1    -20019
    x[2290]   c1220     1
    x[2290]   OBJ       45000
    x[2291]   c501_1    -20019
    x[2291]   c1221     1
    x[2291]   OBJ       40000
    x[2292]   c502_1    -20019
    x[2292]   c1222     1
    x[2292]   OBJ       5000
    x[2293]   c503_1    -20019
    x[2293]   c1223     1
    x[2293]   OBJ       15000
    x[2294]   c504_1    -20019
    x[2294]   c1224     1
    x[2294]   OBJ       5000
    x[2295]   c505_1    -20019
    x[2295]   c1225     1
    x[2295]   OBJ       25000
    x[2296]   c506_1    -20019
    x[2296]   c1226     1
    x[2296]   OBJ       20000
    x[2297]   c507_1    -20019
    x[2297]   c1227     1
    x[2297]   OBJ       35000
    x[2298]   c508_1    -20019
    x[2298]   c1228     1
    x[2298]   OBJ       5000
    x[2299]   c509_1    -20019
    x[2299]   c1229     1
    x[2299]   OBJ       35000
    x[2300]   c510_1    -20019
    x[2300]   c1230     1
    x[2300]   OBJ       40000
    x[2301]   c511_1    -20019
    x[2301]   c1231     1
    x[2301]   OBJ       5000
    x[2302]   c512_1    -20019
    x[2302]   c1232     1
    x[2302]   OBJ       5000
    x[2303]   c513_1    -20019
    x[2303]   c1233     1
    x[2303]   OBJ       40000
    x[2304]   c514_1    -20019
    x[2304]   c1234     1
    x[2304]   OBJ       30000
    x[2305]   c515_1    -20019
    x[2305]   c1235     1
    x[2305]   OBJ       45000
    x[2306]   c516_1    -20019
    x[2306]   c1236     1
    x[2306]   OBJ       30000
    x[2307]   c517_1    -20019
    x[2307]   c1237     1
    x[2307]   OBJ       40000
    x[2308]   c518_1    -20019
    x[2308]   c1238     1
    x[2308]   OBJ       5000
    x[2309]   c519_1    -20019
    x[2309]   c1239     1
    x[2309]   OBJ       45000
    x[2310]   c520_1    -20019
    x[2310]   c1240     1
    x[2310]   OBJ       5000
    x[2311]   c521_1    -20019
    x[2311]   c1241     1
    x[2311]   OBJ       25000
    x[2312]   c522_1    -20019
    x[2312]   c1242     1
    x[2312]   OBJ       40000
    x[2313]   c523_1    -20019
    x[2313]   c1243     1
    x[2313]   OBJ       40000
    x[2314]   c524_1    -20019
    x[2314]   c1244     1
    x[2314]   OBJ       5000
    x[2315]   c525_1    -20019
    x[2315]   c1245     1
    x[2315]   OBJ       30000
    x[2316]   c526_1    -20019
    x[2316]   c1246     1
    x[2316]   OBJ       35000
    x[2317]   c527_1    -20019
    x[2317]   c1247     1
    x[2317]   OBJ       35000
    x[2318]   c528_1    -20019
    x[2318]   c1248     1
    x[2318]   OBJ       10000
    x[2319]   c529_1    -20019
    x[2319]   c1249     1
    x[2319]   OBJ       10000
    x[2320]   c530_1    -20019
    x[2320]   c1250     1
    x[2320]   OBJ       30000
    x[2321]   c531_1    -20019
    x[2321]   c1251     1
    x[2321]   OBJ       40000
    x[2322]   c532_1    -20019
    x[2322]   c1252     1
    x[2322]   OBJ       35000
    x[2323]   c533_1    -20019
    x[2323]   c1253     1
    x[2323]   OBJ       5000
    x[2324]   c534_1    -20019
    x[2324]   c1254     1
    x[2324]   OBJ       10000
    x[2325]   c535_1    -20019
    x[2325]   c1255     1
    x[2325]   OBJ       5000
    x[2326]   c536_1    -20019
    x[2326]   c1256     1
    x[2326]   OBJ       15000
    x[2327]   c537_1    -20019
    x[2327]   c1257     1
    x[2327]   OBJ       30000
    x[2328]   c538_1    -20019
    x[2328]   c1258     1
    x[2328]   OBJ       20000
    x[2329]   c539_1    -20019
    x[2329]   c1259     1
    x[2329]   OBJ       25000
    x[2330]   c540_1    -20019
    x[2330]   c1260     1
    x[2330]   OBJ       10000
    x[2331]   c541_1    -20019
    x[2331]   c1261     1
    x[2331]   OBJ       15000
    x[2332]   c542_1    -20019
    x[2332]   c1262     1
    x[2332]   OBJ       35000
    x[2333]   c543_1    -20019
    x[2333]   c1263     1
    x[2333]   OBJ       15000
    x[2334]   c544_1    -20019
    x[2334]   c1264     1
    x[2334]   OBJ       5000
    x[2335]   c545_1    -20019
    x[2335]   c1265     1
    x[2335]   OBJ       5000
    x[2336]   c546_1    -20019
    x[2336]   c1266     1
    x[2336]   OBJ       30000
    x[2337]   c547_1    -20019
    x[2337]   c1267     1
    x[2337]   OBJ       40000
    x[2338]   c548_1    -20019
    x[2338]   c1268     1
    x[2338]   OBJ       20000
    x[2339]   c549_1    -20019
    x[2339]   c1269     1
    x[2339]   OBJ       35000
    x[2340]   c550_1    -20019
    x[2340]   c1270     1
    x[2340]   OBJ       5000
    x[2341]   c551_1    -20019
    x[2341]   c1271     1
    x[2341]   OBJ       10000
    x[2342]   c552_1    -20019
    x[2342]   c1272     1
    x[2342]   OBJ       25000
    x[2343]   c553_1    -20019
    x[2343]   c1273     1
    x[2343]   OBJ       15000
    x[2344]   c554_1    -20019
    x[2344]   c1274     1
    x[2344]   OBJ       45000
    x[2345]   c555_1    -20019
    x[2345]   c1275     1
    x[2345]   OBJ       10000
    x[2346]   c556_1    -20019
    x[2346]   c1276     1
    x[2346]   OBJ       20000
    x[2347]   c557_1    -20019
    x[2347]   c1277     1
    x[2347]   OBJ       5000
    x[2348]   c558_1    -20019
    x[2348]   c1278     1
    x[2348]   OBJ       20000
    x[2349]   c559_1    -20019
    x[2349]   c1279     1
    x[2349]   OBJ       15000
    x[2350]   c560_1    -20019
    x[2350]   c1280     1
    x[2350]   OBJ       5000
    x[2351]   c561_1    -20019
    x[2351]   c1281     1
    x[2351]   OBJ       20000
    x[2352]   c562_1    -20019
    x[2352]   c1282     1
    x[2352]   OBJ       5000
    x[2353]   c563_1    -20019
    x[2353]   c1283     1
    x[2353]   OBJ       30000
    x[2354]   c564_1    -20019
    x[2354]   c1284     1
    x[2354]   OBJ       25000
    x[2355]   c565_1    -20019
    x[2355]   c1285     1
    x[2355]   OBJ       15000
    x[2356]   c566_1    -20019
    x[2356]   c1286     1
    x[2356]   OBJ       5000
    x[2357]   c567_1    -20019
    x[2357]   c1287     1
    x[2357]   OBJ       35000
    x[2358]   c568_1    -20019
    x[2358]   c1288     1
    x[2358]   OBJ       20000
    x[2359]   c569_1    -20019
    x[2359]   c1289     1
    x[2359]   OBJ       35000
    x[2360]   c570_1    -20019
    x[2360]   c1290     1
    x[2360]   OBJ       20000
    x[2361]   c571_1    -20019
    x[2361]   c1291     1
    x[2361]   OBJ       15000
    x[2362]   c572_1    -20019
    x[2362]   c1292     1
    x[2362]   OBJ       45000
    x[2363]   c573_1    -20019
    x[2363]   c1293     1
    x[2363]   OBJ       25000
    x[2364]   c574_1    -20019
    x[2364]   c1294     1
    x[2364]   OBJ       5000
    x[2365]   c575_1    -20019
    x[2365]   c1295     1
    x[2365]   OBJ       10000
    x[2366]   c576_1    -20019
    x[2366]   c1296     1
    x[2366]   OBJ       20000
    x[2367]   c577_1    -20019
    x[2367]   c1297     1
    x[2367]   OBJ       5000
    x[2368]   c578_1    -20019
    x[2368]   c1298     1
    x[2368]   OBJ       35000
    x[2369]   c579_1    -20019
    x[2369]   c1299     1
    x[2369]   OBJ       15000
    x[2370]   c580_1    -20019
    x[2370]   c1300     1
    x[2370]   OBJ       15000
    x[2371]   c581_1    -20019
    x[2371]   c1301     1
    x[2371]   OBJ       10000
    x[2372]   c582_1    -20019
    x[2372]   c1302     1
    x[2372]   OBJ       40000
    x[2373]   c583_1    -20019
    x[2373]   c1303     1
    x[2373]   OBJ       45000
    x[2374]   c584_1    -20019
    x[2374]   c1304     1
    x[2374]   OBJ       15000
    x[2375]   c585_1    -20019
    x[2375]   c1305     1
    x[2375]   OBJ       40000
    x[2376]   c586_1    -20019
    x[2376]   c1306     1
    x[2376]   OBJ       25000
    x[2377]   c587_1    -20019
    x[2377]   c1307     1
    x[2377]   OBJ       20000
    x[2378]   c588_1    -20019
    x[2378]   c1308     1
    x[2378]   OBJ       10000
    x[2379]   c589_1    -20019
    x[2379]   c1309     1
    x[2379]   OBJ       40000
    x[2380]   c590_1    -20019
    x[2380]   c1310     1
    x[2380]   OBJ       40000
    x[2381]   c591_1    -20019
    x[2381]   c1311     1
    x[2381]   OBJ       5000
    x[2382]   c592_1    -20019
    x[2382]   c1312     1
    x[2382]   OBJ       40000
    x[2383]   c593_1    -20019
    x[2383]   c1313     1
    x[2383]   OBJ       25000
    x[2384]   c594_1    -20019
    x[2384]   c1314     1
    x[2384]   OBJ       5000
    x[2385]   c595_1    -20019
    x[2385]   c1315     1
    x[2385]   OBJ       30000
    x[2386]   c596_1    -20019
    x[2386]   c1316     1
    x[2386]   OBJ       35000
    x[2387]   c597_1    -20019
    x[2387]   c1317     1
    x[2387]   OBJ       30000
    x[2388]   c598_1    -20019
    x[2388]   c1318     1
    x[2388]   OBJ       45000
    x[2389]   c599_1    -20019
    x[2389]   c1319     1
    x[2389]   OBJ       30000
    x[2390]   c600_1    -20019
    x[2390]   c1320     1
    x[2390]   OBJ       20000
    x[2391]   c601_1    -18298
    x[2391]   c1196     1
    x[2392]   c602_1    -18298
    x[2392]   c1196     1
    x[2393]   c603_1    -18298
    x[2393]   c1196     1
    x[2394]   c604_1    -18298
    x[2394]   c1196     1
    x[2395]   c605_1    -18298
    x[2395]   c1196     1
    x[2396]   c606_1    -18298
    x[2396]   c1196     1
    x[2397]   c607_1    -18298
    x[2397]   c1196     1
    x[2398]   c608_1    -18298
    x[2398]   c1196     1
    x[2399]   c609_1    -18298
    x[2399]   c1196     1
    x[2400]   c610_1    -18298
    x[2400]   c1196     1
    x[2401]   c611_1    -18298
    x[2401]   c1196     1
    x[2402]   c612_1    -18298
    x[2402]   c1196     1
    x[2403]   c613_1    -18298
    x[2403]   c1196     1
    x[2404]   c614_1    -18298
    x[2404]   c1196     1
    x[2405]   c615_1    -18298
    x[2405]   c1196     1
    x[2406]   c616_1    -18298
    x[2406]   c1196     1
    x[2407]   c617_1    -18298
    x[2407]   c1196     1
    x[2408]   c618_1    -18298
    x[2408]   c1196     1
    x[2409]   c619_1    -18298
    x[2409]   c1196     1
    x[2410]   c620_1    -18298
    x[2410]   c1196     1
    x[2411]   c621_1    -18298
    x[2411]   c1196     1
    x[2412]   c622_1    -18298
    x[2412]   c1196     1
    x[2413]   c623_1    -18298
    x[2413]   c1196     1
    x[2414]   c624_1    -18298
    x[2414]   c1196     1
    x[2415]   c625      -18298
    x[2415]   c1196     1
    x[2416]   c626      -18298
    x[2416]   c1196     1
    x[2417]   c627      -18298
    x[2417]   c1196     1
    x[2418]   c628      -18298
    x[2418]   c1196     1
    x[2419]   c629      -18298
    x[2419]   c1196     1
    x[2420]   c630      -18298
    x[2420]   c1196     1
    x[2421]   c631      -18298
    x[2421]   c1196     1
    x[2422]   c632      -18298
    x[2422]   c1196     1
    x[2423]   c633      -18298
    x[2423]   c1196     1
    x[2424]   c634      -18298
    x[2424]   c1196     1
    x[2425]   c635      -18298
    x[2425]   c1196     1
    x[2426]   c636      -18298
    x[2426]   c1196     1
    x[2427]   c637      -18298
    x[2427]   c1196     1
    x[2428]   c638      -18298
    x[2428]   c1196     1
    x[2429]   c639      -18298
    x[2429]   c1196     1
    x[2430]   c640      -18298
    x[2430]   c1196     1
    x[2431]   c641      -18298
    x[2431]   c1196     1
    x[2432]   c642      -18298
    x[2432]   c1196     1
    x[2433]   c643      -18298
    x[2433]   c1196     1
    x[2434]   c644      -18298
    x[2434]   c1196     1
    x[2435]   c645      -18298
    x[2435]   c1196     1
    x[2436]   c646      -18298
    x[2436]   c1196     1
    x[2437]   c647      -18298
    x[2437]   c1196     1
    x[2438]   c648      -18298
    x[2438]   c1196     1
    x[2439]   c649      -18298
    x[2439]   c1196     1
    x[2440]   c650      -18298
    x[2440]   c1196     1
    x[2441]   c651      -18298
    x[2441]   c1196     1
    x[2442]   c652      -18298
    x[2442]   c1196     1
    x[2443]   c653      -18298
    x[2443]   c1196     1
    x[2444]   c654      -18298
    x[2444]   c1196     1
    x[2445]   c655      -18298
    x[2445]   c1196     1
    x[2446]   c656      -18298
    x[2446]   c1196     1
    x[2447]   c657      -18298
    x[2447]   c1196     1
    x[2448]   c658      -18298
    x[2448]   c1196     1
    x[2449]   c659      -18298
    x[2449]   c1196     1
    x[2450]   c660      -18298
    x[2450]   c1196     1
    x[2451]   c661      -18298
    x[2451]   c1196     1
    x[2452]   c662      -18298
    x[2452]   c1196     1
    x[2453]   c663      -18298
    x[2453]   c1196     1
    x[2454]   c664      -18298
    x[2454]   c1196     1
    x[2455]   c665      -18298
    x[2455]   c1196     1
    x[2456]   c666      -18298
    x[2456]   c1196     1
    x[2457]   c667      -18298
    x[2457]   c1196     1
    x[2458]   c668      -18298
    x[2458]   c1196     1
    x[2459]   c669      -18298
    x[2459]   c1196     1
    x[2460]   c670      -18298
    x[2460]   c1196     1
    x[2461]   c671      -18298
    x[2461]   c1196     1
    x[2462]   c672      -18298
    x[2462]   c1196     1
    x[2463]   c673      -18298
    x[2463]   c1196     1
    x[2464]   c674      -18298
    x[2464]   c1196     1
    x[2465]   c675      -18298
    x[2465]   c1196     1
    x[2466]   c676      -18298
    x[2466]   c1196     1
    x[2467]   c677      -18298
    x[2467]   c1196     1
    x[2468]   c678      -18298
    x[2468]   c1196     1
    x[2469]   c679      -18298
    x[2469]   c1196     1
    x[2470]   c680      -18298
    x[2470]   c1196     1
    x[2471]   c681      -18298
    x[2471]   c1196     1
    x[2472]   c682      -18298
    x[2472]   c1196     1
    x[2473]   c683      -18298
    x[2473]   c1196     1
    x[2474]   c684      -18298
    x[2474]   c1196     1
    x[2475]   c685      -18298
    x[2475]   c1196     1
    x[2476]   c686      -18298
    x[2476]   c1196     1
    x[2477]   c687      -18298
    x[2477]   c1196     1
    x[2478]   c688      -18298
    x[2478]   c1196     1
    x[2479]   c689      -18298
    x[2479]   c1196     1
    x[2480]   c690      -18298
    x[2480]   c1196     1
    x[2481]   c691      -18298
    x[2481]   c1196     1
    x[2482]   c692      -18298
    x[2482]   c1196     1
    x[2483]   c693      -18298
    x[2483]   c1196     1
    x[2484]   c694      -18298
    x[2484]   c1196     1
    x[2485]   c695      -18298
    x[2485]   c1196     1
    x[2486]   c696      -18298
    x[2486]   c1196     1
    x[2487]   c697      -18298
    x[2487]   c1196     1
    x[2488]   c698      -18298
    x[2488]   c1196     1
    x[2489]   c699      -18298
    x[2489]   c1196     1
    x[2490]   c700      -18298
    x[2490]   c1196     1
    x[2491]   c701      -18298
    x[2491]   c1196     1
    x[2492]   c702      -18298
    x[2492]   c1196     1
    x[2493]   c703      -18298
    x[2493]   c1196     1
    x[2494]   c704      -18298
    x[2494]   c1196     1
    x[2495]   c705      -18298
    x[2495]   c1196     1
    x[2496]   c706      -18298
    x[2496]   c1196     1
    x[2497]   c707      -18298
    x[2497]   c1196     1
    x[2498]   c708      -18298
    x[2498]   c1196     1
    x[2499]   c709      -18298
    x[2499]   c1196     1
    x[2500]   c710      -18298
    x[2500]   c1196     1
    x[2501]   c711      -18298
    x[2501]   c1196     1
    x[2502]   c712      -18298
    x[2502]   c1196     1
    x[2503]   c713      -18298
    x[2503]   c1196     1
    x[2504]   c714      -18298
    x[2504]   c1196     1
    x[2505]   c715      -18298
    x[2505]   c1196     1
    x[2506]   c716      -18298
    x[2506]   c1196     1
    x[2507]   c717      -18298
    x[2507]   c1196     1
    x[2508]   c718      -18298
    x[2508]   c1196     1
    x[2509]   c719      -18298
    x[2509]   c1196     1
    x[2510]   c720      -16531
    x[2510]   c1197     1
    x[2511]   c721      -16531
    x[2511]   c1197     1
    x[2512]   c722      -16531
    x[2512]   c1197     1
    x[2513]   c723      -16531
    x[2513]   c1197     1
    x[2514]   c724      -16531
    x[2514]   c1197     1
    x[2515]   c725      -16531
    x[2515]   c1197     1
    x[2516]   c726      -16531
    x[2516]   c1197     1
    x[2517]   c727      -16531
    x[2517]   c1197     1
    x[2518]   c728      -16531
    x[2518]   c1197     1
    x[2519]   c729      -16531
    x[2519]   c1197     1
    x[2520]   c730      -16531
    x[2520]   c1197     1
    x[2521]   c731      -16531
    x[2521]   c1197     1
    x[2522]   c732      -16531
    x[2522]   c1197     1
    x[2523]   c733      -16531
    x[2523]   c1197     1
    x[2524]   c734      -16531
    x[2524]   c1197     1
    x[2525]   c735      -16531
    x[2525]   c1197     1
    x[2526]   c736      -16531
    x[2526]   c1197     1
    x[2527]   c737      -16531
    x[2527]   c1197     1
    x[2528]   c738      -16531
    x[2528]   c1197     1
    x[2529]   c739      -16531
    x[2529]   c1197     1
    x[2530]   c740      -16531
    x[2530]   c1197     1
    x[2531]   c741      -16531
    x[2531]   c1197     1
    x[2532]   c742      -16531
    x[2532]   c1197     1
    x[2533]   c743      -16531
    x[2533]   c1197     1
    x[2534]   c744      -16531
    x[2534]   c1197     1
    x[2535]   c745      -16531
    x[2535]   c1197     1
    x[2536]   c746      -16531
    x[2536]   c1197     1
    x[2537]   c747      -16531
    x[2537]   c1197     1
    x[2538]   c748      -16531
    x[2538]   c1197     1
    x[2539]   c749      -16531
    x[2539]   c1197     1
    x[2540]   c750      -16531
    x[2540]   c1197     1
    x[2541]   c751      -16531
    x[2541]   c1197     1
    x[2542]   c752      -16531
    x[2542]   c1197     1
    x[2543]   c753      -16531
    x[2543]   c1197     1
    x[2544]   c754      -16531
    x[2544]   c1197     1
    x[2545]   c755      -16531
    x[2545]   c1197     1
    x[2546]   c756      -16531
    x[2546]   c1197     1
    x[2547]   c757      -16531
    x[2547]   c1197     1
    x[2548]   c758      -16531
    x[2548]   c1197     1
    x[2549]   c759      -16531
    x[2549]   c1197     1
    x[2550]   c760      -16531
    x[2550]   c1197     1
    x[2551]   c761      -16531
    x[2551]   c1197     1
    x[2552]   c762      -16531
    x[2552]   c1197     1
    x[2553]   c763      -16531
    x[2553]   c1197     1
    x[2554]   c764      -16531
    x[2554]   c1197     1
    x[2555]   c765      -16531
    x[2555]   c1197     1
    x[2556]   c766      -16531
    x[2556]   c1197     1
    x[2557]   c767      -16531
    x[2557]   c1197     1
    x[2558]   c768      -16531
    x[2558]   c1197     1
    x[2559]   c769      -16531
    x[2559]   c1197     1
    x[2560]   c770      -16531
    x[2560]   c1197     1
    x[2561]   c771      -16531
    x[2561]   c1197     1
    x[2562]   c772      -16531
    x[2562]   c1197     1
    x[2563]   c773      -16531
    x[2563]   c1197     1
    x[2564]   c774      -16531
    x[2564]   c1197     1
    x[2565]   c775      -16531
    x[2565]   c1197     1
    x[2566]   c776      -16531
    x[2566]   c1197     1
    x[2567]   c777      -16531
    x[2567]   c1197     1
    x[2568]   c778      -16531
    x[2568]   c1197     1
    x[2569]   c779      -16531
    x[2569]   c1197     1
    x[2570]   c780      -16531
    x[2570]   c1197     1
    x[2571]   c781      -16531
    x[2571]   c1197     1
    x[2572]   c782      -16531
    x[2572]   c1197     1
    x[2573]   c783      -16531
    x[2573]   c1197     1
    x[2574]   c784      -16531
    x[2574]   c1197     1
    x[2575]   c785      -16531
    x[2575]   c1197     1
    x[2576]   c786      -16531
    x[2576]   c1197     1
    x[2577]   c787      -16531
    x[2577]   c1197     1
    x[2578]   c788      -16531
    x[2578]   c1197     1
    x[2579]   c789      -16531
    x[2579]   c1197     1
    x[2580]   c790      -16531
    x[2580]   c1197     1
    x[2581]   c791      -16531
    x[2581]   c1197     1
    x[2582]   c792      -16531
    x[2582]   c1197     1
    x[2583]   c793      -16531
    x[2583]   c1197     1
    x[2584]   c794      -16531
    x[2584]   c1197     1
    x[2585]   c795      -16531
    x[2585]   c1197     1
    x[2586]   c796      -16531
    x[2586]   c1197     1
    x[2587]   c797      -16531
    x[2587]   c1197     1
    x[2588]   c798      -16531
    x[2588]   c1197     1
    x[2589]   c799      -16531
    x[2589]   c1197     1
    x[2590]   c800      -16531
    x[2590]   c1197     1
    x[2591]   c801      -16531
    x[2591]   c1197     1
    x[2592]   c802      -16531
    x[2592]   c1197     1
    x[2593]   c803      -16531
    x[2593]   c1197     1
    x[2594]   c804      -16531
    x[2594]   c1197     1
    x[2595]   c805      -16531
    x[2595]   c1197     1
    x[2596]   c806      -16531
    x[2596]   c1197     1
    x[2597]   c807      -16531
    x[2597]   c1197     1
    x[2598]   c808      -16531
    x[2598]   c1197     1
    x[2599]   c809      -16531
    x[2599]   c1197     1
    x[2600]   c810      -16531
    x[2600]   c1197     1
    x[2601]   c811      -16531
    x[2601]   c1197     1
    x[2602]   c812      -16531
    x[2602]   c1197     1
    x[2603]   c813      -16531
    x[2603]   c1197     1
    x[2604]   c814      -16531
    x[2604]   c1197     1
    x[2605]   c815      -16531
    x[2605]   c1197     1
    x[2606]   c816      -16531
    x[2606]   c1197     1
    x[2607]   c817      -16531
    x[2607]   c1197     1
    x[2608]   c818      -16531
    x[2608]   c1197     1
    x[2609]   c819      -16531
    x[2609]   c1197     1
    x[2610]   c820      -16531
    x[2610]   c1197     1
    x[2611]   c821      -16531
    x[2611]   c1197     1
    x[2612]   c822      -16531
    x[2612]   c1197     1
    x[2613]   c823      -16531
    x[2613]   c1197     1
    x[2614]   c824      -16531
    x[2614]   c1197     1
    x[2615]   c825      -16531
    x[2615]   c1197     1
    x[2616]   c826      -16531
    x[2616]   c1197     1
    x[2617]   c827      -16531
    x[2617]   c1197     1
    x[2618]   c828      -16531
    x[2618]   c1197     1
    x[2619]   c829      -16531
    x[2619]   c1197     1
    x[2620]   c830      -16531
    x[2620]   c1197     1
    x[2621]   c831      -16531
    x[2621]   c1197     1
    x[2622]   c832      -16531
    x[2622]   c1197     1
    x[2623]   c833      -16531
    x[2623]   c1197     1
    x[2624]   c834      -16531
    x[2624]   c1197     1
    x[2625]   c835      -16531
    x[2625]   c1197     1
    x[2626]   c836      -16531
    x[2626]   c1197     1
    x[2627]   c837      -16531
    x[2627]   c1197     1
    x[2628]   c838      -16531
    x[2628]   c1197     1
    x[2629]   c839      -19386
    x[2629]   c1198     1
    x[2630]   c840      -19386
    x[2630]   c1198     1
    x[2631]   c841      -19386
    x[2631]   c1198     1
    x[2632]   c842      -19386
    x[2632]   c1198     1
    x[2633]   c843      -19386
    x[2633]   c1198     1
    x[2634]   c844      -19386
    x[2634]   c1198     1
    x[2635]   c845      -19386
    x[2635]   c1198     1
    x[2636]   c846      -19386
    x[2636]   c1198     1
    x[2637]   c847      -19386
    x[2637]   c1198     1
    x[2638]   c848      -19386
    x[2638]   c1198     1
    x[2639]   c849      -19386
    x[2639]   c1198     1
    x[2640]   c850      -19386
    x[2640]   c1198     1
    x[2641]   c851      -19386
    x[2641]   c1198     1
    x[2642]   c852      -19386
    x[2642]   c1198     1
    x[2643]   c853      -19386
    x[2643]   c1198     1
    x[2644]   c854      -19386
    x[2644]   c1198     1
    x[2645]   c855      -19386
    x[2645]   c1198     1
    x[2646]   c856      -19386
    x[2646]   c1198     1
    x[2647]   c857      -19386
    x[2647]   c1198     1
    x[2648]   c858      -19386
    x[2648]   c1198     1
    x[2649]   c859      -19386
    x[2649]   c1198     1
    x[2650]   c860      -19386
    x[2650]   c1198     1
    x[2651]   c861      -19386
    x[2651]   c1198     1
    x[2652]   c862      -19386
    x[2652]   c1198     1
    x[2653]   c863      -19386
    x[2653]   c1198     1
    x[2654]   c864      -19386
    x[2654]   c1198     1
    x[2655]   c865      -19386
    x[2655]   c1198     1
    x[2656]   c866      -19386
    x[2656]   c1198     1
    x[2657]   c867      -19386
    x[2657]   c1198     1
    x[2658]   c868      -19386
    x[2658]   c1198     1
    x[2659]   c869      -19386
    x[2659]   c1198     1
    x[2660]   c870      -19386
    x[2660]   c1198     1
    x[2661]   c871      -19386
    x[2661]   c1198     1
    x[2662]   c872      -19386
    x[2662]   c1198     1
    x[2663]   c873      -19386
    x[2663]   c1198     1
    x[2664]   c874      -19386
    x[2664]   c1198     1
    x[2665]   c875      -19386
    x[2665]   c1198     1
    x[2666]   c876      -19386
    x[2666]   c1198     1
    x[2667]   c877      -19386
    x[2667]   c1198     1
    x[2668]   c878      -19386
    x[2668]   c1198     1
    x[2669]   c879      -19386
    x[2669]   c1198     1
    x[2670]   c880      -19386
    x[2670]   c1198     1
    x[2671]   c881      -19386
    x[2671]   c1198     1
    x[2672]   c882      -19386
    x[2672]   c1198     1
    x[2673]   c883      -19386
    x[2673]   c1198     1
    x[2674]   c884      -19386
    x[2674]   c1198     1
    x[2675]   c885      -19386
    x[2675]   c1198     1
    x[2676]   c886      -19386
    x[2676]   c1198     1
    x[2677]   c887      -19386
    x[2677]   c1198     1
    x[2678]   c888      -19386
    x[2678]   c1198     1
    x[2679]   c889      -19386
    x[2679]   c1198     1
    x[2680]   c890      -19386
    x[2680]   c1198     1
    x[2681]   c891      -19386
    x[2681]   c1198     1
    x[2682]   c892      -19386
    x[2682]   c1198     1
    x[2683]   c893      -19386
    x[2683]   c1198     1
    x[2684]   c894      -19386
    x[2684]   c1198     1
    x[2685]   c895      -19386
    x[2685]   c1198     1
    x[2686]   c896      -19386
    x[2686]   c1198     1
    x[2687]   c897      -19386
    x[2687]   c1198     1
    x[2688]   c898      -19386
    x[2688]   c1198     1
    x[2689]   c899      -19386
    x[2689]   c1198     1
    x[2690]   c900      -19386
    x[2690]   c1198     1
    x[2691]   c901      -19386
    x[2691]   c1198     1
    x[2692]   c902      -19386
    x[2692]   c1198     1
    x[2693]   c903      -19386
    x[2693]   c1198     1
    x[2694]   c904      -19386
    x[2694]   c1198     1
    x[2695]   c905      -19386
    x[2695]   c1198     1
    x[2696]   c906      -19386
    x[2696]   c1198     1
    x[2697]   c907      -19386
    x[2697]   c1198     1
    x[2698]   c908      -19386
    x[2698]   c1198     1
    x[2699]   c909      -19386
    x[2699]   c1198     1
    x[2700]   c910      -19386
    x[2700]   c1198     1
    x[2701]   c911      -19386
    x[2701]   c1198     1
    x[2702]   c912      -19386
    x[2702]   c1198     1
    x[2703]   c913      -19386
    x[2703]   c1198     1
    x[2704]   c914      -19386
    x[2704]   c1198     1
    x[2705]   c915      -19386
    x[2705]   c1198     1
    x[2706]   c916      -19386
    x[2706]   c1198     1
    x[2707]   c917      -19386
    x[2707]   c1198     1
    x[2708]   c918      -19386
    x[2708]   c1198     1
    x[2709]   c919      -19386
    x[2709]   c1198     1
    x[2710]   c920      -19386
    x[2710]   c1198     1
    x[2711]   c921      -19386
    x[2711]   c1198     1
    x[2712]   c922      -19386
    x[2712]   c1198     1
    x[2713]   c923      -19386
    x[2713]   c1198     1
    x[2714]   c924      -19386
    x[2714]   c1198     1
    x[2715]   c925      -19386
    x[2715]   c1198     1
    x[2716]   c926      -19386
    x[2716]   c1198     1
    x[2717]   c927      -19386
    x[2717]   c1198     1
    x[2718]   c928      -19386
    x[2718]   c1198     1
    x[2719]   c929      -19386
    x[2719]   c1198     1
    x[2720]   c930      -19386
    x[2720]   c1198     1
    x[2721]   c931      -19386
    x[2721]   c1198     1
    x[2722]   c932      -19386
    x[2722]   c1198     1
    x[2723]   c933      -19386
    x[2723]   c1198     1
    x[2724]   c934      -19386
    x[2724]   c1198     1
    x[2725]   c935      -19386
    x[2725]   c1198     1
    x[2726]   c936      -19386
    x[2726]   c1198     1
    x[2727]   c937      -19386
    x[2727]   c1198     1
    x[2728]   c938      -19386
    x[2728]   c1198     1
    x[2729]   c939      -19386
    x[2729]   c1198     1
    x[2730]   c940      -19386
    x[2730]   c1198     1
    x[2731]   c941      -19386
    x[2731]   c1198     1
    x[2732]   c942      -19386
    x[2732]   c1198     1
    x[2733]   c943      -19386
    x[2733]   c1198     1
    x[2734]   c944      -19386
    x[2734]   c1198     1
    x[2735]   c945      -19386
    x[2735]   c1198     1
    x[2736]   c946      -19386
    x[2736]   c1198     1
    x[2737]   c947      -19386
    x[2737]   c1198     1
    x[2738]   c948      -19386
    x[2738]   c1198     1
    x[2739]   c949      -19386
    x[2739]   c1198     1
    x[2740]   c950      -19386
    x[2740]   c1198     1
    x[2741]   c951      -19386
    x[2741]   c1198     1
    x[2742]   c952      -19386
    x[2742]   c1198     1
    x[2743]   c953      -19386
    x[2743]   c1198     1
    x[2744]   c954      -19386
    x[2744]   c1198     1
    x[2745]   c955      -19386
    x[2745]   c1198     1
    x[2746]   c956      -19386
    x[2746]   c1198     1
    x[2747]   c957      -19386
    x[2747]   c1198     1
    x[2748]   c958      -19269
    x[2748]   c1199     1
    x[2749]   c959      -19269
    x[2749]   c1199     1
    x[2750]   c960      -19269
    x[2750]   c1199     1
    x[2751]   c961      -19269
    x[2751]   c1199     1
    x[2752]   c962      -19269
    x[2752]   c1199     1
    x[2753]   c963      -19269
    x[2753]   c1199     1
    x[2754]   c964      -19269
    x[2754]   c1199     1
    x[2755]   c965      -19269
    x[2755]   c1199     1
    x[2756]   c966      -19269
    x[2756]   c1199     1
    x[2757]   c967      -19269
    x[2757]   c1199     1
    x[2758]   c968      -19269
    x[2758]   c1199     1
    x[2759]   c969      -19269
    x[2759]   c1199     1
    x[2760]   c970      -19269
    x[2760]   c1199     1
    x[2761]   c971      -19269
    x[2761]   c1199     1
    x[2762]   c972      -19269
    x[2762]   c1199     1
    x[2763]   c973      -19269
    x[2763]   c1199     1
    x[2764]   c974      -19269
    x[2764]   c1199     1
    x[2765]   c975      -19269
    x[2765]   c1199     1
    x[2766]   c976      -19269
    x[2766]   c1199     1
    x[2767]   c977      -19269
    x[2767]   c1199     1
    x[2768]   c978      -19269
    x[2768]   c1199     1
    x[2769]   c979      -19269
    x[2769]   c1199     1
    x[2770]   c980      -19269
    x[2770]   c1199     1
    x[2771]   c981      -19269
    x[2771]   c1199     1
    x[2772]   c982      -19269
    x[2772]   c1199     1
    x[2773]   c983      -19269
    x[2773]   c1199     1
    x[2774]   c984      -19269
    x[2774]   c1199     1
    x[2775]   c985      -19269
    x[2775]   c1199     1
    x[2776]   c986      -19269
    x[2776]   c1199     1
    x[2777]   c987      -19269
    x[2777]   c1199     1
    x[2778]   c988      -19269
    x[2778]   c1199     1
    x[2779]   c989      -19269
    x[2779]   c1199     1
    x[2780]   c990      -19269
    x[2780]   c1199     1
    x[2781]   c991      -19269
    x[2781]   c1199     1
    x[2782]   c992      -19269
    x[2782]   c1199     1
    x[2783]   c993      -19269
    x[2783]   c1199     1
    x[2784]   c994      -19269
    x[2784]   c1199     1
    x[2785]   c995      -19269
    x[2785]   c1199     1
    x[2786]   c996      -19269
    x[2786]   c1199     1
    x[2787]   c997      -19269
    x[2787]   c1199     1
    x[2788]   c998      -19269
    x[2788]   c1199     1
    x[2789]   c999      -19269
    x[2789]   c1199     1
    x[2790]   c1000     -19269
    x[2790]   c1199     1
    x[2791]   c1001     -19269
    x[2791]   c1199     1
    x[2792]   c1002     -19269
    x[2792]   c1199     1
    x[2793]   c1003     -19269
    x[2793]   c1199     1
    x[2794]   c1004     -19269
    x[2794]   c1199     1
    x[2795]   c1005     -19269
    x[2795]   c1199     1
    x[2796]   c1006     -19269
    x[2796]   c1199     1
    x[2797]   c1007     -19269
    x[2797]   c1199     1
    x[2798]   c1008     -19269
    x[2798]   c1199     1
    x[2799]   c1009     -19269
    x[2799]   c1199     1
    x[2800]   c1010     -19269
    x[2800]   c1199     1
    x[2801]   c1011     -19269
    x[2801]   c1199     1
    x[2802]   c1012     -19269
    x[2802]   c1199     1
    x[2803]   c1013     -19269
    x[2803]   c1199     1
    x[2804]   c1014     -19269
    x[2804]   c1199     1
    x[2805]   c1015     -19269
    x[2805]   c1199     1
    x[2806]   c1016     -19269
    x[2806]   c1199     1
    x[2807]   c1017     -19269
    x[2807]   c1199     1
    x[2808]   c1018     -19269
    x[2808]   c1199     1
    x[2809]   c1019     -19269
    x[2809]   c1199     1
    x[2810]   c1020     -19269
    x[2810]   c1199     1
    x[2811]   c1021     -19269
    x[2811]   c1199     1
    x[2812]   c1022     -19269
    x[2812]   c1199     1
    x[2813]   c1023     -19269
    x[2813]   c1199     1
    x[2814]   c1024     -19269
    x[2814]   c1199     1
    x[2815]   c1025     -19269
    x[2815]   c1199     1
    x[2816]   c1026     -19269
    x[2816]   c1199     1
    x[2817]   c1027     -19269
    x[2817]   c1199     1
    x[2818]   c1028     -19269
    x[2818]   c1199     1
    x[2819]   c1029     -19269
    x[2819]   c1199     1
    x[2820]   c1030     -19269
    x[2820]   c1199     1
    x[2821]   c1031     -19269
    x[2821]   c1199     1
    x[2822]   c1032     -19269
    x[2822]   c1199     1
    x[2823]   c1033     -19269
    x[2823]   c1199     1
    x[2824]   c1034     -19269
    x[2824]   c1199     1
    x[2825]   c1035     -19269
    x[2825]   c1199     1
    x[2826]   c1036     -19269
    x[2826]   c1199     1
    x[2827]   c1037     -19269
    x[2827]   c1199     1
    x[2828]   c1038     -19269
    x[2828]   c1199     1
    x[2829]   c1039     -19269
    x[2829]   c1199     1
    x[2830]   c1040     -19269
    x[2830]   c1199     1
    x[2831]   c1041     -19269
    x[2831]   c1199     1
    x[2832]   c1042     -19269
    x[2832]   c1199     1
    x[2833]   c1043     -19269
    x[2833]   c1199     1
    x[2834]   c1044     -19269
    x[2834]   c1199     1
    x[2835]   c1045     -19269
    x[2835]   c1199     1
    x[2836]   c1046     -19269
    x[2836]   c1199     1
    x[2837]   c1047     -19269
    x[2837]   c1199     1
    x[2838]   c1048     -19269
    x[2838]   c1199     1
    x[2839]   c1049     -19269
    x[2839]   c1199     1
    x[2840]   c1050     -19269
    x[2840]   c1199     1
    x[2841]   c1051     -19269
    x[2841]   c1199     1
    x[2842]   c1052     -19269
    x[2842]   c1199     1
    x[2843]   c1053     -19269
    x[2843]   c1199     1
    x[2844]   c1054     -19269
    x[2844]   c1199     1
    x[2845]   c1055     -19269
    x[2845]   c1199     1
    x[2846]   c1056     -19269
    x[2846]   c1199     1
    x[2847]   c1057     -19269
    x[2847]   c1199     1
    x[2848]   c1058     -19269
    x[2848]   c1199     1
    x[2849]   c1059     -19269
    x[2849]   c1199     1
    x[2850]   c1060     -19269
    x[2850]   c1199     1
    x[2851]   c1061     -19269
    x[2851]   c1199     1
    x[2852]   c1062     -19269
    x[2852]   c1199     1
    x[2853]   c1063     -19269
    x[2853]   c1199     1
    x[2854]   c1064     -19269
    x[2854]   c1199     1
    x[2855]   c1065     -19269
    x[2855]   c1199     1
    x[2856]   c1066     -19269
    x[2856]   c1199     1
    x[2857]   c1067     -19269
    x[2857]   c1199     1
    x[2858]   c1068     -19269
    x[2858]   c1199     1
    x[2859]   c1069     -19269
    x[2859]   c1199     1
    x[2860]   c1070     -19269
    x[2860]   c1199     1
    x[2861]   c1071     -19269
    x[2861]   c1199     1
    x[2862]   c1072     -19269
    x[2862]   c1199     1
    x[2863]   c1073     -19269
    x[2863]   c1199     1
    x[2864]   c1074     -19269
    x[2864]   c1199     1
    x[2865]   c1075     -19269
    x[2865]   c1199     1
    x[2866]   c1076     -19269
    x[2866]   c1199     1
    x[2867]   c1077     -20019
    x[2867]   c1200     1
    x[2868]   c1078     -20019
    x[2868]   c1200     1
    x[2869]   c1079     -20019
    x[2869]   c1200     1
    x[2870]   c1080     -20019
    x[2870]   c1200     1
    x[2871]   c1081     -20019
    x[2871]   c1200     1
    x[2872]   c1082     -20019
    x[2872]   c1200     1
    x[2873]   c1083     -20019
    x[2873]   c1200     1
    x[2874]   c1084     -20019
    x[2874]   c1200     1
    x[2875]   c1085     -20019
    x[2875]   c1200     1
    x[2876]   c1086     -20019
    x[2876]   c1200     1
    x[2877]   c1087     -20019
    x[2877]   c1200     1
    x[2878]   c1088     -20019
    x[2878]   c1200     1
    x[2879]   c1089     -20019
    x[2879]   c1200     1
    x[2880]   c1090     -20019
    x[2880]   c1200     1
    x[2881]   c1091     -20019
    x[2881]   c1200     1
    x[2882]   c1092     -20019
    x[2882]   c1200     1
    x[2883]   c1093     -20019
    x[2883]   c1200     1
    x[2884]   c1094     -20019
    x[2884]   c1200     1
    x[2885]   c1095     -20019
    x[2885]   c1200     1
    x[2886]   c1096     -20019
    x[2886]   c1200     1
    x[2887]   c1097     -20019
    x[2887]   c1200     1
    x[2888]   c1098     -20019
    x[2888]   c1200     1
    x[2889]   c1099     -20019
    x[2889]   c1200     1
    x[2890]   c1100     -20019
    x[2890]   c1200     1
    x[2891]   c1101     -20019
    x[2891]   c1200     1
    x[2892]   c1102     -20019
    x[2892]   c1200     1
    x[2893]   c1103     -20019
    x[2893]   c1200     1
    x[2894]   c1104     -20019
    x[2894]   c1200     1
    x[2895]   c1105     -20019
    x[2895]   c1200     1
    x[2896]   c1106     -20019
    x[2896]   c1200     1
    x[2897]   c1107     -20019
    x[2897]   c1200     1
    x[2898]   c1108     -20019
    x[2898]   c1200     1
    x[2899]   c1109     -20019
    x[2899]   c1200     1
    x[2900]   c1110     -20019
    x[2900]   c1200     1
    x[2901]   c1111     -20019
    x[2901]   c1200     1
    x[2902]   c1112     -20019
    x[2902]   c1200     1
    x[2903]   c1113     -20019
    x[2903]   c1200     1
    x[2904]   c1114     -20019
    x[2904]   c1200     1
    x[2905]   c1115     -20019
    x[2905]   c1200     1
    x[2906]   c1116     -20019
    x[2906]   c1200     1
    x[2907]   c1117     -20019
    x[2907]   c1200     1
    x[2908]   c1118     -20019
    x[2908]   c1200     1
    x[2909]   c1119     -20019
    x[2909]   c1200     1
    x[2910]   c1120     -20019
    x[2910]   c1200     1
    x[2911]   c1121     -20019
    x[2911]   c1200     1
    x[2912]   c1122     -20019
    x[2912]   c1200     1
    x[2913]   c1123     -20019
    x[2913]   c1200     1
    x[2914]   c1124     -20019
    x[2914]   c1200     1
    x[2915]   c1125     -20019
    x[2915]   c1200     1
    x[2916]   c1126     -20019
    x[2916]   c1200     1
    x[2917]   c1127     -20019
    x[2917]   c1200     1
    x[2918]   c1128     -20019
    x[2918]   c1200     1
    x[2919]   c1129     -20019
    x[2919]   c1200     1
    x[2920]   c1130     -20019
    x[2920]   c1200     1
    x[2921]   c1131     -20019
    x[2921]   c1200     1
    x[2922]   c1132     -20019
    x[2922]   c1200     1
    x[2923]   c1133     -20019
    x[2923]   c1200     1
    x[2924]   c1134     -20019
    x[2924]   c1200     1
    x[2925]   c1135     -20019
    x[2925]   c1200     1
    x[2926]   c1136     -20019
    x[2926]   c1200     1
    x[2927]   c1137     -20019
    x[2927]   c1200     1
    x[2928]   c1138     -20019
    x[2928]   c1200     1
    x[2929]   c1139     -20019
    x[2929]   c1200     1
    x[2930]   c1140     -20019
    x[2930]   c1200     1
    x[2931]   c1141     -20019
    x[2931]   c1200     1
    x[2932]   c1142     -20019
    x[2932]   c1200     1
    x[2933]   c1143     -20019
    x[2933]   c1200     1
    x[2934]   c1144     -20019
    x[2934]   c1200     1
    x[2935]   c1145     -20019
    x[2935]   c1200     1
    x[2936]   c1146     -20019
    x[2936]   c1200     1
    x[2937]   c1147     -20019
    x[2937]   c1200     1
    x[2938]   c1148     -20019
    x[2938]   c1200     1
    x[2939]   c1149     -20019
    x[2939]   c1200     1
    x[2940]   c1150     -20019
    x[2940]   c1200     1
    x[2941]   c1151     -20019
    x[2941]   c1200     1
    x[2942]   c1152     -20019
    x[2942]   c1200     1
    x[2943]   c1153     -20019
    x[2943]   c1200     1
    x[2944]   c1154     -20019
    x[2944]   c1200     1
    x[2945]   c1155     -20019
    x[2945]   c1200     1
    x[2946]   c1156     -20019
    x[2946]   c1200     1
    x[2947]   c1157     -20019
    x[2947]   c1200     1
    x[2948]   c1158     -20019
    x[2948]   c1200     1
    x[2949]   c1159     -20019
    x[2949]   c1200     1
    x[2950]   c1160     -20019
    x[2950]   c1200     1
    x[2951]   c1161     -20019
    x[2951]   c1200     1
    x[2952]   c1162     -20019
    x[2952]   c1200     1
    x[2953]   c1163     -20019
    x[2953]   c1200     1
    x[2954]   c1164     -20019
    x[2954]   c1200     1
    x[2955]   c1165     -20019
    x[2955]   c1200     1
    x[2956]   c1166     -20019
    x[2956]   c1200     1
    x[2957]   c1167     -20019
    x[2957]   c1200     1
    x[2958]   c1168     -20019
    x[2958]   c1200     1
    x[2959]   c1169     -20019
    x[2959]   c1200     1
    x[2960]   c1170     -20019
    x[2960]   c1200     1
    x[2961]   c1171     -20019
    x[2961]   c1200     1
    x[2962]   c1172     -20019
    x[2962]   c1200     1
    x[2963]   c1173     -20019
    x[2963]   c1200     1
    x[2964]   c1174     -20019
    x[2964]   c1200     1
    x[2965]   c1175     -20019
    x[2965]   c1200     1
    x[2966]   c1176     -20019
    x[2966]   c1200     1
    x[2967]   c1177     -20019
    x[2967]   c1200     1
    x[2968]   c1178     -20019
    x[2968]   c1200     1
    x[2969]   c1179     -20019
    x[2969]   c1200     1
    x[2970]   c1180     -20019
    x[2970]   c1200     1
    x[2971]   c1181     -20019
    x[2971]   c1200     1
    x[2972]   c1182     -20019
    x[2972]   c1200     1
    x[2973]   c1183     -20019
    x[2973]   c1200     1
    x[2974]   c1184     -20019
    x[2974]   c1200     1
    x[2975]   c1185     -20019
    x[2975]   c1200     1
    x[2976]   c1186     -20019
    x[2976]   c1200     1
    x[2977]   c1187     -20019
    x[2977]   c1200     1
    x[2978]   c1188     -20019
    x[2978]   c1200     1
    x[2979]   c1189     -20019
    x[2979]   c1200     1
    x[2980]   c1190     -20019
    x[2980]   c1200     1
    x[2981]   c1191     -20019
    x[2981]   c1200     1
    x[2982]   c1192     -20019
    x[2982]   c1200     1
    x[2983]   c1193     -20019
    x[2983]   c1200     1
    x[2984]   c1194     -20019
    x[2984]   c1200     1
    x[2985]   c1195     -20019
    x[2985]   c1200     1
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1_1      0
    rhs       c2_1      0
    rhs       c3_1      0
    rhs       c4_1      0
    rhs       c5_1      0
    rhs       c6_1      0
    rhs       c7_1      0
    rhs       c8_1      0
    rhs       c9_1      0
    rhs       c10_1     0
    rhs       c11_1     0
    rhs       c12_1     0
    rhs       c13_1     0
    rhs       c14_1     0
    rhs       c15_1     0
    rhs       c16_1     0
    rhs       c17_1     0
    rhs       c18_1     0
    rhs       c19_1     0
    rhs       c20_1     0
    rhs       c21_1     0
    rhs       c22_1     0
    rhs       c23_1     0
    rhs       c24_1     0
    rhs       c25_1     0
    rhs       c26_1     0
    rhs       c27_1     0
    rhs       c28_1     0
    rhs       c29_1     0
    rhs       c30_1     0
    rhs       c31_1     0
    rhs       c32_1     0
    rhs       c33_1     0
    rhs       c34_1     0
    rhs       c35_1     0
    rhs       c36_1     0
    rhs       c37_1     0
    rhs       c38_1     0
    rhs       c39_1     0
    rhs       c40_1     0
    rhs       c41_1     0
    rhs       c42_1     0
    rhs       c43_1     0
    rhs       c44_1     0
    rhs       c45_1     0
    rhs       c46_1     0
    rhs       c47_1     0
    rhs       c48_1     0
    rhs       c49_1     0
    rhs       c50_1     0
    rhs       c51_1     0
    rhs       c52_1     0
    rhs       c53_1     0
    rhs       c54_1     0
    rhs       c55_1     0
    rhs       c56_1     0
    rhs       c57_1     0
    rhs       c58_1     0
    rhs       c59_1     0
    rhs       c60_1     0
    rhs       c61_1     0
    rhs       c62_1     0
    rhs       c63_1     0
    rhs       c64_1     0
    rhs       c65_1     0
    rhs       c66_1     0
    rhs       c67_1     0
    rhs       c68_1     0
    rhs       c69_1     0
    rhs       c70_1     0
    rhs       c71_1     0
    rhs       c72_1     0
    rhs       c73_1     0
    rhs       c74_1     0
    rhs       c75_1     0
    rhs       c76_1     0
    rhs       c77_1     0
    rhs       c78_1     0
    rhs       c79_1     0
    rhs       c80_1     0
    rhs       c81_1     0
    rhs       c82_1     0
    rhs       c83_1     0
    rhs       c84_1     0
    rhs       c85_1     0
    rhs       c86_1     0
    rhs       c87_1     0
    rhs       c88_1     0
    rhs       c89_1     0
    rhs       c90_1     0
    rhs       c91_1     0
    rhs       c92_1     0
    rhs       c93_1     0
    rhs       c94_1     0
    rhs       c95_1     0
    rhs       c96_1     0
    rhs       c97_1     0
    rhs       c98_1     0
    rhs       c99_1     0
    rhs       c100_1    0
    rhs       c101_1    0
    rhs       c102_1    0
    rhs       c103_1    0
    rhs       c104_1    0
    rhs       c105_1    0
    rhs       c106_1    0
    rhs       c107_1    0
    rhs       c108_1    0
    rhs       c109_1    0
    rhs       c110_1    0
    rhs       c111_1    0
    rhs       c112_1    0
    rhs       c113_1    0
    rhs       c114_1    0
    rhs       c115_1    0
    rhs       c116_1    0
    rhs       c117_1    0
    rhs       c118_1    0
    rhs       c119_1    0
    rhs       c120_1    0
    rhs       c121_1    0
    rhs       c122_1    0
    rhs       c123_1    0
    rhs       c124_1    0
    rhs       c125_1    0
    rhs       c126_1    0
    rhs       c127_1    0
    rhs       c128_1    0
    rhs       c129_1    0
    rhs       c130_1    0
    rhs       c131_1    0
    rhs       c132_1    0
    rhs       c133_1    0
    rhs       c134_1    0
    rhs       c135_1    0
    rhs       c136_1    0
    rhs       c137_1    0
    rhs       c138_1    0
    rhs       c139_1    0
    rhs       c140_1    0
    rhs       c141_1    0
    rhs       c142_1    0
    rhs       c143_1    0
    rhs       c144_1    0
    rhs       c145_1    0
    rhs       c146_1    0
    rhs       c147_1    0
    rhs       c148_1    0
    rhs       c149_1    0
    rhs       c150_1    0
    rhs       c151_1    0
    rhs       c152_1    0
    rhs       c153_1    0
    rhs       c154_1    0
    rhs       c155_1    0
    rhs       c156_1    0
    rhs       c157_1    0
    rhs       c158_1    0
    rhs       c159_1    0
    rhs       c160_1    0
    rhs       c161_1    0
    rhs       c162_1    0
    rhs       c163_1    0
    rhs       c164_1    0
    rhs       c165_1    0
    rhs       c166_1    0
    rhs       c167_1    0
    rhs       c168_1    0
    rhs       c169_1    0
    rhs       c170_1    0
    rhs       c171_1    0
    rhs       c172_1    0
    rhs       c173_1    0
    rhs       c174_1    0
    rhs       c175_1    0
    rhs       c176_1    0
    rhs       c177_1    0
    rhs       c178_1    0
    rhs       c179_1    0
    rhs       c180_1    0
    rhs       c181_1    0
    rhs       c182_1    0
    rhs       c183_1    0
    rhs       c184_1    0
    rhs       c185_1    0
    rhs       c186_1    0
    rhs       c187_1    0
    rhs       c188_1    0
    rhs       c189_1    0
    rhs       c190_1    0
    rhs       c191_1    0
    rhs       c192_1    0
    rhs       c193_1    0
    rhs       c194_1    0
    rhs       c195_1    0
    rhs       c196_1    0
    rhs       c197_1    0
    rhs       c198_1    0
    rhs       c199_1    0
    rhs       c200_1    0
    rhs       c201_1    0
    rhs       c202_1    0
    rhs       c203_1    0
    rhs       c204_1    0
    rhs       c205_1    0
    rhs       c206_1    0
    rhs       c207_1    0
    rhs       c208_1    0
    rhs       c209_1    0
    rhs       c210_1    0
    rhs       c211_1    0
    rhs       c212_1    0
    rhs       c213_1    0
    rhs       c214_1    0
    rhs       c215_1    0
    rhs       c216_1    0
    rhs       c217_1    0
    rhs       c218_1    0
    rhs       c219_1    0
    rhs       c220_1    0
    rhs       c221_1    0
    rhs       c222_1    0
    rhs       c223_1    0
    rhs       c224_1    0
    rhs       c225_1    0
    rhs       c226_1    0
    rhs       c227_1    0
    rhs       c228_1    0
    rhs       c229_1    0
    rhs       c230_1    0
    rhs       c231_1    0
    rhs       c232_1    0
    rhs       c233_1    0
    rhs       c234_1    0
    rhs       c235_1    0
    rhs       c236_1    0
    rhs       c237_1    0
    rhs       c238_1    0
    rhs       c239_1    0
    rhs       c240_1    0
    rhs       c241_1    0
    rhs       c242_1    0
    rhs       c243_1    0
    rhs       c244_1    0
    rhs       c245_1    0
    rhs       c246_1    0
    rhs       c247_1    0
    rhs       c248_1    0
    rhs       c249_1    0
    rhs       c250_1    0
    rhs       c251_1    0
    rhs       c252_1    0
    rhs       c253_1    0
    rhs       c254_1    0
    rhs       c255_1    0
    rhs       c256_1    0
    rhs       c257_1    0
    rhs       c258_1    0
    rhs       c259_1    0
    rhs       c260_1    0
    rhs       c261_1    0
    rhs       c262_1    0
    rhs       c263_1    0
    rhs       c264_1    0
    rhs       c265_1    0
    rhs       c266_1    0
    rhs       c267_1    0
    rhs       c268_1    0
    rhs       c269_1    0
    rhs       c270_1    0
    rhs       c271_1    0
    rhs       c272_1    0
    rhs       c273_1    0
    rhs       c274_1    0
    rhs       c275_1    0
    rhs       c276_1    0
    rhs       c277_1    0
    rhs       c278_1    0
    rhs       c279_1    0
    rhs       c280_1    0
    rhs       c281_1    0
    rhs       c282_1    0
    rhs       c283_1    0
    rhs       c284_1    0
    rhs       c285_1    0
    rhs       c286_1    0
    rhs       c287_1    0
    rhs       c288_1    0
    rhs       c289_1    0
    rhs       c290_1    0
    rhs       c291_1    0
    rhs       c292_1    0
    rhs       c293_1    0
    rhs       c294_1    0
    rhs       c295_1    0
    rhs       c296_1    0
    rhs       c297_1    0
    rhs       c298_1    0
    rhs       c299_1    0
    rhs       c300_1    0
    rhs       c301_1    0
    rhs       c302_1    0
    rhs       c303_1    0
    rhs       c304_1    0
    rhs       c305_1    0
    rhs       c306_1    0
    rhs       c307_1    0
    rhs       c308_1    0
    rhs       c309_1    0
    rhs       c310_1    0
    rhs       c311_1    0
    rhs       c312_1    0
    rhs       c313_1    0
    rhs       c314_1    0
    rhs       c315_1    0
    rhs       c316_1    0
    rhs       c317_1    0
    rhs       c318_1    0
    rhs       c319_1    0
    rhs       c320_1    0
    rhs       c321_1    0
    rhs       c322_1    0
    rhs       c323_1    0
    rhs       c324_1    0
    rhs       c325_1    0
    rhs       c326_1    0
    rhs       c327_1    0
    rhs       c328_1    0
    rhs       c329_1    0
    rhs       c330_1    0
    rhs       c331_1    0
    rhs       c332_1    0
    rhs       c333_1    0
    rhs       c334_1    0
    rhs       c335_1    0
    rhs       c336_1    0
    rhs       c337_1    0
    rhs       c338_1    0
    rhs       c339_1    0
    rhs       c340_1    0
    rhs       c341_1    0
    rhs       c342_1    0
    rhs       c343_1    0
    rhs       c344_1    0
    rhs       c345_1    0
    rhs       c346_1    0
    rhs       c347_1    0
    rhs       c348_1    0
    rhs       c349_1    0
    rhs       c350_1    0
    rhs       c351_1    0
    rhs       c352_1    0
    rhs       c353_1    0
    rhs       c354_1    0
    rhs       c355_1    0
    rhs       c356_1    0
    rhs       c357_1    0
    rhs       c358_1    0
    rhs       c359_1    0
    rhs       c360_1    0
    rhs       c361_1    0
    rhs       c362_1    0
    rhs       c363_1    0
    rhs       c364_1    0
    rhs       c365_1    0
    rhs       c366_1    0
    rhs       c367_1    0
    rhs       c368_1    0
    rhs       c369_1    0
    rhs       c370_1    0
    rhs       c371_1    0
    rhs       c372_1    0
    rhs       c373_1    0
    rhs       c374_1    0
    rhs       c375_1    0
    rhs       c376_1    0
    rhs       c377_1    0
    rhs       c378_1    0
    rhs       c379_1    0
    rhs       c380_1    0
    rhs       c381_1    0
    rhs       c382_1    0
    rhs       c383_1    0
    rhs       c384_1    0
    rhs       c385_1    0
    rhs       c386_1    0
    rhs       c387_1    0
    rhs       c388_1    0
    rhs       c389_1    0
    rhs       c390_1    0
    rhs       c391_1    0
    rhs       c392_1    0
    rhs       c393_1    0
    rhs       c394_1    0
    rhs       c395_1    0
    rhs       c396_1    0
    rhs       c397_1    0
    rhs       c398_1    0
    rhs       c399_1    0
    rhs       c400_1    0
    rhs       c401_1    0
    rhs       c402_1    0
    rhs       c403_1    0
    rhs       c404_1    0
    rhs       c405_1    0
    rhs       c406_1    0
    rhs       c407_1    0
    rhs       c408_1    0
    rhs       c409_1    0
    rhs       c410_1    0
    rhs       c411_1    0
    rhs       c412_1    0
    rhs       c413_1    0
    rhs       c414_1    0
    rhs       c415_1    0
    rhs       c416_1    0
    rhs       c417_1    0
    rhs       c418_1    0
    rhs       c419_1    0
    rhs       c420_1    0
    rhs       c421_1    0
    rhs       c422_1    0
    rhs       c423_1    0
    rhs       c424_1    0
    rhs       c425_1    0
    rhs       c426_1    0
    rhs       c427_1    0
    rhs       c428_1    0
    rhs       c429_1    0
    rhs       c430_1    0
    rhs       c431_1    0
    rhs       c432_1    0
    rhs       c433_1    0
    rhs       c434_1    0
    rhs       c435_1    0
    rhs       c436_1    0
    rhs       c437_1    0
    rhs       c438_1    0
    rhs       c439_1    0
    rhs       c440_1    0
    rhs       c441_1    0
    rhs       c442_1    0
    rhs       c443_1    0
    rhs       c444_1    0
    rhs       c445_1    0
    rhs       c446_1    0
    rhs       c447_1    0
    rhs       c448_1    0
    rhs       c449_1    0
    rhs       c450_1    0
    rhs       c451_1    0
    rhs       c452_1    0
    rhs       c453_1    0
    rhs       c454_1    0
    rhs       c455_1    0
    rhs       c456_1    0
    rhs       c457_1    0
    rhs       c458_1    0
    rhs       c459_1    0
    rhs       c460_1    0
    rhs       c461_1    0
    rhs       c462_1    0
    rhs       c463_1    0
    rhs       c464_1    0
    rhs       c465_1    0
    rhs       c466_1    0
    rhs       c467_1    0
    rhs       c468_1    0
    rhs       c469_1    0
    rhs       c470_1    0
    rhs       c471_1    0
    rhs       c472_1    0
    rhs       c473_1    0
    rhs       c474_1    0
    rhs       c475_1    0
    rhs       c476_1    0
    rhs       c477_1    0
    rhs       c478_1    0
    rhs       c479_1    0
    rhs       c480_1    0
    rhs       c481_1    0
    rhs       c482_1    0
    rhs       c483_1    0
    rhs       c484_1    0
    rhs       c485_1    0
    rhs       c486_1    0
    rhs       c487_1    0
    rhs       c488_1    0
    rhs       c489_1    0
    rhs       c490_1    0
    rhs       c491_1    0
    rhs       c492_1    0
    rhs       c493_1    0
    rhs       c494_1    0
    rhs       c495_1    0
    rhs       c496_1    0
    rhs       c497_1    0
    rhs       c498_1    0
    rhs       c499_1    0
    rhs       c500_1    0
    rhs       c501_1    0
    rhs       c502_1    0
    rhs       c503_1    0
    rhs       c504_1    0
    rhs       c505_1    0
    rhs       c506_1    0
    rhs       c507_1    0
    rhs       c508_1    0
    rhs       c509_1    0
    rhs       c510_1    0
    rhs       c511_1    0
    rhs       c512_1    0
    rhs       c513_1    0
    rhs       c514_1    0
    rhs       c515_1    0
    rhs       c516_1    0
    rhs       c517_1    0
    rhs       c518_1    0
    rhs       c519_1    0
    rhs       c520_1    0
    rhs       c521_1    0
    rhs       c522_1    0
    rhs       c523_1    0
    rhs       c524_1    0
    rhs       c525_1    0
    rhs       c526_1    0
    rhs       c527_1    0
    rhs       c528_1    0
    rhs       c529_1    0
    rhs       c530_1    0
    rhs       c531_1    0
    rhs       c532_1    0
    rhs       c533_1    0
    rhs       c534_1    0
    rhs       c535_1    0
    rhs       c536_1    0
    rhs       c537_1    0
    rhs       c538_1    0
    rhs       c539_1    0
    rhs       c540_1    0
    rhs       c541_1    0
    rhs       c542_1    0
    rhs       c543_1    0
    rhs       c544_1    0
    rhs       c545_1    0
    rhs       c546_1    0
    rhs       c547_1    0
    rhs       c548_1    0
    rhs       c549_1    0
    rhs       c550_1    0
    rhs       c551_1    0
    rhs       c552_1    0
    rhs       c553_1    0
    rhs       c554_1    0
    rhs       c555_1    0
    rhs       c556_1    0
    rhs       c557_1    0
    rhs       c558_1    0
    rhs       c559_1    0
    rhs       c560_1    0
    rhs       c561_1    0
    rhs       c562_1    0
    rhs       c563_1    0
    rhs       c564_1    0
    rhs       c565_1    0
    rhs       c566_1    0
    rhs       c567_1    0
    rhs       c568_1    0
    rhs       c569_1    0
    rhs       c570_1    0
    rhs       c571_1    0
    rhs       c572_1    0
    rhs       c573_1    0
    rhs       c574_1    0
    rhs       c575_1    0
    rhs       c576_1    0
    rhs       c577_1    0
    rhs       c578_1    0
    rhs       c579_1    0
    rhs       c580_1    0
    rhs       c581_1    0
    rhs       c582_1    0
    rhs       c583_1    0
    rhs       c584_1    0
    rhs       c585_1    0
    rhs       c586_1    0
    rhs       c587_1    0
    rhs       c588_1    0
    rhs       c589_1    0
    rhs       c590_1    0
    rhs       c591_1    0
    rhs       c592_1    0
    rhs       c593_1    0
    rhs       c594_1    0
    rhs       c595_1    0
    rhs       c596_1    0
    rhs       c597_1    0
    rhs       c598_1    0
    rhs       c599_1    0
    rhs       c600_1    0
    rhs       c601_1    0
    rhs       c602_1    0
    rhs       c603_1    0
    rhs       c604_1    0
    rhs       c605_1    0
    rhs       c606_1    0
    rhs       c607_1    0
    rhs       c608_1    0
    rhs       c609_1    0
    rhs       c610_1    0
    rhs       c611_1    0
    rhs       c612_1    0
    rhs       c613_1    0
    rhs       c614_1    0
    rhs       c615_1    0
    rhs       c616_1    0
    rhs       c617_1    0
    rhs       c618_1    0
    rhs       c619_1    0
    rhs       c620_1    0
    rhs       c621_1    0
    rhs       c622_1    0
    rhs       c623_1    0
    rhs       c624_1    0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     12
    rhs       c1197     12
    rhs       c1198     12
    rhs       c1199     12
    rhs       c1200     12
    rhs       c1201     1
    rhs       c1202     1
    rhs       c1203     1
    rhs       c1204     1
    rhs       c1205     1
    rhs       c1206     1
    rhs       c1207     1
    rhs       c1208     1
    rhs       c1209     1
    rhs       c1210     1
    rhs       c1211     1
    rhs       c1212     1
    rhs       c1213     1
    rhs       c1214     1
    rhs       c1215     1
    rhs       c1216     1
    rhs       c1217     1
    rhs       c1218     1
    rhs       c1219     1
    rhs       c1220     1
    rhs       c1221     1
    rhs       c1222     1
    rhs       c1223     1
    rhs       c1224     1
    rhs       c1225     1
    rhs       c1226     1
    rhs       c1227     1
    rhs       c1228     1
    rhs       c1229     1
    rhs       c1230     1
    rhs       c1231     1
    rhs       c1232     1
    rhs       c1233     1
    rhs       c1234     1
    rhs       c1235     1
    rhs       c1236     1
    rhs       c1237     1
    rhs       c1238     1
    rhs       c1239     1
    rhs       c1240     1
    rhs       c1241     1
    rhs       c1242     1
    rhs       c1243     1
    rhs       c1244     1
    rhs       c1245     1
    rhs       c1246     1
    rhs       c1247     1
    rhs       c1248     1
    rhs       c1249     1
    rhs       c1250     1
    rhs       c1251     1
    rhs       c1252     1
    rhs       c1253     1
    rhs       c1254     1
    rhs       c1255     1
    rhs       c1256     1
    rhs       c1257     1
    rhs       c1258     1
    rhs       c1259     1
    rhs       c1260     1
    rhs       c1261     1
    rhs       c1262     1
    rhs       c1263     1
    rhs       c1264     1
    rhs       c1265     1
    rhs       c1266     1
    rhs       c1267     1
    rhs       c1268     1
    rhs       c1269     1
    rhs       c1270     1
    rhs       c1271     1
    rhs       c1272     1
    rhs       c1273     1
    rhs       c1274     1
    rhs       c1275     1
    rhs       c1276     1
    rhs       c1277     1
    rhs       c1278     1
    rhs       c1279     1
    rhs       c1280     1
    rhs       c1281     1
    rhs       c1282     1
    rhs       c1283     1
    rhs       c1284     1
    rhs       c1285     1
    rhs       c1286     1
    rhs       c1287     1
    rhs       c1288     1
    rhs       c1289     1
    rhs       c1290     1
    rhs       c1291     1
    rhs       c1292     1
    rhs       c1293     1
    rhs       c1294     1
    rhs       c1295     1
    rhs       c1296     1
    rhs       c1297     1
    rhs       c1298     1
    rhs       c1299     1
    rhs       c1300     1
    rhs       c1301     1
    rhs       c1302     1
    rhs       c1303     1
    rhs       c1304     1
    rhs       c1305     1
    rhs       c1306     1
    rhs       c1307     1
    rhs       c1308     1
    rhs       c1309     1
    rhs       c1310     1
    rhs       c1311     1
    rhs       c1312     1
    rhs       c1313     1
    rhs       c1314     1
    rhs       c1315     1
    rhs       c1316     1
    rhs       c1317     1
    rhs       c1318     1
    rhs       c1319     1
    rhs       c1320     1
    rhs       c1        163
    rhs       c2        144
    rhs       c3        126
    rhs       c4        196
    rhs       c5        104
    rhs       c6        201
    rhs       c7        148
    rhs       c8        274
    rhs       c9        187
    rhs       c10       21
    rhs       c11       179
    rhs       c12       207
    rhs       c13       52
    rhs       c14       207
    rhs       c15       80
    rhs       c16       282
    rhs       c17       275
    rhs       c18       234
    rhs       c19       137
    rhs       c20       77
    rhs       c21       50
    rhs       c22       155
    rhs       c23       262
    rhs       c24       23
    rhs       c25       154
    rhs       c26       233
    rhs       c27       19
    rhs       c28       17
    rhs       c29       116
    rhs       c30       167
    rhs       c31       18
    rhs       c32       131
    rhs       c33       125
    rhs       c34       222
    rhs       c35       245
    rhs       c36       251
    rhs       c37       15
    rhs       c38       38
    rhs       c39       206
    rhs       c40       237
    rhs       c41       268
    rhs       c42       293
    rhs       c43       167
    rhs       c44       141
    rhs       c45       128
    rhs       c46       165
    rhs       c47       154
    rhs       c48       216
    rhs       c49       143
    rhs       c50       290
    rhs       c51       184
    rhs       c52       262
    rhs       c53       238
    rhs       c54       61
    rhs       c55       195
    rhs       c56       142
    rhs       c57       287
    rhs       c58       167
    rhs       c59       276
    rhs       c60       27
    rhs       c61       28
    rhs       c62       241
    rhs       c63       218
    rhs       c64       147
    rhs       c65       220
    rhs       c66       140
    rhs       c67       41
    rhs       c68       107
    rhs       c69       244
    rhs       c70       259
    rhs       c71       97
    rhs       c72       40
    rhs       c73       199
    rhs       c74       264
    rhs       c75       186
    rhs       c76       100
    rhs       c77       56
    rhs       c78       262
    rhs       c79       73
    rhs       c80       53
    rhs       c81       119
    rhs       c82       31
    rhs       c83       262
    rhs       c84       239
    rhs       c85       145
    rhs       c86       167
    rhs       c87       132
    rhs       c88       77
    rhs       c89       57
    rhs       c90       83
    rhs       c91       264
    rhs       c92       66
    rhs       c93       248
    rhs       c94       190
    rhs       c95       108
    rhs       c96       76
    rhs       c97       61
    rhs       c98       115
    rhs       c99       182
    rhs       c100      105
    rhs       c101      248
    rhs       c102      159
    rhs       c103      256
    rhs       c104      55
    rhs       c105      49
    rhs       c106      148
    rhs       c107      39
    rhs       c108      180
    rhs       c109      61
    rhs       c110      61
    rhs       c111      107
    rhs       c112      90
    rhs       c113      177
    rhs       c114      234
    rhs       c115      147
    rhs       c116      283
    rhs       c117      14
    rhs       c118      244
    rhs       c119      150
    rhs       c120      112
    rhs       c121      84
    rhs       c122      145
    rhs       c123      221
    rhs       c124      87
    rhs       c125      21
    rhs       c126      108
    rhs       c127      229
    rhs       c128      85
    rhs       c129      118
    rhs       c130      44
    rhs       c131      119
    rhs       c132      254
    rhs       c133      254
    rhs       c134      240
    rhs       c135      215
    rhs       c136      126
    rhs       c137      200
    rhs       c138      56
    rhs       c139      115
    rhs       c140      48
    rhs       c141      23
    rhs       c142      290
    rhs       c143      180
    rhs       c144      209
    rhs       c145      154
    rhs       c146      187
    rhs       c147      148
    rhs       c148      58
    rhs       c149      31
    rhs       c150      13
    rhs       c151      261
    rhs       c152      284
    rhs       c153      204
    rhs       c154      94
    rhs       c155      159
    rhs       c156      30
    rhs       c157      223
    rhs       c158      266
    rhs       c159      204
    rhs       c160      27
    rhs       c161      108
    rhs       c162      13
    rhs       c163      225
    rhs       c164      196
    rhs       c165      279
    rhs       c166      226
    rhs       c167      79
    rhs       c168      76
    rhs       c169      119
    rhs       c170      168
    rhs       c171      148
    rhs       c172      10
    rhs       c173      39
    rhs       c174      226
    rhs       c175      265
    rhs       c176      36
    rhs       c177      62
    rhs       c178      123
    rhs       c179      248
    rhs       c180      202
    rhs       c181      104
    rhs       c182      249
    rhs       c183      28
    rhs       c184      202
    rhs       c185      165
    rhs       c186      174
    rhs       c187      258
    rhs       c188      192
    rhs       c189      38
    rhs       c190      128
    rhs       c191      182
    rhs       c192      86
    rhs       c193      70
    rhs       c194      14
    rhs       c195      253
    rhs       c196      98
    rhs       c197      86
    rhs       c198      60
    rhs       c199      26
    rhs       c200      289
    rhs       c201      98
    rhs       c202      104
    rhs       c203      79
    rhs       c204      107
    rhs       c205      181
    rhs       c206      88
    rhs       c207      273
    rhs       c208      54
    rhs       c209      182
    rhs       c210      251
    rhs       c211      178
    rhs       c212      222
    rhs       c213      293
    rhs       c214      185
    rhs       c215      288
    rhs       c216      101
    rhs       c217      100
    rhs       c218      111
    rhs       c219      160
    rhs       c220      230
    rhs       c221      92
    rhs       c222      50
    rhs       c223      45
    rhs       c224      33
    rhs       c225      60
    rhs       c226      29
    rhs       c227      173
    rhs       c228      178
    rhs       c229      84
    rhs       c230      103
    rhs       c231      187
    rhs       c232      45
    rhs       c233      173
    rhs       c234      107
    rhs       c235      113
    rhs       c236      171
    rhs       c237      35
    rhs       c238      18
    rhs       c239      18
    rhs       c240      168
    rhs       c241      68
    rhs       c242      141
    rhs       c243      156
    rhs       c244      219
    rhs       c245      153
    rhs       c246      213
    rhs       c247      16
    rhs       c248      229
    rhs       c249      204
    rhs       c250      183
    rhs       c251      90
    rhs       c252      251
    rhs       c253      141
    rhs       c254      157
    rhs       c255      129
    rhs       c256      293
    rhs       c257      207
    rhs       c258      171
    rhs       c259      215
    rhs       c260      295
    rhs       c261      277
    rhs       c262      236
    rhs       c263      296
    rhs       c264      275
    rhs       c265      274
    rhs       c266      271
    rhs       c267      281
    rhs       c268      227
    rhs       c269      57
    rhs       c270      295
    rhs       c271      121
    rhs       c272      87
    rhs       c273      240
    rhs       c274      220
    rhs       c275      241
    rhs       c276      89
    rhs       c277      176
    rhs       c278      10
    rhs       c279      219
    rhs       c280      298
    rhs       c281      195
    rhs       c282      51
    rhs       c283      299
    rhs       c284      246
    rhs       c285      30
    rhs       c286      157
    rhs       c287      281
    rhs       c288      192
    rhs       c289      268
    rhs       c290      47
    rhs       c291      123
    rhs       c292      198
    rhs       c293      140
    rhs       c294      207
    rhs       c295      292
    rhs       c296      13
    rhs       c297      153
    rhs       c298      128
    rhs       c299      64
    rhs       c300      108
    rhs       c301      99
    rhs       c302      170
    rhs       c303      91
    rhs       c304      73
    rhs       c305      176
    rhs       c306      143
    rhs       c307      49
    rhs       c308      238
    rhs       c309      121
    rhs       c310      222
    rhs       c311      76
    rhs       c312      182
    rhs       c313      294
    rhs       c314      267
    rhs       c315      291
    rhs       c316      174
    rhs       c317      139
    rhs       c318      96
    rhs       c319      147
    rhs       c320      42
    rhs       c321      116
    rhs       c322      208
    rhs       c323      206
    rhs       c324      131
    rhs       c325      39
    rhs       c326      42
    rhs       c327      113
    rhs       c328      162
    rhs       c329      257
    rhs       c330      52
    rhs       c331      122
    rhs       c332      298
    rhs       c333      39
    rhs       c334      260
    rhs       c335      240
    rhs       c336      15
    rhs       c337      143
    rhs       c338      145
    rhs       c339      289
    rhs       c340      52
    rhs       c341      20
    rhs       c342      160
    rhs       c343      109
    rhs       c344      96
    rhs       c345      253
    rhs       c346      89
    rhs       c347      160
    rhs       c348      114
    rhs       c349      163
    rhs       c350      34
    rhs       c351      119
    rhs       c352      110
    rhs       c353      19
    rhs       c354      200
    rhs       c355      156
    rhs       c356      70
    rhs       c357      93
    rhs       c358      244
    rhs       c359      153
    rhs       c360      92
    rhs       c361      69
    rhs       c362      122
    rhs       c363      40
    rhs       c364      241
    rhs       c365      192
    rhs       c366      75
    rhs       c367      200
    rhs       c368      25
    rhs       c369      205
    rhs       c370      135
    rhs       c371      298
    rhs       c372      207
    rhs       c373      106
    rhs       c374      207
    rhs       c375      207
    rhs       c376      269
    rhs       c377      192
    rhs       c378      296
    rhs       c379      246
    rhs       c380      208
    rhs       c381      285
    rhs       c382      75
    rhs       c383      21
    rhs       c384      237
    rhs       c385      116
    rhs       c386      163
    rhs       c387      250
    rhs       c388      179
    rhs       c389      279
    rhs       c390      28
    rhs       c391      43
    rhs       c392      106
    rhs       c393      283
    rhs       c394      216
    rhs       c395      199
    rhs       c396      197
    rhs       c397      50
    rhs       c398      266
    rhs       c399      118
    rhs       c400      248
    rhs       c401      174
    rhs       c402      34
    rhs       c403      17
    rhs       c404      130
    rhs       c405      220
    rhs       c406      235
    rhs       c407      40
    rhs       c408      116
    rhs       c409      57
    rhs       c410      274
    rhs       c411      299
    rhs       c412      86
    rhs       c413      104
    rhs       c414      181
    rhs       c415      203
    rhs       c416      111
    rhs       c417      259
    rhs       c418      187
    rhs       c419      18
    rhs       c420      191
    rhs       c421      32
    rhs       c422      273
    rhs       c423      121
    rhs       c424      207
    rhs       c425      126
    rhs       c426      186
    rhs       c427      247
    rhs       c428      276
    rhs       c429      297
    rhs       c430      299
    rhs       c431      182
    rhs       c432      151
    rhs       c433      212
    rhs       c434      175
    rhs       c435      280
    rhs       c436      159
    rhs       c437      175
    rhs       c438      133
    rhs       c439      129
    rhs       c440      85
    rhs       c441      24
    rhs       c442      107
    rhs       c443      154
    rhs       c444      113
    rhs       c445      237
    rhs       c446      66
    rhs       c447      85
    rhs       c448      197
    rhs       c449      217
    rhs       c450      26
    rhs       c451      171
    rhs       c452      18
    rhs       c453      229
    rhs       c454      169
    rhs       c455      74
    rhs       c456      103
    rhs       c457      260
    rhs       c458      95
    rhs       c459      249
    rhs       c460      121
    rhs       c461      240
    rhs       c462      267
    rhs       c463      223
    rhs       c464      210
    rhs       c465      51
    rhs       c466      42
    rhs       c467      289
    rhs       c468      18
    rhs       c469      181
    rhs       c470      109
    rhs       c471      88
    rhs       c472      102
    rhs       c473      103
    rhs       c474      133
    rhs       c475      191
    rhs       c476      92
    rhs       c477      234
    rhs       c478      20
    rhs       c479      262
    rhs       c480      119
    rhs       c481      237
    rhs       c482      48
    rhs       c483      253
    rhs       c484      137
    rhs       c485      32
    rhs       c486      21
    rhs       c487      252
    rhs       c488      147
    rhs       c489      254
    rhs       c490      241
    rhs       c491      165
    rhs       c492      117
    rhs       c493      253
    rhs       c494      159
    rhs       c495      259
    rhs       c496      192
    rhs       c497      35
    rhs       c498      271
    rhs       c499      89
    rhs       c500      258
    rhs       c501      190
    rhs       c502      195
    rhs       c503      124
    rhs       c504      115
    rhs       c505      106
    rhs       c506      274
    rhs       c507      133
    rhs       c508      76
    rhs       c509      40
    rhs       c510      76
    rhs       c511      37
    rhs       c512      27
    rhs       c513      238
    rhs       c514      223
    rhs       c515      138
    rhs       c516      28
    rhs       c517      182
    rhs       c518      67
    rhs       c519      172
    rhs       c520      34
    rhs       c521      174
    rhs       c522      96
    rhs       c523      283
    rhs       c524      55
    rhs       c525      235
    rhs       c526      79
    rhs       c527      236
    rhs       c528      116
    rhs       c529      197
    rhs       c530      80
    rhs       c531      208
    rhs       c532      291
    rhs       c533      179
    rhs       c534      123
    rhs       c535      298
    rhs       c536      131
    rhs       c537      267
    rhs       c538      27
    rhs       c539      227
    rhs       c540      80
    rhs       c541      78
    rhs       c542      115
    rhs       c543      247
    rhs       c544      285
    rhs       c545      228
    rhs       c546      61
    rhs       c547      144
    rhs       c548      156
    rhs       c549      270
    rhs       c550      240
    rhs       c551      269
    rhs       c552      183
    rhs       c553      231
    rhs       c554      214
    rhs       c555      258
    rhs       c556      200
    rhs       c557      161
    rhs       c558      237
    rhs       c559      142
    rhs       c560      127
    rhs       c561      279
    rhs       c562      284
    rhs       c563      222
    rhs       c564      268
    rhs       c565      217
    rhs       c566      131
    rhs       c567      140
    rhs       c568      36
    rhs       c569      195
    rhs       c570      266
    rhs       c571      190
    rhs       c572      176
    rhs       c573      249
    rhs       c574      43
    rhs       c575      72
    rhs       c576      81
    rhs       c577      216
    rhs       c578      63
    rhs       c579      65
    rhs       c580      266
    rhs       c581      154
    rhs       c582      291
    rhs       c583      251
    rhs       c584      285
    rhs       c585      202
    rhs       c586      151
    rhs       c587      269
    rhs       c588      103
    rhs       c589      131
    rhs       c590      152
    rhs       c591      180
    rhs       c592      153
    rhs       c593      121
    rhs       c594      294
    rhs       c595      281
    rhs       c596      129
    rhs       c597      27
    rhs       c598      114
    rhs       c599      79
    rhs       c600      70
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      18298
 LO bounds    x[2]      0
 UP bounds    x[2]      18298
 LO bounds    x[3]      0
 UP bounds    x[3]      18298
 LO bounds    x[4]      0
 UP bounds    x[4]      18298
 LO bounds    x[5]      0
 UP bounds    x[5]      18298
 LO bounds    x[6]      0
 UP bounds    x[6]      18298
 LO bounds    x[7]      0
 UP bounds    x[7]      18298
 LO bounds    x[8]      0
 UP bounds    x[8]      18298
 LO bounds    x[9]      0
 UP bounds    x[9]      18298
 LO bounds    x[10]     0
 UP bounds    x[10]     18298
 LO bounds    x[11]     0
 UP bounds    x[11]     18298
 LO bounds    x[12]     0
 UP bounds    x[12]     18298
 LO bounds    x[13]     0
 UP bounds    x[13]     18298
 LO bounds    x[14]     0
 UP bounds    x[14]     18298
 LO bounds    x[15]     0
 UP bounds    x[15]     18298
 LO bounds    x[16]     0
 UP bounds    x[16]     18298
 LO bounds    x[17]     0
 UP bounds    x[17]     18298
 LO bounds    x[18]     0
 UP bounds    x[18]     18298
 LO bounds    x[19]     0
 UP bounds    x[19]     18298
 LO bounds    x[20]     0
 UP bounds    x[20]     18298
 LO bounds    x[21]     0
 UP bounds    x[21]     18298
 LO bounds    x[22]     0
 UP bounds    x[22]     18298
 LO bounds    x[23]     0
 UP bounds    x[23]     18298
 LO bounds    x[24]     0
 UP bounds    x[24]     18298
 LO bounds    x[25]     0
 UP bounds    x[25]     18298
 LO bounds    x[26]     0
 UP bounds    x[26]     18298
 LO bounds    x[27]     0
 UP bounds    x[27]     18298
 LO bounds    x[28]     0
 UP bounds    x[28]     18298
 LO bounds    x[29]     0
 UP bounds    x[29]     18298
 LO bounds    x[30]     0
 UP bounds    x[30]     18298
 LO bounds    x[31]     0
 UP bounds    x[31]     18298
 LO bounds    x[32]     0
 UP bounds    x[32]     18298
 LO bounds    x[33]     0
 UP bounds    x[33]     18298
 LO bounds    x[34]     0
 UP bounds    x[34]     18298
 LO bounds    x[35]     0
 UP bounds    x[35]     18298
 LO bounds    x[36]     0
 UP bounds    x[36]     18298
 LO bounds    x[37]     0
 UP bounds    x[37]     18298
 LO bounds    x[38]     0
 UP bounds    x[38]     18298
 LO bounds    x[39]     0
 UP bounds    x[39]     18298
 LO bounds    x[40]     0
 UP bounds    x[40]     18298
 LO bounds    x[41]     0
 UP bounds    x[41]     18298
 LO bounds    x[42]     0
 UP bounds    x[42]     18298
 LO bounds    x[43]     0
 UP bounds    x[43]     18298
 LO bounds    x[44]     0
 UP bounds    x[44]     18298
 LO bounds    x[45]     0
 UP bounds    x[45]     18298
 LO bounds    x[46]     0
 UP bounds    x[46]     18298
 LO bounds    x[47]     0
 UP bounds    x[47]     18298
 LO bounds    x[48]     0
 UP bounds    x[48]     18298
 LO bounds    x[49]     0
 UP bounds    x[49]     18298
 LO bounds    x[50]     0
 UP bounds    x[50]     18298
 LO bounds    x[51]     0
 UP bounds    x[51]     18298
 LO bounds    x[52]     0
 UP bounds    x[52]     18298
 LO bounds    x[53]     0
 UP bounds    x[53]     18298
 LO bounds    x[54]     0
 UP bounds    x[54]     18298
 LO bounds    x[55]     0
 UP bounds    x[55]     18298
 LO bounds    x[56]     0
 UP bounds    x[56]     18298
 LO bounds    x[57]     0
 UP bounds    x[57]     18298
 LO bounds    x[58]     0
 UP bounds    x[58]     18298
 LO bounds    x[59]     0
 UP bounds    x[59]     18298
 LO bounds    x[60]     0
 UP bounds    x[60]     18298
 LO bounds    x[61]     0
 UP bounds    x[61]     18298
 LO bounds    x[62]     0
 UP bounds    x[62]     18298
 LO bounds    x[63]     0
 UP bounds    x[63]     18298
 LO bounds    x[64]     0
 UP bounds    x[64]     18298
 LO bounds    x[65]     0
 UP bounds    x[65]     18298
 LO bounds    x[66]     0
 UP bounds    x[66]     18298
 LO bounds    x[67]     0
 UP bounds    x[67]     18298
 LO bounds    x[68]     0
 UP bounds    x[68]     18298
 LO bounds    x[69]     0
 UP bounds    x[69]     18298
 LO bounds    x[70]     0
 UP bounds    x[70]     18298
 LO bounds    x[71]     0
 UP bounds    x[71]     18298
 LO bounds    x[72]     0
 UP bounds    x[72]     18298
 LO bounds    x[73]     0
 UP bounds    x[73]     18298
 LO bounds    x[74]     0
 UP bounds    x[74]     18298
 LO bounds    x[75]     0
 UP bounds    x[75]     18298
 LO bounds    x[76]     0
 UP bounds    x[76]     18298
 LO bounds    x[77]     0
 UP bounds    x[77]     18298
 LO bounds    x[78]     0
 UP bounds    x[78]     18298
 LO bounds    x[79]     0
 UP bounds    x[79]     18298
 LO bounds    x[80]     0
 UP bounds    x[80]     18298
 LO bounds    x[81]     0
 UP bounds    x[81]     18298
 LO bounds    x[82]     0
 UP bounds    x[82]     18298
 LO bounds    x[83]     0
 UP bounds    x[83]     18298
 LO bounds    x[84]     0
 UP bounds    x[84]     18298
 LO bounds    x[85]     0
 UP bounds    x[85]     18298
 LO bounds    x[86]     0
 UP bounds    x[86]     18298
 LO bounds    x[87]     0
 UP bounds    x[87]     18298
 LO bounds    x[88]     0
 UP bounds    x[88]     18298
 LO bounds    x[89]     0
 UP bounds    x[89]     18298
 LO bounds    x[90]     0
 UP bounds    x[90]     18298
 LO bounds    x[91]     0
 UP bounds    x[91]     18298
 LO bounds    x[92]     0
 UP bounds    x[92]     18298
 LO bounds    x[93]     0
 UP bounds    x[93]     18298
 LO bounds    x[94]     0
 UP bounds    x[94]     18298
 LO bounds    x[95]     0
 UP bounds    x[95]     18298
 LO bounds    x[96]     0
 UP bounds    x[96]     18298
 LO bounds    x[97]     0
 UP bounds    x[97]     18298
 LO bounds    x[98]     0
 UP bounds    x[98]     18298
 LO bounds    x[99]     0
 UP bounds    x[99]     18298
 LO bounds    x[100]    0
 UP bounds    x[100]    18298
 LO bounds    x[101]    0
 UP bounds    x[101]    18298
 LO bounds    x[102]    0
 UP bounds    x[102]    18298
 LO bounds    x[103]    0
 UP bounds    x[103]    18298
 LO bounds    x[104]    0
 UP bounds    x[104]    18298
 LO bounds    x[105]    0
 UP bounds    x[105]    18298
 LO bounds    x[106]    0
 UP bounds    x[106]    18298
 LO bounds    x[107]    0
 UP bounds    x[107]    18298
 LO bounds    x[108]    0
 UP bounds    x[108]    18298
 LO bounds    x[109]    0
 UP bounds    x[109]    18298
 LO bounds    x[110]    0
 UP bounds    x[110]    18298
 LO bounds    x[111]    0
 UP bounds    x[111]    18298
 LO bounds    x[112]    0
 UP bounds    x[112]    18298
 LO bounds    x[113]    0
 UP bounds    x[113]    18298
 LO bounds    x[114]    0
 UP bounds    x[114]    18298
 LO bounds    x[115]    0
 UP bounds    x[115]    18298
 LO bounds    x[116]    0
 UP bounds    x[116]    18298
 LO bounds    x[117]    0
 UP bounds    x[117]    18298
 LO bounds    x[118]    0
 UP bounds    x[118]    18298
 LO bounds    x[119]    0
 UP bounds    x[119]    18298
 LO bounds    x[120]    0
 UP bounds    x[120]    18298
 LO bounds    x[121]    0
 UP bounds    x[121]    16531
 LO bounds    x[122]    0
 UP bounds    x[122]    16531
 LO bounds    x[123]    0
 UP bounds    x[123]    16531
 LO bounds    x[124]    0
 UP bounds    x[124]    16531
 LO bounds    x[125]    0
 UP bounds    x[125]    16531
 LO bounds    x[126]    0
 UP bounds    x[126]    16531
 LO bounds    x[127]    0
 UP bounds    x[127]    16531
 LO bounds    x[128]    0
 UP bounds    x[128]    16531
 LO bounds    x[129]    0
 UP bounds    x[129]    16531
 LO bounds    x[130]    0
 UP bounds    x[130]    16531
 LO bounds    x[131]    0
 UP bounds    x[131]    16531
 LO bounds    x[132]    0
 UP bounds    x[132]    16531
 LO bounds    x[133]    0
 UP bounds    x[133]    16531
 LO bounds    x[134]    0
 UP bounds    x[134]    16531
 LO bounds    x[135]    0
 UP bounds    x[135]    16531
 LO bounds    x[136]    0
 UP bounds    x[136]    16531
 LO bounds    x[137]    0
 UP bounds    x[137]    16531
 LO bounds    x[138]    0
 UP bounds    x[138]    16531
 LO bounds    x[139]    0
 UP bounds    x[139]    16531
 LO bounds    x[140]    0
 UP bounds    x[140]    16531
 LO bounds    x[141]    0
 UP bounds    x[141]    16531
 LO bounds    x[142]    0
 UP bounds    x[142]    16531
 LO bounds    x[143]    0
 UP bounds    x[143]    16531
 LO bounds    x[144]    0
 UP bounds    x[144]    16531
 LO bounds    x[145]    0
 UP bounds    x[145]    16531
 LO bounds    x[146]    0
 UP bounds    x[146]    16531
 LO bounds    x[147]    0
 UP bounds    x[147]    16531
 LO bounds    x[148]    0
 UP bounds    x[148]    16531
 LO bounds    x[149]    0
 UP bounds    x[149]    16531
 LO bounds    x[150]    0
 UP bounds    x[150]    16531
 LO bounds    x[151]    0
 UP bounds    x[151]    16531
 LO bounds    x[152]    0
 UP bounds    x[152]    16531
 LO bounds    x[153]    0
 UP bounds    x[153]    16531
 LO bounds    x[154]    0
 UP bounds    x[154]    16531
 LO bounds    x[155]    0
 UP bounds    x[155]    16531
 LO bounds    x[156]    0
 UP bounds    x[156]    16531
 LO bounds    x[157]    0
 UP bounds    x[157]    16531
 LO bounds    x[158]    0
 UP bounds    x[158]    16531
 LO bounds    x[159]    0
 UP bounds    x[159]    16531
 LO bounds    x[160]    0
 UP bounds    x[160]    16531
 LO bounds    x[161]    0
 UP bounds    x[161]    16531
 LO bounds    x[162]    0
 UP bounds    x[162]    16531
 LO bounds    x[163]    0
 UP bounds    x[163]    16531
 LO bounds    x[164]    0
 UP bounds    x[164]    16531
 LO bounds    x[165]    0
 UP bounds    x[165]    16531
 LO bounds    x[166]    0
 UP bounds    x[166]    16531
 LO bounds    x[167]    0
 UP bounds    x[167]    16531
 LO bounds    x[168]    0
 UP bounds    x[168]    16531
 LO bounds    x[169]    0
 UP bounds    x[169]    16531
 LO bounds    x[170]    0
 UP bounds    x[170]    16531
 LO bounds    x[171]    0
 UP bounds    x[171]    16531
 LO bounds    x[172]    0
 UP bounds    x[172]    16531
 LO bounds    x[173]    0
 UP bounds    x[173]    16531
 LO bounds    x[174]    0
 UP bounds    x[174]    16531
 LO bounds    x[175]    0
 UP bounds    x[175]    16531
 LO bounds    x[176]    0
 UP bounds    x[176]    16531
 LO bounds    x[177]    0
 UP bounds    x[177]    16531
 LO bounds    x[178]    0
 UP bounds    x[178]    16531
 LO bounds    x[179]    0
 UP bounds    x[179]    16531
 LO bounds    x[180]    0
 UP bounds    x[180]    16531
 LO bounds    x[181]    0
 UP bounds    x[181]    16531
 LO bounds    x[182]    0
 UP bounds    x[182]    16531
 LO bounds    x[183]    0
 UP bounds    x[183]    16531
 LO bounds    x[184]    0
 UP bounds    x[184]    16531
 LO bounds    x[185]    0
 UP bounds    x[185]    16531
 LO bounds    x[186]    0
 UP bounds    x[186]    16531
 LO bounds    x[187]    0
 UP bounds    x[187]    16531
 LO bounds    x[188]    0
 UP bounds    x[188]    16531
 LO bounds    x[189]    0
 UP bounds    x[189]    16531
 LO bounds    x[190]    0
 UP bounds    x[190]    16531
 LO bounds    x[191]    0
 UP bounds    x[191]    16531
 LO bounds    x[192]    0
 UP bounds    x[192]    16531
 LO bounds    x[193]    0
 UP bounds    x[193]    16531
 LO bounds    x[194]    0
 UP bounds    x[194]    16531
 LO bounds    x[195]    0
 UP bounds    x[195]    16531
 LO bounds    x[196]    0
 UP bounds    x[196]    16531
 LO bounds    x[197]    0
 UP bounds    x[197]    16531
 LO bounds    x[198]    0
 UP bounds    x[198]    16531
 LO bounds    x[199]    0
 UP bounds    x[199]    16531
 LO bounds    x[200]    0
 UP bounds    x[200]    16531
 LO bounds    x[201]    0
 UP bounds    x[201]    16531
 LO bounds    x[202]    0
 UP bounds    x[202]    16531
 LO bounds    x[203]    0
 UP bounds    x[203]    16531
 LO bounds    x[204]    0
 UP bounds    x[204]    16531
 LO bounds    x[205]    0
 UP bounds    x[205]    16531
 LO bounds    x[206]    0
 UP bounds    x[206]    16531
 LO bounds    x[207]    0
 UP bounds    x[207]    16531
 LO bounds    x[208]    0
 UP bounds    x[208]    16531
 LO bounds    x[209]    0
 UP bounds    x[209]    16531
 LO bounds    x[210]    0
 UP bounds    x[210]    16531
 LO bounds    x[211]    0
 UP bounds    x[211]    16531
 LO bounds    x[212]    0
 UP bounds    x[212]    16531
 LO bounds    x[213]    0
 UP bounds    x[213]    16531
 LO bounds    x[214]    0
 UP bounds    x[214]    16531
 LO bounds    x[215]    0
 UP bounds    x[215]    16531
 LO bounds    x[216]    0
 UP bounds    x[216]    16531
 LO bounds    x[217]    0
 UP bounds    x[217]    16531
 LO bounds    x[218]    0
 UP bounds    x[218]    16531
 LO bounds    x[219]    0
 UP bounds    x[219]    16531
 LO bounds    x[220]    0
 UP bounds    x[220]    16531
 LO bounds    x[221]    0
 UP bounds    x[221]    16531
 LO bounds    x[222]    0
 UP bounds    x[222]    16531
 LO bounds    x[223]    0
 UP bounds    x[223]    16531
 LO bounds    x[224]    0
 UP bounds    x[224]    16531
 LO bounds    x[225]    0
 UP bounds    x[225]    16531
 LO bounds    x[226]    0
 UP bounds    x[226]    16531
 LO bounds    x[227]    0
 UP bounds    x[227]    16531
 LO bounds    x[228]    0
 UP bounds    x[228]    16531
 LO bounds    x[229]    0
 UP bounds    x[229]    16531
 LO bounds    x[230]    0
 UP bounds    x[230]    16531
 LO bounds    x[231]    0
 UP bounds    x[231]    16531
 LO bounds    x[232]    0
 UP bounds    x[232]    16531
 LO bounds    x[233]    0
 UP bounds    x[233]    16531
 LO bounds    x[234]    0
 UP bounds    x[234]    16531
 LO bounds    x[235]    0
 UP bounds    x[235]    16531
 LO bounds    x[236]    0
 UP bounds    x[236]    16531
 LO bounds    x[237]    0
 UP bounds    x[237]    16531
 LO bounds    x[238]    0
 UP bounds    x[238]    16531
 LO bounds    x[239]    0
 UP bounds    x[239]    16531
 LO bounds    x[240]    0
 UP bounds    x[240]    16531
 LO bounds    x[241]    0
 UP bounds    x[241]    19386
 LO bounds    x[242]    0
 UP bounds    x[242]    19386
 LO bounds    x[243]    0
 UP bounds    x[243]    19386
 LO bounds    x[244]    0
 UP bounds    x[244]    19386
 LO bounds    x[245]    0
 UP bounds    x[245]    19386
 LO bounds    x[246]    0
 UP bounds    x[246]    19386
 LO bounds    x[247]    0
 UP bounds    x[247]    19386
 LO bounds    x[248]    0
 UP bounds    x[248]    19386
 LO bounds    x[249]    0
 UP bounds    x[249]    19386
 LO bounds    x[250]    0
 UP bounds    x[250]    19386
 LO bounds    x[251]    0
 UP bounds    x[251]    19386
 LO bounds    x[252]    0
 UP bounds    x[252]    19386
 LO bounds    x[253]    0
 UP bounds    x[253]    19386
 LO bounds    x[254]    0
 UP bounds    x[254]    19386
 LO bounds    x[255]    0
 UP bounds    x[255]    19386
 LO bounds    x[256]    0
 UP bounds    x[256]    19386
 LO bounds    x[257]    0
 UP bounds    x[257]    19386
 LO bounds    x[258]    0
 UP bounds    x[258]    19386
 LO bounds    x[259]    0
 UP bounds    x[259]    19386
 LO bounds    x[260]    0
 UP bounds    x[260]    19386
 LO bounds    x[261]    0
 UP bounds    x[261]    19386
 LO bounds    x[262]    0
 UP bounds    x[262]    19386
 LO bounds    x[263]    0
 UP bounds    x[263]    19386
 LO bounds    x[264]    0
 UP bounds    x[264]    19386
 LO bounds    x[265]    0
 UP bounds    x[265]    19386
 LO bounds    x[266]    0
 UP bounds    x[266]    19386
 LO bounds    x[267]    0
 UP bounds    x[267]    19386
 LO bounds    x[268]    0
 UP bounds    x[268]    19386
 LO bounds    x[269]    0
 UP bounds    x[269]    19386
 LO bounds    x[270]    0
 UP bounds    x[270]    19386
 LO bounds    x[271]    0
 UP bounds    x[271]    19386
 LO bounds    x[272]    0
 UP bounds    x[272]    19386
 LO bounds    x[273]    0
 UP bounds    x[273]    19386
 LO bounds    x[274]    0
 UP bounds    x[274]    19386
 LO bounds    x[275]    0
 UP bounds    x[275]    19386
 LO bounds    x[276]    0
 UP bounds    x[276]    19386
 LO bounds    x[277]    0
 UP bounds    x[277]    19386
 LO bounds    x[278]    0
 UP bounds    x[278]    19386
 LO bounds    x[279]    0
 UP bounds    x[279]    19386
 LO bounds    x[280]    0
 UP bounds    x[280]    19386
 LO bounds    x[281]    0
 UP bounds    x[281]    19386
 LO bounds    x[282]    0
 UP bounds    x[282]    19386
 LO bounds    x[283]    0
 UP bounds    x[283]    19386
 LO bounds    x[284]    0
 UP bounds    x[284]    19386
 LO bounds    x[285]    0
 UP bounds    x[285]    19386
 LO bounds    x[286]    0
 UP bounds    x[286]    19386
 LO bounds    x[287]    0
 UP bounds    x[287]    19386
 LO bounds    x[288]    0
 UP bounds    x[288]    19386
 LO bounds    x[289]    0
 UP bounds    x[289]    19386
 LO bounds    x[290]    0
 UP bounds    x[290]    19386
 LO bounds    x[291]    0
 UP bounds    x[291]    19386
 LO bounds    x[292]    0
 UP bounds    x[292]    19386
 LO bounds    x[293]    0
 UP bounds    x[293]    19386
 LO bounds    x[294]    0
 UP bounds    x[294]    19386
 LO bounds    x[295]    0
 UP bounds    x[295]    19386
 LO bounds    x[296]    0
 UP bounds    x[296]    19386
 LO bounds    x[297]    0
 UP bounds    x[297]    19386
 LO bounds    x[298]    0
 UP bounds    x[298]    19386
 LO bounds    x[299]    0
 UP bounds    x[299]    19386
 LO bounds    x[300]    0
 UP bounds    x[300]    19386
 LO bounds    x[301]    0
 UP bounds    x[301]    19386
 LO bounds    x[302]    0
 UP bounds    x[302]    19386
 LO bounds    x[303]    0
 UP bounds    x[303]    19386
 LO bounds    x[304]    0
 UP bounds    x[304]    19386
 LO bounds    x[305]    0
 UP bounds    x[305]    19386
 LO bounds    x[306]    0
 UP bounds    x[306]    19386
 LO bounds    x[307]    0
 UP bounds    x[307]    19386
 LO bounds    x[308]    0
 UP bounds    x[308]    19386
 LO bounds    x[309]    0
 UP bounds    x[309]    19386
 LO bounds    x[310]    0
 UP bounds    x[310]    19386
 LO bounds    x[311]    0
 UP bounds    x[311]    19386
 LO bounds    x[312]    0
 UP bounds    x[312]    19386
 LO bounds    x[313]    0
 UP bounds    x[313]    19386
 LO bounds    x[314]    0
 UP bounds    x[314]    19386
 LO bounds    x[315]    0
 UP bounds    x[315]    19386
 LO bounds    x[316]    0
 UP bounds    x[316]    19386
 LO bounds    x[317]    0
 UP bounds    x[317]    19386
 LO bounds    x[318]    0
 UP bounds    x[318]    19386
 LO bounds    x[319]    0
 UP bounds    x[319]    19386
 LO bounds    x[320]    0
 UP bounds    x[320]    19386
 LO bounds    x[321]    0
 UP bounds    x[321]    19386
 LO bounds    x[322]    0
 UP bounds    x[322]    19386
 LO bounds    x[323]    0
 UP bounds    x[323]    19386
 LO bounds    x[324]    0
 UP bounds    x[324]    19386
 LO bounds    x[325]    0
 UP bounds    x[325]    19386
 LO bounds    x[326]    0
 UP bounds    x[326]    19386
 LO bounds    x[327]    0
 UP bounds    x[327]    19386
 LO bounds    x[328]    0
 UP bounds    x[328]    19386
 LO bounds    x[329]    0
 UP bounds    x[329]    19386
 LO bounds    x[330]    0
 UP bounds    x[330]    19386
 LO bounds    x[331]    0
 UP bounds    x[331]    19386
 LO bounds    x[332]    0
 UP bounds    x[332]    19386
 LO bounds    x[333]    0
 UP bounds    x[333]    19386
 LO bounds    x[334]    0
 UP bounds    x[334]    19386
 LO bounds    x[335]    0
 UP bounds    x[335]    19386
 LO bounds    x[336]    0
 UP bounds    x[336]    19386
 LO bounds    x[337]    0
 UP bounds    x[337]    19386
 LO bounds    x[338]    0
 UP bounds    x[338]    19386
 LO bounds    x[339]    0
 UP bounds    x[339]    19386
 LO bounds    x[340]    0
 UP bounds    x[340]    19386
 LO bounds    x[341]    0
 UP bounds    x[341]    19386
 LO bounds    x[342]    0
 UP bounds    x[342]    19386
 LO bounds    x[343]    0
 UP bounds    x[343]    19386
 LO bounds    x[344]    0
 UP bounds    x[344]    19386
 LO bounds    x[345]    0
 UP bounds    x[345]    19386
 LO bounds    x[346]    0
 UP bounds    x[346]    19386
 LO bounds    x[347]    0
 UP bounds    x[347]    19386
 LO bounds    x[348]    0
 UP bounds    x[348]    19386
 LO bounds    x[349]    0
 UP bounds    x[349]    19386
 LO bounds    x[350]    0
 UP bounds    x[350]    19386
 LO bounds    x[351]    0
 UP bounds    x[351]    19386
 LO bounds    x[352]    0
 UP bounds    x[352]    19386
 LO bounds    x[353]    0
 UP bounds    x[353]    19386
 LO bounds    x[354]    0
 UP bounds    x[354]    19386
 LO bounds    x[355]    0
 UP bounds    x[355]    19386
 LO bounds    x[356]    0
 UP bounds    x[356]    19386
 LO bounds    x[357]    0
 UP bounds    x[357]    19386
 LO bounds    x[358]    0
 UP bounds    x[358]    19386
 LO bounds    x[359]    0
 UP bounds    x[359]    19386
 LO bounds    x[360]    0
 UP bounds    x[360]    19386
 LO bounds    x[361]    0
 UP bounds    x[361]    19269
 LO bounds    x[362]    0
 UP bounds    x[362]    19269
 LO bounds    x[363]    0
 UP bounds    x[363]    19269
 LO bounds    x[364]    0
 UP bounds    x[364]    19269
 LO bounds    x[365]    0
 UP bounds    x[365]    19269
 LO bounds    x[366]    0
 UP bounds    x[366]    19269
 LO bounds    x[367]    0
 UP bounds    x[367]    19269
 LO bounds    x[368]    0
 UP bounds    x[368]    19269
 LO bounds    x[369]    0
 UP bounds    x[369]    19269
 LO bounds    x[370]    0
 UP bounds    x[370]    19269
 LO bounds    x[371]    0
 UP bounds    x[371]    19269
 LO bounds    x[372]    0
 UP bounds    x[372]    19269
 LO bounds    x[373]    0
 UP bounds    x[373]    19269
 LO bounds    x[374]    0
 UP bounds    x[374]    19269
 LO bounds    x[375]    0
 UP bounds    x[375]    19269
 LO bounds    x[376]    0
 UP bounds    x[376]    19269
 LO bounds    x[377]    0
 UP bounds    x[377]    19269
 LO bounds    x[378]    0
 UP bounds    x[378]    19269
 LO bounds    x[379]    0
 UP bounds    x[379]    19269
 LO bounds    x[380]    0
 UP bounds    x[380]    19269
 LO bounds    x[381]    0
 UP bounds    x[381]    19269
 LO bounds    x[382]    0
 UP bounds    x[382]    19269
 LO bounds    x[383]    0
 UP bounds    x[383]    19269
 LO bounds    x[384]    0
 UP bounds    x[384]    19269
 LO bounds    x[385]    0
 UP bounds    x[385]    19269
 LO bounds    x[386]    0
 UP bounds    x[386]    19269
 LO bounds    x[387]    0
 UP bounds    x[387]    19269
 LO bounds    x[388]    0
 UP bounds    x[388]    19269
 LO bounds    x[389]    0
 UP bounds    x[389]    19269
 LO bounds    x[390]    0
 UP bounds    x[390]    19269
 LO bounds    x[391]    0
 UP bounds    x[391]    19269
 LO bounds    x[392]    0
 UP bounds    x[392]    19269
 LO bounds    x[393]    0
 UP bounds    x[393]    19269
 LO bounds    x[394]    0
 UP bounds    x[394]    19269
 LO bounds    x[395]    0
 UP bounds    x[395]    19269
 LO bounds    x[396]    0
 UP bounds    x[396]    19269
 LO bounds    x[397]    0
 UP bounds    x[397]    19269
 LO bounds    x[398]    0
 UP bounds    x[398]    19269
 LO bounds    x[399]    0
 UP bounds    x[399]    19269
 LO bounds    x[400]    0
 UP bounds    x[400]    19269
 LO bounds    x[401]    0
 UP bounds    x[401]    19269
 LO bounds    x[402]    0
 UP bounds    x[402]    19269
 LO bounds    x[403]    0
 UP bounds    x[403]    19269
 LO bounds    x[404]    0
 UP bounds    x[404]    19269
 LO bounds    x[405]    0
 UP bounds    x[405]    19269
 LO bounds    x[406]    0
 UP bounds    x[406]    19269
 LO bounds    x[407]    0
 UP bounds    x[407]    19269
 LO bounds    x[408]    0
 UP bounds    x[408]    19269
 LO bounds    x[409]    0
 UP bounds    x[409]    19269
 LO bounds    x[410]    0
 UP bounds    x[410]    19269
 LO bounds    x[411]    0
 UP bounds    x[411]    19269
 LO bounds    x[412]    0
 UP bounds    x[412]    19269
 LO bounds    x[413]    0
 UP bounds    x[413]    19269
 LO bounds    x[414]    0
 UP bounds    x[414]    19269
 LO bounds    x[415]    0
 UP bounds    x[415]    19269
 LO bounds    x[416]    0
 UP bounds    x[416]    19269
 LO bounds    x[417]    0
 UP bounds    x[417]    19269
 LO bounds    x[418]    0
 UP bounds    x[418]    19269
 LO bounds    x[419]    0
 UP bounds    x[419]    19269
 LO bounds    x[420]    0
 UP bounds    x[420]    19269
 LO bounds    x[421]    0
 UP bounds    x[421]    19269
 LO bounds    x[422]    0
 UP bounds    x[422]    19269
 LO bounds    x[423]    0
 UP bounds    x[423]    19269
 LO bounds    x[424]    0
 UP bounds    x[424]    19269
 LO bounds    x[425]    0
 UP bounds    x[425]    19269
 LO bounds    x[426]    0
 UP bounds    x[426]    19269
 LO bounds    x[427]    0
 UP bounds    x[427]    19269
 LO bounds    x[428]    0
 UP bounds    x[428]    19269
 LO bounds    x[429]    0
 UP bounds    x[429]    19269
 LO bounds    x[430]    0
 UP bounds    x[430]    19269
 LO bounds    x[431]    0
 UP bounds    x[431]    19269
 LO bounds    x[432]    0
 UP bounds    x[432]    19269
 LO bounds    x[433]    0
 UP bounds    x[433]    19269
 LO bounds    x[434]    0
 UP bounds    x[434]    19269
 LO bounds    x[435]    0
 UP bounds    x[435]    19269
 LO bounds    x[436]    0
 UP bounds    x[436]    19269
 LO bounds    x[437]    0
 UP bounds    x[437]    19269
 LO bounds    x[438]    0
 UP bounds    x[438]    19269
 LO bounds    x[439]    0
 UP bounds    x[439]    19269
 LO bounds    x[440]    0
 UP bounds    x[440]    19269
 LO bounds    x[441]    0
 UP bounds    x[441]    19269
 LO bounds    x[442]    0
 UP bounds    x[442]    19269
 LO bounds    x[443]    0
 UP bounds    x[443]    19269
 LO bounds    x[444]    0
 UP bounds    x[444]    19269
 LO bounds    x[445]    0
 UP bounds    x[445]    19269
 LO bounds    x[446]    0
 UP bounds    x[446]    19269
 LO bounds    x[447]    0
 UP bounds    x[447]    19269
 LO bounds    x[448]    0
 UP bounds    x[448]    19269
 LO bounds    x[449]    0
 UP bounds    x[449]    19269
 LO bounds    x[450]    0
 UP bounds    x[450]    19269
 LO bounds    x[451]    0
 UP bounds    x[451]    19269
 LO bounds    x[452]    0
 UP bounds    x[452]    19269
 LO bounds    x[453]    0
 UP bounds    x[453]    19269
 LO bounds    x[454]    0
 UP bounds    x[454]    19269
 LO bounds    x[455]    0
 UP bounds    x[455]    19269
 LO bounds    x[456]    0
 UP bounds    x[456]    19269
 LO bounds    x[457]    0
 UP bounds    x[457]    19269
 LO bounds    x[458]    0
 UP bounds    x[458]    19269
 LO bounds    x[459]    0
 UP bounds    x[459]    19269
 LO bounds    x[460]    0
 UP bounds    x[460]    19269
 LO bounds    x[461]    0
 UP bounds    x[461]    19269
 LO bounds    x[462]    0
 UP bounds    x[462]    19269
 LO bounds    x[463]    0
 UP bounds    x[463]    19269
 LO bounds    x[464]    0
 UP bounds    x[464]    19269
 LO bounds    x[465]    0
 UP bounds    x[465]    19269
 LO bounds    x[466]    0
 UP bounds    x[466]    19269
 LO bounds    x[467]    0
 UP bounds    x[467]    19269
 LO bounds    x[468]    0
 UP bounds    x[468]    19269
 LO bounds    x[469]    0
 UP bounds    x[469]    19269
 LO bounds    x[470]    0
 UP bounds    x[470]    19269
 LO bounds    x[471]    0
 UP bounds    x[471]    19269
 LO bounds    x[472]    0
 UP bounds    x[472]    19269
 LO bounds    x[473]    0
 UP bounds    x[473]    19269
 LO bounds    x[474]    0
 UP bounds    x[474]    19269
 LO bounds    x[475]    0
 UP bounds    x[475]    19269
 LO bounds    x[476]    0
 UP bounds    x[476]    19269
 LO bounds    x[477]    0
 UP bounds    x[477]    19269
 LO bounds    x[478]    0
 UP bounds    x[478]    19269
 LO bounds    x[479]    0
 UP bounds    x[479]    19269
 LO bounds    x[480]    0
 UP bounds    x[480]    19269
 LO bounds    x[481]    0
 UP bounds    x[481]    20019
 LO bounds    x[482]    0
 UP bounds    x[482]    20019
 LO bounds    x[483]    0
 UP bounds    x[483]    20019
 LO bounds    x[484]    0
 UP bounds    x[484]    20019
 LO bounds    x[485]    0
 UP bounds    x[485]    20019
 LO bounds    x[486]    0
 UP bounds    x[486]    20019
 LO bounds    x[487]    0
 UP bounds    x[487]    20019
 LO bounds    x[488]    0
 UP bounds    x[488]    20019
 LO bounds    x[489]    0
 UP bounds    x[489]    20019
 LO bounds    x[490]    0
 UP bounds    x[490]    20019
 LO bounds    x[491]    0
 UP bounds    x[491]    20019
 LO bounds    x[492]    0
 UP bounds    x[492]    20019
 LO bounds    x[493]    0
 UP bounds    x[493]    20019
 LO bounds    x[494]    0
 UP bounds    x[494]    20019
 LO bounds    x[495]    0
 UP bounds    x[495]    20019
 LO bounds    x[496]    0
 UP bounds    x[496]    20019
 LO bounds    x[497]    0
 UP bounds    x[497]    20019
 LO bounds    x[498]    0
 UP bounds    x[498]    20019
 LO bounds    x[499]    0
 UP bounds    x[499]    20019
 LO bounds    x[500]    0
 UP bounds    x[500]    20019
 LO bounds    x[501]    0
 UP bounds    x[501]    20019
 LO bounds    x[502]    0
 UP bounds    x[502]    20019
 LO bounds    x[503]    0
 UP bounds    x[503]    20019
 LO bounds    x[504]    0
 UP bounds    x[504]    20019
 LO bounds    x[505]    0
 UP bounds    x[505]    20019
 LO bounds    x[506]    0
 UP bounds    x[506]    20019
 LO bounds    x[507]    0
 UP bounds    x[507]    20019
 LO bounds    x[508]    0
 UP bounds    x[508]    20019
 LO bounds    x[509]    0
 UP bounds    x[509]    20019
 LO bounds    x[510]    0
 UP bounds    x[510]    20019
 LO bounds    x[511]    0
 UP bounds    x[511]    20019
 LO bounds    x[512]    0
 UP bounds    x[512]    20019
 LO bounds    x[513]    0
 UP bounds    x[513]    20019
 LO bounds    x[514]    0
 UP bounds    x[514]    20019
 LO bounds    x[515]    0
 UP bounds    x[515]    20019
 LO bounds    x[516]    0
 UP bounds    x[516]    20019
 LO bounds    x[517]    0
 UP bounds    x[517]    20019
 LO bounds    x[518]    0
 UP bounds    x[518]    20019
 LO bounds    x[519]    0
 UP bounds    x[519]    20019
 LO bounds    x[520]    0
 UP bounds    x[520]    20019
 LO bounds    x[521]    0
 UP bounds    x[521]    20019
 LO bounds    x[522]    0
 UP bounds    x[522]    20019
 LO bounds    x[523]    0
 UP bounds    x[523]    20019
 LO bounds    x[524]    0
 UP bounds    x[524]    20019
 LO bounds    x[525]    0
 UP bounds    x[525]    20019
 LO bounds    x[526]    0
 UP bounds    x[526]    20019
 LO bounds    x[527]    0
 UP bounds    x[527]    20019
 LO bounds    x[528]    0
 UP bounds    x[528]    20019
 LO bounds    x[529]    0
 UP bounds    x[529]    20019
 LO bounds    x[530]    0
 UP bounds    x[530]    20019
 LO bounds    x[531]    0
 UP bounds    x[531]    20019
 LO bounds    x[532]    0
 UP bounds    x[532]    20019
 LO bounds    x[533]    0
 UP bounds    x[533]    20019
 LO bounds    x[534]    0
 UP bounds    x[534]    20019
 LO bounds    x[535]    0
 UP bounds    x[535]    20019
 LO bounds    x[536]    0
 UP bounds    x[536]    20019
 LO bounds    x[537]    0
 UP bounds    x[537]    20019
 LO bounds    x[538]    0
 UP bounds    x[538]    20019
 LO bounds    x[539]    0
 UP bounds    x[539]    20019
 LO bounds    x[540]    0
 UP bounds    x[540]    20019
 LO bounds    x[541]    0
 UP bounds    x[541]    20019
 LO bounds    x[542]    0
 UP bounds    x[542]    20019
 LO bounds    x[543]    0
 UP bounds    x[543]    20019
 LO bounds    x[544]    0
 UP bounds    x[544]    20019
 LO bounds    x[545]    0
 UP bounds    x[545]    20019
 LO bounds    x[546]    0
 UP bounds    x[546]    20019
 LO bounds    x[547]    0
 UP bounds    x[547]    20019
 LO bounds    x[548]    0
 UP bounds    x[548]    20019
 LO bounds    x[549]    0
 UP bounds    x[549]    20019
 LO bounds    x[550]    0
 UP bounds    x[550]    20019
 LO bounds    x[551]    0
 UP bounds    x[551]    20019
 LO bounds    x[552]    0
 UP bounds    x[552]    20019
 LO bounds    x[553]    0
 UP bounds    x[553]    20019
 LO bounds    x[554]    0
 UP bounds    x[554]    20019
 LO bounds    x[555]    0
 UP bounds    x[555]    20019
 LO bounds    x[556]    0
 UP bounds    x[556]    20019
 LO bounds    x[557]    0
 UP bounds    x[557]    20019
 LO bounds    x[558]    0
 UP bounds    x[558]    20019
 LO bounds    x[559]    0
 UP bounds    x[559]    20019
 LO bounds    x[560]    0
 UP bounds    x[560]    20019
 LO bounds    x[561]    0
 UP bounds    x[561]    20019
 LO bounds    x[562]    0
 UP bounds    x[562]    20019
 LO bounds    x[563]    0
 UP bounds    x[563]    20019
 LO bounds    x[564]    0
 UP bounds    x[564]    20019
 LO bounds    x[565]    0
 UP bounds    x[565]    20019
 LO bounds    x[566]    0
 UP bounds    x[566]    20019
 LO bounds    x[567]    0
 UP bounds    x[567]    20019
 LO bounds    x[568]    0
 UP bounds    x[568]    20019
 LO bounds    x[569]    0
 UP bounds    x[569]    20019
 LO bounds    x[570]    0
 UP bounds    x[570]    20019
 LO bounds    x[571]    0
 UP bounds    x[571]    20019
 LO bounds    x[572]    0
 UP bounds    x[572]    20019
 LO bounds    x[573]    0
 UP bounds    x[573]    20019
 LO bounds    x[574]    0
 UP bounds    x[574]    20019
 LO bounds    x[575]    0
 UP bounds    x[575]    20019
 LO bounds    x[576]    0
 UP bounds    x[576]    20019
 LO bounds    x[577]    0
 UP bounds    x[577]    20019
 LO bounds    x[578]    0
 UP bounds    x[578]    20019
 LO bounds    x[579]    0
 UP bounds    x[579]    20019
 LO bounds    x[580]    0
 UP bounds    x[580]    20019
 LO bounds    x[581]    0
 UP bounds    x[581]    20019
 LO bounds    x[582]    0
 UP bounds    x[582]    20019
 LO bounds    x[583]    0
 UP bounds    x[583]    20019
 LO bounds    x[584]    0
 UP bounds    x[584]    20019
 LO bounds    x[585]    0
 UP bounds    x[585]    20019
 LO bounds    x[586]    0
 UP bounds    x[586]    20019
 LO bounds    x[587]    0
 UP bounds    x[587]    20019
 LO bounds    x[588]    0
 UP bounds    x[588]    20019
 LO bounds    x[589]    0
 UP bounds    x[589]    20019
 LO bounds    x[590]    0
 UP bounds    x[590]    20019
 LO bounds    x[591]    0
 UP bounds    x[591]    20019
 LO bounds    x[592]    0
 UP bounds    x[592]    20019
 LO bounds    x[593]    0
 UP bounds    x[593]    20019
 LO bounds    x[594]    0
 UP bounds    x[594]    20019
 LO bounds    x[595]    0
 UP bounds    x[595]    20019
 LO bounds    x[596]    0
 UP bounds    x[596]    20019
 LO bounds    x[597]    0
 UP bounds    x[597]    20019
 LO bounds    x[598]    0
 UP bounds    x[598]    20019
 LO bounds    x[599]    0
 UP bounds    x[599]    20019
 LO bounds    x[600]    0
 UP bounds    x[600]    20019
 LO bounds    x[601]    0
 UP bounds    x[601]    18298
 LO bounds    x[602]    0
 UP bounds    x[602]    18298
 LO bounds    x[603]    0
 UP bounds    x[603]    18298
 LO bounds    x[604]    0
 UP bounds    x[604]    18298
 LO bounds    x[605]    0
 UP bounds    x[605]    18298
 LO bounds    x[606]    0
 UP bounds    x[606]    18298
 LO bounds    x[607]    0
 UP bounds    x[607]    18298
 LO bounds    x[608]    0
 UP bounds    x[608]    18298
 LO bounds    x[609]    0
 UP bounds    x[609]    18298
 LO bounds    x[610]    0
 UP bounds    x[610]    18298
 LO bounds    x[611]    0
 UP bounds    x[611]    18298
 LO bounds    x[612]    0
 UP bounds    x[612]    18298
 LO bounds    x[613]    0
 UP bounds    x[613]    18298
 LO bounds    x[614]    0
 UP bounds    x[614]    18298
 LO bounds    x[615]    0
 UP bounds    x[615]    18298
 LO bounds    x[616]    0
 UP bounds    x[616]    18298
 LO bounds    x[617]    0
 UP bounds    x[617]    18298
 LO bounds    x[618]    0
 UP bounds    x[618]    18298
 LO bounds    x[619]    0
 UP bounds    x[619]    18298
 LO bounds    x[620]    0
 UP bounds    x[620]    18298
 LO bounds    x[621]    0
 UP bounds    x[621]    18298
 LO bounds    x[622]    0
 UP bounds    x[622]    18298
 LO bounds    x[623]    0
 UP bounds    x[623]    18298
 LO bounds    x[624]    0
 UP bounds    x[624]    18298
 LO bounds    x[625]    0
 UP bounds    x[625]    18298
 LO bounds    x[626]    0
 UP bounds    x[626]    18298
 LO bounds    x[627]    0
 UP bounds    x[627]    18298
 LO bounds    x[628]    0
 UP bounds    x[628]    18298
 LO bounds    x[629]    0
 UP bounds    x[629]    18298
 LO bounds    x[630]    0
 UP bounds    x[630]    18298
 LO bounds    x[631]    0
 UP bounds    x[631]    18298
 LO bounds    x[632]    0
 UP bounds    x[632]    18298
 LO bounds    x[633]    0
 UP bounds    x[633]    18298
 LO bounds    x[634]    0
 UP bounds    x[634]    18298
 LO bounds    x[635]    0
 UP bounds    x[635]    18298
 LO bounds    x[636]    0
 UP bounds    x[636]    18298
 LO bounds    x[637]    0
 UP bounds    x[637]    18298
 LO bounds    x[638]    0
 UP bounds    x[638]    18298
 LO bounds    x[639]    0
 UP bounds    x[639]    18298
 LO bounds    x[640]    0
 UP bounds    x[640]    18298
 LO bounds    x[641]    0
 UP bounds    x[641]    18298
 LO bounds    x[642]    0
 UP bounds    x[642]    18298
 LO bounds    x[643]    0
 UP bounds    x[643]    18298
 LO bounds    x[644]    0
 UP bounds    x[644]    18298
 LO bounds    x[645]    0
 UP bounds    x[645]    18298
 LO bounds    x[646]    0
 UP bounds    x[646]    18298
 LO bounds    x[647]    0
 UP bounds    x[647]    18298
 LO bounds    x[648]    0
 UP bounds    x[648]    18298
 LO bounds    x[649]    0
 UP bounds    x[649]    18298
 LO bounds    x[650]    0
 UP bounds    x[650]    18298
 LO bounds    x[651]    0
 UP bounds    x[651]    18298
 LO bounds    x[652]    0
 UP bounds    x[652]    18298
 LO bounds    x[653]    0
 UP bounds    x[653]    18298
 LO bounds    x[654]    0
 UP bounds    x[654]    18298
 LO bounds    x[655]    0
 UP bounds    x[655]    18298
 LO bounds    x[656]    0
 UP bounds    x[656]    18298
 LO bounds    x[657]    0
 UP bounds    x[657]    18298
 LO bounds    x[658]    0
 UP bounds    x[658]    18298
 LO bounds    x[659]    0
 UP bounds    x[659]    18298
 LO bounds    x[660]    0
 UP bounds    x[660]    18298
 LO bounds    x[661]    0
 UP bounds    x[661]    18298
 LO bounds    x[662]    0
 UP bounds    x[662]    18298
 LO bounds    x[663]    0
 UP bounds    x[663]    18298
 LO bounds    x[664]    0
 UP bounds    x[664]    18298
 LO bounds    x[665]    0
 UP bounds    x[665]    18298
 LO bounds    x[666]    0
 UP bounds    x[666]    18298
 LO bounds    x[667]    0
 UP bounds    x[667]    18298
 LO bounds    x[668]    0
 UP bounds    x[668]    18298
 LO bounds    x[669]    0
 UP bounds    x[669]    18298
 LO bounds    x[670]    0
 UP bounds    x[670]    18298
 LO bounds    x[671]    0
 UP bounds    x[671]    18298
 LO bounds    x[672]    0
 UP bounds    x[672]    18298
 LO bounds    x[673]    0
 UP bounds    x[673]    18298
 LO bounds    x[674]    0
 UP bounds    x[674]    18298
 LO bounds    x[675]    0
 UP bounds    x[675]    18298
 LO bounds    x[676]    0
 UP bounds    x[676]    18298
 LO bounds    x[677]    0
 UP bounds    x[677]    18298
 LO bounds    x[678]    0
 UP bounds    x[678]    18298
 LO bounds    x[679]    0
 UP bounds    x[679]    18298
 LO bounds    x[680]    0
 UP bounds    x[680]    18298
 LO bounds    x[681]    0
 UP bounds    x[681]    18298
 LO bounds    x[682]    0
 UP bounds    x[682]    18298
 LO bounds    x[683]    0
 UP bounds    x[683]    18298
 LO bounds    x[684]    0
 UP bounds    x[684]    18298
 LO bounds    x[685]    0
 UP bounds    x[685]    18298
 LO bounds    x[686]    0
 UP bounds    x[686]    18298
 LO bounds    x[687]    0
 UP bounds    x[687]    18298
 LO bounds    x[688]    0
 UP bounds    x[688]    18298
 LO bounds    x[689]    0
 UP bounds    x[689]    18298
 LO bounds    x[690]    0
 UP bounds    x[690]    18298
 LO bounds    x[691]    0
 UP bounds    x[691]    18298
 LO bounds    x[692]    0
 UP bounds    x[692]    18298
 LO bounds    x[693]    0
 UP bounds    x[693]    18298
 LO bounds    x[694]    0
 UP bounds    x[694]    18298
 LO bounds    x[695]    0
 UP bounds    x[695]    18298
 LO bounds    x[696]    0
 UP bounds    x[696]    18298
 LO bounds    x[697]    0
 UP bounds    x[697]    18298
 LO bounds    x[698]    0
 UP bounds    x[698]    18298
 LO bounds    x[699]    0
 UP bounds    x[699]    18298
 LO bounds    x[700]    0
 UP bounds    x[700]    18298
 LO bounds    x[701]    0
 UP bounds    x[701]    18298
 LO bounds    x[702]    0
 UP bounds    x[702]    18298
 LO bounds    x[703]    0
 UP bounds    x[703]    18298
 LO bounds    x[704]    0
 UP bounds    x[704]    18298
 LO bounds    x[705]    0
 UP bounds    x[705]    18298
 LO bounds    x[706]    0
 UP bounds    x[706]    18298
 LO bounds    x[707]    0
 UP bounds    x[707]    18298
 LO bounds    x[708]    0
 UP bounds    x[708]    18298
 LO bounds    x[709]    0
 UP bounds    x[709]    18298
 LO bounds    x[710]    0
 UP bounds    x[710]    18298
 LO bounds    x[711]    0
 UP bounds    x[711]    18298
 LO bounds    x[712]    0
 UP bounds    x[712]    18298
 LO bounds    x[713]    0
 UP bounds    x[713]    18298
 LO bounds    x[714]    0
 UP bounds    x[714]    18298
 LO bounds    x[715]    0
 UP bounds    x[715]    18298
 LO bounds    x[716]    0
 UP bounds    x[716]    18298
 LO bounds    x[717]    0
 UP bounds    x[717]    18298
 LO bounds    x[718]    0
 UP bounds    x[718]    18298
 LO bounds    x[719]    0
 UP bounds    x[719]    18298
 LO bounds    x[720]    0
 UP bounds    x[720]    16531
 LO bounds    x[721]    0
 UP bounds    x[721]    16531
 LO bounds    x[722]    0
 UP bounds    x[722]    16531
 LO bounds    x[723]    0
 UP bounds    x[723]    16531
 LO bounds    x[724]    0
 UP bounds    x[724]    16531
 LO bounds    x[725]    0
 UP bounds    x[725]    16531
 LO bounds    x[726]    0
 UP bounds    x[726]    16531
 LO bounds    x[727]    0
 UP bounds    x[727]    16531
 LO bounds    x[728]    0
 UP bounds    x[728]    16531
 LO bounds    x[729]    0
 UP bounds    x[729]    16531
 LO bounds    x[730]    0
 UP bounds    x[730]    16531
 LO bounds    x[731]    0
 UP bounds    x[731]    16531
 LO bounds    x[732]    0
 UP bounds    x[732]    16531
 LO bounds    x[733]    0
 UP bounds    x[733]    16531
 LO bounds    x[734]    0
 UP bounds    x[734]    16531
 LO bounds    x[735]    0
 UP bounds    x[735]    16531
 LO bounds    x[736]    0
 UP bounds    x[736]    16531
 LO bounds    x[737]    0
 UP bounds    x[737]    16531
 LO bounds    x[738]    0
 UP bounds    x[738]    16531
 LO bounds    x[739]    0
 UP bounds    x[739]    16531
 LO bounds    x[740]    0
 UP bounds    x[740]    16531
 LO bounds    x[741]    0
 UP bounds    x[741]    16531
 LO bounds    x[742]    0
 UP bounds    x[742]    16531
 LO bounds    x[743]    0
 UP bounds    x[743]    16531
 LO bounds    x[744]    0
 UP bounds    x[744]    16531
 LO bounds    x[745]    0
 UP bounds    x[745]    16531
 LO bounds    x[746]    0
 UP bounds    x[746]    16531
 LO bounds    x[747]    0
 UP bounds    x[747]    16531
 LO bounds    x[748]    0
 UP bounds    x[748]    16531
 LO bounds    x[749]    0
 UP bounds    x[749]    16531
 LO bounds    x[750]    0
 UP bounds    x[750]    16531
 LO bounds    x[751]    0
 UP bounds    x[751]    16531
 LO bounds    x[752]    0
 UP bounds    x[752]    16531
 LO bounds    x[753]    0
 UP bounds    x[753]    16531
 LO bounds    x[754]    0
 UP bounds    x[754]    16531
 LO bounds    x[755]    0
 UP bounds    x[755]    16531
 LO bounds    x[756]    0
 UP bounds    x[756]    16531
 LO bounds    x[757]    0
 UP bounds    x[757]    16531
 LO bounds    x[758]    0
 UP bounds    x[758]    16531
 LO bounds    x[759]    0
 UP bounds    x[759]    16531
 LO bounds    x[760]    0
 UP bounds    x[760]    16531
 LO bounds    x[761]    0
 UP bounds    x[761]    16531
 LO bounds    x[762]    0
 UP bounds    x[762]    16531
 LO bounds    x[763]    0
 UP bounds    x[763]    16531
 LO bounds    x[764]    0
 UP bounds    x[764]    16531
 LO bounds    x[765]    0
 UP bounds    x[765]    16531
 LO bounds    x[766]    0
 UP bounds    x[766]    16531
 LO bounds    x[767]    0
 UP bounds    x[767]    16531
 LO bounds    x[768]    0
 UP bounds    x[768]    16531
 LO bounds    x[769]    0
 UP bounds    x[769]    16531
 LO bounds    x[770]    0
 UP bounds    x[770]    16531
 LO bounds    x[771]    0
 UP bounds    x[771]    16531
 LO bounds    x[772]    0
 UP bounds    x[772]    16531
 LO bounds    x[773]    0
 UP bounds    x[773]    16531
 LO bounds    x[774]    0
 UP bounds    x[774]    16531
 LO bounds    x[775]    0
 UP bounds    x[775]    16531
 LO bounds    x[776]    0
 UP bounds    x[776]    16531
 LO bounds    x[777]    0
 UP bounds    x[777]    16531
 LO bounds    x[778]    0
 UP bounds    x[778]    16531
 LO bounds    x[779]    0
 UP bounds    x[779]    16531
 LO bounds    x[780]    0
 UP bounds    x[780]    16531
 LO bounds    x[781]    0
 UP bounds    x[781]    16531
 LO bounds    x[782]    0
 UP bounds    x[782]    16531
 LO bounds    x[783]    0
 UP bounds    x[783]    16531
 LO bounds    x[784]    0
 UP bounds    x[784]    16531
 LO bounds    x[785]    0
 UP bounds    x[785]    16531
 LO bounds    x[786]    0
 UP bounds    x[786]    16531
 LO bounds    x[787]    0
 UP bounds    x[787]    16531
 LO bounds    x[788]    0
 UP bounds    x[788]    16531
 LO bounds    x[789]    0
 UP bounds    x[789]    16531
 LO bounds    x[790]    0
 UP bounds    x[790]    16531
 LO bounds    x[791]    0
 UP bounds    x[791]    16531
 LO bounds    x[792]    0
 UP bounds    x[792]    16531
 LO bounds    x[793]    0
 UP bounds    x[793]    16531
 LO bounds    x[794]    0
 UP bounds    x[794]    16531
 LO bounds    x[795]    0
 UP bounds    x[795]    16531
 LO bounds    x[796]    0
 UP bounds    x[796]    16531
 LO bounds    x[797]    0
 UP bounds    x[797]    16531
 LO bounds    x[798]    0
 UP bounds    x[798]    16531
 LO bounds    x[799]    0
 UP bounds    x[799]    16531
 LO bounds    x[800]    0
 UP bounds    x[800]    16531
 LO bounds    x[801]    0
 UP bounds    x[801]    16531
 LO bounds    x[802]    0
 UP bounds    x[802]    16531
 LO bounds    x[803]    0
 UP bounds    x[803]    16531
 LO bounds    x[804]    0
 UP bounds    x[804]    16531
 LO bounds    x[805]    0
 UP bounds    x[805]    16531
 LO bounds    x[806]    0
 UP bounds    x[806]    16531
 LO bounds    x[807]    0
 UP bounds    x[807]    16531
 LO bounds    x[808]    0
 UP bounds    x[808]    16531
 LO bounds    x[809]    0
 UP bounds    x[809]    16531
 LO bounds    x[810]    0
 UP bounds    x[810]    16531
 LO bounds    x[811]    0
 UP bounds    x[811]    16531
 LO bounds    x[812]    0
 UP bounds    x[812]    16531
 LO bounds    x[813]    0
 UP bounds    x[813]    16531
 LO bounds    x[814]    0
 UP bounds    x[814]    16531
 LO bounds    x[815]    0
 UP bounds    x[815]    16531
 LO bounds    x[816]    0
 UP bounds    x[816]    16531
 LO bounds    x[817]    0
 UP bounds    x[817]    16531
 LO bounds    x[818]    0
 UP bounds    x[818]    16531
 LO bounds    x[819]    0
 UP bounds    x[819]    16531
 LO bounds    x[820]    0
 UP bounds    x[820]    16531
 LO bounds    x[821]    0
 UP bounds    x[821]    16531
 LO bounds    x[822]    0
 UP bounds    x[822]    16531
 LO bounds    x[823]    0
 UP bounds    x[823]    16531
 LO bounds    x[824]    0
 UP bounds    x[824]    16531
 LO bounds    x[825]    0
 UP bounds    x[825]    16531
 LO bounds    x[826]    0
 UP bounds    x[826]    16531
 LO bounds    x[827]    0
 UP bounds    x[827]    16531
 LO bounds    x[828]    0
 UP bounds    x[828]    16531
 LO bounds    x[829]    0
 UP bounds    x[829]    16531
 LO bounds    x[830]    0
 UP bounds    x[830]    16531
 LO bounds    x[831]    0
 UP bounds    x[831]    16531
 LO bounds    x[832]    0
 UP bounds    x[832]    16531
 LO bounds    x[833]    0
 UP bounds    x[833]    16531
 LO bounds    x[834]    0
 UP bounds    x[834]    16531
 LO bounds    x[835]    0
 UP bounds    x[835]    16531
 LO bounds    x[836]    0
 UP bounds    x[836]    16531
 LO bounds    x[837]    0
 UP bounds    x[837]    16531
 LO bounds    x[838]    0
 UP bounds    x[838]    16531
 LO bounds    x[839]    0
 UP bounds    x[839]    19386
 LO bounds    x[840]    0
 UP bounds    x[840]    19386
 LO bounds    x[841]    0
 UP bounds    x[841]    19386
 LO bounds    x[842]    0
 UP bounds    x[842]    19386
 LO bounds    x[843]    0
 UP bounds    x[843]    19386
 LO bounds    x[844]    0
 UP bounds    x[844]    19386
 LO bounds    x[845]    0
 UP bounds    x[845]    19386
 LO bounds    x[846]    0
 UP bounds    x[846]    19386
 LO bounds    x[847]    0
 UP bounds    x[847]    19386
 LO bounds    x[848]    0
 UP bounds    x[848]    19386
 LO bounds    x[849]    0
 UP bounds    x[849]    19386
 LO bounds    x[850]    0
 UP bounds    x[850]    19386
 LO bounds    x[851]    0
 UP bounds    x[851]    19386
 LO bounds    x[852]    0
 UP bounds    x[852]    19386
 LO bounds    x[853]    0
 UP bounds    x[853]    19386
 LO bounds    x[854]    0
 UP bounds    x[854]    19386
 LO bounds    x[855]    0
 UP bounds    x[855]    19386
 LO bounds    x[856]    0
 UP bounds    x[856]    19386
 LO bounds    x[857]    0
 UP bounds    x[857]    19386
 LO bounds    x[858]    0
 UP bounds    x[858]    19386
 LO bounds    x[859]    0
 UP bounds    x[859]    19386
 LO bounds    x[860]    0
 UP bounds    x[860]    19386
 LO bounds    x[861]    0
 UP bounds    x[861]    19386
 LO bounds    x[862]    0
 UP bounds    x[862]    19386
 LO bounds    x[863]    0
 UP bounds    x[863]    19386
 LO bounds    x[864]    0
 UP bounds    x[864]    19386
 LO bounds    x[865]    0
 UP bounds    x[865]    19386
 LO bounds    x[866]    0
 UP bounds    x[866]    19386
 LO bounds    x[867]    0
 UP bounds    x[867]    19386
 LO bounds    x[868]    0
 UP bounds    x[868]    19386
 LO bounds    x[869]    0
 UP bounds    x[869]    19386
 LO bounds    x[870]    0
 UP bounds    x[870]    19386
 LO bounds    x[871]    0
 UP bounds    x[871]    19386
 LO bounds    x[872]    0
 UP bounds    x[872]    19386
 LO bounds    x[873]    0
 UP bounds    x[873]    19386
 LO bounds    x[874]    0
 UP bounds    x[874]    19386
 LO bounds    x[875]    0
 UP bounds    x[875]    19386
 LO bounds    x[876]    0
 UP bounds    x[876]    19386
 LO bounds    x[877]    0
 UP bounds    x[877]    19386
 LO bounds    x[878]    0
 UP bounds    x[878]    19386
 LO bounds    x[879]    0
 UP bounds    x[879]    19386
 LO bounds    x[880]    0
 UP bounds    x[880]    19386
 LO bounds    x[881]    0
 UP bounds    x[881]    19386
 LO bounds    x[882]    0
 UP bounds    x[882]    19386
 LO bounds    x[883]    0
 UP bounds    x[883]    19386
 LO bounds    x[884]    0
 UP bounds    x[884]    19386
 LO bounds    x[885]    0
 UP bounds    x[885]    19386
 LO bounds    x[886]    0
 UP bounds    x[886]    19386
 LO bounds    x[887]    0
 UP bounds    x[887]    19386
 LO bounds    x[888]    0
 UP bounds    x[888]    19386
 LO bounds    x[889]    0
 UP bounds    x[889]    19386
 LO bounds    x[890]    0
 UP bounds    x[890]    19386
 LO bounds    x[891]    0
 UP bounds    x[891]    19386
 LO bounds    x[892]    0
 UP bounds    x[892]    19386
 LO bounds    x[893]    0
 UP bounds    x[893]    19386
 LO bounds    x[894]    0
 UP bounds    x[894]    19386
 LO bounds    x[895]    0
 UP bounds    x[895]    19386
 LO bounds    x[896]    0
 UP bounds    x[896]    19386
 LO bounds    x[897]    0
 UP bounds    x[897]    19386
 LO bounds    x[898]    0
 UP bounds    x[898]    19386
 LO bounds    x[899]    0
 UP bounds    x[899]    19386
 LO bounds    x[900]    0
 UP bounds    x[900]    19386
 LO bounds    x[901]    0
 UP bounds    x[901]    19386
 LO bounds    x[902]    0
 UP bounds    x[902]    19386
 LO bounds    x[903]    0
 UP bounds    x[903]    19386
 LO bounds    x[904]    0
 UP bounds    x[904]    19386
 LO bounds    x[905]    0
 UP bounds    x[905]    19386
 LO bounds    x[906]    0
 UP bounds    x[906]    19386
 LO bounds    x[907]    0
 UP bounds    x[907]    19386
 LO bounds    x[908]    0
 UP bounds    x[908]    19386
 LO bounds    x[909]    0
 UP bounds    x[909]    19386
 LO bounds    x[910]    0
 UP bounds    x[910]    19386
 LO bounds    x[911]    0
 UP bounds    x[911]    19386
 LO bounds    x[912]    0
 UP bounds    x[912]    19386
 LO bounds    x[913]    0
 UP bounds    x[913]    19386
 LO bounds    x[914]    0
 UP bounds    x[914]    19386
 LO bounds    x[915]    0
 UP bounds    x[915]    19386
 LO bounds    x[916]    0
 UP bounds    x[916]    19386
 LO bounds    x[917]    0
 UP bounds    x[917]    19386
 LO bounds    x[918]    0
 UP bounds    x[918]    19386
 LO bounds    x[919]    0
 UP bounds    x[919]    19386
 LO bounds    x[920]    0
 UP bounds    x[920]    19386
 LO bounds    x[921]    0
 UP bounds    x[921]    19386
 LO bounds    x[922]    0
 UP bounds    x[922]    19386
 LO bounds    x[923]    0
 UP bounds    x[923]    19386
 LO bounds    x[924]    0
 UP bounds    x[924]    19386
 LO bounds    x[925]    0
 UP bounds    x[925]    19386
 LO bounds    x[926]    0
 UP bounds    x[926]    19386
 LO bounds    x[927]    0
 UP bounds    x[927]    19386
 LO bounds    x[928]    0
 UP bounds    x[928]    19386
 LO bounds    x[929]    0
 UP bounds    x[929]    19386
 LO bounds    x[930]    0
 UP bounds    x[930]    19386
 LO bounds    x[931]    0
 UP bounds    x[931]    19386
 LO bounds    x[932]    0
 UP bounds    x[932]    19386
 LO bounds    x[933]    0
 UP bounds    x[933]    19386
 LO bounds    x[934]    0
 UP bounds    x[934]    19386
 LO bounds    x[935]    0
 UP bounds    x[935]    19386
 LO bounds    x[936]    0
 UP bounds    x[936]    19386
 LO bounds    x[937]    0
 UP bounds    x[937]    19386
 LO bounds    x[938]    0
 UP bounds    x[938]    19386
 LO bounds    x[939]    0
 UP bounds    x[939]    19386
 LO bounds    x[940]    0
 UP bounds    x[940]    19386
 LO bounds    x[941]    0
 UP bounds    x[941]    19386
 LO bounds    x[942]    0
 UP bounds    x[942]    19386
 LO bounds    x[943]    0
 UP bounds    x[943]    19386
 LO bounds    x[944]    0
 UP bounds    x[944]    19386
 LO bounds    x[945]    0
 UP bounds    x[945]    19386
 LO bounds    x[946]    0
 UP bounds    x[946]    19386
 LO bounds    x[947]    0
 UP bounds    x[947]    19386
 LO bounds    x[948]    0
 UP bounds    x[948]    19386
 LO bounds    x[949]    0
 UP bounds    x[949]    19386
 LO bounds    x[950]    0
 UP bounds    x[950]    19386
 LO bounds    x[951]    0
 UP bounds    x[951]    19386
 LO bounds    x[952]    0
 UP bounds    x[952]    19386
 LO bounds    x[953]    0
 UP bounds    x[953]    19386
 LO bounds    x[954]    0
 UP bounds    x[954]    19386
 LO bounds    x[955]    0
 UP bounds    x[955]    19386
 LO bounds    x[956]    0
 UP bounds    x[956]    19386
 LO bounds    x[957]    0
 UP bounds    x[957]    19386
 LO bounds    x[958]    0
 UP bounds    x[958]    19269
 LO bounds    x[959]    0
 UP bounds    x[959]    19269
 LO bounds    x[960]    0
 UP bounds    x[960]    19269
 LO bounds    x[961]    0
 UP bounds    x[961]    19269
 LO bounds    x[962]    0
 UP bounds    x[962]    19269
 LO bounds    x[963]    0
 UP bounds    x[963]    19269
 LO bounds    x[964]    0
 UP bounds    x[964]    19269
 LO bounds    x[965]    0
 UP bounds    x[965]    19269
 LO bounds    x[966]    0
 UP bounds    x[966]    19269
 LO bounds    x[967]    0
 UP bounds    x[967]    19269
 LO bounds    x[968]    0
 UP bounds    x[968]    19269
 LO bounds    x[969]    0
 UP bounds    x[969]    19269
 LO bounds    x[970]    0
 UP bounds    x[970]    19269
 LO bounds    x[971]    0
 UP bounds    x[971]    19269
 LO bounds    x[972]    0
 UP bounds    x[972]    19269
 LO bounds    x[973]    0
 UP bounds    x[973]    19269
 LO bounds    x[974]    0
 UP bounds    x[974]    19269
 LO bounds    x[975]    0
 UP bounds    x[975]    19269
 LO bounds    x[976]    0
 UP bounds    x[976]    19269
 LO bounds    x[977]    0
 UP bounds    x[977]    19269
 LO bounds    x[978]    0
 UP bounds    x[978]    19269
 LO bounds    x[979]    0
 UP bounds    x[979]    19269
 LO bounds    x[980]    0
 UP bounds    x[980]    19269
 LO bounds    x[981]    0
 UP bounds    x[981]    19269
 LO bounds    x[982]    0
 UP bounds    x[982]    19269
 LO bounds    x[983]    0
 UP bounds    x[983]    19269
 LO bounds    x[984]    0
 UP bounds    x[984]    19269
 LO bounds    x[985]    0
 UP bounds    x[985]    19269
 LO bounds    x[986]    0
 UP bounds    x[986]    19269
 LO bounds    x[987]    0
 UP bounds    x[987]    19269
 LO bounds    x[988]    0
 UP bounds    x[988]    19269
 LO bounds    x[989]    0
 UP bounds    x[989]    19269
 LO bounds    x[990]    0
 UP bounds    x[990]    19269
 LO bounds    x[991]    0
 UP bounds    x[991]    19269
 LO bounds    x[992]    0
 UP bounds    x[992]    19269
 LO bounds    x[993]    0
 UP bounds    x[993]    19269
 LO bounds    x[994]    0
 UP bounds    x[994]    19269
 LO bounds    x[995]    0
 UP bounds    x[995]    19269
 LO bounds    x[996]    0
 UP bounds    x[996]    19269
 LO bounds    x[997]    0
 UP bounds    x[997]    19269
 LO bounds    x[998]    0
 UP bounds    x[998]    19269
 LO bounds    x[999]    0
 UP bounds    x[999]    19269
 LO bounds    x[1000]   0
 UP bounds    x[1000]   19269
 LO bounds    x[1001]   0
 UP bounds    x[1001]   19269
 LO bounds    x[1002]   0
 UP bounds    x[1002]   19269
 LO bounds    x[1003]   0
 UP bounds    x[1003]   19269
 LO bounds    x[1004]   0
 UP bounds    x[1004]   19269
 LO bounds    x[1005]   0
 UP bounds    x[1005]   19269
 LO bounds    x[1006]   0
 UP bounds    x[1006]   19269
 LO bounds    x[1007]   0
 UP bounds    x[1007]   19269
 LO bounds    x[1008]   0
 UP bounds    x[1008]   19269
 LO bounds    x[1009]   0
 UP bounds    x[1009]   19269
 LO bounds    x[1010]   0
 UP bounds    x[1010]   19269
 LO bounds    x[1011]   0
 UP bounds    x[1011]   19269
 LO bounds    x[1012]   0
 UP bounds    x[1012]   19269
 LO bounds    x[1013]   0
 UP bounds    x[1013]   19269
 LO bounds    x[1014]   0
 UP bounds    x[1014]   19269
 LO bounds    x[1015]   0
 UP bounds    x[1015]   19269
 LO bounds    x[1016]   0
 UP bounds    x[1016]   19269
 LO bounds    x[1017]   0
 UP bounds    x[1017]   19269
 LO bounds    x[1018]   0
 UP bounds    x[1018]   19269
 LO bounds    x[1019]   0
 UP bounds    x[1019]   19269
 LO bounds    x[1020]   0
 UP bounds    x[1020]   19269
 LO bounds    x[1021]   0
 UP bounds    x[1021]   19269
 LO bounds    x[1022]   0
 UP bounds    x[1022]   19269
 LO bounds    x[1023]   0
 UP bounds    x[1023]   19269
 LO bounds    x[1024]   0
 UP bounds    x[1024]   19269
 LO bounds    x[1025]   0
 UP bounds    x[1025]   19269
 LO bounds    x[1026]   0
 UP bounds    x[1026]   19269
 LO bounds    x[1027]   0
 UP bounds    x[1027]   19269
 LO bounds    x[1028]   0
 UP bounds    x[1028]   19269
 LO bounds    x[1029]   0
 UP bounds    x[1029]   19269
 LO bounds    x[1030]   0
 UP bounds    x[1030]   19269
 LO bounds    x[1031]   0
 UP bounds    x[1031]   19269
 LO bounds    x[1032]   0
 UP bounds    x[1032]   19269
 LO bounds    x[1033]   0
 UP bounds    x[1033]   19269
 LO bounds    x[1034]   0
 UP bounds    x[1034]   19269
 LO bounds    x[1035]   0
 UP bounds    x[1035]   19269
 LO bounds    x[1036]   0
 UP bounds    x[1036]   19269
 LO bounds    x[1037]   0
 UP bounds    x[1037]   19269
 LO bounds    x[1038]   0
 UP bounds    x[1038]   19269
 LO bounds    x[1039]   0
 UP bounds    x[1039]   19269
 LO bounds    x[1040]   0
 UP bounds    x[1040]   19269
 LO bounds    x[1041]   0
 UP bounds    x[1041]   19269
 LO bounds    x[1042]   0
 UP bounds    x[1042]   19269
 LO bounds    x[1043]   0
 UP bounds    x[1043]   19269
 LO bounds    x[1044]   0
 UP bounds    x[1044]   19269
 LO bounds    x[1045]   0
 UP bounds    x[1045]   19269
 LO bounds    x[1046]   0
 UP bounds    x[1046]   19269
 LO bounds    x[1047]   0
 UP bounds    x[1047]   19269
 LO bounds    x[1048]   0
 UP bounds    x[1048]   19269
 LO bounds    x[1049]   0
 UP bounds    x[1049]   19269
 LO bounds    x[1050]   0
 UP bounds    x[1050]   19269
 LO bounds    x[1051]   0
 UP bounds    x[1051]   19269
 LO bounds    x[1052]   0
 UP bounds    x[1052]   19269
 LO bounds    x[1053]   0
 UP bounds    x[1053]   19269
 LO bounds    x[1054]   0
 UP bounds    x[1054]   19269
 LO bounds    x[1055]   0
 UP bounds    x[1055]   19269
 LO bounds    x[1056]   0
 UP bounds    x[1056]   19269
 LO bounds    x[1057]   0
 UP bounds    x[1057]   19269
 LO bounds    x[1058]   0
 UP bounds    x[1058]   19269
 LO bounds    x[1059]   0
 UP bounds    x[1059]   19269
 LO bounds    x[1060]   0
 UP bounds    x[1060]   19269
 LO bounds    x[1061]   0
 UP bounds    x[1061]   19269
 LO bounds    x[1062]   0
 UP bounds    x[1062]   19269
 LO bounds    x[1063]   0
 UP bounds    x[1063]   19269
 LO bounds    x[1064]   0
 UP bounds    x[1064]   19269
 LO bounds    x[1065]   0
 UP bounds    x[1065]   19269
 LO bounds    x[1066]   0
 UP bounds    x[1066]   19269
 LO bounds    x[1067]   0
 UP bounds    x[1067]   19269
 LO bounds    x[1068]   0
 UP bounds    x[1068]   19269
 LO bounds    x[1069]   0
 UP bounds    x[1069]   19269
 LO bounds    x[1070]   0
 UP bounds    x[1070]   19269
 LO bounds    x[1071]   0
 UP bounds    x[1071]   19269
 LO bounds    x[1072]   0
 UP bounds    x[1072]   19269
 LO bounds    x[1073]   0
 UP bounds    x[1073]   19269
 LO bounds    x[1074]   0
 UP bounds    x[1074]   19269
 LO bounds    x[1075]   0
 UP bounds    x[1075]   19269
 LO bounds    x[1076]   0
 UP bounds    x[1076]   19269
 LO bounds    x[1077]   0
 UP bounds    x[1077]   20019
 LO bounds    x[1078]   0
 UP bounds    x[1078]   20019
 LO bounds    x[1079]   0
 UP bounds    x[1079]   20019
 LO bounds    x[1080]   0
 UP bounds    x[1080]   20019
 LO bounds    x[1081]   0
 UP bounds    x[1081]   20019
 LO bounds    x[1082]   0
 UP bounds    x[1082]   20019
 LO bounds    x[1083]   0
 UP bounds    x[1083]   20019
 LO bounds    x[1084]   0
 UP bounds    x[1084]   20019
 LO bounds    x[1085]   0
 UP bounds    x[1085]   20019
 LO bounds    x[1086]   0
 UP bounds    x[1086]   20019
 LO bounds    x[1087]   0
 UP bounds    x[1087]   20019
 LO bounds    x[1088]   0
 UP bounds    x[1088]   20019
 LO bounds    x[1089]   0
 UP bounds    x[1089]   20019
 LO bounds    x[1090]   0
 UP bounds    x[1090]   20019
 LO bounds    x[1091]   0
 UP bounds    x[1091]   20019
 LO bounds    x[1092]   0
 UP bounds    x[1092]   20019
 LO bounds    x[1093]   0
 UP bounds    x[1093]   20019
 LO bounds    x[1094]   0
 UP bounds    x[1094]   20019
 LO bounds    x[1095]   0
 UP bounds    x[1095]   20019
 LO bounds    x[1096]   0
 UP bounds    x[1096]   20019
 LO bounds    x[1097]   0
 UP bounds    x[1097]   20019
 LO bounds    x[1098]   0
 UP bounds    x[1098]   20019
 LO bounds    x[1099]   0
 UP bounds    x[1099]   20019
 LO bounds    x[1100]   0
 UP bounds    x[1100]   20019
 LO bounds    x[1101]   0
 UP bounds    x[1101]   20019
 LO bounds    x[1102]   0
 UP bounds    x[1102]   20019
 LO bounds    x[1103]   0
 UP bounds    x[1103]   20019
 LO bounds    x[1104]   0
 UP bounds    x[1104]   20019
 LO bounds    x[1105]   0
 UP bounds    x[1105]   20019
 LO bounds    x[1106]   0
 UP bounds    x[1106]   20019
 LO bounds    x[1107]   0
 UP bounds    x[1107]   20019
 LO bounds    x[1108]   0
 UP bounds    x[1108]   20019
 LO bounds    x[1109]   0
 UP bounds    x[1109]   20019
 LO bounds    x[1110]   0
 UP bounds    x[1110]   20019
 LO bounds    x[1111]   0
 UP bounds    x[1111]   20019
 LO bounds    x[1112]   0
 UP bounds    x[1112]   20019
 LO bounds    x[1113]   0
 UP bounds    x[1113]   20019
 LO bounds    x[1114]   0
 UP bounds    x[1114]   20019
 LO bounds    x[1115]   0
 UP bounds    x[1115]   20019
 LO bounds    x[1116]   0
 UP bounds    x[1116]   20019
 LO bounds    x[1117]   0
 UP bounds    x[1117]   20019
 LO bounds    x[1118]   0
 UP bounds    x[1118]   20019
 LO bounds    x[1119]   0
 UP bounds    x[1119]   20019
 LO bounds    x[1120]   0
 UP bounds    x[1120]   20019
 LO bounds    x[1121]   0
 UP bounds    x[1121]   20019
 LO bounds    x[1122]   0
 UP bounds    x[1122]   20019
 LO bounds    x[1123]   0
 UP bounds    x[1123]   20019
 LO bounds    x[1124]   0
 UP bounds    x[1124]   20019
 LO bounds    x[1125]   0
 UP bounds    x[1125]   20019
 LO bounds    x[1126]   0
 UP bounds    x[1126]   20019
 LO bounds    x[1127]   0
 UP bounds    x[1127]   20019
 LO bounds    x[1128]   0
 UP bounds    x[1128]   20019
 LO bounds    x[1129]   0
 UP bounds    x[1129]   20019
 LO bounds    x[1130]   0
 UP bounds    x[1130]   20019
 LO bounds    x[1131]   0
 UP bounds    x[1131]   20019
 LO bounds    x[1132]   0
 UP bounds    x[1132]   20019
 LO bounds    x[1133]   0
 UP bounds    x[1133]   20019
 LO bounds    x[1134]   0
 UP bounds    x[1134]   20019
 LO bounds    x[1135]   0
 UP bounds    x[1135]   20019
 LO bounds    x[1136]   0
 UP bounds    x[1136]   20019
 LO bounds    x[1137]   0
 UP bounds    x[1137]   20019
 LO bounds    x[1138]   0
 UP bounds    x[1138]   20019
 LO bounds    x[1139]   0
 UP bounds    x[1139]   20019
 LO bounds    x[1140]   0
 UP bounds    x[1140]   20019
 LO bounds    x[1141]   0
 UP bounds    x[1141]   20019
 LO bounds    x[1142]   0
 UP bounds    x[1142]   20019
 LO bounds    x[1143]   0
 UP bounds    x[1143]   20019
 LO bounds    x[1144]   0
 UP bounds    x[1144]   20019
 LO bounds    x[1145]   0
 UP bounds    x[1145]   20019
 LO bounds    x[1146]   0
 UP bounds    x[1146]   20019
 LO bounds    x[1147]   0
 UP bounds    x[1147]   20019
 LO bounds    x[1148]   0
 UP bounds    x[1148]   20019
 LO bounds    x[1149]   0
 UP bounds    x[1149]   20019
 LO bounds    x[1150]   0
 UP bounds    x[1150]   20019
 LO bounds    x[1151]   0
 UP bounds    x[1151]   20019
 LO bounds    x[1152]   0
 UP bounds    x[1152]   20019
 LO bounds    x[1153]   0
 UP bounds    x[1153]   20019
 LO bounds    x[1154]   0
 UP bounds    x[1154]   20019
 LO bounds    x[1155]   0
 UP bounds    x[1155]   20019
 LO bounds    x[1156]   0
 UP bounds    x[1156]   20019
 LO bounds    x[1157]   0
 UP bounds    x[1157]   20019
 LO bounds    x[1158]   0
 UP bounds    x[1158]   20019
 LO bounds    x[1159]   0
 UP bounds    x[1159]   20019
 LO bounds    x[1160]   0
 UP bounds    x[1160]   20019
 LO bounds    x[1161]   0
 UP bounds    x[1161]   20019
 LO bounds    x[1162]   0
 UP bounds    x[1162]   20019
 LO bounds    x[1163]   0
 UP bounds    x[1163]   20019
 LO bounds    x[1164]   0
 UP bounds    x[1164]   20019
 LO bounds    x[1165]   0
 UP bounds    x[1165]   20019
 LO bounds    x[1166]   0
 UP bounds    x[1166]   20019
 LO bounds    x[1167]   0
 UP bounds    x[1167]   20019
 LO bounds    x[1168]   0
 UP bounds    x[1168]   20019
 LO bounds    x[1169]   0
 UP bounds    x[1169]   20019
 LO bounds    x[1170]   0
 UP bounds    x[1170]   20019
 LO bounds    x[1171]   0
 UP bounds    x[1171]   20019
 LO bounds    x[1172]   0
 UP bounds    x[1172]   20019
 LO bounds    x[1173]   0
 UP bounds    x[1173]   20019
 LO bounds    x[1174]   0
 UP bounds    x[1174]   20019
 LO bounds    x[1175]   0
 UP bounds    x[1175]   20019
 LO bounds    x[1176]   0
 UP bounds    x[1176]   20019
 LO bounds    x[1177]   0
 UP bounds    x[1177]   20019
 LO bounds    x[1178]   0
 UP bounds    x[1178]   20019
 LO bounds    x[1179]   0
 UP bounds    x[1179]   20019
 LO bounds    x[1180]   0
 UP bounds    x[1180]   20019
 LO bounds    x[1181]   0
 UP bounds    x[1181]   20019
 LO bounds    x[1182]   0
 UP bounds    x[1182]   20019
 LO bounds    x[1183]   0
 UP bounds    x[1183]   20019
 LO bounds    x[1184]   0
 UP bounds    x[1184]   20019
 LO bounds    x[1185]   0
 UP bounds    x[1185]   20019
 LO bounds    x[1186]   0
 UP bounds    x[1186]   20019
 LO bounds    x[1187]   0
 UP bounds    x[1187]   20019
 LO bounds    x[1188]   0
 UP bounds    x[1188]   20019
 LO bounds    x[1189]   0
 UP bounds    x[1189]   20019
 LO bounds    x[1190]   0
 UP bounds    x[1190]   20019
 LO bounds    x[1191]   0
 UP bounds    x[1191]   20019
 LO bounds    x[1192]   0
 UP bounds    x[1192]   20019
 LO bounds    x[1193]   0
 UP bounds    x[1193]   20019
 LO bounds    x[1194]   0
 UP bounds    x[1194]   20019
 LO bounds    x[1195]   0
 UP bounds    x[1195]   20019
 LO bounds    x[1196]   0
 PL bounds    x[1196]
 LO bounds    x[1197]   0
 PL bounds    x[1197]
 LO bounds    x[1198]   0
 PL bounds    x[1198]
 LO bounds    x[1199]   0
 PL bounds    x[1199]
 LO bounds    x[1200]   0
 PL bounds    x[1200]
 LO bounds    x[1201]   0
 PL bounds    x[1201]
 LO bounds    x[1202]   0
 PL bounds    x[1202]
 LO bounds    x[1203]   0
 PL bounds    x[1203]
 LO bounds    x[1204]   0
 PL bounds    x[1204]
 LO bounds    x[1205]   0
 PL bounds    x[1205]
 LO bounds    x[1206]   0
 PL bounds    x[1206]
 LO bounds    x[1207]   0
 PL bounds    x[1207]
 LO bounds    x[1208]   0
 PL bounds    x[1208]
 LO bounds    x[1209]   0
 PL bounds    x[1209]
 LO bounds    x[1210]   0
 PL bounds    x[1210]
 LO bounds    x[1211]   0
 PL bounds    x[1211]
 LO bounds    x[1212]   0
 PL bounds    x[1212]
 LO bounds    x[1213]   0
 PL bounds    x[1213]
 LO bounds    x[1214]   0
 PL bounds    x[1214]
 LO bounds    x[1215]   0
 PL bounds    x[1215]
 LO bounds    x[1216]   0
 PL bounds    x[1216]
 LO bounds    x[1217]   0
 PL bounds    x[1217]
 LO bounds    x[1218]   0
 PL bounds    x[1218]
 LO bounds    x[1219]   0
 PL bounds    x[1219]
 LO bounds    x[1220]   0
 PL bounds    x[1220]
 LO bounds    x[1221]   0
 PL bounds    x[1221]
 LO bounds    x[1222]   0
 PL bounds    x[1222]
 LO bounds    x[1223]   0
 PL bounds    x[1223]
 LO bounds    x[1224]   0
 PL bounds    x[1224]
 LO bounds    x[1225]   0
 PL bounds    x[1225]
 LO bounds    x[1226]   0
 PL bounds    x[1226]
 LO bounds    x[1227]   0
 PL bounds    x[1227]
 LO bounds    x[1228]   0
 PL bounds    x[1228]
 LO bounds    x[1229]   0
 PL bounds    x[1229]
 LO bounds    x[1230]   0
 PL bounds    x[1230]
 LO bounds    x[1231]   0
 PL bounds    x[1231]
 LO bounds    x[1232]   0
 PL bounds    x[1232]
 LO bounds    x[1233]   0
 PL bounds    x[1233]
 LO bounds    x[1234]   0
 PL bounds    x[1234]
 LO bounds    x[1235]   0
 PL bounds    x[1235]
 LO bounds    x[1236]   0
 PL bounds    x[1236]
 LO bounds    x[1237]   0
 PL bounds    x[1237]
 LO bounds    x[1238]   0
 PL bounds    x[1238]
 LO bounds    x[1239]   0
 PL bounds    x[1239]
 LO bounds    x[1240]   0
 PL bounds    x[1240]
 LO bounds    x[1241]   0
 PL bounds    x[1241]
 LO bounds    x[1242]   0
 PL bounds    x[1242]
 LO bounds    x[1243]   0
 PL bounds    x[1243]
 LO bounds    x[1244]   0
 PL bounds    x[1244]
 LO bounds    x[1245]   0
 PL bounds    x[1245]
 LO bounds    x[1246]   0
 PL bounds    x[1246]
 LO bounds    x[1247]   0
 PL bounds    x[1247]
 LO bounds    x[1248]   0
 PL bounds    x[1248]
 LO bounds    x[1249]   0
 PL bounds    x[1249]
 LO bounds    x[1250]   0
 PL bounds    x[1250]
 LO bounds    x[1251]   0
 PL bounds    x[1251]
 LO bounds    x[1252]   0
 PL bounds    x[1252]
 LO bounds    x[1253]   0
 PL bounds    x[1253]
 LO bounds    x[1254]   0
 PL bounds    x[1254]
 LO bounds    x[1255]   0
 PL bounds    x[1255]
 LO bounds    x[1256]   0
 PL bounds    x[1256]
 LO bounds    x[1257]   0
 PL bounds    x[1257]
 LO bounds    x[1258]   0
 PL bounds    x[1258]
 LO bounds    x[1259]   0
 PL bounds    x[1259]
 LO bounds    x[1260]   0
 PL bounds    x[1260]
 LO bounds    x[1261]   0
 PL bounds    x[1261]
 LO bounds    x[1262]   0
 PL bounds    x[1262]
 LO bounds    x[1263]   0
 PL bounds    x[1263]
 LO bounds    x[1264]   0
 PL bounds    x[1264]
 LO bounds    x[1265]   0
 PL bounds    x[1265]
 LO bounds    x[1266]   0
 PL bounds    x[1266]
 LO bounds    x[1267]   0
 PL bounds    x[1267]
 LO bounds    x[1268]   0
 PL bounds    x[1268]
 LO bounds    x[1269]   0
 PL bounds    x[1269]
 LO bounds    x[1270]   0
 PL bounds    x[1270]
 LO bounds    x[1271]   0
 PL bounds    x[1271]
 LO bounds    x[1272]   0
 PL bounds    x[1272]
 LO bounds    x[1273]   0
 PL bounds    x[1273]
 LO bounds    x[1274]   0
 PL bounds    x[1274]
 LO bounds    x[1275]   0
 PL bounds    x[1275]
 LO bounds    x[1276]   0
 PL bounds    x[1276]
 LO bounds    x[1277]   0
 PL bounds    x[1277]
 LO bounds    x[1278]   0
 PL bounds    x[1278]
 LO bounds    x[1279]   0
 PL bounds    x[1279]
 LO bounds    x[1280]   0
 PL bounds    x[1280]
 LO bounds    x[1281]   0
 PL bounds    x[1281]
 LO bounds    x[1282]   0
 PL bounds    x[1282]
 LO bounds    x[1283]   0
 PL bounds    x[1283]
 LO bounds    x[1284]   0
 PL bounds    x[1284]
 LO bounds    x[1285]   0
 PL bounds    x[1285]
 LO bounds    x[1286]   0
 PL bounds    x[1286]
 LO bounds    x[1287]   0
 PL bounds    x[1287]
 LO bounds    x[1288]   0
 PL bounds    x[1288]
 LO bounds    x[1289]   0
 PL bounds    x[1289]
 LO bounds    x[1290]   0
 PL bounds    x[1290]
 LO bounds    x[1291]   0
 PL bounds    x[1291]
 LO bounds    x[1292]   0
 PL bounds    x[1292]
 LO bounds    x[1293]   0
 PL bounds    x[1293]
 LO bounds    x[1294]   0
 PL bounds    x[1294]
 LO bounds    x[1295]   0
 PL bounds    x[1295]
 LO bounds    x[1296]   0
 PL bounds    x[1296]
 LO bounds    x[1297]   0
 PL bounds    x[1297]
 LO bounds    x[1298]   0
 PL bounds    x[1298]
 LO bounds    x[1299]   0
 PL bounds    x[1299]
 LO bounds    x[1300]   0
 PL bounds    x[1300]
 LO bounds    x[1301]   0
 PL bounds    x[1301]
 LO bounds    x[1302]   0
 PL bounds    x[1302]
 LO bounds    x[1303]   0
 PL bounds    x[1303]
 LO bounds    x[1304]   0
 PL bounds    x[1304]
 LO bounds    x[1305]   0
 PL bounds    x[1305]
 LO bounds    x[1306]   0
 PL bounds    x[1306]
 LO bounds    x[1307]   0
 PL bounds    x[1307]
 LO bounds    x[1308]   0
 PL bounds    x[1308]
 LO bounds    x[1309]   0
 PL bounds    x[1309]
 LO bounds    x[1310]   0
 PL bounds    x[1310]
 LO bounds    x[1311]   0
 PL bounds    x[1311]
 LO bounds    x[1312]   0
 PL bounds    x[1312]
 LO bounds    x[1313]   0
 PL bounds    x[1313]
 LO bounds    x[1314]   0
 PL bounds    x[1314]
 LO bounds    x[1315]   0
 PL bounds    x[1315]
 LO bounds    x[1316]   0
 PL bounds    x[1316]
 LO bounds    x[1317]   0
 PL bounds    x[1317]
 LO bounds    x[1318]   0
 PL bounds    x[1318]
 LO bounds    x[1319]   0
 PL bounds    x[1319]
 LO bounds    x[1320]   0
 PL bounds    x[1320]
 LO bounds    x[1321]   0
 PL bounds    x[1321]
 LO bounds    x[1322]   0
 PL bounds    x[1322]
 LO bounds    x[1323]   0
 PL bounds    x[1323]
 LO bounds    x[1324]   0
 PL bounds    x[1324]
 LO bounds    x[1325]   0
 PL bounds    x[1325]
 LO bounds    x[1326]   0
 PL bounds    x[1326]
 LO bounds    x[1327]   0
 PL bounds    x[1327]
 LO bounds    x[1328]   0
 PL bounds    x[1328]
 LO bounds    x[1329]   0
 PL bounds    x[1329]
 LO bounds    x[1330]   0
 PL bounds    x[1330]
 LO bounds    x[1331]   0
 PL bounds    x[1331]
 LO bounds    x[1332]   0
 PL bounds    x[1332]
 LO bounds    x[1333]   0
 PL bounds    x[1333]
 LO bounds    x[1334]   0
 PL bounds    x[1334]
 LO bounds    x[1335]   0
 PL bounds    x[1335]
 LO bounds    x[1336]   0
 PL bounds    x[1336]
 LO bounds    x[1337]   0
 PL bounds    x[1337]
 LO bounds    x[1338]   0
 PL bounds    x[1338]
 LO bounds    x[1339]   0
 PL bounds    x[1339]
 LO bounds    x[1340]   0
 PL bounds    x[1340]
 LO bounds    x[1341]   0
 PL bounds    x[1341]
 LO bounds    x[1342]   0
 PL bounds    x[1342]
 LO bounds    x[1343]   0
 PL bounds    x[1343]
 LO bounds    x[1344]   0
 PL bounds    x[1344]
 LO bounds    x[1345]   0
 PL bounds    x[1345]
 LO bounds    x[1346]   0
 PL bounds    x[1346]
 LO bounds    x[1347]   0
 PL bounds    x[1347]
 LO bounds    x[1348]   0
 PL bounds    x[1348]
 LO bounds    x[1349]   0
 PL bounds    x[1349]
 LO bounds    x[1350]   0
 PL bounds    x[1350]
 LO bounds    x[1351]   0
 PL bounds    x[1351]
 LO bounds    x[1352]   0
 PL bounds    x[1352]
 LO bounds    x[1353]   0
 PL bounds    x[1353]
 LO bounds    x[1354]   0
 PL bounds    x[1354]
 LO bounds    x[1355]   0
 PL bounds    x[1355]
 LO bounds    x[1356]   0
 PL bounds    x[1356]
 LO bounds    x[1357]   0
 PL bounds    x[1357]
 LO bounds    x[1358]   0
 PL bounds    x[1358]
 LO bounds    x[1359]   0
 PL bounds    x[1359]
 LO bounds    x[1360]   0
 PL bounds    x[1360]
 LO bounds    x[1361]   0
 PL bounds    x[1361]
 LO bounds    x[1362]   0
 PL bounds    x[1362]
 LO bounds    x[1363]   0
 PL bounds    x[1363]
 LO bounds    x[1364]   0
 PL bounds    x[1364]
 LO bounds    x[1365]   0
 PL bounds    x[1365]
 LO bounds    x[1366]   0
 PL bounds    x[1366]
 LO bounds    x[1367]   0
 PL bounds    x[1367]
 LO bounds    x[1368]   0
 PL bounds    x[1368]
 LO bounds    x[1369]   0
 PL bounds    x[1369]
 LO bounds    x[1370]   0
 PL bounds    x[1370]
 LO bounds    x[1371]   0
 PL bounds    x[1371]
 LO bounds    x[1372]   0
 PL bounds    x[1372]
 LO bounds    x[1373]   0
 PL bounds    x[1373]
 LO bounds    x[1374]   0
 PL bounds    x[1374]
 LO bounds    x[1375]   0
 PL bounds    x[1375]
 LO bounds    x[1376]   0
 PL bounds    x[1376]
 LO bounds    x[1377]   0
 PL bounds    x[1377]
 LO bounds    x[1378]   0
 PL bounds    x[1378]
 LO bounds    x[1379]   0
 PL bounds    x[1379]
 LO bounds    x[1380]   0
 PL bounds    x[1380]
 LO bounds    x[1381]   0
 PL bounds    x[1381]
 LO bounds    x[1382]   0
 PL bounds    x[1382]
 LO bounds    x[1383]   0
 PL bounds    x[1383]
 LO bounds    x[1384]   0
 PL bounds    x[1384]
 LO bounds    x[1385]   0
 PL bounds    x[1385]
 LO bounds    x[1386]   0
 PL bounds    x[1386]
 LO bounds    x[1387]   0
 PL bounds    x[1387]
 LO bounds    x[1388]   0
 PL bounds    x[1388]
 LO bounds    x[1389]   0
 PL bounds    x[1389]
 LO bounds    x[1390]   0
 PL bounds    x[1390]
 LO bounds    x[1391]   0
 PL bounds    x[1391]
 LO bounds    x[1392]   0
 PL bounds    x[1392]
 LO bounds    x[1393]   0
 PL bounds    x[1393]
 LO bounds    x[1394]   0
 PL bounds    x[1394]
 LO bounds    x[1395]   0
 PL bounds    x[1395]
 LO bounds    x[1396]   0
 PL bounds    x[1396]
 LO bounds    x[1397]   0
 PL bounds    x[1397]
 LO bounds    x[1398]   0
 PL bounds    x[1398]
 LO bounds    x[1399]   0
 PL bounds    x[1399]
 LO bounds    x[1400]   0
 PL bounds    x[1400]
 LO bounds    x[1401]   0
 PL bounds    x[1401]
 LO bounds    x[1402]   0
 PL bounds    x[1402]
 LO bounds    x[1403]   0
 PL bounds    x[1403]
 LO bounds    x[1404]   0
 PL bounds    x[1404]
 LO bounds    x[1405]   0
 PL bounds    x[1405]
 LO bounds    x[1406]   0
 PL bounds    x[1406]
 LO bounds    x[1407]   0
 PL bounds    x[1407]
 LO bounds    x[1408]   0
 PL bounds    x[1408]
 LO bounds    x[1409]   0
 PL bounds    x[1409]
 LO bounds    x[1410]   0
 PL bounds    x[1410]
 LO bounds    x[1411]   0
 PL bounds    x[1411]
 LO bounds    x[1412]   0
 PL bounds    x[1412]
 LO bounds    x[1413]   0
 PL bounds    x[1413]
 LO bounds    x[1414]   0
 PL bounds    x[1414]
 LO bounds    x[1415]   0
 PL bounds    x[1415]
 LO bounds    x[1416]   0
 PL bounds    x[1416]
 LO bounds    x[1417]   0
 PL bounds    x[1417]
 LO bounds    x[1418]   0
 PL bounds    x[1418]
 LO bounds    x[1419]   0
 PL bounds    x[1419]
 LO bounds    x[1420]   0
 PL bounds    x[1420]
 LO bounds    x[1421]   0
 PL bounds    x[1421]
 LO bounds    x[1422]   0
 PL bounds    x[1422]
 LO bounds    x[1423]   0
 PL bounds    x[1423]
 LO bounds    x[1424]   0
 PL bounds    x[1424]
 LO bounds    x[1425]   0
 PL bounds    x[1425]
 LO bounds    x[1426]   0
 PL bounds    x[1426]
 LO bounds    x[1427]   0
 PL bounds    x[1427]
 LO bounds    x[1428]   0
 PL bounds    x[1428]
 LO bounds    x[1429]   0
 PL bounds    x[1429]
 LO bounds    x[1430]   0
 PL bounds    x[1430]
 LO bounds    x[1431]   0
 PL bounds    x[1431]
 LO bounds    x[1432]   0
 PL bounds    x[1432]
 LO bounds    x[1433]   0
 PL bounds    x[1433]
 LO bounds    x[1434]   0
 PL bounds    x[1434]
 LO bounds    x[1435]   0
 PL bounds    x[1435]
 LO bounds    x[1436]   0
 PL bounds    x[1436]
 LO bounds    x[1437]   0
 PL bounds    x[1437]
 LO bounds    x[1438]   0
 PL bounds    x[1438]
 LO bounds    x[1439]   0
 PL bounds    x[1439]
 LO bounds    x[1440]   0
 PL bounds    x[1440]
 LO bounds    x[1441]   0
 PL bounds    x[1441]
 LO bounds    x[1442]   0
 PL bounds    x[1442]
 LO bounds    x[1443]   0
 PL bounds    x[1443]
 LO bounds    x[1444]   0
 PL bounds    x[1444]
 LO bounds    x[1445]   0
 PL bounds    x[1445]
 LO bounds    x[1446]   0
 PL bounds    x[1446]
 LO bounds    x[1447]   0
 PL bounds    x[1447]
 LO bounds    x[1448]   0
 PL bounds    x[1448]
 LO bounds    x[1449]   0
 PL bounds    x[1449]
 LO bounds    x[1450]   0
 PL bounds    x[1450]
 LO bounds    x[1451]   0
 PL bounds    x[1451]
 LO bounds    x[1452]   0
 PL bounds    x[1452]
 LO bounds    x[1453]   0
 PL bounds    x[1453]
 LO bounds    x[1454]   0
 PL bounds    x[1454]
 LO bounds    x[1455]   0
 PL bounds    x[1455]
 LO bounds    x[1456]   0
 PL bounds    x[1456]
 LO bounds    x[1457]   0
 PL bounds    x[1457]
 LO bounds    x[1458]   0
 PL bounds    x[1458]
 LO bounds    x[1459]   0
 PL bounds    x[1459]
 LO bounds    x[1460]   0
 PL bounds    x[1460]
 LO bounds    x[1461]   0
 PL bounds    x[1461]
 LO bounds    x[1462]   0
 PL bounds    x[1462]
 LO bounds    x[1463]   0
 PL bounds    x[1463]
 LO bounds    x[1464]   0
 PL bounds    x[1464]
 LO bounds    x[1465]   0
 PL bounds    x[1465]
 LO bounds    x[1466]   0
 PL bounds    x[1466]
 LO bounds    x[1467]   0
 PL bounds    x[1467]
 LO bounds    x[1468]   0
 PL bounds    x[1468]
 LO bounds    x[1469]   0
 PL bounds    x[1469]
 LO bounds    x[1470]   0
 PL bounds    x[1470]
 LO bounds    x[1471]   0
 PL bounds    x[1471]
 LO bounds    x[1472]   0
 PL bounds    x[1472]
 LO bounds    x[1473]   0
 PL bounds    x[1473]
 LO bounds    x[1474]   0
 PL bounds    x[1474]
 LO bounds    x[1475]   0
 PL bounds    x[1475]
 LO bounds    x[1476]   0
 PL bounds    x[1476]
 LO bounds    x[1477]   0
 PL bounds    x[1477]
 LO bounds    x[1478]   0
 PL bounds    x[1478]
 LO bounds    x[1479]   0
 PL bounds    x[1479]
 LO bounds    x[1480]   0
 PL bounds    x[1480]
 LO bounds    x[1481]   0
 PL bounds    x[1481]
 LO bounds    x[1482]   0
 PL bounds    x[1482]
 LO bounds    x[1483]   0
 PL bounds    x[1483]
 LO bounds    x[1484]   0
 PL bounds    x[1484]
 LO bounds    x[1485]   0
 PL bounds    x[1485]
 LO bounds    x[1486]   0
 PL bounds    x[1486]
 LO bounds    x[1487]   0
 PL bounds    x[1487]
 LO bounds    x[1488]   0
 PL bounds    x[1488]
 LO bounds    x[1489]   0
 PL bounds    x[1489]
 LO bounds    x[1490]   0
 PL bounds    x[1490]
 LO bounds    x[1491]   0
 PL bounds    x[1491]
 LO bounds    x[1492]   0
 PL bounds    x[1492]
 LO bounds    x[1493]   0
 PL bounds    x[1493]
 LO bounds    x[1494]   0
 PL bounds    x[1494]
 LO bounds    x[1495]   0
 PL bounds    x[1495]
 LO bounds    x[1496]   0
 PL bounds    x[1496]
 LO bounds    x[1497]   0
 PL bounds    x[1497]
 LO bounds    x[1498]   0
 PL bounds    x[1498]
 LO bounds    x[1499]   0
 PL bounds    x[1499]
 LO bounds    x[1500]   0
 PL bounds    x[1500]
 LO bounds    x[1501]   0
 PL bounds    x[1501]
 LO bounds    x[1502]   0
 PL bounds    x[1502]
 LO bounds    x[1503]   0
 PL bounds    x[1503]
 LO bounds    x[1504]   0
 PL bounds    x[1504]
 LO bounds    x[1505]   0
 PL bounds    x[1505]
 LO bounds    x[1506]   0
 PL bounds    x[1506]
 LO bounds    x[1507]   0
 PL bounds    x[1507]
 LO bounds    x[1508]   0
 PL bounds    x[1508]
 LO bounds    x[1509]   0
 PL bounds    x[1509]
 LO bounds    x[1510]   0
 PL bounds    x[1510]
 LO bounds    x[1511]   0
 PL bounds    x[1511]
 LO bounds    x[1512]   0
 PL bounds    x[1512]
 LO bounds    x[1513]   0
 PL bounds    x[1513]
 LO bounds    x[1514]   0
 PL bounds    x[1514]
 LO bounds    x[1515]   0
 PL bounds    x[1515]
 LO bounds    x[1516]   0
 PL bounds    x[1516]
 LO bounds    x[1517]   0
 PL bounds    x[1517]
 LO bounds    x[1518]   0
 PL bounds    x[1518]
 LO bounds    x[1519]   0
 PL bounds    x[1519]
 LO bounds    x[1520]   0
 PL bounds    x[1520]
 LO bounds    x[1521]   0
 PL bounds    x[1521]
 LO bounds    x[1522]   0
 PL bounds    x[1522]
 LO bounds    x[1523]   0
 PL bounds    x[1523]
 LO bounds    x[1524]   0
 PL bounds    x[1524]
 LO bounds    x[1525]   0
 PL bounds    x[1525]
 LO bounds    x[1526]   0
 PL bounds    x[1526]
 LO bounds    x[1527]   0
 PL bounds    x[1527]
 LO bounds    x[1528]   0
 PL bounds    x[1528]
 LO bounds    x[1529]   0
 PL bounds    x[1529]
 LO bounds    x[1530]   0
 PL bounds    x[1530]
 LO bounds    x[1531]   0
 PL bounds    x[1531]
 LO bounds    x[1532]   0
 PL bounds    x[1532]
 LO bounds    x[1533]   0
 PL bounds    x[1533]
 LO bounds    x[1534]   0
 PL bounds    x[1534]
 LO bounds    x[1535]   0
 PL bounds    x[1535]
 LO bounds    x[1536]   0
 PL bounds    x[1536]
 LO bounds    x[1537]   0
 PL bounds    x[1537]
 LO bounds    x[1538]   0
 PL bounds    x[1538]
 LO bounds    x[1539]   0
 PL bounds    x[1539]
 LO bounds    x[1540]   0
 PL bounds    x[1540]
 LO bounds    x[1541]   0
 PL bounds    x[1541]
 LO bounds    x[1542]   0
 PL bounds    x[1542]
 LO bounds    x[1543]   0
 PL bounds    x[1543]
 LO bounds    x[1544]   0
 PL bounds    x[1544]
 LO bounds    x[1545]   0
 PL bounds    x[1545]
 LO bounds    x[1546]   0
 PL bounds    x[1546]
 LO bounds    x[1547]   0
 PL bounds    x[1547]
 LO bounds    x[1548]   0
 PL bounds    x[1548]
 LO bounds    x[1549]   0
 PL bounds    x[1549]
 LO bounds    x[1550]   0
 PL bounds    x[1550]
 LO bounds    x[1551]   0
 PL bounds    x[1551]
 LO bounds    x[1552]   0
 PL bounds    x[1552]
 LO bounds    x[1553]   0
 PL bounds    x[1553]
 LO bounds    x[1554]   0
 PL bounds    x[1554]
 LO bounds    x[1555]   0
 PL bounds    x[1555]
 LO bounds    x[1556]   0
 PL bounds    x[1556]
 LO bounds    x[1557]   0
 PL bounds    x[1557]
 LO bounds    x[1558]   0
 PL bounds    x[1558]
 LO bounds    x[1559]   0
 PL bounds    x[1559]
 LO bounds    x[1560]   0
 PL bounds    x[1560]
 LO bounds    x[1561]   0
 PL bounds    x[1561]
 LO bounds    x[1562]   0
 PL bounds    x[1562]
 LO bounds    x[1563]   0
 PL bounds    x[1563]
 LO bounds    x[1564]   0
 PL bounds    x[1564]
 LO bounds    x[1565]   0
 PL bounds    x[1565]
 LO bounds    x[1566]   0
 PL bounds    x[1566]
 LO bounds    x[1567]   0
 PL bounds    x[1567]
 LO bounds    x[1568]   0
 PL bounds    x[1568]
 LO bounds    x[1569]   0
 PL bounds    x[1569]
 LO bounds    x[1570]   0
 PL bounds    x[1570]
 LO bounds    x[1571]   0
 PL bounds    x[1571]
 LO bounds    x[1572]   0
 PL bounds    x[1572]
 LO bounds    x[1573]   0
 PL bounds    x[1573]
 LO bounds    x[1574]   0
 PL bounds    x[1574]
 LO bounds    x[1575]   0
 PL bounds    x[1575]
 LO bounds    x[1576]   0
 PL bounds    x[1576]
 LO bounds    x[1577]   0
 PL bounds    x[1577]
 LO bounds    x[1578]   0
 PL bounds    x[1578]
 LO bounds    x[1579]   0
 PL bounds    x[1579]
 LO bounds    x[1580]   0
 PL bounds    x[1580]
 LO bounds    x[1581]   0
 PL bounds    x[1581]
 LO bounds    x[1582]   0
 PL bounds    x[1582]
 LO bounds    x[1583]   0
 PL bounds    x[1583]
 LO bounds    x[1584]   0
 PL bounds    x[1584]
 LO bounds    x[1585]   0
 PL bounds    x[1585]
 LO bounds    x[1586]   0
 PL bounds    x[1586]
 LO bounds    x[1587]   0
 PL bounds    x[1587]
 LO bounds    x[1588]   0
 PL bounds    x[1588]
 LO bounds    x[1589]   0
 PL bounds    x[1589]
 LO bounds    x[1590]   0
 PL bounds    x[1590]
 LO bounds    x[1591]   0
 PL bounds    x[1591]
 LO bounds    x[1592]   0
 PL bounds    x[1592]
 LO bounds    x[1593]   0
 PL bounds    x[1593]
 LO bounds    x[1594]   0
 PL bounds    x[1594]
 LO bounds    x[1595]   0
 PL bounds    x[1595]
 LO bounds    x[1596]   0
 PL bounds    x[1596]
 LO bounds    x[1597]   0
 PL bounds    x[1597]
 LO bounds    x[1598]   0
 PL bounds    x[1598]
 LO bounds    x[1599]   0
 PL bounds    x[1599]
 LO bounds    x[1600]   0
 PL bounds    x[1600]
 LO bounds    x[1601]   0
 PL bounds    x[1601]
 LO bounds    x[1602]   0
 PL bounds    x[1602]
 LO bounds    x[1603]   0
 PL bounds    x[1603]
 LO bounds    x[1604]   0
 PL bounds    x[1604]
 LO bounds    x[1605]   0
 PL bounds    x[1605]
 LO bounds    x[1606]   0
 PL bounds    x[1606]
 LO bounds    x[1607]   0
 PL bounds    x[1607]
 LO bounds    x[1608]   0
 PL bounds    x[1608]
 LO bounds    x[1609]   0
 PL bounds    x[1609]
 LO bounds    x[1610]   0
 PL bounds    x[1610]
 LO bounds    x[1611]   0
 PL bounds    x[1611]
 LO bounds    x[1612]   0
 PL bounds    x[1612]
 LO bounds    x[1613]   0
 PL bounds    x[1613]
 LO bounds    x[1614]   0
 PL bounds    x[1614]
 LO bounds    x[1615]   0
 PL bounds    x[1615]
 LO bounds    x[1616]   0
 PL bounds    x[1616]
 LO bounds    x[1617]   0
 PL bounds    x[1617]
 LO bounds    x[1618]   0
 PL bounds    x[1618]
 LO bounds    x[1619]   0
 PL bounds    x[1619]
 LO bounds    x[1620]   0
 PL bounds    x[1620]
 LO bounds    x[1621]   0
 PL bounds    x[1621]
 LO bounds    x[1622]   0
 PL bounds    x[1622]
 LO bounds    x[1623]   0
 PL bounds    x[1623]
 LO bounds    x[1624]   0
 PL bounds    x[1624]
 LO bounds    x[1625]   0
 PL bounds    x[1625]
 LO bounds    x[1626]   0
 PL bounds    x[1626]
 LO bounds    x[1627]   0
 PL bounds    x[1627]
 LO bounds    x[1628]   0
 PL bounds    x[1628]
 LO bounds    x[1629]   0
 PL bounds    x[1629]
 LO bounds    x[1630]   0
 PL bounds    x[1630]
 LO bounds    x[1631]   0
 PL bounds    x[1631]
 LO bounds    x[1632]   0
 PL bounds    x[1632]
 LO bounds    x[1633]   0
 PL bounds    x[1633]
 LO bounds    x[1634]   0
 PL bounds    x[1634]
 LO bounds    x[1635]   0
 PL bounds    x[1635]
 LO bounds    x[1636]   0
 PL bounds    x[1636]
 LO bounds    x[1637]   0
 PL bounds    x[1637]
 LO bounds    x[1638]   0
 PL bounds    x[1638]
 LO bounds    x[1639]   0
 PL bounds    x[1639]
 LO bounds    x[1640]   0
 PL bounds    x[1640]
 LO bounds    x[1641]   0
 PL bounds    x[1641]
 LO bounds    x[1642]   0
 PL bounds    x[1642]
 LO bounds    x[1643]   0
 PL bounds    x[1643]
 LO bounds    x[1644]   0
 PL bounds    x[1644]
 LO bounds    x[1645]   0
 PL bounds    x[1645]
 LO bounds    x[1646]   0
 PL bounds    x[1646]
 LO bounds    x[1647]   0
 PL bounds    x[1647]
 LO bounds    x[1648]   0
 PL bounds    x[1648]
 LO bounds    x[1649]   0
 PL bounds    x[1649]
 LO bounds    x[1650]   0
 PL bounds    x[1650]
 LO bounds    x[1651]   0
 PL bounds    x[1651]
 LO bounds    x[1652]   0
 PL bounds    x[1652]
 LO bounds    x[1653]   0
 PL bounds    x[1653]
 LO bounds    x[1654]   0
 PL bounds    x[1654]
 LO bounds    x[1655]   0
 PL bounds    x[1655]
 LO bounds    x[1656]   0
 PL bounds    x[1656]
 LO bounds    x[1657]   0
 PL bounds    x[1657]
 LO bounds    x[1658]   0
 PL bounds    x[1658]
 LO bounds    x[1659]   0
 PL bounds    x[1659]
 LO bounds    x[1660]   0
 PL bounds    x[1660]
 LO bounds    x[1661]   0
 PL bounds    x[1661]
 LO bounds    x[1662]   0
 PL bounds    x[1662]
 LO bounds    x[1663]   0
 PL bounds    x[1663]
 LO bounds    x[1664]   0
 PL bounds    x[1664]
 LO bounds    x[1665]   0
 PL bounds    x[1665]
 LO bounds    x[1666]   0
 PL bounds    x[1666]
 LO bounds    x[1667]   0
 PL bounds    x[1667]
 LO bounds    x[1668]   0
 PL bounds    x[1668]
 LO bounds    x[1669]   0
 PL bounds    x[1669]
 LO bounds    x[1670]   0
 PL bounds    x[1670]
 LO bounds    x[1671]   0
 PL bounds    x[1671]
 LO bounds    x[1672]   0
 PL bounds    x[1672]
 LO bounds    x[1673]   0
 PL bounds    x[1673]
 LO bounds    x[1674]   0
 PL bounds    x[1674]
 LO bounds    x[1675]   0
 PL bounds    x[1675]
 LO bounds    x[1676]   0
 PL bounds    x[1676]
 LO bounds    x[1677]   0
 PL bounds    x[1677]
 LO bounds    x[1678]   0
 PL bounds    x[1678]
 LO bounds    x[1679]   0
 PL bounds    x[1679]
 LO bounds    x[1680]   0
 PL bounds    x[1680]
 LO bounds    x[1681]   0
 PL bounds    x[1681]
 LO bounds    x[1682]   0
 PL bounds    x[1682]
 LO bounds    x[1683]   0
 PL bounds    x[1683]
 LO bounds    x[1684]   0
 PL bounds    x[1684]
 LO bounds    x[1685]   0
 PL bounds    x[1685]
 LO bounds    x[1686]   0
 PL bounds    x[1686]
 LO bounds    x[1687]   0
 PL bounds    x[1687]
 LO bounds    x[1688]   0
 PL bounds    x[1688]
 LO bounds    x[1689]   0
 PL bounds    x[1689]
 LO bounds    x[1690]   0
 PL bounds    x[1690]
 LO bounds    x[1691]   0
 PL bounds    x[1691]
 LO bounds    x[1692]   0
 PL bounds    x[1692]
 LO bounds    x[1693]   0
 PL bounds    x[1693]
 LO bounds    x[1694]   0
 PL bounds    x[1694]
 LO bounds    x[1695]   0
 PL bounds    x[1695]
 LO bounds    x[1696]   0
 PL bounds    x[1696]
 LO bounds    x[1697]   0
 PL bounds    x[1697]
 LO bounds    x[1698]   0
 PL bounds    x[1698]
 LO bounds    x[1699]   0
 PL bounds    x[1699]
 LO bounds    x[1700]   0
 PL bounds    x[1700]
 LO bounds    x[1701]   0
 PL bounds    x[1701]
 LO bounds    x[1702]   0
 PL bounds    x[1702]
 LO bounds    x[1703]   0
 PL bounds    x[1703]
 LO bounds    x[1704]   0
 PL bounds    x[1704]
 LO bounds    x[1705]   0
 PL bounds    x[1705]
 LO bounds    x[1706]   0
 PL bounds    x[1706]
 LO bounds    x[1707]   0
 PL bounds    x[1707]
 LO bounds    x[1708]   0
 PL bounds    x[1708]
 LO bounds    x[1709]   0
 PL bounds    x[1709]
 LO bounds    x[1710]   0
 PL bounds    x[1710]
 LO bounds    x[1711]   0
 PL bounds    x[1711]
 LO bounds    x[1712]   0
 PL bounds    x[1712]
 LO bounds    x[1713]   0
 PL bounds    x[1713]
 LO bounds    x[1714]   0
 PL bounds    x[1714]
 LO bounds    x[1715]   0
 PL bounds    x[1715]
 LO bounds    x[1716]   0
 PL bounds    x[1716]
 LO bounds    x[1717]   0
 PL bounds    x[1717]
 LO bounds    x[1718]   0
 PL bounds    x[1718]
 LO bounds    x[1719]   0
 PL bounds    x[1719]
 LO bounds    x[1720]   0
 PL bounds    x[1720]
 LO bounds    x[1721]   0
 PL bounds    x[1721]
 LO bounds    x[1722]   0
 PL bounds    x[1722]
 LO bounds    x[1723]   0
 PL bounds    x[1723]
 LO bounds    x[1724]   0
 PL bounds    x[1724]
 LO bounds    x[1725]   0
 PL bounds    x[1725]
 LO bounds    x[1726]   0
 PL bounds    x[1726]
 LO bounds    x[1727]   0
 PL bounds    x[1727]
 LO bounds    x[1728]   0
 PL bounds    x[1728]
 LO bounds    x[1729]   0
 PL bounds    x[1729]
 LO bounds    x[1730]   0
 PL bounds    x[1730]
 LO bounds    x[1731]   0
 PL bounds    x[1731]
 LO bounds    x[1732]   0
 PL bounds    x[1732]
 LO bounds    x[1733]   0
 PL bounds    x[1733]
 LO bounds    x[1734]   0
 PL bounds    x[1734]
 LO bounds    x[1735]   0
 PL bounds    x[1735]
 LO bounds    x[1736]   0
 PL bounds    x[1736]
 LO bounds    x[1737]   0
 PL bounds    x[1737]
 LO bounds    x[1738]   0
 PL bounds    x[1738]
 LO bounds    x[1739]   0
 PL bounds    x[1739]
 LO bounds    x[1740]   0
 PL bounds    x[1740]
 LO bounds    x[1741]   0
 PL bounds    x[1741]
 LO bounds    x[1742]   0
 PL bounds    x[1742]
 LO bounds    x[1743]   0
 PL bounds    x[1743]
 LO bounds    x[1744]   0
 PL bounds    x[1744]
 LO bounds    x[1745]   0
 PL bounds    x[1745]
 LO bounds    x[1746]   0
 PL bounds    x[1746]
 LO bounds    x[1747]   0
 PL bounds    x[1747]
 LO bounds    x[1748]   0
 PL bounds    x[1748]
 LO bounds    x[1749]   0
 PL bounds    x[1749]
 LO bounds    x[1750]   0
 PL bounds    x[1750]
 LO bounds    x[1751]   0
 PL bounds    x[1751]
 LO bounds    x[1752]   0
 PL bounds    x[1752]
 LO bounds    x[1753]   0
 PL bounds    x[1753]
 LO bounds    x[1754]   0
 PL bounds    x[1754]
 LO bounds    x[1755]   0
 PL bounds    x[1755]
 LO bounds    x[1756]   0
 PL bounds    x[1756]
 LO bounds    x[1757]   0
 PL bounds    x[1757]
 LO bounds    x[1758]   0
 PL bounds    x[1758]
 LO bounds    x[1759]   0
 PL bounds    x[1759]
 LO bounds    x[1760]   0
 PL bounds    x[1760]
 LO bounds    x[1761]   0
 PL bounds    x[1761]
 LO bounds    x[1762]   0
 PL bounds    x[1762]
 LO bounds    x[1763]   0
 PL bounds    x[1763]
 LO bounds    x[1764]   0
 PL bounds    x[1764]
 LO bounds    x[1765]   0
 PL bounds    x[1765]
 LO bounds    x[1766]   0
 PL bounds    x[1766]
 LO bounds    x[1767]   0
 PL bounds    x[1767]
 LO bounds    x[1768]   0
 PL bounds    x[1768]
 LO bounds    x[1769]   0
 PL bounds    x[1769]
 LO bounds    x[1770]   0
 PL bounds    x[1770]
 LO bounds    x[1771]   0
 PL bounds    x[1771]
 LO bounds    x[1772]   0
 PL bounds    x[1772]
 LO bounds    x[1773]   0
 PL bounds    x[1773]
 LO bounds    x[1774]   0
 PL bounds    x[1774]
 LO bounds    x[1775]   0
 PL bounds    x[1775]
 LO bounds    x[1776]   0
 PL bounds    x[1776]
 LO bounds    x[1777]   0
 PL bounds    x[1777]
 LO bounds    x[1778]   0
 PL bounds    x[1778]
 LO bounds    x[1779]   0
 PL bounds    x[1779]
 LO bounds    x[1780]   0
 PL bounds    x[1780]
 LO bounds    x[1781]   0
 PL bounds    x[1781]
 LO bounds    x[1782]   0
 PL bounds    x[1782]
 LO bounds    x[1783]   0
 PL bounds    x[1783]
 LO bounds    x[1784]   0
 PL bounds    x[1784]
 LO bounds    x[1785]   0
 PL bounds    x[1785]
 LO bounds    x[1786]   0
 PL bounds    x[1786]
 LO bounds    x[1787]   0
 PL bounds    x[1787]
 LO bounds    x[1788]   0
 PL bounds    x[1788]
 LO bounds    x[1789]   0
 PL bounds    x[1789]
 LO bounds    x[1790]   0
 PL bounds    x[1790]
 BV bounds    x[1791]
 BV bounds    x[1792]
 BV bounds    x[1793]
 BV bounds    x[1794]
 BV bounds    x[1795]
 BV bounds    x[1796]
 BV bounds    x[1797]
 BV bounds    x[1798]
 BV bounds    x[1799]
 BV bounds    x[1800]
 BV bounds    x[1801]
 BV bounds    x[1802]
 BV bounds    x[1803]
 BV bounds    x[1804]
 BV bounds    x[1805]
 BV bounds    x[1806]
 BV bounds    x[1807]
 BV bounds    x[1808]
 BV bounds    x[1809]
 BV bounds    x[1810]
 BV bounds    x[1811]
 BV bounds    x[1812]
 BV bounds    x[1813]
 BV bounds    x[1814]
 BV bounds    x[1815]
 BV bounds    x[1816]
 BV bounds    x[1817]
 BV bounds    x[1818]
 BV bounds    x[1819]
 BV bounds    x[1820]
 BV bounds    x[1821]
 BV bounds    x[1822]
 BV bounds    x[1823]
 BV bounds    x[1824]
 BV bounds    x[1825]
 BV bounds    x[1826]
 BV bounds    x[1827]
 BV bounds    x[1828]
 BV bounds    x[1829]
 BV bounds    x[1830]
 BV bounds    x[1831]
 BV bounds    x[1832]
 BV bounds    x[1833]
 BV bounds    x[1834]
 BV bounds    x[1835]
 BV bounds    x[1836]
 BV bounds    x[1837]
 BV bounds    x[1838]
 BV bounds    x[1839]
 BV bounds    x[1840]
 BV bounds    x[1841]
 BV bounds    x[1842]
 BV bounds    x[1843]
 BV bounds    x[1844]
 BV bounds    x[1845]
 BV bounds    x[1846]
 BV bounds    x[1847]
 BV bounds    x[1848]
 BV bounds    x[1849]
 BV bounds    x[1850]
 BV bounds    x[1851]
 BV bounds    x[1852]
 BV bounds    x[1853]
 BV bounds    x[1854]
 BV bounds    x[1855]
 BV bounds    x[1856]
 BV bounds    x[1857]
 BV bounds    x[1858]
 BV bounds    x[1859]
 BV bounds    x[1860]
 BV bounds    x[1861]
 BV bounds    x[1862]
 BV bounds    x[1863]
 BV bounds    x[1864]
 BV bounds    x[1865]
 BV bounds    x[1866]
 BV bounds    x[1867]
 BV bounds    x[1868]
 BV bounds    x[1869]
 BV bounds    x[1870]
 BV bounds    x[1871]
 BV bounds    x[1872]
 BV bounds    x[1873]
 BV bounds    x[1874]
 BV bounds    x[1875]
 BV bounds    x[1876]
 BV bounds    x[1877]
 BV bounds    x[1878]
 BV bounds    x[1879]
 BV bounds    x[1880]
 BV bounds    x[1881]
 BV bounds    x[1882]
 BV bounds    x[1883]
 BV bounds    x[1884]
 BV bounds    x[1885]
 BV bounds    x[1886]
 BV bounds    x[1887]
 BV bounds    x[1888]
 BV bounds    x[1889]
 BV bounds    x[1890]
 BV bounds    x[1891]
 BV bounds    x[1892]
 BV bounds    x[1893]
 BV bounds    x[1894]
 BV bounds    x[1895]
 BV bounds    x[1896]
 BV bounds    x[1897]
 BV bounds    x[1898]
 BV bounds    x[1899]
 BV bounds    x[1900]
 BV bounds    x[1901]
 BV bounds    x[1902]
 BV bounds    x[1903]
 BV bounds    x[1904]
 BV bounds    x[1905]
 BV bounds    x[1906]
 BV bounds    x[1907]
 BV bounds    x[1908]
 BV bounds    x[1909]
 BV bounds    x[1910]
 BV bounds    x[1911]
 BV bounds    x[1912]
 BV bounds    x[1913]
 BV bounds    x[1914]
 BV bounds    x[1915]
 BV bounds    x[1916]
 BV bounds    x[1917]
 BV bounds    x[1918]
 BV bounds    x[1919]
 BV bounds    x[1920]
 BV bounds    x[1921]
 BV bounds    x[1922]
 BV bounds    x[1923]
 BV bounds    x[1924]
 BV bounds    x[1925]
 BV bounds    x[1926]
 BV bounds    x[1927]
 BV bounds    x[1928]
 BV bounds    x[1929]
 BV bounds    x[1930]
 BV bounds    x[1931]
 BV bounds    x[1932]
 BV bounds    x[1933]
 BV bounds    x[1934]
 BV bounds    x[1935]
 BV bounds    x[1936]
 BV bounds    x[1937]
 BV bounds    x[1938]
 BV bounds    x[1939]
 BV bounds    x[1940]
 BV bounds    x[1941]
 BV bounds    x[1942]
 BV bounds    x[1943]
 BV bounds    x[1944]
 BV bounds    x[1945]
 BV bounds    x[1946]
 BV bounds    x[1947]
 BV bounds    x[1948]
 BV bounds    x[1949]
 BV bounds    x[1950]
 BV bounds    x[1951]
 BV bounds    x[1952]
 BV bounds    x[1953]
 BV bounds    x[1954]
 BV bounds    x[1955]
 BV bounds    x[1956]
 BV bounds    x[1957]
 BV bounds    x[1958]
 BV bounds    x[1959]
 BV bounds    x[1960]
 BV bounds    x[1961]
 BV bounds    x[1962]
 BV bounds    x[1963]
 BV bounds    x[1964]
 BV bounds    x[1965]
 BV bounds    x[1966]
 BV bounds    x[1967]
 BV bounds    x[1968]
 BV bounds    x[1969]
 BV bounds    x[1970]
 BV bounds    x[1971]
 BV bounds    x[1972]
 BV bounds    x[1973]
 BV bounds    x[1974]
 BV bounds    x[1975]
 BV bounds    x[1976]
 BV bounds    x[1977]
 BV bounds    x[1978]
 BV bounds    x[1979]
 BV bounds    x[1980]
 BV bounds    x[1981]
 BV bounds    x[1982]
 BV bounds    x[1983]
 BV bounds    x[1984]
 BV bounds    x[1985]
 BV bounds    x[1986]
 BV bounds    x[1987]
 BV bounds    x[1988]
 BV bounds    x[1989]
 BV bounds    x[1990]
 BV bounds    x[1991]
 BV bounds    x[1992]
 BV bounds    x[1993]
 BV bounds    x[1994]
 BV bounds    x[1995]
 BV bounds    x[1996]
 BV bounds    x[1997]
 BV bounds    x[1998]
 BV bounds    x[1999]
 BV bounds    x[2000]
 BV bounds    x[2001]
 BV bounds    x[2002]
 BV bounds    x[2003]
 BV bounds    x[2004]
 BV bounds    x[2005]
 BV bounds    x[2006]
 BV bounds    x[2007]
 BV bounds    x[2008]
 BV bounds    x[2009]
 BV bounds    x[2010]
 BV bounds    x[2011]
 BV bounds    x[2012]
 BV bounds    x[2013]
 BV bounds    x[2014]
 BV bounds    x[2015]
 BV bounds    x[2016]
 BV bounds    x[2017]
 BV bounds    x[2018]
 BV bounds    x[2019]
 BV bounds    x[2020]
 BV bounds    x[2021]
 BV bounds    x[2022]
 BV bounds    x[2023]
 BV bounds    x[2024]
 BV bounds    x[2025]
 BV bounds    x[2026]
 BV bounds    x[2027]
 BV bounds    x[2028]
 BV bounds    x[2029]
 BV bounds    x[2030]
 BV bounds    x[2031]
 BV bounds    x[2032]
 BV bounds    x[2033]
 BV bounds    x[2034]
 BV bounds    x[2035]
 BV bounds    x[2036]
 BV bounds    x[2037]
 BV bounds    x[2038]
 BV bounds    x[2039]
 BV bounds    x[2040]
 BV bounds    x[2041]
 BV bounds    x[2042]
 BV bounds    x[2043]
 BV bounds    x[2044]
 BV bounds    x[2045]
 BV bounds    x[2046]
 BV bounds    x[2047]
 BV bounds    x[2048]
 BV bounds    x[2049]
 BV bounds    x[2050]
 BV bounds    x[2051]
 BV bounds    x[2052]
 BV bounds    x[2053]
 BV bounds    x[2054]
 BV bounds    x[2055]
 BV bounds    x[2056]
 BV bounds    x[2057]
 BV bounds    x[2058]
 BV bounds    x[2059]
 BV bounds    x[2060]
 BV bounds    x[2061]
 BV bounds    x[2062]
 BV bounds    x[2063]
 BV bounds    x[2064]
 BV bounds    x[2065]
 BV bounds    x[2066]
 BV bounds    x[2067]
 BV bounds    x[2068]
 BV bounds    x[2069]
 BV bounds    x[2070]
 BV bounds    x[2071]
 BV bounds    x[2072]
 BV bounds    x[2073]
 BV bounds    x[2074]
 BV bounds    x[2075]
 BV bounds    x[2076]
 BV bounds    x[2077]
 BV bounds    x[2078]
 BV bounds    x[2079]
 BV bounds    x[2080]
 BV bounds    x[2081]
 BV bounds    x[2082]
 BV bounds    x[2083]
 BV bounds    x[2084]
 BV bounds    x[2085]
 BV bounds    x[2086]
 BV bounds    x[2087]
 BV bounds    x[2088]
 BV bounds    x[2089]
 BV bounds    x[2090]
 BV bounds    x[2091]
 BV bounds    x[2092]
 BV bounds    x[2093]
 BV bounds    x[2094]
 BV bounds    x[2095]
 BV bounds    x[2096]
 BV bounds    x[2097]
 BV bounds    x[2098]
 BV bounds    x[2099]
 BV bounds    x[2100]
 BV bounds    x[2101]
 BV bounds    x[2102]
 BV bounds    x[2103]
 BV bounds    x[2104]
 BV bounds    x[2105]
 BV bounds    x[2106]
 BV bounds    x[2107]
 BV bounds    x[2108]
 BV bounds    x[2109]
 BV bounds    x[2110]
 BV bounds    x[2111]
 BV bounds    x[2112]
 BV bounds    x[2113]
 BV bounds    x[2114]
 BV bounds    x[2115]
 BV bounds    x[2116]
 BV bounds    x[2117]
 BV bounds    x[2118]
 BV bounds    x[2119]
 BV bounds    x[2120]
 BV bounds    x[2121]
 BV bounds    x[2122]
 BV bounds    x[2123]
 BV bounds    x[2124]
 BV bounds    x[2125]
 BV bounds    x[2126]
 BV bounds    x[2127]
 BV bounds    x[2128]
 BV bounds    x[2129]
 BV bounds    x[2130]
 BV bounds    x[2131]
 BV bounds    x[2132]
 BV bounds    x[2133]
 BV bounds    x[2134]
 BV bounds    x[2135]
 BV bounds    x[2136]
 BV bounds    x[2137]
 BV bounds    x[2138]
 BV bounds    x[2139]
 BV bounds    x[2140]
 BV bounds    x[2141]
 BV bounds    x[2142]
 BV bounds    x[2143]
 BV bounds    x[2144]
 BV bounds    x[2145]
 BV bounds    x[2146]
 BV bounds    x[2147]
 BV bounds    x[2148]
 BV bounds    x[2149]
 BV bounds    x[2150]
 BV bounds    x[2151]
 BV bounds    x[2152]
 BV bounds    x[2153]
 BV bounds    x[2154]
 BV bounds    x[2155]
 BV bounds    x[2156]
 BV bounds    x[2157]
 BV bounds    x[2158]
 BV bounds    x[2159]
 BV bounds    x[2160]
 BV bounds    x[2161]
 BV bounds    x[2162]
 BV bounds    x[2163]
 BV bounds    x[2164]
 BV bounds    x[2165]
 BV bounds    x[2166]
 BV bounds    x[2167]
 BV bounds    x[2168]
 BV bounds    x[2169]
 BV bounds    x[2170]
 BV bounds    x[2171]
 BV bounds    x[2172]
 BV bounds    x[2173]
 BV bounds    x[2174]
 BV bounds    x[2175]
 BV bounds    x[2176]
 BV bounds    x[2177]
 BV bounds    x[2178]
 BV bounds    x[2179]
 BV bounds    x[2180]
 BV bounds    x[2181]
 BV bounds    x[2182]
 BV bounds    x[2183]
 BV bounds    x[2184]
 BV bounds    x[2185]
 BV bounds    x[2186]
 BV bounds    x[2187]
 BV bounds    x[2188]
 BV bounds    x[2189]
 BV bounds    x[2190]
 BV bounds    x[2191]
 BV bounds    x[2192]
 BV bounds    x[2193]
 BV bounds    x[2194]
 BV bounds    x[2195]
 BV bounds    x[2196]
 BV bounds    x[2197]
 BV bounds    x[2198]
 BV bounds    x[2199]
 BV bounds    x[2200]
 BV bounds    x[2201]
 BV bounds    x[2202]
 BV bounds    x[2203]
 BV bounds    x[2204]
 BV bounds    x[2205]
 BV bounds    x[2206]
 BV bounds    x[2207]
 BV bounds    x[2208]
 BV bounds    x[2209]
 BV bounds    x[2210]
 BV bounds    x[2211]
 BV bounds    x[2212]
 BV bounds    x[2213]
 BV bounds    x[2214]
 BV bounds    x[2215]
 BV bounds    x[2216]
 BV bounds    x[2217]
 BV bounds    x[2218]
 BV bounds    x[2219]
 BV bounds    x[2220]
 BV bounds    x[2221]
 BV bounds    x[2222]
 BV bounds    x[2223]
 BV bounds    x[2224]
 BV bounds    x[2225]
 BV bounds    x[2226]
 BV bounds    x[2227]
 BV bounds    x[2228]
 BV bounds    x[2229]
 BV bounds    x[2230]
 BV bounds    x[2231]
 BV bounds    x[2232]
 BV bounds    x[2233]
 BV bounds    x[2234]
 BV bounds    x[2235]
 BV bounds    x[2236]
 BV bounds    x[2237]
 BV bounds    x[2238]
 BV bounds    x[2239]
 BV bounds    x[2240]
 BV bounds    x[2241]
 BV bounds    x[2242]
 BV bounds    x[2243]
 BV bounds    x[2244]
 BV bounds    x[2245]
 BV bounds    x[2246]
 BV bounds    x[2247]
 BV bounds    x[2248]
 BV bounds    x[2249]
 BV bounds    x[2250]
 BV bounds    x[2251]
 BV bounds    x[2252]
 BV bounds    x[2253]
 BV bounds    x[2254]
 BV bounds    x[2255]
 BV bounds    x[2256]
 BV bounds    x[2257]
 BV bounds    x[2258]
 BV bounds    x[2259]
 BV bounds    x[2260]
 BV bounds    x[2261]
 BV bounds    x[2262]
 BV bounds    x[2263]
 BV bounds    x[2264]
 BV bounds    x[2265]
 BV bounds    x[2266]
 BV bounds    x[2267]
 BV bounds    x[2268]
 BV bounds    x[2269]
 BV bounds    x[2270]
 BV bounds    x[2271]
 BV bounds    x[2272]
 BV bounds    x[2273]
 BV bounds    x[2274]
 BV bounds    x[2275]
 BV bounds    x[2276]
 BV bounds    x[2277]
 BV bounds    x[2278]
 BV bounds    x[2279]
 BV bounds    x[2280]
 BV bounds    x[2281]
 BV bounds    x[2282]
 BV bounds    x[2283]
 BV bounds    x[2284]
 BV bounds    x[2285]
 BV bounds    x[2286]
 BV bounds    x[2287]
 BV bounds    x[2288]
 BV bounds    x[2289]
 BV bounds    x[2290]
 BV bounds    x[2291]
 BV bounds    x[2292]
 BV bounds    x[2293]
 BV bounds    x[2294]
 BV bounds    x[2295]
 BV bounds    x[2296]
 BV bounds    x[2297]
 BV bounds    x[2298]
 BV bounds    x[2299]
 BV bounds    x[2300]
 BV bounds    x[2301]
 BV bounds    x[2302]
 BV bounds    x[2303]
 BV bounds    x[2304]
 BV bounds    x[2305]
 BV bounds    x[2306]
 BV bounds    x[2307]
 BV bounds    x[2308]
 BV bounds    x[2309]
 BV bounds    x[2310]
 BV bounds    x[2311]
 BV bounds    x[2312]
 BV bounds    x[2313]
 BV bounds    x[2314]
 BV bounds    x[2315]
 BV bounds    x[2316]
 BV bounds    x[2317]
 BV bounds    x[2318]
 BV bounds    x[2319]
 BV bounds    x[2320]
 BV bounds    x[2321]
 BV bounds    x[2322]
 BV bounds    x[2323]
 BV bounds    x[2324]
 BV bounds    x[2325]
 BV bounds    x[2326]
 BV bounds    x[2327]
 BV bounds    x[2328]
 BV bounds    x[2329]
 BV bounds    x[2330]
 BV bounds    x[2331]
 BV bounds    x[2332]
 BV bounds    x[2333]
 BV bounds    x[2334]
 BV bounds    x[2335]
 BV bounds    x[2336]
 BV bounds    x[2337]
 BV bounds    x[2338]
 BV bounds    x[2339]
 BV bounds    x[2340]
 BV bounds    x[2341]
 BV bounds    x[2342]
 BV bounds    x[2343]
 BV bounds    x[2344]
 BV bounds    x[2345]
 BV bounds    x[2346]
 BV bounds    x[2347]
 BV bounds    x[2348]
 BV bounds    x[2349]
 BV bounds    x[2350]
 BV bounds    x[2351]
 BV bounds    x[2352]
 BV bounds    x[2353]
 BV bounds    x[2354]
 BV bounds    x[2355]
 BV bounds    x[2356]
 BV bounds    x[2357]
 BV bounds    x[2358]
 BV bounds    x[2359]
 BV bounds    x[2360]
 BV bounds    x[2361]
 BV bounds    x[2362]
 BV bounds    x[2363]
 BV bounds    x[2364]
 BV bounds    x[2365]
 BV bounds    x[2366]
 BV bounds    x[2367]
 BV bounds    x[2368]
 BV bounds    x[2369]
 BV bounds    x[2370]
 BV bounds    x[2371]
 BV bounds    x[2372]
 BV bounds    x[2373]
 BV bounds    x[2374]
 BV bounds    x[2375]
 BV bounds    x[2376]
 BV bounds    x[2377]
 BV bounds    x[2378]
 BV bounds    x[2379]
 BV bounds    x[2380]
 BV bounds    x[2381]
 BV bounds    x[2382]
 BV bounds    x[2383]
 BV bounds    x[2384]
 BV bounds    x[2385]
 BV bounds    x[2386]
 BV bounds    x[2387]
 BV bounds    x[2388]
 BV bounds    x[2389]
 BV bounds    x[2390]
 BV bounds    x[2391]
 BV bounds    x[2392]
 BV bounds    x[2393]
 BV bounds    x[2394]
 BV bounds    x[2395]
 BV bounds    x[2396]
 BV bounds    x[2397]
 BV bounds    x[2398]
 BV bounds    x[2399]
 BV bounds    x[2400]
 BV bounds    x[2401]
 BV bounds    x[2402]
 BV bounds    x[2403]
 BV bounds    x[2404]
 BV bounds    x[2405]
 BV bounds    x[2406]
 BV bounds    x[2407]
 BV bounds    x[2408]
 BV bounds    x[2409]
 BV bounds    x[2410]
 BV bounds    x[2411]
 BV bounds    x[2412]
 BV bounds    x[2413]
 BV bounds    x[2414]
 BV bounds    x[2415]
 BV bounds    x[2416]
 BV bounds    x[2417]
 BV bounds    x[2418]
 BV bounds    x[2419]
 BV bounds    x[2420]
 BV bounds    x[2421]
 BV bounds    x[2422]
 BV bounds    x[2423]
 BV bounds    x[2424]
 BV bounds    x[2425]
 BV bounds    x[2426]
 BV bounds    x[2427]
 BV bounds    x[2428]
 BV bounds    x[2429]
 BV bounds    x[2430]
 BV bounds    x[2431]
 BV bounds    x[2432]
 BV bounds    x[2433]
 BV bounds    x[2434]
 BV bounds    x[2435]
 BV bounds    x[2436]
 BV bounds    x[2437]
 BV bounds    x[2438]
 BV bounds    x[2439]
 BV bounds    x[2440]
 BV bounds    x[2441]
 BV bounds    x[2442]
 BV bounds    x[2443]
 BV bounds    x[2444]
 BV bounds    x[2445]
 BV bounds    x[2446]
 BV bounds    x[2447]
 BV bounds    x[2448]
 BV bounds    x[2449]
 BV bounds    x[2450]
 BV bounds    x[2451]
 BV bounds    x[2452]
 BV bounds    x[2453]
 BV bounds    x[2454]
 BV bounds    x[2455]
 BV bounds    x[2456]
 BV bounds    x[2457]
 BV bounds    x[2458]
 BV bounds    x[2459]
 BV bounds    x[2460]
 BV bounds    x[2461]
 BV bounds    x[2462]
 BV bounds    x[2463]
 BV bounds    x[2464]
 BV bounds    x[2465]
 BV bounds    x[2466]
 BV bounds    x[2467]
 BV bounds    x[2468]
 BV bounds    x[2469]
 BV bounds    x[2470]
 BV bounds    x[2471]
 BV bounds    x[2472]
 BV bounds    x[2473]
 BV bounds    x[2474]
 BV bounds    x[2475]
 BV bounds    x[2476]
 BV bounds    x[2477]
 BV bounds    x[2478]
 BV bounds    x[2479]
 BV bounds    x[2480]
 BV bounds    x[2481]
 BV bounds    x[2482]
 BV bounds    x[2483]
 BV bounds    x[2484]
 BV bounds    x[2485]
 BV bounds    x[2486]
 BV bounds    x[2487]
 BV bounds    x[2488]
 BV bounds    x[2489]
 BV bounds    x[2490]
 BV bounds    x[2491]
 BV bounds    x[2492]
 BV bounds    x[2493]
 BV bounds    x[2494]
 BV bounds    x[2495]
 BV bounds    x[2496]
 BV bounds    x[2497]
 BV bounds    x[2498]
 BV bounds    x[2499]
 BV bounds    x[2500]
 BV bounds    x[2501]
 BV bounds    x[2502]
 BV bounds    x[2503]
 BV bounds    x[2504]
 BV bounds    x[2505]
 BV bounds    x[2506]
 BV bounds    x[2507]
 BV bounds    x[2508]
 BV bounds    x[2509]
 BV bounds    x[2510]
 BV bounds    x[2511]
 BV bounds    x[2512]
 BV bounds    x[2513]
 BV bounds    x[2514]
 BV bounds    x[2515]
 BV bounds    x[2516]
 BV bounds    x[2517]
 BV bounds    x[2518]
 BV bounds    x[2519]
 BV bounds    x[2520]
 BV bounds    x[2521]
 BV bounds    x[2522]
 BV bounds    x[2523]
 BV bounds    x[2524]
 BV bounds    x[2525]
 BV bounds    x[2526]
 BV bounds    x[2527]
 BV bounds    x[2528]
 BV bounds    x[2529]
 BV bounds    x[2530]
 BV bounds    x[2531]
 BV bounds    x[2532]
 BV bounds    x[2533]
 BV bounds    x[2534]
 BV bounds    x[2535]
 BV bounds    x[2536]
 BV bounds    x[2537]
 BV bounds    x[2538]
 BV bounds    x[2539]
 BV bounds    x[2540]
 BV bounds    x[2541]
 BV bounds    x[2542]
 BV bounds    x[2543]
 BV bounds    x[2544]
 BV bounds    x[2545]
 BV bounds    x[2546]
 BV bounds    x[2547]
 BV bounds    x[2548]
 BV bounds    x[2549]
 BV bounds    x[2550]
 BV bounds    x[2551]
 BV bounds    x[2552]
 BV bounds    x[2553]
 BV bounds    x[2554]
 BV bounds    x[2555]
 BV bounds    x[2556]
 BV bounds    x[2557]
 BV bounds    x[2558]
 BV bounds    x[2559]
 BV bounds    x[2560]
 BV bounds    x[2561]
 BV bounds    x[2562]
 BV bounds    x[2563]
 BV bounds    x[2564]
 BV bounds    x[2565]
 BV bounds    x[2566]
 BV bounds    x[2567]
 BV bounds    x[2568]
 BV bounds    x[2569]
 BV bounds    x[2570]
 BV bounds    x[2571]
 BV bounds    x[2572]
 BV bounds    x[2573]
 BV bounds    x[2574]
 BV bounds    x[2575]
 BV bounds    x[2576]
 BV bounds    x[2577]
 BV bounds    x[2578]
 BV bounds    x[2579]
 BV bounds    x[2580]
 BV bounds    x[2581]
 BV bounds    x[2582]
 BV bounds    x[2583]
 BV bounds    x[2584]
 BV bounds    x[2585]
 BV bounds    x[2586]
 BV bounds    x[2587]
 BV bounds    x[2588]
 BV bounds    x[2589]
 BV bounds    x[2590]
 BV bounds    x[2591]
 BV bounds    x[2592]
 BV bounds    x[2593]
 BV bounds    x[2594]
 BV bounds    x[2595]
 BV bounds    x[2596]
 BV bounds    x[2597]
 BV bounds    x[2598]
 BV bounds    x[2599]
 BV bounds    x[2600]
 BV bounds    x[2601]
 BV bounds    x[2602]
 BV bounds    x[2603]
 BV bounds    x[2604]
 BV bounds    x[2605]
 BV bounds    x[2606]
 BV bounds    x[2607]
 BV bounds    x[2608]
 BV bounds    x[2609]
 BV bounds    x[2610]
 BV bounds    x[2611]
 BV bounds    x[2612]
 BV bounds    x[2613]
 BV bounds    x[2614]
 BV bounds    x[2615]
 BV bounds    x[2616]
 BV bounds    x[2617]
 BV bounds    x[2618]
 BV bounds    x[2619]
 BV bounds    x[2620]
 BV bounds    x[2621]
 BV bounds    x[2622]
 BV bounds    x[2623]
 BV bounds    x[2624]
 BV bounds    x[2625]
 BV bounds    x[2626]
 BV bounds    x[2627]
 BV bounds    x[2628]
 BV bounds    x[2629]
 BV bounds    x[2630]
 BV bounds    x[2631]
 BV bounds    x[2632]
 BV bounds    x[2633]
 BV bounds    x[2634]
 BV bounds    x[2635]
 BV bounds    x[2636]
 BV bounds    x[2637]
 BV bounds    x[2638]
 BV bounds    x[2639]
 BV bounds    x[2640]
 BV bounds    x[2641]
 BV bounds    x[2642]
 BV bounds    x[2643]
 BV bounds    x[2644]
 BV bounds    x[2645]
 BV bounds    x[2646]
 BV bounds    x[2647]
 BV bounds    x[2648]
 BV bounds    x[2649]
 BV bounds    x[2650]
 BV bounds    x[2651]
 BV bounds    x[2652]
 BV bounds    x[2653]
 BV bounds    x[2654]
 BV bounds    x[2655]
 BV bounds    x[2656]
 BV bounds    x[2657]
 BV bounds    x[2658]
 BV bounds    x[2659]
 BV bounds    x[2660]
 BV bounds    x[2661]
 BV bounds    x[2662]
 BV bounds    x[2663]
 BV bounds    x[2664]
 BV bounds    x[2665]
 BV bounds    x[2666]
 BV bounds    x[2667]
 BV bounds    x[2668]
 BV bounds    x[2669]
 BV bounds    x[2670]
 BV bounds    x[2671]
 BV bounds    x[2672]
 BV bounds    x[2673]
 BV bounds    x[2674]
 BV bounds    x[2675]
 BV bounds    x[2676]
 BV bounds    x[2677]
 BV bounds    x[2678]
 BV bounds    x[2679]
 BV bounds    x[2680]
 BV bounds    x[2681]
 BV bounds    x[2682]
 BV bounds    x[2683]
 BV bounds    x[2684]
 BV bounds    x[2685]
 BV bounds    x[2686]
 BV bounds    x[2687]
 BV bounds    x[2688]
 BV bounds    x[2689]
 BV bounds    x[2690]
 BV bounds    x[2691]
 BV bounds    x[2692]
 BV bounds    x[2693]
 BV bounds    x[2694]
 BV bounds    x[2695]
 BV bounds    x[2696]
 BV bounds    x[2697]
 BV bounds    x[2698]
 BV bounds    x[2699]
 BV bounds    x[2700]
 BV bounds    x[2701]
 BV bounds    x[2702]
 BV bounds    x[2703]
 BV bounds    x[2704]
 BV bounds    x[2705]
 BV bounds    x[2706]
 BV bounds    x[2707]
 BV bounds    x[2708]
 BV bounds    x[2709]
 BV bounds    x[2710]
 BV bounds    x[2711]
 BV bounds    x[2712]
 BV bounds    x[2713]
 BV bounds    x[2714]
 BV bounds    x[2715]
 BV bounds    x[2716]
 BV bounds    x[2717]
 BV bounds    x[2718]
 BV bounds    x[2719]
 BV bounds    x[2720]
 BV bounds    x[2721]
 BV bounds    x[2722]
 BV bounds    x[2723]
 BV bounds    x[2724]
 BV bounds    x[2725]
 BV bounds    x[2726]
 BV bounds    x[2727]
 BV bounds    x[2728]
 BV bounds    x[2729]
 BV bounds    x[2730]
 BV bounds    x[2731]
 BV bounds    x[2732]
 BV bounds    x[2733]
 BV bounds    x[2734]
 BV bounds    x[2735]
 BV bounds    x[2736]
 BV bounds    x[2737]
 BV bounds    x[2738]
 BV bounds    x[2739]
 BV bounds    x[2740]
 BV bounds    x[2741]
 BV bounds    x[2742]
 BV bounds    x[2743]
 BV bounds    x[2744]
 BV bounds    x[2745]
 BV bounds    x[2746]
 BV bounds    x[2747]
 BV bounds    x[2748]
 BV bounds    x[2749]
 BV bounds    x[2750]
 BV bounds    x[2751]
 BV bounds    x[2752]
 BV bounds    x[2753]
 BV bounds    x[2754]
 BV bounds    x[2755]
 BV bounds    x[2756]
 BV bounds    x[2757]
 BV bounds    x[2758]
 BV bounds    x[2759]
 BV bounds    x[2760]
 BV bounds    x[2761]
 BV bounds    x[2762]
 BV bounds    x[2763]
 BV bounds    x[2764]
 BV bounds    x[2765]
 BV bounds    x[2766]
 BV bounds    x[2767]
 BV bounds    x[2768]
 BV bounds    x[2769]
 BV bounds    x[2770]
 BV bounds    x[2771]
 BV bounds    x[2772]
 BV bounds    x[2773]
 BV bounds    x[2774]
 BV bounds    x[2775]
 BV bounds    x[2776]
 BV bounds    x[2777]
 BV bounds    x[2778]
 BV bounds    x[2779]
 BV bounds    x[2780]
 BV bounds    x[2781]
 BV bounds    x[2782]
 BV bounds    x[2783]
 BV bounds    x[2784]
 BV bounds    x[2785]
 BV bounds    x[2786]
 BV bounds    x[2787]
 BV bounds    x[2788]
 BV bounds    x[2789]
 BV bounds    x[2790]
 BV bounds    x[2791]
 BV bounds    x[2792]
 BV bounds    x[2793]
 BV bounds    x[2794]
 BV bounds    x[2795]
 BV bounds    x[2796]
 BV bounds    x[2797]
 BV bounds    x[2798]
 BV bounds    x[2799]
 BV bounds    x[2800]
 BV bounds    x[2801]
 BV bounds    x[2802]
 BV bounds    x[2803]
 BV bounds    x[2804]
 BV bounds    x[2805]
 BV bounds    x[2806]
 BV bounds    x[2807]
 BV bounds    x[2808]
 BV bounds    x[2809]
 BV bounds    x[2810]
 BV bounds    x[2811]
 BV bounds    x[2812]
 BV bounds    x[2813]
 BV bounds    x[2814]
 BV bounds    x[2815]
 BV bounds    x[2816]
 BV bounds    x[2817]
 BV bounds    x[2818]
 BV bounds    x[2819]
 BV bounds    x[2820]
 BV bounds    x[2821]
 BV bounds    x[2822]
 BV bounds    x[2823]
 BV bounds    x[2824]
 BV bounds    x[2825]
 BV bounds    x[2826]
 BV bounds    x[2827]
 BV bounds    x[2828]
 BV bounds    x[2829]
 BV bounds    x[2830]
 BV bounds    x[2831]
 BV bounds    x[2832]
 BV bounds    x[2833]
 BV bounds    x[2834]
 BV bounds    x[2835]
 BV bounds    x[2836]
 BV bounds    x[2837]
 BV bounds    x[2838]
 BV bounds    x[2839]
 BV bounds    x[2840]
 BV bounds    x[2841]
 BV bounds    x[2842]
 BV bounds    x[2843]
 BV bounds    x[2844]
 BV bounds    x[2845]
 BV bounds    x[2846]
 BV bounds    x[2847]
 BV bounds    x[2848]
 BV bounds    x[2849]
 BV bounds    x[2850]
 BV bounds    x[2851]
 BV bounds    x[2852]
 BV bounds    x[2853]
 BV bounds    x[2854]
 BV bounds    x[2855]
 BV bounds    x[2856]
 BV bounds    x[2857]
 BV bounds    x[2858]
 BV bounds    x[2859]
 BV bounds    x[2860]
 BV bounds    x[2861]
 BV bounds    x[2862]
 BV bounds    x[2863]
 BV bounds    x[2864]
 BV bounds    x[2865]
 BV bounds    x[2866]
 BV bounds    x[2867]
 BV bounds    x[2868]
 BV bounds    x[2869]
 BV bounds    x[2870]
 BV bounds    x[2871]
 BV bounds    x[2872]
 BV bounds    x[2873]
 BV bounds    x[2874]
 BV bounds    x[2875]
 BV bounds    x[2876]
 BV bounds    x[2877]
 BV bounds    x[2878]
 BV bounds    x[2879]
 BV bounds    x[2880]
 BV bounds    x[2881]
 BV bounds    x[2882]
 BV bounds    x[2883]
 BV bounds    x[2884]
 BV bounds    x[2885]
 BV bounds    x[2886]
 BV bounds    x[2887]
 BV bounds    x[2888]
 BV bounds    x[2889]
 BV bounds    x[2890]
 BV bounds    x[2891]
 BV bounds    x[2892]
 BV bounds    x[2893]
 BV bounds    x[2894]
 BV bounds    x[2895]
 BV bounds    x[2896]
 BV bounds    x[2897]
 BV bounds    x[2898]
 BV bounds    x[2899]
 BV bounds    x[2900]
 BV bounds    x[2901]
 BV bounds    x[2902]
 BV bounds    x[2903]
 BV bounds    x[2904]
 BV bounds    x[2905]
 BV bounds    x[2906]
 BV bounds    x[2907]
 BV bounds    x[2908]
 BV bounds    x[2909]
 BV bounds    x[2910]
 BV bounds    x[2911]
 BV bounds    x[2912]
 BV bounds    x[2913]
 BV bounds    x[2914]
 BV bounds    x[2915]
 BV bounds    x[2916]
 BV bounds    x[2917]
 BV bounds    x[2918]
 BV bounds    x[2919]
 BV bounds    x[2920]
 BV bounds    x[2921]
 BV bounds    x[2922]
 BV bounds    x[2923]
 BV bounds    x[2924]
 BV bounds    x[2925]
 BV bounds    x[2926]
 BV bounds    x[2927]
 BV bounds    x[2928]
 BV bounds    x[2929]
 BV bounds    x[2930]
 BV bounds    x[2931]
 BV bounds    x[2932]
 BV bounds    x[2933]
 BV bounds    x[2934]
 BV bounds    x[2935]
 BV bounds    x[2936]
 BV bounds    x[2937]
 BV bounds    x[2938]
 BV bounds    x[2939]
 BV bounds    x[2940]
 BV bounds    x[2941]
 BV bounds    x[2942]
 BV bounds    x[2943]
 BV bounds    x[2944]
 BV bounds    x[2945]
 BV bounds    x[2946]
 BV bounds    x[2947]
 BV bounds    x[2948]
 BV bounds    x[2949]
 BV bounds    x[2950]
 BV bounds    x[2951]
 BV bounds    x[2952]
 BV bounds    x[2953]
 BV bounds    x[2954]
 BV bounds    x[2955]
 BV bounds    x[2956]
 BV bounds    x[2957]
 BV bounds    x[2958]
 BV bounds    x[2959]
 BV bounds    x[2960]
 BV bounds    x[2961]
 BV bounds    x[2962]
 BV bounds    x[2963]
 BV bounds    x[2964]
 BV bounds    x[2965]
 BV bounds    x[2966]
 BV bounds    x[2967]
 BV bounds    x[2968]
 BV bounds    x[2969]
 BV bounds    x[2970]
 BV bounds    x[2971]
 BV bounds    x[2972]
 BV bounds    x[2973]
 BV bounds    x[2974]
 BV bounds    x[2975]
 BV bounds    x[2976]
 BV bounds    x[2977]
 BV bounds    x[2978]
 BV bounds    x[2979]
 BV bounds    x[2980]
 BV bounds    x[2981]
 BV bounds    x[2982]
 BV bounds    x[2983]
 BV bounds    x[2984]
 BV bounds    x[2985]
ENDATA
