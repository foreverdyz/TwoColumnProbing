NAME
ROWS
 N  OBJ
 L  c1_2
 L  c2_2
 L  c3_2
 L  c4_2
 L  c5_2
 L  c6_2
 L  c7_2
 L  c8_2
 L  c9_2
 L  c10_2
 L  c11_2
 L  c12_2
 L  c13_2
 L  c14_2
 L  c15_2
 L  c16_2
 L  c17_2
 L  c18_2
 L  c19_2
 L  c20_2
 L  c21_2
 L  c22_2
 L  c23_2
 L  c24_2
 L  c25_2
 L  c26_2
 L  c27_2
 L  c28_2
 L  c29_2
 L  c30_2
 L  c31_2
 L  c32_2
 L  c33_2
 L  c34_2
 L  c35_2
 L  c36_2
 L  c37_2
 L  c38_2
 L  c39_2
 L  c40_2
 L  c41_2
 L  c42_2
 L  c43_2
 L  c44_2
 L  c45_2
 L  c46_2
 L  c47_2
 L  c48_2
 L  c49_2
 L  c50_2
 L  c51_2
 L  c52_2
 L  c53_2
 L  c54_2
 L  c55_2
 L  c56_2
 L  c57_2
 L  c58_2
 L  c59_2
 L  c60_2
 L  c61_2
 L  c62_2
 L  c63_2
 L  c64_2
 L  c65_2
 L  c66_2
 L  c67_2
 L  c68_2
 L  c69_2
 L  c70_2
 L  c71_2
 L  c72_2
 L  c73_2
 L  c74_2
 L  c75_2
 L  c76_2
 L  c77_2
 L  c78_2
 L  c79_2
 L  c80_2
 L  c81_2
 L  c82_2
 L  c83_2
 L  c84_2
 L  c85_2
 L  c86_2
 L  c87_2
 L  c88_2
 L  c89_2
 L  c90_2
 L  c91_2
 L  c92_2
 L  c93_2
 L  c94_2
 L  c95_2
 L  c96_2
 L  c97_2
 L  c98_2
 L  c99_2
 L  c100_2
 L  c101_2
 L  c102_2
 L  c103_2
 L  c104_2
 L  c105_2
 L  c106_2
 L  c107_2
 L  c108_2
 L  c109_2
 L  c110_2
 L  c111_2
 L  c112_2
 L  c113_2
 L  c114_2
 L  c115_2
 L  c116_2
 L  c117_2
 L  c118_2
 L  c119_2
 L  c120_2
 L  c121_2
 L  c122_2
 L  c123_2
 L  c124_2
 L  c125_2
 L  c126_2
 L  c127_2
 L  c128_2
 L  c129_2
 L  c130_2
 L  c131_2
 L  c132_2
 L  c133_2
 L  c134_2
 L  c135_2
 L  c136_2
 L  c137_2
 L  c138_2
 L  c139_2
 L  c140_2
 L  c141_2
 L  c142_2
 L  c143_2
 L  c144_2
 L  c145_2
 L  c146_2
 L  c147_2
 L  c148_2
 L  c149_2
 L  c150_2
 L  c151_2
 L  c152_2
 L  c153_2
 L  c154_2
 L  c155_2
 L  c156_2
 L  c157_2
 L  c158_2
 L  c159_2
 L  c160_2
 L  c161_2
 L  c162_2
 L  c163_2
 L  c164_2
 L  c165_2
 L  c166_2
 L  c167_2
 L  c168_2
 L  c169_2
 L  c170_2
 L  c171_2
 L  c172_2
 L  c173_2
 L  c174_2
 L  c175_2
 L  c176_2
 L  c177_2
 L  c178_2
 L  c179_2
 L  c180_2
 L  c181_2
 L  c182_2
 L  c183_2
 L  c184_2
 L  c185_2
 L  c186_2
 L  c187_2
 L  c188_2
 L  c189_2
 L  c190_2
 L  c191_2
 L  c192_2
 L  c193_2
 L  c194_2
 L  c195_2
 L  c196_2
 L  c197_2
 L  c198_2
 L  c199_2
 L  c200_2
 L  c201_2
 L  c202_2
 L  c203_2
 L  c204_2
 L  c205_2
 L  c206_2
 L  c207_2
 L  c208_2
 L  c209_2
 L  c210_2
 L  c211_2
 L  c212_2
 L  c213_2
 L  c214_2
 L  c215_2
 L  c216_2
 L  c217_2
 L  c218_2
 L  c219_2
 L  c220_2
 L  c221_2
 L  c222_2
 L  c223_2
 L  c224_2
 L  c225_2
 L  c226_2
 L  c227_2
 L  c228_2
 L  c229_2
 L  c230_2
 L  c231_2
 L  c232_2
 L  c233_2
 L  c234_2
 L  c235_2
 L  c236_2
 L  c237_2
 L  c238_2
 L  c239_2
 L  c240_2
 L  c241_2
 L  c242_2
 L  c243_2
 L  c244_2
 L  c245_2
 L  c246_2
 L  c247_2
 L  c248_2
 L  c249_2
 L  c250_2
 L  c251_2
 L  c252_2
 L  c253_2
 L  c254_2
 L  c255_2
 L  c256_2
 L  c257_2
 L  c258_2
 L  c259_2
 L  c260_2
 L  c261_2
 L  c262_2
 L  c263_2
 G  c1_1
 G  c2_1
 G  c3_1
 G  c4_1
 G  c5_1
 G  c6_1
 G  c7_1
 G  c8_1
 G  c9_1
 G  c10_1
 G  c11_1
 G  c12_1
 G  c13_1
 G  c14_1
 G  c15_1
 G  c16_1
 G  c17_1
 G  c18_1
 G  c19_1
 G  c20_1
 G  c21_1
 G  c22_1
 G  c23_1
 G  c24_1
 G  c25_1
 G  c26_1
 G  c27_1
 G  c28_1
 G  c29_1
 G  c30_1
 G  c31_1
 G  c32_1
 G  c33_1
 G  c34_1
 G  c35_1
 G  c36_1
 G  c37_1
 G  c38_1
 G  c39_1
 G  c40_1
 G  c41_1
 G  c42_1
 G  c43_1
 G  c44_1
 G  c45_1
 G  c46_1
 G  c47_1
 G  c48_1
 G  c49_1
 G  c50_1
 G  c51_1
 G  c52_1
 G  c53_1
 G  c54_1
 G  c55_1
 G  c56_1
 G  c57_1
 G  c58_1
 G  c59_1
 G  c60_1
 G  c61_1
 G  c62_1
 G  c63_1
 G  c64_1
 G  c65_1
 G  c66_1
 G  c67_1
 G  c68_1
 G  c69_1
 G  c70_1
 G  c71_1
 G  c72_1
 G  c73_1
 G  c74_1
 G  c75_1
 G  c76_1
 G  c77_1
 G  c78_1
 G  c79_1
 G  c80_1
 G  c81_1
 G  c82_1
 G  c83_1
 G  c84_1
 G  c85_1
 G  c86_1
 G  c87_1
 G  c88_1
 G  c89_1
 G  c90_1
 G  c91_1
 G  c92_1
 G  c93_1
 G  c94_1
 G  c95_1
 G  c96_1
 G  c97_1
 G  c98_1
 G  c99_1
 G  c100_1
 G  c101_1
 G  c102_1
 G  c103_1
 G  c104_1
 G  c105_1
 G  c106_1
 G  c107_1
 G  c108_1
 G  c109_1
 G  c110_1
 G  c111_1
 G  c112_1
 G  c113_1
 G  c114_1
 G  c115_1
 G  c116_1
 G  c117_1
 G  c118_1
 G  c119_1
 G  c120_1
 G  c121_1
 G  c122_1
 G  c123_1
 G  c124_1
 G  c125_1
 G  c126_1
 G  c127_1
 G  c128_1
 G  c129_1
 G  c130_1
 G  c131_1
 G  c132_1
 G  c133_1
 G  c134_1
 G  c135_1
 G  c136_1
 G  c137_1
 G  c138_1
 G  c139_1
 G  c140_1
 G  c141_1
 G  c142_1
 G  c143_1
 G  c144_1
 G  c145_1
 G  c146_1
 G  c147_1
 G  c148_1
 G  c149_1
 G  c150_1
 G  c151_1
 G  c152_1
 G  c153_1
 G  c154_1
 G  c155_1
 G  c156_1
 G  c157_1
 G  c158_1
 G  c159_1
 G  c160_1
 G  c161_1
 G  c162_1
 G  c163_1
 G  c164_1
 G  c165_1
 G  c166_1
 G  c167_1
 G  c168_1
 G  c169_1
 G  c170_1
 G  c171_1
 G  c172_1
 G  c173_1
 G  c174_1
 G  c175_1
 G  c176_1
 G  c177_1
 G  c178_1
 G  c179_1
 G  c180_1
 G  c181_1
 G  c182_1
 G  c183_1
 G  c184_1
 G  c185_1
 G  c186_1
 G  c187_1
 G  c188_1
 G  c189_1
 G  c190_1
 G  c191_1
 G  c192_1
 G  c193_1
 G  c194_1
 G  c195_1
 G  c196_1
 G  c197_1
 G  c198_1
 G  c199_1
 G  c200_1
 G  c201_1
 G  c202_1
 G  c203_1
 G  c204_1
 G  c205_1
 G  c206_1
 G  c207_1
 G  c208_1
 G  c209_1
 G  c210_1
 G  c211_1
 G  c212_1
 G  c213_1
 G  c214_1
 G  c215_1
 G  c216_1
 G  c217_1
 G  c218_1
 G  c219_1
 G  c220_1
 G  c221_1
 G  c222_1
 G  c223_1
 G  c224_1
 G  c225_1
 G  c226_1
 G  c227_1
 G  c228_1
 G  c229_1
 G  c230_1
 G  c231_1
 G  c232_1
 G  c233_1
 G  c234_1
 G  c235_1
 G  c236_1
 G  c237_1
 G  c238_1
 G  c239_1
 G  c240_1
 G  c241_1
 G  c242_1
 G  c243_1
 G  c244_1
 G  c245_1
 G  c246_1
 G  c247_1
 G  c248_1
 G  c249_1
 G  c250_1
 G  c251_1
 G  c252_1
 G  c253_1
 G  c254_1
 G  c255_1
 G  c256_1
 G  c257_1
 G  c258_1
 G  c259_1
 G  c260_1
 G  c261_1
 G  c262_1
 G  c263_1
 G  c264_1
 G  c265_1
 G  c266_1
 G  c267_1
 G  c268_1
 G  c269_1
 G  c270_1
 G  c271_1
 G  c272_1
 G  c273_1
 G  c274_1
 G  c275_1
 G  c276_1
 G  c277_1
 G  c278_1
 G  c279_1
 G  c280_1
 G  c281_1
 G  c282_1
 G  c283_1
 G  c284_1
 G  c285_1
 G  c286_1
 G  c287_1
 G  c288_1
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
 E  c625
 E  c626
 E  c627
 E  c628
 E  c629
 E  c630
 E  c631
 E  c632
 E  c633
 E  c634
 E  c635
 E  c636
 E  c637
 E  c638
 E  c639
 E  c640
 E  c641
 E  c642
 E  c643
 E  c644
 E  c645
 E  c646
 E  c647
 E  c648
 E  c649
 E  c650
 E  c651
 E  c652
 E  c653
 E  c654
 E  c655
 E  c656
 E  c657
 E  c658
 E  c659
 E  c660
 E  c661
 E  c662
 E  c663
 E  c664
 E  c665
 E  c666
 E  c667
 E  c668
 E  c669
 E  c670
 E  c671
 E  c672
 E  c673
 E  c674
 E  c675
 E  c676
 E  c677
 E  c678
 E  c679
 E  c680
 E  c681
 E  c682
 E  c683
 E  c684
 E  c685
 E  c686
 E  c687
 E  c688
 E  c689
 E  c690
 E  c691
 E  c692
 E  c693
 E  c694
 E  c695
 E  c696
 E  c697
 E  c698
 E  c699
 E  c700
 E  c701
 E  c702
 E  c703
 E  c704
 E  c705
 E  c706
 E  c707
 E  c708
 E  c709
 E  c710
 E  c711
 E  c712
 E  c713
 E  c714
 E  c715
 E  c716
 E  c717
 E  c718
 E  c719
 E  c720
 E  c721
 E  c722
 E  c723
 E  c724
 E  c725
 E  c726
 E  c727
 E  c728
 E  c729
 E  c730
 E  c731
 E  c732
 E  c733
 E  c734
 E  c735
 E  c736
 E  c737
 E  c738
 E  c739
 E  c740
 E  c741
 E  c742
 E  c743
 E  c744
 E  c745
 E  c746
 E  c747
 E  c748
 E  c749
 E  c750
 E  c751
 E  c752
 E  c753
 E  c754
 E  c755
 E  c756
 E  c757
 E  c758
 E  c759
 E  c760
 E  c761
 E  c762
 E  c763
 E  c764
 E  c765
 E  c766
 E  c767
 E  c768
 E  c769
 E  c770
 E  c771
 E  c772
 E  c773
 E  c774
 E  c775
 E  c776
 E  c777
 E  c778
 E  c779
 E  c780
 E  c781
 E  c782
 E  c783
 E  c784
 E  c785
 E  c786
 E  c787
 E  c788
 E  c789
 E  c790
 E  c791
 E  c792
 E  c793
 E  c794
 E  c795
 E  c796
 E  c797
 E  c798
 E  c799
 E  c800
 E  c801
 E  c802
 E  c803
 E  c804
 E  c805
 E  c806
 E  c807
 E  c808
 E  c809
 E  c810
 E  c811
 E  c812
 E  c813
 E  c814
 E  c815
 E  c816
 E  c817
 E  c818
 E  c819
 E  c820
 E  c821
 E  c822
 E  c823
 E  c824
 E  c825
 E  c826
 E  c827
 E  c828
 E  c829
 E  c830
 E  c831
 E  c832
 E  c833
 E  c834
 E  c835
 E  c836
 E  c837
 E  c838
 E  c839
 E  c840
 E  c841
 E  c842
 E  c843
 E  c844
 E  c845
 E  c846
 E  c847
 E  c848
 E  c849
 E  c850
 E  c851
 E  c852
 E  c853
 E  c854
 E  c855
 E  c856
 E  c857
 E  c858
 E  c859
 E  c860
 E  c861
 E  c862
 E  c863
 E  c864
 E  c865
 E  c866
 E  c867
 E  c868
 E  c869
 E  c870
 E  c871
 E  c872
 E  c873
 E  c874
 E  c875
 E  c876
 E  c877
 E  c878
 E  c879
 E  c880
 E  c881
 E  c882
 E  c883
 E  c884
 E  c885
 E  c886
 E  c887
 E  c888
 E  c889
 E  c890
 E  c891
 E  c892
 E  c893
 E  c894
 E  c895
 E  c896
 E  c897
 E  c898
 E  c899
 E  c900
 E  c901
 E  c902
 E  c903
 E  c904
 E  c905
 E  c906
 E  c907
 E  c908
 E  c909
 E  c910
 E  c911
 E  c912
 E  c913
 E  c914
 E  c915
 E  c916
 E  c917
 E  c918
 E  c919
 E  c920
 E  c921
 E  c922
 E  c923
 E  c924
 E  c925
 E  c926
 E  c927
 E  c928
 E  c929
 E  c930
 E  c931
 E  c932
 E  c933
 E  c934
 E  c935
 E  c936
 E  c937
 E  c938
 E  c939
 E  c940
 E  c941
 E  c942
 E  c943
 E  c944
 E  c945
 E  c946
 E  c947
 E  c948
 E  c949
 E  c950
 E  c951
 E  c952
 E  c953
 E  c954
 E  c955
 E  c956
 E  c957
 E  c958
 E  c959
 E  c960
 E  c961
 E  c962
 E  c963
 E  c964
 E  c965
 E  c966
 E  c967
 E  c968
 E  c969
 E  c970
 E  c971
 E  c972
 E  c973
 E  c974
 E  c975
 E  c976
 E  c977
 E  c978
 E  c979
 E  c980
 E  c981
 E  c982
 E  c983
 E  c984
 E  c985
 E  c986
 E  c987
 E  c988
 E  c989
 E  c990
 E  c991
 E  c992
 E  c993
 E  c994
 E  c995
 E  c996
 E  c997
 E  c998
 E  c999
 E  c1000
 E  c1001
 E  c1002
 E  c1003
 E  c1004
 E  c1005
 E  c1006
 E  c1007
 E  c1008
 E  c1009
 E  c1010
 E  c1011
 E  c1012
 E  c1013
 E  c1014
 E  c1015
 E  c1016
 E  c1017
 E  c1018
 E  c1019
 E  c1020
 E  c1021
 E  c1022
 E  c1023
 E  c1024
 E  c1025
 E  c1026
 E  c1027
 E  c1028
 E  c1029
 E  c1030
 E  c1031
 E  c1032
 E  c1033
 E  c1034
 E  c1035
 E  c1036
 E  c1037
 E  c1038
 E  c1039
 E  c1040
 E  c1041
 E  c1042
 E  c1043
 E  c1044
 E  c1045
 E  c1046
 E  c1047
 E  c1048
 E  c1049
 E  c1050
 E  c1051
 E  c1052
 E  c1053
 E  c1054
 E  c1055
 E  c1056
 E  c1057
 E  c1058
 E  c1059
 E  c1060
 E  c1061
 E  c1062
 E  c1063
 E  c1064
 E  c1065
 E  c1066
 E  c1067
 E  c1068
 E  c1069
 E  c1070
 E  c1071
 E  c1072
 E  c1073
 E  c1074
 E  c1075
 E  c1076
 E  c1077
 E  c1078
 E  c1079
 E  c1080
 E  c1081
 E  c1082
 E  c1083
 E  c1084
 E  c1085
 E  c1086
 E  c1087
 E  c1088
 E  c1089
 E  c1090
 E  c1091
 E  c1092
 E  c1093
 E  c1094
 E  c1095
 E  c1096
 E  c1097
 E  c1098
 E  c1099
 E  c1100
 E  c1101
 E  c1102
 E  c1103
 E  c1104
 E  c1105
 E  c1106
 E  c1107
 E  c1108
 E  c1109
 E  c1110
 E  c1111
 E  c1112
 E  c1113
 E  c1114
 E  c1115
 E  c1116
 E  c1117
 E  c1118
 E  c1119
 E  c1120
 E  c1121
 E  c1122
 E  c1123
 E  c1124
 E  c1125
 E  c1126
 E  c1127
 E  c1128
 E  c1129
 E  c1130
 E  c1131
 E  c1132
 E  c1133
 E  c1134
 E  c1135
 E  c1136
 E  c1137
 E  c1138
 E  c1139
 E  c1140
 E  c1141
 E  c1142
 E  c1143
 E  c1144
 E  c1145
 E  c1146
 E  c1147
 E  c1148
 E  c1149
 E  c1150
 E  c1151
 E  c1152
 E  c1153
 E  c1154
 E  c1155
 E  c1156
 E  c1157
 E  c1158
 E  c1159
 E  c1160
 E  c1161
 E  c1162
 E  c1163
 E  c1164
 E  c1165
 E  c1166
 E  c1167
 E  c1168
 E  c1169
 E  c1170
 E  c1171
 E  c1172
 E  c1173
 E  c1174
 E  c1175
 E  c1176
 E  c1177
 E  c1178
 E  c1179
 E  c1180
 E  c1181
 E  c1182
 E  c1183
 E  c1184
 E  c1185
 E  c1186
 E  c1187
 E  c1188
 E  c1189
 E  c1190
 E  c1191
 E  c1192
 E  c1193
 E  c1194
 E  c1195
 E  c1196
 E  c1197
 E  c1198
 E  c1199
 E  c1200
 E  c1201
 E  c1202
 E  c1203
 E  c1204
 E  c1205
 E  c1206
 E  c1207
 E  c1208
 E  c1209
 E  c1210
 E  c1211
 E  c1212
 E  c1213
 E  c1214
 E  c1215
 E  c1216
 E  c1217
 E  c1218
 E  c1219
 E  c1220
 E  c1221
 E  c1222
 E  c1223
 E  c1224
 E  c1225
 E  c1226
 E  c1227
 E  c1228
 E  c1229
 E  c1230
 E  c1231
 E  c1232
 E  c1233
 E  c1234
 E  c1235
 E  c1236
 E  c1237
 E  c1238
 E  c1239
 E  c1240
 E  c1241
 E  c1242
 E  c1243
 E  c1244
 E  c1245
 E  c1246
 E  c1247
 E  c1248
 E  c1249
 E  c1250
 E  c1251
 E  c1252
 E  c1253
 E  c1254
 E  c1255
 E  c1256
 E  c1257
 E  c1258
 E  c1259
 E  c1260
 E  c1261
 E  c1262
 E  c1263
 E  c1264
 E  c1265
 E  c1266
 E  c1267
 E  c1268
 E  c1269
 E  c1270
 E  c1271
 E  c1272
 E  c1273
 E  c1274
 E  c1275
 E  c1276
 E  c1277
 E  c1278
 E  c1279
 E  c1280
 E  c1281
 E  c1282
 E  c1283
 E  c1284
 E  c1285
 E  c1286
 E  c1287
 E  c1288
 E  c1289
 E  c1290
 E  c1291
 E  c1292
 E  c1293
 E  c1294
 E  c1295
 E  c1296
 E  c1297
 E  c1298
 E  c1299
 E  c1300
 E  c1301
 E  c1302
 E  c1303
 E  c1304
 E  c1305
 E  c1306
 E  c1307
 E  c1308
 E  c1309
 E  c1310
 E  c1311
 E  c1312
 E  c1313
 E  c1314
 E  c1315
 E  c1316
 E  c1317
 E  c1318
 E  c1319
 E  c1320
 E  c1321
 E  c1322
 E  c1323
 E  c1324
 E  c1325
 E  c1326
 E  c1327
 E  c1328
 E  c1329
 E  c1330
 E  c1331
 E  c1332
 E  c1333
 E  c1334
 E  c1335
 E  c1336
 E  c1337
 E  c1338
 E  c1339
 E  c1340
 E  c1341
 E  c1342
 E  c1343
 E  c1344
 E  c1345
 E  c1346
 E  c1347
 E  c1348
 E  c1349
 E  c1350
 E  c1351
 E  c1352
 E  c1353
 E  c1354
 E  c1355
 E  c1356
 E  c1357
 E  c1358
 E  c1359
 E  c1360
 E  c1361
 E  c1362
 E  c1363
 E  c1364
 E  c1365
 E  c1366
 E  c1367
 E  c1368
 E  c1369
 E  c1370
 E  c1371
 E  c1372
 E  c1373
 E  c1374
 E  c1375
 E  c1376
 E  c1377
 E  c1378
 E  c1379
 E  c1380
 E  c1381
 E  c1382
 E  c1383
 E  c1384
 E  c1385
 E  c1386
 E  c1387
 E  c1388
 E  c1389
 E  c1390
 E  c1391
 E  c1392
 E  c1393
 E  c1394
 E  c1395
 E  c1396
 E  c1397
 E  c1398
 E  c1399
 E  c1400
 E  c1401
 E  c1402
 E  c1403
 E  c1404
 E  c1405
 E  c1406
 E  c1407
 E  c1408
 E  c1409
 E  c1410
 E  c1411
 E  c1412
 E  c1413
 E  c1414
 E  c1415
 E  c1416
 E  c1417
 E  c1418
 E  c1419
 E  c1420
 E  c1421
 E  c1422
 E  c1423
 E  c1424
 E  c1425
 E  c1426
 E  c1427
 E  c1428
 E  c1429
 E  c1430
 E  c1431
 E  c1432
 E  c1433
 E  c1434
 E  c1435
 E  c1436
 E  c1437
 E  c1438
 E  c1439
 E  c1440
 E  c1441
 E  c1442
 E  c1443
 E  c1444
 E  c1445
 E  c1446
 E  c1447
 E  c1448
 E  c1449
 E  c1450
 E  c1451
 E  c1452
 E  c1453
 E  c1454
 E  c1455
 E  c1456
 E  c1457
 E  c1458
 E  c1459
 E  c1460
 E  c1461
 E  c1462
 E  c1463
 E  c1464
 E  c1465
 E  c1466
 E  c1467
 E  c1468
 E  c1469
 E  c1470
 E  c1471
 E  c1472
 E  c1473
 E  c1474
 E  c1475
 E  c1476
 E  c1477
 E  c1478
 E  c1479
 E  c1480
 E  c1481
 E  c1482
 E  c1483
 E  c1484
 E  c1485
 E  c1486
 E  c1487
 E  c1488
 E  c1489
 E  c1490
 E  c1491
 E  c1492
 E  c1493
 E  c1494
 E  c1495
 E  c1496
 E  c1497
 E  c1498
 E  c1499
 E  c1500
 E  c1501
 E  c1502
 E  c1503
 E  c1504
 E  c1505
 E  c1506
 E  c1507
 E  c1508
 E  c1509
 E  c1510
 E  c1511
 E  c1512
 E  c1513
 E  c1514
 E  c1515
 E  c1516
 E  c1517
 E  c1518
 E  c1519
 E  c1520
 E  c1521
 E  c1522
 E  c1523
 E  c1524
 E  c1525
 E  c1526
 E  c1527
 E  c1528
 E  c1529
 E  c1530
 E  c1531
 E  c1532
 E  c1533
 E  c1534
 E  c1535
 E  c1536
 E  c1537
 E  c1538
 E  c1539
 E  c1540
 E  c1541
 E  c1542
 E  c1543
 E  c1544
 E  c1545
 E  c1546
 E  c1547
 E  c1548
 E  c1549
 E  c1550
 E  c1551
 E  c1552
 E  c1553
 E  c1554
 E  c1555
 E  c1556
 E  c1557
 E  c1558
 E  c1559
 E  c1560
 E  c1561
 E  c1562
 E  c1563
 E  c1564
 E  c1565
 E  c1566
 E  c1567
 E  c1568
 E  c1569
 E  c1570
 E  c1571
 E  c1572
 E  c1573
 E  c1574
 E  c1575
 E  c1576
 E  c1577
 E  c1578
 E  c1579
 E  c1580
 E  c1581
 E  c1582
 E  c1583
 E  c1584
 E  c1585
 E  c1586
 E  c1587
 E  c1588
 E  c1589
 E  c1590
 E  c1591
 E  c1592
 E  c1593
 E  c1594
 E  c1595
 E  c1596
 E  c1597
 E  c1598
 E  c1599
 E  c1600
 E  c1601
 E  c1602
 E  c1603
 E  c1604
 E  c1605
 E  c1606
 E  c1607
 E  c1608
 E  c1609
 E  c1610
 E  c1611
 E  c1612
 E  c1613
 E  c1614
 E  c1615
 E  c1616
 E  c1617
 E  c1618
 E  c1619
 E  c1620
 E  c1621
 E  c1622
 E  c1623
 E  c1624
 E  c1625
 E  c1626
 E  c1627
 E  c1628
 E  c1629
 E  c1630
 E  c1631
 E  c1632
 E  c1633
 E  c1634
 E  c1635
 E  c1636
 E  c1637
 E  c1638
 E  c1639
 E  c1640
 E  c1641
 E  c1642
 E  c1643
 E  c1644
 E  c1645
 E  c1646
 E  c1647
 E  c1648
 E  c1649
 E  c1650
 E  c1651
 E  c1652
 E  c1653
 E  c1654
 E  c1655
 E  c1656
 E  c1657
 E  c1658
 E  c1659
 E  c1660
 E  c1661
 E  c1662
 E  c1663
 E  c1664
 E  c1665
 E  c1666
 E  c1667
 E  c1668
 E  c1669
 E  c1670
 E  c1671
 E  c1672
 E  c1673
 E  c1674
 E  c1675
 E  c1676
 E  c1677
 E  c1678
 E  c1679
 E  c1680
 E  c1681
 E  c1682
 E  c1683
 E  c1684
 E  c1685
 E  c1686
 E  c1687
 E  c1688
 E  c1689
 E  c1690
 E  c1691
 E  c1692
 E  c1693
 E  c1694
 E  c1695
 E  c1696
 E  c1697
 E  c1698
 E  c1699
 E  c1700
 E  c1701
 E  c1702
 E  c1703
 E  c1704
 E  c1705
 E  c1706
 E  c1707
 E  c1708
 E  c1709
 E  c1710
 E  c1711
 E  c1712
 E  c1713
 E  c1714
 E  c1715
 E  c1716
 E  c1717
 E  c1718
 E  c1719
 E  c1720
 E  c1721
 E  c1722
 E  c1723
 E  c1724
 E  c1725
 E  c1726
 E  c1727
 E  c1728
 E  c1729
 E  c1730
 E  c1731
 E  c1732
 E  c1733
 E  c1734
 E  c1735
 E  c1736
 E  c1737
 E  c1738
 E  c1739
 E  c1740
 E  c1741
 E  c1742
 E  c1743
 E  c1744
 E  c1745
 E  c1746
 E  c1747
 E  c1748
 E  c1749
 E  c1750
 E  c1751
 E  c1752
 E  c1753
 E  c1754
 E  c1755
 E  c1756
 E  c1757
 E  c1758
 E  c1759
 E  c1760
 E  c1761
 E  c1762
 E  c1763
 E  c1764
 E  c1765
 E  c1766
 E  c1767
 E  c1768
 E  c1769
 E  c1770
 E  c1771
 E  c1772
 E  c1773
 E  c1774
 E  c1775
 E  c1776
 E  c1777
 E  c1778
 E  c1779
 E  c1780
 E  c1781
 E  c1782
 E  c1783
 E  c1784
 E  c1785
 E  c1786
 E  c1787
 E  c1788
 E  c1789
 E  c1790
 E  c1791
 E  c1792
 E  c1793
 E  c1794
 E  c1795
 E  c1796
 E  c1797
 E  c1798
 E  c1799
 E  c1800
 E  c1801
 E  c1802
 E  c1803
 E  c1804
 E  c1805
 E  c1806
 E  c1807
 E  c1808
 E  c1809
 E  c1810
 E  c1811
 E  c1812
 E  c1813
 E  c1814
 E  c1815
 E  c1816
 E  c1817
 E  c1818
 E  c1819
 E  c1820
 E  c1821
 E  c1822
 E  c1823
 E  c1824
 E  c1825
 E  c1826
 E  c1827
 E  c1828
 E  c1829
 E  c1830
 E  c1831
 E  c1832
 E  c1833
 E  c1834
 E  c1835
 E  c1836
 E  c1837
 E  c1838
 E  c1839
 E  c1840
 E  c1841
 E  c1842
 E  c1843
 E  c1844
 E  c1845
 E  c1846
 E  c1847
 E  c1848
 E  c1849
 E  c1850
 E  c1851
 E  c1852
 E  c1853
 E  c1854
 E  c1855
 E  c1856
 E  c1857
 E  c1858
 E  c1859
 E  c1860
 E  c1861
 E  c1862
 E  c1863
 E  c1864
 E  c1865
 E  c1866
 E  c1867
 E  c1868
 E  c1869
 E  c1870
 E  c1871
 E  c1872
 E  c1873
 E  c1874
 E  c1875
 E  c1876
 E  c1877
 E  c1878
 E  c1879
 E  c1880
 E  c1881
 E  c1882
 E  c1883
 E  c1884
 E  c1885
 E  c1886
 E  c1887
 E  c1888
 E  c1889
 E  c1890
 E  c1891
 E  c1892
 E  c1893
 E  c1894
 E  c1895
 E  c1896
 E  c1897
 E  c1898
 E  c1899
 E  c1900
 E  c1901
 E  c1902
 E  c1903
 E  c1904
 E  c1905
 E  c1906
 E  c1907
 E  c1908
 E  c1909
 E  c1910
 E  c1911
 E  c1912
 E  c1913
 E  c1914
 E  c1915
 E  c1916
 E  c1917
 E  c1918
 E  c1919
 E  c1920
 E  c1921
 E  c1922
 E  c1923
 E  c1924
 E  c1925
 E  c1926
 E  c1927
 E  c1928
 E  c1929
 E  c1930
 E  c1931
 E  c1932
 E  c1933
 E  c1934
 E  c1935
 E  c1936
 E  c1937
 E  c1938
 E  c1939
 E  c1940
 E  c1941
 E  c1942
 E  c1943
 E  c1944
 E  c1945
 E  c1946
 E  c1947
 E  c1948
 E  c1949
 E  c1950
 E  c1951
 E  c1952
 E  c1953
 E  c1954
 E  c1955
 E  c1956
 E  c1957
 E  c1958
 E  c1959
 E  c1960
 E  c1961
 E  c1962
 E  c1963
 E  c1964
 E  c1965
 E  c1966
 E  c1967
 E  c1968
 E  c1969
 E  c1970
 E  c1971
 E  c1972
 E  c1973
 E  c1974
 E  c1975
 E  c1976
 E  c1977
 E  c1978
 E  c1979
 E  c1980
 E  c1981
 E  c1982
 E  c1983
 E  c1984
 E  c1985
 E  c1986
 E  c1987
 E  c1988
 E  c1989
 E  c1990
 E  c1991
 E  c1992
 E  c1993
 E  c1994
 E  c1995
 E  c1996
 E  c1997
 E  c1998
 E  c1999
 E  c2000
 E  c2001
 E  c2002
 E  c2003
 E  c2004
 E  c2005
 E  c2006
 E  c2007
 E  c2008
 E  c2009
 E  c2010
 E  c2011
 E  c2012
 E  c2013
 E  c2014
 E  c2015
 E  c2016
 E  c2017
 E  c2018
 E  c2019
 E  c2020
 E  c2021
 E  c2022
 E  c2023
 E  c2024
 E  c2025
 E  c2026
 E  c2027
 E  c2028
 E  c2029
 E  c2030
 E  c2031
 E  c2032
 E  c2033
 E  c2034
 E  c2035
 E  c2036
 E  c2037
 E  c2038
 E  c2039
 E  c2040
 E  c2041
 E  c2042
 E  c2043
 E  c2044
 E  c2045
 E  c2046
 E  c2047
 E  c2048
 E  c2049
 E  c2050
 E  c2051
 E  c2052
 E  c2053
 E  c2054
 E  c2055
 E  c2056
 E  c2057
 E  c2058
 E  c2059
 E  c2060
 E  c2061
 E  c2062
 E  c2063
 E  c2064
 E  c2065
 E  c2066
 E  c2067
 E  c2068
 E  c2069
 E  c2070
 E  c2071
 E  c2072
 E  c2073
 E  c2074
 E  c2075
 E  c2076
 E  c2077
 E  c2078
 E  c2079
 E  c2080
 E  c2081
 E  c2082
 E  c2083
 E  c2084
 E  c2085
 E  c2086
 E  c2087
 E  c2088
 E  c2089
 E  c2090
 E  c2091
 E  c2092
 E  c2093
 E  c2094
 E  c2095
 E  c2096
 E  c2097
 E  c2098
 E  c2099
 E  c2100
 E  c2101
 E  c2102
 E  c2103
 E  c2104
 E  c2105
 E  c2106
 E  c2107
 E  c2108
 E  c2109
 E  c2110
 E  c2111
 E  c2112
 E  c2113
 E  c2114
 E  c2115
 E  c2116
 E  c2117
 E  c2118
 E  c2119
 E  c2120
 E  c2121
 E  c2122
 E  c2123
 E  c2124
 E  c2125
 E  c2126
 E  c2127
 E  c2128
 E  c2129
 E  c2130
 E  c2131
 E  c2132
 E  c2133
 E  c2134
 E  c2135
 E  c2136
 E  c2137
 E  c2138
 E  c2139
 E  c2140
 E  c2141
 E  c2142
 E  c2143
 E  c2144
 E  c2145
 E  c2146
 E  c2147
 E  c2148
 E  c2149
 E  c2150
 E  c2151
 E  c2152
 E  c2153
 E  c2154
 E  c2155
 E  c2156
 E  c2157
 E  c2158
 E  c2159
 E  c2160
 E  c2161
 E  c2162
 E  c2163
 E  c2164
 E  c2165
 E  c2166
 E  c2167
 E  c2168
 E  c2169
 E  c2170
 E  c2171
 E  c2172
 E  c2173
 E  c2174
 E  c2175
 E  c2176
 E  c2177
 E  c2178
 E  c2179
 E  c2180
 E  c2181
 E  c2182
 E  c2183
 E  c2184
 E  c2185
 E  c2186
 E  c2187
 E  c2188
 E  c2189
 E  c2190
 E  c2191
 E  c2192
 E  c2193
 E  c2194
 E  c2195
 E  c2196
 E  c2197
 E  c2198
 E  c2199
 E  c2200
 E  c2201
 E  c2202
 E  c2203
 E  c2204
 E  c2205
 E  c2206
 E  c2207
 E  c2208
 E  c2209
 E  c2210
 E  c2211
 E  c2212
 E  c2213
 E  c2214
 E  c2215
 E  c2216
 E  c2217
 E  c2218
 E  c2219
 E  c2220
 E  c2221
 E  c2222
 E  c2223
 E  c2224
 E  c2225
 E  c2226
 E  c2227
 E  c2228
 E  c2229
 E  c2230
 E  c2231
 E  c2232
 E  c2233
 E  c2234
 E  c2235
 E  c2236
 E  c2237
 E  c2238
 E  c2239
 E  c2240
 E  c2241
 E  c2242
 E  c2243
 E  c2244
 E  c2245
 E  c2246
 E  c2247
 E  c2248
 E  c2249
 E  c2250
 E  c2251
 E  c2252
 E  c2253
 E  c2254
 E  c2255
 E  c2256
 E  c2257
 E  c2258
 E  c2259
 E  c2260
 E  c2261
 E  c2262
 E  c2263
 E  c2264
 E  c2265
 E  c2266
 E  c2267
 E  c2268
 E  c2269
 E  c2270
 E  c2271
 E  c2272
 E  c2273
 E  c2274
 E  c2275
 E  c2276
 E  c2277
 E  c2278
 E  c2279
 E  c2280
 E  c2281
 E  c2282
 E  c2283
 E  c2284
 E  c2285
 E  c2286
 E  c2287
 E  c2288
 E  c2289
 E  c2290
 E  c2291
 E  c2292
 E  c2293
 E  c2294
 E  c2295
 E  c2296
 E  c2297
 E  c2298
 E  c2299
 E  c2300
 E  c2301
 E  c2302
 E  c2303
 E  c2304
 E  c2305
 E  c2306
 E  c2307
 E  c2308
 E  c2309
 E  c2310
 E  c2311
 E  c2312
 E  c2313
 E  c2314
 E  c2315
 E  c2316
 E  c2317
 E  c2318
 E  c2319
 E  c2320
 E  c2321
 E  c2322
 E  c2323
 E  c2324
 E  c2325
 E  c2326
 E  c2327
 E  c2328
 E  c2329
 E  c2330
 E  c2331
 E  c2332
 E  c2333
 E  c2334
 E  c2335
 E  c2336
 E  c2337
 E  c2338
 E  c2339
 E  c2340
 E  c2341
 E  c2342
 E  c2343
 E  c2344
 E  c2345
 E  c2346
 E  c2347
 E  c2348
 E  c2349
 E  c2350
 E  c2351
 E  c2352
 E  c2353
 E  c2354
 E  c2355
 E  c2356
 E  c2357
 E  c2358
 E  c2359
 E  c2360
 E  c2361
 E  c2362
 E  c2363
 E  c2364
 E  c2365
 E  c2366
 E  c2367
 E  c2368
 E  c2369
 E  c2370
 E  c2371
 E  c2372
 E  c2373
 E  c2374
 E  c2375
 E  c2376
 E  c2377
 E  c2378
 E  c2379
 E  c2380
 E  c2381
 E  c2382
 E  c2383
 E  c2384
 E  c2385
 E  c2386
 E  c2387
 E  c2388
 E  c2389
 E  c2390
 E  c2391
 E  c2392
 E  c2393
 E  c2394
 E  c2395
 E  c2396
 E  c2397
 E  c2398
 E  c2399
 E  c2400
 E  c2401
 E  c2402
 E  c2403
 E  c2404
 E  c2405
 E  c2406
 E  c2407
 E  c2408
 E  c2409
 E  c2410
 E  c2411
 E  c2412
 E  c2413
 E  c2414
 E  c2415
 E  c2416
 E  c2417
 E  c2418
 E  c2419
 E  c2420
 E  c2421
 E  c2422
 E  c2423
 E  c2424
 E  c2425
 E  c2426
 E  c2427
 E  c2428
 E  c2429
 E  c2430
 E  c2431
 E  c2432
 E  c2433
 E  c2434
 E  c2435
 E  c2436
 E  c2437
 E  c2438
 E  c2439
 E  c2440
 E  c2441
 E  c2442
 E  c2443
 E  c2444
 E  c2445
 E  c2446
 E  c2447
 E  c2448
 E  c2449
 E  c2450
 E  c2451
 E  c2452
 E  c2453
 E  c2454
 E  c2455
 E  c2456
 E  c2457
 E  c2458
 E  c2459
 E  c2460
 E  c2461
 E  c2462
 E  c2463
 E  c2464
 E  c2465
 E  c2466
 E  c2467
 E  c2468
 E  c2469
 E  c2470
 E  c2471
 E  c2472
 E  c2473
 E  c2474
 E  c2475
 E  c2476
 E  c2477
 E  c2478
 E  c2479
 E  c2480
 E  c2481
 E  c2482
 E  c2483
 E  c2484
 E  c2485
 E  c2486
 E  c2487
 E  c2488
 E  c2489
 E  c2490
 E  c2491
 E  c2492
 E  c2493
 E  c2494
 E  c2495
 E  c2496
 E  c2497
 E  c2498
 E  c2499
 E  c2500
 E  c2501
 E  c2502
 E  c2503
 E  c2504
 E  c2505
 E  c2506
 E  c2507
 E  c2508
 E  c2509
 E  c2510
 E  c2511
 E  c2512
 E  c2513
 E  c2514
 E  c2515
 E  c2516
 E  c2517
 E  c2518
 E  c2519
 E  c2520
 E  c2521
 E  c2522
 E  c2523
 E  c2524
 E  c2525
 E  c2526
 E  c2527
 E  c2528
 E  c2529
 E  c2530
 E  c2531
 E  c2532
 E  c2533
 E  c2534
 E  c2535
 E  c2536
 E  c2537
 E  c2538
 E  c2539
 E  c2540
 E  c2541
 E  c2542
 E  c2543
 E  c2544
 E  c2545
 E  c2546
 E  c2547
 E  c2548
 E  c2549
 E  c2550
 E  c2551
 E  c2552
 E  c2553
 E  c2554
 E  c2555
 E  c2556
 E  c2557
 E  c2558
 E  c2559
 E  c2560
 E  c2561
 E  c2562
 E  c2563
 E  c2564
 E  c2565
 E  c2566
 E  c2567
 E  c2568
 E  c2569
 E  c2570
 E  c2571
 E  c2572
 E  c2573
 E  c2574
 E  c2575
 E  c2576
 E  c2577
 E  c2578
 E  c2579
 E  c2580
 E  c2581
 E  c2582
 E  c2583
 E  c2584
 E  c2585
 E  c2586
 E  c2587
 E  c2588
 E  c2589
 E  c2590
 E  c2591
 E  c2592
 E  c2593
 E  c2594
 E  c2595
 E  c2596
 E  c2597
 E  c2598
 E  c2599
 E  c2600
 E  c2601
 E  c2602
 E  c2603
 E  c2604
 E  c2605
 E  c2606
 E  c2607
 E  c2608
 E  c2609
 E  c2610
 E  c2611
 E  c2612
 E  c2613
 E  c2614
 E  c2615
 E  c2616
 E  c2617
 E  c2618
 E  c2619
 E  c2620
 E  c2621
 E  c2622
 E  c2623
 E  c2624
 E  c2625
 E  c2626
 E  c2627
 E  c2628
 E  c2629
 E  c2630
 E  c2631
 E  c2632
 E  c2633
 E  c2634
 E  c2635
 E  c2636
 E  c2637
 E  c2638
 E  c2639
 E  c2640
 E  c2641
 E  c2642
 E  c2643
 E  c2644
 E  c2645
 E  c2646
 E  c2647
 E  c2648
 E  c2649
 E  c2650
 E  c2651
 E  c2652
 E  c2653
 E  c2654
 E  c2655
 E  c2656
 E  c2657
 E  c2658
 E  c2659
 E  c2660
 E  c2661
 E  c2662
 E  c2663
 E  c2664
 E  c2665
 E  c2666
 E  c2667
 E  c2668
 E  c2669
 E  c2670
 E  c2671
 E  c2672
 E  c2673
 E  c2674
 E  c2675
 E  c2676
 E  c2677
 E  c2678
 E  c2679
 E  c2680
 E  c2681
 E  c2682
 E  c2683
 E  c2684
 E  c2685
 E  c2686
 E  c2687
 E  c2688
 E  c2689
 E  c2690
 E  c2691
 E  c2692
 E  c2693
 E  c2694
 E  c2695
 E  c2696
 E  c2697
 E  c2698
 E  c2699
 E  c2700
 E  c2701
 E  c2702
 E  c2703
 E  c2704
 E  c2705
 E  c2706
 E  c2707
 E  c2708
 E  c2709
 E  c2710
 E  c2711
 E  c2712
 E  c2713
 E  c2714
 E  c2715
 E  c2716
 E  c2717
 E  c2718
 E  c2719
 E  c2720
 E  c2721
 E  c2722
 E  c2723
 E  c2724
 E  c2725
 E  c2726
 E  c2727
 E  c2728
 E  c2729
 E  c2730
 E  c2731
 E  c2732
 E  c2733
 E  c2734
 E  c2735
 E  c2736
 E  c2737
 E  c2738
 E  c2739
 E  c2740
 E  c2741
 E  c2742
 E  c2743
 E  c2744
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c288_1    1
    x[1]      c1005     1
    x[1]      OBJ       1
    x[2]      c208_1    -6518
    x[2]      c249_1    -6518
    x[2]      c1        1
    x[3]      c210_1    -6518
    x[3]      c251_1    -6518
    x[3]      c2        1
    x[4]      c213_1    -6518
    x[4]      c254_1    -6518
    x[4]      c3        1
    x[5]      c217_1    -6518
    x[5]      c258_1    -6518
    x[5]      c4        1
    x[6]      c222_1    -6518
    x[6]      c263_1    -6518
    x[6]      c5        1
    x[7]      c239_1    -6518
    x[7]      c280_1    -6518
    x[7]      c6        1
    x[8]      c206_1    -6518
    x[8]      c247_1    -6518
    x[8]      c7        1
    x[9]      c207_1    -6518
    x[9]      c248_1    -6518
    x[9]      c8        1
    x[10]     c209_1    -6518
    x[10]     c250_1    -6518
    x[10]     c9        1
    x[11]     c212_1    -6518
    x[11]     c253_1    -6518
    x[11]     c10       1
    x[12]     c216_1    -6518
    x[12]     c257_1    -6518
    x[12]     c11       1
    x[13]     c221_1    -6518
    x[13]     c262_1    -6518
    x[13]     c12       1
    x[14]     c227_1    -6518
    x[14]     c268_1    -6518
    x[14]     c13       1
    x[15]     c231_1    -6518
    x[15]     c272_1    -6518
    x[15]     c14       1
    x[16]     c238_1    -6518
    x[16]     c279_1    -6518
    x[16]     c15       1
    x[17]     c206_1    -6518
    x[17]     c247_1    -6518
    x[17]     c16       1
    x[17]     c17       1
    x[18]     c207_1    -6518
    x[18]     c248_1    -6518
    x[18]     c16       1
    x[18]     c18       1
    x[19]     c209_1    -6518
    x[19]     c250_1    -6518
    x[19]     c16       1
    x[19]     c19       1
    x[20]     c212_1    -6518
    x[20]     c253_1    -6518
    x[20]     c16       1
    x[20]     c20       1
    x[21]     c216_1    -6518
    x[21]     c257_1    -6518
    x[21]     c16       1
    x[21]     c21       1
    x[22]     c221_1    -6518
    x[22]     c262_1    -6518
    x[22]     c16       1
    x[22]     c22       1
    x[23]     c227_1    -6518
    x[23]     c268_1    -6518
    x[23]     c16       1
    x[23]     c23       1
    x[24]     c231_1    -6518
    x[24]     c272_1    -6518
    x[24]     c16       1
    x[24]     c24       1
    x[25]     c238_1    -6518
    x[25]     c279_1    -6518
    x[25]     c16       1
    x[25]     c25       1
    x[26]     c3_2      1
    x[26]     c4_2      1
    x[26]     c5_2      1
    x[26]     c6_2      1
    x[26]     c208_1    -6518
    x[26]     c249_1    -6518
    x[26]     c17       1
    x[26]     c18       -1
    x[27]     c3_2      1
    x[27]     c210_1    -6518
    x[27]     c251_1    -6518
    x[27]     c17       1
    x[27]     c19       -1
    x[28]     c213_1    -6518
    x[28]     c254_1    -6518
    x[28]     c17       1
    x[28]     c20       -1
    x[29]     c4_2      1
    x[29]     c217_1    -6518
    x[29]     c258_1    -6518
    x[29]     c17       1
    x[29]     c21       -1
    x[30]     c5_2      1
    x[30]     c222_1    -6518
    x[30]     c263_1    -6518
    x[30]     c17       1
    x[30]     c22       -1
    x[31]     c6_2      1
    x[31]     c239_1    -6518
    x[31]     c280_1    -6518
    x[31]     c17       1
    x[31]     c25       -1
    x[32]     c211_1    -6518
    x[32]     c252_1    -6518
    x[32]     c18       1
    x[32]     c19       -1
    x[33]     c214_1    -6518
    x[33]     c255_1    -6518
    x[33]     c18       1
    x[33]     c20       -1
    x[34]     c218_1    -6518
    x[34]     c259_1    -6518
    x[34]     c18       1
    x[34]     c21       -1
    x[35]     c223_1    -6518
    x[35]     c264_1    -6518
    x[35]     c18       1
    x[35]     c22       -1
    x[36]     c232_1    -6518
    x[36]     c273_1    -6518
    x[36]     c18       1
    x[36]     c24       -1
    x[37]     c240_1    -6518
    x[37]     c281_1    -6518
    x[37]     c18       1
    x[37]     c25       -1
    x[38]     c211_1    -6518
    x[38]     c252_1    -6518
    x[38]     c18       -1
    x[38]     c19       1
    x[39]     c214_1    -6518
    x[39]     c255_1    -6518
    x[39]     c18       -1
    x[39]     c20       1
    x[40]     c218_1    -6518
    x[40]     c259_1    -6518
    x[40]     c18       -1
    x[40]     c21       1
    x[41]     c223_1    -6518
    x[41]     c264_1    -6518
    x[41]     c18       -1
    x[41]     c22       1
    x[42]     c232_1    -6518
    x[42]     c273_1    -6518
    x[42]     c18       -1
    x[42]     c24       1
    x[43]     c240_1    -6518
    x[43]     c281_1    -6518
    x[43]     c18       -1
    x[43]     c25       1
    x[44]     c215_1    -6518
    x[44]     c256_1    -6518
    x[44]     c19       1
    x[44]     c20       -1
    x[45]     c219_1    -6518
    x[45]     c260_1    -6518
    x[45]     c19       1
    x[45]     c21       -1
    x[46]     c224_1    -6518
    x[46]     c265_1    -6518
    x[46]     c19       1
    x[46]     c22       -1
    x[47]     c233_1    -6518
    x[47]     c274_1    -6518
    x[47]     c19       1
    x[47]     c24       -1
    x[48]     c241_1    -6518
    x[48]     c282_1    -6518
    x[48]     c19       1
    x[48]     c25       -1
    x[49]     c215_1    -6518
    x[49]     c256_1    -6518
    x[49]     c19       -1
    x[49]     c20       1
    x[50]     c219_1    -6518
    x[50]     c260_1    -6518
    x[50]     c19       -1
    x[50]     c21       1
    x[51]     c224_1    -6518
    x[51]     c265_1    -6518
    x[51]     c19       -1
    x[51]     c22       1
    x[52]     c233_1    -6518
    x[52]     c274_1    -6518
    x[52]     c19       -1
    x[52]     c24       1
    x[53]     c241_1    -6518
    x[53]     c282_1    -6518
    x[53]     c19       -1
    x[53]     c25       1
    x[54]     c220_1    -6518
    x[54]     c261_1    -6518
    x[54]     c20       1
    x[54]     c21       -1
    x[55]     c225_1    -6518
    x[55]     c266_1    -6518
    x[55]     c20       1
    x[55]     c22       -1
    x[56]     c228_1    -6518
    x[56]     c269_1    -6518
    x[56]     c20       1
    x[56]     c23       -1
    x[57]     c234_1    -6518
    x[57]     c275_1    -6518
    x[57]     c20       1
    x[57]     c24       -1
    x[58]     c242_1    -6518
    x[58]     c283_1    -6518
    x[58]     c20       1
    x[58]     c25       -1
    x[59]     c220_1    -6518
    x[59]     c261_1    -6518
    x[59]     c20       -1
    x[59]     c21       1
    x[60]     c225_1    -6518
    x[60]     c266_1    -6518
    x[60]     c20       -1
    x[60]     c22       1
    x[61]     c228_1    -6518
    x[61]     c269_1    -6518
    x[61]     c20       -1
    x[61]     c23       1
    x[62]     c234_1    -6518
    x[62]     c275_1    -6518
    x[62]     c20       -1
    x[62]     c24       1
    x[63]     c242_1    -6518
    x[63]     c283_1    -6518
    x[63]     c20       -1
    x[63]     c25       1
    x[64]     c226_1    -6518
    x[64]     c267_1    -6518
    x[64]     c21       1
    x[64]     c22       -1
    x[65]     c229_1    -6518
    x[65]     c270_1    -6518
    x[65]     c21       1
    x[65]     c23       -1
    x[66]     c235_1    -6518
    x[66]     c276_1    -6518
    x[66]     c21       1
    x[66]     c24       -1
    x[67]     c243_1    -6518
    x[67]     c284_1    -6518
    x[67]     c21       1
    x[67]     c25       -1
    x[68]     c226_1    -6518
    x[68]     c267_1    -6518
    x[68]     c21       -1
    x[68]     c22       1
    x[69]     c229_1    -6518
    x[69]     c270_1    -6518
    x[69]     c21       -1
    x[69]     c23       1
    x[70]     c235_1    -6518
    x[70]     c276_1    -6518
    x[70]     c21       -1
    x[70]     c24       1
    x[71]     c243_1    -6518
    x[71]     c284_1    -6518
    x[71]     c21       -1
    x[71]     c25       1
    x[72]     c230_1    -6518
    x[72]     c271_1    -6518
    x[72]     c22       1
    x[72]     c23       -1
    x[73]     c236_1    -6518
    x[73]     c277_1    -6518
    x[73]     c22       1
    x[73]     c24       -1
    x[74]     c244_1    -6518
    x[74]     c285_1    -6518
    x[74]     c22       1
    x[74]     c25       -1
    x[75]     c230_1    -6518
    x[75]     c271_1    -6518
    x[75]     c22       -1
    x[75]     c23       1
    x[76]     c236_1    -6518
    x[76]     c277_1    -6518
    x[76]     c22       -1
    x[76]     c24       1
    x[77]     c244_1    -6518
    x[77]     c285_1    -6518
    x[77]     c22       -1
    x[77]     c25       1
    x[78]     c237_1    -6518
    x[78]     c278_1    -6518
    x[78]     c23       1
    x[78]     c24       -1
    x[79]     c245_1    -6518
    x[79]     c286_1    -6518
    x[79]     c23       1
    x[79]     c25       -1
    x[80]     c237_1    -6518
    x[80]     c278_1    -6518
    x[80]     c23       -1
    x[80]     c24       1
    x[81]     c245_1    -6518
    x[81]     c286_1    -6518
    x[81]     c23       -1
    x[81]     c25       1
    x[82]     c246_1    -6518
    x[82]     c287_1    -6518
    x[82]     c24       1
    x[82]     c25       -1
    x[83]     c246_1    -6518
    x[83]     c287_1    -6518
    x[83]     c24       -1
    x[83]     c25       1
    x[84]     c238_1    -454
    x[84]     c279_1    -454
    x[84]     c26       1
    x[85]     c239_1    -454
    x[85]     c280_1    -454
    x[85]     c27       1
    x[86]     c240_1    -454
    x[86]     c281_1    -454
    x[86]     c28       1
    x[87]     c241_1    -454
    x[87]     c282_1    -454
    x[87]     c29       1
    x[88]     c242_1    -454
    x[88]     c283_1    -454
    x[88]     c30       1
    x[89]     c243_1    -454
    x[89]     c284_1    -454
    x[89]     c31       1
    x[90]     c244_1    -454
    x[90]     c285_1    -454
    x[90]     c32       1
    x[91]     c245_1    -454
    x[91]     c286_1    -454
    x[91]     c33       1
    x[92]     c246_1    -454
    x[92]     c287_1    -454
    x[92]     c34       1
    x[93]     c231_1    -454
    x[93]     c272_1    -454
    x[93]     c35       1
    x[94]     c232_1    -454
    x[94]     c273_1    -454
    x[94]     c36       1
    x[95]     c233_1    -454
    x[95]     c274_1    -454
    x[95]     c37       1
    x[96]     c234_1    -454
    x[96]     c275_1    -454
    x[96]     c38       1
    x[97]     c235_1    -454
    x[97]     c276_1    -454
    x[97]     c39       1
    x[98]     c236_1    -454
    x[98]     c277_1    -454
    x[98]     c40       1
    x[99]     c237_1    -454
    x[99]     c278_1    -454
    x[99]     c41       1
    x[100]    c238_1    -454
    x[100]    c279_1    -454
    x[100]    c42       1
    x[100]    c44       1
    x[101]    c239_1    -454
    x[101]    c280_1    -454
    x[101]    c42       1
    x[101]    c45       1
    x[102]    c240_1    -454
    x[102]    c281_1    -454
    x[102]    c42       1
    x[102]    c46       1
    x[103]    c241_1    -454
    x[103]    c282_1    -454
    x[103]    c42       1
    x[103]    c47       1
    x[104]    c242_1    -454
    x[104]    c283_1    -454
    x[104]    c42       1
    x[104]    c48       1
    x[105]    c243_1    -454
    x[105]    c284_1    -454
    x[105]    c42       1
    x[105]    c49       1
    x[106]    c244_1    -454
    x[106]    c285_1    -454
    x[106]    c42       1
    x[106]    c50       1
    x[107]    c245_1    -454
    x[107]    c286_1    -454
    x[107]    c42       1
    x[107]    c51       1
    x[108]    c246_1    -454
    x[108]    c287_1    -454
    x[108]    c42       1
    x[108]    c43       1
    x[109]    c36_2     1
    x[109]    c37_2     1
    x[109]    c38_2     1
    x[109]    c39_2     1
    x[109]    c40_2     1
    x[109]    c231_1    -454
    x[109]    c272_1    -454
    x[109]    c43       1
    x[109]    c44       -1
    x[110]    c36_2     1
    x[110]    c232_1    -454
    x[110]    c273_1    -454
    x[110]    c43       1
    x[110]    c46       -1
    x[111]    c37_2     1
    x[111]    c233_1    -454
    x[111]    c274_1    -454
    x[111]    c43       1
    x[111]    c47       -1
    x[112]    c38_2     1
    x[112]    c234_1    -454
    x[112]    c275_1    -454
    x[112]    c43       1
    x[112]    c48       -1
    x[113]    c235_1    -454
    x[113]    c276_1    -454
    x[113]    c43       1
    x[113]    c49       -1
    x[114]    c39_2     1
    x[114]    c236_1    -454
    x[114]    c277_1    -454
    x[114]    c43       1
    x[114]    c50       -1
    x[115]    c40_2     1
    x[115]    c237_1    -454
    x[115]    c278_1    -454
    x[115]    c43       1
    x[115]    c51       -1
    x[116]    c206_1    -454
    x[116]    c247_1    -454
    x[116]    c44       1
    x[116]    c45       -1
    x[117]    c207_1    -454
    x[117]    c248_1    -454
    x[117]    c44       1
    x[117]    c46       -1
    x[118]    c209_1    -454
    x[118]    c250_1    -454
    x[118]    c44       1
    x[118]    c47       -1
    x[119]    c212_1    -454
    x[119]    c253_1    -454
    x[119]    c44       1
    x[119]    c48       -1
    x[120]    c216_1    -454
    x[120]    c257_1    -454
    x[120]    c44       1
    x[120]    c49       -1
    x[121]    c221_1    -454
    x[121]    c262_1    -454
    x[121]    c44       1
    x[121]    c50       -1
    x[122]    c227_1    -454
    x[122]    c268_1    -454
    x[122]    c44       1
    x[122]    c51       -1
    x[123]    c206_1    -454
    x[123]    c247_1    -454
    x[123]    c44       -1
    x[123]    c45       1
    x[124]    c207_1    -454
    x[124]    c248_1    -454
    x[124]    c44       -1
    x[124]    c46       1
    x[125]    c209_1    -454
    x[125]    c250_1    -454
    x[125]    c44       -1
    x[125]    c47       1
    x[126]    c212_1    -454
    x[126]    c253_1    -454
    x[126]    c44       -1
    x[126]    c48       1
    x[127]    c216_1    -454
    x[127]    c257_1    -454
    x[127]    c44       -1
    x[127]    c49       1
    x[128]    c221_1    -454
    x[128]    c262_1    -454
    x[128]    c44       -1
    x[128]    c50       1
    x[129]    c227_1    -454
    x[129]    c268_1    -454
    x[129]    c44       -1
    x[129]    c51       1
    x[130]    c208_1    -454
    x[130]    c249_1    -454
    x[130]    c45       1
    x[130]    c46       -1
    x[131]    c210_1    -454
    x[131]    c251_1    -454
    x[131]    c45       1
    x[131]    c47       -1
    x[132]    c213_1    -454
    x[132]    c254_1    -454
    x[132]    c45       1
    x[132]    c48       -1
    x[133]    c217_1    -454
    x[133]    c258_1    -454
    x[133]    c45       1
    x[133]    c49       -1
    x[134]    c222_1    -454
    x[134]    c263_1    -454
    x[134]    c45       1
    x[134]    c50       -1
    x[135]    c208_1    -454
    x[135]    c249_1    -454
    x[135]    c45       -1
    x[135]    c46       1
    x[136]    c210_1    -454
    x[136]    c251_1    -454
    x[136]    c45       -1
    x[136]    c47       1
    x[137]    c213_1    -454
    x[137]    c254_1    -454
    x[137]    c45       -1
    x[137]    c48       1
    x[138]    c217_1    -454
    x[138]    c258_1    -454
    x[138]    c45       -1
    x[138]    c49       1
    x[139]    c222_1    -454
    x[139]    c263_1    -454
    x[139]    c45       -1
    x[139]    c50       1
    x[140]    c211_1    -454
    x[140]    c252_1    -454
    x[140]    c46       1
    x[140]    c47       -1
    x[141]    c214_1    -454
    x[141]    c255_1    -454
    x[141]    c46       1
    x[141]    c48       -1
    x[142]    c218_1    -454
    x[142]    c259_1    -454
    x[142]    c46       1
    x[142]    c49       -1
    x[143]    c223_1    -454
    x[143]    c264_1    -454
    x[143]    c46       1
    x[143]    c50       -1
    x[144]    c211_1    -454
    x[144]    c252_1    -454
    x[144]    c46       -1
    x[144]    c47       1
    x[145]    c214_1    -454
    x[145]    c255_1    -454
    x[145]    c46       -1
    x[145]    c48       1
    x[146]    c218_1    -454
    x[146]    c259_1    -454
    x[146]    c46       -1
    x[146]    c49       1
    x[147]    c223_1    -454
    x[147]    c264_1    -454
    x[147]    c46       -1
    x[147]    c50       1
    x[148]    c215_1    -454
    x[148]    c256_1    -454
    x[148]    c47       1
    x[148]    c48       -1
    x[149]    c219_1    -454
    x[149]    c260_1    -454
    x[149]    c47       1
    x[149]    c49       -1
    x[150]    c224_1    -454
    x[150]    c265_1    -454
    x[150]    c47       1
    x[150]    c50       -1
    x[151]    c215_1    -454
    x[151]    c256_1    -454
    x[151]    c47       -1
    x[151]    c48       1
    x[152]    c219_1    -454
    x[152]    c260_1    -454
    x[152]    c47       -1
    x[152]    c49       1
    x[153]    c224_1    -454
    x[153]    c265_1    -454
    x[153]    c47       -1
    x[153]    c50       1
    x[154]    c220_1    -454
    x[154]    c261_1    -454
    x[154]    c48       1
    x[154]    c49       -1
    x[155]    c225_1    -454
    x[155]    c266_1    -454
    x[155]    c48       1
    x[155]    c50       -1
    x[156]    c228_1    -454
    x[156]    c269_1    -454
    x[156]    c48       1
    x[156]    c51       -1
    x[157]    c220_1    -454
    x[157]    c261_1    -454
    x[157]    c48       -1
    x[157]    c49       1
    x[158]    c225_1    -454
    x[158]    c266_1    -454
    x[158]    c48       -1
    x[158]    c50       1
    x[159]    c228_1    -454
    x[159]    c269_1    -454
    x[159]    c48       -1
    x[159]    c51       1
    x[160]    c226_1    -454
    x[160]    c267_1    -454
    x[160]    c49       1
    x[160]    c50       -1
    x[161]    c229_1    -454
    x[161]    c270_1    -454
    x[161]    c49       1
    x[161]    c51       -1
    x[162]    c226_1    -454
    x[162]    c267_1    -454
    x[162]    c49       -1
    x[162]    c50       1
    x[163]    c229_1    -454
    x[163]    c270_1    -454
    x[163]    c49       -1
    x[163]    c51       1
    x[164]    c230_1    -454
    x[164]    c271_1    -454
    x[164]    c50       1
    x[164]    c51       -1
    x[165]    c230_1    -454
    x[165]    c271_1    -454
    x[165]    c50       -1
    x[165]    c51       1
    x[166]    c220_1    -1239
    x[166]    c261_1    -1239
    x[166]    c52       1
    x[167]    c225_1    -1239
    x[167]    c266_1    -1239
    x[167]    c53       1
    x[168]    c228_1    -1239
    x[168]    c269_1    -1239
    x[168]    c54       1
    x[169]    c234_1    -1239
    x[169]    c275_1    -1239
    x[169]    c55       1
    x[170]    c242_1    -1239
    x[170]    c283_1    -1239
    x[170]    c56       1
    x[171]    c206_1    -1239
    x[171]    c247_1    -1239
    x[171]    c57       1
    x[172]    c207_1    -1239
    x[172]    c248_1    -1239
    x[172]    c58       1
    x[173]    c209_1    -1239
    x[173]    c250_1    -1239
    x[173]    c59       1
    x[174]    c212_1    -1239
    x[174]    c253_1    -1239
    x[174]    c60       1
    x[175]    c213_1    -1239
    x[175]    c254_1    -1239
    x[175]    c61       1
    x[176]    c214_1    -1239
    x[176]    c255_1    -1239
    x[176]    c62       1
    x[177]    c215_1    -1239
    x[177]    c256_1    -1239
    x[177]    c63       1
    x[178]    c216_1    -1239
    x[178]    c257_1    -1239
    x[178]    c64       1
    x[179]    c221_1    -1239
    x[179]    c262_1    -1239
    x[179]    c65       1
    x[180]    c227_1    -1239
    x[180]    c268_1    -1239
    x[180]    c66       1
    x[181]    c231_1    -1239
    x[181]    c272_1    -1239
    x[181]    c67       1
    x[182]    c238_1    -1239
    x[182]    c279_1    -1239
    x[182]    c68       1
    x[183]    c41_2     1
    x[183]    c206_1    -1239
    x[183]    c247_1    -1239
    x[183]    c69       1
    x[183]    c71       1
    x[184]    c42_2     1
    x[184]    c207_1    -1239
    x[184]    c248_1    -1239
    x[184]    c69       1
    x[184]    c72       1
    x[185]    c43_2     1
    x[185]    c209_1    -1239
    x[185]    c250_1    -1239
    x[185]    c69       1
    x[185]    c73       1
    x[186]    c41_2     1
    x[186]    c42_2     1
    x[186]    c43_2     1
    x[186]    c44_2     1
    x[186]    c45_2     1
    x[186]    c46_2     1
    x[186]    c212_1    -1239
    x[186]    c253_1    -1239
    x[186]    c69       1
    x[186]    c70       1
    x[187]    c216_1    -1239
    x[187]    c257_1    -1239
    x[187]    c69       1
    x[187]    c74       1
    x[188]    c44_2     1
    x[188]    c221_1    -1239
    x[188]    c262_1    -1239
    x[188]    c69       1
    x[188]    c75       1
    x[189]    c227_1    -1239
    x[189]    c268_1    -1239
    x[189]    c69       1
    x[189]    c76       1
    x[190]    c45_2     1
    x[190]    c231_1    -1239
    x[190]    c272_1    -1239
    x[190]    c69       1
    x[190]    c77       1
    x[191]    c46_2     1
    x[191]    c238_1    -1239
    x[191]    c279_1    -1239
    x[191]    c69       1
    x[191]    c78       1
    x[192]    c71_2     1
    x[192]    c72_2     1
    x[192]    c73_2     1
    x[192]    c74_2     1
    x[192]    c75_2     1
    x[192]    c213_1    -1239
    x[192]    c254_1    -1239
    x[192]    c70       1
    x[192]    c71       -1
    x[193]    c71_2     1
    x[193]    c214_1    -1239
    x[193]    c255_1    -1239
    x[193]    c70       1
    x[193]    c72       -1
    x[194]    c72_2     1
    x[194]    c215_1    -1239
    x[194]    c256_1    -1239
    x[194]    c70       1
    x[194]    c73       -1
    x[195]    c73_2     1
    x[195]    c220_1    -1239
    x[195]    c261_1    -1239
    x[195]    c70       1
    x[195]    c74       -1
    x[196]    c74_2     1
    x[196]    c225_1    -1239
    x[196]    c266_1    -1239
    x[196]    c70       1
    x[196]    c75       -1
    x[197]    c228_1    -1239
    x[197]    c269_1    -1239
    x[197]    c70       1
    x[197]    c76       -1
    x[198]    c234_1    -1239
    x[198]    c275_1    -1239
    x[198]    c70       1
    x[198]    c77       -1
    x[199]    c75_2     1
    x[199]    c242_1    -1239
    x[199]    c283_1    -1239
    x[199]    c70       1
    x[199]    c78       -1
    x[200]    c208_1    -1239
    x[200]    c249_1    -1239
    x[200]    c71       1
    x[200]    c72       -1
    x[201]    c210_1    -1239
    x[201]    c251_1    -1239
    x[201]    c71       1
    x[201]    c73       -1
    x[202]    c217_1    -1239
    x[202]    c258_1    -1239
    x[202]    c71       1
    x[202]    c74       -1
    x[203]    c222_1    -1239
    x[203]    c263_1    -1239
    x[203]    c71       1
    x[203]    c75       -1
    x[204]    c239_1    -1239
    x[204]    c280_1    -1239
    x[204]    c71       1
    x[204]    c78       -1
    x[205]    c208_1    -1239
    x[205]    c249_1    -1239
    x[205]    c71       -1
    x[205]    c72       1
    x[206]    c210_1    -1239
    x[206]    c251_1    -1239
    x[206]    c71       -1
    x[206]    c73       1
    x[207]    c217_1    -1239
    x[207]    c258_1    -1239
    x[207]    c71       -1
    x[207]    c74       1
    x[208]    c222_1    -1239
    x[208]    c263_1    -1239
    x[208]    c71       -1
    x[208]    c75       1
    x[209]    c239_1    -1239
    x[209]    c280_1    -1239
    x[209]    c71       -1
    x[209]    c78       1
    x[210]    c211_1    -1239
    x[210]    c252_1    -1239
    x[210]    c72       1
    x[210]    c73       -1
    x[211]    c218_1    -1239
    x[211]    c259_1    -1239
    x[211]    c72       1
    x[211]    c74       -1
    x[212]    c223_1    -1239
    x[212]    c264_1    -1239
    x[212]    c72       1
    x[212]    c75       -1
    x[213]    c232_1    -1239
    x[213]    c273_1    -1239
    x[213]    c72       1
    x[213]    c77       -1
    x[214]    c240_1    -1239
    x[214]    c281_1    -1239
    x[214]    c72       1
    x[214]    c78       -1
    x[215]    c211_1    -1239
    x[215]    c252_1    -1239
    x[215]    c72       -1
    x[215]    c73       1
    x[216]    c218_1    -1239
    x[216]    c259_1    -1239
    x[216]    c72       -1
    x[216]    c74       1
    x[217]    c223_1    -1239
    x[217]    c264_1    -1239
    x[217]    c72       -1
    x[217]    c75       1
    x[218]    c232_1    -1239
    x[218]    c273_1    -1239
    x[218]    c72       -1
    x[218]    c77       1
    x[219]    c240_1    -1239
    x[219]    c281_1    -1239
    x[219]    c72       -1
    x[219]    c78       1
    x[220]    c219_1    -1239
    x[220]    c260_1    -1239
    x[220]    c73       1
    x[220]    c74       -1
    x[221]    c224_1    -1239
    x[221]    c265_1    -1239
    x[221]    c73       1
    x[221]    c75       -1
    x[222]    c233_1    -1239
    x[222]    c274_1    -1239
    x[222]    c73       1
    x[222]    c77       -1
    x[223]    c241_1    -1239
    x[223]    c282_1    -1239
    x[223]    c73       1
    x[223]    c78       -1
    x[224]    c219_1    -1239
    x[224]    c260_1    -1239
    x[224]    c73       -1
    x[224]    c74       1
    x[225]    c224_1    -1239
    x[225]    c265_1    -1239
    x[225]    c73       -1
    x[225]    c75       1
    x[226]    c233_1    -1239
    x[226]    c274_1    -1239
    x[226]    c73       -1
    x[226]    c77       1
    x[227]    c241_1    -1239
    x[227]    c282_1    -1239
    x[227]    c73       -1
    x[227]    c78       1
    x[228]    c226_1    -1239
    x[228]    c267_1    -1239
    x[228]    c74       1
    x[228]    c75       -1
    x[229]    c229_1    -1239
    x[229]    c270_1    -1239
    x[229]    c74       1
    x[229]    c76       -1
    x[230]    c235_1    -1239
    x[230]    c276_1    -1239
    x[230]    c74       1
    x[230]    c77       -1
    x[231]    c243_1    -1239
    x[231]    c284_1    -1239
    x[231]    c74       1
    x[231]    c78       -1
    x[232]    c226_1    -1239
    x[232]    c267_1    -1239
    x[232]    c74       -1
    x[232]    c75       1
    x[233]    c229_1    -1239
    x[233]    c270_1    -1239
    x[233]    c74       -1
    x[233]    c76       1
    x[234]    c235_1    -1239
    x[234]    c276_1    -1239
    x[234]    c74       -1
    x[234]    c77       1
    x[235]    c243_1    -1239
    x[235]    c284_1    -1239
    x[235]    c74       -1
    x[235]    c78       1
    x[236]    c230_1    -1239
    x[236]    c271_1    -1239
    x[236]    c75       1
    x[236]    c76       -1
    x[237]    c236_1    -1239
    x[237]    c277_1    -1239
    x[237]    c75       1
    x[237]    c77       -1
    x[238]    c244_1    -1239
    x[238]    c285_1    -1239
    x[238]    c75       1
    x[238]    c78       -1
    x[239]    c230_1    -1239
    x[239]    c271_1    -1239
    x[239]    c75       -1
    x[239]    c76       1
    x[240]    c236_1    -1239
    x[240]    c277_1    -1239
    x[240]    c75       -1
    x[240]    c77       1
    x[241]    c244_1    -1239
    x[241]    c285_1    -1239
    x[241]    c75       -1
    x[241]    c78       1
    x[242]    c237_1    -1239
    x[242]    c278_1    -1239
    x[242]    c76       1
    x[242]    c77       -1
    x[243]    c245_1    -1239
    x[243]    c286_1    -1239
    x[243]    c76       1
    x[243]    c78       -1
    x[244]    c237_1    -1239
    x[244]    c278_1    -1239
    x[244]    c76       -1
    x[244]    c77       1
    x[245]    c245_1    -1239
    x[245]    c286_1    -1239
    x[245]    c76       -1
    x[245]    c78       1
    x[246]    c246_1    -1239
    x[246]    c287_1    -1239
    x[246]    c77       1
    x[246]    c78       -1
    x[247]    c246_1    -1239
    x[247]    c287_1    -1239
    x[247]    c77       -1
    x[247]    c78       1
    x[248]    c237_1    -740
    x[248]    c278_1    -740
    x[248]    c79       1
    x[249]    c238_1    -740
    x[249]    c279_1    -740
    x[249]    c80       1
    x[250]    c239_1    -740
    x[250]    c280_1    -740
    x[250]    c81       1
    x[251]    c240_1    -740
    x[251]    c281_1    -740
    x[251]    c82       1
    x[252]    c241_1    -740
    x[252]    c282_1    -740
    x[252]    c83       1
    x[253]    c242_1    -740
    x[253]    c283_1    -740
    x[253]    c84       1
    x[254]    c243_1    -740
    x[254]    c284_1    -740
    x[254]    c85       1
    x[255]    c244_1    -740
    x[255]    c285_1    -740
    x[255]    c86       1
    x[256]    c245_1    -740
    x[256]    c286_1    -740
    x[256]    c87       1
    x[257]    c246_1    -740
    x[257]    c287_1    -740
    x[257]    c88       1
    x[258]    c227_1    -740
    x[258]    c268_1    -740
    x[258]    c89       1
    x[259]    c228_1    -740
    x[259]    c269_1    -740
    x[259]    c90       1
    x[260]    c229_1    -740
    x[260]    c270_1    -740
    x[260]    c91       1
    x[261]    c230_1    -740
    x[261]    c271_1    -740
    x[261]    c92       1
    x[262]    c86_2     1
    x[262]    c91_2     1
    x[262]    c238_1    -740
    x[262]    c279_1    -740
    x[262]    c93       1
    x[262]    c95       1
    x[263]    c239_1    -740
    x[263]    c280_1    -740
    x[263]    c93       1
    x[263]    c96       1
    x[264]    c87_2     1
    x[264]    c240_1    -740
    x[264]    c281_1    -740
    x[264]    c93       1
    x[264]    c97       1
    x[265]    c88_2     1
    x[265]    c241_1    -740
    x[265]    c282_1    -740
    x[265]    c93       1
    x[265]    c98       1
    x[266]    c89_2     1
    x[266]    c242_1    -740
    x[266]    c283_1    -740
    x[266]    c93       1
    x[266]    c99       1
    x[267]    c243_1    -740
    x[267]    c284_1    -740
    x[267]    c93       1
    x[267]    c100      1
    x[268]    c90_2     1
    x[268]    c244_1    -740
    x[268]    c285_1    -740
    x[268]    c93       1
    x[268]    c101      1
    x[269]    c86_2     1
    x[269]    c87_2     1
    x[269]    c88_2     1
    x[269]    c89_2     1
    x[269]    c90_2     1
    x[269]    c245_1    -740
    x[269]    c286_1    -740
    x[269]    c93       1
    x[269]    c94       1
    x[270]    c91_2     1
    x[270]    c246_1    -740
    x[270]    c287_1    -740
    x[270]    c93       1
    x[270]    c102      1
    x[271]    c109_2    1
    x[271]    c110_2    1
    x[271]    c111_2    1
    x[271]    c227_1    -740
    x[271]    c268_1    -740
    x[271]    c94       1
    x[271]    c95       -1
    x[272]    c112_2    1
    x[272]    c228_1    -740
    x[272]    c269_1    -740
    x[272]    c94       1
    x[272]    c99       -1
    x[273]    c109_2    1
    x[273]    c112_2    1
    x[273]    c229_1    -740
    x[273]    c270_1    -740
    x[273]    c94       1
    x[273]    c100      -1
    x[274]    c110_2    1
    x[274]    c230_1    -740
    x[274]    c271_1    -740
    x[274]    c94       1
    x[274]    c101      -1
    x[275]    c111_2    1
    x[275]    c237_1    -740
    x[275]    c278_1    -740
    x[275]    c94       1
    x[275]    c102      -1
    x[276]    c206_1    -740
    x[276]    c247_1    -740
    x[276]    c95       1
    x[276]    c96       -1
    x[277]    c207_1    -740
    x[277]    c248_1    -740
    x[277]    c95       1
    x[277]    c97       -1
    x[278]    c209_1    -740
    x[278]    c250_1    -740
    x[278]    c95       1
    x[278]    c98       -1
    x[279]    c212_1    -740
    x[279]    c253_1    -740
    x[279]    c95       1
    x[279]    c99       -1
    x[280]    c216_1    -740
    x[280]    c257_1    -740
    x[280]    c95       1
    x[280]    c100      -1
    x[281]    c221_1    -740
    x[281]    c262_1    -740
    x[281]    c95       1
    x[281]    c101      -1
    x[282]    c231_1    -740
    x[282]    c272_1    -740
    x[282]    c95       1
    x[282]    c102      -1
    x[283]    c206_1    -740
    x[283]    c247_1    -740
    x[283]    c95       -1
    x[283]    c96       1
    x[284]    c207_1    -740
    x[284]    c248_1    -740
    x[284]    c95       -1
    x[284]    c97       1
    x[285]    c209_1    -740
    x[285]    c250_1    -740
    x[285]    c95       -1
    x[285]    c98       1
    x[286]    c212_1    -740
    x[286]    c253_1    -740
    x[286]    c95       -1
    x[286]    c99       1
    x[287]    c216_1    -740
    x[287]    c257_1    -740
    x[287]    c95       -1
    x[287]    c100      1
    x[288]    c221_1    -740
    x[288]    c262_1    -740
    x[288]    c95       -1
    x[288]    c101      1
    x[289]    c231_1    -740
    x[289]    c272_1    -740
    x[289]    c95       -1
    x[289]    c102      1
    x[290]    c208_1    -740
    x[290]    c249_1    -740
    x[290]    c96       1
    x[290]    c97       -1
    x[291]    c210_1    -740
    x[291]    c251_1    -740
    x[291]    c96       1
    x[291]    c98       -1
    x[292]    c213_1    -740
    x[292]    c254_1    -740
    x[292]    c96       1
    x[292]    c99       -1
    x[293]    c217_1    -740
    x[293]    c258_1    -740
    x[293]    c96       1
    x[293]    c100      -1
    x[294]    c222_1    -740
    x[294]    c263_1    -740
    x[294]    c96       1
    x[294]    c101      -1
    x[295]    c208_1    -740
    x[295]    c249_1    -740
    x[295]    c96       -1
    x[295]    c97       1
    x[296]    c210_1    -740
    x[296]    c251_1    -740
    x[296]    c96       -1
    x[296]    c98       1
    x[297]    c213_1    -740
    x[297]    c254_1    -740
    x[297]    c96       -1
    x[297]    c99       1
    x[298]    c217_1    -740
    x[298]    c258_1    -740
    x[298]    c96       -1
    x[298]    c100      1
    x[299]    c222_1    -740
    x[299]    c263_1    -740
    x[299]    c96       -1
    x[299]    c101      1
    x[300]    c211_1    -740
    x[300]    c252_1    -740
    x[300]    c97       1
    x[300]    c98       -1
    x[301]    c214_1    -740
    x[301]    c255_1    -740
    x[301]    c97       1
    x[301]    c99       -1
    x[302]    c218_1    -740
    x[302]    c259_1    -740
    x[302]    c97       1
    x[302]    c100      -1
    x[303]    c223_1    -740
    x[303]    c264_1    -740
    x[303]    c97       1
    x[303]    c101      -1
    x[304]    c232_1    -740
    x[304]    c273_1    -740
    x[304]    c97       1
    x[304]    c102      -1
    x[305]    c211_1    -740
    x[305]    c252_1    -740
    x[305]    c97       -1
    x[305]    c98       1
    x[306]    c214_1    -740
    x[306]    c255_1    -740
    x[306]    c97       -1
    x[306]    c99       1
    x[307]    c218_1    -740
    x[307]    c259_1    -740
    x[307]    c97       -1
    x[307]    c100      1
    x[308]    c223_1    -740
    x[308]    c264_1    -740
    x[308]    c97       -1
    x[308]    c101      1
    x[309]    c232_1    -740
    x[309]    c273_1    -740
    x[309]    c97       -1
    x[309]    c102      1
    x[310]    c215_1    -740
    x[310]    c256_1    -740
    x[310]    c98       1
    x[310]    c99       -1
    x[311]    c219_1    -740
    x[311]    c260_1    -740
    x[311]    c98       1
    x[311]    c100      -1
    x[312]    c224_1    -740
    x[312]    c265_1    -740
    x[312]    c98       1
    x[312]    c101      -1
    x[313]    c233_1    -740
    x[313]    c274_1    -740
    x[313]    c98       1
    x[313]    c102      -1
    x[314]    c215_1    -740
    x[314]    c256_1    -740
    x[314]    c98       -1
    x[314]    c99       1
    x[315]    c219_1    -740
    x[315]    c260_1    -740
    x[315]    c98       -1
    x[315]    c100      1
    x[316]    c224_1    -740
    x[316]    c265_1    -740
    x[316]    c98       -1
    x[316]    c101      1
    x[317]    c233_1    -740
    x[317]    c274_1    -740
    x[317]    c98       -1
    x[317]    c102      1
    x[318]    c220_1    -740
    x[318]    c261_1    -740
    x[318]    c99       1
    x[318]    c100      -1
    x[319]    c225_1    -740
    x[319]    c266_1    -740
    x[319]    c99       1
    x[319]    c101      -1
    x[320]    c234_1    -740
    x[320]    c275_1    -740
    x[320]    c99       1
    x[320]    c102      -1
    x[321]    c220_1    -740
    x[321]    c261_1    -740
    x[321]    c99       -1
    x[321]    c100      1
    x[322]    c225_1    -740
    x[322]    c266_1    -740
    x[322]    c99       -1
    x[322]    c101      1
    x[323]    c234_1    -740
    x[323]    c275_1    -740
    x[323]    c99       -1
    x[323]    c102      1
    x[324]    c226_1    -740
    x[324]    c267_1    -740
    x[324]    c100      1
    x[324]    c101      -1
    x[325]    c235_1    -740
    x[325]    c276_1    -740
    x[325]    c100      1
    x[325]    c102      -1
    x[326]    c226_1    -740
    x[326]    c267_1    -740
    x[326]    c100      -1
    x[326]    c101      1
    x[327]    c235_1    -740
    x[327]    c276_1    -740
    x[327]    c100      -1
    x[327]    c102      1
    x[328]    c236_1    -740
    x[328]    c277_1    -740
    x[328]    c101      1
    x[328]    c102      -1
    x[329]    c236_1    -740
    x[329]    c277_1    -740
    x[329]    c101      -1
    x[329]    c102      1
    x[330]    c226_1    -284
    x[330]    c267_1    -284
    x[330]    c103      1
    x[331]    c229_1    -284
    x[331]    c270_1    -284
    x[331]    c104      1
    x[332]    c235_1    -284
    x[332]    c276_1    -284
    x[332]    c105      1
    x[333]    c243_1    -284
    x[333]    c284_1    -284
    x[333]    c106      1
    x[334]    c206_1    -284
    x[334]    c247_1    -284
    x[334]    c107      1
    x[335]    c207_1    -284
    x[335]    c248_1    -284
    x[335]    c108      1
    x[336]    c209_1    -284
    x[336]    c250_1    -284
    x[336]    c109      1
    x[337]    c212_1    -284
    x[337]    c253_1    -284
    x[337]    c110      1
    x[338]    c216_1    -284
    x[338]    c257_1    -284
    x[338]    c111      1
    x[339]    c217_1    -284
    x[339]    c258_1    -284
    x[339]    c112      1
    x[340]    c218_1    -284
    x[340]    c259_1    -284
    x[340]    c113      1
    x[341]    c219_1    -284
    x[341]    c260_1    -284
    x[341]    c114      1
    x[342]    c220_1    -284
    x[342]    c261_1    -284
    x[342]    c115      1
    x[343]    c221_1    -284
    x[343]    c262_1    -284
    x[343]    c116      1
    x[344]    c227_1    -284
    x[344]    c268_1    -284
    x[344]    c117      1
    x[345]    c231_1    -284
    x[345]    c272_1    -284
    x[345]    c118      1
    x[346]    c238_1    -284
    x[346]    c279_1    -284
    x[346]    c119      1
    x[347]    c115_2    1
    x[347]    c206_1    -284
    x[347]    c247_1    -284
    x[347]    c120      1
    x[347]    c122      1
    x[348]    c116_2    1
    x[348]    c207_1    -284
    x[348]    c248_1    -284
    x[348]    c120      1
    x[348]    c123      1
    x[349]    c209_1    -284
    x[349]    c250_1    -284
    x[349]    c120      1
    x[349]    c124      1
    x[350]    c117_2    1
    x[350]    c212_1    -284
    x[350]    c253_1    -284
    x[350]    c120      1
    x[350]    c125      1
    x[351]    c115_2    1
    x[351]    c116_2    1
    x[351]    c117_2    1
    x[351]    c118_2    1
    x[351]    c119_2    1
    x[351]    c120_2    1
    x[351]    c216_1    -284
    x[351]    c257_1    -284
    x[351]    c120      1
    x[351]    c121      1
    x[352]    c221_1    -284
    x[352]    c262_1    -284
    x[352]    c120      1
    x[352]    c126      1
    x[353]    c118_2    1
    x[353]    c227_1    -284
    x[353]    c268_1    -284
    x[353]    c120      1
    x[353]    c127      1
    x[354]    c119_2    1
    x[354]    c231_1    -284
    x[354]    c272_1    -284
    x[354]    c120      1
    x[354]    c128      1
    x[355]    c120_2    1
    x[355]    c238_1    -284
    x[355]    c279_1    -284
    x[355]    c120      1
    x[355]    c129      1
    x[356]    c134_2    1
    x[356]    c135_2    1
    x[356]    c136_2    1
    x[356]    c137_2    1
    x[356]    c138_2    1
    x[356]    c217_1    -284
    x[356]    c258_1    -284
    x[356]    c121      1
    x[356]    c122      -1
    x[357]    c134_2    1
    x[357]    c218_1    -284
    x[357]    c259_1    -284
    x[357]    c121      1
    x[357]    c123      -1
    x[358]    c135_2    1
    x[358]    c219_1    -284
    x[358]    c260_1    -284
    x[358]    c121      1
    x[358]    c124      -1
    x[359]    c136_2    1
    x[359]    c220_1    -284
    x[359]    c261_1    -284
    x[359]    c121      1
    x[359]    c125      -1
    x[360]    c137_2    1
    x[360]    c226_1    -284
    x[360]    c267_1    -284
    x[360]    c121      1
    x[360]    c126      -1
    x[361]    c229_1    -284
    x[361]    c270_1    -284
    x[361]    c121      1
    x[361]    c127      -1
    x[362]    c138_2    1
    x[362]    c235_1    -284
    x[362]    c276_1    -284
    x[362]    c121      1
    x[362]    c128      -1
    x[363]    c243_1    -284
    x[363]    c284_1    -284
    x[363]    c121      1
    x[363]    c129      -1
    x[364]    c208_1    -284
    x[364]    c249_1    -284
    x[364]    c122      1
    x[364]    c123      -1
    x[365]    c210_1    -284
    x[365]    c251_1    -284
    x[365]    c122      1
    x[365]    c124      -1
    x[366]    c213_1    -284
    x[366]    c254_1    -284
    x[366]    c122      1
    x[366]    c125      -1
    x[367]    c222_1    -284
    x[367]    c263_1    -284
    x[367]    c122      1
    x[367]    c126      -1
    x[368]    c239_1    -284
    x[368]    c280_1    -284
    x[368]    c122      1
    x[368]    c129      -1
    x[369]    c208_1    -284
    x[369]    c249_1    -284
    x[369]    c122      -1
    x[369]    c123      1
    x[370]    c210_1    -284
    x[370]    c251_1    -284
    x[370]    c122      -1
    x[370]    c124      1
    x[371]    c213_1    -284
    x[371]    c254_1    -284
    x[371]    c122      -1
    x[371]    c125      1
    x[372]    c222_1    -284
    x[372]    c263_1    -284
    x[372]    c122      -1
    x[372]    c126      1
    x[373]    c239_1    -284
    x[373]    c280_1    -284
    x[373]    c122      -1
    x[373]    c129      1
    x[374]    c211_1    -284
    x[374]    c252_1    -284
    x[374]    c123      1
    x[374]    c124      -1
    x[375]    c214_1    -284
    x[375]    c255_1    -284
    x[375]    c123      1
    x[375]    c125      -1
    x[376]    c223_1    -284
    x[376]    c264_1    -284
    x[376]    c123      1
    x[376]    c126      -1
    x[377]    c232_1    -284
    x[377]    c273_1    -284
    x[377]    c123      1
    x[377]    c128      -1
    x[378]    c240_1    -284
    x[378]    c281_1    -284
    x[378]    c123      1
    x[378]    c129      -1
    x[379]    c211_1    -284
    x[379]    c252_1    -284
    x[379]    c123      -1
    x[379]    c124      1
    x[380]    c214_1    -284
    x[380]    c255_1    -284
    x[380]    c123      -1
    x[380]    c125      1
    x[381]    c223_1    -284
    x[381]    c264_1    -284
    x[381]    c123      -1
    x[381]    c126      1
    x[382]    c232_1    -284
    x[382]    c273_1    -284
    x[382]    c123      -1
    x[382]    c128      1
    x[383]    c240_1    -284
    x[383]    c281_1    -284
    x[383]    c123      -1
    x[383]    c129      1
    x[384]    c215_1    -284
    x[384]    c256_1    -284
    x[384]    c124      1
    x[384]    c125      -1
    x[385]    c224_1    -284
    x[385]    c265_1    -284
    x[385]    c124      1
    x[385]    c126      -1
    x[386]    c233_1    -284
    x[386]    c274_1    -284
    x[386]    c124      1
    x[386]    c128      -1
    x[387]    c241_1    -284
    x[387]    c282_1    -284
    x[387]    c124      1
    x[387]    c129      -1
    x[388]    c215_1    -284
    x[388]    c256_1    -284
    x[388]    c124      -1
    x[388]    c125      1
    x[389]    c224_1    -284
    x[389]    c265_1    -284
    x[389]    c124      -1
    x[389]    c126      1
    x[390]    c233_1    -284
    x[390]    c274_1    -284
    x[390]    c124      -1
    x[390]    c128      1
    x[391]    c241_1    -284
    x[391]    c282_1    -284
    x[391]    c124      -1
    x[391]    c129      1
    x[392]    c225_1    -284
    x[392]    c266_1    -284
    x[392]    c125      1
    x[392]    c126      -1
    x[393]    c228_1    -284
    x[393]    c269_1    -284
    x[393]    c125      1
    x[393]    c127      -1
    x[394]    c234_1    -284
    x[394]    c275_1    -284
    x[394]    c125      1
    x[394]    c128      -1
    x[395]    c242_1    -284
    x[395]    c283_1    -284
    x[395]    c125      1
    x[395]    c129      -1
    x[396]    c225_1    -284
    x[396]    c266_1    -284
    x[396]    c125      -1
    x[396]    c126      1
    x[397]    c228_1    -284
    x[397]    c269_1    -284
    x[397]    c125      -1
    x[397]    c127      1
    x[398]    c234_1    -284
    x[398]    c275_1    -284
    x[398]    c125      -1
    x[398]    c128      1
    x[399]    c242_1    -284
    x[399]    c283_1    -284
    x[399]    c125      -1
    x[399]    c129      1
    x[400]    c230_1    -284
    x[400]    c271_1    -284
    x[400]    c126      1
    x[400]    c127      -1
    x[401]    c236_1    -284
    x[401]    c277_1    -284
    x[401]    c126      1
    x[401]    c128      -1
    x[402]    c244_1    -284
    x[402]    c285_1    -284
    x[402]    c126      1
    x[402]    c129      -1
    x[403]    c230_1    -284
    x[403]    c271_1    -284
    x[403]    c126      -1
    x[403]    c127      1
    x[404]    c236_1    -284
    x[404]    c277_1    -284
    x[404]    c126      -1
    x[404]    c128      1
    x[405]    c244_1    -284
    x[405]    c285_1    -284
    x[405]    c126      -1
    x[405]    c129      1
    x[406]    c237_1    -284
    x[406]    c278_1    -284
    x[406]    c127      1
    x[406]    c128      -1
    x[407]    c245_1    -284
    x[407]    c286_1    -284
    x[407]    c127      1
    x[407]    c129      -1
    x[408]    c237_1    -284
    x[408]    c278_1    -284
    x[408]    c127      -1
    x[408]    c128      1
    x[409]    c245_1    -284
    x[409]    c286_1    -284
    x[409]    c127      -1
    x[409]    c129      1
    x[410]    c246_1    -284
    x[410]    c287_1    -284
    x[410]    c128      1
    x[410]    c129      -1
    x[411]    c246_1    -284
    x[411]    c287_1    -284
    x[411]    c128      -1
    x[411]    c129      1
    x[412]    c231_1    -3204
    x[412]    c272_1    -3204
    x[412]    c130      1
    x[413]    c232_1    -3204
    x[413]    c273_1    -3204
    x[413]    c131      1
    x[414]    c233_1    -3204
    x[414]    c274_1    -3204
    x[414]    c132      1
    x[415]    c234_1    -3204
    x[415]    c275_1    -3204
    x[415]    c133      1
    x[416]    c235_1    -3204
    x[416]    c276_1    -3204
    x[416]    c134      1
    x[417]    c236_1    -3204
    x[417]    c277_1    -3204
    x[417]    c135      1
    x[418]    c237_1    -3204
    x[418]    c278_1    -3204
    x[418]    c136      1
    x[419]    c245_1    -3204
    x[419]    c286_1    -3204
    x[419]    c137      1
    x[420]    c227_1    -3204
    x[420]    c268_1    -3204
    x[420]    c138      1
    x[421]    c228_1    -3204
    x[421]    c269_1    -3204
    x[421]    c139      1
    x[422]    c229_1    -3204
    x[422]    c270_1    -3204
    x[422]    c140      1
    x[423]    c230_1    -3204
    x[423]    c271_1    -3204
    x[423]    c141      1
    x[424]    c246_1    -3204
    x[424]    c287_1    -3204
    x[424]    c142      1
    x[425]    c152_2    1
    x[425]    c246_1    -3204
    x[425]    c287_1    -3204
    x[425]    c143      1
    x[425]    c152      1
    x[426]    c153_2    1
    x[426]    c231_1    -3204
    x[426]    c272_1    -3204
    x[426]    c143      1
    x[426]    c145      1
    x[427]    c232_1    -3204
    x[427]    c273_1    -3204
    x[427]    c143      1
    x[427]    c147      1
    x[428]    c154_2    1
    x[428]    c233_1    -3204
    x[428]    c274_1    -3204
    x[428]    c143      1
    x[428]    c148      1
    x[429]    c234_1    -3204
    x[429]    c275_1    -3204
    x[429]    c143      1
    x[429]    c149      1
    x[430]    c155_2    1
    x[430]    c235_1    -3204
    x[430]    c276_1    -3204
    x[430]    c143      1
    x[430]    c150      1
    x[431]    c156_2    1
    x[431]    c236_1    -3204
    x[431]    c277_1    -3204
    x[431]    c143      1
    x[431]    c151      1
    x[432]    c152_2    1
    x[432]    c153_2    1
    x[432]    c154_2    1
    x[432]    c155_2    1
    x[432]    c156_2    1
    x[432]    c237_1    -3204
    x[432]    c278_1    -3204
    x[432]    c143      1
    x[432]    c144      1
    x[433]    c186_2    1
    x[433]    c227_1    -3204
    x[433]    c268_1    -3204
    x[433]    c144      1
    x[433]    c145      -1
    x[434]    c186_2    1
    x[434]    c228_1    -3204
    x[434]    c269_1    -3204
    x[434]    c144      1
    x[434]    c149      -1
    x[435]    c229_1    -3204
    x[435]    c270_1    -3204
    x[435]    c144      1
    x[435]    c150      -1
    x[436]    c230_1    -3204
    x[436]    c271_1    -3204
    x[436]    c144      1
    x[436]    c151      -1
    x[437]    c245_1    -3204
    x[437]    c286_1    -3204
    x[437]    c144      1
    x[437]    c152      -1
    x[438]    c206_1    -3204
    x[438]    c247_1    -3204
    x[438]    c145      1
    x[438]    c146      -1
    x[439]    c207_1    -3204
    x[439]    c248_1    -3204
    x[439]    c145      1
    x[439]    c147      -1
    x[440]    c209_1    -3204
    x[440]    c250_1    -3204
    x[440]    c145      1
    x[440]    c148      -1
    x[441]    c212_1    -3204
    x[441]    c253_1    -3204
    x[441]    c145      1
    x[441]    c149      -1
    x[442]    c216_1    -3204
    x[442]    c257_1    -3204
    x[442]    c145      1
    x[442]    c150      -1
    x[443]    c221_1    -3204
    x[443]    c262_1    -3204
    x[443]    c145      1
    x[443]    c151      -1
    x[444]    c238_1    -3204
    x[444]    c279_1    -3204
    x[444]    c145      1
    x[444]    c152      -1
    x[445]    c206_1    -3204
    x[445]    c247_1    -3204
    x[445]    c145      -1
    x[445]    c146      1
    x[446]    c207_1    -3204
    x[446]    c248_1    -3204
    x[446]    c145      -1
    x[446]    c147      1
    x[447]    c209_1    -3204
    x[447]    c250_1    -3204
    x[447]    c145      -1
    x[447]    c148      1
    x[448]    c212_1    -3204
    x[448]    c253_1    -3204
    x[448]    c145      -1
    x[448]    c149      1
    x[449]    c216_1    -3204
    x[449]    c257_1    -3204
    x[449]    c145      -1
    x[449]    c150      1
    x[450]    c221_1    -3204
    x[450]    c262_1    -3204
    x[450]    c145      -1
    x[450]    c151      1
    x[451]    c238_1    -3204
    x[451]    c279_1    -3204
    x[451]    c145      -1
    x[451]    c152      1
    x[452]    c208_1    -3204
    x[452]    c249_1    -3204
    x[452]    c146      1
    x[452]    c147      -1
    x[453]    c210_1    -3204
    x[453]    c251_1    -3204
    x[453]    c146      1
    x[453]    c148      -1
    x[454]    c213_1    -3204
    x[454]    c254_1    -3204
    x[454]    c146      1
    x[454]    c149      -1
    x[455]    c217_1    -3204
    x[455]    c258_1    -3204
    x[455]    c146      1
    x[455]    c150      -1
    x[456]    c222_1    -3204
    x[456]    c263_1    -3204
    x[456]    c146      1
    x[456]    c151      -1
    x[457]    c239_1    -3204
    x[457]    c280_1    -3204
    x[457]    c146      1
    x[457]    c152      -1
    x[458]    c208_1    -3204
    x[458]    c249_1    -3204
    x[458]    c146      -1
    x[458]    c147      1
    x[459]    c210_1    -3204
    x[459]    c251_1    -3204
    x[459]    c146      -1
    x[459]    c148      1
    x[460]    c213_1    -3204
    x[460]    c254_1    -3204
    x[460]    c146      -1
    x[460]    c149      1
    x[461]    c217_1    -3204
    x[461]    c258_1    -3204
    x[461]    c146      -1
    x[461]    c150      1
    x[462]    c222_1    -3204
    x[462]    c263_1    -3204
    x[462]    c146      -1
    x[462]    c151      1
    x[463]    c239_1    -3204
    x[463]    c280_1    -3204
    x[463]    c146      -1
    x[463]    c152      1
    x[464]    c211_1    -3204
    x[464]    c252_1    -3204
    x[464]    c147      1
    x[464]    c148      -1
    x[465]    c214_1    -3204
    x[465]    c255_1    -3204
    x[465]    c147      1
    x[465]    c149      -1
    x[466]    c218_1    -3204
    x[466]    c259_1    -3204
    x[466]    c147      1
    x[466]    c150      -1
    x[467]    c223_1    -3204
    x[467]    c264_1    -3204
    x[467]    c147      1
    x[467]    c151      -1
    x[468]    c240_1    -3204
    x[468]    c281_1    -3204
    x[468]    c147      1
    x[468]    c152      -1
    x[469]    c211_1    -3204
    x[469]    c252_1    -3204
    x[469]    c147      -1
    x[469]    c148      1
    x[470]    c214_1    -3204
    x[470]    c255_1    -3204
    x[470]    c147      -1
    x[470]    c149      1
    x[471]    c218_1    -3204
    x[471]    c259_1    -3204
    x[471]    c147      -1
    x[471]    c150      1
    x[472]    c223_1    -3204
    x[472]    c264_1    -3204
    x[472]    c147      -1
    x[472]    c151      1
    x[473]    c240_1    -3204
    x[473]    c281_1    -3204
    x[473]    c147      -1
    x[473]    c152      1
    x[474]    c215_1    -3204
    x[474]    c256_1    -3204
    x[474]    c148      1
    x[474]    c149      -1
    x[475]    c219_1    -3204
    x[475]    c260_1    -3204
    x[475]    c148      1
    x[475]    c150      -1
    x[476]    c224_1    -3204
    x[476]    c265_1    -3204
    x[476]    c148      1
    x[476]    c151      -1
    x[477]    c241_1    -3204
    x[477]    c282_1    -3204
    x[477]    c148      1
    x[477]    c152      -1
    x[478]    c215_1    -3204
    x[478]    c256_1    -3204
    x[478]    c148      -1
    x[478]    c149      1
    x[479]    c219_1    -3204
    x[479]    c260_1    -3204
    x[479]    c148      -1
    x[479]    c150      1
    x[480]    c224_1    -3204
    x[480]    c265_1    -3204
    x[480]    c148      -1
    x[480]    c151      1
    x[481]    c241_1    -3204
    x[481]    c282_1    -3204
    x[481]    c148      -1
    x[481]    c152      1
    x[482]    c220_1    -3204
    x[482]    c261_1    -3204
    x[482]    c149      1
    x[482]    c150      -1
    x[483]    c225_1    -3204
    x[483]    c266_1    -3204
    x[483]    c149      1
    x[483]    c151      -1
    x[484]    c242_1    -3204
    x[484]    c283_1    -3204
    x[484]    c149      1
    x[484]    c152      -1
    x[485]    c220_1    -3204
    x[485]    c261_1    -3204
    x[485]    c149      -1
    x[485]    c150      1
    x[486]    c225_1    -3204
    x[486]    c266_1    -3204
    x[486]    c149      -1
    x[486]    c151      1
    x[487]    c242_1    -3204
    x[487]    c283_1    -3204
    x[487]    c149      -1
    x[487]    c152      1
    x[488]    c226_1    -3204
    x[488]    c267_1    -3204
    x[488]    c150      1
    x[488]    c151      -1
    x[489]    c243_1    -3204
    x[489]    c284_1    -3204
    x[489]    c150      1
    x[489]    c152      -1
    x[490]    c226_1    -3204
    x[490]    c267_1    -3204
    x[490]    c150      -1
    x[490]    c151      1
    x[491]    c243_1    -3204
    x[491]    c284_1    -3204
    x[491]    c150      -1
    x[491]    c152      1
    x[492]    c244_1    -3204
    x[492]    c285_1    -3204
    x[492]    c151      1
    x[492]    c152      -1
    x[493]    c244_1    -3204
    x[493]    c285_1    -3204
    x[493]    c151      -1
    x[493]    c152      1
    x[494]    c230_1    -6357
    x[494]    c271_1    -6357
    x[494]    c153      1
    x[495]    c236_1    -6357
    x[495]    c277_1    -6357
    x[495]    c154      1
    x[496]    c244_1    -6357
    x[496]    c285_1    -6357
    x[496]    c155      1
    x[497]    c206_1    -6357
    x[497]    c247_1    -6357
    x[497]    c156      1
    x[498]    c207_1    -6357
    x[498]    c248_1    -6357
    x[498]    c157      1
    x[499]    c209_1    -6357
    x[499]    c250_1    -6357
    x[499]    c158      1
    x[500]    c212_1    -6357
    x[500]    c253_1    -6357
    x[500]    c159      1
    x[501]    c216_1    -6357
    x[501]    c257_1    -6357
    x[501]    c160      1
    x[502]    c221_1    -6357
    x[502]    c262_1    -6357
    x[502]    c161      1
    x[503]    c222_1    -6357
    x[503]    c263_1    -6357
    x[503]    c162      1
    x[504]    c223_1    -6357
    x[504]    c264_1    -6357
    x[504]    c163      1
    x[505]    c224_1    -6357
    x[505]    c265_1    -6357
    x[505]    c164      1
    x[506]    c225_1    -6357
    x[506]    c266_1    -6357
    x[506]    c165      1
    x[507]    c226_1    -6357
    x[507]    c267_1    -6357
    x[507]    c166      1
    x[508]    c227_1    -6357
    x[508]    c268_1    -6357
    x[508]    c167      1
    x[509]    c231_1    -6357
    x[509]    c272_1    -6357
    x[509]    c168      1
    x[510]    c238_1    -6357
    x[510]    c279_1    -6357
    x[510]    c169      1
    x[511]    c189_2    1
    x[511]    c206_1    -6357
    x[511]    c247_1    -6357
    x[511]    c170      1
    x[511]    c172      1
    x[512]    c190_2    1
    x[512]    c207_1    -6357
    x[512]    c248_1    -6357
    x[512]    c170      1
    x[512]    c173      1
    x[513]    c209_1    -6357
    x[513]    c250_1    -6357
    x[513]    c170      1
    x[513]    c174      1
    x[514]    c191_2    1
    x[514]    c212_1    -6357
    x[514]    c253_1    -6357
    x[514]    c170      1
    x[514]    c175      1
    x[515]    c216_1    -6357
    x[515]    c257_1    -6357
    x[515]    c170      1
    x[515]    c176      1
    x[516]    c189_2    1
    x[516]    c190_2    1
    x[516]    c191_2    1
    x[516]    c192_2    1
    x[516]    c193_2    1
    x[516]    c221_1    -6357
    x[516]    c262_1    -6357
    x[516]    c170      1
    x[516]    c171      1
    x[517]    c227_1    -6357
    x[517]    c268_1    -6357
    x[517]    c170      1
    x[517]    c177      1
    x[518]    c192_2    1
    x[518]    c231_1    -6357
    x[518]    c272_1    -6357
    x[518]    c170      1
    x[518]    c178      1
    x[519]    c193_2    1
    x[519]    c238_1    -6357
    x[519]    c279_1    -6357
    x[519]    c170      1
    x[519]    c179      1
    x[520]    c213_2    1
    x[520]    c222_1    -6357
    x[520]    c263_1    -6357
    x[520]    c171      1
    x[520]    c172      -1
    x[521]    c223_1    -6357
    x[521]    c264_1    -6357
    x[521]    c171      1
    x[521]    c173      -1
    x[522]    c224_1    -6357
    x[522]    c265_1    -6357
    x[522]    c171      1
    x[522]    c174      -1
    x[523]    c225_1    -6357
    x[523]    c266_1    -6357
    x[523]    c171      1
    x[523]    c175      -1
    x[524]    c226_1    -6357
    x[524]    c267_1    -6357
    x[524]    c171      1
    x[524]    c176      -1
    x[525]    c213_2    1
    x[525]    c230_1    -6357
    x[525]    c271_1    -6357
    x[525]    c171      1
    x[525]    c177      -1
    x[526]    c236_1    -6357
    x[526]    c277_1    -6357
    x[526]    c171      1
    x[526]    c178      -1
    x[527]    c244_1    -6357
    x[527]    c285_1    -6357
    x[527]    c171      1
    x[527]    c179      -1
    x[528]    c208_1    -6357
    x[528]    c249_1    -6357
    x[528]    c172      1
    x[528]    c173      -1
    x[529]    c210_1    -6357
    x[529]    c251_1    -6357
    x[529]    c172      1
    x[529]    c174      -1
    x[530]    c213_1    -6357
    x[530]    c254_1    -6357
    x[530]    c172      1
    x[530]    c175      -1
    x[531]    c217_1    -6357
    x[531]    c258_1    -6357
    x[531]    c172      1
    x[531]    c176      -1
    x[532]    c239_1    -6357
    x[532]    c280_1    -6357
    x[532]    c172      1
    x[532]    c179      -1
    x[533]    c208_1    -6357
    x[533]    c249_1    -6357
    x[533]    c172      -1
    x[533]    c173      1
    x[534]    c210_1    -6357
    x[534]    c251_1    -6357
    x[534]    c172      -1
    x[534]    c174      1
    x[535]    c213_1    -6357
    x[535]    c254_1    -6357
    x[535]    c172      -1
    x[535]    c175      1
    x[536]    c217_1    -6357
    x[536]    c258_1    -6357
    x[536]    c172      -1
    x[536]    c176      1
    x[537]    c239_1    -6357
    x[537]    c280_1    -6357
    x[537]    c172      -1
    x[537]    c179      1
    x[538]    c211_1    -6357
    x[538]    c252_1    -6357
    x[538]    c173      1
    x[538]    c174      -1
    x[539]    c214_1    -6357
    x[539]    c255_1    -6357
    x[539]    c173      1
    x[539]    c175      -1
    x[540]    c218_1    -6357
    x[540]    c259_1    -6357
    x[540]    c173      1
    x[540]    c176      -1
    x[541]    c232_1    -6357
    x[541]    c273_1    -6357
    x[541]    c173      1
    x[541]    c178      -1
    x[542]    c240_1    -6357
    x[542]    c281_1    -6357
    x[542]    c173      1
    x[542]    c179      -1
    x[543]    c211_1    -6357
    x[543]    c252_1    -6357
    x[543]    c173      -1
    x[543]    c174      1
    x[544]    c214_1    -6357
    x[544]    c255_1    -6357
    x[544]    c173      -1
    x[544]    c175      1
    x[545]    c218_1    -6357
    x[545]    c259_1    -6357
    x[545]    c173      -1
    x[545]    c176      1
    x[546]    c232_1    -6357
    x[546]    c273_1    -6357
    x[546]    c173      -1
    x[546]    c178      1
    x[547]    c240_1    -6357
    x[547]    c281_1    -6357
    x[547]    c173      -1
    x[547]    c179      1
    x[548]    c215_1    -6357
    x[548]    c256_1    -6357
    x[548]    c174      1
    x[548]    c175      -1
    x[549]    c219_1    -6357
    x[549]    c260_1    -6357
    x[549]    c174      1
    x[549]    c176      -1
    x[550]    c233_1    -6357
    x[550]    c274_1    -6357
    x[550]    c174      1
    x[550]    c178      -1
    x[551]    c241_1    -6357
    x[551]    c282_1    -6357
    x[551]    c174      1
    x[551]    c179      -1
    x[552]    c215_1    -6357
    x[552]    c256_1    -6357
    x[552]    c174      -1
    x[552]    c175      1
    x[553]    c219_1    -6357
    x[553]    c260_1    -6357
    x[553]    c174      -1
    x[553]    c176      1
    x[554]    c233_1    -6357
    x[554]    c274_1    -6357
    x[554]    c174      -1
    x[554]    c178      1
    x[555]    c241_1    -6357
    x[555]    c282_1    -6357
    x[555]    c174      -1
    x[555]    c179      1
    x[556]    c220_1    -6357
    x[556]    c261_1    -6357
    x[556]    c175      1
    x[556]    c176      -1
    x[557]    c228_1    -6357
    x[557]    c269_1    -6357
    x[557]    c175      1
    x[557]    c177      -1
    x[558]    c234_1    -6357
    x[558]    c275_1    -6357
    x[558]    c175      1
    x[558]    c178      -1
    x[559]    c242_1    -6357
    x[559]    c283_1    -6357
    x[559]    c175      1
    x[559]    c179      -1
    x[560]    c220_1    -6357
    x[560]    c261_1    -6357
    x[560]    c175      -1
    x[560]    c176      1
    x[561]    c228_1    -6357
    x[561]    c269_1    -6357
    x[561]    c175      -1
    x[561]    c177      1
    x[562]    c234_1    -6357
    x[562]    c275_1    -6357
    x[562]    c175      -1
    x[562]    c178      1
    x[563]    c242_1    -6357
    x[563]    c283_1    -6357
    x[563]    c175      -1
    x[563]    c179      1
    x[564]    c229_1    -6357
    x[564]    c270_1    -6357
    x[564]    c176      1
    x[564]    c177      -1
    x[565]    c235_1    -6357
    x[565]    c276_1    -6357
    x[565]    c176      1
    x[565]    c178      -1
    x[566]    c243_1    -6357
    x[566]    c284_1    -6357
    x[566]    c176      1
    x[566]    c179      -1
    x[567]    c229_1    -6357
    x[567]    c270_1    -6357
    x[567]    c176      -1
    x[567]    c177      1
    x[568]    c235_1    -6357
    x[568]    c276_1    -6357
    x[568]    c176      -1
    x[568]    c178      1
    x[569]    c243_1    -6357
    x[569]    c284_1    -6357
    x[569]    c176      -1
    x[569]    c179      1
    x[570]    c237_1    -6357
    x[570]    c278_1    -6357
    x[570]    c177      1
    x[570]    c178      -1
    x[571]    c245_1    -6357
    x[571]    c286_1    -6357
    x[571]    c177      1
    x[571]    c179      -1
    x[572]    c237_1    -6357
    x[572]    c278_1    -6357
    x[572]    c177      -1
    x[572]    c178      1
    x[573]    c245_1    -6357
    x[573]    c286_1    -6357
    x[573]    c177      -1
    x[573]    c179      1
    x[574]    c246_1    -6357
    x[574]    c287_1    -6357
    x[574]    c178      1
    x[574]    c179      -1
    x[575]    c246_1    -6357
    x[575]    c287_1    -6357
    x[575]    c178      -1
    x[575]    c179      1
    x[576]    c230_1    -1431
    x[576]    c271_1    -1431
    x[576]    c180      1
    x[577]    c236_1    -1431
    x[577]    c277_1    -1431
    x[577]    c181      1
    x[578]    c238_1    -1431
    x[578]    c279_1    -1431
    x[578]    c182      1
    x[579]    c239_1    -1431
    x[579]    c280_1    -1431
    x[579]    c183      1
    x[580]    c240_1    -1431
    x[580]    c281_1    -1431
    x[580]    c184      1
    x[581]    c241_1    -1431
    x[581]    c282_1    -1431
    x[581]    c185      1
    x[582]    c242_1    -1431
    x[582]    c283_1    -1431
    x[582]    c186      1
    x[583]    c243_1    -1431
    x[583]    c284_1    -1431
    x[583]    c187      1
    x[584]    c244_1    -1431
    x[584]    c285_1    -1431
    x[584]    c188      1
    x[585]    c245_1    -1431
    x[585]    c286_1    -1431
    x[585]    c189      1
    x[586]    c246_1    -1431
    x[586]    c287_1    -1431
    x[586]    c190      1
    x[587]    c221_1    -1431
    x[587]    c262_1    -1431
    x[587]    c191      1
    x[588]    c222_1    -1431
    x[588]    c263_1    -1431
    x[588]    c192      1
    x[589]    c223_1    -1431
    x[589]    c264_1    -1431
    x[589]    c193      1
    x[590]    c224_1    -1431
    x[590]    c265_1    -1431
    x[590]    c194      1
    x[591]    c225_1    -1431
    x[591]    c266_1    -1431
    x[591]    c195      1
    x[592]    c226_1    -1431
    x[592]    c267_1    -1431
    x[592]    c196      1
    x[593]    c228_2    1
    x[593]    c234_2    1
    x[593]    c238_1    -1431
    x[593]    c279_1    -1431
    x[593]    c197      1
    x[593]    c199      1
    x[594]    c229_2    1
    x[594]    c239_1    -1431
    x[594]    c280_1    -1431
    x[594]    c197      1
    x[594]    c200      1
    x[595]    c230_2    1
    x[595]    c240_1    -1431
    x[595]    c281_1    -1431
    x[595]    c197      1
    x[595]    c201      1
    x[596]    c231_2    1
    x[596]    c241_1    -1431
    x[596]    c282_1    -1431
    x[596]    c197      1
    x[596]    c202      1
    x[597]    c242_1    -1431
    x[597]    c283_1    -1431
    x[597]    c197      1
    x[597]    c203      1
    x[598]    c243_1    -1431
    x[598]    c284_1    -1431
    x[598]    c197      1
    x[598]    c204      1
    x[599]    c228_2    1
    x[599]    c229_2    1
    x[599]    c230_2    1
    x[599]    c231_2    1
    x[599]    c232_2    1
    x[599]    c244_1    -1431
    x[599]    c285_1    -1431
    x[599]    c197      1
    x[599]    c198      1
    x[600]    c234_2    1
    x[600]    c245_1    -1431
    x[600]    c286_1    -1431
    x[600]    c197      1
    x[600]    c205      1
    x[601]    c232_2    1
    x[601]    c246_1    -1431
    x[601]    c287_1    -1431
    x[601]    c197      1
    x[601]    c206      1
    x[602]    c256_2    1
    x[602]    c257_2    1
    x[602]    c258_2    1
    x[602]    c259_2    1
    x[602]    c260_2    1
    x[602]    c221_1    -1431
    x[602]    c262_1    -1431
    x[602]    c198      1
    x[602]    c199      -1
    x[603]    c256_2    1
    x[603]    c222_1    -1431
    x[603]    c263_1    -1431
    x[603]    c198      1
    x[603]    c200      -1
    x[604]    c223_1    -1431
    x[604]    c264_1    -1431
    x[604]    c198      1
    x[604]    c201      -1
    x[605]    c257_2    1
    x[605]    c224_1    -1431
    x[605]    c265_1    -1431
    x[605]    c198      1
    x[605]    c202      -1
    x[606]    c258_2    1
    x[606]    c225_1    -1431
    x[606]    c266_1    -1431
    x[606]    c198      1
    x[606]    c203      -1
    x[607]    c259_2    1
    x[607]    c226_1    -1431
    x[607]    c267_1    -1431
    x[607]    c198      1
    x[607]    c204      -1
    x[608]    c260_2    1
    x[608]    c230_1    -1431
    x[608]    c271_1    -1431
    x[608]    c198      1
    x[608]    c205      -1
    x[609]    c236_1    -1431
    x[609]    c277_1    -1431
    x[609]    c198      1
    x[609]    c206      -1
    x[610]    c206_1    -1431
    x[610]    c247_1    -1431
    x[610]    c199      1
    x[610]    c200      -1
    x[611]    c207_1    -1431
    x[611]    c248_1    -1431
    x[611]    c199      1
    x[611]    c201      -1
    x[612]    c209_1    -1431
    x[612]    c250_1    -1431
    x[612]    c199      1
    x[612]    c202      -1
    x[613]    c212_1    -1431
    x[613]    c253_1    -1431
    x[613]    c199      1
    x[613]    c203      -1
    x[614]    c216_1    -1431
    x[614]    c257_1    -1431
    x[614]    c199      1
    x[614]    c204      -1
    x[615]    c227_1    -1431
    x[615]    c268_1    -1431
    x[615]    c199      1
    x[615]    c205      -1
    x[616]    c231_1    -1431
    x[616]    c272_1    -1431
    x[616]    c199      1
    x[616]    c206      -1
    x[617]    c206_1    -1431
    x[617]    c247_1    -1431
    x[617]    c199      -1
    x[617]    c200      1
    x[618]    c207_1    -1431
    x[618]    c248_1    -1431
    x[618]    c199      -1
    x[618]    c201      1
    x[619]    c209_1    -1431
    x[619]    c250_1    -1431
    x[619]    c199      -1
    x[619]    c202      1
    x[620]    c212_1    -1431
    x[620]    c253_1    -1431
    x[620]    c199      -1
    x[620]    c203      1
    x[621]    c216_1    -1431
    x[621]    c257_1    -1431
    x[621]    c199      -1
    x[621]    c204      1
    x[622]    c227_1    -1431
    x[622]    c268_1    -1431
    x[622]    c199      -1
    x[622]    c205      1
    x[623]    c231_1    -1431
    x[623]    c272_1    -1431
    x[623]    c199      -1
    x[623]    c206      1
    x[624]    c208_1    -1431
    x[624]    c249_1    -1431
    x[624]    c200      1
    x[624]    c201      -1
    x[625]    c210_1    -1431
    x[625]    c251_1    -1431
    x[625]    c200      1
    x[625]    c202      -1
    x[626]    c213_1    -1431
    x[626]    c254_1    -1431
    x[626]    c200      1
    x[626]    c203      -1
    x[627]    c217_1    -1431
    x[627]    c258_1    -1431
    x[627]    c200      1
    x[627]    c204      -1
    x[628]    c208_1    -1431
    x[628]    c249_1    -1431
    x[628]    c200      -1
    x[628]    c201      1
    x[629]    c210_1    -1431
    x[629]    c251_1    -1431
    x[629]    c200      -1
    x[629]    c202      1
    x[630]    c213_1    -1431
    x[630]    c254_1    -1431
    x[630]    c200      -1
    x[630]    c203      1
    x[631]    c217_1    -1431
    x[631]    c258_1    -1431
    x[631]    c200      -1
    x[631]    c204      1
    x[632]    c211_1    -1431
    x[632]    c252_1    -1431
    x[632]    c201      1
    x[632]    c202      -1
    x[633]    c214_1    -1431
    x[633]    c255_1    -1431
    x[633]    c201      1
    x[633]    c203      -1
    x[634]    c218_1    -1431
    x[634]    c259_1    -1431
    x[634]    c201      1
    x[634]    c204      -1
    x[635]    c232_1    -1431
    x[635]    c273_1    -1431
    x[635]    c201      1
    x[635]    c206      -1
    x[636]    c211_1    -1431
    x[636]    c252_1    -1431
    x[636]    c201      -1
    x[636]    c202      1
    x[637]    c214_1    -1431
    x[637]    c255_1    -1431
    x[637]    c201      -1
    x[637]    c203      1
    x[638]    c218_1    -1431
    x[638]    c259_1    -1431
    x[638]    c201      -1
    x[638]    c204      1
    x[639]    c232_1    -1431
    x[639]    c273_1    -1431
    x[639]    c201      -1
    x[639]    c206      1
    x[640]    c215_1    -1431
    x[640]    c256_1    -1431
    x[640]    c202      1
    x[640]    c203      -1
    x[641]    c219_1    -1431
    x[641]    c260_1    -1431
    x[641]    c202      1
    x[641]    c204      -1
    x[642]    c233_1    -1431
    x[642]    c274_1    -1431
    x[642]    c202      1
    x[642]    c206      -1
    x[643]    c215_1    -1431
    x[643]    c256_1    -1431
    x[643]    c202      -1
    x[643]    c203      1
    x[644]    c219_1    -1431
    x[644]    c260_1    -1431
    x[644]    c202      -1
    x[644]    c204      1
    x[645]    c233_1    -1431
    x[645]    c274_1    -1431
    x[645]    c202      -1
    x[645]    c206      1
    x[646]    c220_1    -1431
    x[646]    c261_1    -1431
    x[646]    c203      1
    x[646]    c204      -1
    x[647]    c228_1    -1431
    x[647]    c269_1    -1431
    x[647]    c203      1
    x[647]    c205      -1
    x[648]    c234_1    -1431
    x[648]    c275_1    -1431
    x[648]    c203      1
    x[648]    c206      -1
    x[649]    c220_1    -1431
    x[649]    c261_1    -1431
    x[649]    c203      -1
    x[649]    c204      1
    x[650]    c228_1    -1431
    x[650]    c269_1    -1431
    x[650]    c203      -1
    x[650]    c205      1
    x[651]    c234_1    -1431
    x[651]    c275_1    -1431
    x[651]    c203      -1
    x[651]    c206      1
    x[652]    c229_1    -1431
    x[652]    c270_1    -1431
    x[652]    c204      1
    x[652]    c205      -1
    x[653]    c235_1    -1431
    x[653]    c276_1    -1431
    x[653]    c204      1
    x[653]    c206      -1
    x[654]    c229_1    -1431
    x[654]    c270_1    -1431
    x[654]    c204      -1
    x[654]    c205      1
    x[655]    c235_1    -1431
    x[655]    c276_1    -1431
    x[655]    c204      -1
    x[655]    c206      1
    x[656]    c237_1    -1431
    x[656]    c278_1    -1431
    x[656]    c205      1
    x[656]    c206      -1
    x[657]    c237_1    -1431
    x[657]    c278_1    -1431
    x[657]    c205      -1
    x[657]    c206      1
    x[658]    c237_1    -512
    x[658]    c278_1    -512
    x[658]    c207      1
    x[659]    c245_1    -512
    x[659]    c286_1    -512
    x[659]    c208      1
    x[660]    c206_1    -512
    x[660]    c247_1    -512
    x[660]    c209      1
    x[661]    c207_1    -512
    x[661]    c248_1    -512
    x[661]    c210      1
    x[662]    c209_1    -512
    x[662]    c250_1    -512
    x[662]    c211      1
    x[663]    c212_1    -512
    x[663]    c253_1    -512
    x[663]    c212      1
    x[664]    c216_1    -512
    x[664]    c257_1    -512
    x[664]    c213      1
    x[665]    c221_1    -512
    x[665]    c262_1    -512
    x[665]    c214      1
    x[666]    c227_1    -512
    x[666]    c268_1    -512
    x[666]    c215      1
    x[667]    c228_1    -512
    x[667]    c269_1    -512
    x[667]    c216      1
    x[668]    c229_1    -512
    x[668]    c270_1    -512
    x[668]    c217      1
    x[669]    c230_1    -512
    x[669]    c271_1    -512
    x[669]    c218      1
    x[670]    c231_1    -512
    x[670]    c272_1    -512
    x[670]    c219      1
    x[671]    c238_1    -512
    x[671]    c279_1    -512
    x[671]    c220      1
    x[672]    c102_2    1
    x[672]    c108_2    1
    x[672]    c206_1    -512
    x[672]    c247_1    -512
    x[672]    c221      1
    x[672]    c223      1
    x[673]    c103_2    1
    x[673]    c207_1    -512
    x[673]    c248_1    -512
    x[673]    c221      1
    x[673]    c224      1
    x[674]    c104_2    1
    x[674]    c209_1    -512
    x[674]    c250_1    -512
    x[674]    c221      1
    x[674]    c225      1
    x[675]    c105_2    1
    x[675]    c212_1    -512
    x[675]    c253_1    -512
    x[675]    c221      1
    x[675]    c226      1
    x[676]    c106_2    1
    x[676]    c216_1    -512
    x[676]    c257_1    -512
    x[676]    c221      1
    x[676]    c227      1
    x[677]    c107_2    1
    x[677]    c221_1    -512
    x[677]    c262_1    -512
    x[677]    c221      1
    x[677]    c228      1
    x[678]    c102_2    1
    x[678]    c103_2    1
    x[678]    c104_2    1
    x[678]    c105_2    1
    x[678]    c106_2    1
    x[678]    c107_2    1
    x[678]    c227_1    -512
    x[678]    c268_1    -512
    x[678]    c221      1
    x[678]    c222      1
    x[679]    c108_2    1
    x[679]    c231_1    -512
    x[679]    c272_1    -512
    x[679]    c221      1
    x[679]    c229      1
    x[680]    c238_1    -512
    x[680]    c279_1    -512
    x[680]    c221      1
    x[680]    c230      1
    x[681]    c187_2    1
    x[681]    c228_1    -512
    x[681]    c269_1    -512
    x[681]    c222      1
    x[681]    c226      -1
    x[682]    c229_1    -512
    x[682]    c270_1    -512
    x[682]    c222      1
    x[682]    c227      -1
    x[683]    c230_1    -512
    x[683]    c271_1    -512
    x[683]    c222      1
    x[683]    c228      -1
    x[684]    c187_2    1
    x[684]    c237_1    -512
    x[684]    c278_1    -512
    x[684]    c222      1
    x[684]    c229      -1
    x[685]    c245_1    -512
    x[685]    c286_1    -512
    x[685]    c222      1
    x[685]    c230      -1
    x[686]    c208_1    -512
    x[686]    c249_1    -512
    x[686]    c223      1
    x[686]    c224      -1
    x[687]    c210_1    -512
    x[687]    c251_1    -512
    x[687]    c223      1
    x[687]    c225      -1
    x[688]    c213_1    -512
    x[688]    c254_1    -512
    x[688]    c223      1
    x[688]    c226      -1
    x[689]    c217_1    -512
    x[689]    c258_1    -512
    x[689]    c223      1
    x[689]    c227      -1
    x[690]    c222_1    -512
    x[690]    c263_1    -512
    x[690]    c223      1
    x[690]    c228      -1
    x[691]    c239_1    -512
    x[691]    c280_1    -512
    x[691]    c223      1
    x[691]    c230      -1
    x[692]    c208_1    -512
    x[692]    c249_1    -512
    x[692]    c223      -1
    x[692]    c224      1
    x[693]    c210_1    -512
    x[693]    c251_1    -512
    x[693]    c223      -1
    x[693]    c225      1
    x[694]    c213_1    -512
    x[694]    c254_1    -512
    x[694]    c223      -1
    x[694]    c226      1
    x[695]    c217_1    -512
    x[695]    c258_1    -512
    x[695]    c223      -1
    x[695]    c227      1
    x[696]    c222_1    -512
    x[696]    c263_1    -512
    x[696]    c223      -1
    x[696]    c228      1
    x[697]    c239_1    -512
    x[697]    c280_1    -512
    x[697]    c223      -1
    x[697]    c230      1
    x[698]    c211_1    -512
    x[698]    c252_1    -512
    x[698]    c224      1
    x[698]    c225      -1
    x[699]    c214_1    -512
    x[699]    c255_1    -512
    x[699]    c224      1
    x[699]    c226      -1
    x[700]    c218_1    -512
    x[700]    c259_1    -512
    x[700]    c224      1
    x[700]    c227      -1
    x[701]    c223_1    -512
    x[701]    c264_1    -512
    x[701]    c224      1
    x[701]    c228      -1
    x[702]    c232_1    -512
    x[702]    c273_1    -512
    x[702]    c224      1
    x[702]    c229      -1
    x[703]    c240_1    -512
    x[703]    c281_1    -512
    x[703]    c224      1
    x[703]    c230      -1
    x[704]    c211_1    -512
    x[704]    c252_1    -512
    x[704]    c224      -1
    x[704]    c225      1
    x[705]    c214_1    -512
    x[705]    c255_1    -512
    x[705]    c224      -1
    x[705]    c226      1
    x[706]    c218_1    -512
    x[706]    c259_1    -512
    x[706]    c224      -1
    x[706]    c227      1
    x[707]    c223_1    -512
    x[707]    c264_1    -512
    x[707]    c224      -1
    x[707]    c228      1
    x[708]    c232_1    -512
    x[708]    c273_1    -512
    x[708]    c224      -1
    x[708]    c229      1
    x[709]    c240_1    -512
    x[709]    c281_1    -512
    x[709]    c224      -1
    x[709]    c230      1
    x[710]    c215_1    -512
    x[710]    c256_1    -512
    x[710]    c225      1
    x[710]    c226      -1
    x[711]    c219_1    -512
    x[711]    c260_1    -512
    x[711]    c225      1
    x[711]    c227      -1
    x[712]    c224_1    -512
    x[712]    c265_1    -512
    x[712]    c225      1
    x[712]    c228      -1
    x[713]    c233_1    -512
    x[713]    c274_1    -512
    x[713]    c225      1
    x[713]    c229      -1
    x[714]    c241_1    -512
    x[714]    c282_1    -512
    x[714]    c225      1
    x[714]    c230      -1
    x[715]    c215_1    -512
    x[715]    c256_1    -512
    x[715]    c225      -1
    x[715]    c226      1
    x[716]    c219_1    -512
    x[716]    c260_1    -512
    x[716]    c225      -1
    x[716]    c227      1
    x[717]    c224_1    -512
    x[717]    c265_1    -512
    x[717]    c225      -1
    x[717]    c228      1
    x[718]    c233_1    -512
    x[718]    c274_1    -512
    x[718]    c225      -1
    x[718]    c229      1
    x[719]    c241_1    -512
    x[719]    c282_1    -512
    x[719]    c225      -1
    x[719]    c230      1
    x[720]    c220_1    -512
    x[720]    c261_1    -512
    x[720]    c226      1
    x[720]    c227      -1
    x[721]    c225_1    -512
    x[721]    c266_1    -512
    x[721]    c226      1
    x[721]    c228      -1
    x[722]    c234_1    -512
    x[722]    c275_1    -512
    x[722]    c226      1
    x[722]    c229      -1
    x[723]    c242_1    -512
    x[723]    c283_1    -512
    x[723]    c226      1
    x[723]    c230      -1
    x[724]    c220_1    -512
    x[724]    c261_1    -512
    x[724]    c226      -1
    x[724]    c227      1
    x[725]    c225_1    -512
    x[725]    c266_1    -512
    x[725]    c226      -1
    x[725]    c228      1
    x[726]    c234_1    -512
    x[726]    c275_1    -512
    x[726]    c226      -1
    x[726]    c229      1
    x[727]    c242_1    -512
    x[727]    c283_1    -512
    x[727]    c226      -1
    x[727]    c230      1
    x[728]    c226_1    -512
    x[728]    c267_1    -512
    x[728]    c227      1
    x[728]    c228      -1
    x[729]    c235_1    -512
    x[729]    c276_1    -512
    x[729]    c227      1
    x[729]    c229      -1
    x[730]    c243_1    -512
    x[730]    c284_1    -512
    x[730]    c227      1
    x[730]    c230      -1
    x[731]    c226_1    -512
    x[731]    c267_1    -512
    x[731]    c227      -1
    x[731]    c228      1
    x[732]    c235_1    -512
    x[732]    c276_1    -512
    x[732]    c227      -1
    x[732]    c229      1
    x[733]    c243_1    -512
    x[733]    c284_1    -512
    x[733]    c227      -1
    x[733]    c230      1
    x[734]    c236_1    -512
    x[734]    c277_1    -512
    x[734]    c228      1
    x[734]    c229      -1
    x[735]    c244_1    -512
    x[735]    c285_1    -512
    x[735]    c228      1
    x[735]    c230      -1
    x[736]    c236_1    -512
    x[736]    c277_1    -512
    x[736]    c228      -1
    x[736]    c229      1
    x[737]    c244_1    -512
    x[737]    c285_1    -512
    x[737]    c228      -1
    x[737]    c230      1
    x[738]    c246_1    -512
    x[738]    c287_1    -512
    x[738]    c229      1
    x[738]    c230      -1
    x[739]    c246_1    -512
    x[739]    c287_1    -512
    x[739]    c229      -1
    x[739]    c230      1
    x[740]    c230_1    -2318
    x[740]    c271_1    -2318
    x[740]    c231      1
    x[741]    c231_1    -2318
    x[741]    c272_1    -2318
    x[741]    c232      1
    x[742]    c232_1    -2318
    x[742]    c273_1    -2318
    x[742]    c233      1
    x[743]    c233_1    -2318
    x[743]    c274_1    -2318
    x[743]    c234      1
    x[744]    c234_1    -2318
    x[744]    c275_1    -2318
    x[744]    c235      1
    x[745]    c235_1    -2318
    x[745]    c276_1    -2318
    x[745]    c236      1
    x[746]    c236_1    -2318
    x[746]    c277_1    -2318
    x[746]    c237      1
    x[747]    c237_1    -2318
    x[747]    c278_1    -2318
    x[747]    c238      1
    x[748]    c244_1    -2318
    x[748]    c285_1    -2318
    x[748]    c239      1
    x[749]    c221_1    -2318
    x[749]    c262_1    -2318
    x[749]    c240      1
    x[750]    c222_1    -2318
    x[750]    c263_1    -2318
    x[750]    c241      1
    x[751]    c223_1    -2318
    x[751]    c264_1    -2318
    x[751]    c242      1
    x[752]    c224_1    -2318
    x[752]    c265_1    -2318
    x[752]    c243      1
    x[753]    c225_1    -2318
    x[753]    c266_1    -2318
    x[753]    c244      1
    x[754]    c226_1    -2318
    x[754]    c267_1    -2318
    x[754]    c245      1
    x[755]    c246_1    -2318
    x[755]    c287_1    -2318
    x[755]    c246      1
    x[756]    c246_1    -2318
    x[756]    c287_1    -2318
    x[756]    c247      1
    x[756]    c256      1
    x[757]    c231_1    -2318
    x[757]    c272_1    -2318
    x[757]    c247      1
    x[757]    c249      1
    x[758]    c1_2      1
    x[758]    c232_1    -2318
    x[758]    c273_1    -2318
    x[758]    c247      1
    x[758]    c251      1
    x[759]    c233_1    -2318
    x[759]    c274_1    -2318
    x[759]    c247      1
    x[759]    c252      1
    x[760]    c234_1    -2318
    x[760]    c275_1    -2318
    x[760]    c247      1
    x[760]    c253      1
    x[761]    c235_1    -2318
    x[761]    c276_1    -2318
    x[761]    c247      1
    x[761]    c254      1
    x[762]    c1_2      1
    x[762]    c236_1    -2318
    x[762]    c277_1    -2318
    x[762]    c247      1
    x[762]    c248      1
    x[763]    c237_1    -2318
    x[763]    c278_1    -2318
    x[763]    c247      1
    x[763]    c255      1
    x[764]    c30_2     1
    x[764]    c31_2     1
    x[764]    c32_2     1
    x[764]    c33_2     1
    x[764]    c34_2     1
    x[764]    c35_2     1
    x[764]    c221_1    -2318
    x[764]    c262_1    -2318
    x[764]    c248      1
    x[764]    c249      -1
    x[765]    c30_2     1
    x[765]    c222_1    -2318
    x[765]    c263_1    -2318
    x[765]    c248      1
    x[765]    c250      -1
    x[766]    c31_2     1
    x[766]    c223_1    -2318
    x[766]    c264_1    -2318
    x[766]    c248      1
    x[766]    c251      -1
    x[767]    c32_2     1
    x[767]    c224_1    -2318
    x[767]    c265_1    -2318
    x[767]    c248      1
    x[767]    c252      -1
    x[768]    c33_2     1
    x[768]    c225_1    -2318
    x[768]    c266_1    -2318
    x[768]    c248      1
    x[768]    c253      -1
    x[769]    c226_1    -2318
    x[769]    c267_1    -2318
    x[769]    c248      1
    x[769]    c254      -1
    x[770]    c34_2     1
    x[770]    c230_1    -2318
    x[770]    c271_1    -2318
    x[770]    c248      1
    x[770]    c255      -1
    x[771]    c35_2     1
    x[771]    c244_1    -2318
    x[771]    c285_1    -2318
    x[771]    c248      1
    x[771]    c256      -1
    x[772]    c206_1    -2318
    x[772]    c247_1    -2318
    x[772]    c249      1
    x[772]    c250      -1
    x[773]    c207_1    -2318
    x[773]    c248_1    -2318
    x[773]    c249      1
    x[773]    c251      -1
    x[774]    c209_1    -2318
    x[774]    c250_1    -2318
    x[774]    c249      1
    x[774]    c252      -1
    x[775]    c212_1    -2318
    x[775]    c253_1    -2318
    x[775]    c249      1
    x[775]    c253      -1
    x[776]    c216_1    -2318
    x[776]    c257_1    -2318
    x[776]    c249      1
    x[776]    c254      -1
    x[777]    c227_1    -2318
    x[777]    c268_1    -2318
    x[777]    c249      1
    x[777]    c255      -1
    x[778]    c238_1    -2318
    x[778]    c279_1    -2318
    x[778]    c249      1
    x[778]    c256      -1
    x[779]    c206_1    -2318
    x[779]    c247_1    -2318
    x[779]    c249      -1
    x[779]    c250      1
    x[780]    c207_1    -2318
    x[780]    c248_1    -2318
    x[780]    c249      -1
    x[780]    c251      1
    x[781]    c209_1    -2318
    x[781]    c250_1    -2318
    x[781]    c249      -1
    x[781]    c252      1
    x[782]    c212_1    -2318
    x[782]    c253_1    -2318
    x[782]    c249      -1
    x[782]    c253      1
    x[783]    c216_1    -2318
    x[783]    c257_1    -2318
    x[783]    c249      -1
    x[783]    c254      1
    x[784]    c227_1    -2318
    x[784]    c268_1    -2318
    x[784]    c249      -1
    x[784]    c255      1
    x[785]    c238_1    -2318
    x[785]    c279_1    -2318
    x[785]    c249      -1
    x[785]    c256      1
    x[786]    c208_1    -2318
    x[786]    c249_1    -2318
    x[786]    c250      1
    x[786]    c251      -1
    x[787]    c210_1    -2318
    x[787]    c251_1    -2318
    x[787]    c250      1
    x[787]    c252      -1
    x[788]    c213_1    -2318
    x[788]    c254_1    -2318
    x[788]    c250      1
    x[788]    c253      -1
    x[789]    c217_1    -2318
    x[789]    c258_1    -2318
    x[789]    c250      1
    x[789]    c254      -1
    x[790]    c239_1    -2318
    x[790]    c280_1    -2318
    x[790]    c250      1
    x[790]    c256      -1
    x[791]    c208_1    -2318
    x[791]    c249_1    -2318
    x[791]    c250      -1
    x[791]    c251      1
    x[792]    c210_1    -2318
    x[792]    c251_1    -2318
    x[792]    c250      -1
    x[792]    c252      1
    x[793]    c213_1    -2318
    x[793]    c254_1    -2318
    x[793]    c250      -1
    x[793]    c253      1
    x[794]    c217_1    -2318
    x[794]    c258_1    -2318
    x[794]    c250      -1
    x[794]    c254      1
    x[795]    c239_1    -2318
    x[795]    c280_1    -2318
    x[795]    c250      -1
    x[795]    c256      1
    x[796]    c211_1    -2318
    x[796]    c252_1    -2318
    x[796]    c251      1
    x[796]    c252      -1
    x[797]    c214_1    -2318
    x[797]    c255_1    -2318
    x[797]    c251      1
    x[797]    c253      -1
    x[798]    c218_1    -2318
    x[798]    c259_1    -2318
    x[798]    c251      1
    x[798]    c254      -1
    x[799]    c240_1    -2318
    x[799]    c281_1    -2318
    x[799]    c251      1
    x[799]    c256      -1
    x[800]    c211_1    -2318
    x[800]    c252_1    -2318
    x[800]    c251      -1
    x[800]    c252      1
    x[801]    c214_1    -2318
    x[801]    c255_1    -2318
    x[801]    c251      -1
    x[801]    c253      1
    x[802]    c218_1    -2318
    x[802]    c259_1    -2318
    x[802]    c251      -1
    x[802]    c254      1
    x[803]    c240_1    -2318
    x[803]    c281_1    -2318
    x[803]    c251      -1
    x[803]    c256      1
    x[804]    c215_1    -2318
    x[804]    c256_1    -2318
    x[804]    c252      1
    x[804]    c253      -1
    x[805]    c219_1    -2318
    x[805]    c260_1    -2318
    x[805]    c252      1
    x[805]    c254      -1
    x[806]    c241_1    -2318
    x[806]    c282_1    -2318
    x[806]    c252      1
    x[806]    c256      -1
    x[807]    c215_1    -2318
    x[807]    c256_1    -2318
    x[807]    c252      -1
    x[807]    c253      1
    x[808]    c219_1    -2318
    x[808]    c260_1    -2318
    x[808]    c252      -1
    x[808]    c254      1
    x[809]    c241_1    -2318
    x[809]    c282_1    -2318
    x[809]    c252      -1
    x[809]    c256      1
    x[810]    c220_1    -2318
    x[810]    c261_1    -2318
    x[810]    c253      1
    x[810]    c254      -1
    x[811]    c228_1    -2318
    x[811]    c269_1    -2318
    x[811]    c253      1
    x[811]    c255      -1
    x[812]    c242_1    -2318
    x[812]    c283_1    -2318
    x[812]    c253      1
    x[812]    c256      -1
    x[813]    c220_1    -2318
    x[813]    c261_1    -2318
    x[813]    c253      -1
    x[813]    c254      1
    x[814]    c228_1    -2318
    x[814]    c269_1    -2318
    x[814]    c253      -1
    x[814]    c255      1
    x[815]    c242_1    -2318
    x[815]    c283_1    -2318
    x[815]    c253      -1
    x[815]    c256      1
    x[816]    c229_1    -2318
    x[816]    c270_1    -2318
    x[816]    c254      1
    x[816]    c255      -1
    x[817]    c243_1    -2318
    x[817]    c284_1    -2318
    x[817]    c254      1
    x[817]    c256      -1
    x[818]    c229_1    -2318
    x[818]    c270_1    -2318
    x[818]    c254      -1
    x[818]    c255      1
    x[819]    c243_1    -2318
    x[819]    c284_1    -2318
    x[819]    c254      -1
    x[819]    c256      1
    x[820]    c245_1    -2318
    x[820]    c286_1    -2318
    x[820]    c255      1
    x[820]    c256      -1
    x[821]    c245_1    -2318
    x[821]    c286_1    -2318
    x[821]    c255      -1
    x[821]    c256      1
    x[822]    c206_1    -2346
    x[822]    c247_1    -2346
    x[822]    c257      1
    x[823]    c207_1    -2346
    x[823]    c248_1    -2346
    x[823]    c258      1
    x[824]    c209_1    -2346
    x[824]    c250_1    -2346
    x[824]    c259      1
    x[825]    c212_1    -2346
    x[825]    c253_1    -2346
    x[825]    c260      1
    x[826]    c216_1    -2346
    x[826]    c257_1    -2346
    x[826]    c261      1
    x[827]    c221_1    -2346
    x[827]    c262_1    -2346
    x[827]    c262      1
    x[828]    c227_1    -2346
    x[828]    c268_1    -2346
    x[828]    c263      1
    x[829]    c231_1    -2346
    x[829]    c272_1    -2346
    x[829]    c264      1
    x[830]    c238_1    -2346
    x[830]    c279_1    -2346
    x[830]    c265      1
    x[831]    c239_1    -2346
    x[831]    c280_1    -2346
    x[831]    c266      1
    x[832]    c240_1    -2346
    x[832]    c281_1    -2346
    x[832]    c267      1
    x[833]    c241_1    -2346
    x[833]    c282_1    -2346
    x[833]    c268      1
    x[834]    c242_1    -2346
    x[834]    c283_1    -2346
    x[834]    c269      1
    x[835]    c243_1    -2346
    x[835]    c284_1    -2346
    x[835]    c270      1
    x[836]    c244_1    -2346
    x[836]    c285_1    -2346
    x[836]    c271      1
    x[837]    c245_1    -2346
    x[837]    c286_1    -2346
    x[837]    c272      1
    x[838]    c246_1    -2346
    x[838]    c287_1    -2346
    x[838]    c273      1
    x[839]    c65_2     1
    x[839]    c206_1    -2346
    x[839]    c247_1    -2346
    x[839]    c274      1
    x[839]    c276      1
    x[840]    c66_2     1
    x[840]    c207_1    -2346
    x[840]    c248_1    -2346
    x[840]    c274      1
    x[840]    c277      1
    x[841]    c67_2     1
    x[841]    c209_1    -2346
    x[841]    c250_1    -2346
    x[841]    c274      1
    x[841]    c278      1
    x[842]    c68_2     1
    x[842]    c212_1    -2346
    x[842]    c253_1    -2346
    x[842]    c274      1
    x[842]    c279      1
    x[843]    c69_2     1
    x[843]    c216_1    -2346
    x[843]    c257_1    -2346
    x[843]    c274      1
    x[843]    c280      1
    x[844]    c70_2     1
    x[844]    c221_1    -2346
    x[844]    c262_1    -2346
    x[844]    c274      1
    x[844]    c281      1
    x[845]    c227_1    -2346
    x[845]    c268_1    -2346
    x[845]    c274      1
    x[845]    c282      1
    x[846]    c231_1    -2346
    x[846]    c272_1    -2346
    x[846]    c274      1
    x[846]    c283      1
    x[847]    c65_2     1
    x[847]    c66_2     1
    x[847]    c67_2     1
    x[847]    c68_2     1
    x[847]    c69_2     1
    x[847]    c70_2     1
    x[847]    c238_1    -2346
    x[847]    c279_1    -2346
    x[847]    c274      1
    x[847]    c275      1
    x[848]    c139_2    1
    x[848]    c140_2    1
    x[848]    c141_2    1
    x[848]    c142_2    1
    x[848]    c239_1    -2346
    x[848]    c280_1    -2346
    x[848]    c275      1
    x[848]    c276      -1
    x[849]    c139_2    1
    x[849]    c240_1    -2346
    x[849]    c281_1    -2346
    x[849]    c275      1
    x[849]    c277      -1
    x[850]    c140_2    1
    x[850]    c241_1    -2346
    x[850]    c282_1    -2346
    x[850]    c275      1
    x[850]    c278      -1
    x[851]    c242_1    -2346
    x[851]    c283_1    -2346
    x[851]    c275      1
    x[851]    c279      -1
    x[852]    c243_1    -2346
    x[852]    c284_1    -2346
    x[852]    c275      1
    x[852]    c280      -1
    x[853]    c141_2    1
    x[853]    c244_1    -2346
    x[853]    c285_1    -2346
    x[853]    c275      1
    x[853]    c281      -1
    x[854]    c245_1    -2346
    x[854]    c286_1    -2346
    x[854]    c275      1
    x[854]    c282      -1
    x[855]    c142_2    1
    x[855]    c246_1    -2346
    x[855]    c287_1    -2346
    x[855]    c275      1
    x[855]    c283      -1
    x[856]    c208_1    -2346
    x[856]    c249_1    -2346
    x[856]    c276      1
    x[856]    c277      -1
    x[857]    c210_1    -2346
    x[857]    c251_1    -2346
    x[857]    c276      1
    x[857]    c278      -1
    x[858]    c213_1    -2346
    x[858]    c254_1    -2346
    x[858]    c276      1
    x[858]    c279      -1
    x[859]    c217_1    -2346
    x[859]    c258_1    -2346
    x[859]    c276      1
    x[859]    c280      -1
    x[860]    c222_1    -2346
    x[860]    c263_1    -2346
    x[860]    c276      1
    x[860]    c281      -1
    x[861]    c208_1    -2346
    x[861]    c249_1    -2346
    x[861]    c276      -1
    x[861]    c277      1
    x[862]    c210_1    -2346
    x[862]    c251_1    -2346
    x[862]    c276      -1
    x[862]    c278      1
    x[863]    c213_1    -2346
    x[863]    c254_1    -2346
    x[863]    c276      -1
    x[863]    c279      1
    x[864]    c217_1    -2346
    x[864]    c258_1    -2346
    x[864]    c276      -1
    x[864]    c280      1
    x[865]    c222_1    -2346
    x[865]    c263_1    -2346
    x[865]    c276      -1
    x[865]    c281      1
    x[866]    c211_1    -2346
    x[866]    c252_1    -2346
    x[866]    c277      1
    x[866]    c278      -1
    x[867]    c214_1    -2346
    x[867]    c255_1    -2346
    x[867]    c277      1
    x[867]    c279      -1
    x[868]    c218_1    -2346
    x[868]    c259_1    -2346
    x[868]    c277      1
    x[868]    c280      -1
    x[869]    c223_1    -2346
    x[869]    c264_1    -2346
    x[869]    c277      1
    x[869]    c281      -1
    x[870]    c232_1    -2346
    x[870]    c273_1    -2346
    x[870]    c277      1
    x[870]    c283      -1
    x[871]    c211_1    -2346
    x[871]    c252_1    -2346
    x[871]    c277      -1
    x[871]    c278      1
    x[872]    c214_1    -2346
    x[872]    c255_1    -2346
    x[872]    c277      -1
    x[872]    c279      1
    x[873]    c218_1    -2346
    x[873]    c259_1    -2346
    x[873]    c277      -1
    x[873]    c280      1
    x[874]    c223_1    -2346
    x[874]    c264_1    -2346
    x[874]    c277      -1
    x[874]    c281      1
    x[875]    c232_1    -2346
    x[875]    c273_1    -2346
    x[875]    c277      -1
    x[875]    c283      1
    x[876]    c215_1    -2346
    x[876]    c256_1    -2346
    x[876]    c278      1
    x[876]    c279      -1
    x[877]    c219_1    -2346
    x[877]    c260_1    -2346
    x[877]    c278      1
    x[877]    c280      -1
    x[878]    c224_1    -2346
    x[878]    c265_1    -2346
    x[878]    c278      1
    x[878]    c281      -1
    x[879]    c233_1    -2346
    x[879]    c274_1    -2346
    x[879]    c278      1
    x[879]    c283      -1
    x[880]    c215_1    -2346
    x[880]    c256_1    -2346
    x[880]    c278      -1
    x[880]    c279      1
    x[881]    c219_1    -2346
    x[881]    c260_1    -2346
    x[881]    c278      -1
    x[881]    c280      1
    x[882]    c224_1    -2346
    x[882]    c265_1    -2346
    x[882]    c278      -1
    x[882]    c281      1
    x[883]    c233_1    -2346
    x[883]    c274_1    -2346
    x[883]    c278      -1
    x[883]    c283      1
    x[884]    c220_1    -2346
    x[884]    c261_1    -2346
    x[884]    c279      1
    x[884]    c280      -1
    x[885]    c225_1    -2346
    x[885]    c266_1    -2346
    x[885]    c279      1
    x[885]    c281      -1
    x[886]    c228_1    -2346
    x[886]    c269_1    -2346
    x[886]    c279      1
    x[886]    c282      -1
    x[887]    c234_1    -2346
    x[887]    c275_1    -2346
    x[887]    c279      1
    x[887]    c283      -1
    x[888]    c220_1    -2346
    x[888]    c261_1    -2346
    x[888]    c279      -1
    x[888]    c280      1
    x[889]    c225_1    -2346
    x[889]    c266_1    -2346
    x[889]    c279      -1
    x[889]    c281      1
    x[890]    c228_1    -2346
    x[890]    c269_1    -2346
    x[890]    c279      -1
    x[890]    c282      1
    x[891]    c234_1    -2346
    x[891]    c275_1    -2346
    x[891]    c279      -1
    x[891]    c283      1
    x[892]    c226_1    -2346
    x[892]    c267_1    -2346
    x[892]    c280      1
    x[892]    c281      -1
    x[893]    c229_1    -2346
    x[893]    c270_1    -2346
    x[893]    c280      1
    x[893]    c282      -1
    x[894]    c235_1    -2346
    x[894]    c276_1    -2346
    x[894]    c280      1
    x[894]    c283      -1
    x[895]    c226_1    -2346
    x[895]    c267_1    -2346
    x[895]    c280      -1
    x[895]    c281      1
    x[896]    c229_1    -2346
    x[896]    c270_1    -2346
    x[896]    c280      -1
    x[896]    c282      1
    x[897]    c235_1    -2346
    x[897]    c276_1    -2346
    x[897]    c280      -1
    x[897]    c283      1
    x[898]    c230_1    -2346
    x[898]    c271_1    -2346
    x[898]    c281      1
    x[898]    c282      -1
    x[899]    c236_1    -2346
    x[899]    c277_1    -2346
    x[899]    c281      1
    x[899]    c283      -1
    x[900]    c230_1    -2346
    x[900]    c271_1    -2346
    x[900]    c281      -1
    x[900]    c282      1
    x[901]    c236_1    -2346
    x[901]    c277_1    -2346
    x[901]    c281      -1
    x[901]    c283      1
    x[902]    c237_1    -2346
    x[902]    c278_1    -2346
    x[902]    c282      1
    x[902]    c283      -1
    x[903]    c237_1    -2346
    x[903]    c278_1    -2346
    x[903]    c282      -1
    x[903]    c283      1
    x[904]    c227_1    -9579
    x[904]    c268_1    -9579
    x[904]    c284      1
    x[905]    c228_1    -9579
    x[905]    c269_1    -9579
    x[905]    c285      1
    x[906]    c229_1    -9579
    x[906]    c270_1    -9579
    x[906]    c286      1
    x[907]    c230_1    -9579
    x[907]    c271_1    -9579
    x[907]    c287      1
    x[908]    c236_1    -9579
    x[908]    c277_1    -9579
    x[908]    c288      1
    x[909]    c244_1    -9579
    x[909]    c285_1    -9579
    x[909]    c289      1
    x[910]    c221_1    -9579
    x[910]    c262_1    -9579
    x[910]    c290      1
    x[911]    c222_1    -9579
    x[911]    c263_1    -9579
    x[911]    c291      1
    x[912]    c223_1    -9579
    x[912]    c264_1    -9579
    x[912]    c292      1
    x[913]    c224_1    -9579
    x[913]    c265_1    -9579
    x[913]    c293      1
    x[914]    c225_1    -9579
    x[914]    c266_1    -9579
    x[914]    c294      1
    x[915]    c226_1    -9579
    x[915]    c267_1    -9579
    x[915]    c295      1
    x[916]    c237_1    -9579
    x[916]    c278_1    -9579
    x[916]    c296      1
    x[917]    c245_1    -9579
    x[917]    c286_1    -9579
    x[917]    c297      1
    x[918]    c157_2    1
    x[918]    c237_1    -9579
    x[918]    c278_1    -9579
    x[918]    c298      1
    x[918]    c306      1
    x[919]    c158_2    1
    x[919]    c245_1    -9579
    x[919]    c286_1    -9579
    x[919]    c298      1
    x[919]    c307      1
    x[920]    c159_2    1
    x[920]    c227_1    -9579
    x[920]    c268_1    -9579
    x[920]    c298      1
    x[920]    c300      1
    x[921]    c228_1    -9579
    x[921]    c269_1    -9579
    x[921]    c298      1
    x[921]    c304      1
    x[922]    c160_2    1
    x[922]    c229_1    -9579
    x[922]    c270_1    -9579
    x[922]    c298      1
    x[922]    c305      1
    x[923]    c157_2    1
    x[923]    c158_2    1
    x[923]    c159_2    1
    x[923]    c160_2    1
    x[923]    c230_1    -9579
    x[923]    c271_1    -9579
    x[923]    c298      1
    x[923]    c299      1
    x[924]    c214_2    1
    x[924]    c221_1    -9579
    x[924]    c262_1    -9579
    x[924]    c299      1
    x[924]    c300      -1
    x[925]    c214_2    1
    x[925]    c222_1    -9579
    x[925]    c263_1    -9579
    x[925]    c299      1
    x[925]    c301      -1
    x[926]    c223_1    -9579
    x[926]    c264_1    -9579
    x[926]    c299      1
    x[926]    c302      -1
    x[927]    c224_1    -9579
    x[927]    c265_1    -9579
    x[927]    c299      1
    x[927]    c303      -1
    x[928]    c225_1    -9579
    x[928]    c266_1    -9579
    x[928]    c299      1
    x[928]    c304      -1
    x[929]    c226_1    -9579
    x[929]    c267_1    -9579
    x[929]    c299      1
    x[929]    c305      -1
    x[930]    c236_1    -9579
    x[930]    c277_1    -9579
    x[930]    c299      1
    x[930]    c306      -1
    x[931]    c244_1    -9579
    x[931]    c285_1    -9579
    x[931]    c299      1
    x[931]    c307      -1
    x[932]    c206_1    -9579
    x[932]    c247_1    -9579
    x[932]    c300      1
    x[932]    c301      -1
    x[933]    c207_1    -9579
    x[933]    c248_1    -9579
    x[933]    c300      1
    x[933]    c302      -1
    x[934]    c209_1    -9579
    x[934]    c250_1    -9579
    x[934]    c300      1
    x[934]    c303      -1
    x[935]    c212_1    -9579
    x[935]    c253_1    -9579
    x[935]    c300      1
    x[935]    c304      -1
    x[936]    c216_1    -9579
    x[936]    c257_1    -9579
    x[936]    c300      1
    x[936]    c305      -1
    x[937]    c231_1    -9579
    x[937]    c272_1    -9579
    x[937]    c300      1
    x[937]    c306      -1
    x[938]    c238_1    -9579
    x[938]    c279_1    -9579
    x[938]    c300      1
    x[938]    c307      -1
    x[939]    c206_1    -9579
    x[939]    c247_1    -9579
    x[939]    c300      -1
    x[939]    c301      1
    x[940]    c207_1    -9579
    x[940]    c248_1    -9579
    x[940]    c300      -1
    x[940]    c302      1
    x[941]    c209_1    -9579
    x[941]    c250_1    -9579
    x[941]    c300      -1
    x[941]    c303      1
    x[942]    c212_1    -9579
    x[942]    c253_1    -9579
    x[942]    c300      -1
    x[942]    c304      1
    x[943]    c216_1    -9579
    x[943]    c257_1    -9579
    x[943]    c300      -1
    x[943]    c305      1
    x[944]    c231_1    -9579
    x[944]    c272_1    -9579
    x[944]    c300      -1
    x[944]    c306      1
    x[945]    c238_1    -9579
    x[945]    c279_1    -9579
    x[945]    c300      -1
    x[945]    c307      1
    x[946]    c208_1    -9579
    x[946]    c249_1    -9579
    x[946]    c301      1
    x[946]    c302      -1
    x[947]    c210_1    -9579
    x[947]    c251_1    -9579
    x[947]    c301      1
    x[947]    c303      -1
    x[948]    c213_1    -9579
    x[948]    c254_1    -9579
    x[948]    c301      1
    x[948]    c304      -1
    x[949]    c217_1    -9579
    x[949]    c258_1    -9579
    x[949]    c301      1
    x[949]    c305      -1
    x[950]    c239_1    -9579
    x[950]    c280_1    -9579
    x[950]    c301      1
    x[950]    c307      -1
    x[951]    c208_1    -9579
    x[951]    c249_1    -9579
    x[951]    c301      -1
    x[951]    c302      1
    x[952]    c210_1    -9579
    x[952]    c251_1    -9579
    x[952]    c301      -1
    x[952]    c303      1
    x[953]    c213_1    -9579
    x[953]    c254_1    -9579
    x[953]    c301      -1
    x[953]    c304      1
    x[954]    c217_1    -9579
    x[954]    c258_1    -9579
    x[954]    c301      -1
    x[954]    c305      1
    x[955]    c239_1    -9579
    x[955]    c280_1    -9579
    x[955]    c301      -1
    x[955]    c307      1
    x[956]    c211_1    -9579
    x[956]    c252_1    -9579
    x[956]    c302      1
    x[956]    c303      -1
    x[957]    c214_1    -9579
    x[957]    c255_1    -9579
    x[957]    c302      1
    x[957]    c304      -1
    x[958]    c218_1    -9579
    x[958]    c259_1    -9579
    x[958]    c302      1
    x[958]    c305      -1
    x[959]    c232_1    -9579
    x[959]    c273_1    -9579
    x[959]    c302      1
    x[959]    c306      -1
    x[960]    c240_1    -9579
    x[960]    c281_1    -9579
    x[960]    c302      1
    x[960]    c307      -1
    x[961]    c211_1    -9579
    x[961]    c252_1    -9579
    x[961]    c302      -1
    x[961]    c303      1
    x[962]    c214_1    -9579
    x[962]    c255_1    -9579
    x[962]    c302      -1
    x[962]    c304      1
    x[963]    c218_1    -9579
    x[963]    c259_1    -9579
    x[963]    c302      -1
    x[963]    c305      1
    x[964]    c232_1    -9579
    x[964]    c273_1    -9579
    x[964]    c302      -1
    x[964]    c306      1
    x[965]    c240_1    -9579
    x[965]    c281_1    -9579
    x[965]    c302      -1
    x[965]    c307      1
    x[966]    c215_1    -9579
    x[966]    c256_1    -9579
    x[966]    c303      1
    x[966]    c304      -1
    x[967]    c219_1    -9579
    x[967]    c260_1    -9579
    x[967]    c303      1
    x[967]    c305      -1
    x[968]    c233_1    -9579
    x[968]    c274_1    -9579
    x[968]    c303      1
    x[968]    c306      -1
    x[969]    c241_1    -9579
    x[969]    c282_1    -9579
    x[969]    c303      1
    x[969]    c307      -1
    x[970]    c215_1    -9579
    x[970]    c256_1    -9579
    x[970]    c303      -1
    x[970]    c304      1
    x[971]    c219_1    -9579
    x[971]    c260_1    -9579
    x[971]    c303      -1
    x[971]    c305      1
    x[972]    c233_1    -9579
    x[972]    c274_1    -9579
    x[972]    c303      -1
    x[972]    c306      1
    x[973]    c241_1    -9579
    x[973]    c282_1    -9579
    x[973]    c303      -1
    x[973]    c307      1
    x[974]    c220_1    -9579
    x[974]    c261_1    -9579
    x[974]    c304      1
    x[974]    c305      -1
    x[975]    c234_1    -9579
    x[975]    c275_1    -9579
    x[975]    c304      1
    x[975]    c306      -1
    x[976]    c242_1    -9579
    x[976]    c283_1    -9579
    x[976]    c304      1
    x[976]    c307      -1
    x[977]    c220_1    -9579
    x[977]    c261_1    -9579
    x[977]    c304      -1
    x[977]    c305      1
    x[978]    c234_1    -9579
    x[978]    c275_1    -9579
    x[978]    c304      -1
    x[978]    c306      1
    x[979]    c242_1    -9579
    x[979]    c283_1    -9579
    x[979]    c304      -1
    x[979]    c307      1
    x[980]    c235_1    -9579
    x[980]    c276_1    -9579
    x[980]    c305      1
    x[980]    c306      -1
    x[981]    c243_1    -9579
    x[981]    c284_1    -9579
    x[981]    c305      1
    x[981]    c307      -1
    x[982]    c235_1    -9579
    x[982]    c276_1    -9579
    x[982]    c305      -1
    x[982]    c306      1
    x[983]    c243_1    -9579
    x[983]    c284_1    -9579
    x[983]    c305      -1
    x[983]    c307      1
    x[984]    c246_1    -9579
    x[984]    c287_1    -9579
    x[984]    c306      1
    x[984]    c307      -1
    x[985]    c246_1    -9579
    x[985]    c287_1    -9579
    x[985]    c306      -1
    x[985]    c307      1
    x[986]    c206_1    -1865
    x[986]    c247_1    -1865
    x[986]    c308      1
    x[987]    c211_1    -1865
    x[987]    c252_1    -1865
    x[987]    c309      1
    x[988]    c214_1    -1865
    x[988]    c255_1    -1865
    x[988]    c310      1
    x[989]    c218_1    -1865
    x[989]    c259_1    -1865
    x[989]    c311      1
    x[990]    c223_1    -1865
    x[990]    c264_1    -1865
    x[990]    c312      1
    x[991]    c232_1    -1865
    x[991]    c273_1    -1865
    x[991]    c313      1
    x[992]    c240_1    -1865
    x[992]    c281_1    -1865
    x[992]    c314      1
    x[993]    c207_1    -1865
    x[993]    c248_1    -1865
    x[993]    c315      1
    x[994]    c208_1    -1865
    x[994]    c249_1    -1865
    x[994]    c316      1
    x[995]    c210_1    -1865
    x[995]    c251_1    -1865
    x[995]    c317      1
    x[996]    c213_1    -1865
    x[996]    c254_1    -1865
    x[996]    c318      1
    x[997]    c217_1    -1865
    x[997]    c258_1    -1865
    x[997]    c319      1
    x[998]    c222_1    -1865
    x[998]    c263_1    -1865
    x[998]    c320      1
    x[999]    c239_1    -1865
    x[999]    c280_1    -1865
    x[999]    c321      1
    x[1000]   c252_2    1
    x[1000]   c253_2    1
    x[1000]   c254_2    1
    x[1000]   c255_2    1
    x[1000]   c208_1    -1865
    x[1000]   c249_1    -1865
    x[1000]   c322      1
    x[1000]   c323      1
    x[1001]   c262_2    1
    x[1001]   c210_1    -1865
    x[1001]   c251_1    -1865
    x[1001]   c322      1
    x[1001]   c325      1
    x[1002]   c252_2    1
    x[1002]   c262_2    1
    x[1002]   c213_1    -1865
    x[1002]   c254_1    -1865
    x[1002]   c322      1
    x[1002]   c326      1
    x[1003]   c253_2    1
    x[1003]   c217_1    -1865
    x[1003]   c258_1    -1865
    x[1003]   c322      1
    x[1003]   c327      1
    x[1004]   c222_1    -1865
    x[1004]   c263_1    -1865
    x[1004]   c322      1
    x[1004]   c328      1
    x[1005]   c254_2    1
    x[1005]   c239_1    -1865
    x[1005]   c280_1    -1865
    x[1005]   c322      1
    x[1005]   c331      1
    x[1006]   c255_2    1
    x[1006]   c206_1    -1865
    x[1006]   c247_1    -1865
    x[1006]   c322      1
    x[1006]   c324      1
    x[1007]   c207_1    -1865
    x[1007]   c248_1    -1865
    x[1007]   c323      1
    x[1007]   c324      -1
    x[1008]   c211_1    -1865
    x[1008]   c252_1    -1865
    x[1008]   c323      1
    x[1008]   c325      -1
    x[1009]   c214_1    -1865
    x[1009]   c255_1    -1865
    x[1009]   c323      1
    x[1009]   c326      -1
    x[1010]   c218_1    -1865
    x[1010]   c259_1    -1865
    x[1010]   c323      1
    x[1010]   c327      -1
    x[1011]   c223_1    -1865
    x[1011]   c264_1    -1865
    x[1011]   c323      1
    x[1011]   c328      -1
    x[1012]   c232_1    -1865
    x[1012]   c273_1    -1865
    x[1012]   c323      1
    x[1012]   c330      -1
    x[1013]   c240_1    -1865
    x[1013]   c281_1    -1865
    x[1013]   c323      1
    x[1013]   c331      -1
    x[1014]   c209_1    -1865
    x[1014]   c250_1    -1865
    x[1014]   c324      1
    x[1014]   c325      -1
    x[1015]   c212_1    -1865
    x[1015]   c253_1    -1865
    x[1015]   c324      1
    x[1015]   c326      -1
    x[1016]   c216_1    -1865
    x[1016]   c257_1    -1865
    x[1016]   c324      1
    x[1016]   c327      -1
    x[1017]   c221_1    -1865
    x[1017]   c262_1    -1865
    x[1017]   c324      1
    x[1017]   c328      -1
    x[1018]   c227_1    -1865
    x[1018]   c268_1    -1865
    x[1018]   c324      1
    x[1018]   c329      -1
    x[1019]   c231_1    -1865
    x[1019]   c272_1    -1865
    x[1019]   c324      1
    x[1019]   c330      -1
    x[1020]   c238_1    -1865
    x[1020]   c279_1    -1865
    x[1020]   c324      1
    x[1020]   c331      -1
    x[1021]   c209_1    -1865
    x[1021]   c250_1    -1865
    x[1021]   c324      -1
    x[1021]   c325      1
    x[1022]   c212_1    -1865
    x[1022]   c253_1    -1865
    x[1022]   c324      -1
    x[1022]   c326      1
    x[1023]   c216_1    -1865
    x[1023]   c257_1    -1865
    x[1023]   c324      -1
    x[1023]   c327      1
    x[1024]   c221_1    -1865
    x[1024]   c262_1    -1865
    x[1024]   c324      -1
    x[1024]   c328      1
    x[1025]   c227_1    -1865
    x[1025]   c268_1    -1865
    x[1025]   c324      -1
    x[1025]   c329      1
    x[1026]   c231_1    -1865
    x[1026]   c272_1    -1865
    x[1026]   c324      -1
    x[1026]   c330      1
    x[1027]   c238_1    -1865
    x[1027]   c279_1    -1865
    x[1027]   c324      -1
    x[1027]   c331      1
    x[1028]   c215_1    -1865
    x[1028]   c256_1    -1865
    x[1028]   c325      1
    x[1028]   c326      -1
    x[1029]   c219_1    -1865
    x[1029]   c260_1    -1865
    x[1029]   c325      1
    x[1029]   c327      -1
    x[1030]   c224_1    -1865
    x[1030]   c265_1    -1865
    x[1030]   c325      1
    x[1030]   c328      -1
    x[1031]   c233_1    -1865
    x[1031]   c274_1    -1865
    x[1031]   c325      1
    x[1031]   c330      -1
    x[1032]   c241_1    -1865
    x[1032]   c282_1    -1865
    x[1032]   c325      1
    x[1032]   c331      -1
    x[1033]   c215_1    -1865
    x[1033]   c256_1    -1865
    x[1033]   c325      -1
    x[1033]   c326      1
    x[1034]   c219_1    -1865
    x[1034]   c260_1    -1865
    x[1034]   c325      -1
    x[1034]   c327      1
    x[1035]   c224_1    -1865
    x[1035]   c265_1    -1865
    x[1035]   c325      -1
    x[1035]   c328      1
    x[1036]   c233_1    -1865
    x[1036]   c274_1    -1865
    x[1036]   c325      -1
    x[1036]   c330      1
    x[1037]   c241_1    -1865
    x[1037]   c282_1    -1865
    x[1037]   c325      -1
    x[1037]   c331      1
    x[1038]   c220_1    -1865
    x[1038]   c261_1    -1865
    x[1038]   c326      1
    x[1038]   c327      -1
    x[1039]   c225_1    -1865
    x[1039]   c266_1    -1865
    x[1039]   c326      1
    x[1039]   c328      -1
    x[1040]   c228_1    -1865
    x[1040]   c269_1    -1865
    x[1040]   c326      1
    x[1040]   c329      -1
    x[1041]   c234_1    -1865
    x[1041]   c275_1    -1865
    x[1041]   c326      1
    x[1041]   c330      -1
    x[1042]   c242_1    -1865
    x[1042]   c283_1    -1865
    x[1042]   c326      1
    x[1042]   c331      -1
    x[1043]   c220_1    -1865
    x[1043]   c261_1    -1865
    x[1043]   c326      -1
    x[1043]   c327      1
    x[1044]   c225_1    -1865
    x[1044]   c266_1    -1865
    x[1044]   c326      -1
    x[1044]   c328      1
    x[1045]   c228_1    -1865
    x[1045]   c269_1    -1865
    x[1045]   c326      -1
    x[1045]   c329      1
    x[1046]   c234_1    -1865
    x[1046]   c275_1    -1865
    x[1046]   c326      -1
    x[1046]   c330      1
    x[1047]   c242_1    -1865
    x[1047]   c283_1    -1865
    x[1047]   c326      -1
    x[1047]   c331      1
    x[1048]   c226_1    -1865
    x[1048]   c267_1    -1865
    x[1048]   c327      1
    x[1048]   c328      -1
    x[1049]   c229_1    -1865
    x[1049]   c270_1    -1865
    x[1049]   c327      1
    x[1049]   c329      -1
    x[1050]   c235_1    -1865
    x[1050]   c276_1    -1865
    x[1050]   c327      1
    x[1050]   c330      -1
    x[1051]   c243_1    -1865
    x[1051]   c284_1    -1865
    x[1051]   c327      1
    x[1051]   c331      -1
    x[1052]   c226_1    -1865
    x[1052]   c267_1    -1865
    x[1052]   c327      -1
    x[1052]   c328      1
    x[1053]   c229_1    -1865
    x[1053]   c270_1    -1865
    x[1053]   c327      -1
    x[1053]   c329      1
    x[1054]   c235_1    -1865
    x[1054]   c276_1    -1865
    x[1054]   c327      -1
    x[1054]   c330      1
    x[1055]   c243_1    -1865
    x[1055]   c284_1    -1865
    x[1055]   c327      -1
    x[1055]   c331      1
    x[1056]   c230_1    -1865
    x[1056]   c271_1    -1865
    x[1056]   c328      1
    x[1056]   c329      -1
    x[1057]   c236_1    -1865
    x[1057]   c277_1    -1865
    x[1057]   c328      1
    x[1057]   c330      -1
    x[1058]   c244_1    -1865
    x[1058]   c285_1    -1865
    x[1058]   c328      1
    x[1058]   c331      -1
    x[1059]   c230_1    -1865
    x[1059]   c271_1    -1865
    x[1059]   c328      -1
    x[1059]   c329      1
    x[1060]   c236_1    -1865
    x[1060]   c277_1    -1865
    x[1060]   c328      -1
    x[1060]   c330      1
    x[1061]   c244_1    -1865
    x[1061]   c285_1    -1865
    x[1061]   c328      -1
    x[1061]   c331      1
    x[1062]   c237_1    -1865
    x[1062]   c278_1    -1865
    x[1062]   c329      1
    x[1062]   c330      -1
    x[1063]   c245_1    -1865
    x[1063]   c286_1    -1865
    x[1063]   c329      1
    x[1063]   c331      -1
    x[1064]   c237_1    -1865
    x[1064]   c278_1    -1865
    x[1064]   c329      -1
    x[1064]   c330      1
    x[1065]   c245_1    -1865
    x[1065]   c286_1    -1865
    x[1065]   c329      -1
    x[1065]   c331      1
    x[1066]   c246_1    -1865
    x[1066]   c287_1    -1865
    x[1066]   c330      1
    x[1066]   c331      -1
    x[1067]   c246_1    -1865
    x[1067]   c287_1    -1865
    x[1067]   c330      -1
    x[1067]   c331      1
    x[1068]   c226_1    -4056
    x[1068]   c267_1    -4056
    x[1068]   c332      1
    x[1069]   c229_1    -4056
    x[1069]   c270_1    -4056
    x[1069]   c333      1
    x[1070]   c235_1    -4056
    x[1070]   c276_1    -4056
    x[1070]   c334      1
    x[1071]   c238_1    -4056
    x[1071]   c279_1    -4056
    x[1071]   c335      1
    x[1072]   c239_1    -4056
    x[1072]   c280_1    -4056
    x[1072]   c336      1
    x[1073]   c240_1    -4056
    x[1073]   c281_1    -4056
    x[1073]   c337      1
    x[1074]   c241_1    -4056
    x[1074]   c282_1    -4056
    x[1074]   c338      1
    x[1075]   c242_1    -4056
    x[1075]   c283_1    -4056
    x[1075]   c339      1
    x[1076]   c243_1    -4056
    x[1076]   c284_1    -4056
    x[1076]   c340      1
    x[1077]   c244_1    -4056
    x[1077]   c285_1    -4056
    x[1077]   c341      1
    x[1078]   c245_1    -4056
    x[1078]   c286_1    -4056
    x[1078]   c342      1
    x[1079]   c246_1    -4056
    x[1079]   c287_1    -4056
    x[1079]   c343      1
    x[1080]   c216_1    -4056
    x[1080]   c257_1    -4056
    x[1080]   c344      1
    x[1081]   c217_1    -4056
    x[1081]   c258_1    -4056
    x[1081]   c345      1
    x[1082]   c218_1    -4056
    x[1082]   c259_1    -4056
    x[1082]   c346      1
    x[1083]   c219_1    -4056
    x[1083]   c260_1    -4056
    x[1083]   c347      1
    x[1084]   c220_1    -4056
    x[1084]   c261_1    -4056
    x[1084]   c348      1
    x[1085]   c238_1    -4056
    x[1085]   c279_1    -4056
    x[1085]   c349      1
    x[1085]   c351      1
    x[1086]   c239_1    -4056
    x[1086]   c280_1    -4056
    x[1086]   c349      1
    x[1086]   c352      1
    x[1087]   c240_1    -4056
    x[1087]   c281_1    -4056
    x[1087]   c349      1
    x[1087]   c353      1
    x[1088]   c241_1    -4056
    x[1088]   c282_1    -4056
    x[1088]   c349      1
    x[1088]   c354      1
    x[1089]   c242_1    -4056
    x[1089]   c283_1    -4056
    x[1089]   c349      1
    x[1089]   c355      1
    x[1090]   c243_1    -4056
    x[1090]   c284_1    -4056
    x[1090]   c349      1
    x[1090]   c350      1
    x[1091]   c244_1    -4056
    x[1091]   c285_1    -4056
    x[1091]   c349      1
    x[1091]   c356      1
    x[1092]   c245_1    -4056
    x[1092]   c286_1    -4056
    x[1092]   c349      1
    x[1092]   c357      1
    x[1093]   c246_1    -4056
    x[1093]   c287_1    -4056
    x[1093]   c349      1
    x[1093]   c358      1
    x[1094]   c47_2     1
    x[1094]   c48_2     1
    x[1094]   c49_2     1
    x[1094]   c50_2     1
    x[1094]   c51_2     1
    x[1094]   c216_1    -4056
    x[1094]   c257_1    -4056
    x[1094]   c350      1
    x[1094]   c351      -1
    x[1095]   c217_1    -4056
    x[1095]   c258_1    -4056
    x[1095]   c350      1
    x[1095]   c352      -1
    x[1096]   c47_2     1
    x[1096]   c218_1    -4056
    x[1096]   c259_1    -4056
    x[1096]   c350      1
    x[1096]   c353      -1
    x[1097]   c48_2     1
    x[1097]   c219_1    -4056
    x[1097]   c260_1    -4056
    x[1097]   c350      1
    x[1097]   c354      -1
    x[1098]   c49_2     1
    x[1098]   c220_1    -4056
    x[1098]   c261_1    -4056
    x[1098]   c350      1
    x[1098]   c355      -1
    x[1099]   c50_2     1
    x[1099]   c226_1    -4056
    x[1099]   c267_1    -4056
    x[1099]   c350      1
    x[1099]   c356      -1
    x[1100]   c229_1    -4056
    x[1100]   c270_1    -4056
    x[1100]   c350      1
    x[1100]   c357      -1
    x[1101]   c51_2     1
    x[1101]   c235_1    -4056
    x[1101]   c276_1    -4056
    x[1101]   c350      1
    x[1101]   c358      -1
    x[1102]   c206_1    -4056
    x[1102]   c247_1    -4056
    x[1102]   c351      1
    x[1102]   c352      -1
    x[1103]   c207_1    -4056
    x[1103]   c248_1    -4056
    x[1103]   c351      1
    x[1103]   c353      -1
    x[1104]   c209_1    -4056
    x[1104]   c250_1    -4056
    x[1104]   c351      1
    x[1104]   c354      -1
    x[1105]   c212_1    -4056
    x[1105]   c253_1    -4056
    x[1105]   c351      1
    x[1105]   c355      -1
    x[1106]   c221_1    -4056
    x[1106]   c262_1    -4056
    x[1106]   c351      1
    x[1106]   c356      -1
    x[1107]   c227_1    -4056
    x[1107]   c268_1    -4056
    x[1107]   c351      1
    x[1107]   c357      -1
    x[1108]   c231_1    -4056
    x[1108]   c272_1    -4056
    x[1108]   c351      1
    x[1108]   c358      -1
    x[1109]   c206_1    -4056
    x[1109]   c247_1    -4056
    x[1109]   c351      -1
    x[1109]   c352      1
    x[1110]   c207_1    -4056
    x[1110]   c248_1    -4056
    x[1110]   c351      -1
    x[1110]   c353      1
    x[1111]   c209_1    -4056
    x[1111]   c250_1    -4056
    x[1111]   c351      -1
    x[1111]   c354      1
    x[1112]   c212_1    -4056
    x[1112]   c253_1    -4056
    x[1112]   c351      -1
    x[1112]   c355      1
    x[1113]   c221_1    -4056
    x[1113]   c262_1    -4056
    x[1113]   c351      -1
    x[1113]   c356      1
    x[1114]   c227_1    -4056
    x[1114]   c268_1    -4056
    x[1114]   c351      -1
    x[1114]   c357      1
    x[1115]   c231_1    -4056
    x[1115]   c272_1    -4056
    x[1115]   c351      -1
    x[1115]   c358      1
    x[1116]   c208_1    -4056
    x[1116]   c249_1    -4056
    x[1116]   c352      1
    x[1116]   c353      -1
    x[1117]   c210_1    -4056
    x[1117]   c251_1    -4056
    x[1117]   c352      1
    x[1117]   c354      -1
    x[1118]   c213_1    -4056
    x[1118]   c254_1    -4056
    x[1118]   c352      1
    x[1118]   c355      -1
    x[1119]   c222_1    -4056
    x[1119]   c263_1    -4056
    x[1119]   c352      1
    x[1119]   c356      -1
    x[1120]   c208_1    -4056
    x[1120]   c249_1    -4056
    x[1120]   c352      -1
    x[1120]   c353      1
    x[1121]   c210_1    -4056
    x[1121]   c251_1    -4056
    x[1121]   c352      -1
    x[1121]   c354      1
    x[1122]   c213_1    -4056
    x[1122]   c254_1    -4056
    x[1122]   c352      -1
    x[1122]   c355      1
    x[1123]   c222_1    -4056
    x[1123]   c263_1    -4056
    x[1123]   c352      -1
    x[1123]   c356      1
    x[1124]   c211_1    -4056
    x[1124]   c252_1    -4056
    x[1124]   c353      1
    x[1124]   c354      -1
    x[1125]   c214_1    -4056
    x[1125]   c255_1    -4056
    x[1125]   c353      1
    x[1125]   c355      -1
    x[1126]   c223_1    -4056
    x[1126]   c264_1    -4056
    x[1126]   c353      1
    x[1126]   c356      -1
    x[1127]   c232_1    -4056
    x[1127]   c273_1    -4056
    x[1127]   c353      1
    x[1127]   c358      -1
    x[1128]   c211_1    -4056
    x[1128]   c252_1    -4056
    x[1128]   c353      -1
    x[1128]   c354      1
    x[1129]   c214_1    -4056
    x[1129]   c255_1    -4056
    x[1129]   c353      -1
    x[1129]   c355      1
    x[1130]   c223_1    -4056
    x[1130]   c264_1    -4056
    x[1130]   c353      -1
    x[1130]   c356      1
    x[1131]   c232_1    -4056
    x[1131]   c273_1    -4056
    x[1131]   c353      -1
    x[1131]   c358      1
    x[1132]   c215_1    -4056
    x[1132]   c256_1    -4056
    x[1132]   c354      1
    x[1132]   c355      -1
    x[1133]   c224_1    -4056
    x[1133]   c265_1    -4056
    x[1133]   c354      1
    x[1133]   c356      -1
    x[1134]   c233_1    -4056
    x[1134]   c274_1    -4056
    x[1134]   c354      1
    x[1134]   c358      -1
    x[1135]   c215_1    -4056
    x[1135]   c256_1    -4056
    x[1135]   c354      -1
    x[1135]   c355      1
    x[1136]   c224_1    -4056
    x[1136]   c265_1    -4056
    x[1136]   c354      -1
    x[1136]   c356      1
    x[1137]   c233_1    -4056
    x[1137]   c274_1    -4056
    x[1137]   c354      -1
    x[1137]   c358      1
    x[1138]   c225_1    -4056
    x[1138]   c266_1    -4056
    x[1138]   c355      1
    x[1138]   c356      -1
    x[1139]   c228_1    -4056
    x[1139]   c269_1    -4056
    x[1139]   c355      1
    x[1139]   c357      -1
    x[1140]   c234_1    -4056
    x[1140]   c275_1    -4056
    x[1140]   c355      1
    x[1140]   c358      -1
    x[1141]   c225_1    -4056
    x[1141]   c266_1    -4056
    x[1141]   c355      -1
    x[1141]   c356      1
    x[1142]   c228_1    -4056
    x[1142]   c269_1    -4056
    x[1142]   c355      -1
    x[1142]   c357      1
    x[1143]   c234_1    -4056
    x[1143]   c275_1    -4056
    x[1143]   c355      -1
    x[1143]   c358      1
    x[1144]   c230_1    -4056
    x[1144]   c271_1    -4056
    x[1144]   c356      1
    x[1144]   c357      -1
    x[1145]   c236_1    -4056
    x[1145]   c277_1    -4056
    x[1145]   c356      1
    x[1145]   c358      -1
    x[1146]   c230_1    -4056
    x[1146]   c271_1    -4056
    x[1146]   c356      -1
    x[1146]   c357      1
    x[1147]   c236_1    -4056
    x[1147]   c277_1    -4056
    x[1147]   c356      -1
    x[1147]   c358      1
    x[1148]   c237_1    -4056
    x[1148]   c278_1    -4056
    x[1148]   c357      1
    x[1148]   c358      -1
    x[1149]   c237_1    -4056
    x[1149]   c278_1    -4056
    x[1149]   c357      -1
    x[1149]   c358      1
    x[1150]   c206_1    -1346
    x[1150]   c247_1    -1346
    x[1150]   c359      1
    x[1151]   c215_1    -1346
    x[1151]   c256_1    -1346
    x[1151]   c360      1
    x[1152]   c219_1    -1346
    x[1152]   c260_1    -1346
    x[1152]   c361      1
    x[1153]   c224_1    -1346
    x[1153]   c265_1    -1346
    x[1153]   c362      1
    x[1154]   c233_1    -1346
    x[1154]   c274_1    -1346
    x[1154]   c363      1
    x[1155]   c241_1    -1346
    x[1155]   c282_1    -1346
    x[1155]   c364      1
    x[1156]   c208_1    -1346
    x[1156]   c249_1    -1346
    x[1156]   c365      1
    x[1157]   c209_1    -1346
    x[1157]   c250_1    -1346
    x[1157]   c366      1
    x[1158]   c210_1    -1346
    x[1158]   c251_1    -1346
    x[1158]   c367      1
    x[1159]   c211_1    -1346
    x[1159]   c252_1    -1346
    x[1159]   c368      1
    x[1160]   c213_1    -1346
    x[1160]   c254_1    -1346
    x[1160]   c369      1
    x[1161]   c217_1    -1346
    x[1161]   c258_1    -1346
    x[1161]   c370      1
    x[1162]   c222_1    -1346
    x[1162]   c263_1    -1346
    x[1162]   c371      1
    x[1163]   c239_1    -1346
    x[1163]   c280_1    -1346
    x[1163]   c372      1
    x[1164]   c208_1    -1346
    x[1164]   c249_1    -1346
    x[1164]   c373      1
    x[1164]   c376      1
    x[1165]   c210_1    -1346
    x[1165]   c251_1    -1346
    x[1165]   c373      1
    x[1165]   c374      1
    x[1166]   c213_1    -1346
    x[1166]   c254_1    -1346
    x[1166]   c373      1
    x[1166]   c377      1
    x[1167]   c217_1    -1346
    x[1167]   c258_1    -1346
    x[1167]   c373      1
    x[1167]   c378      1
    x[1168]   c222_1    -1346
    x[1168]   c263_1    -1346
    x[1168]   c373      1
    x[1168]   c379      1
    x[1169]   c239_1    -1346
    x[1169]   c280_1    -1346
    x[1169]   c373      1
    x[1169]   c382      1
    x[1170]   c206_1    -1346
    x[1170]   c247_1    -1346
    x[1170]   c373      1
    x[1170]   c375      1
    x[1171]   c209_1    -1346
    x[1171]   c250_1    -1346
    x[1171]   c374      1
    x[1171]   c375      -1
    x[1172]   c211_1    -1346
    x[1172]   c252_1    -1346
    x[1172]   c374      1
    x[1172]   c376      -1
    x[1173]   c215_1    -1346
    x[1173]   c256_1    -1346
    x[1173]   c374      1
    x[1173]   c377      -1
    x[1174]   c219_1    -1346
    x[1174]   c260_1    -1346
    x[1174]   c374      1
    x[1174]   c378      -1
    x[1175]   c224_1    -1346
    x[1175]   c265_1    -1346
    x[1175]   c374      1
    x[1175]   c379      -1
    x[1176]   c233_1    -1346
    x[1176]   c274_1    -1346
    x[1176]   c374      1
    x[1176]   c381      -1
    x[1177]   c241_1    -1346
    x[1177]   c282_1    -1346
    x[1177]   c374      1
    x[1177]   c382      -1
    x[1178]   c207_1    -1346
    x[1178]   c248_1    -1346
    x[1178]   c375      1
    x[1178]   c376      -1
    x[1179]   c212_1    -1346
    x[1179]   c253_1    -1346
    x[1179]   c375      1
    x[1179]   c377      -1
    x[1180]   c216_1    -1346
    x[1180]   c257_1    -1346
    x[1180]   c375      1
    x[1180]   c378      -1
    x[1181]   c221_1    -1346
    x[1181]   c262_1    -1346
    x[1181]   c375      1
    x[1181]   c379      -1
    x[1182]   c227_1    -1346
    x[1182]   c268_1    -1346
    x[1182]   c375      1
    x[1182]   c380      -1
    x[1183]   c231_1    -1346
    x[1183]   c272_1    -1346
    x[1183]   c375      1
    x[1183]   c381      -1
    x[1184]   c238_1    -1346
    x[1184]   c279_1    -1346
    x[1184]   c375      1
    x[1184]   c382      -1
    x[1185]   c207_1    -1346
    x[1185]   c248_1    -1346
    x[1185]   c375      -1
    x[1185]   c376      1
    x[1186]   c212_1    -1346
    x[1186]   c253_1    -1346
    x[1186]   c375      -1
    x[1186]   c377      1
    x[1187]   c216_1    -1346
    x[1187]   c257_1    -1346
    x[1187]   c375      -1
    x[1187]   c378      1
    x[1188]   c221_1    -1346
    x[1188]   c262_1    -1346
    x[1188]   c375      -1
    x[1188]   c379      1
    x[1189]   c227_1    -1346
    x[1189]   c268_1    -1346
    x[1189]   c375      -1
    x[1189]   c380      1
    x[1190]   c231_1    -1346
    x[1190]   c272_1    -1346
    x[1190]   c375      -1
    x[1190]   c381      1
    x[1191]   c238_1    -1346
    x[1191]   c279_1    -1346
    x[1191]   c375      -1
    x[1191]   c382      1
    x[1192]   c214_1    -1346
    x[1192]   c255_1    -1346
    x[1192]   c376      1
    x[1192]   c377      -1
    x[1193]   c218_1    -1346
    x[1193]   c259_1    -1346
    x[1193]   c376      1
    x[1193]   c378      -1
    x[1194]   c223_1    -1346
    x[1194]   c264_1    -1346
    x[1194]   c376      1
    x[1194]   c379      -1
    x[1195]   c232_1    -1346
    x[1195]   c273_1    -1346
    x[1195]   c376      1
    x[1195]   c381      -1
    x[1196]   c240_1    -1346
    x[1196]   c281_1    -1346
    x[1196]   c376      1
    x[1196]   c382      -1
    x[1197]   c214_1    -1346
    x[1197]   c255_1    -1346
    x[1197]   c376      -1
    x[1197]   c377      1
    x[1198]   c218_1    -1346
    x[1198]   c259_1    -1346
    x[1198]   c376      -1
    x[1198]   c378      1
    x[1199]   c223_1    -1346
    x[1199]   c264_1    -1346
    x[1199]   c376      -1
    x[1199]   c379      1
    x[1200]   c232_1    -1346
    x[1200]   c273_1    -1346
    x[1200]   c376      -1
    x[1200]   c381      1
    x[1201]   c240_1    -1346
    x[1201]   c281_1    -1346
    x[1201]   c376      -1
    x[1201]   c382      1
    x[1202]   c220_1    -1346
    x[1202]   c261_1    -1346
    x[1202]   c377      1
    x[1202]   c378      -1
    x[1203]   c225_1    -1346
    x[1203]   c266_1    -1346
    x[1203]   c377      1
    x[1203]   c379      -1
    x[1204]   c228_1    -1346
    x[1204]   c269_1    -1346
    x[1204]   c377      1
    x[1204]   c380      -1
    x[1205]   c234_1    -1346
    x[1205]   c275_1    -1346
    x[1205]   c377      1
    x[1205]   c381      -1
    x[1206]   c242_1    -1346
    x[1206]   c283_1    -1346
    x[1206]   c377      1
    x[1206]   c382      -1
    x[1207]   c220_1    -1346
    x[1207]   c261_1    -1346
    x[1207]   c377      -1
    x[1207]   c378      1
    x[1208]   c225_1    -1346
    x[1208]   c266_1    -1346
    x[1208]   c377      -1
    x[1208]   c379      1
    x[1209]   c228_1    -1346
    x[1209]   c269_1    -1346
    x[1209]   c377      -1
    x[1209]   c380      1
    x[1210]   c234_1    -1346
    x[1210]   c275_1    -1346
    x[1210]   c377      -1
    x[1210]   c381      1
    x[1211]   c242_1    -1346
    x[1211]   c283_1    -1346
    x[1211]   c377      -1
    x[1211]   c382      1
    x[1212]   c226_1    -1346
    x[1212]   c267_1    -1346
    x[1212]   c378      1
    x[1212]   c379      -1
    x[1213]   c229_1    -1346
    x[1213]   c270_1    -1346
    x[1213]   c378      1
    x[1213]   c380      -1
    x[1214]   c235_1    -1346
    x[1214]   c276_1    -1346
    x[1214]   c378      1
    x[1214]   c381      -1
    x[1215]   c243_1    -1346
    x[1215]   c284_1    -1346
    x[1215]   c378      1
    x[1215]   c382      -1
    x[1216]   c226_1    -1346
    x[1216]   c267_1    -1346
    x[1216]   c378      -1
    x[1216]   c379      1
    x[1217]   c229_1    -1346
    x[1217]   c270_1    -1346
    x[1217]   c378      -1
    x[1217]   c380      1
    x[1218]   c235_1    -1346
    x[1218]   c276_1    -1346
    x[1218]   c378      -1
    x[1218]   c381      1
    x[1219]   c243_1    -1346
    x[1219]   c284_1    -1346
    x[1219]   c378      -1
    x[1219]   c382      1
    x[1220]   c230_1    -1346
    x[1220]   c271_1    -1346
    x[1220]   c379      1
    x[1220]   c380      -1
    x[1221]   c236_1    -1346
    x[1221]   c277_1    -1346
    x[1221]   c379      1
    x[1221]   c381      -1
    x[1222]   c244_1    -1346
    x[1222]   c285_1    -1346
    x[1222]   c379      1
    x[1222]   c382      -1
    x[1223]   c230_1    -1346
    x[1223]   c271_1    -1346
    x[1223]   c379      -1
    x[1223]   c380      1
    x[1224]   c236_1    -1346
    x[1224]   c277_1    -1346
    x[1224]   c379      -1
    x[1224]   c381      1
    x[1225]   c244_1    -1346
    x[1225]   c285_1    -1346
    x[1225]   c379      -1
    x[1225]   c382      1
    x[1226]   c237_1    -1346
    x[1226]   c278_1    -1346
    x[1226]   c380      1
    x[1226]   c381      -1
    x[1227]   c245_1    -1346
    x[1227]   c286_1    -1346
    x[1227]   c380      1
    x[1227]   c382      -1
    x[1228]   c237_1    -1346
    x[1228]   c278_1    -1346
    x[1228]   c380      -1
    x[1228]   c381      1
    x[1229]   c245_1    -1346
    x[1229]   c286_1    -1346
    x[1229]   c380      -1
    x[1229]   c382      1
    x[1230]   c246_1    -1346
    x[1230]   c287_1    -1346
    x[1230]   c381      1
    x[1230]   c382      -1
    x[1231]   c246_1    -1346
    x[1231]   c287_1    -1346
    x[1231]   c381      -1
    x[1231]   c382      1
    x[1232]   c226_1    -507
    x[1232]   c267_1    -507
    x[1232]   c383      1
    x[1233]   c227_1    -507
    x[1233]   c268_1    -507
    x[1233]   c384      1
    x[1234]   c228_1    -507
    x[1234]   c269_1    -507
    x[1234]   c385      1
    x[1235]   c229_1    -507
    x[1235]   c270_1    -507
    x[1235]   c386      1
    x[1236]   c230_1    -507
    x[1236]   c271_1    -507
    x[1236]   c387      1
    x[1237]   c235_1    -507
    x[1237]   c276_1    -507
    x[1237]   c388      1
    x[1238]   c243_1    -507
    x[1238]   c284_1    -507
    x[1238]   c389      1
    x[1239]   c216_1    -507
    x[1239]   c257_1    -507
    x[1239]   c390      1
    x[1240]   c217_1    -507
    x[1240]   c258_1    -507
    x[1240]   c391      1
    x[1241]   c218_1    -507
    x[1241]   c259_1    -507
    x[1241]   c392      1
    x[1242]   c219_1    -507
    x[1242]   c260_1    -507
    x[1242]   c393      1
    x[1243]   c220_1    -507
    x[1243]   c261_1    -507
    x[1243]   c394      1
    x[1244]   c237_1    -507
    x[1244]   c278_1    -507
    x[1244]   c395      1
    x[1245]   c245_1    -507
    x[1245]   c286_1    -507
    x[1245]   c396      1
    x[1246]   c194_2    1
    x[1246]   c207_2    1
    x[1246]   c237_1    -507
    x[1246]   c278_1    -507
    x[1246]   c397      1
    x[1246]   c405      1
    x[1247]   c195_2    1
    x[1247]   c245_1    -507
    x[1247]   c286_1    -507
    x[1247]   c397      1
    x[1247]   c406      1
    x[1248]   c227_1    -507
    x[1248]   c268_1    -507
    x[1248]   c397      1
    x[1248]   c399      1
    x[1249]   c196_2    1
    x[1249]   c228_1    -507
    x[1249]   c269_1    -507
    x[1249]   c397      1
    x[1249]   c403      1
    x[1250]   c194_2    1
    x[1250]   c195_2    1
    x[1250]   c196_2    1
    x[1250]   c229_1    -507
    x[1250]   c270_1    -507
    x[1250]   c397      1
    x[1250]   c398      1
    x[1251]   c207_2    1
    x[1251]   c230_1    -507
    x[1251]   c271_1    -507
    x[1251]   c397      1
    x[1251]   c404      1
    x[1252]   c216_1    -507
    x[1252]   c257_1    -507
    x[1252]   c398      1
    x[1252]   c399      -1
    x[1253]   c217_1    -507
    x[1253]   c258_1    -507
    x[1253]   c398      1
    x[1253]   c400      -1
    x[1254]   c218_1    -507
    x[1254]   c259_1    -507
    x[1254]   c398      1
    x[1254]   c401      -1
    x[1255]   c219_1    -507
    x[1255]   c260_1    -507
    x[1255]   c398      1
    x[1255]   c402      -1
    x[1256]   c220_1    -507
    x[1256]   c261_1    -507
    x[1256]   c398      1
    x[1256]   c403      -1
    x[1257]   c226_1    -507
    x[1257]   c267_1    -507
    x[1257]   c398      1
    x[1257]   c404      -1
    x[1258]   c235_1    -507
    x[1258]   c276_1    -507
    x[1258]   c398      1
    x[1258]   c405      -1
    x[1259]   c243_1    -507
    x[1259]   c284_1    -507
    x[1259]   c398      1
    x[1259]   c406      -1
    x[1260]   c206_1    -507
    x[1260]   c247_1    -507
    x[1260]   c399      1
    x[1260]   c400      -1
    x[1261]   c207_1    -507
    x[1261]   c248_1    -507
    x[1261]   c399      1
    x[1261]   c401      -1
    x[1262]   c209_1    -507
    x[1262]   c250_1    -507
    x[1262]   c399      1
    x[1262]   c402      -1
    x[1263]   c212_1    -507
    x[1263]   c253_1    -507
    x[1263]   c399      1
    x[1263]   c403      -1
    x[1264]   c221_1    -507
    x[1264]   c262_1    -507
    x[1264]   c399      1
    x[1264]   c404      -1
    x[1265]   c231_1    -507
    x[1265]   c272_1    -507
    x[1265]   c399      1
    x[1265]   c405      -1
    x[1266]   c238_1    -507
    x[1266]   c279_1    -507
    x[1266]   c399      1
    x[1266]   c406      -1
    x[1267]   c206_1    -507
    x[1267]   c247_1    -507
    x[1267]   c399      -1
    x[1267]   c400      1
    x[1268]   c207_1    -507
    x[1268]   c248_1    -507
    x[1268]   c399      -1
    x[1268]   c401      1
    x[1269]   c209_1    -507
    x[1269]   c250_1    -507
    x[1269]   c399      -1
    x[1269]   c402      1
    x[1270]   c212_1    -507
    x[1270]   c253_1    -507
    x[1270]   c399      -1
    x[1270]   c403      1
    x[1271]   c221_1    -507
    x[1271]   c262_1    -507
    x[1271]   c399      -1
    x[1271]   c404      1
    x[1272]   c231_1    -507
    x[1272]   c272_1    -507
    x[1272]   c399      -1
    x[1272]   c405      1
    x[1273]   c238_1    -507
    x[1273]   c279_1    -507
    x[1273]   c399      -1
    x[1273]   c406      1
    x[1274]   c208_1    -507
    x[1274]   c249_1    -507
    x[1274]   c400      1
    x[1274]   c401      -1
    x[1275]   c210_1    -507
    x[1275]   c251_1    -507
    x[1275]   c400      1
    x[1275]   c402      -1
    x[1276]   c213_1    -507
    x[1276]   c254_1    -507
    x[1276]   c400      1
    x[1276]   c403      -1
    x[1277]   c222_1    -507
    x[1277]   c263_1    -507
    x[1277]   c400      1
    x[1277]   c404      -1
    x[1278]   c239_1    -507
    x[1278]   c280_1    -507
    x[1278]   c400      1
    x[1278]   c406      -1
    x[1279]   c208_1    -507
    x[1279]   c249_1    -507
    x[1279]   c400      -1
    x[1279]   c401      1
    x[1280]   c210_1    -507
    x[1280]   c251_1    -507
    x[1280]   c400      -1
    x[1280]   c402      1
    x[1281]   c213_1    -507
    x[1281]   c254_1    -507
    x[1281]   c400      -1
    x[1281]   c403      1
    x[1282]   c222_1    -507
    x[1282]   c263_1    -507
    x[1282]   c400      -1
    x[1282]   c404      1
    x[1283]   c239_1    -507
    x[1283]   c280_1    -507
    x[1283]   c400      -1
    x[1283]   c406      1
    x[1284]   c211_1    -507
    x[1284]   c252_1    -507
    x[1284]   c401      1
    x[1284]   c402      -1
    x[1285]   c214_1    -507
    x[1285]   c255_1    -507
    x[1285]   c401      1
    x[1285]   c403      -1
    x[1286]   c223_1    -507
    x[1286]   c264_1    -507
    x[1286]   c401      1
    x[1286]   c404      -1
    x[1287]   c232_1    -507
    x[1287]   c273_1    -507
    x[1287]   c401      1
    x[1287]   c405      -1
    x[1288]   c240_1    -507
    x[1288]   c281_1    -507
    x[1288]   c401      1
    x[1288]   c406      -1
    x[1289]   c211_1    -507
    x[1289]   c252_1    -507
    x[1289]   c401      -1
    x[1289]   c402      1
    x[1290]   c214_1    -507
    x[1290]   c255_1    -507
    x[1290]   c401      -1
    x[1290]   c403      1
    x[1291]   c223_1    -507
    x[1291]   c264_1    -507
    x[1291]   c401      -1
    x[1291]   c404      1
    x[1292]   c232_1    -507
    x[1292]   c273_1    -507
    x[1292]   c401      -1
    x[1292]   c405      1
    x[1293]   c240_1    -507
    x[1293]   c281_1    -507
    x[1293]   c401      -1
    x[1293]   c406      1
    x[1294]   c215_1    -507
    x[1294]   c256_1    -507
    x[1294]   c402      1
    x[1294]   c403      -1
    x[1295]   c224_1    -507
    x[1295]   c265_1    -507
    x[1295]   c402      1
    x[1295]   c404      -1
    x[1296]   c233_1    -507
    x[1296]   c274_1    -507
    x[1296]   c402      1
    x[1296]   c405      -1
    x[1297]   c241_1    -507
    x[1297]   c282_1    -507
    x[1297]   c402      1
    x[1297]   c406      -1
    x[1298]   c215_1    -507
    x[1298]   c256_1    -507
    x[1298]   c402      -1
    x[1298]   c403      1
    x[1299]   c224_1    -507
    x[1299]   c265_1    -507
    x[1299]   c402      -1
    x[1299]   c404      1
    x[1300]   c233_1    -507
    x[1300]   c274_1    -507
    x[1300]   c402      -1
    x[1300]   c405      1
    x[1301]   c241_1    -507
    x[1301]   c282_1    -507
    x[1301]   c402      -1
    x[1301]   c406      1
    x[1302]   c225_1    -507
    x[1302]   c266_1    -507
    x[1302]   c403      1
    x[1302]   c404      -1
    x[1303]   c234_1    -507
    x[1303]   c275_1    -507
    x[1303]   c403      1
    x[1303]   c405      -1
    x[1304]   c242_1    -507
    x[1304]   c283_1    -507
    x[1304]   c403      1
    x[1304]   c406      -1
    x[1305]   c225_1    -507
    x[1305]   c266_1    -507
    x[1305]   c403      -1
    x[1305]   c404      1
    x[1306]   c234_1    -507
    x[1306]   c275_1    -507
    x[1306]   c403      -1
    x[1306]   c405      1
    x[1307]   c242_1    -507
    x[1307]   c283_1    -507
    x[1307]   c403      -1
    x[1307]   c406      1
    x[1308]   c236_1    -507
    x[1308]   c277_1    -507
    x[1308]   c404      1
    x[1308]   c405      -1
    x[1309]   c244_1    -507
    x[1309]   c285_1    -507
    x[1309]   c404      1
    x[1309]   c406      -1
    x[1310]   c236_1    -507
    x[1310]   c277_1    -507
    x[1310]   c404      -1
    x[1310]   c405      1
    x[1311]   c244_1    -507
    x[1311]   c285_1    -507
    x[1311]   c404      -1
    x[1311]   c406      1
    x[1312]   c246_1    -507
    x[1312]   c287_1    -507
    x[1312]   c405      1
    x[1312]   c406      -1
    x[1313]   c246_1    -507
    x[1313]   c287_1    -507
    x[1313]   c405      -1
    x[1313]   c406      1
    x[1314]   c206_1    -5620
    x[1314]   c247_1    -5620
    x[1314]   c407      1
    x[1315]   c220_1    -5620
    x[1315]   c261_1    -5620
    x[1315]   c408      1
    x[1316]   c225_1    -5620
    x[1316]   c266_1    -5620
    x[1316]   c409      1
    x[1317]   c228_1    -5620
    x[1317]   c269_1    -5620
    x[1317]   c410      1
    x[1318]   c234_1    -5620
    x[1318]   c275_1    -5620
    x[1318]   c411      1
    x[1319]   c242_1    -5620
    x[1319]   c283_1    -5620
    x[1319]   c412      1
    x[1320]   c208_1    -5620
    x[1320]   c249_1    -5620
    x[1320]   c413      1
    x[1321]   c210_1    -5620
    x[1321]   c251_1    -5620
    x[1321]   c414      1
    x[1322]   c212_1    -5620
    x[1322]   c253_1    -5620
    x[1322]   c415      1
    x[1323]   c213_1    -5620
    x[1323]   c254_1    -5620
    x[1323]   c416      1
    x[1324]   c214_1    -5620
    x[1324]   c255_1    -5620
    x[1324]   c417      1
    x[1325]   c215_1    -5620
    x[1325]   c256_1    -5620
    x[1325]   c418      1
    x[1326]   c217_1    -5620
    x[1326]   c258_1    -5620
    x[1326]   c419      1
    x[1327]   c222_1    -5620
    x[1327]   c263_1    -5620
    x[1327]   c420      1
    x[1328]   c239_1    -5620
    x[1328]   c280_1    -5620
    x[1328]   c421      1
    x[1329]   c176_2    1
    x[1329]   c188_2    1
    x[1329]   c208_1    -5620
    x[1329]   c249_1    -5620
    x[1329]   c422      1
    x[1329]   c425      1
    x[1330]   c177_2    1
    x[1330]   c210_1    -5620
    x[1330]   c251_1    -5620
    x[1330]   c422      1
    x[1330]   c426      1
    x[1331]   c176_2    1
    x[1331]   c177_2    1
    x[1331]   c178_2    1
    x[1331]   c179_2    1
    x[1331]   c213_1    -5620
    x[1331]   c254_1    -5620
    x[1331]   c422      1
    x[1331]   c423      1
    x[1332]   c188_2    1
    x[1332]   c217_1    -5620
    x[1332]   c258_1    -5620
    x[1332]   c422      1
    x[1332]   c427      1
    x[1333]   c222_1    -5620
    x[1333]   c263_1    -5620
    x[1333]   c422      1
    x[1333]   c428      1
    x[1334]   c178_2    1
    x[1334]   c239_1    -5620
    x[1334]   c280_1    -5620
    x[1334]   c422      1
    x[1334]   c431      1
    x[1335]   c179_2    1
    x[1335]   c206_1    -5620
    x[1335]   c247_1    -5620
    x[1335]   c422      1
    x[1335]   c424      1
    x[1336]   c212_1    -5620
    x[1336]   c253_1    -5620
    x[1336]   c423      1
    x[1336]   c424      -1
    x[1337]   c2_2      1
    x[1337]   c214_1    -5620
    x[1337]   c255_1    -5620
    x[1337]   c423      1
    x[1337]   c425      -1
    x[1338]   c2_2      1
    x[1338]   c215_1    -5620
    x[1338]   c256_1    -5620
    x[1338]   c423      1
    x[1338]   c426      -1
    x[1339]   c220_1    -5620
    x[1339]   c261_1    -5620
    x[1339]   c423      1
    x[1339]   c427      -1
    x[1340]   c225_1    -5620
    x[1340]   c266_1    -5620
    x[1340]   c423      1
    x[1340]   c428      -1
    x[1341]   c228_1    -5620
    x[1341]   c269_1    -5620
    x[1341]   c423      1
    x[1341]   c429      -1
    x[1342]   c234_1    -5620
    x[1342]   c275_1    -5620
    x[1342]   c423      1
    x[1342]   c430      -1
    x[1343]   c242_1    -5620
    x[1343]   c283_1    -5620
    x[1343]   c423      1
    x[1343]   c431      -1
    x[1344]   c207_1    -5620
    x[1344]   c248_1    -5620
    x[1344]   c424      1
    x[1344]   c425      -1
    x[1345]   c209_1    -5620
    x[1345]   c250_1    -5620
    x[1345]   c424      1
    x[1345]   c426      -1
    x[1346]   c216_1    -5620
    x[1346]   c257_1    -5620
    x[1346]   c424      1
    x[1346]   c427      -1
    x[1347]   c221_1    -5620
    x[1347]   c262_1    -5620
    x[1347]   c424      1
    x[1347]   c428      -1
    x[1348]   c227_1    -5620
    x[1348]   c268_1    -5620
    x[1348]   c424      1
    x[1348]   c429      -1
    x[1349]   c231_1    -5620
    x[1349]   c272_1    -5620
    x[1349]   c424      1
    x[1349]   c430      -1
    x[1350]   c238_1    -5620
    x[1350]   c279_1    -5620
    x[1350]   c424      1
    x[1350]   c431      -1
    x[1351]   c207_1    -5620
    x[1351]   c248_1    -5620
    x[1351]   c424      -1
    x[1351]   c425      1
    x[1352]   c209_1    -5620
    x[1352]   c250_1    -5620
    x[1352]   c424      -1
    x[1352]   c426      1
    x[1353]   c216_1    -5620
    x[1353]   c257_1    -5620
    x[1353]   c424      -1
    x[1353]   c427      1
    x[1354]   c221_1    -5620
    x[1354]   c262_1    -5620
    x[1354]   c424      -1
    x[1354]   c428      1
    x[1355]   c227_1    -5620
    x[1355]   c268_1    -5620
    x[1355]   c424      -1
    x[1355]   c429      1
    x[1356]   c231_1    -5620
    x[1356]   c272_1    -5620
    x[1356]   c424      -1
    x[1356]   c430      1
    x[1357]   c238_1    -5620
    x[1357]   c279_1    -5620
    x[1357]   c424      -1
    x[1357]   c431      1
    x[1358]   c211_1    -5620
    x[1358]   c252_1    -5620
    x[1358]   c425      1
    x[1358]   c426      -1
    x[1359]   c218_1    -5620
    x[1359]   c259_1    -5620
    x[1359]   c425      1
    x[1359]   c427      -1
    x[1360]   c223_1    -5620
    x[1360]   c264_1    -5620
    x[1360]   c425      1
    x[1360]   c428      -1
    x[1361]   c232_1    -5620
    x[1361]   c273_1    -5620
    x[1361]   c425      1
    x[1361]   c430      -1
    x[1362]   c240_1    -5620
    x[1362]   c281_1    -5620
    x[1362]   c425      1
    x[1362]   c431      -1
    x[1363]   c211_1    -5620
    x[1363]   c252_1    -5620
    x[1363]   c425      -1
    x[1363]   c426      1
    x[1364]   c218_1    -5620
    x[1364]   c259_1    -5620
    x[1364]   c425      -1
    x[1364]   c427      1
    x[1365]   c223_1    -5620
    x[1365]   c264_1    -5620
    x[1365]   c425      -1
    x[1365]   c428      1
    x[1366]   c232_1    -5620
    x[1366]   c273_1    -5620
    x[1366]   c425      -1
    x[1366]   c430      1
    x[1367]   c240_1    -5620
    x[1367]   c281_1    -5620
    x[1367]   c425      -1
    x[1367]   c431      1
    x[1368]   c219_1    -5620
    x[1368]   c260_1    -5620
    x[1368]   c426      1
    x[1368]   c427      -1
    x[1369]   c224_1    -5620
    x[1369]   c265_1    -5620
    x[1369]   c426      1
    x[1369]   c428      -1
    x[1370]   c233_1    -5620
    x[1370]   c274_1    -5620
    x[1370]   c426      1
    x[1370]   c430      -1
    x[1371]   c241_1    -5620
    x[1371]   c282_1    -5620
    x[1371]   c426      1
    x[1371]   c431      -1
    x[1372]   c219_1    -5620
    x[1372]   c260_1    -5620
    x[1372]   c426      -1
    x[1372]   c427      1
    x[1373]   c224_1    -5620
    x[1373]   c265_1    -5620
    x[1373]   c426      -1
    x[1373]   c428      1
    x[1374]   c233_1    -5620
    x[1374]   c274_1    -5620
    x[1374]   c426      -1
    x[1374]   c430      1
    x[1375]   c241_1    -5620
    x[1375]   c282_1    -5620
    x[1375]   c426      -1
    x[1375]   c431      1
    x[1376]   c226_1    -5620
    x[1376]   c267_1    -5620
    x[1376]   c427      1
    x[1376]   c428      -1
    x[1377]   c229_1    -5620
    x[1377]   c270_1    -5620
    x[1377]   c427      1
    x[1377]   c429      -1
    x[1378]   c235_1    -5620
    x[1378]   c276_1    -5620
    x[1378]   c427      1
    x[1378]   c430      -1
    x[1379]   c243_1    -5620
    x[1379]   c284_1    -5620
    x[1379]   c427      1
    x[1379]   c431      -1
    x[1380]   c226_1    -5620
    x[1380]   c267_1    -5620
    x[1380]   c427      -1
    x[1380]   c428      1
    x[1381]   c229_1    -5620
    x[1381]   c270_1    -5620
    x[1381]   c427      -1
    x[1381]   c429      1
    x[1382]   c235_1    -5620
    x[1382]   c276_1    -5620
    x[1382]   c427      -1
    x[1382]   c430      1
    x[1383]   c243_1    -5620
    x[1383]   c284_1    -5620
    x[1383]   c427      -1
    x[1383]   c431      1
    x[1384]   c230_1    -5620
    x[1384]   c271_1    -5620
    x[1384]   c428      1
    x[1384]   c429      -1
    x[1385]   c236_1    -5620
    x[1385]   c277_1    -5620
    x[1385]   c428      1
    x[1385]   c430      -1
    x[1386]   c244_1    -5620
    x[1386]   c285_1    -5620
    x[1386]   c428      1
    x[1386]   c431      -1
    x[1387]   c230_1    -5620
    x[1387]   c271_1    -5620
    x[1387]   c428      -1
    x[1387]   c429      1
    x[1388]   c236_1    -5620
    x[1388]   c277_1    -5620
    x[1388]   c428      -1
    x[1388]   c430      1
    x[1389]   c244_1    -5620
    x[1389]   c285_1    -5620
    x[1389]   c428      -1
    x[1389]   c431      1
    x[1390]   c237_1    -5620
    x[1390]   c278_1    -5620
    x[1390]   c429      1
    x[1390]   c430      -1
    x[1391]   c245_1    -5620
    x[1391]   c286_1    -5620
    x[1391]   c429      1
    x[1391]   c431      -1
    x[1392]   c237_1    -5620
    x[1392]   c278_1    -5620
    x[1392]   c429      -1
    x[1392]   c430      1
    x[1393]   c245_1    -5620
    x[1393]   c286_1    -5620
    x[1393]   c429      -1
    x[1393]   c431      1
    x[1394]   c246_1    -5620
    x[1394]   c287_1    -5620
    x[1394]   c430      1
    x[1394]   c431      -1
    x[1395]   c246_1    -5620
    x[1395]   c287_1    -5620
    x[1395]   c430      -1
    x[1395]   c431      1
    x[1396]   c220_1    -661
    x[1396]   c261_1    -661
    x[1396]   c432      1
    x[1397]   c225_1    -661
    x[1397]   c266_1    -661
    x[1397]   c433      1
    x[1398]   c228_1    -661
    x[1398]   c269_1    -661
    x[1398]   c434      1
    x[1399]   c234_1    -661
    x[1399]   c275_1    -661
    x[1399]   c435      1
    x[1400]   c238_1    -661
    x[1400]   c279_1    -661
    x[1400]   c436      1
    x[1401]   c239_1    -661
    x[1401]   c280_1    -661
    x[1401]   c437      1
    x[1402]   c240_1    -661
    x[1402]   c281_1    -661
    x[1402]   c438      1
    x[1403]   c241_1    -661
    x[1403]   c282_1    -661
    x[1403]   c439      1
    x[1404]   c242_1    -661
    x[1404]   c283_1    -661
    x[1404]   c440      1
    x[1405]   c243_1    -661
    x[1405]   c284_1    -661
    x[1405]   c441      1
    x[1406]   c244_1    -661
    x[1406]   c285_1    -661
    x[1406]   c442      1
    x[1407]   c245_1    -661
    x[1407]   c286_1    -661
    x[1407]   c443      1
    x[1408]   c246_1    -661
    x[1408]   c287_1    -661
    x[1408]   c444      1
    x[1409]   c212_1    -661
    x[1409]   c253_1    -661
    x[1409]   c445      1
    x[1410]   c213_1    -661
    x[1410]   c254_1    -661
    x[1410]   c446      1
    x[1411]   c214_1    -661
    x[1411]   c255_1    -661
    x[1411]   c447      1
    x[1412]   c215_1    -661
    x[1412]   c256_1    -661
    x[1412]   c448      1
    x[1413]   c238_1    -661
    x[1413]   c279_1    -661
    x[1413]   c449      1
    x[1413]   c451      1
    x[1414]   c239_1    -661
    x[1414]   c280_1    -661
    x[1414]   c449      1
    x[1414]   c452      1
    x[1415]   c240_1    -661
    x[1415]   c281_1    -661
    x[1415]   c449      1
    x[1415]   c453      1
    x[1416]   c241_1    -661
    x[1416]   c282_1    -661
    x[1416]   c449      1
    x[1416]   c454      1
    x[1417]   c242_1    -661
    x[1417]   c283_1    -661
    x[1417]   c449      1
    x[1417]   c450      1
    x[1418]   c243_1    -661
    x[1418]   c284_1    -661
    x[1418]   c449      1
    x[1418]   c455      1
    x[1419]   c244_1    -661
    x[1419]   c285_1    -661
    x[1419]   c449      1
    x[1419]   c456      1
    x[1420]   c245_1    -661
    x[1420]   c286_1    -661
    x[1420]   c449      1
    x[1420]   c457      1
    x[1421]   c246_1    -661
    x[1421]   c287_1    -661
    x[1421]   c449      1
    x[1421]   c458      1
    x[1422]   c161_2    1
    x[1422]   c162_2    1
    x[1422]   c163_2    1
    x[1422]   c164_2    1
    x[1422]   c212_1    -661
    x[1422]   c253_1    -661
    x[1422]   c450      1
    x[1422]   c451      -1
    x[1423]   c161_2    1
    x[1423]   c213_1    -661
    x[1423]   c254_1    -661
    x[1423]   c450      1
    x[1423]   c452      -1
    x[1424]   c214_1    -661
    x[1424]   c255_1    -661
    x[1424]   c450      1
    x[1424]   c453      -1
    x[1425]   c162_2    1
    x[1425]   c215_1    -661
    x[1425]   c256_1    -661
    x[1425]   c450      1
    x[1425]   c454      -1
    x[1426]   c163_2    1
    x[1426]   c220_1    -661
    x[1426]   c261_1    -661
    x[1426]   c450      1
    x[1426]   c455      -1
    x[1427]   c164_2    1
    x[1427]   c225_1    -661
    x[1427]   c266_1    -661
    x[1427]   c450      1
    x[1427]   c456      -1
    x[1428]   c228_1    -661
    x[1428]   c269_1    -661
    x[1428]   c450      1
    x[1428]   c457      -1
    x[1429]   c234_1    -661
    x[1429]   c275_1    -661
    x[1429]   c450      1
    x[1429]   c458      -1
    x[1430]   c206_1    -661
    x[1430]   c247_1    -661
    x[1430]   c451      1
    x[1430]   c452      -1
    x[1431]   c207_1    -661
    x[1431]   c248_1    -661
    x[1431]   c451      1
    x[1431]   c453      -1
    x[1432]   c209_1    -661
    x[1432]   c250_1    -661
    x[1432]   c451      1
    x[1432]   c454      -1
    x[1433]   c216_1    -661
    x[1433]   c257_1    -661
    x[1433]   c451      1
    x[1433]   c455      -1
    x[1434]   c221_1    -661
    x[1434]   c262_1    -661
    x[1434]   c451      1
    x[1434]   c456      -1
    x[1435]   c227_1    -661
    x[1435]   c268_1    -661
    x[1435]   c451      1
    x[1435]   c457      -1
    x[1436]   c231_1    -661
    x[1436]   c272_1    -661
    x[1436]   c451      1
    x[1436]   c458      -1
    x[1437]   c206_1    -661
    x[1437]   c247_1    -661
    x[1437]   c451      -1
    x[1437]   c452      1
    x[1438]   c207_1    -661
    x[1438]   c248_1    -661
    x[1438]   c451      -1
    x[1438]   c453      1
    x[1439]   c209_1    -661
    x[1439]   c250_1    -661
    x[1439]   c451      -1
    x[1439]   c454      1
    x[1440]   c216_1    -661
    x[1440]   c257_1    -661
    x[1440]   c451      -1
    x[1440]   c455      1
    x[1441]   c221_1    -661
    x[1441]   c262_1    -661
    x[1441]   c451      -1
    x[1441]   c456      1
    x[1442]   c227_1    -661
    x[1442]   c268_1    -661
    x[1442]   c451      -1
    x[1442]   c457      1
    x[1443]   c231_1    -661
    x[1443]   c272_1    -661
    x[1443]   c451      -1
    x[1443]   c458      1
    x[1444]   c208_1    -661
    x[1444]   c249_1    -661
    x[1444]   c452      1
    x[1444]   c453      -1
    x[1445]   c210_1    -661
    x[1445]   c251_1    -661
    x[1445]   c452      1
    x[1445]   c454      -1
    x[1446]   c217_1    -661
    x[1446]   c258_1    -661
    x[1446]   c452      1
    x[1446]   c455      -1
    x[1447]   c222_1    -661
    x[1447]   c263_1    -661
    x[1447]   c452      1
    x[1447]   c456      -1
    x[1448]   c208_1    -661
    x[1448]   c249_1    -661
    x[1448]   c452      -1
    x[1448]   c453      1
    x[1449]   c210_1    -661
    x[1449]   c251_1    -661
    x[1449]   c452      -1
    x[1449]   c454      1
    x[1450]   c217_1    -661
    x[1450]   c258_1    -661
    x[1450]   c452      -1
    x[1450]   c455      1
    x[1451]   c222_1    -661
    x[1451]   c263_1    -661
    x[1451]   c452      -1
    x[1451]   c456      1
    x[1452]   c211_1    -661
    x[1452]   c252_1    -661
    x[1452]   c453      1
    x[1452]   c454      -1
    x[1453]   c218_1    -661
    x[1453]   c259_1    -661
    x[1453]   c453      1
    x[1453]   c455      -1
    x[1454]   c223_1    -661
    x[1454]   c264_1    -661
    x[1454]   c453      1
    x[1454]   c456      -1
    x[1455]   c232_1    -661
    x[1455]   c273_1    -661
    x[1455]   c453      1
    x[1455]   c458      -1
    x[1456]   c211_1    -661
    x[1456]   c252_1    -661
    x[1456]   c453      -1
    x[1456]   c454      1
    x[1457]   c218_1    -661
    x[1457]   c259_1    -661
    x[1457]   c453      -1
    x[1457]   c455      1
    x[1458]   c223_1    -661
    x[1458]   c264_1    -661
    x[1458]   c453      -1
    x[1458]   c456      1
    x[1459]   c232_1    -661
    x[1459]   c273_1    -661
    x[1459]   c453      -1
    x[1459]   c458      1
    x[1460]   c219_1    -661
    x[1460]   c260_1    -661
    x[1460]   c454      1
    x[1460]   c455      -1
    x[1461]   c224_1    -661
    x[1461]   c265_1    -661
    x[1461]   c454      1
    x[1461]   c456      -1
    x[1462]   c233_1    -661
    x[1462]   c274_1    -661
    x[1462]   c454      1
    x[1462]   c458      -1
    x[1463]   c219_1    -661
    x[1463]   c260_1    -661
    x[1463]   c454      -1
    x[1463]   c455      1
    x[1464]   c224_1    -661
    x[1464]   c265_1    -661
    x[1464]   c454      -1
    x[1464]   c456      1
    x[1465]   c233_1    -661
    x[1465]   c274_1    -661
    x[1465]   c454      -1
    x[1465]   c458      1
    x[1466]   c226_1    -661
    x[1466]   c267_1    -661
    x[1466]   c455      1
    x[1466]   c456      -1
    x[1467]   c229_1    -661
    x[1467]   c270_1    -661
    x[1467]   c455      1
    x[1467]   c457      -1
    x[1468]   c235_1    -661
    x[1468]   c276_1    -661
    x[1468]   c455      1
    x[1468]   c458      -1
    x[1469]   c226_1    -661
    x[1469]   c267_1    -661
    x[1469]   c455      -1
    x[1469]   c456      1
    x[1470]   c229_1    -661
    x[1470]   c270_1    -661
    x[1470]   c455      -1
    x[1470]   c457      1
    x[1471]   c235_1    -661
    x[1471]   c276_1    -661
    x[1471]   c455      -1
    x[1471]   c458      1
    x[1472]   c230_1    -661
    x[1472]   c271_1    -661
    x[1472]   c456      1
    x[1472]   c457      -1
    x[1473]   c236_1    -661
    x[1473]   c277_1    -661
    x[1473]   c456      1
    x[1473]   c458      -1
    x[1474]   c230_1    -661
    x[1474]   c271_1    -661
    x[1474]   c456      -1
    x[1474]   c457      1
    x[1475]   c236_1    -661
    x[1475]   c277_1    -661
    x[1475]   c456      -1
    x[1475]   c458      1
    x[1476]   c237_1    -661
    x[1476]   c278_1    -661
    x[1476]   c457      1
    x[1476]   c458      -1
    x[1477]   c237_1    -661
    x[1477]   c278_1    -661
    x[1477]   c457      -1
    x[1477]   c458      1
    x[1478]   c206_1    -3193
    x[1478]   c247_1    -3193
    x[1478]   c459      1
    x[1479]   c226_1    -3193
    x[1479]   c267_1    -3193
    x[1479]   c460      1
    x[1480]   c229_1    -3193
    x[1480]   c270_1    -3193
    x[1480]   c461      1
    x[1481]   c235_1    -3193
    x[1481]   c276_1    -3193
    x[1481]   c462      1
    x[1482]   c243_1    -3193
    x[1482]   c284_1    -3193
    x[1482]   c463      1
    x[1483]   c208_1    -3193
    x[1483]   c249_1    -3193
    x[1483]   c464      1
    x[1484]   c210_1    -3193
    x[1484]   c251_1    -3193
    x[1484]   c465      1
    x[1485]   c213_1    -3193
    x[1485]   c254_1    -3193
    x[1485]   c466      1
    x[1486]   c216_1    -3193
    x[1486]   c257_1    -3193
    x[1486]   c467      1
    x[1487]   c217_1    -3193
    x[1487]   c258_1    -3193
    x[1487]   c468      1
    x[1488]   c218_1    -3193
    x[1488]   c259_1    -3193
    x[1488]   c469      1
    x[1489]   c219_1    -3193
    x[1489]   c260_1    -3193
    x[1489]   c470      1
    x[1490]   c220_1    -3193
    x[1490]   c261_1    -3193
    x[1490]   c471      1
    x[1491]   c222_1    -3193
    x[1491]   c263_1    -3193
    x[1491]   c472      1
    x[1492]   c239_1    -3193
    x[1492]   c280_1    -3193
    x[1492]   c473      1
    x[1493]   c25_2     1
    x[1493]   c208_1    -3193
    x[1493]   c249_1    -3193
    x[1493]   c474      1
    x[1493]   c477      1
    x[1494]   c26_2     1
    x[1494]   c210_1    -3193
    x[1494]   c251_1    -3193
    x[1494]   c474      1
    x[1494]   c478      1
    x[1495]   c27_2     1
    x[1495]   c213_1    -3193
    x[1495]   c254_1    -3193
    x[1495]   c474      1
    x[1495]   c479      1
    x[1496]   c25_2     1
    x[1496]   c26_2     1
    x[1496]   c27_2     1
    x[1496]   c28_2     1
    x[1496]   c29_2     1
    x[1496]   c217_1    -3193
    x[1496]   c258_1    -3193
    x[1496]   c474      1
    x[1496]   c475      1
    x[1497]   c222_1    -3193
    x[1497]   c263_1    -3193
    x[1497]   c474      1
    x[1497]   c480      1
    x[1498]   c28_2     1
    x[1498]   c239_1    -3193
    x[1498]   c280_1    -3193
    x[1498]   c474      1
    x[1498]   c483      1
    x[1499]   c29_2     1
    x[1499]   c206_1    -3193
    x[1499]   c247_1    -3193
    x[1499]   c474      1
    x[1499]   c476      1
    x[1500]   c197_2    1
    x[1500]   c198_2    1
    x[1500]   c199_2    1
    x[1500]   c200_2    1
    x[1500]   c216_1    -3193
    x[1500]   c257_1    -3193
    x[1500]   c475      1
    x[1500]   c476      -1
    x[1501]   c201_2    1
    x[1501]   c218_1    -3193
    x[1501]   c259_1    -3193
    x[1501]   c475      1
    x[1501]   c477      -1
    x[1502]   c201_2    1
    x[1502]   c219_1    -3193
    x[1502]   c260_1    -3193
    x[1502]   c475      1
    x[1502]   c478      -1
    x[1503]   c197_2    1
    x[1503]   c220_1    -3193
    x[1503]   c261_1    -3193
    x[1503]   c475      1
    x[1503]   c479      -1
    x[1504]   c198_2    1
    x[1504]   c226_1    -3193
    x[1504]   c267_1    -3193
    x[1504]   c475      1
    x[1504]   c480      -1
    x[1505]   c229_1    -3193
    x[1505]   c270_1    -3193
    x[1505]   c475      1
    x[1505]   c481      -1
    x[1506]   c199_2    1
    x[1506]   c235_1    -3193
    x[1506]   c276_1    -3193
    x[1506]   c475      1
    x[1506]   c482      -1
    x[1507]   c200_2    1
    x[1507]   c243_1    -3193
    x[1507]   c284_1    -3193
    x[1507]   c475      1
    x[1507]   c483      -1
    x[1508]   c207_1    -3193
    x[1508]   c248_1    -3193
    x[1508]   c476      1
    x[1508]   c477      -1
    x[1509]   c209_1    -3193
    x[1509]   c250_1    -3193
    x[1509]   c476      1
    x[1509]   c478      -1
    x[1510]   c212_1    -3193
    x[1510]   c253_1    -3193
    x[1510]   c476      1
    x[1510]   c479      -1
    x[1511]   c221_1    -3193
    x[1511]   c262_1    -3193
    x[1511]   c476      1
    x[1511]   c480      -1
    x[1512]   c227_1    -3193
    x[1512]   c268_1    -3193
    x[1512]   c476      1
    x[1512]   c481      -1
    x[1513]   c231_1    -3193
    x[1513]   c272_1    -3193
    x[1513]   c476      1
    x[1513]   c482      -1
    x[1514]   c238_1    -3193
    x[1514]   c279_1    -3193
    x[1514]   c476      1
    x[1514]   c483      -1
    x[1515]   c207_1    -3193
    x[1515]   c248_1    -3193
    x[1515]   c476      -1
    x[1515]   c477      1
    x[1516]   c209_1    -3193
    x[1516]   c250_1    -3193
    x[1516]   c476      -1
    x[1516]   c478      1
    x[1517]   c212_1    -3193
    x[1517]   c253_1    -3193
    x[1517]   c476      -1
    x[1517]   c479      1
    x[1518]   c221_1    -3193
    x[1518]   c262_1    -3193
    x[1518]   c476      -1
    x[1518]   c480      1
    x[1519]   c227_1    -3193
    x[1519]   c268_1    -3193
    x[1519]   c476      -1
    x[1519]   c481      1
    x[1520]   c231_1    -3193
    x[1520]   c272_1    -3193
    x[1520]   c476      -1
    x[1520]   c482      1
    x[1521]   c238_1    -3193
    x[1521]   c279_1    -3193
    x[1521]   c476      -1
    x[1521]   c483      1
    x[1522]   c211_1    -3193
    x[1522]   c252_1    -3193
    x[1522]   c477      1
    x[1522]   c478      -1
    x[1523]   c214_1    -3193
    x[1523]   c255_1    -3193
    x[1523]   c477      1
    x[1523]   c479      -1
    x[1524]   c223_1    -3193
    x[1524]   c264_1    -3193
    x[1524]   c477      1
    x[1524]   c480      -1
    x[1525]   c232_1    -3193
    x[1525]   c273_1    -3193
    x[1525]   c477      1
    x[1525]   c482      -1
    x[1526]   c240_1    -3193
    x[1526]   c281_1    -3193
    x[1526]   c477      1
    x[1526]   c483      -1
    x[1527]   c211_1    -3193
    x[1527]   c252_1    -3193
    x[1527]   c477      -1
    x[1527]   c478      1
    x[1528]   c214_1    -3193
    x[1528]   c255_1    -3193
    x[1528]   c477      -1
    x[1528]   c479      1
    x[1529]   c223_1    -3193
    x[1529]   c264_1    -3193
    x[1529]   c477      -1
    x[1529]   c480      1
    x[1530]   c232_1    -3193
    x[1530]   c273_1    -3193
    x[1530]   c477      -1
    x[1530]   c482      1
    x[1531]   c240_1    -3193
    x[1531]   c281_1    -3193
    x[1531]   c477      -1
    x[1531]   c483      1
    x[1532]   c215_1    -3193
    x[1532]   c256_1    -3193
    x[1532]   c478      1
    x[1532]   c479      -1
    x[1533]   c224_1    -3193
    x[1533]   c265_1    -3193
    x[1533]   c478      1
    x[1533]   c480      -1
    x[1534]   c233_1    -3193
    x[1534]   c274_1    -3193
    x[1534]   c478      1
    x[1534]   c482      -1
    x[1535]   c241_1    -3193
    x[1535]   c282_1    -3193
    x[1535]   c478      1
    x[1535]   c483      -1
    x[1536]   c215_1    -3193
    x[1536]   c256_1    -3193
    x[1536]   c478      -1
    x[1536]   c479      1
    x[1537]   c224_1    -3193
    x[1537]   c265_1    -3193
    x[1537]   c478      -1
    x[1537]   c480      1
    x[1538]   c233_1    -3193
    x[1538]   c274_1    -3193
    x[1538]   c478      -1
    x[1538]   c482      1
    x[1539]   c241_1    -3193
    x[1539]   c282_1    -3193
    x[1539]   c478      -1
    x[1539]   c483      1
    x[1540]   c225_1    -3193
    x[1540]   c266_1    -3193
    x[1540]   c479      1
    x[1540]   c480      -1
    x[1541]   c228_1    -3193
    x[1541]   c269_1    -3193
    x[1541]   c479      1
    x[1541]   c481      -1
    x[1542]   c234_1    -3193
    x[1542]   c275_1    -3193
    x[1542]   c479      1
    x[1542]   c482      -1
    x[1543]   c242_1    -3193
    x[1543]   c283_1    -3193
    x[1543]   c479      1
    x[1543]   c483      -1
    x[1544]   c225_1    -3193
    x[1544]   c266_1    -3193
    x[1544]   c479      -1
    x[1544]   c480      1
    x[1545]   c228_1    -3193
    x[1545]   c269_1    -3193
    x[1545]   c479      -1
    x[1545]   c481      1
    x[1546]   c234_1    -3193
    x[1546]   c275_1    -3193
    x[1546]   c479      -1
    x[1546]   c482      1
    x[1547]   c242_1    -3193
    x[1547]   c283_1    -3193
    x[1547]   c479      -1
    x[1547]   c483      1
    x[1548]   c230_1    -3193
    x[1548]   c271_1    -3193
    x[1548]   c480      1
    x[1548]   c481      -1
    x[1549]   c236_1    -3193
    x[1549]   c277_1    -3193
    x[1549]   c480      1
    x[1549]   c482      -1
    x[1550]   c244_1    -3193
    x[1550]   c285_1    -3193
    x[1550]   c480      1
    x[1550]   c483      -1
    x[1551]   c230_1    -3193
    x[1551]   c271_1    -3193
    x[1551]   c480      -1
    x[1551]   c481      1
    x[1552]   c236_1    -3193
    x[1552]   c277_1    -3193
    x[1552]   c480      -1
    x[1552]   c482      1
    x[1553]   c244_1    -3193
    x[1553]   c285_1    -3193
    x[1553]   c480      -1
    x[1553]   c483      1
    x[1554]   c237_1    -3193
    x[1554]   c278_1    -3193
    x[1554]   c481      1
    x[1554]   c482      -1
    x[1555]   c245_1    -3193
    x[1555]   c286_1    -3193
    x[1555]   c481      1
    x[1555]   c483      -1
    x[1556]   c237_1    -3193
    x[1556]   c278_1    -3193
    x[1556]   c481      -1
    x[1556]   c482      1
    x[1557]   c245_1    -3193
    x[1557]   c286_1    -3193
    x[1557]   c481      -1
    x[1557]   c483      1
    x[1558]   c246_1    -3193
    x[1558]   c287_1    -3193
    x[1558]   c482      1
    x[1558]   c483      -1
    x[1559]   c246_1    -3193
    x[1559]   c287_1    -3193
    x[1559]   c482      -1
    x[1559]   c483      1
    x[1560]   c220_1    -1346
    x[1560]   c261_1    -1346
    x[1560]   c484      1
    x[1561]   c225_1    -1346
    x[1561]   c266_1    -1346
    x[1561]   c485      1
    x[1562]   c228_1    -1346
    x[1562]   c269_1    -1346
    x[1562]   c486      1
    x[1563]   c231_1    -1346
    x[1563]   c272_1    -1346
    x[1563]   c487      1
    x[1564]   c232_1    -1346
    x[1564]   c273_1    -1346
    x[1564]   c488      1
    x[1565]   c233_1    -1346
    x[1565]   c274_1    -1346
    x[1565]   c489      1
    x[1566]   c234_1    -1346
    x[1566]   c275_1    -1346
    x[1566]   c490      1
    x[1567]   c235_1    -1346
    x[1567]   c276_1    -1346
    x[1567]   c491      1
    x[1568]   c236_1    -1346
    x[1568]   c277_1    -1346
    x[1568]   c492      1
    x[1569]   c237_1    -1346
    x[1569]   c278_1    -1346
    x[1569]   c493      1
    x[1570]   c242_1    -1346
    x[1570]   c283_1    -1346
    x[1570]   c494      1
    x[1571]   c212_1    -1346
    x[1571]   c253_1    -1346
    x[1571]   c495      1
    x[1572]   c213_1    -1346
    x[1572]   c254_1    -1346
    x[1572]   c496      1
    x[1573]   c214_1    -1346
    x[1573]   c255_1    -1346
    x[1573]   c497      1
    x[1574]   c215_1    -1346
    x[1574]   c256_1    -1346
    x[1574]   c498      1
    x[1575]   c246_1    -1346
    x[1575]   c287_1    -1346
    x[1575]   c499      1
    x[1576]   c243_2    1
    x[1576]   c261_2    1
    x[1576]   c246_1    -1346
    x[1576]   c287_1    -1346
    x[1576]   c500      1
    x[1576]   c509      1
    x[1577]   c244_2    1
    x[1577]   c231_1    -1346
    x[1577]   c272_1    -1346
    x[1577]   c500      1
    x[1577]   c502      1
    x[1578]   c232_1    -1346
    x[1578]   c273_1    -1346
    x[1578]   c500      1
    x[1578]   c504      1
    x[1579]   c245_2    1
    x[1579]   c233_1    -1346
    x[1579]   c274_1    -1346
    x[1579]   c500      1
    x[1579]   c505      1
    x[1580]   c243_2    1
    x[1580]   c244_2    1
    x[1580]   c245_2    1
    x[1580]   c246_2    1
    x[1580]   c234_1    -1346
    x[1580]   c275_1    -1346
    x[1580]   c500      1
    x[1580]   c501      1
    x[1581]   c261_2    1
    x[1581]   c235_1    -1346
    x[1581]   c276_1    -1346
    x[1581]   c500      1
    x[1581]   c506      1
    x[1582]   c236_1    -1346
    x[1582]   c277_1    -1346
    x[1582]   c500      1
    x[1582]   c507      1
    x[1583]   c246_2    1
    x[1583]   c237_1    -1346
    x[1583]   c278_1    -1346
    x[1583]   c500      1
    x[1583]   c508      1
    x[1584]   c212_1    -1346
    x[1584]   c253_1    -1346
    x[1584]   c501      1
    x[1584]   c502      -1
    x[1585]   c213_1    -1346
    x[1585]   c254_1    -1346
    x[1585]   c501      1
    x[1585]   c503      -1
    x[1586]   c214_1    -1346
    x[1586]   c255_1    -1346
    x[1586]   c501      1
    x[1586]   c504      -1
    x[1587]   c215_1    -1346
    x[1587]   c256_1    -1346
    x[1587]   c501      1
    x[1587]   c505      -1
    x[1588]   c220_1    -1346
    x[1588]   c261_1    -1346
    x[1588]   c501      1
    x[1588]   c506      -1
    x[1589]   c225_1    -1346
    x[1589]   c266_1    -1346
    x[1589]   c501      1
    x[1589]   c507      -1
    x[1590]   c228_1    -1346
    x[1590]   c269_1    -1346
    x[1590]   c501      1
    x[1590]   c508      -1
    x[1591]   c242_1    -1346
    x[1591]   c283_1    -1346
    x[1591]   c501      1
    x[1591]   c509      -1
    x[1592]   c206_1    -1346
    x[1592]   c247_1    -1346
    x[1592]   c502      1
    x[1592]   c503      -1
    x[1593]   c207_1    -1346
    x[1593]   c248_1    -1346
    x[1593]   c502      1
    x[1593]   c504      -1
    x[1594]   c209_1    -1346
    x[1594]   c250_1    -1346
    x[1594]   c502      1
    x[1594]   c505      -1
    x[1595]   c216_1    -1346
    x[1595]   c257_1    -1346
    x[1595]   c502      1
    x[1595]   c506      -1
    x[1596]   c221_1    -1346
    x[1596]   c262_1    -1346
    x[1596]   c502      1
    x[1596]   c507      -1
    x[1597]   c227_1    -1346
    x[1597]   c268_1    -1346
    x[1597]   c502      1
    x[1597]   c508      -1
    x[1598]   c238_1    -1346
    x[1598]   c279_1    -1346
    x[1598]   c502      1
    x[1598]   c509      -1
    x[1599]   c206_1    -1346
    x[1599]   c247_1    -1346
    x[1599]   c502      -1
    x[1599]   c503      1
    x[1600]   c207_1    -1346
    x[1600]   c248_1    -1346
    x[1600]   c502      -1
    x[1600]   c504      1
    x[1601]   c209_1    -1346
    x[1601]   c250_1    -1346
    x[1601]   c502      -1
    x[1601]   c505      1
    x[1602]   c216_1    -1346
    x[1602]   c257_1    -1346
    x[1602]   c502      -1
    x[1602]   c506      1
    x[1603]   c221_1    -1346
    x[1603]   c262_1    -1346
    x[1603]   c502      -1
    x[1603]   c507      1
    x[1604]   c227_1    -1346
    x[1604]   c268_1    -1346
    x[1604]   c502      -1
    x[1604]   c508      1
    x[1605]   c238_1    -1346
    x[1605]   c279_1    -1346
    x[1605]   c502      -1
    x[1605]   c509      1
    x[1606]   c208_1    -1346
    x[1606]   c249_1    -1346
    x[1606]   c503      1
    x[1606]   c504      -1
    x[1607]   c210_1    -1346
    x[1607]   c251_1    -1346
    x[1607]   c503      1
    x[1607]   c505      -1
    x[1608]   c217_1    -1346
    x[1608]   c258_1    -1346
    x[1608]   c503      1
    x[1608]   c506      -1
    x[1609]   c222_1    -1346
    x[1609]   c263_1    -1346
    x[1609]   c503      1
    x[1609]   c507      -1
    x[1610]   c239_1    -1346
    x[1610]   c280_1    -1346
    x[1610]   c503      1
    x[1610]   c509      -1
    x[1611]   c208_1    -1346
    x[1611]   c249_1    -1346
    x[1611]   c503      -1
    x[1611]   c504      1
    x[1612]   c210_1    -1346
    x[1612]   c251_1    -1346
    x[1612]   c503      -1
    x[1612]   c505      1
    x[1613]   c217_1    -1346
    x[1613]   c258_1    -1346
    x[1613]   c503      -1
    x[1613]   c506      1
    x[1614]   c222_1    -1346
    x[1614]   c263_1    -1346
    x[1614]   c503      -1
    x[1614]   c507      1
    x[1615]   c239_1    -1346
    x[1615]   c280_1    -1346
    x[1615]   c503      -1
    x[1615]   c509      1
    x[1616]   c211_1    -1346
    x[1616]   c252_1    -1346
    x[1616]   c504      1
    x[1616]   c505      -1
    x[1617]   c218_1    -1346
    x[1617]   c259_1    -1346
    x[1617]   c504      1
    x[1617]   c506      -1
    x[1618]   c223_1    -1346
    x[1618]   c264_1    -1346
    x[1618]   c504      1
    x[1618]   c507      -1
    x[1619]   c240_1    -1346
    x[1619]   c281_1    -1346
    x[1619]   c504      1
    x[1619]   c509      -1
    x[1620]   c211_1    -1346
    x[1620]   c252_1    -1346
    x[1620]   c504      -1
    x[1620]   c505      1
    x[1621]   c218_1    -1346
    x[1621]   c259_1    -1346
    x[1621]   c504      -1
    x[1621]   c506      1
    x[1622]   c223_1    -1346
    x[1622]   c264_1    -1346
    x[1622]   c504      -1
    x[1622]   c507      1
    x[1623]   c240_1    -1346
    x[1623]   c281_1    -1346
    x[1623]   c504      -1
    x[1623]   c509      1
    x[1624]   c219_1    -1346
    x[1624]   c260_1    -1346
    x[1624]   c505      1
    x[1624]   c506      -1
    x[1625]   c224_1    -1346
    x[1625]   c265_1    -1346
    x[1625]   c505      1
    x[1625]   c507      -1
    x[1626]   c241_1    -1346
    x[1626]   c282_1    -1346
    x[1626]   c505      1
    x[1626]   c509      -1
    x[1627]   c219_1    -1346
    x[1627]   c260_1    -1346
    x[1627]   c505      -1
    x[1627]   c506      1
    x[1628]   c224_1    -1346
    x[1628]   c265_1    -1346
    x[1628]   c505      -1
    x[1628]   c507      1
    x[1629]   c241_1    -1346
    x[1629]   c282_1    -1346
    x[1629]   c505      -1
    x[1629]   c509      1
    x[1630]   c226_1    -1346
    x[1630]   c267_1    -1346
    x[1630]   c506      1
    x[1630]   c507      -1
    x[1631]   c229_1    -1346
    x[1631]   c270_1    -1346
    x[1631]   c506      1
    x[1631]   c508      -1
    x[1632]   c243_1    -1346
    x[1632]   c284_1    -1346
    x[1632]   c506      1
    x[1632]   c509      -1
    x[1633]   c226_1    -1346
    x[1633]   c267_1    -1346
    x[1633]   c506      -1
    x[1633]   c507      1
    x[1634]   c229_1    -1346
    x[1634]   c270_1    -1346
    x[1634]   c506      -1
    x[1634]   c508      1
    x[1635]   c243_1    -1346
    x[1635]   c284_1    -1346
    x[1635]   c506      -1
    x[1635]   c509      1
    x[1636]   c230_1    -1346
    x[1636]   c271_1    -1346
    x[1636]   c507      1
    x[1636]   c508      -1
    x[1637]   c244_1    -1346
    x[1637]   c285_1    -1346
    x[1637]   c507      1
    x[1637]   c509      -1
    x[1638]   c230_1    -1346
    x[1638]   c271_1    -1346
    x[1638]   c507      -1
    x[1638]   c508      1
    x[1639]   c244_1    -1346
    x[1639]   c285_1    -1346
    x[1639]   c507      -1
    x[1639]   c509      1
    x[1640]   c245_1    -1346
    x[1640]   c286_1    -1346
    x[1640]   c508      1
    x[1640]   c509      -1
    x[1641]   c245_1    -1346
    x[1641]   c286_1    -1346
    x[1641]   c508      -1
    x[1641]   c509      1
    x[1642]   c206_1    -11660
    x[1642]   c247_1    -11660
    x[1642]   c510      1
    x[1643]   c230_1    -11660
    x[1643]   c271_1    -11660
    x[1643]   c511      1
    x[1644]   c236_1    -11660
    x[1644]   c277_1    -11660
    x[1644]   c512      1
    x[1645]   c244_1    -11660
    x[1645]   c285_1    -11660
    x[1645]   c513      1
    x[1646]   c208_1    -11660
    x[1646]   c249_1    -11660
    x[1646]   c514      1
    x[1647]   c210_1    -11660
    x[1647]   c251_1    -11660
    x[1647]   c515      1
    x[1648]   c213_1    -11660
    x[1648]   c254_1    -11660
    x[1648]   c516      1
    x[1649]   c217_1    -11660
    x[1649]   c258_1    -11660
    x[1649]   c517      1
    x[1650]   c221_1    -11660
    x[1650]   c262_1    -11660
    x[1650]   c518      1
    x[1651]   c222_1    -11660
    x[1651]   c263_1    -11660
    x[1651]   c519      1
    x[1652]   c223_1    -11660
    x[1652]   c264_1    -11660
    x[1652]   c520      1
    x[1653]   c224_1    -11660
    x[1653]   c265_1    -11660
    x[1653]   c521      1
    x[1654]   c225_1    -11660
    x[1654]   c266_1    -11660
    x[1654]   c522      1
    x[1655]   c226_1    -11660
    x[1655]   c267_1    -11660
    x[1655]   c523      1
    x[1656]   c239_1    -11660
    x[1656]   c280_1    -11660
    x[1656]   c524      1
    x[1657]   c208_1    -11660
    x[1657]   c249_1    -11660
    x[1657]   c525      1
    x[1657]   c528      1
    x[1658]   c210_1    -11660
    x[1658]   c251_1    -11660
    x[1658]   c525      1
    x[1658]   c529      1
    x[1659]   c213_1    -11660
    x[1659]   c254_1    -11660
    x[1659]   c525      1
    x[1659]   c530      1
    x[1660]   c217_1    -11660
    x[1660]   c258_1    -11660
    x[1660]   c525      1
    x[1660]   c531      1
    x[1661]   c222_1    -11660
    x[1661]   c263_1    -11660
    x[1661]   c525      1
    x[1661]   c526      1
    x[1662]   c239_1    -11660
    x[1662]   c280_1    -11660
    x[1662]   c525      1
    x[1662]   c534      1
    x[1663]   c206_1    -11660
    x[1663]   c247_1    -11660
    x[1663]   c525      1
    x[1663]   c527      1
    x[1664]   c121_2    1
    x[1664]   c122_2    1
    x[1664]   c123_2    1
    x[1664]   c124_2    1
    x[1664]   c125_2    1
    x[1664]   c221_1    -11660
    x[1664]   c262_1    -11660
    x[1664]   c526      1
    x[1664]   c527      -1
    x[1665]   c126_2    1
    x[1665]   c223_1    -11660
    x[1665]   c264_1    -11660
    x[1665]   c526      1
    x[1665]   c528      -1
    x[1666]   c126_2    1
    x[1666]   c224_1    -11660
    x[1666]   c265_1    -11660
    x[1666]   c526      1
    x[1666]   c529      -1
    x[1667]   c121_2    1
    x[1667]   c225_1    -11660
    x[1667]   c266_1    -11660
    x[1667]   c526      1
    x[1667]   c530      -1
    x[1668]   c122_2    1
    x[1668]   c226_1    -11660
    x[1668]   c267_1    -11660
    x[1668]   c526      1
    x[1668]   c531      -1
    x[1669]   c123_2    1
    x[1669]   c230_1    -11660
    x[1669]   c271_1    -11660
    x[1669]   c526      1
    x[1669]   c532      -1
    x[1670]   c124_2    1
    x[1670]   c236_1    -11660
    x[1670]   c277_1    -11660
    x[1670]   c526      1
    x[1670]   c533      -1
    x[1671]   c125_2    1
    x[1671]   c244_1    -11660
    x[1671]   c285_1    -11660
    x[1671]   c526      1
    x[1671]   c534      -1
    x[1672]   c207_1    -11660
    x[1672]   c248_1    -11660
    x[1672]   c527      1
    x[1672]   c528      -1
    x[1673]   c209_1    -11660
    x[1673]   c250_1    -11660
    x[1673]   c527      1
    x[1673]   c529      -1
    x[1674]   c212_1    -11660
    x[1674]   c253_1    -11660
    x[1674]   c527      1
    x[1674]   c530      -1
    x[1675]   c216_1    -11660
    x[1675]   c257_1    -11660
    x[1675]   c527      1
    x[1675]   c531      -1
    x[1676]   c227_1    -11660
    x[1676]   c268_1    -11660
    x[1676]   c527      1
    x[1676]   c532      -1
    x[1677]   c231_1    -11660
    x[1677]   c272_1    -11660
    x[1677]   c527      1
    x[1677]   c533      -1
    x[1678]   c238_1    -11660
    x[1678]   c279_1    -11660
    x[1678]   c527      1
    x[1678]   c534      -1
    x[1679]   c207_1    -11660
    x[1679]   c248_1    -11660
    x[1679]   c527      -1
    x[1679]   c528      1
    x[1680]   c209_1    -11660
    x[1680]   c250_1    -11660
    x[1680]   c527      -1
    x[1680]   c529      1
    x[1681]   c212_1    -11660
    x[1681]   c253_1    -11660
    x[1681]   c527      -1
    x[1681]   c530      1
    x[1682]   c216_1    -11660
    x[1682]   c257_1    -11660
    x[1682]   c527      -1
    x[1682]   c531      1
    x[1683]   c227_1    -11660
    x[1683]   c268_1    -11660
    x[1683]   c527      -1
    x[1683]   c532      1
    x[1684]   c231_1    -11660
    x[1684]   c272_1    -11660
    x[1684]   c527      -1
    x[1684]   c533      1
    x[1685]   c238_1    -11660
    x[1685]   c279_1    -11660
    x[1685]   c527      -1
    x[1685]   c534      1
    x[1686]   c211_1    -11660
    x[1686]   c252_1    -11660
    x[1686]   c528      1
    x[1686]   c529      -1
    x[1687]   c214_1    -11660
    x[1687]   c255_1    -11660
    x[1687]   c528      1
    x[1687]   c530      -1
    x[1688]   c218_1    -11660
    x[1688]   c259_1    -11660
    x[1688]   c528      1
    x[1688]   c531      -1
    x[1689]   c232_1    -11660
    x[1689]   c273_1    -11660
    x[1689]   c528      1
    x[1689]   c533      -1
    x[1690]   c240_1    -11660
    x[1690]   c281_1    -11660
    x[1690]   c528      1
    x[1690]   c534      -1
    x[1691]   c211_1    -11660
    x[1691]   c252_1    -11660
    x[1691]   c528      -1
    x[1691]   c529      1
    x[1692]   c214_1    -11660
    x[1692]   c255_1    -11660
    x[1692]   c528      -1
    x[1692]   c530      1
    x[1693]   c218_1    -11660
    x[1693]   c259_1    -11660
    x[1693]   c528      -1
    x[1693]   c531      1
    x[1694]   c232_1    -11660
    x[1694]   c273_1    -11660
    x[1694]   c528      -1
    x[1694]   c533      1
    x[1695]   c240_1    -11660
    x[1695]   c281_1    -11660
    x[1695]   c528      -1
    x[1695]   c534      1
    x[1696]   c215_1    -11660
    x[1696]   c256_1    -11660
    x[1696]   c529      1
    x[1696]   c530      -1
    x[1697]   c219_1    -11660
    x[1697]   c260_1    -11660
    x[1697]   c529      1
    x[1697]   c531      -1
    x[1698]   c233_1    -11660
    x[1698]   c274_1    -11660
    x[1698]   c529      1
    x[1698]   c533      -1
    x[1699]   c241_1    -11660
    x[1699]   c282_1    -11660
    x[1699]   c529      1
    x[1699]   c534      -1
    x[1700]   c215_1    -11660
    x[1700]   c256_1    -11660
    x[1700]   c529      -1
    x[1700]   c530      1
    x[1701]   c219_1    -11660
    x[1701]   c260_1    -11660
    x[1701]   c529      -1
    x[1701]   c531      1
    x[1702]   c233_1    -11660
    x[1702]   c274_1    -11660
    x[1702]   c529      -1
    x[1702]   c533      1
    x[1703]   c241_1    -11660
    x[1703]   c282_1    -11660
    x[1703]   c529      -1
    x[1703]   c534      1
    x[1704]   c220_1    -11660
    x[1704]   c261_1    -11660
    x[1704]   c530      1
    x[1704]   c531      -1
    x[1705]   c228_1    -11660
    x[1705]   c269_1    -11660
    x[1705]   c530      1
    x[1705]   c532      -1
    x[1706]   c234_1    -11660
    x[1706]   c275_1    -11660
    x[1706]   c530      1
    x[1706]   c533      -1
    x[1707]   c242_1    -11660
    x[1707]   c283_1    -11660
    x[1707]   c530      1
    x[1707]   c534      -1
    x[1708]   c220_1    -11660
    x[1708]   c261_1    -11660
    x[1708]   c530      -1
    x[1708]   c531      1
    x[1709]   c228_1    -11660
    x[1709]   c269_1    -11660
    x[1709]   c530      -1
    x[1709]   c532      1
    x[1710]   c234_1    -11660
    x[1710]   c275_1    -11660
    x[1710]   c530      -1
    x[1710]   c533      1
    x[1711]   c242_1    -11660
    x[1711]   c283_1    -11660
    x[1711]   c530      -1
    x[1711]   c534      1
    x[1712]   c229_1    -11660
    x[1712]   c270_1    -11660
    x[1712]   c531      1
    x[1712]   c532      -1
    x[1713]   c235_1    -11660
    x[1713]   c276_1    -11660
    x[1713]   c531      1
    x[1713]   c533      -1
    x[1714]   c243_1    -11660
    x[1714]   c284_1    -11660
    x[1714]   c531      1
    x[1714]   c534      -1
    x[1715]   c229_1    -11660
    x[1715]   c270_1    -11660
    x[1715]   c531      -1
    x[1715]   c532      1
    x[1716]   c235_1    -11660
    x[1716]   c276_1    -11660
    x[1716]   c531      -1
    x[1716]   c533      1
    x[1717]   c243_1    -11660
    x[1717]   c284_1    -11660
    x[1717]   c531      -1
    x[1717]   c534      1
    x[1718]   c237_1    -11660
    x[1718]   c278_1    -11660
    x[1718]   c532      1
    x[1718]   c533      -1
    x[1719]   c245_1    -11660
    x[1719]   c286_1    -11660
    x[1719]   c532      1
    x[1719]   c534      -1
    x[1720]   c237_1    -11660
    x[1720]   c278_1    -11660
    x[1720]   c532      -1
    x[1720]   c533      1
    x[1721]   c245_1    -11660
    x[1721]   c286_1    -11660
    x[1721]   c532      -1
    x[1721]   c534      1
    x[1722]   c246_1    -11660
    x[1722]   c287_1    -11660
    x[1722]   c533      1
    x[1722]   c534      -1
    x[1723]   c246_1    -11660
    x[1723]   c287_1    -11660
    x[1723]   c533      -1
    x[1723]   c534      1
    x[1724]   c220_1    -10512
    x[1724]   c261_1    -10512
    x[1724]   c535      1
    x[1725]   c225_1    -10512
    x[1725]   c266_1    -10512
    x[1725]   c536      1
    x[1726]   c227_1    -10512
    x[1726]   c268_1    -10512
    x[1726]   c537      1
    x[1727]   c228_1    -10512
    x[1727]   c269_1    -10512
    x[1727]   c538      1
    x[1728]   c229_1    -10512
    x[1728]   c270_1    -10512
    x[1728]   c539      1
    x[1729]   c230_1    -10512
    x[1729]   c271_1    -10512
    x[1729]   c540      1
    x[1730]   c234_1    -10512
    x[1730]   c275_1    -10512
    x[1730]   c541      1
    x[1731]   c242_1    -10512
    x[1731]   c283_1    -10512
    x[1731]   c542      1
    x[1732]   c212_1    -10512
    x[1732]   c253_1    -10512
    x[1732]   c543      1
    x[1733]   c213_1    -10512
    x[1733]   c254_1    -10512
    x[1733]   c544      1
    x[1734]   c214_1    -10512
    x[1734]   c255_1    -10512
    x[1734]   c545      1
    x[1735]   c215_1    -10512
    x[1735]   c256_1    -10512
    x[1735]   c546      1
    x[1736]   c237_1    -10512
    x[1736]   c278_1    -10512
    x[1736]   c547      1
    x[1737]   c245_1    -10512
    x[1737]   c286_1    -10512
    x[1737]   c548      1
    x[1738]   c131_2    1
    x[1738]   c237_1    -10512
    x[1738]   c278_1    -10512
    x[1738]   c549      1
    x[1738]   c557      1
    x[1739]   c245_1    -10512
    x[1739]   c286_1    -10512
    x[1739]   c549      1
    x[1739]   c558      1
    x[1740]   c132_2    1
    x[1740]   c227_1    -10512
    x[1740]   c268_1    -10512
    x[1740]   c549      1
    x[1740]   c551      1
    x[1741]   c131_2    1
    x[1741]   c132_2    1
    x[1741]   c133_2    1
    x[1741]   c228_1    -10512
    x[1741]   c269_1    -10512
    x[1741]   c549      1
    x[1741]   c550      1
    x[1742]   c229_1    -10512
    x[1742]   c270_1    -10512
    x[1742]   c549      1
    x[1742]   c555      1
    x[1743]   c133_2    1
    x[1743]   c230_1    -10512
    x[1743]   c271_1    -10512
    x[1743]   c549      1
    x[1743]   c556      1
    x[1744]   c215_2    1
    x[1744]   c216_2    1
    x[1744]   c217_2    1
    x[1744]   c218_2    1
    x[1744]   c219_2    1
    x[1744]   c212_1    -10512
    x[1744]   c253_1    -10512
    x[1744]   c550      1
    x[1744]   c551      -1
    x[1745]   c215_2    1
    x[1745]   c213_1    -10512
    x[1745]   c254_1    -10512
    x[1745]   c550      1
    x[1745]   c552      -1
    x[1746]   c214_1    -10512
    x[1746]   c255_1    -10512
    x[1746]   c550      1
    x[1746]   c553      -1
    x[1747]   c216_2    1
    x[1747]   c215_1    -10512
    x[1747]   c256_1    -10512
    x[1747]   c550      1
    x[1747]   c554      -1
    x[1748]   c217_2    1
    x[1748]   c220_1    -10512
    x[1748]   c261_1    -10512
    x[1748]   c550      1
    x[1748]   c555      -1
    x[1749]   c225_1    -10512
    x[1749]   c266_1    -10512
    x[1749]   c550      1
    x[1749]   c556      -1
    x[1750]   c218_2    1
    x[1750]   c234_1    -10512
    x[1750]   c275_1    -10512
    x[1750]   c550      1
    x[1750]   c557      -1
    x[1751]   c219_2    1
    x[1751]   c242_1    -10512
    x[1751]   c283_1    -10512
    x[1751]   c550      1
    x[1751]   c558      -1
    x[1752]   c206_1    -10512
    x[1752]   c247_1    -10512
    x[1752]   c551      1
    x[1752]   c552      -1
    x[1753]   c207_1    -10512
    x[1753]   c248_1    -10512
    x[1753]   c551      1
    x[1753]   c553      -1
    x[1754]   c209_1    -10512
    x[1754]   c250_1    -10512
    x[1754]   c551      1
    x[1754]   c554      -1
    x[1755]   c216_1    -10512
    x[1755]   c257_1    -10512
    x[1755]   c551      1
    x[1755]   c555      -1
    x[1756]   c221_1    -10512
    x[1756]   c262_1    -10512
    x[1756]   c551      1
    x[1756]   c556      -1
    x[1757]   c231_1    -10512
    x[1757]   c272_1    -10512
    x[1757]   c551      1
    x[1757]   c557      -1
    x[1758]   c238_1    -10512
    x[1758]   c279_1    -10512
    x[1758]   c551      1
    x[1758]   c558      -1
    x[1759]   c206_1    -10512
    x[1759]   c247_1    -10512
    x[1759]   c551      -1
    x[1759]   c552      1
    x[1760]   c207_1    -10512
    x[1760]   c248_1    -10512
    x[1760]   c551      -1
    x[1760]   c553      1
    x[1761]   c209_1    -10512
    x[1761]   c250_1    -10512
    x[1761]   c551      -1
    x[1761]   c554      1
    x[1762]   c216_1    -10512
    x[1762]   c257_1    -10512
    x[1762]   c551      -1
    x[1762]   c555      1
    x[1763]   c221_1    -10512
    x[1763]   c262_1    -10512
    x[1763]   c551      -1
    x[1763]   c556      1
    x[1764]   c231_1    -10512
    x[1764]   c272_1    -10512
    x[1764]   c551      -1
    x[1764]   c557      1
    x[1765]   c238_1    -10512
    x[1765]   c279_1    -10512
    x[1765]   c551      -1
    x[1765]   c558      1
    x[1766]   c208_1    -10512
    x[1766]   c249_1    -10512
    x[1766]   c552      1
    x[1766]   c553      -1
    x[1767]   c210_1    -10512
    x[1767]   c251_1    -10512
    x[1767]   c552      1
    x[1767]   c554      -1
    x[1768]   c217_1    -10512
    x[1768]   c258_1    -10512
    x[1768]   c552      1
    x[1768]   c555      -1
    x[1769]   c222_1    -10512
    x[1769]   c263_1    -10512
    x[1769]   c552      1
    x[1769]   c556      -1
    x[1770]   c239_1    -10512
    x[1770]   c280_1    -10512
    x[1770]   c552      1
    x[1770]   c558      -1
    x[1771]   c208_1    -10512
    x[1771]   c249_1    -10512
    x[1771]   c552      -1
    x[1771]   c553      1
    x[1772]   c210_1    -10512
    x[1772]   c251_1    -10512
    x[1772]   c552      -1
    x[1772]   c554      1
    x[1773]   c217_1    -10512
    x[1773]   c258_1    -10512
    x[1773]   c552      -1
    x[1773]   c555      1
    x[1774]   c222_1    -10512
    x[1774]   c263_1    -10512
    x[1774]   c552      -1
    x[1774]   c556      1
    x[1775]   c239_1    -10512
    x[1775]   c280_1    -10512
    x[1775]   c552      -1
    x[1775]   c558      1
    x[1776]   c211_1    -10512
    x[1776]   c252_1    -10512
    x[1776]   c553      1
    x[1776]   c554      -1
    x[1777]   c218_1    -10512
    x[1777]   c259_1    -10512
    x[1777]   c553      1
    x[1777]   c555      -1
    x[1778]   c223_1    -10512
    x[1778]   c264_1    -10512
    x[1778]   c553      1
    x[1778]   c556      -1
    x[1779]   c232_1    -10512
    x[1779]   c273_1    -10512
    x[1779]   c553      1
    x[1779]   c557      -1
    x[1780]   c240_1    -10512
    x[1780]   c281_1    -10512
    x[1780]   c553      1
    x[1780]   c558      -1
    x[1781]   c211_1    -10512
    x[1781]   c252_1    -10512
    x[1781]   c553      -1
    x[1781]   c554      1
    x[1782]   c218_1    -10512
    x[1782]   c259_1    -10512
    x[1782]   c553      -1
    x[1782]   c555      1
    x[1783]   c223_1    -10512
    x[1783]   c264_1    -10512
    x[1783]   c553      -1
    x[1783]   c556      1
    x[1784]   c232_1    -10512
    x[1784]   c273_1    -10512
    x[1784]   c553      -1
    x[1784]   c557      1
    x[1785]   c240_1    -10512
    x[1785]   c281_1    -10512
    x[1785]   c553      -1
    x[1785]   c558      1
    x[1786]   c219_1    -10512
    x[1786]   c260_1    -10512
    x[1786]   c554      1
    x[1786]   c555      -1
    x[1787]   c224_1    -10512
    x[1787]   c265_1    -10512
    x[1787]   c554      1
    x[1787]   c556      -1
    x[1788]   c233_1    -10512
    x[1788]   c274_1    -10512
    x[1788]   c554      1
    x[1788]   c557      -1
    x[1789]   c241_1    -10512
    x[1789]   c282_1    -10512
    x[1789]   c554      1
    x[1789]   c558      -1
    x[1790]   c219_1    -10512
    x[1790]   c260_1    -10512
    x[1790]   c554      -1
    x[1790]   c555      1
    x[1791]   c224_1    -10512
    x[1791]   c265_1    -10512
    x[1791]   c554      -1
    x[1791]   c556      1
    x[1792]   c233_1    -10512
    x[1792]   c274_1    -10512
    x[1792]   c554      -1
    x[1792]   c557      1
    x[1793]   c241_1    -10512
    x[1793]   c282_1    -10512
    x[1793]   c554      -1
    x[1793]   c558      1
    x[1794]   c226_1    -10512
    x[1794]   c267_1    -10512
    x[1794]   c555      1
    x[1794]   c556      -1
    x[1795]   c235_1    -10512
    x[1795]   c276_1    -10512
    x[1795]   c555      1
    x[1795]   c557      -1
    x[1796]   c243_1    -10512
    x[1796]   c284_1    -10512
    x[1796]   c555      1
    x[1796]   c558      -1
    x[1797]   c226_1    -10512
    x[1797]   c267_1    -10512
    x[1797]   c555      -1
    x[1797]   c556      1
    x[1798]   c235_1    -10512
    x[1798]   c276_1    -10512
    x[1798]   c555      -1
    x[1798]   c557      1
    x[1799]   c243_1    -10512
    x[1799]   c284_1    -10512
    x[1799]   c555      -1
    x[1799]   c558      1
    x[1800]   c236_1    -10512
    x[1800]   c277_1    -10512
    x[1800]   c556      1
    x[1800]   c557      -1
    x[1801]   c244_1    -10512
    x[1801]   c285_1    -10512
    x[1801]   c556      1
    x[1801]   c558      -1
    x[1802]   c236_1    -10512
    x[1802]   c277_1    -10512
    x[1802]   c556      -1
    x[1802]   c557      1
    x[1803]   c244_1    -10512
    x[1803]   c285_1    -10512
    x[1803]   c556      -1
    x[1803]   c558      1
    x[1804]   c246_1    -10512
    x[1804]   c287_1    -10512
    x[1804]   c557      1
    x[1804]   c558      -1
    x[1805]   c246_1    -10512
    x[1805]   c287_1    -10512
    x[1805]   c557      -1
    x[1805]   c558      1
    x[1806]   c206_1    -2440
    x[1806]   c247_1    -2440
    x[1806]   c559      1
    x[1807]   c246_1    -2440
    x[1807]   c287_1    -2440
    x[1807]   c560      1
    x[1808]   c208_1    -2440
    x[1808]   c249_1    -2440
    x[1808]   c561      1
    x[1809]   c210_1    -2440
    x[1809]   c251_1    -2440
    x[1809]   c562      1
    x[1810]   c213_1    -2440
    x[1810]   c254_1    -2440
    x[1810]   c563      1
    x[1811]   c217_1    -2440
    x[1811]   c258_1    -2440
    x[1811]   c564      1
    x[1812]   c222_1    -2440
    x[1812]   c263_1    -2440
    x[1812]   c565      1
    x[1813]   c231_1    -2440
    x[1813]   c272_1    -2440
    x[1813]   c566      1
    x[1814]   c232_1    -2440
    x[1814]   c273_1    -2440
    x[1814]   c567      1
    x[1815]   c233_1    -2440
    x[1815]   c274_1    -2440
    x[1815]   c568      1
    x[1816]   c234_1    -2440
    x[1816]   c275_1    -2440
    x[1816]   c569      1
    x[1817]   c235_1    -2440
    x[1817]   c276_1    -2440
    x[1817]   c570      1
    x[1818]   c236_1    -2440
    x[1818]   c277_1    -2440
    x[1818]   c571      1
    x[1819]   c237_1    -2440
    x[1819]   c278_1    -2440
    x[1819]   c572      1
    x[1820]   c239_1    -2440
    x[1820]   c280_1    -2440
    x[1820]   c573      1
    x[1821]   c52_2     1
    x[1821]   c53_2     1
    x[1821]   c54_2     1
    x[1821]   c55_2     1
    x[1821]   c208_1    -2440
    x[1821]   c249_1    -2440
    x[1821]   c574      1
    x[1821]   c577      1
    x[1822]   c52_2     1
    x[1822]   c210_1    -2440
    x[1822]   c251_1    -2440
    x[1822]   c574      1
    x[1822]   c578      1
    x[1823]   c53_2     1
    x[1823]   c213_1    -2440
    x[1823]   c254_1    -2440
    x[1823]   c574      1
    x[1823]   c579      1
    x[1824]   c217_1    -2440
    x[1824]   c258_1    -2440
    x[1824]   c574      1
    x[1824]   c580      1
    x[1825]   c54_2     1
    x[1825]   c222_1    -2440
    x[1825]   c263_1    -2440
    x[1825]   c574      1
    x[1825]   c581      1
    x[1826]   c55_2     1
    x[1826]   c239_1    -2440
    x[1826]   c280_1    -2440
    x[1826]   c574      1
    x[1826]   c583      1
    x[1827]   c206_1    -2440
    x[1827]   c247_1    -2440
    x[1827]   c574      1
    x[1827]   c576      1
    x[1828]   c76_2     1
    x[1828]   c77_2     1
    x[1828]   c78_2     1
    x[1828]   c79_2     1
    x[1828]   c231_1    -2440
    x[1828]   c272_1    -2440
    x[1828]   c575      1
    x[1828]   c576      -1
    x[1829]   c80_2     1
    x[1829]   c232_1    -2440
    x[1829]   c273_1    -2440
    x[1829]   c575      1
    x[1829]   c577      -1
    x[1830]   c76_2     1
    x[1830]   c80_2     1
    x[1830]   c233_1    -2440
    x[1830]   c274_1    -2440
    x[1830]   c575      1
    x[1830]   c578      -1
    x[1831]   c234_1    -2440
    x[1831]   c275_1    -2440
    x[1831]   c575      1
    x[1831]   c579      -1
    x[1832]   c77_2     1
    x[1832]   c235_1    -2440
    x[1832]   c276_1    -2440
    x[1832]   c575      1
    x[1832]   c580      -1
    x[1833]   c78_2     1
    x[1833]   c236_1    -2440
    x[1833]   c277_1    -2440
    x[1833]   c575      1
    x[1833]   c581      -1
    x[1834]   c237_1    -2440
    x[1834]   c278_1    -2440
    x[1834]   c575      1
    x[1834]   c582      -1
    x[1835]   c79_2     1
    x[1835]   c246_1    -2440
    x[1835]   c287_1    -2440
    x[1835]   c575      1
    x[1835]   c583      -1
    x[1836]   c207_1    -2440
    x[1836]   c248_1    -2440
    x[1836]   c576      1
    x[1836]   c577      -1
    x[1837]   c209_1    -2440
    x[1837]   c250_1    -2440
    x[1837]   c576      1
    x[1837]   c578      -1
    x[1838]   c212_1    -2440
    x[1838]   c253_1    -2440
    x[1838]   c576      1
    x[1838]   c579      -1
    x[1839]   c216_1    -2440
    x[1839]   c257_1    -2440
    x[1839]   c576      1
    x[1839]   c580      -1
    x[1840]   c221_1    -2440
    x[1840]   c262_1    -2440
    x[1840]   c576      1
    x[1840]   c581      -1
    x[1841]   c227_1    -2440
    x[1841]   c268_1    -2440
    x[1841]   c576      1
    x[1841]   c582      -1
    x[1842]   c238_1    -2440
    x[1842]   c279_1    -2440
    x[1842]   c576      1
    x[1842]   c583      -1
    x[1843]   c207_1    -2440
    x[1843]   c248_1    -2440
    x[1843]   c576      -1
    x[1843]   c577      1
    x[1844]   c209_1    -2440
    x[1844]   c250_1    -2440
    x[1844]   c576      -1
    x[1844]   c578      1
    x[1845]   c212_1    -2440
    x[1845]   c253_1    -2440
    x[1845]   c576      -1
    x[1845]   c579      1
    x[1846]   c216_1    -2440
    x[1846]   c257_1    -2440
    x[1846]   c576      -1
    x[1846]   c580      1
    x[1847]   c221_1    -2440
    x[1847]   c262_1    -2440
    x[1847]   c576      -1
    x[1847]   c581      1
    x[1848]   c227_1    -2440
    x[1848]   c268_1    -2440
    x[1848]   c576      -1
    x[1848]   c582      1
    x[1849]   c238_1    -2440
    x[1849]   c279_1    -2440
    x[1849]   c576      -1
    x[1849]   c583      1
    x[1850]   c211_1    -2440
    x[1850]   c252_1    -2440
    x[1850]   c577      1
    x[1850]   c578      -1
    x[1851]   c214_1    -2440
    x[1851]   c255_1    -2440
    x[1851]   c577      1
    x[1851]   c579      -1
    x[1852]   c218_1    -2440
    x[1852]   c259_1    -2440
    x[1852]   c577      1
    x[1852]   c580      -1
    x[1853]   c223_1    -2440
    x[1853]   c264_1    -2440
    x[1853]   c577      1
    x[1853]   c581      -1
    x[1854]   c240_1    -2440
    x[1854]   c281_1    -2440
    x[1854]   c577      1
    x[1854]   c583      -1
    x[1855]   c211_1    -2440
    x[1855]   c252_1    -2440
    x[1855]   c577      -1
    x[1855]   c578      1
    x[1856]   c214_1    -2440
    x[1856]   c255_1    -2440
    x[1856]   c577      -1
    x[1856]   c579      1
    x[1857]   c218_1    -2440
    x[1857]   c259_1    -2440
    x[1857]   c577      -1
    x[1857]   c580      1
    x[1858]   c223_1    -2440
    x[1858]   c264_1    -2440
    x[1858]   c577      -1
    x[1858]   c581      1
    x[1859]   c240_1    -2440
    x[1859]   c281_1    -2440
    x[1859]   c577      -1
    x[1859]   c583      1
    x[1860]   c215_1    -2440
    x[1860]   c256_1    -2440
    x[1860]   c578      1
    x[1860]   c579      -1
    x[1861]   c219_1    -2440
    x[1861]   c260_1    -2440
    x[1861]   c578      1
    x[1861]   c580      -1
    x[1862]   c224_1    -2440
    x[1862]   c265_1    -2440
    x[1862]   c578      1
    x[1862]   c581      -1
    x[1863]   c241_1    -2440
    x[1863]   c282_1    -2440
    x[1863]   c578      1
    x[1863]   c583      -1
    x[1864]   c215_1    -2440
    x[1864]   c256_1    -2440
    x[1864]   c578      -1
    x[1864]   c579      1
    x[1865]   c219_1    -2440
    x[1865]   c260_1    -2440
    x[1865]   c578      -1
    x[1865]   c580      1
    x[1866]   c224_1    -2440
    x[1866]   c265_1    -2440
    x[1866]   c578      -1
    x[1866]   c581      1
    x[1867]   c241_1    -2440
    x[1867]   c282_1    -2440
    x[1867]   c578      -1
    x[1867]   c583      1
    x[1868]   c220_1    -2440
    x[1868]   c261_1    -2440
    x[1868]   c579      1
    x[1868]   c580      -1
    x[1869]   c225_1    -2440
    x[1869]   c266_1    -2440
    x[1869]   c579      1
    x[1869]   c581      -1
    x[1870]   c228_1    -2440
    x[1870]   c269_1    -2440
    x[1870]   c579      1
    x[1870]   c582      -1
    x[1871]   c242_1    -2440
    x[1871]   c283_1    -2440
    x[1871]   c579      1
    x[1871]   c583      -1
    x[1872]   c220_1    -2440
    x[1872]   c261_1    -2440
    x[1872]   c579      -1
    x[1872]   c580      1
    x[1873]   c225_1    -2440
    x[1873]   c266_1    -2440
    x[1873]   c579      -1
    x[1873]   c581      1
    x[1874]   c228_1    -2440
    x[1874]   c269_1    -2440
    x[1874]   c579      -1
    x[1874]   c582      1
    x[1875]   c242_1    -2440
    x[1875]   c283_1    -2440
    x[1875]   c579      -1
    x[1875]   c583      1
    x[1876]   c226_1    -2440
    x[1876]   c267_1    -2440
    x[1876]   c580      1
    x[1876]   c581      -1
    x[1877]   c229_1    -2440
    x[1877]   c270_1    -2440
    x[1877]   c580      1
    x[1877]   c582      -1
    x[1878]   c243_1    -2440
    x[1878]   c284_1    -2440
    x[1878]   c580      1
    x[1878]   c583      -1
    x[1879]   c226_1    -2440
    x[1879]   c267_1    -2440
    x[1879]   c580      -1
    x[1879]   c581      1
    x[1880]   c229_1    -2440
    x[1880]   c270_1    -2440
    x[1880]   c580      -1
    x[1880]   c582      1
    x[1881]   c243_1    -2440
    x[1881]   c284_1    -2440
    x[1881]   c580      -1
    x[1881]   c583      1
    x[1882]   c230_1    -2440
    x[1882]   c271_1    -2440
    x[1882]   c581      1
    x[1882]   c582      -1
    x[1883]   c244_1    -2440
    x[1883]   c285_1    -2440
    x[1883]   c581      1
    x[1883]   c583      -1
    x[1884]   c230_1    -2440
    x[1884]   c271_1    -2440
    x[1884]   c581      -1
    x[1884]   c582      1
    x[1885]   c244_1    -2440
    x[1885]   c285_1    -2440
    x[1885]   c581      -1
    x[1885]   c583      1
    x[1886]   c245_1    -2440
    x[1886]   c286_1    -2440
    x[1886]   c582      1
    x[1886]   c583      -1
    x[1887]   c245_1    -2440
    x[1887]   c286_1    -2440
    x[1887]   c582      -1
    x[1887]   c583      1
    x[1888]   c220_1    -4510
    x[1888]   c261_1    -4510
    x[1888]   c584      1
    x[1889]   c221_1    -4510
    x[1889]   c262_1    -4510
    x[1889]   c585      1
    x[1890]   c222_1    -4510
    x[1890]   c263_1    -4510
    x[1890]   c586      1
    x[1891]   c223_1    -4510
    x[1891]   c264_1    -4510
    x[1891]   c587      1
    x[1892]   c224_1    -4510
    x[1892]   c265_1    -4510
    x[1892]   c588      1
    x[1893]   c225_1    -4510
    x[1893]   c266_1    -4510
    x[1893]   c589      1
    x[1894]   c226_1    -4510
    x[1894]   c267_1    -4510
    x[1894]   c590      1
    x[1895]   c228_1    -4510
    x[1895]   c269_1    -4510
    x[1895]   c591      1
    x[1896]   c234_1    -4510
    x[1896]   c275_1    -4510
    x[1896]   c592      1
    x[1897]   c242_1    -4510
    x[1897]   c283_1    -4510
    x[1897]   c593      1
    x[1898]   c212_1    -4510
    x[1898]   c253_1    -4510
    x[1898]   c594      1
    x[1899]   c213_1    -4510
    x[1899]   c254_1    -4510
    x[1899]   c595      1
    x[1900]   c214_1    -4510
    x[1900]   c255_1    -4510
    x[1900]   c596      1
    x[1901]   c215_1    -4510
    x[1901]   c256_1    -4510
    x[1901]   c597      1
    x[1902]   c230_1    -4510
    x[1902]   c271_1    -4510
    x[1902]   c598      1
    x[1903]   c236_1    -4510
    x[1903]   c277_1    -4510
    x[1903]   c599      1
    x[1904]   c244_1    -4510
    x[1904]   c285_1    -4510
    x[1904]   c600      1
    x[1905]   c171_2    1
    x[1905]   c184_2    1
    x[1905]   c230_1    -4510
    x[1905]   c271_1    -4510
    x[1905]   c601      1
    x[1905]   c608      1
    x[1906]   c172_2    1
    x[1906]   c236_1    -4510
    x[1906]   c277_1    -4510
    x[1906]   c601      1
    x[1906]   c609      1
    x[1907]   c173_2    1
    x[1907]   c244_1    -4510
    x[1907]   c285_1    -4510
    x[1907]   c601      1
    x[1907]   c610      1
    x[1908]   c174_2    1
    x[1908]   c221_1    -4510
    x[1908]   c262_1    -4510
    x[1908]   c601      1
    x[1908]   c603      1
    x[1909]   c222_1    -4510
    x[1909]   c263_1    -4510
    x[1909]   c601      1
    x[1909]   c604      1
    x[1910]   c223_1    -4510
    x[1910]   c264_1    -4510
    x[1910]   c601      1
    x[1910]   c605      1
    x[1911]   c175_2    1
    x[1911]   c224_1    -4510
    x[1911]   c265_1    -4510
    x[1911]   c601      1
    x[1911]   c606      1
    x[1912]   c171_2    1
    x[1912]   c172_2    1
    x[1912]   c173_2    1
    x[1912]   c174_2    1
    x[1912]   c175_2    1
    x[1912]   c225_1    -4510
    x[1912]   c266_1    -4510
    x[1912]   c601      1
    x[1912]   c602      1
    x[1913]   c184_2    1
    x[1913]   c226_1    -4510
    x[1913]   c267_1    -4510
    x[1913]   c601      1
    x[1913]   c607      1
    x[1914]   c235_2    1
    x[1914]   c236_2    1
    x[1914]   c237_2    1
    x[1914]   c238_2    1
    x[1914]   c239_2    1
    x[1914]   c212_1    -4510
    x[1914]   c253_1    -4510
    x[1914]   c602      1
    x[1914]   c603      -1
    x[1915]   c235_2    1
    x[1915]   c213_1    -4510
    x[1915]   c254_1    -4510
    x[1915]   c602      1
    x[1915]   c604      -1
    x[1916]   c236_2    1
    x[1916]   c214_1    -4510
    x[1916]   c255_1    -4510
    x[1916]   c602      1
    x[1916]   c605      -1
    x[1917]   c237_2    1
    x[1917]   c215_1    -4510
    x[1917]   c256_1    -4510
    x[1917]   c602      1
    x[1917]   c606      -1
    x[1918]   c220_1    -4510
    x[1918]   c261_1    -4510
    x[1918]   c602      1
    x[1918]   c607      -1
    x[1919]   c238_2    1
    x[1919]   c228_1    -4510
    x[1919]   c269_1    -4510
    x[1919]   c602      1
    x[1919]   c608      -1
    x[1920]   c239_2    1
    x[1920]   c234_1    -4510
    x[1920]   c275_1    -4510
    x[1920]   c602      1
    x[1920]   c609      -1
    x[1921]   c242_1    -4510
    x[1921]   c283_1    -4510
    x[1921]   c602      1
    x[1921]   c610      -1
    x[1922]   c206_1    -4510
    x[1922]   c247_1    -4510
    x[1922]   c603      1
    x[1922]   c604      -1
    x[1923]   c207_1    -4510
    x[1923]   c248_1    -4510
    x[1923]   c603      1
    x[1923]   c605      -1
    x[1924]   c209_1    -4510
    x[1924]   c250_1    -4510
    x[1924]   c603      1
    x[1924]   c606      -1
    x[1925]   c216_1    -4510
    x[1925]   c257_1    -4510
    x[1925]   c603      1
    x[1925]   c607      -1
    x[1926]   c227_1    -4510
    x[1926]   c268_1    -4510
    x[1926]   c603      1
    x[1926]   c608      -1
    x[1927]   c231_1    -4510
    x[1927]   c272_1    -4510
    x[1927]   c603      1
    x[1927]   c609      -1
    x[1928]   c238_1    -4510
    x[1928]   c279_1    -4510
    x[1928]   c603      1
    x[1928]   c610      -1
    x[1929]   c206_1    -4510
    x[1929]   c247_1    -4510
    x[1929]   c603      -1
    x[1929]   c604      1
    x[1930]   c207_1    -4510
    x[1930]   c248_1    -4510
    x[1930]   c603      -1
    x[1930]   c605      1
    x[1931]   c209_1    -4510
    x[1931]   c250_1    -4510
    x[1931]   c603      -1
    x[1931]   c606      1
    x[1932]   c216_1    -4510
    x[1932]   c257_1    -4510
    x[1932]   c603      -1
    x[1932]   c607      1
    x[1933]   c227_1    -4510
    x[1933]   c268_1    -4510
    x[1933]   c603      -1
    x[1933]   c608      1
    x[1934]   c231_1    -4510
    x[1934]   c272_1    -4510
    x[1934]   c603      -1
    x[1934]   c609      1
    x[1935]   c238_1    -4510
    x[1935]   c279_1    -4510
    x[1935]   c603      -1
    x[1935]   c610      1
    x[1936]   c208_1    -4510
    x[1936]   c249_1    -4510
    x[1936]   c604      1
    x[1936]   c605      -1
    x[1937]   c210_1    -4510
    x[1937]   c251_1    -4510
    x[1937]   c604      1
    x[1937]   c606      -1
    x[1938]   c217_1    -4510
    x[1938]   c258_1    -4510
    x[1938]   c604      1
    x[1938]   c607      -1
    x[1939]   c239_1    -4510
    x[1939]   c280_1    -4510
    x[1939]   c604      1
    x[1939]   c610      -1
    x[1940]   c208_1    -4510
    x[1940]   c249_1    -4510
    x[1940]   c604      -1
    x[1940]   c605      1
    x[1941]   c210_1    -4510
    x[1941]   c251_1    -4510
    x[1941]   c604      -1
    x[1941]   c606      1
    x[1942]   c217_1    -4510
    x[1942]   c258_1    -4510
    x[1942]   c604      -1
    x[1942]   c607      1
    x[1943]   c239_1    -4510
    x[1943]   c280_1    -4510
    x[1943]   c604      -1
    x[1943]   c610      1
    x[1944]   c211_1    -4510
    x[1944]   c252_1    -4510
    x[1944]   c605      1
    x[1944]   c606      -1
    x[1945]   c218_1    -4510
    x[1945]   c259_1    -4510
    x[1945]   c605      1
    x[1945]   c607      -1
    x[1946]   c232_1    -4510
    x[1946]   c273_1    -4510
    x[1946]   c605      1
    x[1946]   c609      -1
    x[1947]   c240_1    -4510
    x[1947]   c281_1    -4510
    x[1947]   c605      1
    x[1947]   c610      -1
    x[1948]   c211_1    -4510
    x[1948]   c252_1    -4510
    x[1948]   c605      -1
    x[1948]   c606      1
    x[1949]   c218_1    -4510
    x[1949]   c259_1    -4510
    x[1949]   c605      -1
    x[1949]   c607      1
    x[1950]   c232_1    -4510
    x[1950]   c273_1    -4510
    x[1950]   c605      -1
    x[1950]   c609      1
    x[1951]   c240_1    -4510
    x[1951]   c281_1    -4510
    x[1951]   c605      -1
    x[1951]   c610      1
    x[1952]   c219_1    -4510
    x[1952]   c260_1    -4510
    x[1952]   c606      1
    x[1952]   c607      -1
    x[1953]   c233_1    -4510
    x[1953]   c274_1    -4510
    x[1953]   c606      1
    x[1953]   c609      -1
    x[1954]   c241_1    -4510
    x[1954]   c282_1    -4510
    x[1954]   c606      1
    x[1954]   c610      -1
    x[1955]   c219_1    -4510
    x[1955]   c260_1    -4510
    x[1955]   c606      -1
    x[1955]   c607      1
    x[1956]   c233_1    -4510
    x[1956]   c274_1    -4510
    x[1956]   c606      -1
    x[1956]   c609      1
    x[1957]   c241_1    -4510
    x[1957]   c282_1    -4510
    x[1957]   c606      -1
    x[1957]   c610      1
    x[1958]   c229_1    -4510
    x[1958]   c270_1    -4510
    x[1958]   c607      1
    x[1958]   c608      -1
    x[1959]   c235_1    -4510
    x[1959]   c276_1    -4510
    x[1959]   c607      1
    x[1959]   c609      -1
    x[1960]   c243_1    -4510
    x[1960]   c284_1    -4510
    x[1960]   c607      1
    x[1960]   c610      -1
    x[1961]   c229_1    -4510
    x[1961]   c270_1    -4510
    x[1961]   c607      -1
    x[1961]   c608      1
    x[1962]   c235_1    -4510
    x[1962]   c276_1    -4510
    x[1962]   c607      -1
    x[1962]   c609      1
    x[1963]   c243_1    -4510
    x[1963]   c284_1    -4510
    x[1963]   c607      -1
    x[1963]   c610      1
    x[1964]   c237_1    -4510
    x[1964]   c278_1    -4510
    x[1964]   c608      1
    x[1964]   c609      -1
    x[1965]   c245_1    -4510
    x[1965]   c286_1    -4510
    x[1965]   c608      1
    x[1965]   c610      -1
    x[1966]   c237_1    -4510
    x[1966]   c278_1    -4510
    x[1966]   c608      -1
    x[1966]   c609      1
    x[1967]   c245_1    -4510
    x[1967]   c286_1    -4510
    x[1967]   c608      -1
    x[1967]   c610      1
    x[1968]   c246_1    -4510
    x[1968]   c287_1    -4510
    x[1968]   c609      1
    x[1968]   c610      -1
    x[1969]   c246_1    -4510
    x[1969]   c287_1    -4510
    x[1969]   c609      -1
    x[1969]   c610      1
    x[1970]   c207_1    -9483
    x[1970]   c248_1    -9483
    x[1970]   c611      1
    x[1971]   c208_1    -9483
    x[1971]   c249_1    -9483
    x[1971]   c612      1
    x[1972]   c220_1    -9483
    x[1972]   c261_1    -9483
    x[1972]   c613      1
    x[1973]   c225_1    -9483
    x[1973]   c266_1    -9483
    x[1973]   c614      1
    x[1974]   c228_1    -9483
    x[1974]   c269_1    -9483
    x[1974]   c615      1
    x[1975]   c234_1    -9483
    x[1975]   c275_1    -9483
    x[1975]   c616      1
    x[1976]   c242_1    -9483
    x[1976]   c283_1    -9483
    x[1976]   c617      1
    x[1977]   c211_1    -9483
    x[1977]   c252_1    -9483
    x[1977]   c618      1
    x[1978]   c212_1    -9483
    x[1978]   c253_1    -9483
    x[1978]   c619      1
    x[1979]   c213_1    -9483
    x[1979]   c254_1    -9483
    x[1979]   c620      1
    x[1980]   c214_1    -9483
    x[1980]   c255_1    -9483
    x[1980]   c621      1
    x[1981]   c215_1    -9483
    x[1981]   c256_1    -9483
    x[1981]   c622      1
    x[1982]   c218_1    -9483
    x[1982]   c259_1    -9483
    x[1982]   c623      1
    x[1983]   c223_1    -9483
    x[1983]   c264_1    -9483
    x[1983]   c624      1
    x[1984]   c232_1    -9483
    x[1984]   c273_1    -9483
    x[1984]   c625      1
    x[1985]   c240_1    -9483
    x[1985]   c281_1    -9483
    x[1985]   c626      1
    x[1986]   c211_1    -9483
    x[1986]   c252_1    -9483
    x[1986]   c627      1
    x[1986]   c631      1
    x[1987]   c7_2      1
    x[1987]   c8_2      1
    x[1987]   c9_2      1
    x[1987]   c10_2     1
    x[1987]   c11_2     1
    x[1987]   c214_1    -9483
    x[1987]   c255_1    -9483
    x[1987]   c627      1
    x[1987]   c628      1
    x[1988]   c7_2      1
    x[1988]   c218_1    -9483
    x[1988]   c259_1    -9483
    x[1988]   c627      1
    x[1988]   c632      1
    x[1989]   c8_2      1
    x[1989]   c223_1    -9483
    x[1989]   c264_1    -9483
    x[1989]   c627      1
    x[1989]   c633      1
    x[1990]   c9_2      1
    x[1990]   c232_1    -9483
    x[1990]   c273_1    -9483
    x[1990]   c627      1
    x[1990]   c635      1
    x[1991]   c240_1    -9483
    x[1991]   c281_1    -9483
    x[1991]   c627      1
    x[1991]   c636      1
    x[1992]   c10_2     1
    x[1992]   c207_1    -9483
    x[1992]   c248_1    -9483
    x[1992]   c627      1
    x[1992]   c629      1
    x[1993]   c11_2     1
    x[1993]   c208_1    -9483
    x[1993]   c249_1    -9483
    x[1993]   c627      1
    x[1993]   c630      1
    x[1994]   c212_1    -9483
    x[1994]   c253_1    -9483
    x[1994]   c628      1
    x[1994]   c629      -1
    x[1995]   c213_1    -9483
    x[1995]   c254_1    -9483
    x[1995]   c628      1
    x[1995]   c630      -1
    x[1996]   c215_1    -9483
    x[1996]   c256_1    -9483
    x[1996]   c628      1
    x[1996]   c631      -1
    x[1997]   c220_1    -9483
    x[1997]   c261_1    -9483
    x[1997]   c628      1
    x[1997]   c632      -1
    x[1998]   c225_1    -9483
    x[1998]   c266_1    -9483
    x[1998]   c628      1
    x[1998]   c633      -1
    x[1999]   c228_1    -9483
    x[1999]   c269_1    -9483
    x[1999]   c628      1
    x[1999]   c634      -1
    x[2000]   c234_1    -9483
    x[2000]   c275_1    -9483
    x[2000]   c628      1
    x[2000]   c635      -1
    x[2001]   c242_1    -9483
    x[2001]   c283_1    -9483
    x[2001]   c628      1
    x[2001]   c636      -1
    x[2002]   c206_1    -9483
    x[2002]   c247_1    -9483
    x[2002]   c629      1
    x[2002]   c630      -1
    x[2003]   c209_1    -9483
    x[2003]   c250_1    -9483
    x[2003]   c629      1
    x[2003]   c631      -1
    x[2004]   c216_1    -9483
    x[2004]   c257_1    -9483
    x[2004]   c629      1
    x[2004]   c632      -1
    x[2005]   c221_1    -9483
    x[2005]   c262_1    -9483
    x[2005]   c629      1
    x[2005]   c633      -1
    x[2006]   c227_1    -9483
    x[2006]   c268_1    -9483
    x[2006]   c629      1
    x[2006]   c634      -1
    x[2007]   c231_1    -9483
    x[2007]   c272_1    -9483
    x[2007]   c629      1
    x[2007]   c635      -1
    x[2008]   c238_1    -9483
    x[2008]   c279_1    -9483
    x[2008]   c629      1
    x[2008]   c636      -1
    x[2009]   c206_1    -9483
    x[2009]   c247_1    -9483
    x[2009]   c629      -1
    x[2009]   c630      1
    x[2010]   c209_1    -9483
    x[2010]   c250_1    -9483
    x[2010]   c629      -1
    x[2010]   c631      1
    x[2011]   c216_1    -9483
    x[2011]   c257_1    -9483
    x[2011]   c629      -1
    x[2011]   c632      1
    x[2012]   c221_1    -9483
    x[2012]   c262_1    -9483
    x[2012]   c629      -1
    x[2012]   c633      1
    x[2013]   c227_1    -9483
    x[2013]   c268_1    -9483
    x[2013]   c629      -1
    x[2013]   c634      1
    x[2014]   c231_1    -9483
    x[2014]   c272_1    -9483
    x[2014]   c629      -1
    x[2014]   c635      1
    x[2015]   c238_1    -9483
    x[2015]   c279_1    -9483
    x[2015]   c629      -1
    x[2015]   c636      1
    x[2016]   c210_1    -9483
    x[2016]   c251_1    -9483
    x[2016]   c630      1
    x[2016]   c631      -1
    x[2017]   c217_1    -9483
    x[2017]   c258_1    -9483
    x[2017]   c630      1
    x[2017]   c632      -1
    x[2018]   c222_1    -9483
    x[2018]   c263_1    -9483
    x[2018]   c630      1
    x[2018]   c633      -1
    x[2019]   c239_1    -9483
    x[2019]   c280_1    -9483
    x[2019]   c630      1
    x[2019]   c636      -1
    x[2020]   c210_1    -9483
    x[2020]   c251_1    -9483
    x[2020]   c630      -1
    x[2020]   c631      1
    x[2021]   c217_1    -9483
    x[2021]   c258_1    -9483
    x[2021]   c630      -1
    x[2021]   c632      1
    x[2022]   c222_1    -9483
    x[2022]   c263_1    -9483
    x[2022]   c630      -1
    x[2022]   c633      1
    x[2023]   c239_1    -9483
    x[2023]   c280_1    -9483
    x[2023]   c630      -1
    x[2023]   c636      1
    x[2024]   c219_1    -9483
    x[2024]   c260_1    -9483
    x[2024]   c631      1
    x[2024]   c632      -1
    x[2025]   c224_1    -9483
    x[2025]   c265_1    -9483
    x[2025]   c631      1
    x[2025]   c633      -1
    x[2026]   c233_1    -9483
    x[2026]   c274_1    -9483
    x[2026]   c631      1
    x[2026]   c635      -1
    x[2027]   c241_1    -9483
    x[2027]   c282_1    -9483
    x[2027]   c631      1
    x[2027]   c636      -1
    x[2028]   c219_1    -9483
    x[2028]   c260_1    -9483
    x[2028]   c631      -1
    x[2028]   c632      1
    x[2029]   c224_1    -9483
    x[2029]   c265_1    -9483
    x[2029]   c631      -1
    x[2029]   c633      1
    x[2030]   c233_1    -9483
    x[2030]   c274_1    -9483
    x[2030]   c631      -1
    x[2030]   c635      1
    x[2031]   c241_1    -9483
    x[2031]   c282_1    -9483
    x[2031]   c631      -1
    x[2031]   c636      1
    x[2032]   c226_1    -9483
    x[2032]   c267_1    -9483
    x[2032]   c632      1
    x[2032]   c633      -1
    x[2033]   c229_1    -9483
    x[2033]   c270_1    -9483
    x[2033]   c632      1
    x[2033]   c634      -1
    x[2034]   c235_1    -9483
    x[2034]   c276_1    -9483
    x[2034]   c632      1
    x[2034]   c635      -1
    x[2035]   c243_1    -9483
    x[2035]   c284_1    -9483
    x[2035]   c632      1
    x[2035]   c636      -1
    x[2036]   c226_1    -9483
    x[2036]   c267_1    -9483
    x[2036]   c632      -1
    x[2036]   c633      1
    x[2037]   c229_1    -9483
    x[2037]   c270_1    -9483
    x[2037]   c632      -1
    x[2037]   c634      1
    x[2038]   c235_1    -9483
    x[2038]   c276_1    -9483
    x[2038]   c632      -1
    x[2038]   c635      1
    x[2039]   c243_1    -9483
    x[2039]   c284_1    -9483
    x[2039]   c632      -1
    x[2039]   c636      1
    x[2040]   c230_1    -9483
    x[2040]   c271_1    -9483
    x[2040]   c633      1
    x[2040]   c634      -1
    x[2041]   c236_1    -9483
    x[2041]   c277_1    -9483
    x[2041]   c633      1
    x[2041]   c635      -1
    x[2042]   c244_1    -9483
    x[2042]   c285_1    -9483
    x[2042]   c633      1
    x[2042]   c636      -1
    x[2043]   c230_1    -9483
    x[2043]   c271_1    -9483
    x[2043]   c633      -1
    x[2043]   c634      1
    x[2044]   c236_1    -9483
    x[2044]   c277_1    -9483
    x[2044]   c633      -1
    x[2044]   c635      1
    x[2045]   c244_1    -9483
    x[2045]   c285_1    -9483
    x[2045]   c633      -1
    x[2045]   c636      1
    x[2046]   c237_1    -9483
    x[2046]   c278_1    -9483
    x[2046]   c634      1
    x[2046]   c635      -1
    x[2047]   c245_1    -9483
    x[2047]   c286_1    -9483
    x[2047]   c634      1
    x[2047]   c636      -1
    x[2048]   c237_1    -9483
    x[2048]   c278_1    -9483
    x[2048]   c634      -1
    x[2048]   c635      1
    x[2049]   c245_1    -9483
    x[2049]   c286_1    -9483
    x[2049]   c634      -1
    x[2049]   c636      1
    x[2050]   c246_1    -9483
    x[2050]   c287_1    -9483
    x[2050]   c635      1
    x[2050]   c636      -1
    x[2051]   c246_1    -9483
    x[2051]   c287_1    -9483
    x[2051]   c635      -1
    x[2051]   c636      1
    x[2052]   c216_1    -857
    x[2052]   c257_1    -857
    x[2052]   c637      1
    x[2053]   c217_1    -857
    x[2053]   c258_1    -857
    x[2053]   c638      1
    x[2054]   c218_1    -857
    x[2054]   c259_1    -857
    x[2054]   c639      1
    x[2055]   c219_1    -857
    x[2055]   c260_1    -857
    x[2055]   c640      1
    x[2056]   c220_1    -857
    x[2056]   c261_1    -857
    x[2056]   c641      1
    x[2057]   c225_1    -857
    x[2057]   c266_1    -857
    x[2057]   c642      1
    x[2058]   c228_1    -857
    x[2058]   c269_1    -857
    x[2058]   c643      1
    x[2059]   c234_1    -857
    x[2059]   c275_1    -857
    x[2059]   c644      1
    x[2060]   c242_1    -857
    x[2060]   c283_1    -857
    x[2060]   c645      1
    x[2061]   c212_1    -857
    x[2061]   c253_1    -857
    x[2061]   c646      1
    x[2062]   c213_1    -857
    x[2062]   c254_1    -857
    x[2062]   c647      1
    x[2063]   c214_1    -857
    x[2063]   c255_1    -857
    x[2063]   c648      1
    x[2064]   c215_1    -857
    x[2064]   c256_1    -857
    x[2064]   c649      1
    x[2065]   c226_1    -857
    x[2065]   c267_1    -857
    x[2065]   c650      1
    x[2066]   c229_1    -857
    x[2066]   c270_1    -857
    x[2066]   c651      1
    x[2067]   c235_1    -857
    x[2067]   c276_1    -857
    x[2067]   c652      1
    x[2068]   c243_1    -857
    x[2068]   c284_1    -857
    x[2068]   c653      1
    x[2069]   c19_2     1
    x[2069]   c226_1    -857
    x[2069]   c267_1    -857
    x[2069]   c654      1
    x[2069]   c660      1
    x[2070]   c20_2     1
    x[2070]   c229_1    -857
    x[2070]   c270_1    -857
    x[2070]   c654      1
    x[2070]   c661      1
    x[2071]   c235_1    -857
    x[2071]   c276_1    -857
    x[2071]   c654      1
    x[2071]   c662      1
    x[2072]   c21_2     1
    x[2072]   c243_1    -857
    x[2072]   c284_1    -857
    x[2072]   c654      1
    x[2072]   c663      1
    x[2073]   c22_2     1
    x[2073]   c216_1    -857
    x[2073]   c257_1    -857
    x[2073]   c654      1
    x[2073]   c656      1
    x[2074]   c217_1    -857
    x[2074]   c258_1    -857
    x[2074]   c654      1
    x[2074]   c657      1
    x[2075]   c23_2     1
    x[2075]   c218_1    -857
    x[2075]   c259_1    -857
    x[2075]   c654      1
    x[2075]   c658      1
    x[2076]   c24_2     1
    x[2076]   c219_1    -857
    x[2076]   c260_1    -857
    x[2076]   c654      1
    x[2076]   c659      1
    x[2077]   c19_2     1
    x[2077]   c20_2     1
    x[2077]   c21_2     1
    x[2077]   c22_2     1
    x[2077]   c23_2     1
    x[2077]   c24_2     1
    x[2077]   c220_1    -857
    x[2077]   c261_1    -857
    x[2077]   c654      1
    x[2077]   c655      1
    x[2078]   c143_2    1
    x[2078]   c144_2    1
    x[2078]   c145_2    1
    x[2078]   c146_2    1
    x[2078]   c147_2    1
    x[2078]   c212_1    -857
    x[2078]   c253_1    -857
    x[2078]   c655      1
    x[2078]   c656      -1
    x[2079]   c143_2    1
    x[2079]   c213_1    -857
    x[2079]   c254_1    -857
    x[2079]   c655      1
    x[2079]   c657      -1
    x[2080]   c144_2    1
    x[2080]   c214_1    -857
    x[2080]   c255_1    -857
    x[2080]   c655      1
    x[2080]   c658      -1
    x[2081]   c145_2    1
    x[2081]   c215_1    -857
    x[2081]   c256_1    -857
    x[2081]   c655      1
    x[2081]   c659      -1
    x[2082]   c146_2    1
    x[2082]   c225_1    -857
    x[2082]   c266_1    -857
    x[2082]   c655      1
    x[2082]   c660      -1
    x[2083]   c228_1    -857
    x[2083]   c269_1    -857
    x[2083]   c655      1
    x[2083]   c661      -1
    x[2084]   c147_2    1
    x[2084]   c234_1    -857
    x[2084]   c275_1    -857
    x[2084]   c655      1
    x[2084]   c662      -1
    x[2085]   c242_1    -857
    x[2085]   c283_1    -857
    x[2085]   c655      1
    x[2085]   c663      -1
    x[2086]   c206_1    -857
    x[2086]   c247_1    -857
    x[2086]   c656      1
    x[2086]   c657      -1
    x[2087]   c207_1    -857
    x[2087]   c248_1    -857
    x[2087]   c656      1
    x[2087]   c658      -1
    x[2088]   c209_1    -857
    x[2088]   c250_1    -857
    x[2088]   c656      1
    x[2088]   c659      -1
    x[2089]   c221_1    -857
    x[2089]   c262_1    -857
    x[2089]   c656      1
    x[2089]   c660      -1
    x[2090]   c227_1    -857
    x[2090]   c268_1    -857
    x[2090]   c656      1
    x[2090]   c661      -1
    x[2091]   c231_1    -857
    x[2091]   c272_1    -857
    x[2091]   c656      1
    x[2091]   c662      -1
    x[2092]   c238_1    -857
    x[2092]   c279_1    -857
    x[2092]   c656      1
    x[2092]   c663      -1
    x[2093]   c206_1    -857
    x[2093]   c247_1    -857
    x[2093]   c656      -1
    x[2093]   c657      1
    x[2094]   c207_1    -857
    x[2094]   c248_1    -857
    x[2094]   c656      -1
    x[2094]   c658      1
    x[2095]   c209_1    -857
    x[2095]   c250_1    -857
    x[2095]   c656      -1
    x[2095]   c659      1
    x[2096]   c221_1    -857
    x[2096]   c262_1    -857
    x[2096]   c656      -1
    x[2096]   c660      1
    x[2097]   c227_1    -857
    x[2097]   c268_1    -857
    x[2097]   c656      -1
    x[2097]   c661      1
    x[2098]   c231_1    -857
    x[2098]   c272_1    -857
    x[2098]   c656      -1
    x[2098]   c662      1
    x[2099]   c238_1    -857
    x[2099]   c279_1    -857
    x[2099]   c656      -1
    x[2099]   c663      1
    x[2100]   c208_1    -857
    x[2100]   c249_1    -857
    x[2100]   c657      1
    x[2100]   c658      -1
    x[2101]   c210_1    -857
    x[2101]   c251_1    -857
    x[2101]   c657      1
    x[2101]   c659      -1
    x[2102]   c222_1    -857
    x[2102]   c263_1    -857
    x[2102]   c657      1
    x[2102]   c660      -1
    x[2103]   c239_1    -857
    x[2103]   c280_1    -857
    x[2103]   c657      1
    x[2103]   c663      -1
    x[2104]   c208_1    -857
    x[2104]   c249_1    -857
    x[2104]   c657      -1
    x[2104]   c658      1
    x[2105]   c210_1    -857
    x[2105]   c251_1    -857
    x[2105]   c657      -1
    x[2105]   c659      1
    x[2106]   c222_1    -857
    x[2106]   c263_1    -857
    x[2106]   c657      -1
    x[2106]   c660      1
    x[2107]   c239_1    -857
    x[2107]   c280_1    -857
    x[2107]   c657      -1
    x[2107]   c663      1
    x[2108]   c211_1    -857
    x[2108]   c252_1    -857
    x[2108]   c658      1
    x[2108]   c659      -1
    x[2109]   c223_1    -857
    x[2109]   c264_1    -857
    x[2109]   c658      1
    x[2109]   c660      -1
    x[2110]   c232_1    -857
    x[2110]   c273_1    -857
    x[2110]   c658      1
    x[2110]   c662      -1
    x[2111]   c240_1    -857
    x[2111]   c281_1    -857
    x[2111]   c658      1
    x[2111]   c663      -1
    x[2112]   c211_1    -857
    x[2112]   c252_1    -857
    x[2112]   c658      -1
    x[2112]   c659      1
    x[2113]   c223_1    -857
    x[2113]   c264_1    -857
    x[2113]   c658      -1
    x[2113]   c660      1
    x[2114]   c232_1    -857
    x[2114]   c273_1    -857
    x[2114]   c658      -1
    x[2114]   c662      1
    x[2115]   c240_1    -857
    x[2115]   c281_1    -857
    x[2115]   c658      -1
    x[2115]   c663      1
    x[2116]   c224_1    -857
    x[2116]   c265_1    -857
    x[2116]   c659      1
    x[2116]   c660      -1
    x[2117]   c233_1    -857
    x[2117]   c274_1    -857
    x[2117]   c659      1
    x[2117]   c662      -1
    x[2118]   c241_1    -857
    x[2118]   c282_1    -857
    x[2118]   c659      1
    x[2118]   c663      -1
    x[2119]   c224_1    -857
    x[2119]   c265_1    -857
    x[2119]   c659      -1
    x[2119]   c660      1
    x[2120]   c233_1    -857
    x[2120]   c274_1    -857
    x[2120]   c659      -1
    x[2120]   c662      1
    x[2121]   c241_1    -857
    x[2121]   c282_1    -857
    x[2121]   c659      -1
    x[2121]   c663      1
    x[2122]   c230_1    -857
    x[2122]   c271_1    -857
    x[2122]   c660      1
    x[2122]   c661      -1
    x[2123]   c236_1    -857
    x[2123]   c277_1    -857
    x[2123]   c660      1
    x[2123]   c662      -1
    x[2124]   c244_1    -857
    x[2124]   c285_1    -857
    x[2124]   c660      1
    x[2124]   c663      -1
    x[2125]   c230_1    -857
    x[2125]   c271_1    -857
    x[2125]   c660      -1
    x[2125]   c661      1
    x[2126]   c236_1    -857
    x[2126]   c277_1    -857
    x[2126]   c660      -1
    x[2126]   c662      1
    x[2127]   c244_1    -857
    x[2127]   c285_1    -857
    x[2127]   c660      -1
    x[2127]   c663      1
    x[2128]   c237_1    -857
    x[2128]   c278_1    -857
    x[2128]   c661      1
    x[2128]   c662      -1
    x[2129]   c245_1    -857
    x[2129]   c286_1    -857
    x[2129]   c661      1
    x[2129]   c663      -1
    x[2130]   c237_1    -857
    x[2130]   c278_1    -857
    x[2130]   c661      -1
    x[2130]   c662      1
    x[2131]   c245_1    -857
    x[2131]   c286_1    -857
    x[2131]   c661      -1
    x[2131]   c663      1
    x[2132]   c246_1    -857
    x[2132]   c287_1    -857
    x[2132]   c662      1
    x[2132]   c663      -1
    x[2133]   c246_1    -857
    x[2133]   c287_1    -857
    x[2133]   c662      -1
    x[2133]   c663      1
    x[2134]   c207_1    -304
    x[2134]   c248_1    -304
    x[2134]   c664      1
    x[2135]   c208_1    -304
    x[2135]   c249_1    -304
    x[2135]   c665      1
    x[2136]   c226_1    -304
    x[2136]   c267_1    -304
    x[2136]   c666      1
    x[2137]   c229_1    -304
    x[2137]   c270_1    -304
    x[2137]   c667      1
    x[2138]   c235_1    -304
    x[2138]   c276_1    -304
    x[2138]   c668      1
    x[2139]   c243_1    -304
    x[2139]   c284_1    -304
    x[2139]   c669      1
    x[2140]   c211_1    -304
    x[2140]   c252_1    -304
    x[2140]   c670      1
    x[2141]   c214_1    -304
    x[2141]   c255_1    -304
    x[2141]   c671      1
    x[2142]   c216_1    -304
    x[2142]   c257_1    -304
    x[2142]   c672      1
    x[2143]   c217_1    -304
    x[2143]   c258_1    -304
    x[2143]   c673      1
    x[2144]   c218_1    -304
    x[2144]   c259_1    -304
    x[2144]   c674      1
    x[2145]   c219_1    -304
    x[2145]   c260_1    -304
    x[2145]   c675      1
    x[2146]   c220_1    -304
    x[2146]   c261_1    -304
    x[2146]   c676      1
    x[2147]   c223_1    -304
    x[2147]   c264_1    -304
    x[2147]   c677      1
    x[2148]   c232_1    -304
    x[2148]   c273_1    -304
    x[2148]   c678      1
    x[2149]   c240_1    -304
    x[2149]   c281_1    -304
    x[2149]   c679      1
    x[2150]   c148_2    1
    x[2150]   c165_2    1
    x[2150]   c211_1    -304
    x[2150]   c252_1    -304
    x[2150]   c680      1
    x[2150]   c684      1
    x[2151]   c214_1    -304
    x[2151]   c255_1    -304
    x[2151]   c680      1
    x[2151]   c685      1
    x[2152]   c148_2    1
    x[2152]   c149_2    1
    x[2152]   c150_2    1
    x[2152]   c151_2    1
    x[2152]   c218_1    -304
    x[2152]   c259_1    -304
    x[2152]   c680      1
    x[2152]   c681      1
    x[2153]   c165_2    1
    x[2153]   c223_1    -304
    x[2153]   c264_1    -304
    x[2153]   c680      1
    x[2153]   c686      1
    x[2154]   c232_1    -304
    x[2154]   c273_1    -304
    x[2154]   c680      1
    x[2154]   c688      1
    x[2155]   c149_2    1
    x[2155]   c240_1    -304
    x[2155]   c281_1    -304
    x[2155]   c680      1
    x[2155]   c689      1
    x[2156]   c150_2    1
    x[2156]   c207_1    -304
    x[2156]   c248_1    -304
    x[2156]   c680      1
    x[2156]   c682      1
    x[2157]   c151_2    1
    x[2157]   c208_1    -304
    x[2157]   c249_1    -304
    x[2157]   c680      1
    x[2157]   c683      1
    x[2158]   c92_2     1
    x[2158]   c93_2     1
    x[2158]   c94_2     1
    x[2158]   c95_2     1
    x[2158]   c96_2     1
    x[2158]   c97_2     1
    x[2158]   c216_1    -304
    x[2158]   c257_1    -304
    x[2158]   c681      1
    x[2158]   c682      -1
    x[2159]   c92_2     1
    x[2159]   c217_1    -304
    x[2159]   c258_1    -304
    x[2159]   c681      1
    x[2159]   c683      -1
    x[2160]   c93_2     1
    x[2160]   c219_1    -304
    x[2160]   c260_1    -304
    x[2160]   c681      1
    x[2160]   c684      -1
    x[2161]   c94_2     1
    x[2161]   c220_1    -304
    x[2161]   c261_1    -304
    x[2161]   c681      1
    x[2161]   c685      -1
    x[2162]   c95_2     1
    x[2162]   c226_1    -304
    x[2162]   c267_1    -304
    x[2162]   c681      1
    x[2162]   c686      -1
    x[2163]   c96_2     1
    x[2163]   c229_1    -304
    x[2163]   c270_1    -304
    x[2163]   c681      1
    x[2163]   c687      -1
    x[2164]   c97_2     1
    x[2164]   c235_1    -304
    x[2164]   c276_1    -304
    x[2164]   c681      1
    x[2164]   c688      -1
    x[2165]   c243_1    -304
    x[2165]   c284_1    -304
    x[2165]   c681      1
    x[2165]   c689      -1
    x[2166]   c206_1    -304
    x[2166]   c247_1    -304
    x[2166]   c682      1
    x[2166]   c683      -1
    x[2167]   c209_1    -304
    x[2167]   c250_1    -304
    x[2167]   c682      1
    x[2167]   c684      -1
    x[2168]   c212_1    -304
    x[2168]   c253_1    -304
    x[2168]   c682      1
    x[2168]   c685      -1
    x[2169]   c221_1    -304
    x[2169]   c262_1    -304
    x[2169]   c682      1
    x[2169]   c686      -1
    x[2170]   c227_1    -304
    x[2170]   c268_1    -304
    x[2170]   c682      1
    x[2170]   c687      -1
    x[2171]   c231_1    -304
    x[2171]   c272_1    -304
    x[2171]   c682      1
    x[2171]   c688      -1
    x[2172]   c238_1    -304
    x[2172]   c279_1    -304
    x[2172]   c682      1
    x[2172]   c689      -1
    x[2173]   c206_1    -304
    x[2173]   c247_1    -304
    x[2173]   c682      -1
    x[2173]   c683      1
    x[2174]   c209_1    -304
    x[2174]   c250_1    -304
    x[2174]   c682      -1
    x[2174]   c684      1
    x[2175]   c212_1    -304
    x[2175]   c253_1    -304
    x[2175]   c682      -1
    x[2175]   c685      1
    x[2176]   c221_1    -304
    x[2176]   c262_1    -304
    x[2176]   c682      -1
    x[2176]   c686      1
    x[2177]   c227_1    -304
    x[2177]   c268_1    -304
    x[2177]   c682      -1
    x[2177]   c687      1
    x[2178]   c231_1    -304
    x[2178]   c272_1    -304
    x[2178]   c682      -1
    x[2178]   c688      1
    x[2179]   c238_1    -304
    x[2179]   c279_1    -304
    x[2179]   c682      -1
    x[2179]   c689      1
    x[2180]   c210_1    -304
    x[2180]   c251_1    -304
    x[2180]   c683      1
    x[2180]   c684      -1
    x[2181]   c213_1    -304
    x[2181]   c254_1    -304
    x[2181]   c683      1
    x[2181]   c685      -1
    x[2182]   c222_1    -304
    x[2182]   c263_1    -304
    x[2182]   c683      1
    x[2182]   c686      -1
    x[2183]   c239_1    -304
    x[2183]   c280_1    -304
    x[2183]   c683      1
    x[2183]   c689      -1
    x[2184]   c210_1    -304
    x[2184]   c251_1    -304
    x[2184]   c683      -1
    x[2184]   c684      1
    x[2185]   c213_1    -304
    x[2185]   c254_1    -304
    x[2185]   c683      -1
    x[2185]   c685      1
    x[2186]   c222_1    -304
    x[2186]   c263_1    -304
    x[2186]   c683      -1
    x[2186]   c686      1
    x[2187]   c239_1    -304
    x[2187]   c280_1    -304
    x[2187]   c683      -1
    x[2187]   c689      1
    x[2188]   c215_1    -304
    x[2188]   c256_1    -304
    x[2188]   c684      1
    x[2188]   c685      -1
    x[2189]   c224_1    -304
    x[2189]   c265_1    -304
    x[2189]   c684      1
    x[2189]   c686      -1
    x[2190]   c233_1    -304
    x[2190]   c274_1    -304
    x[2190]   c684      1
    x[2190]   c688      -1
    x[2191]   c241_1    -304
    x[2191]   c282_1    -304
    x[2191]   c684      1
    x[2191]   c689      -1
    x[2192]   c215_1    -304
    x[2192]   c256_1    -304
    x[2192]   c684      -1
    x[2192]   c685      1
    x[2193]   c224_1    -304
    x[2193]   c265_1    -304
    x[2193]   c684      -1
    x[2193]   c686      1
    x[2194]   c233_1    -304
    x[2194]   c274_1    -304
    x[2194]   c684      -1
    x[2194]   c688      1
    x[2195]   c241_1    -304
    x[2195]   c282_1    -304
    x[2195]   c684      -1
    x[2195]   c689      1
    x[2196]   c225_1    -304
    x[2196]   c266_1    -304
    x[2196]   c685      1
    x[2196]   c686      -1
    x[2197]   c228_1    -304
    x[2197]   c269_1    -304
    x[2197]   c685      1
    x[2197]   c687      -1
    x[2198]   c234_1    -304
    x[2198]   c275_1    -304
    x[2198]   c685      1
    x[2198]   c688      -1
    x[2199]   c242_1    -304
    x[2199]   c283_1    -304
    x[2199]   c685      1
    x[2199]   c689      -1
    x[2200]   c225_1    -304
    x[2200]   c266_1    -304
    x[2200]   c685      -1
    x[2200]   c686      1
    x[2201]   c228_1    -304
    x[2201]   c269_1    -304
    x[2201]   c685      -1
    x[2201]   c687      1
    x[2202]   c234_1    -304
    x[2202]   c275_1    -304
    x[2202]   c685      -1
    x[2202]   c688      1
    x[2203]   c242_1    -304
    x[2203]   c283_1    -304
    x[2203]   c685      -1
    x[2203]   c689      1
    x[2204]   c230_1    -304
    x[2204]   c271_1    -304
    x[2204]   c686      1
    x[2204]   c687      -1
    x[2205]   c236_1    -304
    x[2205]   c277_1    -304
    x[2205]   c686      1
    x[2205]   c688      -1
    x[2206]   c244_1    -304
    x[2206]   c285_1    -304
    x[2206]   c686      1
    x[2206]   c689      -1
    x[2207]   c230_1    -304
    x[2207]   c271_1    -304
    x[2207]   c686      -1
    x[2207]   c687      1
    x[2208]   c236_1    -304
    x[2208]   c277_1    -304
    x[2208]   c686      -1
    x[2208]   c688      1
    x[2209]   c244_1    -304
    x[2209]   c285_1    -304
    x[2209]   c686      -1
    x[2209]   c689      1
    x[2210]   c237_1    -304
    x[2210]   c278_1    -304
    x[2210]   c687      1
    x[2210]   c688      -1
    x[2211]   c245_1    -304
    x[2211]   c286_1    -304
    x[2211]   c687      1
    x[2211]   c689      -1
    x[2212]   c237_1    -304
    x[2212]   c278_1    -304
    x[2212]   c687      -1
    x[2212]   c688      1
    x[2213]   c245_1    -304
    x[2213]   c286_1    -304
    x[2213]   c687      -1
    x[2213]   c689      1
    x[2214]   c246_1    -304
    x[2214]   c287_1    -304
    x[2214]   c688      1
    x[2214]   c689      -1
    x[2215]   c246_1    -304
    x[2215]   c287_1    -304
    x[2215]   c688      -1
    x[2215]   c689      1
    x[2216]   c215_1    -148
    x[2216]   c256_1    -148
    x[2216]   c690      1
    x[2217]   c219_1    -148
    x[2217]   c260_1    -148
    x[2217]   c691      1
    x[2218]   c224_1    -148
    x[2218]   c265_1    -148
    x[2218]   c692      1
    x[2219]   c233_1    -148
    x[2219]   c274_1    -148
    x[2219]   c693      1
    x[2220]   c238_1    -148
    x[2220]   c279_1    -148
    x[2220]   c694      1
    x[2221]   c239_1    -148
    x[2221]   c280_1    -148
    x[2221]   c695      1
    x[2222]   c240_1    -148
    x[2222]   c281_1    -148
    x[2222]   c696      1
    x[2223]   c241_1    -148
    x[2223]   c282_1    -148
    x[2223]   c697      1
    x[2224]   c242_1    -148
    x[2224]   c283_1    -148
    x[2224]   c698      1
    x[2225]   c243_1    -148
    x[2225]   c284_1    -148
    x[2225]   c699      1
    x[2226]   c244_1    -148
    x[2226]   c285_1    -148
    x[2226]   c700      1
    x[2227]   c245_1    -148
    x[2227]   c286_1    -148
    x[2227]   c701      1
    x[2228]   c246_1    -148
    x[2228]   c287_1    -148
    x[2228]   c702      1
    x[2229]   c209_1    -148
    x[2229]   c250_1    -148
    x[2229]   c703      1
    x[2230]   c210_1    -148
    x[2230]   c251_1    -148
    x[2230]   c704      1
    x[2231]   c211_1    -148
    x[2231]   c252_1    -148
    x[2231]   c705      1
    x[2232]   c238_1    -148
    x[2232]   c279_1    -148
    x[2232]   c706      1
    x[2232]   c708      1
    x[2233]   c239_1    -148
    x[2233]   c280_1    -148
    x[2233]   c706      1
    x[2233]   c709      1
    x[2234]   c240_1    -148
    x[2234]   c281_1    -148
    x[2234]   c706      1
    x[2234]   c710      1
    x[2235]   c241_1    -148
    x[2235]   c282_1    -148
    x[2235]   c706      1
    x[2235]   c707      1
    x[2236]   c242_1    -148
    x[2236]   c283_1    -148
    x[2236]   c706      1
    x[2236]   c711      1
    x[2237]   c243_1    -148
    x[2237]   c284_1    -148
    x[2237]   c706      1
    x[2237]   c712      1
    x[2238]   c244_1    -148
    x[2238]   c285_1    -148
    x[2238]   c706      1
    x[2238]   c713      1
    x[2239]   c245_1    -148
    x[2239]   c286_1    -148
    x[2239]   c706      1
    x[2239]   c714      1
    x[2240]   c246_1    -148
    x[2240]   c287_1    -148
    x[2240]   c706      1
    x[2240]   c715      1
    x[2241]   c202_2    1
    x[2241]   c203_2    1
    x[2241]   c204_2    1
    x[2241]   c205_2    1
    x[2241]   c209_1    -148
    x[2241]   c250_1    -148
    x[2241]   c707      1
    x[2241]   c708      -1
    x[2242]   c206_2    1
    x[2242]   c210_1    -148
    x[2242]   c251_1    -148
    x[2242]   c707      1
    x[2242]   c709      -1
    x[2243]   c202_2    1
    x[2243]   c206_2    1
    x[2243]   c211_1    -148
    x[2243]   c252_1    -148
    x[2243]   c707      1
    x[2243]   c710      -1
    x[2244]   c203_2    1
    x[2244]   c215_1    -148
    x[2244]   c256_1    -148
    x[2244]   c707      1
    x[2244]   c711      -1
    x[2245]   c219_1    -148
    x[2245]   c260_1    -148
    x[2245]   c707      1
    x[2245]   c712      -1
    x[2246]   c204_2    1
    x[2246]   c224_1    -148
    x[2246]   c265_1    -148
    x[2246]   c707      1
    x[2246]   c713      -1
    x[2247]   c205_2    1
    x[2247]   c233_1    -148
    x[2247]   c274_1    -148
    x[2247]   c707      1
    x[2247]   c715      -1
    x[2248]   c206_1    -148
    x[2248]   c247_1    -148
    x[2248]   c708      1
    x[2248]   c709      -1
    x[2249]   c207_1    -148
    x[2249]   c248_1    -148
    x[2249]   c708      1
    x[2249]   c710      -1
    x[2250]   c212_1    -148
    x[2250]   c253_1    -148
    x[2250]   c708      1
    x[2250]   c711      -1
    x[2251]   c216_1    -148
    x[2251]   c257_1    -148
    x[2251]   c708      1
    x[2251]   c712      -1
    x[2252]   c221_1    -148
    x[2252]   c262_1    -148
    x[2252]   c708      1
    x[2252]   c713      -1
    x[2253]   c227_1    -148
    x[2253]   c268_1    -148
    x[2253]   c708      1
    x[2253]   c714      -1
    x[2254]   c231_1    -148
    x[2254]   c272_1    -148
    x[2254]   c708      1
    x[2254]   c715      -1
    x[2255]   c206_1    -148
    x[2255]   c247_1    -148
    x[2255]   c708      -1
    x[2255]   c709      1
    x[2256]   c207_1    -148
    x[2256]   c248_1    -148
    x[2256]   c708      -1
    x[2256]   c710      1
    x[2257]   c212_1    -148
    x[2257]   c253_1    -148
    x[2257]   c708      -1
    x[2257]   c711      1
    x[2258]   c216_1    -148
    x[2258]   c257_1    -148
    x[2258]   c708      -1
    x[2258]   c712      1
    x[2259]   c221_1    -148
    x[2259]   c262_1    -148
    x[2259]   c708      -1
    x[2259]   c713      1
    x[2260]   c227_1    -148
    x[2260]   c268_1    -148
    x[2260]   c708      -1
    x[2260]   c714      1
    x[2261]   c231_1    -148
    x[2261]   c272_1    -148
    x[2261]   c708      -1
    x[2261]   c715      1
    x[2262]   c208_1    -148
    x[2262]   c249_1    -148
    x[2262]   c709      1
    x[2262]   c710      -1
    x[2263]   c213_1    -148
    x[2263]   c254_1    -148
    x[2263]   c709      1
    x[2263]   c711      -1
    x[2264]   c217_1    -148
    x[2264]   c258_1    -148
    x[2264]   c709      1
    x[2264]   c712      -1
    x[2265]   c222_1    -148
    x[2265]   c263_1    -148
    x[2265]   c709      1
    x[2265]   c713      -1
    x[2266]   c208_1    -148
    x[2266]   c249_1    -148
    x[2266]   c709      -1
    x[2266]   c710      1
    x[2267]   c213_1    -148
    x[2267]   c254_1    -148
    x[2267]   c709      -1
    x[2267]   c711      1
    x[2268]   c217_1    -148
    x[2268]   c258_1    -148
    x[2268]   c709      -1
    x[2268]   c712      1
    x[2269]   c222_1    -148
    x[2269]   c263_1    -148
    x[2269]   c709      -1
    x[2269]   c713      1
    x[2270]   c214_1    -148
    x[2270]   c255_1    -148
    x[2270]   c710      1
    x[2270]   c711      -1
    x[2271]   c218_1    -148
    x[2271]   c259_1    -148
    x[2271]   c710      1
    x[2271]   c712      -1
    x[2272]   c223_1    -148
    x[2272]   c264_1    -148
    x[2272]   c710      1
    x[2272]   c713      -1
    x[2273]   c232_1    -148
    x[2273]   c273_1    -148
    x[2273]   c710      1
    x[2273]   c715      -1
    x[2274]   c214_1    -148
    x[2274]   c255_1    -148
    x[2274]   c710      -1
    x[2274]   c711      1
    x[2275]   c218_1    -148
    x[2275]   c259_1    -148
    x[2275]   c710      -1
    x[2275]   c712      1
    x[2276]   c223_1    -148
    x[2276]   c264_1    -148
    x[2276]   c710      -1
    x[2276]   c713      1
    x[2277]   c232_1    -148
    x[2277]   c273_1    -148
    x[2277]   c710      -1
    x[2277]   c715      1
    x[2278]   c220_1    -148
    x[2278]   c261_1    -148
    x[2278]   c711      1
    x[2278]   c712      -1
    x[2279]   c225_1    -148
    x[2279]   c266_1    -148
    x[2279]   c711      1
    x[2279]   c713      -1
    x[2280]   c228_1    -148
    x[2280]   c269_1    -148
    x[2280]   c711      1
    x[2280]   c714      -1
    x[2281]   c234_1    -148
    x[2281]   c275_1    -148
    x[2281]   c711      1
    x[2281]   c715      -1
    x[2282]   c220_1    -148
    x[2282]   c261_1    -148
    x[2282]   c711      -1
    x[2282]   c712      1
    x[2283]   c225_1    -148
    x[2283]   c266_1    -148
    x[2283]   c711      -1
    x[2283]   c713      1
    x[2284]   c228_1    -148
    x[2284]   c269_1    -148
    x[2284]   c711      -1
    x[2284]   c714      1
    x[2285]   c234_1    -148
    x[2285]   c275_1    -148
    x[2285]   c711      -1
    x[2285]   c715      1
    x[2286]   c226_1    -148
    x[2286]   c267_1    -148
    x[2286]   c712      1
    x[2286]   c713      -1
    x[2287]   c229_1    -148
    x[2287]   c270_1    -148
    x[2287]   c712      1
    x[2287]   c714      -1
    x[2288]   c235_1    -148
    x[2288]   c276_1    -148
    x[2288]   c712      1
    x[2288]   c715      -1
    x[2289]   c226_1    -148
    x[2289]   c267_1    -148
    x[2289]   c712      -1
    x[2289]   c713      1
    x[2290]   c229_1    -148
    x[2290]   c270_1    -148
    x[2290]   c712      -1
    x[2290]   c714      1
    x[2291]   c235_1    -148
    x[2291]   c276_1    -148
    x[2291]   c712      -1
    x[2291]   c715      1
    x[2292]   c230_1    -148
    x[2292]   c271_1    -148
    x[2292]   c713      1
    x[2292]   c714      -1
    x[2293]   c236_1    -148
    x[2293]   c277_1    -148
    x[2293]   c713      1
    x[2293]   c715      -1
    x[2294]   c230_1    -148
    x[2294]   c271_1    -148
    x[2294]   c713      -1
    x[2294]   c714      1
    x[2295]   c236_1    -148
    x[2295]   c277_1    -148
    x[2295]   c713      -1
    x[2295]   c715      1
    x[2296]   c237_1    -148
    x[2296]   c278_1    -148
    x[2296]   c714      1
    x[2296]   c715      -1
    x[2297]   c237_1    -148
    x[2297]   c278_1    -148
    x[2297]   c714      -1
    x[2297]   c715      1
    x[2298]   c207_1    -426
    x[2298]   c248_1    -426
    x[2298]   c716      1
    x[2299]   c208_1    -426
    x[2299]   c249_1    -426
    x[2299]   c717      1
    x[2300]   c230_1    -426
    x[2300]   c271_1    -426
    x[2300]   c718      1
    x[2301]   c236_1    -426
    x[2301]   c277_1    -426
    x[2301]   c719      1
    x[2302]   c244_1    -426
    x[2302]   c285_1    -426
    x[2302]   c720      1
    x[2303]   c211_1    -426
    x[2303]   c252_1    -426
    x[2303]   c721      1
    x[2304]   c214_1    -426
    x[2304]   c255_1    -426
    x[2304]   c722      1
    x[2305]   c218_1    -426
    x[2305]   c259_1    -426
    x[2305]   c723      1
    x[2306]   c221_1    -426
    x[2306]   c262_1    -426
    x[2306]   c724      1
    x[2307]   c222_1    -426
    x[2307]   c263_1    -426
    x[2307]   c725      1
    x[2308]   c223_1    -426
    x[2308]   c264_1    -426
    x[2308]   c726      1
    x[2309]   c224_1    -426
    x[2309]   c265_1    -426
    x[2309]   c727      1
    x[2310]   c225_1    -426
    x[2310]   c266_1    -426
    x[2310]   c728      1
    x[2311]   c226_1    -426
    x[2311]   c267_1    -426
    x[2311]   c729      1
    x[2312]   c232_1    -426
    x[2312]   c273_1    -426
    x[2312]   c730      1
    x[2313]   c240_1    -426
    x[2313]   c281_1    -426
    x[2313]   c731      1
    x[2314]   c247_2    1
    x[2314]   c211_1    -426
    x[2314]   c252_1    -426
    x[2314]   c732      1
    x[2314]   c736      1
    x[2315]   c248_2    1
    x[2315]   c214_1    -426
    x[2315]   c255_1    -426
    x[2315]   c732      1
    x[2315]   c737      1
    x[2316]   c249_2    1
    x[2316]   c218_1    -426
    x[2316]   c259_1    -426
    x[2316]   c732      1
    x[2316]   c738      1
    x[2317]   c247_2    1
    x[2317]   c248_2    1
    x[2317]   c249_2    1
    x[2317]   c250_2    1
    x[2317]   c251_2    1
    x[2317]   c223_1    -426
    x[2317]   c264_1    -426
    x[2317]   c732      1
    x[2317]   c733      1
    x[2318]   c232_1    -426
    x[2318]   c273_1    -426
    x[2318]   c732      1
    x[2318]   c740      1
    x[2319]   c250_2    1
    x[2319]   c240_1    -426
    x[2319]   c281_1    -426
    x[2319]   c732      1
    x[2319]   c741      1
    x[2320]   c251_2    1
    x[2320]   c207_1    -426
    x[2320]   c248_1    -426
    x[2320]   c732      1
    x[2320]   c734      1
    x[2321]   c208_1    -426
    x[2321]   c249_1    -426
    x[2321]   c732      1
    x[2321]   c735      1
    x[2322]   c221_1    -426
    x[2322]   c262_1    -426
    x[2322]   c733      1
    x[2322]   c734      -1
    x[2323]   c222_1    -426
    x[2323]   c263_1    -426
    x[2323]   c733      1
    x[2323]   c735      -1
    x[2324]   c224_1    -426
    x[2324]   c265_1    -426
    x[2324]   c733      1
    x[2324]   c736      -1
    x[2325]   c225_1    -426
    x[2325]   c266_1    -426
    x[2325]   c733      1
    x[2325]   c737      -1
    x[2326]   c226_1    -426
    x[2326]   c267_1    -426
    x[2326]   c733      1
    x[2326]   c738      -1
    x[2327]   c230_1    -426
    x[2327]   c271_1    -426
    x[2327]   c733      1
    x[2327]   c739      -1
    x[2328]   c236_1    -426
    x[2328]   c277_1    -426
    x[2328]   c733      1
    x[2328]   c740      -1
    x[2329]   c244_1    -426
    x[2329]   c285_1    -426
    x[2329]   c733      1
    x[2329]   c741      -1
    x[2330]   c206_1    -426
    x[2330]   c247_1    -426
    x[2330]   c734      1
    x[2330]   c735      -1
    x[2331]   c209_1    -426
    x[2331]   c250_1    -426
    x[2331]   c734      1
    x[2331]   c736      -1
    x[2332]   c212_1    -426
    x[2332]   c253_1    -426
    x[2332]   c734      1
    x[2332]   c737      -1
    x[2333]   c216_1    -426
    x[2333]   c257_1    -426
    x[2333]   c734      1
    x[2333]   c738      -1
    x[2334]   c227_1    -426
    x[2334]   c268_1    -426
    x[2334]   c734      1
    x[2334]   c739      -1
    x[2335]   c231_1    -426
    x[2335]   c272_1    -426
    x[2335]   c734      1
    x[2335]   c740      -1
    x[2336]   c238_1    -426
    x[2336]   c279_1    -426
    x[2336]   c734      1
    x[2336]   c741      -1
    x[2337]   c206_1    -426
    x[2337]   c247_1    -426
    x[2337]   c734      -1
    x[2337]   c735      1
    x[2338]   c209_1    -426
    x[2338]   c250_1    -426
    x[2338]   c734      -1
    x[2338]   c736      1
    x[2339]   c212_1    -426
    x[2339]   c253_1    -426
    x[2339]   c734      -1
    x[2339]   c737      1
    x[2340]   c216_1    -426
    x[2340]   c257_1    -426
    x[2340]   c734      -1
    x[2340]   c738      1
    x[2341]   c227_1    -426
    x[2341]   c268_1    -426
    x[2341]   c734      -1
    x[2341]   c739      1
    x[2342]   c231_1    -426
    x[2342]   c272_1    -426
    x[2342]   c734      -1
    x[2342]   c740      1
    x[2343]   c238_1    -426
    x[2343]   c279_1    -426
    x[2343]   c734      -1
    x[2343]   c741      1
    x[2344]   c210_1    -426
    x[2344]   c251_1    -426
    x[2344]   c735      1
    x[2344]   c736      -1
    x[2345]   c213_1    -426
    x[2345]   c254_1    -426
    x[2345]   c735      1
    x[2345]   c737      -1
    x[2346]   c217_1    -426
    x[2346]   c258_1    -426
    x[2346]   c735      1
    x[2346]   c738      -1
    x[2347]   c239_1    -426
    x[2347]   c280_1    -426
    x[2347]   c735      1
    x[2347]   c741      -1
    x[2348]   c210_1    -426
    x[2348]   c251_1    -426
    x[2348]   c735      -1
    x[2348]   c736      1
    x[2349]   c213_1    -426
    x[2349]   c254_1    -426
    x[2349]   c735      -1
    x[2349]   c737      1
    x[2350]   c217_1    -426
    x[2350]   c258_1    -426
    x[2350]   c735      -1
    x[2350]   c738      1
    x[2351]   c239_1    -426
    x[2351]   c280_1    -426
    x[2351]   c735      -1
    x[2351]   c741      1
    x[2352]   c215_1    -426
    x[2352]   c256_1    -426
    x[2352]   c736      1
    x[2352]   c737      -1
    x[2353]   c219_1    -426
    x[2353]   c260_1    -426
    x[2353]   c736      1
    x[2353]   c738      -1
    x[2354]   c233_1    -426
    x[2354]   c274_1    -426
    x[2354]   c736      1
    x[2354]   c740      -1
    x[2355]   c241_1    -426
    x[2355]   c282_1    -426
    x[2355]   c736      1
    x[2355]   c741      -1
    x[2356]   c215_1    -426
    x[2356]   c256_1    -426
    x[2356]   c736      -1
    x[2356]   c737      1
    x[2357]   c219_1    -426
    x[2357]   c260_1    -426
    x[2357]   c736      -1
    x[2357]   c738      1
    x[2358]   c233_1    -426
    x[2358]   c274_1    -426
    x[2358]   c736      -1
    x[2358]   c740      1
    x[2359]   c241_1    -426
    x[2359]   c282_1    -426
    x[2359]   c736      -1
    x[2359]   c741      1
    x[2360]   c220_1    -426
    x[2360]   c261_1    -426
    x[2360]   c737      1
    x[2360]   c738      -1
    x[2361]   c228_1    -426
    x[2361]   c269_1    -426
    x[2361]   c737      1
    x[2361]   c739      -1
    x[2362]   c234_1    -426
    x[2362]   c275_1    -426
    x[2362]   c737      1
    x[2362]   c740      -1
    x[2363]   c242_1    -426
    x[2363]   c283_1    -426
    x[2363]   c737      1
    x[2363]   c741      -1
    x[2364]   c220_1    -426
    x[2364]   c261_1    -426
    x[2364]   c737      -1
    x[2364]   c738      1
    x[2365]   c228_1    -426
    x[2365]   c269_1    -426
    x[2365]   c737      -1
    x[2365]   c739      1
    x[2366]   c234_1    -426
    x[2366]   c275_1    -426
    x[2366]   c737      -1
    x[2366]   c740      1
    x[2367]   c242_1    -426
    x[2367]   c283_1    -426
    x[2367]   c737      -1
    x[2367]   c741      1
    x[2368]   c229_1    -426
    x[2368]   c270_1    -426
    x[2368]   c738      1
    x[2368]   c739      -1
    x[2369]   c235_1    -426
    x[2369]   c276_1    -426
    x[2369]   c738      1
    x[2369]   c740      -1
    x[2370]   c243_1    -426
    x[2370]   c284_1    -426
    x[2370]   c738      1
    x[2370]   c741      -1
    x[2371]   c229_1    -426
    x[2371]   c270_1    -426
    x[2371]   c738      -1
    x[2371]   c739      1
    x[2372]   c235_1    -426
    x[2372]   c276_1    -426
    x[2372]   c738      -1
    x[2372]   c740      1
    x[2373]   c243_1    -426
    x[2373]   c284_1    -426
    x[2373]   c738      -1
    x[2373]   c741      1
    x[2374]   c237_1    -426
    x[2374]   c278_1    -426
    x[2374]   c739      1
    x[2374]   c740      -1
    x[2375]   c245_1    -426
    x[2375]   c286_1    -426
    x[2375]   c739      1
    x[2375]   c741      -1
    x[2376]   c237_1    -426
    x[2376]   c278_1    -426
    x[2376]   c739      -1
    x[2376]   c740      1
    x[2377]   c245_1    -426
    x[2377]   c286_1    -426
    x[2377]   c739      -1
    x[2377]   c741      1
    x[2378]   c246_1    -426
    x[2378]   c287_1    -426
    x[2378]   c740      1
    x[2378]   c741      -1
    x[2379]   c246_1    -426
    x[2379]   c287_1    -426
    x[2379]   c740      -1
    x[2379]   c741      1
    x[2380]   c215_1    -1153
    x[2380]   c256_1    -1153
    x[2380]   c742      1
    x[2381]   c219_1    -1153
    x[2381]   c260_1    -1153
    x[2381]   c743      1
    x[2382]   c224_1    -1153
    x[2382]   c265_1    -1153
    x[2382]   c744      1
    x[2383]   c227_1    -1153
    x[2383]   c268_1    -1153
    x[2383]   c745      1
    x[2384]   c228_1    -1153
    x[2384]   c269_1    -1153
    x[2384]   c746      1
    x[2385]   c229_1    -1153
    x[2385]   c270_1    -1153
    x[2385]   c747      1
    x[2386]   c230_1    -1153
    x[2386]   c271_1    -1153
    x[2386]   c748      1
    x[2387]   c233_1    -1153
    x[2387]   c274_1    -1153
    x[2387]   c749      1
    x[2388]   c241_1    -1153
    x[2388]   c282_1    -1153
    x[2388]   c750      1
    x[2389]   c209_1    -1153
    x[2389]   c250_1    -1153
    x[2389]   c751      1
    x[2390]   c210_1    -1153
    x[2390]   c251_1    -1153
    x[2390]   c752      1
    x[2391]   c211_1    -1153
    x[2391]   c252_1    -1153
    x[2391]   c753      1
    x[2392]   c237_1    -1153
    x[2392]   c278_1    -1153
    x[2392]   c754      1
    x[2393]   c245_1    -1153
    x[2393]   c286_1    -1153
    x[2393]   c755      1
    x[2394]   c56_2     1
    x[2394]   c57_2     1
    x[2394]   c58_2     1
    x[2394]   c237_1    -1153
    x[2394]   c278_1    -1153
    x[2394]   c756      1
    x[2394]   c764      1
    x[2395]   c56_2     1
    x[2395]   c245_1    -1153
    x[2395]   c286_1    -1153
    x[2395]   c756      1
    x[2395]   c765      1
    x[2396]   c227_1    -1153
    x[2396]   c268_1    -1153
    x[2396]   c756      1
    x[2396]   c758      1
    x[2397]   c57_2     1
    x[2397]   c228_1    -1153
    x[2397]   c269_1    -1153
    x[2397]   c756      1
    x[2397]   c761      1
    x[2398]   c229_1    -1153
    x[2398]   c270_1    -1153
    x[2398]   c756      1
    x[2398]   c762      1
    x[2399]   c58_2     1
    x[2399]   c230_1    -1153
    x[2399]   c271_1    -1153
    x[2399]   c756      1
    x[2399]   c763      1
    x[2400]   c209_1    -1153
    x[2400]   c250_1    -1153
    x[2400]   c757      1
    x[2400]   c758      -1
    x[2401]   c127_2    1
    x[2401]   c210_1    -1153
    x[2401]   c251_1    -1153
    x[2401]   c757      1
    x[2401]   c759      -1
    x[2402]   c127_2    1
    x[2402]   c211_1    -1153
    x[2402]   c252_1    -1153
    x[2402]   c757      1
    x[2402]   c760      -1
    x[2403]   c215_1    -1153
    x[2403]   c256_1    -1153
    x[2403]   c757      1
    x[2403]   c761      -1
    x[2404]   c219_1    -1153
    x[2404]   c260_1    -1153
    x[2404]   c757      1
    x[2404]   c762      -1
    x[2405]   c224_1    -1153
    x[2405]   c265_1    -1153
    x[2405]   c757      1
    x[2405]   c763      -1
    x[2406]   c233_1    -1153
    x[2406]   c274_1    -1153
    x[2406]   c757      1
    x[2406]   c764      -1
    x[2407]   c241_1    -1153
    x[2407]   c282_1    -1153
    x[2407]   c757      1
    x[2407]   c765      -1
    x[2408]   c206_1    -1153
    x[2408]   c247_1    -1153
    x[2408]   c758      1
    x[2408]   c759      -1
    x[2409]   c207_1    -1153
    x[2409]   c248_1    -1153
    x[2409]   c758      1
    x[2409]   c760      -1
    x[2410]   c212_1    -1153
    x[2410]   c253_1    -1153
    x[2410]   c758      1
    x[2410]   c761      -1
    x[2411]   c216_1    -1153
    x[2411]   c257_1    -1153
    x[2411]   c758      1
    x[2411]   c762      -1
    x[2412]   c221_1    -1153
    x[2412]   c262_1    -1153
    x[2412]   c758      1
    x[2412]   c763      -1
    x[2413]   c231_1    -1153
    x[2413]   c272_1    -1153
    x[2413]   c758      1
    x[2413]   c764      -1
    x[2414]   c238_1    -1153
    x[2414]   c279_1    -1153
    x[2414]   c758      1
    x[2414]   c765      -1
    x[2415]   c206_1    -1153
    x[2415]   c247_1    -1153
    x[2415]   c758      -1
    x[2415]   c759      1
    x[2416]   c207_1    -1153
    x[2416]   c248_1    -1153
    x[2416]   c758      -1
    x[2416]   c760      1
    x[2417]   c212_1    -1153
    x[2417]   c253_1    -1153
    x[2417]   c758      -1
    x[2417]   c761      1
    x[2418]   c216_1    -1153
    x[2418]   c257_1    -1153
    x[2418]   c758      -1
    x[2418]   c762      1
    x[2419]   c221_1    -1153
    x[2419]   c262_1    -1153
    x[2419]   c758      -1
    x[2419]   c763      1
    x[2420]   c231_1    -1153
    x[2420]   c272_1    -1153
    x[2420]   c758      -1
    x[2420]   c764      1
    x[2421]   c238_1    -1153
    x[2421]   c279_1    -1153
    x[2421]   c758      -1
    x[2421]   c765      1
    x[2422]   c208_1    -1153
    x[2422]   c249_1    -1153
    x[2422]   c759      1
    x[2422]   c760      -1
    x[2423]   c213_1    -1153
    x[2423]   c254_1    -1153
    x[2423]   c759      1
    x[2423]   c761      -1
    x[2424]   c217_1    -1153
    x[2424]   c258_1    -1153
    x[2424]   c759      1
    x[2424]   c762      -1
    x[2425]   c222_1    -1153
    x[2425]   c263_1    -1153
    x[2425]   c759      1
    x[2425]   c763      -1
    x[2426]   c239_1    -1153
    x[2426]   c280_1    -1153
    x[2426]   c759      1
    x[2426]   c765      -1
    x[2427]   c208_1    -1153
    x[2427]   c249_1    -1153
    x[2427]   c759      -1
    x[2427]   c760      1
    x[2428]   c213_1    -1153
    x[2428]   c254_1    -1153
    x[2428]   c759      -1
    x[2428]   c761      1
    x[2429]   c217_1    -1153
    x[2429]   c258_1    -1153
    x[2429]   c759      -1
    x[2429]   c762      1
    x[2430]   c222_1    -1153
    x[2430]   c263_1    -1153
    x[2430]   c759      -1
    x[2430]   c763      1
    x[2431]   c239_1    -1153
    x[2431]   c280_1    -1153
    x[2431]   c759      -1
    x[2431]   c765      1
    x[2432]   c214_1    -1153
    x[2432]   c255_1    -1153
    x[2432]   c760      1
    x[2432]   c761      -1
    x[2433]   c218_1    -1153
    x[2433]   c259_1    -1153
    x[2433]   c760      1
    x[2433]   c762      -1
    x[2434]   c223_1    -1153
    x[2434]   c264_1    -1153
    x[2434]   c760      1
    x[2434]   c763      -1
    x[2435]   c232_1    -1153
    x[2435]   c273_1    -1153
    x[2435]   c760      1
    x[2435]   c764      -1
    x[2436]   c240_1    -1153
    x[2436]   c281_1    -1153
    x[2436]   c760      1
    x[2436]   c765      -1
    x[2437]   c214_1    -1153
    x[2437]   c255_1    -1153
    x[2437]   c760      -1
    x[2437]   c761      1
    x[2438]   c218_1    -1153
    x[2438]   c259_1    -1153
    x[2438]   c760      -1
    x[2438]   c762      1
    x[2439]   c223_1    -1153
    x[2439]   c264_1    -1153
    x[2439]   c760      -1
    x[2439]   c763      1
    x[2440]   c232_1    -1153
    x[2440]   c273_1    -1153
    x[2440]   c760      -1
    x[2440]   c764      1
    x[2441]   c240_1    -1153
    x[2441]   c281_1    -1153
    x[2441]   c760      -1
    x[2441]   c765      1
    x[2442]   c220_1    -1153
    x[2442]   c261_1    -1153
    x[2442]   c761      1
    x[2442]   c762      -1
    x[2443]   c225_1    -1153
    x[2443]   c266_1    -1153
    x[2443]   c761      1
    x[2443]   c763      -1
    x[2444]   c234_1    -1153
    x[2444]   c275_1    -1153
    x[2444]   c761      1
    x[2444]   c764      -1
    x[2445]   c242_1    -1153
    x[2445]   c283_1    -1153
    x[2445]   c761      1
    x[2445]   c765      -1
    x[2446]   c220_1    -1153
    x[2446]   c261_1    -1153
    x[2446]   c761      -1
    x[2446]   c762      1
    x[2447]   c225_1    -1153
    x[2447]   c266_1    -1153
    x[2447]   c761      -1
    x[2447]   c763      1
    x[2448]   c234_1    -1153
    x[2448]   c275_1    -1153
    x[2448]   c761      -1
    x[2448]   c764      1
    x[2449]   c242_1    -1153
    x[2449]   c283_1    -1153
    x[2449]   c761      -1
    x[2449]   c765      1
    x[2450]   c226_1    -1153
    x[2450]   c267_1    -1153
    x[2450]   c762      1
    x[2450]   c763      -1
    x[2451]   c235_1    -1153
    x[2451]   c276_1    -1153
    x[2451]   c762      1
    x[2451]   c764      -1
    x[2452]   c243_1    -1153
    x[2452]   c284_1    -1153
    x[2452]   c762      1
    x[2452]   c765      -1
    x[2453]   c226_1    -1153
    x[2453]   c267_1    -1153
    x[2453]   c762      -1
    x[2453]   c763      1
    x[2454]   c235_1    -1153
    x[2454]   c276_1    -1153
    x[2454]   c762      -1
    x[2454]   c764      1
    x[2455]   c243_1    -1153
    x[2455]   c284_1    -1153
    x[2455]   c762      -1
    x[2455]   c765      1
    x[2456]   c236_1    -1153
    x[2456]   c277_1    -1153
    x[2456]   c763      1
    x[2456]   c764      -1
    x[2457]   c244_1    -1153
    x[2457]   c285_1    -1153
    x[2457]   c763      1
    x[2457]   c765      -1
    x[2458]   c236_1    -1153
    x[2458]   c277_1    -1153
    x[2458]   c763      -1
    x[2458]   c764      1
    x[2459]   c244_1    -1153
    x[2459]   c285_1    -1153
    x[2459]   c763      -1
    x[2459]   c765      1
    x[2460]   c246_1    -1153
    x[2460]   c287_1    -1153
    x[2460]   c764      1
    x[2460]   c765      -1
    x[2461]   c246_1    -1153
    x[2461]   c287_1    -1153
    x[2461]   c764      -1
    x[2461]   c765      1
    x[2462]   c207_1    -8649
    x[2462]   c248_1    -8649
    x[2462]   c766      1
    x[2463]   c208_1    -8649
    x[2463]   c249_1    -8649
    x[2463]   c767      1
    x[2464]   c237_1    -8649
    x[2464]   c278_1    -8649
    x[2464]   c768      1
    x[2465]   c245_1    -8649
    x[2465]   c286_1    -8649
    x[2465]   c769      1
    x[2466]   c211_1    -8649
    x[2466]   c252_1    -8649
    x[2466]   c770      1
    x[2467]   c214_1    -8649
    x[2467]   c255_1    -8649
    x[2467]   c771      1
    x[2468]   c218_1    -8649
    x[2468]   c259_1    -8649
    x[2468]   c772      1
    x[2469]   c223_1    -8649
    x[2469]   c264_1    -8649
    x[2469]   c773      1
    x[2470]   c227_1    -8649
    x[2470]   c268_1    -8649
    x[2470]   c774      1
    x[2471]   c228_1    -8649
    x[2471]   c269_1    -8649
    x[2471]   c775      1
    x[2472]   c229_1    -8649
    x[2472]   c270_1    -8649
    x[2472]   c776      1
    x[2473]   c230_1    -8649
    x[2473]   c271_1    -8649
    x[2473]   c777      1
    x[2474]   c232_1    -8649
    x[2474]   c273_1    -8649
    x[2474]   c778      1
    x[2475]   c240_1    -8649
    x[2475]   c281_1    -8649
    x[2475]   c779      1
    x[2476]   c220_2    1
    x[2476]   c221_2    1
    x[2476]   c222_2    1
    x[2476]   c223_2    1
    x[2476]   c224_2    1
    x[2476]   c225_2    1
    x[2476]   c211_1    -8649
    x[2476]   c252_1    -8649
    x[2476]   c780      1
    x[2476]   c784      1
    x[2477]   c220_2    1
    x[2477]   c214_1    -8649
    x[2477]   c255_1    -8649
    x[2477]   c780      1
    x[2477]   c785      1
    x[2478]   c221_2    1
    x[2478]   c218_1    -8649
    x[2478]   c259_1    -8649
    x[2478]   c780      1
    x[2478]   c786      1
    x[2479]   c223_1    -8649
    x[2479]   c264_1    -8649
    x[2479]   c780      1
    x[2479]   c787      1
    x[2480]   c222_2    1
    x[2480]   c232_1    -8649
    x[2480]   c273_1    -8649
    x[2480]   c780      1
    x[2480]   c788      1
    x[2481]   c223_2    1
    x[2481]   c240_1    -8649
    x[2481]   c281_1    -8649
    x[2481]   c780      1
    x[2481]   c789      1
    x[2482]   c224_2    1
    x[2482]   c207_1    -8649
    x[2482]   c248_1    -8649
    x[2482]   c780      1
    x[2482]   c782      1
    x[2483]   c225_2    1
    x[2483]   c208_1    -8649
    x[2483]   c249_1    -8649
    x[2483]   c780      1
    x[2483]   c783      1
    x[2484]   c81_2     1
    x[2484]   c82_2     1
    x[2484]   c83_2     1
    x[2484]   c227_1    -8649
    x[2484]   c268_1    -8649
    x[2484]   c781      1
    x[2484]   c782      -1
    x[2485]   c228_1    -8649
    x[2485]   c269_1    -8649
    x[2485]   c781      1
    x[2485]   c785      -1
    x[2486]   c81_2     1
    x[2486]   c229_1    -8649
    x[2486]   c270_1    -8649
    x[2486]   c781      1
    x[2486]   c786      -1
    x[2487]   c82_2     1
    x[2487]   c230_1    -8649
    x[2487]   c271_1    -8649
    x[2487]   c781      1
    x[2487]   c787      -1
    x[2488]   c237_1    -8649
    x[2488]   c278_1    -8649
    x[2488]   c781      1
    x[2488]   c788      -1
    x[2489]   c83_2     1
    x[2489]   c245_1    -8649
    x[2489]   c286_1    -8649
    x[2489]   c781      1
    x[2489]   c789      -1
    x[2490]   c206_1    -8649
    x[2490]   c247_1    -8649
    x[2490]   c782      1
    x[2490]   c783      -1
    x[2491]   c209_1    -8649
    x[2491]   c250_1    -8649
    x[2491]   c782      1
    x[2491]   c784      -1
    x[2492]   c212_1    -8649
    x[2492]   c253_1    -8649
    x[2492]   c782      1
    x[2492]   c785      -1
    x[2493]   c216_1    -8649
    x[2493]   c257_1    -8649
    x[2493]   c782      1
    x[2493]   c786      -1
    x[2494]   c221_1    -8649
    x[2494]   c262_1    -8649
    x[2494]   c782      1
    x[2494]   c787      -1
    x[2495]   c231_1    -8649
    x[2495]   c272_1    -8649
    x[2495]   c782      1
    x[2495]   c788      -1
    x[2496]   c238_1    -8649
    x[2496]   c279_1    -8649
    x[2496]   c782      1
    x[2496]   c789      -1
    x[2497]   c206_1    -8649
    x[2497]   c247_1    -8649
    x[2497]   c782      -1
    x[2497]   c783      1
    x[2498]   c209_1    -8649
    x[2498]   c250_1    -8649
    x[2498]   c782      -1
    x[2498]   c784      1
    x[2499]   c212_1    -8649
    x[2499]   c253_1    -8649
    x[2499]   c782      -1
    x[2499]   c785      1
    x[2500]   c216_1    -8649
    x[2500]   c257_1    -8649
    x[2500]   c782      -1
    x[2500]   c786      1
    x[2501]   c221_1    -8649
    x[2501]   c262_1    -8649
    x[2501]   c782      -1
    x[2501]   c787      1
    x[2502]   c231_1    -8649
    x[2502]   c272_1    -8649
    x[2502]   c782      -1
    x[2502]   c788      1
    x[2503]   c238_1    -8649
    x[2503]   c279_1    -8649
    x[2503]   c782      -1
    x[2503]   c789      1
    x[2504]   c210_1    -8649
    x[2504]   c251_1    -8649
    x[2504]   c783      1
    x[2504]   c784      -1
    x[2505]   c213_1    -8649
    x[2505]   c254_1    -8649
    x[2505]   c783      1
    x[2505]   c785      -1
    x[2506]   c217_1    -8649
    x[2506]   c258_1    -8649
    x[2506]   c783      1
    x[2506]   c786      -1
    x[2507]   c222_1    -8649
    x[2507]   c263_1    -8649
    x[2507]   c783      1
    x[2507]   c787      -1
    x[2508]   c239_1    -8649
    x[2508]   c280_1    -8649
    x[2508]   c783      1
    x[2508]   c789      -1
    x[2509]   c210_1    -8649
    x[2509]   c251_1    -8649
    x[2509]   c783      -1
    x[2509]   c784      1
    x[2510]   c213_1    -8649
    x[2510]   c254_1    -8649
    x[2510]   c783      -1
    x[2510]   c785      1
    x[2511]   c217_1    -8649
    x[2511]   c258_1    -8649
    x[2511]   c783      -1
    x[2511]   c786      1
    x[2512]   c222_1    -8649
    x[2512]   c263_1    -8649
    x[2512]   c783      -1
    x[2512]   c787      1
    x[2513]   c239_1    -8649
    x[2513]   c280_1    -8649
    x[2513]   c783      -1
    x[2513]   c789      1
    x[2514]   c215_1    -8649
    x[2514]   c256_1    -8649
    x[2514]   c784      1
    x[2514]   c785      -1
    x[2515]   c219_1    -8649
    x[2515]   c260_1    -8649
    x[2515]   c784      1
    x[2515]   c786      -1
    x[2516]   c224_1    -8649
    x[2516]   c265_1    -8649
    x[2516]   c784      1
    x[2516]   c787      -1
    x[2517]   c233_1    -8649
    x[2517]   c274_1    -8649
    x[2517]   c784      1
    x[2517]   c788      -1
    x[2518]   c241_1    -8649
    x[2518]   c282_1    -8649
    x[2518]   c784      1
    x[2518]   c789      -1
    x[2519]   c215_1    -8649
    x[2519]   c256_1    -8649
    x[2519]   c784      -1
    x[2519]   c785      1
    x[2520]   c219_1    -8649
    x[2520]   c260_1    -8649
    x[2520]   c784      -1
    x[2520]   c786      1
    x[2521]   c224_1    -8649
    x[2521]   c265_1    -8649
    x[2521]   c784      -1
    x[2521]   c787      1
    x[2522]   c233_1    -8649
    x[2522]   c274_1    -8649
    x[2522]   c784      -1
    x[2522]   c788      1
    x[2523]   c241_1    -8649
    x[2523]   c282_1    -8649
    x[2523]   c784      -1
    x[2523]   c789      1
    x[2524]   c220_1    -8649
    x[2524]   c261_1    -8649
    x[2524]   c785      1
    x[2524]   c786      -1
    x[2525]   c225_1    -8649
    x[2525]   c266_1    -8649
    x[2525]   c785      1
    x[2525]   c787      -1
    x[2526]   c234_1    -8649
    x[2526]   c275_1    -8649
    x[2526]   c785      1
    x[2526]   c788      -1
    x[2527]   c242_1    -8649
    x[2527]   c283_1    -8649
    x[2527]   c785      1
    x[2527]   c789      -1
    x[2528]   c220_1    -8649
    x[2528]   c261_1    -8649
    x[2528]   c785      -1
    x[2528]   c786      1
    x[2529]   c225_1    -8649
    x[2529]   c266_1    -8649
    x[2529]   c785      -1
    x[2529]   c787      1
    x[2530]   c234_1    -8649
    x[2530]   c275_1    -8649
    x[2530]   c785      -1
    x[2530]   c788      1
    x[2531]   c242_1    -8649
    x[2531]   c283_1    -8649
    x[2531]   c785      -1
    x[2531]   c789      1
    x[2532]   c226_1    -8649
    x[2532]   c267_1    -8649
    x[2532]   c786      1
    x[2532]   c787      -1
    x[2533]   c235_1    -8649
    x[2533]   c276_1    -8649
    x[2533]   c786      1
    x[2533]   c788      -1
    x[2534]   c243_1    -8649
    x[2534]   c284_1    -8649
    x[2534]   c786      1
    x[2534]   c789      -1
    x[2535]   c226_1    -8649
    x[2535]   c267_1    -8649
    x[2535]   c786      -1
    x[2535]   c787      1
    x[2536]   c235_1    -8649
    x[2536]   c276_1    -8649
    x[2536]   c786      -1
    x[2536]   c788      1
    x[2537]   c243_1    -8649
    x[2537]   c284_1    -8649
    x[2537]   c786      -1
    x[2537]   c789      1
    x[2538]   c236_1    -8649
    x[2538]   c277_1    -8649
    x[2538]   c787      1
    x[2538]   c788      -1
    x[2539]   c244_1    -8649
    x[2539]   c285_1    -8649
    x[2539]   c787      1
    x[2539]   c789      -1
    x[2540]   c236_1    -8649
    x[2540]   c277_1    -8649
    x[2540]   c787      -1
    x[2540]   c788      1
    x[2541]   c244_1    -8649
    x[2541]   c285_1    -8649
    x[2541]   c787      -1
    x[2541]   c789      1
    x[2542]   c246_1    -8649
    x[2542]   c287_1    -8649
    x[2542]   c788      1
    x[2542]   c789      -1
    x[2543]   c246_1    -8649
    x[2543]   c287_1    -8649
    x[2543]   c788      -1
    x[2543]   c789      1
    x[2544]   c215_1    -1194
    x[2544]   c256_1    -1194
    x[2544]   c790      1
    x[2545]   c216_1    -1194
    x[2545]   c257_1    -1194
    x[2545]   c791      1
    x[2546]   c217_1    -1194
    x[2546]   c258_1    -1194
    x[2546]   c792      1
    x[2547]   c218_1    -1194
    x[2547]   c259_1    -1194
    x[2547]   c793      1
    x[2548]   c219_1    -1194
    x[2548]   c260_1    -1194
    x[2548]   c794      1
    x[2549]   c220_1    -1194
    x[2549]   c261_1    -1194
    x[2549]   c795      1
    x[2550]   c224_1    -1194
    x[2550]   c265_1    -1194
    x[2550]   c796      1
    x[2551]   c233_1    -1194
    x[2551]   c274_1    -1194
    x[2551]   c797      1
    x[2552]   c241_1    -1194
    x[2552]   c282_1    -1194
    x[2552]   c798      1
    x[2553]   c209_1    -1194
    x[2553]   c250_1    -1194
    x[2553]   c799      1
    x[2554]   c210_1    -1194
    x[2554]   c251_1    -1194
    x[2554]   c800      1
    x[2555]   c211_1    -1194
    x[2555]   c252_1    -1194
    x[2555]   c801      1
    x[2556]   c226_1    -1194
    x[2556]   c267_1    -1194
    x[2556]   c802      1
    x[2557]   c229_1    -1194
    x[2557]   c270_1    -1194
    x[2557]   c803      1
    x[2558]   c235_1    -1194
    x[2558]   c276_1    -1194
    x[2558]   c804      1
    x[2559]   c243_1    -1194
    x[2559]   c284_1    -1194
    x[2559]   c805      1
    x[2560]   c226_1    -1194
    x[2560]   c267_1    -1194
    x[2560]   c806      1
    x[2560]   c812      1
    x[2561]   c233_2    1
    x[2561]   c229_1    -1194
    x[2561]   c270_1    -1194
    x[2561]   c806      1
    x[2561]   c813      1
    x[2562]   c235_1    -1194
    x[2562]   c276_1    -1194
    x[2562]   c806      1
    x[2562]   c814      1
    x[2563]   c243_1    -1194
    x[2563]   c284_1    -1194
    x[2563]   c806      1
    x[2563]   c815      1
    x[2564]   c216_1    -1194
    x[2564]   c257_1    -1194
    x[2564]   c806      1
    x[2564]   c808      1
    x[2565]   c217_1    -1194
    x[2565]   c258_1    -1194
    x[2565]   c806      1
    x[2565]   c809      1
    x[2566]   c218_1    -1194
    x[2566]   c259_1    -1194
    x[2566]   c806      1
    x[2566]   c810      1
    x[2567]   c233_2    1
    x[2567]   c219_1    -1194
    x[2567]   c260_1    -1194
    x[2567]   c806      1
    x[2567]   c807      1
    x[2568]   c220_1    -1194
    x[2568]   c261_1    -1194
    x[2568]   c806      1
    x[2568]   c811      1
    x[2569]   c12_2     1
    x[2569]   c13_2     1
    x[2569]   c14_2     1
    x[2569]   c15_2     1
    x[2569]   c209_1    -1194
    x[2569]   c250_1    -1194
    x[2569]   c807      1
    x[2569]   c808      -1
    x[2570]   c12_2     1
    x[2570]   c210_1    -1194
    x[2570]   c251_1    -1194
    x[2570]   c807      1
    x[2570]   c809      -1
    x[2571]   c211_1    -1194
    x[2571]   c252_1    -1194
    x[2571]   c807      1
    x[2571]   c810      -1
    x[2572]   c13_2     1
    x[2572]   c215_1    -1194
    x[2572]   c256_1    -1194
    x[2572]   c807      1
    x[2572]   c811      -1
    x[2573]   c14_2     1
    x[2573]   c224_1    -1194
    x[2573]   c265_1    -1194
    x[2573]   c807      1
    x[2573]   c812      -1
    x[2574]   c15_2     1
    x[2574]   c233_1    -1194
    x[2574]   c274_1    -1194
    x[2574]   c807      1
    x[2574]   c814      -1
    x[2575]   c241_1    -1194
    x[2575]   c282_1    -1194
    x[2575]   c807      1
    x[2575]   c815      -1
    x[2576]   c206_1    -1194
    x[2576]   c247_1    -1194
    x[2576]   c808      1
    x[2576]   c809      -1
    x[2577]   c207_1    -1194
    x[2577]   c248_1    -1194
    x[2577]   c808      1
    x[2577]   c810      -1
    x[2578]   c212_1    -1194
    x[2578]   c253_1    -1194
    x[2578]   c808      1
    x[2578]   c811      -1
    x[2579]   c221_1    -1194
    x[2579]   c262_1    -1194
    x[2579]   c808      1
    x[2579]   c812      -1
    x[2580]   c227_1    -1194
    x[2580]   c268_1    -1194
    x[2580]   c808      1
    x[2580]   c813      -1
    x[2581]   c231_1    -1194
    x[2581]   c272_1    -1194
    x[2581]   c808      1
    x[2581]   c814      -1
    x[2582]   c238_1    -1194
    x[2582]   c279_1    -1194
    x[2582]   c808      1
    x[2582]   c815      -1
    x[2583]   c206_1    -1194
    x[2583]   c247_1    -1194
    x[2583]   c808      -1
    x[2583]   c809      1
    x[2584]   c207_1    -1194
    x[2584]   c248_1    -1194
    x[2584]   c808      -1
    x[2584]   c810      1
    x[2585]   c212_1    -1194
    x[2585]   c253_1    -1194
    x[2585]   c808      -1
    x[2585]   c811      1
    x[2586]   c221_1    -1194
    x[2586]   c262_1    -1194
    x[2586]   c808      -1
    x[2586]   c812      1
    x[2587]   c227_1    -1194
    x[2587]   c268_1    -1194
    x[2587]   c808      -1
    x[2587]   c813      1
    x[2588]   c231_1    -1194
    x[2588]   c272_1    -1194
    x[2588]   c808      -1
    x[2588]   c814      1
    x[2589]   c238_1    -1194
    x[2589]   c279_1    -1194
    x[2589]   c808      -1
    x[2589]   c815      1
    x[2590]   c208_1    -1194
    x[2590]   c249_1    -1194
    x[2590]   c809      1
    x[2590]   c810      -1
    x[2591]   c213_1    -1194
    x[2591]   c254_1    -1194
    x[2591]   c809      1
    x[2591]   c811      -1
    x[2592]   c222_1    -1194
    x[2592]   c263_1    -1194
    x[2592]   c809      1
    x[2592]   c812      -1
    x[2593]   c239_1    -1194
    x[2593]   c280_1    -1194
    x[2593]   c809      1
    x[2593]   c815      -1
    x[2594]   c208_1    -1194
    x[2594]   c249_1    -1194
    x[2594]   c809      -1
    x[2594]   c810      1
    x[2595]   c213_1    -1194
    x[2595]   c254_1    -1194
    x[2595]   c809      -1
    x[2595]   c811      1
    x[2596]   c222_1    -1194
    x[2596]   c263_1    -1194
    x[2596]   c809      -1
    x[2596]   c812      1
    x[2597]   c239_1    -1194
    x[2597]   c280_1    -1194
    x[2597]   c809      -1
    x[2597]   c815      1
    x[2598]   c214_1    -1194
    x[2598]   c255_1    -1194
    x[2598]   c810      1
    x[2598]   c811      -1
    x[2599]   c223_1    -1194
    x[2599]   c264_1    -1194
    x[2599]   c810      1
    x[2599]   c812      -1
    x[2600]   c232_1    -1194
    x[2600]   c273_1    -1194
    x[2600]   c810      1
    x[2600]   c814      -1
    x[2601]   c240_1    -1194
    x[2601]   c281_1    -1194
    x[2601]   c810      1
    x[2601]   c815      -1
    x[2602]   c214_1    -1194
    x[2602]   c255_1    -1194
    x[2602]   c810      -1
    x[2602]   c811      1
    x[2603]   c223_1    -1194
    x[2603]   c264_1    -1194
    x[2603]   c810      -1
    x[2603]   c812      1
    x[2604]   c232_1    -1194
    x[2604]   c273_1    -1194
    x[2604]   c810      -1
    x[2604]   c814      1
    x[2605]   c240_1    -1194
    x[2605]   c281_1    -1194
    x[2605]   c810      -1
    x[2605]   c815      1
    x[2606]   c225_1    -1194
    x[2606]   c266_1    -1194
    x[2606]   c811      1
    x[2606]   c812      -1
    x[2607]   c228_1    -1194
    x[2607]   c269_1    -1194
    x[2607]   c811      1
    x[2607]   c813      -1
    x[2608]   c234_1    -1194
    x[2608]   c275_1    -1194
    x[2608]   c811      1
    x[2608]   c814      -1
    x[2609]   c242_1    -1194
    x[2609]   c283_1    -1194
    x[2609]   c811      1
    x[2609]   c815      -1
    x[2610]   c225_1    -1194
    x[2610]   c266_1    -1194
    x[2610]   c811      -1
    x[2610]   c812      1
    x[2611]   c228_1    -1194
    x[2611]   c269_1    -1194
    x[2611]   c811      -1
    x[2611]   c813      1
    x[2612]   c234_1    -1194
    x[2612]   c275_1    -1194
    x[2612]   c811      -1
    x[2612]   c814      1
    x[2613]   c242_1    -1194
    x[2613]   c283_1    -1194
    x[2613]   c811      -1
    x[2613]   c815      1
    x[2614]   c230_1    -1194
    x[2614]   c271_1    -1194
    x[2614]   c812      1
    x[2614]   c813      -1
    x[2615]   c236_1    -1194
    x[2615]   c277_1    -1194
    x[2615]   c812      1
    x[2615]   c814      -1
    x[2616]   c244_1    -1194
    x[2616]   c285_1    -1194
    x[2616]   c812      1
    x[2616]   c815      -1
    x[2617]   c230_1    -1194
    x[2617]   c271_1    -1194
    x[2617]   c812      -1
    x[2617]   c813      1
    x[2618]   c236_1    -1194
    x[2618]   c277_1    -1194
    x[2618]   c812      -1
    x[2618]   c814      1
    x[2619]   c244_1    -1194
    x[2619]   c285_1    -1194
    x[2619]   c812      -1
    x[2619]   c815      1
    x[2620]   c237_1    -1194
    x[2620]   c278_1    -1194
    x[2620]   c813      1
    x[2620]   c814      -1
    x[2621]   c245_1    -1194
    x[2621]   c286_1    -1194
    x[2621]   c813      1
    x[2621]   c815      -1
    x[2622]   c237_1    -1194
    x[2622]   c278_1    -1194
    x[2622]   c813      -1
    x[2622]   c814      1
    x[2623]   c245_1    -1194
    x[2623]   c286_1    -1194
    x[2623]   c813      -1
    x[2623]   c815      1
    x[2624]   c246_1    -1194
    x[2624]   c287_1    -1194
    x[2624]   c814      1
    x[2624]   c815      -1
    x[2625]   c246_1    -1194
    x[2625]   c287_1    -1194
    x[2625]   c814      -1
    x[2625]   c815      1
    x[2626]   c207_1    -3553
    x[2626]   c248_1    -3553
    x[2626]   c816      1
    x[2627]   c208_1    -3553
    x[2627]   c249_1    -3553
    x[2627]   c817      1
    x[2628]   c246_1    -3553
    x[2628]   c287_1    -3553
    x[2628]   c818      1
    x[2629]   c211_1    -3553
    x[2629]   c252_1    -3553
    x[2629]   c819      1
    x[2630]   c214_1    -3553
    x[2630]   c255_1    -3553
    x[2630]   c820      1
    x[2631]   c218_1    -3553
    x[2631]   c259_1    -3553
    x[2631]   c821      1
    x[2632]   c223_1    -3553
    x[2632]   c264_1    -3553
    x[2632]   c822      1
    x[2633]   c231_1    -3553
    x[2633]   c272_1    -3553
    x[2633]   c823      1
    x[2634]   c232_1    -3553
    x[2634]   c273_1    -3553
    x[2634]   c824      1
    x[2635]   c233_1    -3553
    x[2635]   c274_1    -3553
    x[2635]   c825      1
    x[2636]   c234_1    -3553
    x[2636]   c275_1    -3553
    x[2636]   c826      1
    x[2637]   c235_1    -3553
    x[2637]   c276_1    -3553
    x[2637]   c827      1
    x[2638]   c236_1    -3553
    x[2638]   c277_1    -3553
    x[2638]   c828      1
    x[2639]   c237_1    -3553
    x[2639]   c278_1    -3553
    x[2639]   c829      1
    x[2640]   c240_1    -3553
    x[2640]   c281_1    -3553
    x[2640]   c830      1
    x[2641]   c180_2    1
    x[2641]   c185_2    1
    x[2641]   c211_1    -3553
    x[2641]   c252_1    -3553
    x[2641]   c831      1
    x[2641]   c835      1
    x[2642]   c181_2    1
    x[2642]   c214_1    -3553
    x[2642]   c255_1    -3553
    x[2642]   c831      1
    x[2642]   c836      1
    x[2643]   c182_2    1
    x[2643]   c218_1    -3553
    x[2643]   c259_1    -3553
    x[2643]   c831      1
    x[2643]   c837      1
    x[2644]   c223_1    -3553
    x[2644]   c264_1    -3553
    x[2644]   c831      1
    x[2644]   c838      1
    x[2645]   c180_2    1
    x[2645]   c181_2    1
    x[2645]   c182_2    1
    x[2645]   c183_2    1
    x[2645]   c232_1    -3553
    x[2645]   c273_1    -3553
    x[2645]   c831      1
    x[2645]   c832      1
    x[2646]   c185_2    1
    x[2646]   c240_1    -3553
    x[2646]   c281_1    -3553
    x[2646]   c831      1
    x[2646]   c840      1
    x[2647]   c183_2    1
    x[2647]   c207_1    -3553
    x[2647]   c248_1    -3553
    x[2647]   c831      1
    x[2647]   c833      1
    x[2648]   c208_1    -3553
    x[2648]   c249_1    -3553
    x[2648]   c831      1
    x[2648]   c834      1
    x[2649]   c231_1    -3553
    x[2649]   c272_1    -3553
    x[2649]   c832      1
    x[2649]   c833      -1
    x[2650]   c233_1    -3553
    x[2650]   c274_1    -3553
    x[2650]   c832      1
    x[2650]   c835      -1
    x[2651]   c234_1    -3553
    x[2651]   c275_1    -3553
    x[2651]   c832      1
    x[2651]   c836      -1
    x[2652]   c235_1    -3553
    x[2652]   c276_1    -3553
    x[2652]   c832      1
    x[2652]   c837      -1
    x[2653]   c236_1    -3553
    x[2653]   c277_1    -3553
    x[2653]   c832      1
    x[2653]   c838      -1
    x[2654]   c237_1    -3553
    x[2654]   c278_1    -3553
    x[2654]   c832      1
    x[2654]   c839      -1
    x[2655]   c246_1    -3553
    x[2655]   c287_1    -3553
    x[2655]   c832      1
    x[2655]   c840      -1
    x[2656]   c206_1    -3553
    x[2656]   c247_1    -3553
    x[2656]   c833      1
    x[2656]   c834      -1
    x[2657]   c209_1    -3553
    x[2657]   c250_1    -3553
    x[2657]   c833      1
    x[2657]   c835      -1
    x[2658]   c212_1    -3553
    x[2658]   c253_1    -3553
    x[2658]   c833      1
    x[2658]   c836      -1
    x[2659]   c216_1    -3553
    x[2659]   c257_1    -3553
    x[2659]   c833      1
    x[2659]   c837      -1
    x[2660]   c221_1    -3553
    x[2660]   c262_1    -3553
    x[2660]   c833      1
    x[2660]   c838      -1
    x[2661]   c227_1    -3553
    x[2661]   c268_1    -3553
    x[2661]   c833      1
    x[2661]   c839      -1
    x[2662]   c238_1    -3553
    x[2662]   c279_1    -3553
    x[2662]   c833      1
    x[2662]   c840      -1
    x[2663]   c206_1    -3553
    x[2663]   c247_1    -3553
    x[2663]   c833      -1
    x[2663]   c834      1
    x[2664]   c209_1    -3553
    x[2664]   c250_1    -3553
    x[2664]   c833      -1
    x[2664]   c835      1
    x[2665]   c212_1    -3553
    x[2665]   c253_1    -3553
    x[2665]   c833      -1
    x[2665]   c836      1
    x[2666]   c216_1    -3553
    x[2666]   c257_1    -3553
    x[2666]   c833      -1
    x[2666]   c837      1
    x[2667]   c221_1    -3553
    x[2667]   c262_1    -3553
    x[2667]   c833      -1
    x[2667]   c838      1
    x[2668]   c227_1    -3553
    x[2668]   c268_1    -3553
    x[2668]   c833      -1
    x[2668]   c839      1
    x[2669]   c238_1    -3553
    x[2669]   c279_1    -3553
    x[2669]   c833      -1
    x[2669]   c840      1
    x[2670]   c210_1    -3553
    x[2670]   c251_1    -3553
    x[2670]   c834      1
    x[2670]   c835      -1
    x[2671]   c213_1    -3553
    x[2671]   c254_1    -3553
    x[2671]   c834      1
    x[2671]   c836      -1
    x[2672]   c217_1    -3553
    x[2672]   c258_1    -3553
    x[2672]   c834      1
    x[2672]   c837      -1
    x[2673]   c222_1    -3553
    x[2673]   c263_1    -3553
    x[2673]   c834      1
    x[2673]   c838      -1
    x[2674]   c239_1    -3553
    x[2674]   c280_1    -3553
    x[2674]   c834      1
    x[2674]   c840      -1
    x[2675]   c210_1    -3553
    x[2675]   c251_1    -3553
    x[2675]   c834      -1
    x[2675]   c835      1
    x[2676]   c213_1    -3553
    x[2676]   c254_1    -3553
    x[2676]   c834      -1
    x[2676]   c836      1
    x[2677]   c217_1    -3553
    x[2677]   c258_1    -3553
    x[2677]   c834      -1
    x[2677]   c837      1
    x[2678]   c222_1    -3553
    x[2678]   c263_1    -3553
    x[2678]   c834      -1
    x[2678]   c838      1
    x[2679]   c239_1    -3553
    x[2679]   c280_1    -3553
    x[2679]   c834      -1
    x[2679]   c840      1
    x[2680]   c215_1    -3553
    x[2680]   c256_1    -3553
    x[2680]   c835      1
    x[2680]   c836      -1
    x[2681]   c219_1    -3553
    x[2681]   c260_1    -3553
    x[2681]   c835      1
    x[2681]   c837      -1
    x[2682]   c224_1    -3553
    x[2682]   c265_1    -3553
    x[2682]   c835      1
    x[2682]   c838      -1
    x[2683]   c241_1    -3553
    x[2683]   c282_1    -3553
    x[2683]   c835      1
    x[2683]   c840      -1
    x[2684]   c215_1    -3553
    x[2684]   c256_1    -3553
    x[2684]   c835      -1
    x[2684]   c836      1
    x[2685]   c219_1    -3553
    x[2685]   c260_1    -3553
    x[2685]   c835      -1
    x[2685]   c837      1
    x[2686]   c224_1    -3553
    x[2686]   c265_1    -3553
    x[2686]   c835      -1
    x[2686]   c838      1
    x[2687]   c241_1    -3553
    x[2687]   c282_1    -3553
    x[2687]   c835      -1
    x[2687]   c840      1
    x[2688]   c220_1    -3553
    x[2688]   c261_1    -3553
    x[2688]   c836      1
    x[2688]   c837      -1
    x[2689]   c225_1    -3553
    x[2689]   c266_1    -3553
    x[2689]   c836      1
    x[2689]   c838      -1
    x[2690]   c228_1    -3553
    x[2690]   c269_1    -3553
    x[2690]   c836      1
    x[2690]   c839      -1
    x[2691]   c242_1    -3553
    x[2691]   c283_1    -3553
    x[2691]   c836      1
    x[2691]   c840      -1
    x[2692]   c220_1    -3553
    x[2692]   c261_1    -3553
    x[2692]   c836      -1
    x[2692]   c837      1
    x[2693]   c225_1    -3553
    x[2693]   c266_1    -3553
    x[2693]   c836      -1
    x[2693]   c838      1
    x[2694]   c228_1    -3553
    x[2694]   c269_1    -3553
    x[2694]   c836      -1
    x[2694]   c839      1
    x[2695]   c242_1    -3553
    x[2695]   c283_1    -3553
    x[2695]   c836      -1
    x[2695]   c840      1
    x[2696]   c226_1    -3553
    x[2696]   c267_1    -3553
    x[2696]   c837      1
    x[2696]   c838      -1
    x[2697]   c229_1    -3553
    x[2697]   c270_1    -3553
    x[2697]   c837      1
    x[2697]   c839      -1
    x[2698]   c243_1    -3553
    x[2698]   c284_1    -3553
    x[2698]   c837      1
    x[2698]   c840      -1
    x[2699]   c226_1    -3553
    x[2699]   c267_1    -3553
    x[2699]   c837      -1
    x[2699]   c838      1
    x[2700]   c229_1    -3553
    x[2700]   c270_1    -3553
    x[2700]   c837      -1
    x[2700]   c839      1
    x[2701]   c243_1    -3553
    x[2701]   c284_1    -3553
    x[2701]   c837      -1
    x[2701]   c840      1
    x[2702]   c230_1    -3553
    x[2702]   c271_1    -3553
    x[2702]   c838      1
    x[2702]   c839      -1
    x[2703]   c244_1    -3553
    x[2703]   c285_1    -3553
    x[2703]   c838      1
    x[2703]   c840      -1
    x[2704]   c230_1    -3553
    x[2704]   c271_1    -3553
    x[2704]   c838      -1
    x[2704]   c839      1
    x[2705]   c244_1    -3553
    x[2705]   c285_1    -3553
    x[2705]   c838      -1
    x[2705]   c840      1
    x[2706]   c245_1    -3553
    x[2706]   c286_1    -3553
    x[2706]   c839      1
    x[2706]   c840      -1
    x[2707]   c245_1    -3553
    x[2707]   c286_1    -3553
    x[2707]   c839      -1
    x[2707]   c840      1
    x[2708]   c59_2     -1
    x[2708]   c1_1      1
    x[2708]   c842      -2048
    x[2708]   c843      -2048
    x[2708]   c844      -209
    x[2709]   c59_2     1
    x[2709]   c1_1      -1
    x[2709]   c2_1      1
    x[2709]   c842      -2048
    x[2709]   c843      -2048
    x[2709]   c844      -209
    x[2710]   c2_1      -1
    x[2710]   c3_1      1
    x[2710]   c842      -2048
    x[2710]   c843      -2048
    x[2710]   c844      -209
    x[2711]   c3_1      -1
    x[2711]   c4_1      1
    x[2711]   c842      -27856
    x[2711]   c843      -27856
    x[2711]   c844      -1289
    x[2712]   c4_1      -1
    x[2712]   c5_1      1
    x[2712]   c842      -34000
    x[2712]   c843      -34000
    x[2712]   c844      -1916
    x[2713]   c5_1      -1
    x[2713]   c842      -34000
    x[2713]   c843      -34000
    x[2713]   c844      -1916
    x[2714]   c841      1
    x[2715]   c206_1    1
    x[2715]   c842      1
    x[2716]   c247_1    1
    x[2716]   c843      1
    x[2717]   c844      1
    x[2717]   c1005     -1
    x[2718]   c84_2     -1
    x[2718]   c6_1      1
    x[2718]   c846      -2048
    x[2718]   c847      -2048
    x[2718]   c848      -47
    x[2719]   c84_2     1
    x[2719]   c6_1      -1
    x[2719]   c7_1      1
    x[2719]   c846      -2048
    x[2719]   c847      -2048
    x[2719]   c848      -47
    x[2720]   c7_1      -1
    x[2720]   c8_1      1
    x[2720]   c846      -2048
    x[2720]   c847      -2048
    x[2720]   c848      -47
    x[2721]   c8_1      -1
    x[2721]   c9_1      1
    x[2721]   c846      -27856
    x[2721]   c847      -27856
    x[2721]   c848      -267
    x[2722]   c9_1      -1
    x[2722]   c10_1     1
    x[2722]   c846      -34000
    x[2722]   c847      -34000
    x[2722]   c848      -408
    x[2723]   c10_1     -1
    x[2723]   c846      -34000
    x[2723]   c847      -34000
    x[2723]   c848      -408
    x[2724]   c845      1
    x[2725]   c207_1    1
    x[2725]   c846      1
    x[2726]   c248_1    1
    x[2726]   c847      1
    x[2727]   c848      1
    x[2727]   c1005     -1
    x[2728]   c263_2    -1
    x[2728]   c11_1     1
    x[2728]   c850      -2048
    x[2728]   c851      -2048
    x[2728]   c852      -212
    x[2729]   c263_2    1
    x[2729]   c11_1     -1
    x[2729]   c12_1     1
    x[2729]   c850      -2048
    x[2729]   c851      -2048
    x[2729]   c852      -212
    x[2730]   c12_1     -1
    x[2730]   c13_1     1
    x[2730]   c850      -2048
    x[2730]   c851      -2048
    x[2730]   c852      -212
    x[2731]   c13_1     -1
    x[2731]   c14_1     1
    x[2731]   c850      -27856
    x[2731]   c851      -27856
    x[2731]   c852      -1304
    x[2732]   c14_1     -1
    x[2732]   c15_1     1
    x[2732]   c850      -34000
    x[2732]   c851      -34000
    x[2732]   c852      -1940
    x[2733]   c15_1     -1
    x[2733]   c850      -34000
    x[2733]   c851      -34000
    x[2733]   c852      -1940
    x[2734]   c849      1
    x[2735]   c208_1    1
    x[2735]   c850      1
    x[2736]   c249_1    1
    x[2736]   c851      1
    x[2737]   c852      1
    x[2737]   c1005     -1
    x[2738]   c113_2    -1
    x[2738]   c16_1     1
    x[2738]   c854      -2048
    x[2738]   c855      -2048
    x[2738]   c856      -147
    x[2739]   c113_2    1
    x[2739]   c16_1     -1
    x[2739]   c17_1     1
    x[2739]   c854      -2048
    x[2739]   c855      -2048
    x[2739]   c856      -147
    x[2740]   c17_1     -1
    x[2740]   c18_1     1
    x[2740]   c854      -2048
    x[2740]   c855      -2048
    x[2740]   c856      -147
    x[2741]   c18_1     -1
    x[2741]   c19_1     1
    x[2741]   c854      -27856
    x[2741]   c855      -27856
    x[2741]   c856      -899
    x[2742]   c19_1     -1
    x[2742]   c20_1     1
    x[2742]   c854      -34000
    x[2742]   c855      -34000
    x[2742]   c856      -1340
    x[2743]   c20_1     -1
    x[2743]   c854      -34000
    x[2743]   c855      -34000
    x[2743]   c856      -1340
    x[2744]   c853      1
    x[2745]   c209_1    1
    x[2745]   c854      1
    x[2746]   c250_1    1
    x[2746]   c855      1
    x[2747]   c856      1
    x[2747]   c1005     -1
    x[2748]   c226_2    -1
    x[2748]   c21_1     1
    x[2748]   c858      -2048
    x[2748]   c859      -2048
    x[2748]   c860      -238
    x[2749]   c226_2    1
    x[2749]   c21_1     -1
    x[2749]   c22_1     1
    x[2749]   c858      -2048
    x[2749]   c859      -2048
    x[2749]   c860      -238
    x[2750]   c22_1     -1
    x[2750]   c23_1     1
    x[2750]   c858      -2048
    x[2750]   c859      -2048
    x[2750]   c860      -238
    x[2751]   c23_1     -1
    x[2751]   c24_1     1
    x[2751]   c858      -27856
    x[2751]   c859      -27856
    x[2751]   c860      -1467
    x[2752]   c24_1     -1
    x[2752]   c25_1     1
    x[2752]   c858      -34000
    x[2752]   c859      -34000
    x[2752]   c860      -2181
    x[2753]   c25_1     -1
    x[2753]   c858      -34000
    x[2753]   c859      -34000
    x[2753]   c860      -2181
    x[2754]   c857      1
    x[2755]   c210_1    1
    x[2755]   c858      1
    x[2756]   c251_1    1
    x[2756]   c859      1
    x[2757]   c860      1
    x[2757]   c1005     -1
    x[2758]   c85_2     -1
    x[2758]   c26_1     1
    x[2758]   c862      -2048
    x[2758]   c863      -2048
    x[2758]   c864      -149
    x[2759]   c85_2     1
    x[2759]   c26_1     -1
    x[2759]   c27_1     1
    x[2759]   c862      -2048
    x[2759]   c863      -2048
    x[2759]   c864      -149
    x[2760]   c27_1     -1
    x[2760]   c28_1     1
    x[2760]   c862      -2048
    x[2760]   c863      -2048
    x[2760]   c864      -149
    x[2761]   c28_1     -1
    x[2761]   c29_1     1
    x[2761]   c862      -27856
    x[2761]   c863      -27856
    x[2761]   c864      -912
    x[2762]   c29_1     -1
    x[2762]   c30_1     1
    x[2762]   c862      -34000
    x[2762]   c863      -34000
    x[2762]   c864      -1359
    x[2763]   c30_1     -1
    x[2763]   c862      -34000
    x[2763]   c863      -34000
    x[2763]   c864      -1359
    x[2764]   c861      1
    x[2765]   c211_1    1
    x[2765]   c862      1
    x[2766]   c252_1    1
    x[2766]   c863      1
    x[2767]   c864      1
    x[2767]   c1005     -1
    x[2768]   c208_2    -1
    x[2768]   c31_1     1
    x[2768]   c866      -2048
    x[2768]   c867      -2048
    x[2768]   c868      -324
    x[2769]   c208_2    1
    x[2769]   c31_1     -1
    x[2769]   c32_1     1
    x[2769]   c866      -2048
    x[2769]   c867      -2048
    x[2769]   c868      -324
    x[2770]   c32_1     -1
    x[2770]   c33_1     1
    x[2770]   c866      -2048
    x[2770]   c867      -2048
    x[2770]   c868      -324
    x[2771]   c33_1     -1
    x[2771]   c34_1     1
    x[2771]   c866      -27856
    x[2771]   c867      -27856
    x[2771]   c868      -2036
    x[2772]   c34_1     -1
    x[2772]   c35_1     1
    x[2772]   c866      -34000
    x[2772]   c867      -34000
    x[2772]   c868      -3008
    x[2773]   c35_1     -1
    x[2773]   c866      -34000
    x[2773]   c867      -34000
    x[2773]   c868      -3008
    x[2774]   c865      1
    x[2775]   c212_1    1
    x[2775]   c866      1
    x[2776]   c253_1    1
    x[2776]   c867      1
    x[2777]   c868      1
    x[2777]   c1005     -1
    x[2778]   c60_2     -1
    x[2778]   c36_1     1
    x[2778]   c870      -2048
    x[2778]   c871      -2048
    x[2778]   c872      -381
    x[2779]   c60_2     1
    x[2779]   c36_1     -1
    x[2779]   c37_1     1
    x[2779]   c870      -2048
    x[2779]   c871      -2048
    x[2779]   c872      -381
    x[2780]   c37_1     -1
    x[2780]   c38_1     1
    x[2780]   c870      -2048
    x[2780]   c871      -2048
    x[2780]   c872      -381
    x[2781]   c38_1     -1
    x[2781]   c39_1     1
    x[2781]   c870      -27856
    x[2781]   c871      -27856
    x[2781]   c872      -2428
    x[2782]   c39_1     -1
    x[2782]   c40_1     1
    x[2782]   c870      -34000
    x[2782]   c871      -34000
    x[2782]   c872      -3571
    x[2783]   c40_1     -1
    x[2783]   c870      -34000
    x[2783]   c871      -34000
    x[2783]   c872      -3571
    x[2784]   c869      1
    x[2785]   c213_1    1
    x[2785]   c870      1
    x[2786]   c254_1    1
    x[2786]   c871      1
    x[2787]   c872      1
    x[2787]   c1005     -1
    x[2788]   c166_2    -1
    x[2788]   c41_1     1
    x[2788]   c874      -2048
    x[2788]   c875      -2048
    x[2788]   c876      -322
    x[2789]   c166_2    1
    x[2789]   c41_1     -1
    x[2789]   c42_1     1
    x[2789]   c874      -2048
    x[2789]   c875      -2048
    x[2789]   c876      -322
    x[2790]   c42_1     -1
    x[2790]   c43_1     1
    x[2790]   c874      -2048
    x[2790]   c875      -2048
    x[2790]   c876      -322
    x[2791]   c43_1     -1
    x[2791]   c44_1     1
    x[2791]   c874      -27856
    x[2791]   c875      -27856
    x[2791]   c876      -2024
    x[2792]   c44_1     -1
    x[2792]   c45_1     1
    x[2792]   c874      -34000
    x[2792]   c875      -34000
    x[2792]   c876      -2990
    x[2793]   c45_1     -1
    x[2793]   c874      -34000
    x[2793]   c875      -34000
    x[2793]   c876      -2990
    x[2794]   c873      1
    x[2795]   c214_1    1
    x[2795]   c874      1
    x[2796]   c255_1    1
    x[2796]   c875      1
    x[2797]   c876      1
    x[2797]   c1005     -1
    x[2798]   c46_1     1
    x[2798]   c878      -2048
    x[2798]   c879      -2048
    x[2798]   c880      -232
    x[2799]   c46_1     -1
    x[2799]   c47_1     1
    x[2799]   c878      -2048
    x[2799]   c879      -2048
    x[2799]   c880      -232
    x[2800]   c47_1     -1
    x[2800]   c48_1     1
    x[2800]   c878      -2048
    x[2800]   c879      -2048
    x[2800]   c880      -232
    x[2801]   c48_1     -1
    x[2801]   c49_1     1
    x[2801]   c878      -27856
    x[2801]   c879      -27856
    x[2801]   c880      -1431
    x[2802]   c49_1     -1
    x[2802]   c50_1     1
    x[2802]   c878      -34000
    x[2802]   c879      -34000
    x[2802]   c880      -2127
    x[2803]   c50_1     -1
    x[2803]   c878      -34000
    x[2803]   c879      -34000
    x[2803]   c880      -2127
    x[2804]   c877      1
    x[2805]   c215_1    1
    x[2805]   c878      1
    x[2806]   c256_1    1
    x[2806]   c879      1
    x[2807]   c880      1
    x[2807]   c1005     -1
    x[2808]   c114_2    -1
    x[2808]   c51_1     1
    x[2808]   c882      -2048
    x[2808]   c883      -2048
    x[2808]   c884      -278
    x[2809]   c114_2    1
    x[2809]   c51_1     -1
    x[2809]   c52_1     1
    x[2809]   c882      -2048
    x[2809]   c883      -2048
    x[2809]   c884      -278
    x[2810]   c52_1     -1
    x[2810]   c53_1     1
    x[2810]   c882      -2048
    x[2810]   c883      -2048
    x[2810]   c884      -278
    x[2811]   c53_1     -1
    x[2811]   c54_1     1
    x[2811]   c882      -27856
    x[2811]   c883      -27856
    x[2811]   c884      -1727
    x[2812]   c54_1     -1
    x[2812]   c55_1     1
    x[2812]   c882      -34000
    x[2812]   c883      -34000
    x[2812]   c884      -2561
    x[2813]   c55_1     -1
    x[2813]   c882      -34000
    x[2813]   c883      -34000
    x[2813]   c884      -2561
    x[2814]   c881      1
    x[2815]   c216_1    1
    x[2815]   c882      1
    x[2816]   c257_1    1
    x[2816]   c883      1
    x[2817]   c884      1
    x[2817]   c1005     -1
    x[2818]   c227_2    -1
    x[2818]   c56_1     1
    x[2818]   c886      -2048
    x[2818]   c887      -2048
    x[2818]   c888      -316
    x[2819]   c227_2    1
    x[2819]   c56_1     -1
    x[2819]   c57_1     1
    x[2819]   c886      -2048
    x[2819]   c887      -2048
    x[2819]   c888      -316
    x[2820]   c57_1     -1
    x[2820]   c58_1     1
    x[2820]   c886      -2048
    x[2820]   c887      -2048
    x[2820]   c888      -316
    x[2821]   c58_1     -1
    x[2821]   c59_1     1
    x[2821]   c886      -27856
    x[2821]   c887      -27856
    x[2821]   c888      -1981
    x[2822]   c59_1     -1
    x[2822]   c60_1     1
    x[2822]   c886      -34000
    x[2822]   c887      -34000
    x[2822]   c888      -2929
    x[2823]   c60_1     -1
    x[2823]   c886      -34000
    x[2823]   c887      -34000
    x[2823]   c888      -2929
    x[2824]   c885      1
    x[2825]   c217_1    1
    x[2825]   c886      1
    x[2826]   c258_1    1
    x[2826]   c887      1
    x[2827]   c888      1
    x[2827]   c1005     -1
    x[2828]   c61_2     -1
    x[2828]   c61_1     1
    x[2828]   c890      -2048
    x[2828]   c891      -2048
    x[2828]   c892      -277
    x[2829]   c61_2     1
    x[2829]   c61_1     -1
    x[2829]   c62_1     1
    x[2829]   c890      -2048
    x[2829]   c891      -2048
    x[2829]   c892      -277
    x[2830]   c62_1     -1
    x[2830]   c63_1     1
    x[2830]   c890      -2048
    x[2830]   c891      -2048
    x[2830]   c892      -277
    x[2831]   c63_1     -1
    x[2831]   c64_1     1
    x[2831]   c890      -27856
    x[2831]   c891      -27856
    x[2831]   c892      -1715
    x[2832]   c64_1     -1
    x[2832]   c65_1     1
    x[2832]   c890      -34000
    x[2832]   c891      -34000
    x[2832]   c892      -2546
    x[2833]   c65_1     -1
    x[2833]   c890      -34000
    x[2833]   c891      -34000
    x[2833]   c892      -2546
    x[2834]   c889      1
    x[2835]   c218_1    1
    x[2835]   c890      1
    x[2836]   c259_1    1
    x[2836]   c891      1
    x[2837]   c892      1
    x[2837]   c1005     -1
    x[2838]   c167_2    -1
    x[2838]   c66_1     1
    x[2838]   c894      -2048
    x[2838]   c895      -2048
    x[2838]   c896      -226
    x[2839]   c167_2    1
    x[2839]   c66_1     -1
    x[2839]   c67_1     1
    x[2839]   c894      -2048
    x[2839]   c895      -2048
    x[2839]   c896      -226
    x[2840]   c67_1     -1
    x[2840]   c68_1     1
    x[2840]   c894      -2048
    x[2840]   c895      -2048
    x[2840]   c896      -226
    x[2841]   c68_1     -1
    x[2841]   c69_1     1
    x[2841]   c894      -27856
    x[2841]   c895      -27856
    x[2841]   c896      -1396
    x[2842]   c69_1     -1
    x[2842]   c70_1     1
    x[2842]   c894      -34000
    x[2842]   c895      -34000
    x[2842]   c896      -2074
    x[2843]   c70_1     -1
    x[2843]   c894      -34000
    x[2843]   c895      -34000
    x[2843]   c896      -2074
    x[2844]   c893      1
    x[2845]   c219_1    1
    x[2845]   c894      1
    x[2846]   c260_1    1
    x[2846]   c895      1
    x[2847]   c896      1
    x[2847]   c1005     -1
    x[2848]   c71_1     1
    x[2848]   c898      -2048
    x[2848]   c899      -2048
    x[2848]   c900      -173
    x[2849]   c71_1     -1
    x[2849]   c72_1     1
    x[2849]   c898      -2048
    x[2849]   c899      -2048
    x[2849]   c900      -173
    x[2850]   c72_1     -1
    x[2850]   c73_1     1
    x[2850]   c898      -2048
    x[2850]   c899      -2048
    x[2850]   c900      -173
    x[2851]   c73_1     -1
    x[2851]   c74_1     1
    x[2851]   c898      -27856
    x[2851]   c899      -27856
    x[2851]   c900      -1062
    x[2852]   c74_1     -1
    x[2852]   c75_1     1
    x[2852]   c898      -34000
    x[2852]   c899      -34000
    x[2852]   c900      -1581
    x[2853]   c75_1     -1
    x[2853]   c898      -34000
    x[2853]   c899      -34000
    x[2853]   c900      -1581
    x[2854]   c897      1
    x[2855]   c220_1    1
    x[2855]   c898      1
    x[2856]   c261_1    1
    x[2856]   c899      1
    x[2857]   c900      1
    x[2857]   c1005     -1
    x[2858]   c98_2     -1
    x[2858]   c76_1     1
    x[2858]   c902      -2048
    x[2858]   c903      -2048
    x[2858]   c904      -173
    x[2859]   c98_2     1
    x[2859]   c76_1     -1
    x[2859]   c77_1     1
    x[2859]   c902      -2048
    x[2859]   c903      -2048
    x[2859]   c904      -173
    x[2860]   c77_1     -1
    x[2860]   c78_1     1
    x[2860]   c902      -2048
    x[2860]   c903      -2048
    x[2860]   c904      -173
    x[2861]   c78_1     -1
    x[2861]   c79_1     1
    x[2861]   c902      -27856
    x[2861]   c903      -27856
    x[2861]   c904      -1058
    x[2862]   c79_1     -1
    x[2862]   c80_1     1
    x[2862]   c902      -34000
    x[2862]   c903      -34000
    x[2862]   c904      -1577
    x[2863]   c80_1     -1
    x[2863]   c902      -34000
    x[2863]   c903      -34000
    x[2863]   c904      -1577
    x[2864]   c901      1
    x[2865]   c221_1    1
    x[2865]   c902      1
    x[2866]   c262_1    1
    x[2866]   c903      1
    x[2867]   c904      1
    x[2867]   c1005     -1
    x[2868]   c209_2    -1
    x[2868]   c81_1     1
    x[2868]   c906      -2048
    x[2868]   c907      -2048
    x[2868]   c908      -300
    x[2869]   c209_2    1
    x[2869]   c81_1     -1
    x[2869]   c82_1     1
    x[2869]   c906      -2048
    x[2869]   c907      -2048
    x[2869]   c908      -300
    x[2870]   c82_1     -1
    x[2870]   c83_1     1
    x[2870]   c906      -2048
    x[2870]   c907      -2048
    x[2870]   c908      -300
    x[2871]   c83_1     -1
    x[2871]   c84_1     1
    x[2871]   c906      -27856
    x[2871]   c907      -27856
    x[2871]   c908      -1873
    x[2872]   c84_1     -1
    x[2872]   c85_1     1
    x[2872]   c906      -34000
    x[2872]   c907      -34000
    x[2872]   c908      -2773
    x[2873]   c85_1     -1
    x[2873]   c906      -34000
    x[2873]   c907      -34000
    x[2873]   c908      -2773
    x[2874]   c905      1
    x[2875]   c222_1    1
    x[2875]   c906      1
    x[2876]   c263_1    1
    x[2876]   c907      1
    x[2877]   c908      1
    x[2877]   c1005     -1
    x[2878]   c16_2     -1
    x[2878]   c86_1     1
    x[2878]   c910      -2048
    x[2878]   c911      -2048
    x[2878]   c912      -168
    x[2879]   c16_2     1
    x[2879]   c86_1     -1
    x[2879]   c87_1     1
    x[2879]   c910      -2048
    x[2879]   c911      -2048
    x[2879]   c912      -168
    x[2880]   c87_1     -1
    x[2880]   c88_1     1
    x[2880]   c910      -2048
    x[2880]   c911      -2048
    x[2880]   c912      -168
    x[2881]   c88_1     -1
    x[2881]   c89_1     1
    x[2881]   c910      -27856
    x[2881]   c911      -27856
    x[2881]   c912      -1025
    x[2882]   c89_1     -1
    x[2882]   c90_1     1
    x[2882]   c910      -34000
    x[2882]   c911      -34000
    x[2882]   c912      -1529
    x[2883]   c90_1     -1
    x[2883]   c910      -34000
    x[2883]   c911      -34000
    x[2883]   c912      -1529
    x[2884]   c909      1
    x[2885]   c223_1    1
    x[2885]   c910      1
    x[2886]   c264_1    1
    x[2886]   c911      1
    x[2887]   c912      1
    x[2887]   c1005     -1
    x[2888]   c128_2    -1
    x[2888]   c91_1     1
    x[2888]   c914      -2048
    x[2888]   c915      -2048
    x[2888]   c916      -259
    x[2889]   c128_2    1
    x[2889]   c91_1     -1
    x[2889]   c92_1     1
    x[2889]   c914      -2048
    x[2889]   c915      -2048
    x[2889]   c916      -259
    x[2890]   c92_1     -1
    x[2890]   c93_1     1
    x[2890]   c914      -2048
    x[2890]   c915      -2048
    x[2890]   c916      -259
    x[2891]   c93_1     -1
    x[2891]   c94_1     1
    x[2891]   c914      -27856
    x[2891]   c915      -27856
    x[2891]   c916      -1606
    x[2892]   c94_1     -1
    x[2892]   c95_1     1
    x[2892]   c914      -34000
    x[2892]   c915      -34000
    x[2892]   c916      -2383
    x[2893]   c95_1     -1
    x[2893]   c914      -34000
    x[2893]   c915      -34000
    x[2893]   c916      -2383
    x[2894]   c913      1
    x[2895]   c224_1    1
    x[2895]   c914      1
    x[2896]   c265_1    1
    x[2896]   c915      1
    x[2897]   c916      1
    x[2897]   c1005     -1
    x[2898]   c240_2    -1
    x[2898]   c96_1     1
    x[2898]   c918      -2048
    x[2898]   c919      -2048
    x[2898]   c920      -324
    x[2899]   c240_2    1
    x[2899]   c96_1     -1
    x[2899]   c97_1     1
    x[2899]   c918      -2048
    x[2899]   c919      -2048
    x[2899]   c920      -324
    x[2900]   c97_1     -1
    x[2900]   c98_1     1
    x[2900]   c918      -2048
    x[2900]   c919      -2048
    x[2900]   c920      -324
    x[2901]   c98_1     -1
    x[2901]   c99_1     1
    x[2901]   c918      -27856
    x[2901]   c919      -27856
    x[2901]   c920      -2042
    x[2902]   c99_1     -1
    x[2902]   c100_1    1
    x[2902]   c918      -34000
    x[2902]   c919      -34000
    x[2902]   c920      -3014
    x[2903]   c100_1    -1
    x[2903]   c918      -34000
    x[2903]   c919      -34000
    x[2903]   c920      -3014
    x[2904]   c917      1
    x[2905]   c225_1    1
    x[2905]   c918      1
    x[2906]   c266_1    1
    x[2906]   c919      1
    x[2907]   c920      1
    x[2907]   c1005     -1
    x[2908]   c62_2     -1
    x[2908]   c101_1    1
    x[2908]   c922      -2048
    x[2908]   c923      -2048
    x[2908]   c924      -284
    x[2909]   c62_2     1
    x[2909]   c101_1    -1
    x[2909]   c102_1    1
    x[2909]   c922      -2048
    x[2909]   c923      -2048
    x[2909]   c924      -284
    x[2910]   c102_1    -1
    x[2910]   c103_1    1
    x[2910]   c922      -2048
    x[2910]   c923      -2048
    x[2910]   c924      -284
    x[2911]   c103_1    -1
    x[2911]   c104_1    1
    x[2911]   c922      -27856
    x[2911]   c923      -27856
    x[2911]   c924      -1766
    x[2912]   c104_1    -1
    x[2912]   c105_1    1
    x[2912]   c922      -34000
    x[2912]   c923      -34000
    x[2912]   c924      -2618
    x[2913]   c105_1    -1
    x[2913]   c922      -34000
    x[2913]   c923      -34000
    x[2913]   c924      -2618
    x[2914]   c921      1
    x[2915]   c226_1    1
    x[2915]   c922      1
    x[2916]   c267_1    1
    x[2916]   c923      1
    x[2917]   c924      1
    x[2917]   c1005     -1
    x[2918]   c168_2    -1
    x[2918]   c106_1    1
    x[2918]   c926      -2048
    x[2918]   c927      -2048
    x[2918]   c928      -42
    x[2919]   c168_2    1
    x[2919]   c106_1    -1
    x[2919]   c107_1    1
    x[2919]   c926      -2048
    x[2919]   c927      -2048
    x[2919]   c928      -42
    x[2920]   c107_1    -1
    x[2920]   c108_1    1
    x[2920]   c926      -2048
    x[2920]   c927      -2048
    x[2920]   c928      -42
    x[2921]   c108_1    -1
    x[2921]   c109_1    1
    x[2921]   c926      -27856
    x[2921]   c927      -27856
    x[2921]   c928      -198
    x[2922]   c109_1    -1
    x[2922]   c110_1    1
    x[2922]   c926      -34000
    x[2922]   c927      -34000
    x[2922]   c928      -324
    x[2923]   c110_1    -1
    x[2923]   c926      -34000
    x[2923]   c927      -34000
    x[2923]   c928      -324
    x[2924]   c925      1
    x[2925]   c227_1    1
    x[2925]   c926      1
    x[2926]   c268_1    1
    x[2926]   c927      1
    x[2927]   c928      1
    x[2927]   c1005     -1
    x[2928]   c111_1    1
    x[2928]   c930      -2048
    x[2928]   c931      -2048
    x[2928]   c932      -323
    x[2929]   c111_1    -1
    x[2929]   c112_1    1
    x[2929]   c930      -2048
    x[2929]   c931      -2048
    x[2929]   c932      -323
    x[2930]   c112_1    -1
    x[2930]   c113_1    1
    x[2930]   c930      -2048
    x[2930]   c931      -2048
    x[2930]   c932      -323
    x[2931]   c113_1    -1
    x[2931]   c114_1    1
    x[2931]   c930      -27856
    x[2931]   c931      -27856
    x[2931]   c932      -2030
    x[2932]   c114_1    -1
    x[2932]   c115_1    1
    x[2932]   c930      -34000
    x[2932]   c931      -34000
    x[2932]   c932      -2999
    x[2933]   c115_1    -1
    x[2933]   c930      -34000
    x[2933]   c931      -34000
    x[2933]   c932      -2999
    x[2934]   c929      1
    x[2935]   c228_1    1
    x[2935]   c930      1
    x[2936]   c269_1    1
    x[2936]   c931      1
    x[2937]   c932      1
    x[2937]   c1005     -1
    x[2938]   c99_2     -1
    x[2938]   c116_1    1
    x[2938]   c934      -2048
    x[2938]   c935      -2048
    x[2938]   c936      -277
    x[2939]   c99_2     1
    x[2939]   c116_1    -1
    x[2939]   c117_1    1
    x[2939]   c934      -2048
    x[2939]   c935      -2048
    x[2939]   c936      -277
    x[2940]   c117_1    -1
    x[2940]   c118_1    1
    x[2940]   c934      -2048
    x[2940]   c935      -2048
    x[2940]   c936      -277
    x[2941]   c118_1    -1
    x[2941]   c119_1    1
    x[2941]   c934      -27856
    x[2941]   c935      -27856
    x[2941]   c936      -1722
    x[2942]   c119_1    -1
    x[2942]   c120_1    1
    x[2942]   c934      -34000
    x[2942]   c935      -34000
    x[2942]   c936      -2553
    x[2943]   c120_1    -1
    x[2943]   c934      -34000
    x[2943]   c935      -34000
    x[2943]   c936      -2553
    x[2944]   c933      1
    x[2945]   c229_1    1
    x[2945]   c934      1
    x[2946]   c270_1    1
    x[2946]   c935      1
    x[2947]   c936      1
    x[2947]   c1005     -1
    x[2948]   c210_2    -1
    x[2948]   c121_1    1
    x[2948]   c938      -2048
    x[2948]   c939      -2048
    x[2948]   c940      -172
    x[2949]   c210_2    1
    x[2949]   c121_1    -1
    x[2949]   c122_1    1
    x[2949]   c938      -2048
    x[2949]   c939      -2048
    x[2949]   c940      -172
    x[2950]   c122_1    -1
    x[2950]   c123_1    1
    x[2950]   c938      -2048
    x[2950]   c939      -2048
    x[2950]   c940      -172
    x[2951]   c123_1    -1
    x[2951]   c124_1    1
    x[2951]   c938      -27856
    x[2951]   c939      -27856
    x[2951]   c940      -1048
    x[2952]   c124_1    -1
    x[2952]   c125_1    1
    x[2952]   c938      -34000
    x[2952]   c939      -34000
    x[2952]   c940      -1564
    x[2953]   c125_1    -1
    x[2953]   c938      -34000
    x[2953]   c939      -34000
    x[2953]   c940      -1564
    x[2954]   c937      1
    x[2955]   c230_1    1
    x[2955]   c938      1
    x[2956]   c271_1    1
    x[2956]   c939      1
    x[2957]   c940      1
    x[2957]   c1005     -1
    x[2958]   c17_2     -1
    x[2958]   c126_1    1
    x[2958]   c942      -2048
    x[2958]   c943      -2048
    x[2958]   c944      -298
    x[2959]   c17_2     1
    x[2959]   c126_1    -1
    x[2959]   c127_1    1
    x[2959]   c942      -2048
    x[2959]   c943      -2048
    x[2959]   c944      -298
    x[2960]   c127_1    -1
    x[2960]   c128_1    1
    x[2960]   c942      -2048
    x[2960]   c943      -2048
    x[2960]   c944      -298
    x[2961]   c128_1    -1
    x[2961]   c129_1    1
    x[2961]   c942      -27856
    x[2961]   c943      -27856
    x[2961]   c944      -1859
    x[2962]   c129_1    -1
    x[2962]   c130_1    1
    x[2962]   c942      -34000
    x[2962]   c943      -34000
    x[2962]   c944      -2753
    x[2963]   c130_1    -1
    x[2963]   c942      -34000
    x[2963]   c943      -34000
    x[2963]   c944      -2753
    x[2964]   c941      1
    x[2965]   c231_1    1
    x[2965]   c942      1
    x[2966]   c272_1    1
    x[2966]   c943      1
    x[2967]   c944      1
    x[2967]   c1005     -1
    x[2968]   c129_2    -1
    x[2968]   c131_1    1
    x[2968]   c946      -2048
    x[2968]   c947      -2048
    x[2968]   c948      -300
    x[2969]   c129_2    1
    x[2969]   c131_1    -1
    x[2969]   c132_1    1
    x[2969]   c946      -2048
    x[2969]   c947      -2048
    x[2969]   c948      -300
    x[2970]   c132_1    -1
    x[2970]   c133_1    1
    x[2970]   c946      -2048
    x[2970]   c947      -2048
    x[2970]   c948      -300
    x[2971]   c133_1    -1
    x[2971]   c134_1    1
    x[2971]   c946      -27856
    x[2971]   c947      -27856
    x[2971]   c948      -1873
    x[2972]   c134_1    -1
    x[2972]   c135_1    1
    x[2972]   c946      -34000
    x[2972]   c947      -34000
    x[2972]   c948      -2773
    x[2973]   c135_1    -1
    x[2973]   c946      -34000
    x[2973]   c947      -34000
    x[2973]   c948      -2773
    x[2974]   c945      1
    x[2975]   c232_1    1
    x[2975]   c946      1
    x[2976]   c273_1    1
    x[2976]   c947      1
    x[2977]   c948      1
    x[2977]   c1005     -1
    x[2978]   c241_2    -1
    x[2978]   c136_1    1
    x[2978]   c950      -2048
    x[2978]   c951      -2048
    x[2978]   c952      -356
    x[2979]   c241_2    1
    x[2979]   c136_1    -1
    x[2979]   c137_1    1
    x[2979]   c950      -2048
    x[2979]   c951      -2048
    x[2979]   c952      -356
    x[2980]   c137_1    -1
    x[2980]   c138_1    1
    x[2980]   c950      -2048
    x[2980]   c951      -2048
    x[2980]   c952      -356
    x[2981]   c138_1    -1
    x[2981]   c139_1    1
    x[2981]   c950      -27856
    x[2981]   c951      -27856
    x[2981]   c952      -2255
    x[2982]   c139_1    -1
    x[2982]   c140_1    1
    x[2982]   c950      -34000
    x[2982]   c951      -34000
    x[2982]   c952      -3323
    x[2983]   c140_1    -1
    x[2983]   c950      -34000
    x[2983]   c951      -34000
    x[2983]   c952      -3323
    x[2984]   c949      1
    x[2985]   c233_1    1
    x[2985]   c950      1
    x[2986]   c274_1    1
    x[2986]   c951      1
    x[2987]   c952      1
    x[2987]   c1005     -1
    x[2988]   c63_2     -1
    x[2988]   c141_1    1
    x[2988]   c954      -2048
    x[2988]   c955      -2048
    x[2988]   c956      -286
    x[2989]   c63_2     1
    x[2989]   c141_1    -1
    x[2989]   c142_1    1
    x[2989]   c954      -2048
    x[2989]   c955      -2048
    x[2989]   c956      -286
    x[2990]   c142_1    -1
    x[2990]   c143_1    1
    x[2990]   c954      -2048
    x[2990]   c955      -2048
    x[2990]   c956      -286
    x[2991]   c143_1    -1
    x[2991]   c144_1    1
    x[2991]   c954      -27856
    x[2991]   c955      -27856
    x[2991]   c956      -1782
    x[2992]   c144_1    -1
    x[2992]   c145_1    1
    x[2992]   c954      -34000
    x[2992]   c955      -34000
    x[2992]   c956      -2640
    x[2993]   c145_1    -1
    x[2993]   c954      -34000
    x[2993]   c955      -34000
    x[2993]   c956      -2640
    x[2994]   c953      1
    x[2995]   c234_1    1
    x[2995]   c954      1
    x[2996]   c275_1    1
    x[2996]   c955      1
    x[2997]   c956      1
    x[2997]   c1005     -1
    x[2998]   c169_2    -1
    x[2998]   c146_1    1
    x[2998]   c958      -2048
    x[2998]   c959      -2048
    x[2998]   c960      -244
    x[2999]   c169_2    1
    x[2999]   c146_1    -1
    x[2999]   c147_1    1
    x[2999]   c958      -2048
    x[2999]   c959      -2048
    x[2999]   c960      -244
    x[3000]   c147_1    -1
    x[3000]   c148_1    1
    x[3000]   c958      -2048
    x[3000]   c959      -2048
    x[3000]   c960      -244
    x[3001]   c148_1    -1
    x[3001]   c149_1    1
    x[3001]   c958      -27856
    x[3001]   c959      -27856
    x[3001]   c960      -1510
    x[3002]   c149_1    -1
    x[3002]   c150_1    1
    x[3002]   c958      -34000
    x[3002]   c959      -34000
    x[3002]   c960      -2242
    x[3003]   c150_1    -1
    x[3003]   c958      -34000
    x[3003]   c959      -34000
    x[3003]   c960      -2242
    x[3004]   c957      1
    x[3005]   c235_1    1
    x[3005]   c958      1
    x[3006]   c276_1    1
    x[3006]   c959      1
    x[3007]   c960      1
    x[3007]   c1005     -1
    x[3008]   c151_1    1
    x[3008]   c962      -2048
    x[3008]   c963      -2048
    x[3008]   c964      -338
    x[3009]   c151_1    -1
    x[3009]   c152_1    1
    x[3009]   c962      -2048
    x[3009]   c963      -2048
    x[3009]   c964      -338
    x[3010]   c152_1    -1
    x[3010]   c153_1    1
    x[3010]   c962      -2048
    x[3010]   c963      -2048
    x[3010]   c964      -338
    x[3011]   c153_1    -1
    x[3011]   c154_1    1
    x[3011]   c962      -27856
    x[3011]   c963      -27856
    x[3011]   c964      -2133
    x[3012]   c154_1    -1
    x[3012]   c155_1    1
    x[3012]   c962      -34000
    x[3012]   c963      -34000
    x[3012]   c964      -3147
    x[3013]   c155_1    -1
    x[3013]   c962      -34000
    x[3013]   c963      -34000
    x[3013]   c964      -3147
    x[3014]   c961      1
    x[3015]   c236_1    1
    x[3015]   c962      1
    x[3016]   c277_1    1
    x[3016]   c963      1
    x[3017]   c964      1
    x[3017]   c1005     -1
    x[3018]   c100_2    -1
    x[3018]   c156_1    1
    x[3018]   c966      -2048
    x[3018]   c967      -2048
    x[3018]   c968      -298
    x[3019]   c100_2    1
    x[3019]   c156_1    -1
    x[3019]   c157_1    1
    x[3019]   c966      -2048
    x[3019]   c967      -2048
    x[3019]   c968      -298
    x[3020]   c157_1    -1
    x[3020]   c158_1    1
    x[3020]   c966      -2048
    x[3020]   c967      -2048
    x[3020]   c968      -298
    x[3021]   c158_1    -1
    x[3021]   c159_1    1
    x[3021]   c966      -27856
    x[3021]   c967      -27856
    x[3021]   c968      -1863
    x[3022]   c159_1    -1
    x[3022]   c160_1    1
    x[3022]   c966      -34000
    x[3022]   c967      -34000
    x[3022]   c968      -2757
    x[3023]   c160_1    -1
    x[3023]   c966      -34000
    x[3023]   c967      -34000
    x[3023]   c968      -2757
    x[3024]   c965      1
    x[3025]   c237_1    1
    x[3025]   c966      1
    x[3026]   c278_1    1
    x[3026]   c967      1
    x[3027]   c968      1
    x[3027]   c1005     -1
    x[3028]   c211_2    -1
    x[3028]   c161_1    1
    x[3028]   c970      -2048
    x[3028]   c971      -2048
    x[3028]   c972      -45
    x[3029]   c211_2    1
    x[3029]   c161_1    -1
    x[3029]   c162_1    1
    x[3029]   c970      -2048
    x[3029]   c971      -2048
    x[3029]   c972      -45
    x[3030]   c162_1    -1
    x[3030]   c163_1    1
    x[3030]   c970      -2048
    x[3030]   c971      -2048
    x[3030]   c972      -45
    x[3031]   c163_1    -1
    x[3031]   c164_1    1
    x[3031]   c970      -27856
    x[3031]   c971      -27856
    x[3031]   c972      -234
    x[3032]   c164_1    -1
    x[3032]   c165_1    1
    x[3032]   c970      -34000
    x[3032]   c971      -34000
    x[3032]   c972      -369
    x[3033]   c165_1    -1
    x[3033]   c970      -34000
    x[3033]   c971      -34000
    x[3033]   c972      -369
    x[3034]   c969      1
    x[3035]   c238_1    1
    x[3035]   c970      1
    x[3036]   c279_1    1
    x[3036]   c971      1
    x[3037]   c972      1
    x[3037]   c1005     -1
    x[3038]   c18_2     -1
    x[3038]   c166_1    1
    x[3038]   c974      -2048
    x[3038]   c975      -2048
    x[3038]   c976      -209
    x[3039]   c18_2     1
    x[3039]   c166_1    -1
    x[3039]   c167_1    1
    x[3039]   c974      -2048
    x[3039]   c975      -2048
    x[3039]   c976      -209
    x[3040]   c167_1    -1
    x[3040]   c168_1    1
    x[3040]   c974      -2048
    x[3040]   c975      -2048
    x[3040]   c976      -209
    x[3041]   c168_1    -1
    x[3041]   c169_1    1
    x[3041]   c974      -27856
    x[3041]   c975      -27856
    x[3041]   c976      -1286
    x[3042]   c169_1    -1
    x[3042]   c170_1    1
    x[3042]   c974      -34000
    x[3042]   c975      -34000
    x[3042]   c976      -1913
    x[3043]   c170_1    -1
    x[3043]   c974      -34000
    x[3043]   c975      -34000
    x[3043]   c976      -1913
    x[3044]   c973      1
    x[3045]   c239_1    1
    x[3045]   c974      1
    x[3046]   c280_1    1
    x[3046]   c975      1
    x[3047]   c976      1
    x[3047]   c1005     -1
    x[3048]   c130_2    -1
    x[3048]   c171_1    1
    x[3048]   c978      -2048
    x[3048]   c979      -2048
    x[3048]   c980      -45
    x[3049]   c130_2    1
    x[3049]   c171_1    -1
    x[3049]   c172_1    1
    x[3049]   c978      -2048
    x[3049]   c979      -2048
    x[3049]   c980      -45
    x[3050]   c172_1    -1
    x[3050]   c173_1    1
    x[3050]   c978      -2048
    x[3050]   c979      -2048
    x[3050]   c980      -45
    x[3051]   c173_1    -1
    x[3051]   c174_1    1
    x[3051]   c978      -27856
    x[3051]   c979      -27856
    x[3051]   c980      -236
    x[3052]   c174_1    -1
    x[3052]   c175_1    1
    x[3052]   c978      -34000
    x[3052]   c979      -34000
    x[3052]   c980      -371
    x[3053]   c175_1    -1
    x[3053]   c978      -34000
    x[3053]   c979      -34000
    x[3053]   c980      -371
    x[3054]   c977      1
    x[3055]   c240_1    1
    x[3055]   c978      1
    x[3056]   c281_1    1
    x[3056]   c979      1
    x[3057]   c980      1
    x[3057]   c1005     -1
    x[3058]   c242_2    -1
    x[3058]   c176_1    1
    x[3058]   c982      -2048
    x[3058]   c983      -2048
    x[3058]   c984      -144
    x[3059]   c242_2    1
    x[3059]   c176_1    -1
    x[3059]   c177_1    1
    x[3059]   c982      -2048
    x[3059]   c983      -2048
    x[3059]   c984      -144
    x[3060]   c177_1    -1
    x[3060]   c178_1    1
    x[3060]   c982      -2048
    x[3060]   c983      -2048
    x[3060]   c984      -144
    x[3061]   c178_1    -1
    x[3061]   c179_1    1
    x[3061]   c982      -27856
    x[3061]   c983      -27856
    x[3061]   c984      -880
    x[3062]   c179_1    -1
    x[3062]   c180_1    1
    x[3062]   c982      -34000
    x[3062]   c983      -34000
    x[3062]   c984      -1312
    x[3063]   c180_1    -1
    x[3063]   c982      -34000
    x[3063]   c983      -34000
    x[3063]   c984      -1312
    x[3064]   c981      1
    x[3065]   c241_1    1
    x[3065]   c982      1
    x[3066]   c282_1    1
    x[3066]   c983      1
    x[3067]   c984      1
    x[3067]   c1005     -1
    x[3068]   c64_2     -1
    x[3068]   c181_1    1
    x[3068]   c986      -2048
    x[3068]   c987      -2048
    x[3068]   c988      -322
    x[3069]   c64_2     1
    x[3069]   c181_1    -1
    x[3069]   c182_1    1
    x[3069]   c986      -2048
    x[3069]   c987      -2048
    x[3069]   c988      -322
    x[3070]   c182_1    -1
    x[3070]   c183_1    1
    x[3070]   c986      -2048
    x[3070]   c987      -2048
    x[3070]   c988      -322
    x[3071]   c183_1    -1
    x[3071]   c184_1    1
    x[3071]   c986      -27856
    x[3071]   c987      -27856
    x[3071]   c988      -2027
    x[3072]   c184_1    -1
    x[3072]   c185_1    1
    x[3072]   c986      -34000
    x[3072]   c987      -34000
    x[3072]   c988      -2993
    x[3073]   c185_1    -1
    x[3073]   c986      -34000
    x[3073]   c987      -34000
    x[3073]   c988      -2993
    x[3074]   c985      1
    x[3075]   c242_1    1
    x[3075]   c986      1
    x[3076]   c283_1    1
    x[3076]   c987      1
    x[3077]   c988      1
    x[3077]   c1005     -1
    x[3078]   c170_2    -1
    x[3078]   c186_1    1
    x[3078]   c990      -2048
    x[3078]   c991      -2048
    x[3078]   c992      -277
    x[3079]   c170_2    1
    x[3079]   c186_1    -1
    x[3079]   c187_1    1
    x[3079]   c990      -2048
    x[3079]   c991      -2048
    x[3079]   c992      -277
    x[3080]   c187_1    -1
    x[3080]   c188_1    1
    x[3080]   c990      -2048
    x[3080]   c991      -2048
    x[3080]   c992      -277
    x[3081]   c188_1    -1
    x[3081]   c189_1    1
    x[3081]   c990      -27856
    x[3081]   c991      -27856
    x[3081]   c992      -1716
    x[3082]   c189_1    -1
    x[3082]   c190_1    1
    x[3082]   c990      -34000
    x[3082]   c991      -34000
    x[3082]   c992      -2547
    x[3083]   c190_1    -1
    x[3083]   c990      -34000
    x[3083]   c991      -34000
    x[3083]   c992      -2547
    x[3084]   c989      1
    x[3085]   c243_1    1
    x[3085]   c990      1
    x[3086]   c284_1    1
    x[3086]   c991      1
    x[3087]   c992      1
    x[3087]   c1005     -1
    x[3088]   c191_1    1
    x[3088]   c994      -2048
    x[3088]   c995      -2048
    x[3088]   c996      -170
    x[3089]   c191_1    -1
    x[3089]   c192_1    1
    x[3089]   c994      -2048
    x[3089]   c995      -2048
    x[3089]   c996      -170
    x[3090]   c192_1    -1
    x[3090]   c193_1    1
    x[3090]   c994      -2048
    x[3090]   c995      -2048
    x[3090]   c996      -170
    x[3091]   c193_1    -1
    x[3091]   c194_1    1
    x[3091]   c994      -27856
    x[3091]   c995      -27856
    x[3091]   c996      -1040
    x[3092]   c194_1    -1
    x[3092]   c195_1    1
    x[3092]   c994      -34000
    x[3092]   c995      -34000
    x[3092]   c996      -1550
    x[3093]   c195_1    -1
    x[3093]   c994      -34000
    x[3093]   c995      -34000
    x[3093]   c996      -1550
    x[3094]   c993      1
    x[3095]   c244_1    1
    x[3095]   c994      1
    x[3096]   c285_1    1
    x[3096]   c995      1
    x[3097]   c996      1
    x[3097]   c1005     -1
    x[3098]   c101_2    -1
    x[3098]   c196_1    1
    x[3098]   c998      -2048
    x[3098]   c999      -2048
    x[3098]   c1000     -36
    x[3099]   c101_2    1
    x[3099]   c196_1    -1
    x[3099]   c197_1    1
    x[3099]   c998      -2048
    x[3099]   c999      -2048
    x[3099]   c1000     -36
    x[3100]   c197_1    -1
    x[3100]   c198_1    1
    x[3100]   c998      -2048
    x[3100]   c999      -2048
    x[3100]   c1000     -36
    x[3101]   c198_1    -1
    x[3101]   c199_1    1
    x[3101]   c998      -27856
    x[3101]   c999      -27856
    x[3101]   c1000     -137
    x[3102]   c199_1    -1
    x[3102]   c200_1    1
    x[3102]   c998      -34000
    x[3102]   c999      -34000
    x[3102]   c1000     -245
    x[3103]   c200_1    -1
    x[3103]   c998      -34000
    x[3103]   c999      -34000
    x[3103]   c1000     -245
    x[3104]   c997      1
    x[3105]   c245_1    1
    x[3105]   c998      1
    x[3106]   c286_1    1
    x[3106]   c999      1
    x[3107]   c1000     1
    x[3107]   c1005     -1
    x[3108]   c212_2    -1
    x[3108]   c201_1    1
    x[3108]   c1002     -2048
    x[3108]   c1003     -2048
    x[3108]   c1004     -299
    x[3109]   c212_2    1
    x[3109]   c201_1    -1
    x[3109]   c202_1    1
    x[3109]   c1002     -2048
    x[3109]   c1003     -2048
    x[3109]   c1004     -299
    x[3110]   c202_1    -1
    x[3110]   c203_1    1
    x[3110]   c1002     -2048
    x[3110]   c1003     -2048
    x[3110]   c1004     -299
    x[3111]   c203_1    -1
    x[3111]   c204_1    1
    x[3111]   c1002     -27856
    x[3111]   c1003     -27856
    x[3111]   c1004     -1866
    x[3112]   c204_1    -1
    x[3112]   c205_1    1
    x[3112]   c1002     -34000
    x[3112]   c1003     -34000
    x[3112]   c1004     -2763
    x[3113]   c205_1    -1
    x[3113]   c1002     -34000
    x[3113]   c1003     -34000
    x[3113]   c1004     -2763
    x[3114]   c1001     1
    x[3115]   c246_1    1
    x[3115]   c1002     1
    x[3116]   c287_1    1
    x[3116]   c1003     1
    x[3117]   c1004     1
    x[3117]   c1005     -1
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1_2      1
    rhs       c2_2      1
    rhs       c3_2      1
    rhs       c4_2      1
    rhs       c5_2      1
    rhs       c6_2      1
    rhs       c7_2      1
    rhs       c8_2      1
    rhs       c9_2      1
    rhs       c10_2     1
    rhs       c11_2     1
    rhs       c12_2     1
    rhs       c13_2     1
    rhs       c14_2     1
    rhs       c15_2     1
    rhs       c16_2     0
    rhs       c17_2     0
    rhs       c18_2     0
    rhs       c19_2     1
    rhs       c20_2     1
    rhs       c21_2     1
    rhs       c22_2     1
    rhs       c23_2     1
    rhs       c24_2     1
    rhs       c25_2     1
    rhs       c26_2     1
    rhs       c27_2     1
    rhs       c28_2     1
    rhs       c29_2     1
    rhs       c30_2     1
    rhs       c31_2     1
    rhs       c32_2     1
    rhs       c33_2     1
    rhs       c34_2     1
    rhs       c35_2     1
    rhs       c36_2     1
    rhs       c37_2     1
    rhs       c38_2     1
    rhs       c39_2     1
    rhs       c40_2     1
    rhs       c41_2     1
    rhs       c42_2     1
    rhs       c43_2     1
    rhs       c44_2     1
    rhs       c45_2     1
    rhs       c46_2     1
    rhs       c47_2     1
    rhs       c48_2     1
    rhs       c49_2     1
    rhs       c50_2     1
    rhs       c51_2     1
    rhs       c52_2     1
    rhs       c53_2     1
    rhs       c54_2     1
    rhs       c55_2     1
    rhs       c56_2     1
    rhs       c57_2     1
    rhs       c58_2     1
    rhs       c59_2     0
    rhs       c60_2     0
    rhs       c61_2     0
    rhs       c62_2     0
    rhs       c63_2     0
    rhs       c64_2     0
    rhs       c65_2     1
    rhs       c66_2     1
    rhs       c67_2     1
    rhs       c68_2     1
    rhs       c69_2     1
    rhs       c70_2     1
    rhs       c71_2     1
    rhs       c72_2     1
    rhs       c73_2     1
    rhs       c74_2     1
    rhs       c75_2     1
    rhs       c76_2     1
    rhs       c77_2     1
    rhs       c78_2     1
    rhs       c79_2     1
    rhs       c80_2     1
    rhs       c81_2     1
    rhs       c82_2     1
    rhs       c83_2     1
    rhs       c84_2     0
    rhs       c85_2     0
    rhs       c86_2     1
    rhs       c87_2     1
    rhs       c88_2     1
    rhs       c89_2     1
    rhs       c90_2     1
    rhs       c91_2     1
    rhs       c92_2     1
    rhs       c93_2     1
    rhs       c94_2     1
    rhs       c95_2     1
    rhs       c96_2     1
    rhs       c97_2     1
    rhs       c98_2     0
    rhs       c99_2     0
    rhs       c100_2    0
    rhs       c101_2    0
    rhs       c102_2    1
    rhs       c103_2    1
    rhs       c104_2    1
    rhs       c105_2    1
    rhs       c106_2    1
    rhs       c107_2    1
    rhs       c108_2    1
    rhs       c109_2    1
    rhs       c110_2    1
    rhs       c111_2    1
    rhs       c112_2    1
    rhs       c113_2    0
    rhs       c114_2    0
    rhs       c115_2    1
    rhs       c116_2    1
    rhs       c117_2    1
    rhs       c118_2    1
    rhs       c119_2    1
    rhs       c120_2    1
    rhs       c121_2    1
    rhs       c122_2    1
    rhs       c123_2    1
    rhs       c124_2    1
    rhs       c125_2    1
    rhs       c126_2    1
    rhs       c127_2    1
    rhs       c128_2    0
    rhs       c129_2    0
    rhs       c130_2    0
    rhs       c131_2    1
    rhs       c132_2    1
    rhs       c133_2    1
    rhs       c134_2    1
    rhs       c135_2    1
    rhs       c136_2    1
    rhs       c137_2    1
    rhs       c138_2    1
    rhs       c139_2    1
    rhs       c140_2    1
    rhs       c141_2    1
    rhs       c142_2    1
    rhs       c143_2    1
    rhs       c144_2    1
    rhs       c145_2    1
    rhs       c146_2    1
    rhs       c147_2    1
    rhs       c148_2    1
    rhs       c149_2    1
    rhs       c150_2    1
    rhs       c151_2    1
    rhs       c152_2    1
    rhs       c153_2    1
    rhs       c154_2    1
    rhs       c155_2    1
    rhs       c156_2    1
    rhs       c157_2    1
    rhs       c158_2    1
    rhs       c159_2    1
    rhs       c160_2    1
    rhs       c161_2    1
    rhs       c162_2    1
    rhs       c163_2    1
    rhs       c164_2    1
    rhs       c165_2    1
    rhs       c166_2    0
    rhs       c167_2    0
    rhs       c168_2    0
    rhs       c169_2    0
    rhs       c170_2    0
    rhs       c171_2    1
    rhs       c172_2    1
    rhs       c173_2    1
    rhs       c174_2    1
    rhs       c175_2    1
    rhs       c176_2    1
    rhs       c177_2    1
    rhs       c178_2    1
    rhs       c179_2    1
    rhs       c180_2    1
    rhs       c181_2    1
    rhs       c182_2    1
    rhs       c183_2    1
    rhs       c184_2    1
    rhs       c185_2    1
    rhs       c186_2    1
    rhs       c187_2    1
    rhs       c188_2    1
    rhs       c189_2    1
    rhs       c190_2    1
    rhs       c191_2    1
    rhs       c192_2    1
    rhs       c193_2    1
    rhs       c194_2    1
    rhs       c195_2    1
    rhs       c196_2    1
    rhs       c197_2    1
    rhs       c198_2    1
    rhs       c199_2    1
    rhs       c200_2    1
    rhs       c201_2    1
    rhs       c202_2    1
    rhs       c203_2    1
    rhs       c204_2    1
    rhs       c205_2    1
    rhs       c206_2    1
    rhs       c207_2    1
    rhs       c208_2    0
    rhs       c209_2    0
    rhs       c210_2    0
    rhs       c211_2    0
    rhs       c212_2    0
    rhs       c213_2    1
    rhs       c214_2    1
    rhs       c215_2    1
    rhs       c216_2    1
    rhs       c217_2    1
    rhs       c218_2    1
    rhs       c219_2    1
    rhs       c220_2    1
    rhs       c221_2    1
    rhs       c222_2    1
    rhs       c223_2    1
    rhs       c224_2    1
    rhs       c225_2    1
    rhs       c226_2    0
    rhs       c227_2    0
    rhs       c228_2    1
    rhs       c229_2    1
    rhs       c230_2    1
    rhs       c231_2    1
    rhs       c232_2    1
    rhs       c233_2    1
    rhs       c234_2    1
    rhs       c235_2    1
    rhs       c236_2    1
    rhs       c237_2    1
    rhs       c238_2    1
    rhs       c239_2    1
    rhs       c240_2    0
    rhs       c241_2    0
    rhs       c242_2    0
    rhs       c243_2    1
    rhs       c244_2    1
    rhs       c245_2    1
    rhs       c246_2    1
    rhs       c247_2    1
    rhs       c248_2    1
    rhs       c249_2    1
    rhs       c250_2    1
    rhs       c251_2    1
    rhs       c252_2    1
    rhs       c253_2    1
    rhs       c254_2    1
    rhs       c255_2    1
    rhs       c256_2    1
    rhs       c257_2    1
    rhs       c258_2    1
    rhs       c259_2    1
    rhs       c260_2    1
    rhs       c261_2    1
    rhs       c262_2    1
    rhs       c263_2    0
    rhs       c1_1      0
    rhs       c2_1      0
    rhs       c3_1      0
    rhs       c4_1      0
    rhs       c5_1      0
    rhs       c6_1      0
    rhs       c7_1      0
    rhs       c8_1      0
    rhs       c9_1      0
    rhs       c10_1     0
    rhs       c11_1     0
    rhs       c12_1     0
    rhs       c13_1     0
    rhs       c14_1     0
    rhs       c15_1     0
    rhs       c16_1     0
    rhs       c17_1     0
    rhs       c18_1     0
    rhs       c19_1     0
    rhs       c20_1     0
    rhs       c21_1     0
    rhs       c22_1     0
    rhs       c23_1     0
    rhs       c24_1     0
    rhs       c25_1     0
    rhs       c26_1     0
    rhs       c27_1     0
    rhs       c28_1     0
    rhs       c29_1     0
    rhs       c30_1     0
    rhs       c31_1     0
    rhs       c32_1     0
    rhs       c33_1     0
    rhs       c34_1     0
    rhs       c35_1     0
    rhs       c36_1     0
    rhs       c37_1     0
    rhs       c38_1     0
    rhs       c39_1     0
    rhs       c40_1     0
    rhs       c41_1     0
    rhs       c42_1     0
    rhs       c43_1     0
    rhs       c44_1     0
    rhs       c45_1     0
    rhs       c46_1     0
    rhs       c47_1     0
    rhs       c48_1     0
    rhs       c49_1     0
    rhs       c50_1     0
    rhs       c51_1     0
    rhs       c52_1     0
    rhs       c53_1     0
    rhs       c54_1     0
    rhs       c55_1     0
    rhs       c56_1     0
    rhs       c57_1     0
    rhs       c58_1     0
    rhs       c59_1     0
    rhs       c60_1     0
    rhs       c61_1     0
    rhs       c62_1     0
    rhs       c63_1     0
    rhs       c64_1     0
    rhs       c65_1     0
    rhs       c66_1     0
    rhs       c67_1     0
    rhs       c68_1     0
    rhs       c69_1     0
    rhs       c70_1     0
    rhs       c71_1     0
    rhs       c72_1     0
    rhs       c73_1     0
    rhs       c74_1     0
    rhs       c75_1     0
    rhs       c76_1     0
    rhs       c77_1     0
    rhs       c78_1     0
    rhs       c79_1     0
    rhs       c80_1     0
    rhs       c81_1     0
    rhs       c82_1     0
    rhs       c83_1     0
    rhs       c84_1     0
    rhs       c85_1     0
    rhs       c86_1     0
    rhs       c87_1     0
    rhs       c88_1     0
    rhs       c89_1     0
    rhs       c90_1     0
    rhs       c91_1     0
    rhs       c92_1     0
    rhs       c93_1     0
    rhs       c94_1     0
    rhs       c95_1     0
    rhs       c96_1     0
    rhs       c97_1     0
    rhs       c98_1     0
    rhs       c99_1     0
    rhs       c100_1    0
    rhs       c101_1    0
    rhs       c102_1    0
    rhs       c103_1    0
    rhs       c104_1    0
    rhs       c105_1    0
    rhs       c106_1    0
    rhs       c107_1    0
    rhs       c108_1    0
    rhs       c109_1    0
    rhs       c110_1    0
    rhs       c111_1    0
    rhs       c112_1    0
    rhs       c113_1    0
    rhs       c114_1    0
    rhs       c115_1    0
    rhs       c116_1    0
    rhs       c117_1    0
    rhs       c118_1    0
    rhs       c119_1    0
    rhs       c120_1    0
    rhs       c121_1    0
    rhs       c122_1    0
    rhs       c123_1    0
    rhs       c124_1    0
    rhs       c125_1    0
    rhs       c126_1    0
    rhs       c127_1    0
    rhs       c128_1    0
    rhs       c129_1    0
    rhs       c130_1    0
    rhs       c131_1    0
    rhs       c132_1    0
    rhs       c133_1    0
    rhs       c134_1    0
    rhs       c135_1    0
    rhs       c136_1    0
    rhs       c137_1    0
    rhs       c138_1    0
    rhs       c139_1    0
    rhs       c140_1    0
    rhs       c141_1    0
    rhs       c142_1    0
    rhs       c143_1    0
    rhs       c144_1    0
    rhs       c145_1    0
    rhs       c146_1    0
    rhs       c147_1    0
    rhs       c148_1    0
    rhs       c149_1    0
    rhs       c150_1    0
    rhs       c151_1    0
    rhs       c152_1    0
    rhs       c153_1    0
    rhs       c154_1    0
    rhs       c155_1    0
    rhs       c156_1    0
    rhs       c157_1    0
    rhs       c158_1    0
    rhs       c159_1    0
    rhs       c160_1    0
    rhs       c161_1    0
    rhs       c162_1    0
    rhs       c163_1    0
    rhs       c164_1    0
    rhs       c165_1    0
    rhs       c166_1    0
    rhs       c167_1    0
    rhs       c168_1    0
    rhs       c169_1    0
    rhs       c170_1    0
    rhs       c171_1    0
    rhs       c172_1    0
    rhs       c173_1    0
    rhs       c174_1    0
    rhs       c175_1    0
    rhs       c176_1    0
    rhs       c177_1    0
    rhs       c178_1    0
    rhs       c179_1    0
    rhs       c180_1    0
    rhs       c181_1    0
    rhs       c182_1    0
    rhs       c183_1    0
    rhs       c184_1    0
    rhs       c185_1    0
    rhs       c186_1    0
    rhs       c187_1    0
    rhs       c188_1    0
    rhs       c189_1    0
    rhs       c190_1    0
    rhs       c191_1    0
    rhs       c192_1    0
    rhs       c193_1    0
    rhs       c194_1    0
    rhs       c195_1    0
    rhs       c196_1    0
    rhs       c197_1    0
    rhs       c198_1    0
    rhs       c199_1    0
    rhs       c200_1    0
    rhs       c201_1    0
    rhs       c202_1    0
    rhs       c203_1    0
    rhs       c204_1    0
    rhs       c205_1    0
    rhs       c206_1    0
    rhs       c207_1    0
    rhs       c208_1    0
    rhs       c209_1    0
    rhs       c210_1    0
    rhs       c211_1    0
    rhs       c212_1    0
    rhs       c213_1    0
    rhs       c214_1    0
    rhs       c215_1    0
    rhs       c216_1    0
    rhs       c217_1    0
    rhs       c218_1    0
    rhs       c219_1    0
    rhs       c220_1    0
    rhs       c221_1    0
    rhs       c222_1    0
    rhs       c223_1    0
    rhs       c224_1    0
    rhs       c225_1    0
    rhs       c226_1    0
    rhs       c227_1    0
    rhs       c228_1    0
    rhs       c229_1    0
    rhs       c230_1    0
    rhs       c231_1    0
    rhs       c232_1    0
    rhs       c233_1    0
    rhs       c234_1    0
    rhs       c235_1    0
    rhs       c236_1    0
    rhs       c237_1    0
    rhs       c238_1    0
    rhs       c239_1    0
    rhs       c240_1    0
    rhs       c241_1    0
    rhs       c242_1    0
    rhs       c243_1    0
    rhs       c244_1    0
    rhs       c245_1    0
    rhs       c246_1    0
    rhs       c247_1    0
    rhs       c248_1    0
    rhs       c249_1    0
    rhs       c250_1    0
    rhs       c251_1    0
    rhs       c252_1    0
    rhs       c253_1    0
    rhs       c254_1    0
    rhs       c255_1    0
    rhs       c256_1    0
    rhs       c257_1    0
    rhs       c258_1    0
    rhs       c259_1    0
    rhs       c260_1    0
    rhs       c261_1    0
    rhs       c262_1    0
    rhs       c263_1    0
    rhs       c264_1    0
    rhs       c265_1    0
    rhs       c266_1    0
    rhs       c267_1    0
    rhs       c268_1    0
    rhs       c269_1    0
    rhs       c270_1    0
    rhs       c271_1    0
    rhs       c272_1    0
    rhs       c273_1    0
    rhs       c274_1    0
    rhs       c275_1    0
    rhs       c276_1    0
    rhs       c277_1    0
    rhs       c278_1    0
    rhs       c279_1    0
    rhs       c280_1    0
    rhs       c281_1    0
    rhs       c282_1    0
    rhs       c283_1    0
    rhs       c284_1    0
    rhs       c285_1    0
    rhs       c286_1    0
    rhs       c287_1    0
    rhs       c288_1    0
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       1
    rhs       c17       1
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       1
    rhs       c43       1
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       1
    rhs       c70       1
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       1
    rhs       c94       1
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      1
    rhs       c121      1
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      1
    rhs       c144      1
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      1
    rhs       c171      1
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      1
    rhs       c198      1
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      1
    rhs       c222      1
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      1
    rhs       c248      1
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      0
    rhs       c262      0
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      1
    rhs       c275      1
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      0
    rhs       c289      0
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      1
    rhs       c299      1
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      1
    rhs       c323      1
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      1
    rhs       c350      1
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      1
    rhs       c374      1
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      1
    rhs       c398      1
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      1
    rhs       c423      1
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      1
    rhs       c450      1
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      1
    rhs       c475      1
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      1
    rhs       c501      1
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      1
    rhs       c526      1
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      1
    rhs       c550      1
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      1
    rhs       c575      1
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      1
    rhs       c602      1
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      1
    rhs       c628      1
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      1
    rhs       c655      1
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      1
    rhs       c681      1
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      1
    rhs       c707      1
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      1
    rhs       c733      1
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      1
    rhs       c757      1
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      1
    rhs       c781      1
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      1
    rhs       c807      1
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      1
    rhs       c832      1
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      1
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      1
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      1
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      1
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      1
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      1
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      1
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      1
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      1
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      1
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      1
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      1
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      1
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      1
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      1
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      1
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      1
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      1
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      1
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      1
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      1
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      1
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      1
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      1
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      1
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      1
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      1
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      1
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      1
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      1
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      1
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      1
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      1
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      1
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      1
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      1
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      1
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      1
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      1
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      1
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     1
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     0
    rhs       c1207     0
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     0
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     0
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     0
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     0
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     0
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     0
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     0
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     0
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     0
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     0
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     0
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     0
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     0
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     0
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     0
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     0
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
    rhs       c1981     0
    rhs       c1982     0
    rhs       c1983     0
    rhs       c1984     0
    rhs       c1985     0
    rhs       c1986     0
    rhs       c1987     0
    rhs       c1988     0
    rhs       c1989     0
    rhs       c1990     0
    rhs       c1991     0
    rhs       c1992     0
    rhs       c1993     0
    rhs       c1994     0
    rhs       c1995     0
    rhs       c1996     0
    rhs       c1997     0
    rhs       c1998     0
    rhs       c1999     0
    rhs       c2000     0
    rhs       c2001     0
    rhs       c2002     0
    rhs       c2003     0
    rhs       c2004     0
    rhs       c2005     0
    rhs       c2006     0
    rhs       c2007     0
    rhs       c2008     0
    rhs       c2009     0
    rhs       c2010     0
    rhs       c2011     0
    rhs       c2012     0
    rhs       c2013     0
    rhs       c2014     0
    rhs       c2015     0
    rhs       c2016     0
    rhs       c2017     0
    rhs       c2018     0
    rhs       c2019     0
    rhs       c2020     0
    rhs       c2021     0
    rhs       c2022     0
    rhs       c2023     0
    rhs       c2024     0
    rhs       c2025     0
    rhs       c2026     0
    rhs       c2027     0
    rhs       c2028     0
    rhs       c2029     0
    rhs       c2030     0
    rhs       c2031     0
    rhs       c2032     0
    rhs       c2033     0
    rhs       c2034     0
    rhs       c2035     0
    rhs       c2036     0
    rhs       c2037     0
    rhs       c2038     0
    rhs       c2039     0
    rhs       c2040     0
    rhs       c2041     0
    rhs       c2042     0
    rhs       c2043     0
    rhs       c2044     0
    rhs       c2045     0
    rhs       c2046     0
    rhs       c2047     0
    rhs       c2048     0
    rhs       c2049     0
    rhs       c2050     0
    rhs       c2051     0
    rhs       c2052     0
    rhs       c2053     0
    rhs       c2054     0
    rhs       c2055     0
    rhs       c2056     0
    rhs       c2057     0
    rhs       c2058     0
    rhs       c2059     0
    rhs       c2060     0
    rhs       c2061     0
    rhs       c2062     0
    rhs       c2063     0
    rhs       c2064     0
    rhs       c2065     0
    rhs       c2066     0
    rhs       c2067     0
    rhs       c2068     0
    rhs       c2069     0
    rhs       c2070     0
    rhs       c2071     0
    rhs       c2072     0
    rhs       c2073     0
    rhs       c2074     0
    rhs       c2075     0
    rhs       c2076     0
    rhs       c2077     0
    rhs       c2078     0
    rhs       c2079     0
    rhs       c2080     0
    rhs       c2081     0
    rhs       c2082     0
    rhs       c2083     0
    rhs       c2084     0
    rhs       c2085     0
    rhs       c2086     0
    rhs       c2087     0
    rhs       c2088     0
    rhs       c2089     0
    rhs       c2090     0
    rhs       c2091     0
    rhs       c2092     0
    rhs       c2093     0
    rhs       c2094     0
    rhs       c2095     0
    rhs       c2096     0
    rhs       c2097     0
    rhs       c2098     0
    rhs       c2099     0
    rhs       c2100     0
    rhs       c2101     0
    rhs       c2102     0
    rhs       c2103     0
    rhs       c2104     0
    rhs       c2105     0
    rhs       c2106     0
    rhs       c2107     0
    rhs       c2108     0
    rhs       c2109     0
    rhs       c2110     0
    rhs       c2111     0
    rhs       c2112     0
    rhs       c2113     0
    rhs       c2114     0
    rhs       c2115     0
    rhs       c2116     0
    rhs       c2117     0
    rhs       c2118     0
    rhs       c2119     0
    rhs       c2120     0
    rhs       c2121     0
    rhs       c2122     0
    rhs       c2123     0
    rhs       c2124     0
    rhs       c2125     0
    rhs       c2126     0
    rhs       c2127     0
    rhs       c2128     0
    rhs       c2129     0
    rhs       c2130     0
    rhs       c2131     0
    rhs       c2132     0
    rhs       c2133     0
    rhs       c2134     0
    rhs       c2135     0
    rhs       c2136     0
    rhs       c2137     0
    rhs       c2138     0
    rhs       c2139     0
    rhs       c2140     0
    rhs       c2141     0
    rhs       c2142     0
    rhs       c2143     0
    rhs       c2144     0
    rhs       c2145     0
    rhs       c2146     0
    rhs       c2147     0
    rhs       c2148     0
    rhs       c2149     0
    rhs       c2150     0
    rhs       c2151     0
    rhs       c2152     0
    rhs       c2153     0
    rhs       c2154     0
    rhs       c2155     0
    rhs       c2156     0
    rhs       c2157     0
    rhs       c2158     0
    rhs       c2159     0
    rhs       c2160     0
    rhs       c2161     0
    rhs       c2162     0
    rhs       c2163     0
    rhs       c2164     0
    rhs       c2165     0
    rhs       c2166     0
    rhs       c2167     0
    rhs       c2168     0
    rhs       c2169     0
    rhs       c2170     0
    rhs       c2171     0
    rhs       c2172     0
    rhs       c2173     0
    rhs       c2174     0
    rhs       c2175     0
    rhs       c2176     0
    rhs       c2177     0
    rhs       c2178     0
    rhs       c2179     0
    rhs       c2180     0
    rhs       c2181     0
    rhs       c2182     0
    rhs       c2183     0
    rhs       c2184     0
    rhs       c2185     0
    rhs       c2186     0
    rhs       c2187     0
    rhs       c2188     0
    rhs       c2189     0
    rhs       c2190     0
    rhs       c2191     0
    rhs       c2192     0
    rhs       c2193     0
    rhs       c2194     0
    rhs       c2195     0
    rhs       c2196     0
    rhs       c2197     0
    rhs       c2198     0
    rhs       c2199     0
    rhs       c2200     0
    rhs       c2201     0
    rhs       c2202     0
    rhs       c2203     0
    rhs       c2204     0
    rhs       c2205     0
    rhs       c2206     0
    rhs       c2207     0
    rhs       c2208     0
    rhs       c2209     0
    rhs       c2210     0
    rhs       c2211     0
    rhs       c2212     0
    rhs       c2213     0
    rhs       c2214     0
    rhs       c2215     0
    rhs       c2216     0
    rhs       c2217     0
    rhs       c2218     0
    rhs       c2219     0
    rhs       c2220     0
    rhs       c2221     0
    rhs       c2222     0
    rhs       c2223     0
    rhs       c2224     0
    rhs       c2225     0
    rhs       c2226     0
    rhs       c2227     0
    rhs       c2228     0
    rhs       c2229     0
    rhs       c2230     0
    rhs       c2231     0
    rhs       c2232     0
    rhs       c2233     0
    rhs       c2234     0
    rhs       c2235     0
    rhs       c2236     0
    rhs       c2237     0
    rhs       c2238     0
    rhs       c2239     0
    rhs       c2240     0
    rhs       c2241     0
    rhs       c2242     0
    rhs       c2243     0
    rhs       c2244     0
    rhs       c2245     0
    rhs       c2246     0
    rhs       c2247     0
    rhs       c2248     0
    rhs       c2249     0
    rhs       c2250     0
    rhs       c2251     0
    rhs       c2252     0
    rhs       c2253     0
    rhs       c2254     0
    rhs       c2255     0
    rhs       c2256     0
    rhs       c2257     0
    rhs       c2258     0
    rhs       c2259     0
    rhs       c2260     0
    rhs       c2261     0
    rhs       c2262     0
    rhs       c2263     0
    rhs       c2264     0
    rhs       c2265     0
    rhs       c2266     0
    rhs       c2267     0
    rhs       c2268     0
    rhs       c2269     0
    rhs       c2270     0
    rhs       c2271     0
    rhs       c2272     0
    rhs       c2273     0
    rhs       c2274     0
    rhs       c2275     0
    rhs       c2276     0
    rhs       c2277     0
    rhs       c2278     0
    rhs       c2279     0
    rhs       c2280     0
    rhs       c2281     0
    rhs       c2282     0
    rhs       c2283     0
    rhs       c2284     0
    rhs       c2285     0
    rhs       c2286     0
    rhs       c2287     0
    rhs       c2288     0
    rhs       c2289     0
    rhs       c2290     0
    rhs       c2291     0
    rhs       c2292     0
    rhs       c2293     0
    rhs       c2294     0
    rhs       c2295     0
    rhs       c2296     0
    rhs       c2297     0
    rhs       c2298     0
    rhs       c2299     0
    rhs       c2300     0
    rhs       c2301     0
    rhs       c2302     0
    rhs       c2303     0
    rhs       c2304     0
    rhs       c2305     0
    rhs       c2306     0
    rhs       c2307     0
    rhs       c2308     0
    rhs       c2309     0
    rhs       c2310     0
    rhs       c2311     0
    rhs       c2312     0
    rhs       c2313     0
    rhs       c2314     0
    rhs       c2315     0
    rhs       c2316     0
    rhs       c2317     0
    rhs       c2318     0
    rhs       c2319     0
    rhs       c2320     0
    rhs       c2321     0
    rhs       c2322     0
    rhs       c2323     0
    rhs       c2324     0
    rhs       c2325     0
    rhs       c2326     0
    rhs       c2327     0
    rhs       c2328     0
    rhs       c2329     0
    rhs       c2330     0
    rhs       c2331     0
    rhs       c2332     0
    rhs       c2333     0
    rhs       c2334     0
    rhs       c2335     0
    rhs       c2336     0
    rhs       c2337     0
    rhs       c2338     0
    rhs       c2339     0
    rhs       c2340     0
    rhs       c2341     0
    rhs       c2342     0
    rhs       c2343     0
    rhs       c2344     0
    rhs       c2345     0
    rhs       c2346     0
    rhs       c2347     0
    rhs       c2348     0
    rhs       c2349     0
    rhs       c2350     0
    rhs       c2351     0
    rhs       c2352     0
    rhs       c2353     0
    rhs       c2354     0
    rhs       c2355     0
    rhs       c2356     0
    rhs       c2357     0
    rhs       c2358     0
    rhs       c2359     0
    rhs       c2360     0
    rhs       c2361     0
    rhs       c2362     0
    rhs       c2363     0
    rhs       c2364     0
    rhs       c2365     0
    rhs       c2366     0
    rhs       c2367     0
    rhs       c2368     0
    rhs       c2369     0
    rhs       c2370     0
    rhs       c2371     0
    rhs       c2372     0
    rhs       c2373     0
    rhs       c2374     0
    rhs       c2375     0
    rhs       c2376     0
    rhs       c2377     0
    rhs       c2378     0
    rhs       c2379     0
    rhs       c2380     0
    rhs       c2381     0
    rhs       c2382     0
    rhs       c2383     0
    rhs       c2384     0
    rhs       c2385     0
    rhs       c2386     0
    rhs       c2387     0
    rhs       c2388     0
    rhs       c2389     0
    rhs       c2390     0
    rhs       c2391     0
    rhs       c2392     0
    rhs       c2393     0
    rhs       c2394     0
    rhs       c2395     0
    rhs       c2396     0
    rhs       c2397     0
    rhs       c2398     0
    rhs       c2399     0
    rhs       c2400     0
    rhs       c2401     0
    rhs       c2402     0
    rhs       c2403     0
    rhs       c2404     0
    rhs       c2405     0
    rhs       c2406     0
    rhs       c2407     0
    rhs       c2408     0
    rhs       c2409     0
    rhs       c2410     0
    rhs       c2411     0
    rhs       c2412     0
    rhs       c2413     0
    rhs       c2414     0
    rhs       c2415     0
    rhs       c2416     0
    rhs       c2417     0
    rhs       c2418     0
    rhs       c2419     0
    rhs       c2420     0
    rhs       c2421     0
    rhs       c2422     0
    rhs       c2423     0
    rhs       c2424     0
    rhs       c2425     0
    rhs       c2426     0
    rhs       c2427     0
    rhs       c2428     0
    rhs       c2429     0
    rhs       c2430     0
    rhs       c2431     0
    rhs       c2432     0
    rhs       c2433     0
    rhs       c2434     0
    rhs       c2435     0
    rhs       c2436     0
    rhs       c2437     0
    rhs       c2438     0
    rhs       c2439     0
    rhs       c2440     0
    rhs       c2441     0
    rhs       c2442     0
    rhs       c2443     0
    rhs       c2444     0
    rhs       c2445     0
    rhs       c2446     0
    rhs       c2447     0
    rhs       c2448     0
    rhs       c2449     0
    rhs       c2450     0
    rhs       c2451     0
    rhs       c2452     0
    rhs       c2453     0
    rhs       c2454     0
    rhs       c2455     0
    rhs       c2456     0
    rhs       c2457     0
    rhs       c2458     0
    rhs       c2459     0
    rhs       c2460     0
    rhs       c2461     0
    rhs       c2462     0
    rhs       c2463     0
    rhs       c2464     0
    rhs       c2465     0
    rhs       c2466     0
    rhs       c2467     0
    rhs       c2468     0
    rhs       c2469     0
    rhs       c2470     0
    rhs       c2471     0
    rhs       c2472     0
    rhs       c2473     0
    rhs       c2474     0
    rhs       c2475     0
    rhs       c2476     0
    rhs       c2477     0
    rhs       c2478     0
    rhs       c2479     0
    rhs       c2480     0
    rhs       c2481     0
    rhs       c2482     0
    rhs       c2483     0
    rhs       c2484     0
    rhs       c2485     0
    rhs       c2486     0
    rhs       c2487     0
    rhs       c2488     0
    rhs       c2489     0
    rhs       c2490     0
    rhs       c2491     0
    rhs       c2492     0
    rhs       c2493     0
    rhs       c2494     0
    rhs       c2495     0
    rhs       c2496     0
    rhs       c2497     0
    rhs       c2498     0
    rhs       c2499     0
    rhs       c2500     0
    rhs       c2501     0
    rhs       c2502     0
    rhs       c2503     0
    rhs       c2504     0
    rhs       c2505     0
    rhs       c2506     0
    rhs       c2507     0
    rhs       c2508     0
    rhs       c2509     0
    rhs       c2510     0
    rhs       c2511     0
    rhs       c2512     0
    rhs       c2513     0
    rhs       c2514     0
    rhs       c2515     0
    rhs       c2516     0
    rhs       c2517     0
    rhs       c2518     0
    rhs       c2519     0
    rhs       c2520     0
    rhs       c2521     0
    rhs       c2522     0
    rhs       c2523     0
    rhs       c2524     0
    rhs       c2525     0
    rhs       c2526     0
    rhs       c2527     0
    rhs       c2528     0
    rhs       c2529     0
    rhs       c2530     0
    rhs       c2531     0
    rhs       c2532     0
    rhs       c2533     0
    rhs       c2534     0
    rhs       c2535     0
    rhs       c2536     0
    rhs       c2537     0
    rhs       c2538     0
    rhs       c2539     0
    rhs       c2540     0
    rhs       c2541     0
    rhs       c2542     0
    rhs       c2543     0
    rhs       c2544     0
    rhs       c2545     0
    rhs       c2546     0
    rhs       c2547     0
    rhs       c2548     0
    rhs       c2549     0
    rhs       c2550     0
    rhs       c2551     0
    rhs       c2552     0
    rhs       c2553     0
    rhs       c2554     0
    rhs       c2555     0
    rhs       c2556     0
    rhs       c2557     0
    rhs       c2558     0
    rhs       c2559     0
    rhs       c2560     0
    rhs       c2561     0
    rhs       c2562     0
    rhs       c2563     0
    rhs       c2564     0
    rhs       c2565     0
    rhs       c2566     0
    rhs       c2567     0
    rhs       c2568     0
    rhs       c2569     0
    rhs       c2570     0
    rhs       c2571     0
    rhs       c2572     0
    rhs       c2573     0
    rhs       c2574     0
    rhs       c2575     0
    rhs       c2576     0
    rhs       c2577     0
    rhs       c2578     0
    rhs       c2579     0
    rhs       c2580     0
    rhs       c2581     0
    rhs       c2582     0
    rhs       c2583     0
    rhs       c2584     0
    rhs       c2585     0
    rhs       c2586     0
    rhs       c2587     0
    rhs       c2588     0
    rhs       c2589     0
    rhs       c2590     0
    rhs       c2591     0
    rhs       c2592     0
    rhs       c2593     0
    rhs       c2594     0
    rhs       c2595     0
    rhs       c2596     0
    rhs       c2597     0
    rhs       c2598     0
    rhs       c2599     0
    rhs       c2600     0
    rhs       c2601     0
    rhs       c2602     0
    rhs       c2603     0
    rhs       c2604     0
    rhs       c2605     0
    rhs       c2606     0
    rhs       c2607     0
    rhs       c2608     0
    rhs       c2609     0
    rhs       c2610     0
    rhs       c2611     0
    rhs       c2612     0
    rhs       c2613     0
    rhs       c2614     0
    rhs       c2615     0
    rhs       c2616     0
    rhs       c2617     0
    rhs       c2618     0
    rhs       c2619     0
    rhs       c2620     0
    rhs       c2621     0
    rhs       c2622     0
    rhs       c2623     0
    rhs       c2624     0
    rhs       c2625     0
    rhs       c2626     0
    rhs       c2627     0
    rhs       c2628     0
    rhs       c2629     0
    rhs       c2630     0
    rhs       c2631     0
    rhs       c2632     0
    rhs       c2633     0
    rhs       c2634     0
    rhs       c2635     0
    rhs       c2636     0
    rhs       c2637     0
    rhs       c2638     0
    rhs       c2639     0
    rhs       c2640     0
    rhs       c2641     0
    rhs       c2642     0
    rhs       c2643     0
    rhs       c2644     0
    rhs       c2645     0
    rhs       c2646     0
    rhs       c2647     0
    rhs       c2648     0
    rhs       c2649     0
    rhs       c2650     0
    rhs       c2651     0
    rhs       c2652     0
    rhs       c2653     0
    rhs       c2654     0
    rhs       c2655     0
    rhs       c2656     0
    rhs       c2657     0
    rhs       c2658     0
    rhs       c2659     0
    rhs       c2660     0
    rhs       c2661     0
    rhs       c2662     0
    rhs       c2663     0
    rhs       c2664     0
    rhs       c2665     0
    rhs       c2666     0
    rhs       c2667     0
    rhs       c2668     0
    rhs       c2669     0
    rhs       c2670     0
    rhs       c2671     0
    rhs       c2672     0
    rhs       c2673     0
    rhs       c2674     0
    rhs       c2675     0
    rhs       c2676     0
    rhs       c2677     0
    rhs       c2678     0
    rhs       c2679     0
    rhs       c2680     0
    rhs       c2681     0
    rhs       c2682     0
    rhs       c2683     0
    rhs       c2684     0
    rhs       c2685     0
    rhs       c2686     0
    rhs       c2687     0
    rhs       c2688     0
    rhs       c2689     0
    rhs       c2690     0
    rhs       c2691     0
    rhs       c2692     0
    rhs       c2693     0
    rhs       c2694     0
    rhs       c2695     0
    rhs       c2696     0
    rhs       c2697     0
    rhs       c2698     0
    rhs       c2699     0
    rhs       c2700     0
    rhs       c2701     0
    rhs       c2702     0
    rhs       c2703     0
    rhs       c2704     0
    rhs       c2705     0
    rhs       c2706     0
    rhs       c2707     0
    rhs       c2708     0
    rhs       c2709     0
    rhs       c2710     0
    rhs       c2711     0
    rhs       c2712     0
    rhs       c2713     0
    rhs       c2714     0
    rhs       c2715     0
    rhs       c2716     0
    rhs       c2717     0
    rhs       c2718     0
    rhs       c2719     0
    rhs       c2720     0
    rhs       c2721     0
    rhs       c2722     0
    rhs       c2723     0
    rhs       c2724     0
    rhs       c2725     0
    rhs       c2726     0
    rhs       c2727     0
    rhs       c2728     0
    rhs       c2729     0
    rhs       c2730     0
    rhs       c2731     0
    rhs       c2732     0
    rhs       c2733     0
    rhs       c2734     0
    rhs       c2735     0
    rhs       c2736     0
    rhs       c2737     0
    rhs       c2738     0
    rhs       c2739     0
    rhs       c2740     0
    rhs       c2741     0
    rhs       c2742     0
    rhs       c2743     0
    rhs       c2744     0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      262689
 FX bounds    x[2]      0
 FX bounds    x[3]      0
 FX bounds    x[4]      0
 FX bounds    x[5]      0
 FX bounds    x[6]      0
 FX bounds    x[7]      0
 FX bounds    x[8]      0
 FX bounds    x[9]      0
 FX bounds    x[10]     0
 FX bounds    x[11]     0
 FX bounds    x[12]     0
 FX bounds    x[13]     0
 FX bounds    x[14]     0
 FX bounds    x[15]     0
 FX bounds    x[16]     0
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 BV bounds    x[75]
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 BV bounds    x[80]
 BV bounds    x[81]
 BV bounds    x[82]
 BV bounds    x[83]
 FX bounds    x[84]     0
 FX bounds    x[85]     0
 FX bounds    x[86]     0
 FX bounds    x[87]     0
 FX bounds    x[88]     0
 FX bounds    x[89]     0
 FX bounds    x[90]     0
 FX bounds    x[91]     0
 FX bounds    x[92]     0
 FX bounds    x[93]     0
 FX bounds    x[94]     0
 FX bounds    x[95]     0
 FX bounds    x[96]     0
 FX bounds    x[97]     0
 FX bounds    x[98]     0
 FX bounds    x[99]     0
 BV bounds    x[100]
 BV bounds    x[101]
 BV bounds    x[102]
 BV bounds    x[103]
 BV bounds    x[104]
 BV bounds    x[105]
 BV bounds    x[106]
 BV bounds    x[107]
 BV bounds    x[108]
 BV bounds    x[109]
 BV bounds    x[110]
 BV bounds    x[111]
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 BV bounds    x[119]
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 BV bounds    x[127]
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 BV bounds    x[135]
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 FX bounds    x[166]    0
 FX bounds    x[167]    0
 FX bounds    x[168]    0
 FX bounds    x[169]    0
 FX bounds    x[170]    0
 FX bounds    x[171]    0
 FX bounds    x[172]    0
 FX bounds    x[173]    0
 FX bounds    x[174]    0
 FX bounds    x[175]    0
 FX bounds    x[176]    0
 FX bounds    x[177]    0
 FX bounds    x[178]    0
 FX bounds    x[179]    0
 FX bounds    x[180]    0
 FX bounds    x[181]    0
 FX bounds    x[182]    0
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 BV bounds    x[188]
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 BV bounds    x[198]
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 FX bounds    x[248]    0
 FX bounds    x[249]    0
 FX bounds    x[250]    0
 FX bounds    x[251]    0
 FX bounds    x[252]    0
 FX bounds    x[253]    0
 FX bounds    x[254]    0
 FX bounds    x[255]    0
 FX bounds    x[256]    0
 FX bounds    x[257]    0
 FX bounds    x[258]    0
 FX bounds    x[259]    0
 FX bounds    x[260]    0
 FX bounds    x[261]    0
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 BV bounds    x[272]
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 BV bounds    x[284]
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 FX bounds    x[330]    0
 FX bounds    x[331]    0
 FX bounds    x[332]    0
 FX bounds    x[333]    0
 FX bounds    x[334]    0
 FX bounds    x[335]    0
 FX bounds    x[336]    0
 FX bounds    x[337]    0
 FX bounds    x[338]    0
 FX bounds    x[339]    0
 FX bounds    x[340]    0
 FX bounds    x[341]    0
 FX bounds    x[342]    0
 FX bounds    x[343]    0
 FX bounds    x[344]    0
 FX bounds    x[345]    0
 FX bounds    x[346]    0
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 BV bounds    x[369]
 BV bounds    x[370]
 BV bounds    x[371]
 BV bounds    x[372]
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 BV bounds    x[411]
 FX bounds    x[412]    0
 FX bounds    x[413]    0
 FX bounds    x[414]    0
 FX bounds    x[415]    0
 FX bounds    x[416]    0
 FX bounds    x[417]    0
 FX bounds    x[418]    0
 FX bounds    x[419]    0
 FX bounds    x[420]    0
 FX bounds    x[421]    0
 FX bounds    x[422]    0
 FX bounds    x[423]    0
 FX bounds    x[424]    0
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 BV bounds    x[457]
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 BV bounds    x[461]
 BV bounds    x[462]
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 BV bounds    x[467]
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 FX bounds    x[494]    0
 FX bounds    x[495]    0
 FX bounds    x[496]    0
 FX bounds    x[497]    0
 FX bounds    x[498]    0
 FX bounds    x[499]    0
 FX bounds    x[500]    0
 FX bounds    x[501]    0
 FX bounds    x[502]    0
 FX bounds    x[503]    0
 FX bounds    x[504]    0
 FX bounds    x[505]    0
 FX bounds    x[506]    0
 FX bounds    x[507]    0
 FX bounds    x[508]    0
 FX bounds    x[509]    0
 FX bounds    x[510]    0
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 BV bounds    x[552]
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 FX bounds    x[576]    0
 FX bounds    x[577]    0
 FX bounds    x[578]    0
 FX bounds    x[579]    0
 FX bounds    x[580]    0
 FX bounds    x[581]    0
 FX bounds    x[582]    0
 FX bounds    x[583]    0
 FX bounds    x[584]    0
 FX bounds    x[585]    0
 FX bounds    x[586]    0
 FX bounds    x[587]    0
 FX bounds    x[588]    0
 FX bounds    x[589]    0
 FX bounds    x[590]    0
 FX bounds    x[591]    0
 FX bounds    x[592]    0
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 BV bounds    x[640]
 BV bounds    x[641]
 BV bounds    x[642]
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 FX bounds    x[658]    0
 FX bounds    x[659]    0
 FX bounds    x[660]    0
 FX bounds    x[661]    0
 FX bounds    x[662]    0
 FX bounds    x[663]    0
 FX bounds    x[664]    0
 FX bounds    x[665]    0
 FX bounds    x[666]    0
 FX bounds    x[667]    0
 FX bounds    x[668]    0
 FX bounds    x[669]    0
 FX bounds    x[670]    0
 FX bounds    x[671]    0
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 BV bounds    x[712]
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 BV bounds    x[722]
 BV bounds    x[723]
 BV bounds    x[724]
 BV bounds    x[725]
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 BV bounds    x[736]
 BV bounds    x[737]
 BV bounds    x[738]
 BV bounds    x[739]
 FX bounds    x[740]    0
 FX bounds    x[741]    0
 FX bounds    x[742]    0
 FX bounds    x[743]    0
 FX bounds    x[744]    0
 FX bounds    x[745]    0
 FX bounds    x[746]    0
 FX bounds    x[747]    0
 FX bounds    x[748]    0
 FX bounds    x[749]    0
 FX bounds    x[750]    0
 FX bounds    x[751]    0
 FX bounds    x[752]    0
 FX bounds    x[753]    0
 FX bounds    x[754]    0
 FX bounds    x[755]    0
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 BV bounds    x[816]
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 FX bounds    x[822]    0
 FX bounds    x[823]    0
 FX bounds    x[824]    0
 FX bounds    x[825]    0
 FX bounds    x[826]    0
 FX bounds    x[827]    0
 FX bounds    x[828]    0
 FX bounds    x[829]    0
 FX bounds    x[830]    0
 FX bounds    x[831]    0
 FX bounds    x[832]    0
 FX bounds    x[833]    0
 FX bounds    x[834]    0
 FX bounds    x[835]    0
 FX bounds    x[836]    0
 FX bounds    x[837]    0
 FX bounds    x[838]    0
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 FX bounds    x[904]    0
 FX bounds    x[905]    0
 FX bounds    x[906]    0
 FX bounds    x[907]    0
 FX bounds    x[908]    0
 FX bounds    x[909]    0
 FX bounds    x[910]    0
 FX bounds    x[911]    0
 FX bounds    x[912]    0
 FX bounds    x[913]    0
 FX bounds    x[914]    0
 FX bounds    x[915]    0
 FX bounds    x[916]    0
 FX bounds    x[917]    0
 BV bounds    x[918]
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 FX bounds    x[986]    0
 FX bounds    x[987]    0
 FX bounds    x[988]    0
 FX bounds    x[989]    0
 FX bounds    x[990]    0
 FX bounds    x[991]    0
 FX bounds    x[992]    0
 FX bounds    x[993]    0
 FX bounds    x[994]    0
 FX bounds    x[995]    0
 FX bounds    x[996]    0
 FX bounds    x[997]    0
 FX bounds    x[998]    0
 FX bounds    x[999]    0
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 BV bounds    x[1003]
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 BV bounds    x[1017]
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 FX bounds    x[1068]   0
 FX bounds    x[1069]   0
 FX bounds    x[1070]   0
 FX bounds    x[1071]   0
 FX bounds    x[1072]   0
 FX bounds    x[1073]   0
 FX bounds    x[1074]   0
 FX bounds    x[1075]   0
 FX bounds    x[1076]   0
 FX bounds    x[1077]   0
 FX bounds    x[1078]   0
 FX bounds    x[1079]   0
 FX bounds    x[1080]   0
 FX bounds    x[1081]   0
 FX bounds    x[1082]   0
 FX bounds    x[1083]   0
 FX bounds    x[1084]   0
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 BV bounds    x[1096]
 BV bounds    x[1097]
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 BV bounds    x[1101]
 BV bounds    x[1102]
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 BV bounds    x[1107]
 BV bounds    x[1108]
 BV bounds    x[1109]
 BV bounds    x[1110]
 BV bounds    x[1111]
 BV bounds    x[1112]
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 FX bounds    x[1150]   0
 FX bounds    x[1151]   0
 FX bounds    x[1152]   0
 FX bounds    x[1153]   0
 FX bounds    x[1154]   0
 FX bounds    x[1155]   0
 FX bounds    x[1156]   0
 FX bounds    x[1157]   0
 FX bounds    x[1158]   0
 FX bounds    x[1159]   0
 FX bounds    x[1160]   0
 FX bounds    x[1161]   0
 FX bounds    x[1162]   0
 FX bounds    x[1163]   0
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 BV bounds    x[1167]
 BV bounds    x[1168]
 BV bounds    x[1169]
 BV bounds    x[1170]
 BV bounds    x[1171]
 BV bounds    x[1172]
 BV bounds    x[1173]
 BV bounds    x[1174]
 BV bounds    x[1175]
 BV bounds    x[1176]
 BV bounds    x[1177]
 BV bounds    x[1178]
 BV bounds    x[1179]
 BV bounds    x[1180]
 BV bounds    x[1181]
 BV bounds    x[1182]
 BV bounds    x[1183]
 BV bounds    x[1184]
 BV bounds    x[1185]
 BV bounds    x[1186]
 BV bounds    x[1187]
 BV bounds    x[1188]
 BV bounds    x[1189]
 BV bounds    x[1190]
 BV bounds    x[1191]
 BV bounds    x[1192]
 BV bounds    x[1193]
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 BV bounds    x[1197]
 BV bounds    x[1198]
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 BV bounds    x[1203]
 BV bounds    x[1204]
 BV bounds    x[1205]
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 BV bounds    x[1209]
 BV bounds    x[1210]
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 BV bounds    x[1217]
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 BV bounds    x[1229]
 BV bounds    x[1230]
 BV bounds    x[1231]
 FX bounds    x[1232]   0
 FX bounds    x[1233]   0
 FX bounds    x[1234]   0
 FX bounds    x[1235]   0
 FX bounds    x[1236]   0
 FX bounds    x[1237]   0
 FX bounds    x[1238]   0
 FX bounds    x[1239]   0
 FX bounds    x[1240]   0
 FX bounds    x[1241]   0
 FX bounds    x[1242]   0
 FX bounds    x[1243]   0
 FX bounds    x[1244]   0
 FX bounds    x[1245]   0
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 BV bounds    x[1249]
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 BV bounds    x[1260]
 BV bounds    x[1261]
 BV bounds    x[1262]
 BV bounds    x[1263]
 BV bounds    x[1264]
 BV bounds    x[1265]
 BV bounds    x[1266]
 BV bounds    x[1267]
 BV bounds    x[1268]
 BV bounds    x[1269]
 BV bounds    x[1270]
 BV bounds    x[1271]
 BV bounds    x[1272]
 BV bounds    x[1273]
 BV bounds    x[1274]
 BV bounds    x[1275]
 BV bounds    x[1276]
 BV bounds    x[1277]
 BV bounds    x[1278]
 BV bounds    x[1279]
 BV bounds    x[1280]
 BV bounds    x[1281]
 BV bounds    x[1282]
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 BV bounds    x[1293]
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 BV bounds    x[1311]
 BV bounds    x[1312]
 BV bounds    x[1313]
 FX bounds    x[1314]   0
 FX bounds    x[1315]   0
 FX bounds    x[1316]   0
 FX bounds    x[1317]   0
 FX bounds    x[1318]   0
 FX bounds    x[1319]   0
 FX bounds    x[1320]   0
 FX bounds    x[1321]   0
 FX bounds    x[1322]   0
 FX bounds    x[1323]   0
 FX bounds    x[1324]   0
 FX bounds    x[1325]   0
 FX bounds    x[1326]   0
 FX bounds    x[1327]   0
 FX bounds    x[1328]   0
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 BV bounds    x[1336]
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 BV bounds    x[1341]
 BV bounds    x[1342]
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 BV bounds    x[1353]
 BV bounds    x[1354]
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 BV bounds    x[1359]
 BV bounds    x[1360]
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 BV bounds    x[1364]
 BV bounds    x[1365]
 BV bounds    x[1366]
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 FX bounds    x[1396]   0
 FX bounds    x[1397]   0
 FX bounds    x[1398]   0
 FX bounds    x[1399]   0
 FX bounds    x[1400]   0
 FX bounds    x[1401]   0
 FX bounds    x[1402]   0
 FX bounds    x[1403]   0
 FX bounds    x[1404]   0
 FX bounds    x[1405]   0
 FX bounds    x[1406]   0
 FX bounds    x[1407]   0
 FX bounds    x[1408]   0
 FX bounds    x[1409]   0
 FX bounds    x[1410]   0
 FX bounds    x[1411]   0
 FX bounds    x[1412]   0
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 BV bounds    x[1442]
 BV bounds    x[1443]
 BV bounds    x[1444]
 BV bounds    x[1445]
 BV bounds    x[1446]
 BV bounds    x[1447]
 BV bounds    x[1448]
 BV bounds    x[1449]
 BV bounds    x[1450]
 BV bounds    x[1451]
 BV bounds    x[1452]
 BV bounds    x[1453]
 BV bounds    x[1454]
 BV bounds    x[1455]
 BV bounds    x[1456]
 BV bounds    x[1457]
 BV bounds    x[1458]
 BV bounds    x[1459]
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 FX bounds    x[1478]   0
 FX bounds    x[1479]   0
 FX bounds    x[1480]   0
 FX bounds    x[1481]   0
 FX bounds    x[1482]   0
 FX bounds    x[1483]   0
 FX bounds    x[1484]   0
 FX bounds    x[1485]   0
 FX bounds    x[1486]   0
 FX bounds    x[1487]   0
 FX bounds    x[1488]   0
 FX bounds    x[1489]   0
 FX bounds    x[1490]   0
 FX bounds    x[1491]   0
 FX bounds    x[1492]   0
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 BV bounds    x[1515]
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 BV bounds    x[1521]
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 BV bounds    x[1527]
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 BV bounds    x[1532]
 BV bounds    x[1533]
 BV bounds    x[1534]
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 BV bounds    x[1539]
 BV bounds    x[1540]
 BV bounds    x[1541]
 BV bounds    x[1542]
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 BV bounds    x[1550]
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 FX bounds    x[1560]   0
 FX bounds    x[1561]   0
 FX bounds    x[1562]   0
 FX bounds    x[1563]   0
 FX bounds    x[1564]   0
 FX bounds    x[1565]   0
 FX bounds    x[1566]   0
 FX bounds    x[1567]   0
 FX bounds    x[1568]   0
 FX bounds    x[1569]   0
 FX bounds    x[1570]   0
 FX bounds    x[1571]   0
 FX bounds    x[1572]   0
 FX bounds    x[1573]   0
 FX bounds    x[1574]   0
 FX bounds    x[1575]   0
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 BV bounds    x[1580]
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 BV bounds    x[1586]
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 BV bounds    x[1592]
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 BV bounds    x[1599]
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 BV bounds    x[1605]
 BV bounds    x[1606]
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 BV bounds    x[1611]
 BV bounds    x[1612]
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 BV bounds    x[1616]
 BV bounds    x[1617]
 BV bounds    x[1618]
 BV bounds    x[1619]
 BV bounds    x[1620]
 BV bounds    x[1621]
 BV bounds    x[1622]
 BV bounds    x[1623]
 BV bounds    x[1624]
 BV bounds    x[1625]
 BV bounds    x[1626]
 BV bounds    x[1627]
 BV bounds    x[1628]
 BV bounds    x[1629]
 BV bounds    x[1630]
 BV bounds    x[1631]
 BV bounds    x[1632]
 BV bounds    x[1633]
 BV bounds    x[1634]
 BV bounds    x[1635]
 BV bounds    x[1636]
 BV bounds    x[1637]
 BV bounds    x[1638]
 BV bounds    x[1639]
 BV bounds    x[1640]
 BV bounds    x[1641]
 FX bounds    x[1642]   0
 FX bounds    x[1643]   0
 FX bounds    x[1644]   0
 FX bounds    x[1645]   0
 FX bounds    x[1646]   0
 FX bounds    x[1647]   0
 FX bounds    x[1648]   0
 FX bounds    x[1649]   0
 FX bounds    x[1650]   0
 FX bounds    x[1651]   0
 FX bounds    x[1652]   0
 FX bounds    x[1653]   0
 FX bounds    x[1654]   0
 FX bounds    x[1655]   0
 FX bounds    x[1656]   0
 BV bounds    x[1657]
 BV bounds    x[1658]
 BV bounds    x[1659]
 BV bounds    x[1660]
 BV bounds    x[1661]
 BV bounds    x[1662]
 BV bounds    x[1663]
 BV bounds    x[1664]
 BV bounds    x[1665]
 BV bounds    x[1666]
 BV bounds    x[1667]
 BV bounds    x[1668]
 BV bounds    x[1669]
 BV bounds    x[1670]
 BV bounds    x[1671]
 BV bounds    x[1672]
 BV bounds    x[1673]
 BV bounds    x[1674]
 BV bounds    x[1675]
 BV bounds    x[1676]
 BV bounds    x[1677]
 BV bounds    x[1678]
 BV bounds    x[1679]
 BV bounds    x[1680]
 BV bounds    x[1681]
 BV bounds    x[1682]
 BV bounds    x[1683]
 BV bounds    x[1684]
 BV bounds    x[1685]
 BV bounds    x[1686]
 BV bounds    x[1687]
 BV bounds    x[1688]
 BV bounds    x[1689]
 BV bounds    x[1690]
 BV bounds    x[1691]
 BV bounds    x[1692]
 BV bounds    x[1693]
 BV bounds    x[1694]
 BV bounds    x[1695]
 BV bounds    x[1696]
 BV bounds    x[1697]
 BV bounds    x[1698]
 BV bounds    x[1699]
 BV bounds    x[1700]
 BV bounds    x[1701]
 BV bounds    x[1702]
 BV bounds    x[1703]
 BV bounds    x[1704]
 BV bounds    x[1705]
 BV bounds    x[1706]
 BV bounds    x[1707]
 BV bounds    x[1708]
 BV bounds    x[1709]
 BV bounds    x[1710]
 BV bounds    x[1711]
 BV bounds    x[1712]
 BV bounds    x[1713]
 BV bounds    x[1714]
 BV bounds    x[1715]
 BV bounds    x[1716]
 BV bounds    x[1717]
 BV bounds    x[1718]
 BV bounds    x[1719]
 BV bounds    x[1720]
 BV bounds    x[1721]
 BV bounds    x[1722]
 BV bounds    x[1723]
 FX bounds    x[1724]   0
 FX bounds    x[1725]   0
 FX bounds    x[1726]   0
 FX bounds    x[1727]   0
 FX bounds    x[1728]   0
 FX bounds    x[1729]   0
 FX bounds    x[1730]   0
 FX bounds    x[1731]   0
 FX bounds    x[1732]   0
 FX bounds    x[1733]   0
 FX bounds    x[1734]   0
 FX bounds    x[1735]   0
 FX bounds    x[1736]   0
 FX bounds    x[1737]   0
 BV bounds    x[1738]
 BV bounds    x[1739]
 BV bounds    x[1740]
 BV bounds    x[1741]
 BV bounds    x[1742]
 BV bounds    x[1743]
 BV bounds    x[1744]
 BV bounds    x[1745]
 BV bounds    x[1746]
 BV bounds    x[1747]
 BV bounds    x[1748]
 BV bounds    x[1749]
 BV bounds    x[1750]
 BV bounds    x[1751]
 BV bounds    x[1752]
 BV bounds    x[1753]
 BV bounds    x[1754]
 BV bounds    x[1755]
 BV bounds    x[1756]
 BV bounds    x[1757]
 BV bounds    x[1758]
 BV bounds    x[1759]
 BV bounds    x[1760]
 BV bounds    x[1761]
 BV bounds    x[1762]
 BV bounds    x[1763]
 BV bounds    x[1764]
 BV bounds    x[1765]
 BV bounds    x[1766]
 BV bounds    x[1767]
 BV bounds    x[1768]
 BV bounds    x[1769]
 BV bounds    x[1770]
 BV bounds    x[1771]
 BV bounds    x[1772]
 BV bounds    x[1773]
 BV bounds    x[1774]
 BV bounds    x[1775]
 BV bounds    x[1776]
 BV bounds    x[1777]
 BV bounds    x[1778]
 BV bounds    x[1779]
 BV bounds    x[1780]
 BV bounds    x[1781]
 BV bounds    x[1782]
 BV bounds    x[1783]
 BV bounds    x[1784]
 BV bounds    x[1785]
 BV bounds    x[1786]
 BV bounds    x[1787]
 BV bounds    x[1788]
 BV bounds    x[1789]
 BV bounds    x[1790]
 BV bounds    x[1791]
 BV bounds    x[1792]
 BV bounds    x[1793]
 BV bounds    x[1794]
 BV bounds    x[1795]
 BV bounds    x[1796]
 BV bounds    x[1797]
 BV bounds    x[1798]
 BV bounds    x[1799]
 BV bounds    x[1800]
 BV bounds    x[1801]
 BV bounds    x[1802]
 BV bounds    x[1803]
 BV bounds    x[1804]
 BV bounds    x[1805]
 FX bounds    x[1806]   0
 FX bounds    x[1807]   0
 FX bounds    x[1808]   0
 FX bounds    x[1809]   0
 FX bounds    x[1810]   0
 FX bounds    x[1811]   0
 FX bounds    x[1812]   0
 FX bounds    x[1813]   0
 FX bounds    x[1814]   0
 FX bounds    x[1815]   0
 FX bounds    x[1816]   0
 FX bounds    x[1817]   0
 FX bounds    x[1818]   0
 FX bounds    x[1819]   0
 FX bounds    x[1820]   0
 BV bounds    x[1821]
 BV bounds    x[1822]
 BV bounds    x[1823]
 BV bounds    x[1824]
 BV bounds    x[1825]
 BV bounds    x[1826]
 BV bounds    x[1827]
 BV bounds    x[1828]
 BV bounds    x[1829]
 BV bounds    x[1830]
 BV bounds    x[1831]
 BV bounds    x[1832]
 BV bounds    x[1833]
 BV bounds    x[1834]
 BV bounds    x[1835]
 BV bounds    x[1836]
 BV bounds    x[1837]
 BV bounds    x[1838]
 BV bounds    x[1839]
 BV bounds    x[1840]
 BV bounds    x[1841]
 BV bounds    x[1842]
 BV bounds    x[1843]
 BV bounds    x[1844]
 BV bounds    x[1845]
 BV bounds    x[1846]
 BV bounds    x[1847]
 BV bounds    x[1848]
 BV bounds    x[1849]
 BV bounds    x[1850]
 BV bounds    x[1851]
 BV bounds    x[1852]
 BV bounds    x[1853]
 BV bounds    x[1854]
 BV bounds    x[1855]
 BV bounds    x[1856]
 BV bounds    x[1857]
 BV bounds    x[1858]
 BV bounds    x[1859]
 BV bounds    x[1860]
 BV bounds    x[1861]
 BV bounds    x[1862]
 BV bounds    x[1863]
 BV bounds    x[1864]
 BV bounds    x[1865]
 BV bounds    x[1866]
 BV bounds    x[1867]
 BV bounds    x[1868]
 BV bounds    x[1869]
 BV bounds    x[1870]
 BV bounds    x[1871]
 BV bounds    x[1872]
 BV bounds    x[1873]
 BV bounds    x[1874]
 BV bounds    x[1875]
 BV bounds    x[1876]
 BV bounds    x[1877]
 BV bounds    x[1878]
 BV bounds    x[1879]
 BV bounds    x[1880]
 BV bounds    x[1881]
 BV bounds    x[1882]
 BV bounds    x[1883]
 BV bounds    x[1884]
 BV bounds    x[1885]
 BV bounds    x[1886]
 BV bounds    x[1887]
 FX bounds    x[1888]   0
 FX bounds    x[1889]   0
 FX bounds    x[1890]   0
 FX bounds    x[1891]   0
 FX bounds    x[1892]   0
 FX bounds    x[1893]   0
 FX bounds    x[1894]   0
 FX bounds    x[1895]   0
 FX bounds    x[1896]   0
 FX bounds    x[1897]   0
 FX bounds    x[1898]   0
 FX bounds    x[1899]   0
 FX bounds    x[1900]   0
 FX bounds    x[1901]   0
 FX bounds    x[1902]   0
 FX bounds    x[1903]   0
 FX bounds    x[1904]   0
 BV bounds    x[1905]
 BV bounds    x[1906]
 BV bounds    x[1907]
 BV bounds    x[1908]
 BV bounds    x[1909]
 BV bounds    x[1910]
 BV bounds    x[1911]
 BV bounds    x[1912]
 BV bounds    x[1913]
 BV bounds    x[1914]
 BV bounds    x[1915]
 BV bounds    x[1916]
 BV bounds    x[1917]
 BV bounds    x[1918]
 BV bounds    x[1919]
 BV bounds    x[1920]
 BV bounds    x[1921]
 BV bounds    x[1922]
 BV bounds    x[1923]
 BV bounds    x[1924]
 BV bounds    x[1925]
 BV bounds    x[1926]
 BV bounds    x[1927]
 BV bounds    x[1928]
 BV bounds    x[1929]
 BV bounds    x[1930]
 BV bounds    x[1931]
 BV bounds    x[1932]
 BV bounds    x[1933]
 BV bounds    x[1934]
 BV bounds    x[1935]
 BV bounds    x[1936]
 BV bounds    x[1937]
 BV bounds    x[1938]
 BV bounds    x[1939]
 BV bounds    x[1940]
 BV bounds    x[1941]
 BV bounds    x[1942]
 BV bounds    x[1943]
 BV bounds    x[1944]
 BV bounds    x[1945]
 BV bounds    x[1946]
 BV bounds    x[1947]
 BV bounds    x[1948]
 BV bounds    x[1949]
 BV bounds    x[1950]
 BV bounds    x[1951]
 BV bounds    x[1952]
 BV bounds    x[1953]
 BV bounds    x[1954]
 BV bounds    x[1955]
 BV bounds    x[1956]
 BV bounds    x[1957]
 BV bounds    x[1958]
 BV bounds    x[1959]
 BV bounds    x[1960]
 BV bounds    x[1961]
 BV bounds    x[1962]
 BV bounds    x[1963]
 BV bounds    x[1964]
 BV bounds    x[1965]
 BV bounds    x[1966]
 BV bounds    x[1967]
 BV bounds    x[1968]
 BV bounds    x[1969]
 FX bounds    x[1970]   0
 FX bounds    x[1971]   0
 FX bounds    x[1972]   0
 FX bounds    x[1973]   0
 FX bounds    x[1974]   0
 FX bounds    x[1975]   0
 FX bounds    x[1976]   0
 FX bounds    x[1977]   0
 FX bounds    x[1978]   0
 FX bounds    x[1979]   0
 FX bounds    x[1980]   0
 FX bounds    x[1981]   0
 FX bounds    x[1982]   0
 FX bounds    x[1983]   0
 FX bounds    x[1984]   0
 FX bounds    x[1985]   0
 BV bounds    x[1986]
 BV bounds    x[1987]
 BV bounds    x[1988]
 BV bounds    x[1989]
 BV bounds    x[1990]
 BV bounds    x[1991]
 BV bounds    x[1992]
 BV bounds    x[1993]
 BV bounds    x[1994]
 BV bounds    x[1995]
 BV bounds    x[1996]
 BV bounds    x[1997]
 BV bounds    x[1998]
 BV bounds    x[1999]
 BV bounds    x[2000]
 BV bounds    x[2001]
 BV bounds    x[2002]
 BV bounds    x[2003]
 BV bounds    x[2004]
 BV bounds    x[2005]
 BV bounds    x[2006]
 BV bounds    x[2007]
 BV bounds    x[2008]
 BV bounds    x[2009]
 BV bounds    x[2010]
 BV bounds    x[2011]
 BV bounds    x[2012]
 BV bounds    x[2013]
 BV bounds    x[2014]
 BV bounds    x[2015]
 BV bounds    x[2016]
 BV bounds    x[2017]
 BV bounds    x[2018]
 BV bounds    x[2019]
 BV bounds    x[2020]
 BV bounds    x[2021]
 BV bounds    x[2022]
 BV bounds    x[2023]
 BV bounds    x[2024]
 BV bounds    x[2025]
 BV bounds    x[2026]
 BV bounds    x[2027]
 BV bounds    x[2028]
 BV bounds    x[2029]
 BV bounds    x[2030]
 BV bounds    x[2031]
 BV bounds    x[2032]
 BV bounds    x[2033]
 BV bounds    x[2034]
 BV bounds    x[2035]
 BV bounds    x[2036]
 BV bounds    x[2037]
 BV bounds    x[2038]
 BV bounds    x[2039]
 BV bounds    x[2040]
 BV bounds    x[2041]
 BV bounds    x[2042]
 BV bounds    x[2043]
 BV bounds    x[2044]
 BV bounds    x[2045]
 BV bounds    x[2046]
 BV bounds    x[2047]
 BV bounds    x[2048]
 BV bounds    x[2049]
 BV bounds    x[2050]
 BV bounds    x[2051]
 FX bounds    x[2052]   0
 FX bounds    x[2053]   0
 FX bounds    x[2054]   0
 FX bounds    x[2055]   0
 FX bounds    x[2056]   0
 FX bounds    x[2057]   0
 FX bounds    x[2058]   0
 FX bounds    x[2059]   0
 FX bounds    x[2060]   0
 FX bounds    x[2061]   0
 FX bounds    x[2062]   0
 FX bounds    x[2063]   0
 FX bounds    x[2064]   0
 FX bounds    x[2065]   0
 FX bounds    x[2066]   0
 FX bounds    x[2067]   0
 FX bounds    x[2068]   0
 BV bounds    x[2069]
 BV bounds    x[2070]
 BV bounds    x[2071]
 BV bounds    x[2072]
 BV bounds    x[2073]
 BV bounds    x[2074]
 BV bounds    x[2075]
 BV bounds    x[2076]
 BV bounds    x[2077]
 BV bounds    x[2078]
 BV bounds    x[2079]
 BV bounds    x[2080]
 BV bounds    x[2081]
 BV bounds    x[2082]
 BV bounds    x[2083]
 BV bounds    x[2084]
 BV bounds    x[2085]
 BV bounds    x[2086]
 BV bounds    x[2087]
 BV bounds    x[2088]
 BV bounds    x[2089]
 BV bounds    x[2090]
 BV bounds    x[2091]
 BV bounds    x[2092]
 BV bounds    x[2093]
 BV bounds    x[2094]
 BV bounds    x[2095]
 BV bounds    x[2096]
 BV bounds    x[2097]
 BV bounds    x[2098]
 BV bounds    x[2099]
 BV bounds    x[2100]
 BV bounds    x[2101]
 BV bounds    x[2102]
 BV bounds    x[2103]
 BV bounds    x[2104]
 BV bounds    x[2105]
 BV bounds    x[2106]
 BV bounds    x[2107]
 BV bounds    x[2108]
 BV bounds    x[2109]
 BV bounds    x[2110]
 BV bounds    x[2111]
 BV bounds    x[2112]
 BV bounds    x[2113]
 BV bounds    x[2114]
 BV bounds    x[2115]
 BV bounds    x[2116]
 BV bounds    x[2117]
 BV bounds    x[2118]
 BV bounds    x[2119]
 BV bounds    x[2120]
 BV bounds    x[2121]
 BV bounds    x[2122]
 BV bounds    x[2123]
 BV bounds    x[2124]
 BV bounds    x[2125]
 BV bounds    x[2126]
 BV bounds    x[2127]
 BV bounds    x[2128]
 BV bounds    x[2129]
 BV bounds    x[2130]
 BV bounds    x[2131]
 BV bounds    x[2132]
 BV bounds    x[2133]
 FX bounds    x[2134]   0
 FX bounds    x[2135]   0
 FX bounds    x[2136]   0
 FX bounds    x[2137]   0
 FX bounds    x[2138]   0
 FX bounds    x[2139]   0
 FX bounds    x[2140]   0
 FX bounds    x[2141]   0
 FX bounds    x[2142]   0
 FX bounds    x[2143]   0
 FX bounds    x[2144]   0
 FX bounds    x[2145]   0
 FX bounds    x[2146]   0
 FX bounds    x[2147]   0
 FX bounds    x[2148]   0
 FX bounds    x[2149]   0
 BV bounds    x[2150]
 BV bounds    x[2151]
 BV bounds    x[2152]
 BV bounds    x[2153]
 BV bounds    x[2154]
 BV bounds    x[2155]
 BV bounds    x[2156]
 BV bounds    x[2157]
 BV bounds    x[2158]
 BV bounds    x[2159]
 BV bounds    x[2160]
 BV bounds    x[2161]
 BV bounds    x[2162]
 BV bounds    x[2163]
 BV bounds    x[2164]
 BV bounds    x[2165]
 BV bounds    x[2166]
 BV bounds    x[2167]
 BV bounds    x[2168]
 BV bounds    x[2169]
 BV bounds    x[2170]
 BV bounds    x[2171]
 BV bounds    x[2172]
 BV bounds    x[2173]
 BV bounds    x[2174]
 BV bounds    x[2175]
 BV bounds    x[2176]
 BV bounds    x[2177]
 BV bounds    x[2178]
 BV bounds    x[2179]
 BV bounds    x[2180]
 BV bounds    x[2181]
 BV bounds    x[2182]
 BV bounds    x[2183]
 BV bounds    x[2184]
 BV bounds    x[2185]
 BV bounds    x[2186]
 BV bounds    x[2187]
 BV bounds    x[2188]
 BV bounds    x[2189]
 BV bounds    x[2190]
 BV bounds    x[2191]
 BV bounds    x[2192]
 BV bounds    x[2193]
 BV bounds    x[2194]
 BV bounds    x[2195]
 BV bounds    x[2196]
 BV bounds    x[2197]
 BV bounds    x[2198]
 BV bounds    x[2199]
 BV bounds    x[2200]
 BV bounds    x[2201]
 BV bounds    x[2202]
 BV bounds    x[2203]
 BV bounds    x[2204]
 BV bounds    x[2205]
 BV bounds    x[2206]
 BV bounds    x[2207]
 BV bounds    x[2208]
 BV bounds    x[2209]
 BV bounds    x[2210]
 BV bounds    x[2211]
 BV bounds    x[2212]
 BV bounds    x[2213]
 BV bounds    x[2214]
 BV bounds    x[2215]
 FX bounds    x[2216]   0
 FX bounds    x[2217]   0
 FX bounds    x[2218]   0
 FX bounds    x[2219]   0
 FX bounds    x[2220]   0
 FX bounds    x[2221]   0
 FX bounds    x[2222]   0
 FX bounds    x[2223]   0
 FX bounds    x[2224]   0
 FX bounds    x[2225]   0
 FX bounds    x[2226]   0
 FX bounds    x[2227]   0
 FX bounds    x[2228]   0
 FX bounds    x[2229]   0
 FX bounds    x[2230]   0
 FX bounds    x[2231]   0
 BV bounds    x[2232]
 BV bounds    x[2233]
 BV bounds    x[2234]
 BV bounds    x[2235]
 BV bounds    x[2236]
 BV bounds    x[2237]
 BV bounds    x[2238]
 BV bounds    x[2239]
 BV bounds    x[2240]
 BV bounds    x[2241]
 BV bounds    x[2242]
 BV bounds    x[2243]
 BV bounds    x[2244]
 BV bounds    x[2245]
 BV bounds    x[2246]
 BV bounds    x[2247]
 BV bounds    x[2248]
 BV bounds    x[2249]
 BV bounds    x[2250]
 BV bounds    x[2251]
 BV bounds    x[2252]
 BV bounds    x[2253]
 BV bounds    x[2254]
 BV bounds    x[2255]
 BV bounds    x[2256]
 BV bounds    x[2257]
 BV bounds    x[2258]
 BV bounds    x[2259]
 BV bounds    x[2260]
 BV bounds    x[2261]
 BV bounds    x[2262]
 BV bounds    x[2263]
 BV bounds    x[2264]
 BV bounds    x[2265]
 BV bounds    x[2266]
 BV bounds    x[2267]
 BV bounds    x[2268]
 BV bounds    x[2269]
 BV bounds    x[2270]
 BV bounds    x[2271]
 BV bounds    x[2272]
 BV bounds    x[2273]
 BV bounds    x[2274]
 BV bounds    x[2275]
 BV bounds    x[2276]
 BV bounds    x[2277]
 BV bounds    x[2278]
 BV bounds    x[2279]
 BV bounds    x[2280]
 BV bounds    x[2281]
 BV bounds    x[2282]
 BV bounds    x[2283]
 BV bounds    x[2284]
 BV bounds    x[2285]
 BV bounds    x[2286]
 BV bounds    x[2287]
 BV bounds    x[2288]
 BV bounds    x[2289]
 BV bounds    x[2290]
 BV bounds    x[2291]
 BV bounds    x[2292]
 BV bounds    x[2293]
 BV bounds    x[2294]
 BV bounds    x[2295]
 BV bounds    x[2296]
 BV bounds    x[2297]
 FX bounds    x[2298]   0
 FX bounds    x[2299]   0
 FX bounds    x[2300]   0
 FX bounds    x[2301]   0
 FX bounds    x[2302]   0
 FX bounds    x[2303]   0
 FX bounds    x[2304]   0
 FX bounds    x[2305]   0
 FX bounds    x[2306]   0
 FX bounds    x[2307]   0
 FX bounds    x[2308]   0
 FX bounds    x[2309]   0
 FX bounds    x[2310]   0
 FX bounds    x[2311]   0
 FX bounds    x[2312]   0
 FX bounds    x[2313]   0
 BV bounds    x[2314]
 BV bounds    x[2315]
 BV bounds    x[2316]
 BV bounds    x[2317]
 BV bounds    x[2318]
 BV bounds    x[2319]
 BV bounds    x[2320]
 BV bounds    x[2321]
 BV bounds    x[2322]
 BV bounds    x[2323]
 BV bounds    x[2324]
 BV bounds    x[2325]
 BV bounds    x[2326]
 BV bounds    x[2327]
 BV bounds    x[2328]
 BV bounds    x[2329]
 BV bounds    x[2330]
 BV bounds    x[2331]
 BV bounds    x[2332]
 BV bounds    x[2333]
 BV bounds    x[2334]
 BV bounds    x[2335]
 BV bounds    x[2336]
 BV bounds    x[2337]
 BV bounds    x[2338]
 BV bounds    x[2339]
 BV bounds    x[2340]
 BV bounds    x[2341]
 BV bounds    x[2342]
 BV bounds    x[2343]
 BV bounds    x[2344]
 BV bounds    x[2345]
 BV bounds    x[2346]
 BV bounds    x[2347]
 BV bounds    x[2348]
 BV bounds    x[2349]
 BV bounds    x[2350]
 BV bounds    x[2351]
 BV bounds    x[2352]
 BV bounds    x[2353]
 BV bounds    x[2354]
 BV bounds    x[2355]
 BV bounds    x[2356]
 BV bounds    x[2357]
 BV bounds    x[2358]
 BV bounds    x[2359]
 BV bounds    x[2360]
 BV bounds    x[2361]
 BV bounds    x[2362]
 BV bounds    x[2363]
 BV bounds    x[2364]
 BV bounds    x[2365]
 BV bounds    x[2366]
 BV bounds    x[2367]
 BV bounds    x[2368]
 BV bounds    x[2369]
 BV bounds    x[2370]
 BV bounds    x[2371]
 BV bounds    x[2372]
 BV bounds    x[2373]
 BV bounds    x[2374]
 BV bounds    x[2375]
 BV bounds    x[2376]
 BV bounds    x[2377]
 BV bounds    x[2378]
 BV bounds    x[2379]
 FX bounds    x[2380]   0
 FX bounds    x[2381]   0
 FX bounds    x[2382]   0
 FX bounds    x[2383]   0
 FX bounds    x[2384]   0
 FX bounds    x[2385]   0
 FX bounds    x[2386]   0
 FX bounds    x[2387]   0
 FX bounds    x[2388]   0
 FX bounds    x[2389]   0
 FX bounds    x[2390]   0
 FX bounds    x[2391]   0
 FX bounds    x[2392]   0
 FX bounds    x[2393]   0
 BV bounds    x[2394]
 BV bounds    x[2395]
 BV bounds    x[2396]
 BV bounds    x[2397]
 BV bounds    x[2398]
 BV bounds    x[2399]
 BV bounds    x[2400]
 BV bounds    x[2401]
 BV bounds    x[2402]
 BV bounds    x[2403]
 BV bounds    x[2404]
 BV bounds    x[2405]
 BV bounds    x[2406]
 BV bounds    x[2407]
 BV bounds    x[2408]
 BV bounds    x[2409]
 BV bounds    x[2410]
 BV bounds    x[2411]
 BV bounds    x[2412]
 BV bounds    x[2413]
 BV bounds    x[2414]
 BV bounds    x[2415]
 BV bounds    x[2416]
 BV bounds    x[2417]
 BV bounds    x[2418]
 BV bounds    x[2419]
 BV bounds    x[2420]
 BV bounds    x[2421]
 BV bounds    x[2422]
 BV bounds    x[2423]
 BV bounds    x[2424]
 BV bounds    x[2425]
 BV bounds    x[2426]
 BV bounds    x[2427]
 BV bounds    x[2428]
 BV bounds    x[2429]
 BV bounds    x[2430]
 BV bounds    x[2431]
 BV bounds    x[2432]
 BV bounds    x[2433]
 BV bounds    x[2434]
 BV bounds    x[2435]
 BV bounds    x[2436]
 BV bounds    x[2437]
 BV bounds    x[2438]
 BV bounds    x[2439]
 BV bounds    x[2440]
 BV bounds    x[2441]
 BV bounds    x[2442]
 BV bounds    x[2443]
 BV bounds    x[2444]
 BV bounds    x[2445]
 BV bounds    x[2446]
 BV bounds    x[2447]
 BV bounds    x[2448]
 BV bounds    x[2449]
 BV bounds    x[2450]
 BV bounds    x[2451]
 BV bounds    x[2452]
 BV bounds    x[2453]
 BV bounds    x[2454]
 BV bounds    x[2455]
 BV bounds    x[2456]
 BV bounds    x[2457]
 BV bounds    x[2458]
 BV bounds    x[2459]
 BV bounds    x[2460]
 BV bounds    x[2461]
 FX bounds    x[2462]   0
 FX bounds    x[2463]   0
 FX bounds    x[2464]   0
 FX bounds    x[2465]   0
 FX bounds    x[2466]   0
 FX bounds    x[2467]   0
 FX bounds    x[2468]   0
 FX bounds    x[2469]   0
 FX bounds    x[2470]   0
 FX bounds    x[2471]   0
 FX bounds    x[2472]   0
 FX bounds    x[2473]   0
 FX bounds    x[2474]   0
 FX bounds    x[2475]   0
 BV bounds    x[2476]
 BV bounds    x[2477]
 BV bounds    x[2478]
 BV bounds    x[2479]
 BV bounds    x[2480]
 BV bounds    x[2481]
 BV bounds    x[2482]
 BV bounds    x[2483]
 BV bounds    x[2484]
 BV bounds    x[2485]
 BV bounds    x[2486]
 BV bounds    x[2487]
 BV bounds    x[2488]
 BV bounds    x[2489]
 BV bounds    x[2490]
 BV bounds    x[2491]
 BV bounds    x[2492]
 BV bounds    x[2493]
 BV bounds    x[2494]
 BV bounds    x[2495]
 BV bounds    x[2496]
 BV bounds    x[2497]
 BV bounds    x[2498]
 BV bounds    x[2499]
 BV bounds    x[2500]
 BV bounds    x[2501]
 BV bounds    x[2502]
 BV bounds    x[2503]
 BV bounds    x[2504]
 BV bounds    x[2505]
 BV bounds    x[2506]
 BV bounds    x[2507]
 BV bounds    x[2508]
 BV bounds    x[2509]
 BV bounds    x[2510]
 BV bounds    x[2511]
 BV bounds    x[2512]
 BV bounds    x[2513]
 BV bounds    x[2514]
 BV bounds    x[2515]
 BV bounds    x[2516]
 BV bounds    x[2517]
 BV bounds    x[2518]
 BV bounds    x[2519]
 BV bounds    x[2520]
 BV bounds    x[2521]
 BV bounds    x[2522]
 BV bounds    x[2523]
 BV bounds    x[2524]
 BV bounds    x[2525]
 BV bounds    x[2526]
 BV bounds    x[2527]
 BV bounds    x[2528]
 BV bounds    x[2529]
 BV bounds    x[2530]
 BV bounds    x[2531]
 BV bounds    x[2532]
 BV bounds    x[2533]
 BV bounds    x[2534]
 BV bounds    x[2535]
 BV bounds    x[2536]
 BV bounds    x[2537]
 BV bounds    x[2538]
 BV bounds    x[2539]
 BV bounds    x[2540]
 BV bounds    x[2541]
 BV bounds    x[2542]
 BV bounds    x[2543]
 FX bounds    x[2544]   0
 FX bounds    x[2545]   0
 FX bounds    x[2546]   0
 FX bounds    x[2547]   0
 FX bounds    x[2548]   0
 FX bounds    x[2549]   0
 FX bounds    x[2550]   0
 FX bounds    x[2551]   0
 FX bounds    x[2552]   0
 FX bounds    x[2553]   0
 FX bounds    x[2554]   0
 FX bounds    x[2555]   0
 FX bounds    x[2556]   0
 FX bounds    x[2557]   0
 FX bounds    x[2558]   0
 FX bounds    x[2559]   0
 BV bounds    x[2560]
 BV bounds    x[2561]
 BV bounds    x[2562]
 BV bounds    x[2563]
 BV bounds    x[2564]
 BV bounds    x[2565]
 BV bounds    x[2566]
 BV bounds    x[2567]
 BV bounds    x[2568]
 BV bounds    x[2569]
 BV bounds    x[2570]
 BV bounds    x[2571]
 BV bounds    x[2572]
 BV bounds    x[2573]
 BV bounds    x[2574]
 BV bounds    x[2575]
 BV bounds    x[2576]
 BV bounds    x[2577]
 BV bounds    x[2578]
 BV bounds    x[2579]
 BV bounds    x[2580]
 BV bounds    x[2581]
 BV bounds    x[2582]
 BV bounds    x[2583]
 BV bounds    x[2584]
 BV bounds    x[2585]
 BV bounds    x[2586]
 BV bounds    x[2587]
 BV bounds    x[2588]
 BV bounds    x[2589]
 BV bounds    x[2590]
 BV bounds    x[2591]
 BV bounds    x[2592]
 BV bounds    x[2593]
 BV bounds    x[2594]
 BV bounds    x[2595]
 BV bounds    x[2596]
 BV bounds    x[2597]
 BV bounds    x[2598]
 BV bounds    x[2599]
 BV bounds    x[2600]
 BV bounds    x[2601]
 BV bounds    x[2602]
 BV bounds    x[2603]
 BV bounds    x[2604]
 BV bounds    x[2605]
 BV bounds    x[2606]
 BV bounds    x[2607]
 BV bounds    x[2608]
 BV bounds    x[2609]
 BV bounds    x[2610]
 BV bounds    x[2611]
 BV bounds    x[2612]
 BV bounds    x[2613]
 BV bounds    x[2614]
 BV bounds    x[2615]
 BV bounds    x[2616]
 BV bounds    x[2617]
 BV bounds    x[2618]
 BV bounds    x[2619]
 BV bounds    x[2620]
 BV bounds    x[2621]
 BV bounds    x[2622]
 BV bounds    x[2623]
 BV bounds    x[2624]
 BV bounds    x[2625]
 FX bounds    x[2626]   0
 FX bounds    x[2627]   0
 FX bounds    x[2628]   0
 FX bounds    x[2629]   0
 FX bounds    x[2630]   0
 FX bounds    x[2631]   0
 FX bounds    x[2632]   0
 FX bounds    x[2633]   0
 FX bounds    x[2634]   0
 FX bounds    x[2635]   0
 FX bounds    x[2636]   0
 FX bounds    x[2637]   0
 FX bounds    x[2638]   0
 FX bounds    x[2639]   0
 FX bounds    x[2640]   0
 BV bounds    x[2641]
 BV bounds    x[2642]
 BV bounds    x[2643]
 BV bounds    x[2644]
 BV bounds    x[2645]
 BV bounds    x[2646]
 BV bounds    x[2647]
 BV bounds    x[2648]
 BV bounds    x[2649]
 BV bounds    x[2650]
 BV bounds    x[2651]
 BV bounds    x[2652]
 BV bounds    x[2653]
 BV bounds    x[2654]
 BV bounds    x[2655]
 BV bounds    x[2656]
 BV bounds    x[2657]
 BV bounds    x[2658]
 BV bounds    x[2659]
 BV bounds    x[2660]
 BV bounds    x[2661]
 BV bounds    x[2662]
 BV bounds    x[2663]
 BV bounds    x[2664]
 BV bounds    x[2665]
 BV bounds    x[2666]
 BV bounds    x[2667]
 BV bounds    x[2668]
 BV bounds    x[2669]
 BV bounds    x[2670]
 BV bounds    x[2671]
 BV bounds    x[2672]
 BV bounds    x[2673]
 BV bounds    x[2674]
 BV bounds    x[2675]
 BV bounds    x[2676]
 BV bounds    x[2677]
 BV bounds    x[2678]
 BV bounds    x[2679]
 BV bounds    x[2680]
 BV bounds    x[2681]
 BV bounds    x[2682]
 BV bounds    x[2683]
 BV bounds    x[2684]
 BV bounds    x[2685]
 BV bounds    x[2686]
 BV bounds    x[2687]
 BV bounds    x[2688]
 BV bounds    x[2689]
 BV bounds    x[2690]
 BV bounds    x[2691]
 BV bounds    x[2692]
 BV bounds    x[2693]
 BV bounds    x[2694]
 BV bounds    x[2695]
 BV bounds    x[2696]
 BV bounds    x[2697]
 BV bounds    x[2698]
 BV bounds    x[2699]
 BV bounds    x[2700]
 BV bounds    x[2701]
 BV bounds    x[2702]
 BV bounds    x[2703]
 BV bounds    x[2704]
 BV bounds    x[2705]
 BV bounds    x[2706]
 BV bounds    x[2707]
 BV bounds    x[2708]
 BV bounds    x[2709]
 BV bounds    x[2710]
 BV bounds    x[2711]
 BV bounds    x[2712]
 BV bounds    x[2713]
 FX bounds    x[2714]   1
 LO bounds    x[2715]   0
 UP bounds    x[2715]   102000
 LO bounds    x[2716]   0
 UP bounds    x[2716]   102000
 LO bounds    x[2717]   0
 UP bounds    x[2717]   5748
 BV bounds    x[2718]
 BV bounds    x[2719]
 BV bounds    x[2720]
 BV bounds    x[2721]
 BV bounds    x[2722]
 BV bounds    x[2723]
 FX bounds    x[2724]   1
 LO bounds    x[2725]   0
 UP bounds    x[2725]   102000
 LO bounds    x[2726]   0
 UP bounds    x[2726]   102000
 LO bounds    x[2727]   0
 UP bounds    x[2727]   1224
 BV bounds    x[2728]
 BV bounds    x[2729]
 BV bounds    x[2730]
 BV bounds    x[2731]
 BV bounds    x[2732]
 BV bounds    x[2733]
 FX bounds    x[2734]   1
 LO bounds    x[2735]   0
 UP bounds    x[2735]   102000
 LO bounds    x[2736]   0
 UP bounds    x[2736]   102000
 LO bounds    x[2737]   0
 UP bounds    x[2737]   5820
 BV bounds    x[2738]
 BV bounds    x[2739]
 BV bounds    x[2740]
 BV bounds    x[2741]
 BV bounds    x[2742]
 BV bounds    x[2743]
 FX bounds    x[2744]   1
 LO bounds    x[2745]   0
 UP bounds    x[2745]   102000
 LO bounds    x[2746]   0
 UP bounds    x[2746]   102000
 LO bounds    x[2747]   0
 UP bounds    x[2747]   4020
 BV bounds    x[2748]
 BV bounds    x[2749]
 BV bounds    x[2750]
 BV bounds    x[2751]
 BV bounds    x[2752]
 BV bounds    x[2753]
 FX bounds    x[2754]   1
 LO bounds    x[2755]   0
 UP bounds    x[2755]   102000
 LO bounds    x[2756]   0
 UP bounds    x[2756]   102000
 LO bounds    x[2757]   0
 UP bounds    x[2757]   6543
 BV bounds    x[2758]
 BV bounds    x[2759]
 BV bounds    x[2760]
 BV bounds    x[2761]
 BV bounds    x[2762]
 BV bounds    x[2763]
 FX bounds    x[2764]   1
 LO bounds    x[2765]   0
 UP bounds    x[2765]   102000
 LO bounds    x[2766]   0
 UP bounds    x[2766]   102000
 LO bounds    x[2767]   0
 UP bounds    x[2767]   4077
 BV bounds    x[2768]
 BV bounds    x[2769]
 BV bounds    x[2770]
 BV bounds    x[2771]
 BV bounds    x[2772]
 BV bounds    x[2773]
 FX bounds    x[2774]   1
 LO bounds    x[2775]   0
 UP bounds    x[2775]   102000
 LO bounds    x[2776]   0
 UP bounds    x[2776]   102000
 LO bounds    x[2777]   0
 UP bounds    x[2777]   9024
 BV bounds    x[2778]
 BV bounds    x[2779]
 BV bounds    x[2780]
 BV bounds    x[2781]
 BV bounds    x[2782]
 BV bounds    x[2783]
 FX bounds    x[2784]   1
 LO bounds    x[2785]   0
 UP bounds    x[2785]   102000
 LO bounds    x[2786]   0
 UP bounds    x[2786]   102000
 LO bounds    x[2787]   0
 UP bounds    x[2787]   10713
 BV bounds    x[2788]
 BV bounds    x[2789]
 BV bounds    x[2790]
 BV bounds    x[2791]
 BV bounds    x[2792]
 BV bounds    x[2793]
 FX bounds    x[2794]   1
 LO bounds    x[2795]   0
 UP bounds    x[2795]   102000
 LO bounds    x[2796]   0
 UP bounds    x[2796]   102000
 LO bounds    x[2797]   0
 UP bounds    x[2797]   8970
 BV bounds    x[2798]
 BV bounds    x[2799]
 BV bounds    x[2800]
 BV bounds    x[2801]
 BV bounds    x[2802]
 BV bounds    x[2803]
 FX bounds    x[2804]   1
 LO bounds    x[2805]   0
 UP bounds    x[2805]   102000
 LO bounds    x[2806]   0
 UP bounds    x[2806]   102000
 LO bounds    x[2807]   0
 UP bounds    x[2807]   6381
 BV bounds    x[2808]
 BV bounds    x[2809]
 BV bounds    x[2810]
 BV bounds    x[2811]
 BV bounds    x[2812]
 BV bounds    x[2813]
 FX bounds    x[2814]   1
 LO bounds    x[2815]   0
 UP bounds    x[2815]   102000
 LO bounds    x[2816]   0
 UP bounds    x[2816]   102000
 LO bounds    x[2817]   0
 UP bounds    x[2817]   7683
 BV bounds    x[2818]
 BV bounds    x[2819]
 BV bounds    x[2820]
 BV bounds    x[2821]
 BV bounds    x[2822]
 BV bounds    x[2823]
 FX bounds    x[2824]   1
 LO bounds    x[2825]   0
 UP bounds    x[2825]   102000
 LO bounds    x[2826]   0
 UP bounds    x[2826]   102000
 LO bounds    x[2827]   0
 UP bounds    x[2827]   8787
 BV bounds    x[2828]
 BV bounds    x[2829]
 BV bounds    x[2830]
 BV bounds    x[2831]
 BV bounds    x[2832]
 BV bounds    x[2833]
 FX bounds    x[2834]   1
 LO bounds    x[2835]   0
 UP bounds    x[2835]   102000
 LO bounds    x[2836]   0
 UP bounds    x[2836]   102000
 LO bounds    x[2837]   0
 UP bounds    x[2837]   7638
 BV bounds    x[2838]
 BV bounds    x[2839]
 BV bounds    x[2840]
 BV bounds    x[2841]
 BV bounds    x[2842]
 BV bounds    x[2843]
 FX bounds    x[2844]   1
 LO bounds    x[2845]   0
 UP bounds    x[2845]   102000
 LO bounds    x[2846]   0
 UP bounds    x[2846]   102000
 LO bounds    x[2847]   0
 UP bounds    x[2847]   6222
 BV bounds    x[2848]
 BV bounds    x[2849]
 BV bounds    x[2850]
 BV bounds    x[2851]
 BV bounds    x[2852]
 BV bounds    x[2853]
 FX bounds    x[2854]   1
 LO bounds    x[2855]   0
 UP bounds    x[2855]   102000
 LO bounds    x[2856]   0
 UP bounds    x[2856]   102000
 LO bounds    x[2857]   0
 UP bounds    x[2857]   4743
 BV bounds    x[2858]
 BV bounds    x[2859]
 BV bounds    x[2860]
 BV bounds    x[2861]
 BV bounds    x[2862]
 BV bounds    x[2863]
 FX bounds    x[2864]   1
 LO bounds    x[2865]   0
 UP bounds    x[2865]   102000
 LO bounds    x[2866]   0
 UP bounds    x[2866]   102000
 LO bounds    x[2867]   0
 UP bounds    x[2867]   4731
 BV bounds    x[2868]
 BV bounds    x[2869]
 BV bounds    x[2870]
 BV bounds    x[2871]
 BV bounds    x[2872]
 BV bounds    x[2873]
 FX bounds    x[2874]   1
 LO bounds    x[2875]   0
 UP bounds    x[2875]   102000
 LO bounds    x[2876]   0
 UP bounds    x[2876]   102000
 LO bounds    x[2877]   0
 UP bounds    x[2877]   8319
 BV bounds    x[2878]
 BV bounds    x[2879]
 BV bounds    x[2880]
 BV bounds    x[2881]
 BV bounds    x[2882]
 BV bounds    x[2883]
 FX bounds    x[2884]   1
 LO bounds    x[2885]   0
 UP bounds    x[2885]   102000
 LO bounds    x[2886]   0
 UP bounds    x[2886]   102000
 LO bounds    x[2887]   0
 UP bounds    x[2887]   4587
 BV bounds    x[2888]
 BV bounds    x[2889]
 BV bounds    x[2890]
 BV bounds    x[2891]
 BV bounds    x[2892]
 BV bounds    x[2893]
 FX bounds    x[2894]   1
 LO bounds    x[2895]   0
 UP bounds    x[2895]   102000
 LO bounds    x[2896]   0
 UP bounds    x[2896]   102000
 LO bounds    x[2897]   0
 UP bounds    x[2897]   7149
 BV bounds    x[2898]
 BV bounds    x[2899]
 BV bounds    x[2900]
 BV bounds    x[2901]
 BV bounds    x[2902]
 BV bounds    x[2903]
 FX bounds    x[2904]   1
 LO bounds    x[2905]   0
 UP bounds    x[2905]   102000
 LO bounds    x[2906]   0
 UP bounds    x[2906]   102000
 LO bounds    x[2907]   0
 UP bounds    x[2907]   9042
 BV bounds    x[2908]
 BV bounds    x[2909]
 BV bounds    x[2910]
 BV bounds    x[2911]
 BV bounds    x[2912]
 BV bounds    x[2913]
 FX bounds    x[2914]   1
 LO bounds    x[2915]   0
 UP bounds    x[2915]   102000
 LO bounds    x[2916]   0
 UP bounds    x[2916]   102000
 LO bounds    x[2917]   0
 UP bounds    x[2917]   7854
 BV bounds    x[2918]
 BV bounds    x[2919]
 BV bounds    x[2920]
 BV bounds    x[2921]
 BV bounds    x[2922]
 BV bounds    x[2923]
 FX bounds    x[2924]   1
 LO bounds    x[2925]   0
 UP bounds    x[2925]   102000
 LO bounds    x[2926]   0
 UP bounds    x[2926]   102000
 LO bounds    x[2927]   0
 UP bounds    x[2927]   972
 BV bounds    x[2928]
 BV bounds    x[2929]
 BV bounds    x[2930]
 BV bounds    x[2931]
 BV bounds    x[2932]
 BV bounds    x[2933]
 FX bounds    x[2934]   1
 LO bounds    x[2935]   0
 UP bounds    x[2935]   102000
 LO bounds    x[2936]   0
 UP bounds    x[2936]   102000
 LO bounds    x[2937]   0
 UP bounds    x[2937]   8997
 BV bounds    x[2938]
 BV bounds    x[2939]
 BV bounds    x[2940]
 BV bounds    x[2941]
 BV bounds    x[2942]
 BV bounds    x[2943]
 FX bounds    x[2944]   1
 LO bounds    x[2945]   0
 UP bounds    x[2945]   102000
 LO bounds    x[2946]   0
 UP bounds    x[2946]   102000
 LO bounds    x[2947]   0
 UP bounds    x[2947]   7659
 BV bounds    x[2948]
 BV bounds    x[2949]
 BV bounds    x[2950]
 BV bounds    x[2951]
 BV bounds    x[2952]
 BV bounds    x[2953]
 FX bounds    x[2954]   1
 LO bounds    x[2955]   0
 UP bounds    x[2955]   102000
 LO bounds    x[2956]   0
 UP bounds    x[2956]   102000
 LO bounds    x[2957]   0
 UP bounds    x[2957]   4692
 BV bounds    x[2958]
 BV bounds    x[2959]
 BV bounds    x[2960]
 BV bounds    x[2961]
 BV bounds    x[2962]
 BV bounds    x[2963]
 FX bounds    x[2964]   1
 LO bounds    x[2965]   0
 UP bounds    x[2965]   102000
 LO bounds    x[2966]   0
 UP bounds    x[2966]   102000
 LO bounds    x[2967]   0
 UP bounds    x[2967]   8259
 BV bounds    x[2968]
 BV bounds    x[2969]
 BV bounds    x[2970]
 BV bounds    x[2971]
 BV bounds    x[2972]
 BV bounds    x[2973]
 FX bounds    x[2974]   1
 LO bounds    x[2975]   0
 UP bounds    x[2975]   102000
 LO bounds    x[2976]   0
 UP bounds    x[2976]   102000
 LO bounds    x[2977]   0
 UP bounds    x[2977]   8319
 BV bounds    x[2978]
 BV bounds    x[2979]
 BV bounds    x[2980]
 BV bounds    x[2981]
 BV bounds    x[2982]
 BV bounds    x[2983]
 FX bounds    x[2984]   1
 LO bounds    x[2985]   0
 UP bounds    x[2985]   102000
 LO bounds    x[2986]   0
 UP bounds    x[2986]   102000
 LO bounds    x[2987]   0
 UP bounds    x[2987]   9969
 BV bounds    x[2988]
 BV bounds    x[2989]
 BV bounds    x[2990]
 BV bounds    x[2991]
 BV bounds    x[2992]
 BV bounds    x[2993]
 FX bounds    x[2994]   1
 LO bounds    x[2995]   0
 UP bounds    x[2995]   102000
 LO bounds    x[2996]   0
 UP bounds    x[2996]   102000
 LO bounds    x[2997]   0
 UP bounds    x[2997]   7920
 BV bounds    x[2998]
 BV bounds    x[2999]
 BV bounds    x[3000]
 BV bounds    x[3001]
 BV bounds    x[3002]
 BV bounds    x[3003]
 FX bounds    x[3004]   1
 LO bounds    x[3005]   0
 UP bounds    x[3005]   102000
 LO bounds    x[3006]   0
 UP bounds    x[3006]   102000
 LO bounds    x[3007]   0
 UP bounds    x[3007]   6726
 BV bounds    x[3008]
 BV bounds    x[3009]
 BV bounds    x[3010]
 BV bounds    x[3011]
 BV bounds    x[3012]
 BV bounds    x[3013]
 FX bounds    x[3014]   1
 LO bounds    x[3015]   0
 UP bounds    x[3015]   102000
 LO bounds    x[3016]   0
 UP bounds    x[3016]   102000
 LO bounds    x[3017]   0
 UP bounds    x[3017]   9441
 BV bounds    x[3018]
 BV bounds    x[3019]
 BV bounds    x[3020]
 BV bounds    x[3021]
 BV bounds    x[3022]
 BV bounds    x[3023]
 FX bounds    x[3024]   1
 LO bounds    x[3025]   0
 UP bounds    x[3025]   102000
 LO bounds    x[3026]   0
 UP bounds    x[3026]   102000
 LO bounds    x[3027]   0
 UP bounds    x[3027]   8271
 BV bounds    x[3028]
 BV bounds    x[3029]
 BV bounds    x[3030]
 BV bounds    x[3031]
 BV bounds    x[3032]
 BV bounds    x[3033]
 FX bounds    x[3034]   1
 LO bounds    x[3035]   0
 UP bounds    x[3035]   102000
 LO bounds    x[3036]   0
 UP bounds    x[3036]   102000
 LO bounds    x[3037]   0
 UP bounds    x[3037]   1107
 BV bounds    x[3038]
 BV bounds    x[3039]
 BV bounds    x[3040]
 BV bounds    x[3041]
 BV bounds    x[3042]
 BV bounds    x[3043]
 FX bounds    x[3044]   1
 LO bounds    x[3045]   0
 UP bounds    x[3045]   102000
 LO bounds    x[3046]   0
 UP bounds    x[3046]   102000
 LO bounds    x[3047]   0
 UP bounds    x[3047]   5739
 BV bounds    x[3048]
 BV bounds    x[3049]
 BV bounds    x[3050]
 BV bounds    x[3051]
 BV bounds    x[3052]
 BV bounds    x[3053]
 FX bounds    x[3054]   1
 LO bounds    x[3055]   0
 UP bounds    x[3055]   102000
 LO bounds    x[3056]   0
 UP bounds    x[3056]   102000
 LO bounds    x[3057]   0
 UP bounds    x[3057]   1113
 BV bounds    x[3058]
 BV bounds    x[3059]
 BV bounds    x[3060]
 BV bounds    x[3061]
 BV bounds    x[3062]
 BV bounds    x[3063]
 FX bounds    x[3064]   1
 LO bounds    x[3065]   0
 UP bounds    x[3065]   102000
 LO bounds    x[3066]   0
 UP bounds    x[3066]   102000
 LO bounds    x[3067]   0
 UP bounds    x[3067]   3936
 BV bounds    x[3068]
 BV bounds    x[3069]
 BV bounds    x[3070]
 BV bounds    x[3071]
 BV bounds    x[3072]
 BV bounds    x[3073]
 FX bounds    x[3074]   1
 LO bounds    x[3075]   0
 UP bounds    x[3075]   102000
 LO bounds    x[3076]   0
 UP bounds    x[3076]   102000
 LO bounds    x[3077]   0
 UP bounds    x[3077]   8979
 BV bounds    x[3078]
 BV bounds    x[3079]
 BV bounds    x[3080]
 BV bounds    x[3081]
 BV bounds    x[3082]
 BV bounds    x[3083]
 FX bounds    x[3084]   1
 LO bounds    x[3085]   0
 UP bounds    x[3085]   102000
 LO bounds    x[3086]   0
 UP bounds    x[3086]   102000
 LO bounds    x[3087]   0
 UP bounds    x[3087]   7641
 BV bounds    x[3088]
 BV bounds    x[3089]
 BV bounds    x[3090]
 BV bounds    x[3091]
 BV bounds    x[3092]
 BV bounds    x[3093]
 FX bounds    x[3094]   1
 LO bounds    x[3095]   0
 UP bounds    x[3095]   102000
 LO bounds    x[3096]   0
 UP bounds    x[3096]   102000
 LO bounds    x[3097]   0
 UP bounds    x[3097]   4650
 BV bounds    x[3098]
 BV bounds    x[3099]
 BV bounds    x[3100]
 BV bounds    x[3101]
 BV bounds    x[3102]
 BV bounds    x[3103]
 FX bounds    x[3104]   1
 LO bounds    x[3105]   0
 UP bounds    x[3105]   102000
 LO bounds    x[3106]   0
 UP bounds    x[3106]   102000
 LO bounds    x[3107]   0
 UP bounds    x[3107]   735
 BV bounds    x[3108]
 BV bounds    x[3109]
 BV bounds    x[3110]
 BV bounds    x[3111]
 BV bounds    x[3112]
 BV bounds    x[3113]
 FX bounds    x[3114]   1
 LO bounds    x[3115]   0
 UP bounds    x[3115]   102000
 LO bounds    x[3116]   0
 UP bounds    x[3116]   102000
 LO bounds    x[3117]   0
 UP bounds    x[3117]   8289
ENDATA
