NAME
ROWS
 N  OBJ
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c65       1
    x[1]      c81       1
    x[1]      c97       1
    x[1]      OBJ       1
    x[2]      c1        1
    x[2]      c65       1
    x[2]      c66       1
    x[2]      c97       1
    x[2]      OBJ       1
    x[3]      c2        1
    x[3]      c65       1
    x[3]      c66       1
    x[3]      c67       1
    x[3]      OBJ       1
    x[4]      c3        1
    x[4]      c66       1
    x[4]      c67       1
    x[4]      c68       1
    x[4]      OBJ       1
    x[5]      c4        1
    x[5]      c67       1
    x[5]      c68       1
    x[5]      c69       1
    x[5]      OBJ       1
    x[6]      c5        1
    x[6]      c68       1
    x[6]      c69       1
    x[6]      c70       1
    x[6]      OBJ       1
    x[7]      c6        1
    x[7]      c69       1
    x[7]      c70       1
    x[7]      c71       1
    x[7]      OBJ       1
    x[8]      c7        1
    x[8]      c70       1
    x[8]      c71       1
    x[8]      c72       1
    x[8]      OBJ       1
    x[9]      c8        1
    x[9]      c71       1
    x[9]      c72       1
    x[9]      c99       1
    x[9]      OBJ       1
    x[10]     c72       1
    x[10]     c89       1
    x[10]     c99       1
    x[10]     OBJ       1
    x[11]     c1        1
    x[11]     c81       1
    x[11]     c82       1
    x[11]     c97       1
    x[11]     OBJ       1
    x[12]     c1        1
    x[12]     c2        1
    x[12]     c9        1
    x[12]     c65       1
    x[12]     c81       1
    x[12]     OBJ       1
    x[13]     c1        1
    x[13]     c2        1
    x[13]     c3        1
    x[13]     c10       1
    x[13]     c66       1
    x[13]     OBJ       1
    x[14]     c2        1
    x[14]     c3        1
    x[14]     c4        1
    x[14]     c11       1
    x[14]     c67       1
    x[14]     OBJ       1
    x[15]     c3        1
    x[15]     c4        1
    x[15]     c5        1
    x[15]     c12       1
    x[15]     c68       1
    x[15]     OBJ       1
    x[16]     c4        1
    x[16]     c5        1
    x[16]     c6        1
    x[16]     c13       1
    x[16]     c69       1
    x[16]     OBJ       1
    x[17]     c5        1
    x[17]     c6        1
    x[17]     c7        1
    x[17]     c14       1
    x[17]     c70       1
    x[17]     OBJ       1
    x[18]     c6        1
    x[18]     c7        1
    x[18]     c8        1
    x[18]     c15       1
    x[18]     c71       1
    x[18]     OBJ       1
    x[19]     c7        1
    x[19]     c8        1
    x[19]     c16       1
    x[19]     c72       1
    x[19]     c89       1
    x[19]     OBJ       1
    x[20]     c8        1
    x[20]     c89       1
    x[20]     c90       1
    x[20]     c99       1
    x[20]     OBJ       1
    x[21]     c9        1
    x[21]     c81       1
    x[21]     c82       1
    x[21]     c83       1
    x[21]     OBJ       1
    x[22]     c1        1
    x[22]     c9        1
    x[22]     c10       1
    x[22]     c17       1
    x[22]     c82       1
    x[22]     OBJ       1
    x[23]     c2        1
    x[23]     c9        1
    x[23]     c10       1
    x[23]     c11       1
    x[23]     c18       1
    x[23]     OBJ       1
    x[24]     c3        1
    x[24]     c10       1
    x[24]     c11       1
    x[24]     c12       1
    x[24]     c19       1
    x[24]     OBJ       1
    x[25]     c4        1
    x[25]     c11       1
    x[25]     c12       1
    x[25]     c13       1
    x[25]     c20       1
    x[25]     OBJ       1
    x[26]     c5        1
    x[26]     c12       1
    x[26]     c13       1
    x[26]     c14       1
    x[26]     c21       1
    x[26]     OBJ       1
    x[27]     c6        1
    x[27]     c13       1
    x[27]     c14       1
    x[27]     c15       1
    x[27]     c22       1
    x[27]     OBJ       1
    x[28]     c7        1
    x[28]     c14       1
    x[28]     c15       1
    x[28]     c16       1
    x[28]     c23       1
    x[28]     OBJ       1
    x[29]     c8        1
    x[29]     c15       1
    x[29]     c16       1
    x[29]     c24       1
    x[29]     c90       1
    x[29]     OBJ       1
    x[30]     c16       1
    x[30]     c89       1
    x[30]     c90       1
    x[30]     c91       1
    x[30]     OBJ       1
    x[31]     c17       1
    x[31]     c82       1
    x[31]     c83       1
    x[31]     c84       1
    x[31]     OBJ       1
    x[32]     c9        1
    x[32]     c17       1
    x[32]     c18       1
    x[32]     c25       1
    x[32]     c83       1
    x[32]     OBJ       1
    x[33]     c10       1
    x[33]     c17       1
    x[33]     c18       1
    x[33]     c19       1
    x[33]     c26       1
    x[33]     OBJ       1
    x[34]     c11       1
    x[34]     c18       1
    x[34]     c19       1
    x[34]     c20       1
    x[34]     c27       1
    x[34]     OBJ       1
    x[35]     c12       1
    x[35]     c19       1
    x[35]     c20       1
    x[35]     c21       1
    x[35]     c28       1
    x[35]     OBJ       1
    x[36]     c13       1
    x[36]     c20       1
    x[36]     c21       1
    x[36]     c22       1
    x[36]     c29       1
    x[36]     OBJ       1
    x[37]     c14       1
    x[37]     c21       1
    x[37]     c22       1
    x[37]     c23       1
    x[37]     c30       1
    x[37]     OBJ       1
    x[38]     c15       1
    x[38]     c22       1
    x[38]     c23       1
    x[38]     c24       1
    x[38]     c31       1
    x[38]     OBJ       1
    x[39]     c16       1
    x[39]     c23       1
    x[39]     c24       1
    x[39]     c32       1
    x[39]     c91       1
    x[39]     OBJ       1
    x[40]     c24       1
    x[40]     c90       1
    x[40]     c91       1
    x[40]     c92       1
    x[40]     OBJ       1
    x[41]     c25       1
    x[41]     c83       1
    x[41]     c84       1
    x[41]     c85       1
    x[41]     OBJ       1
    x[42]     c17       1
    x[42]     c25       1
    x[42]     c26       1
    x[42]     c33       1
    x[42]     c84       1
    x[42]     OBJ       1
    x[43]     c18       1
    x[43]     c25       1
    x[43]     c26       1
    x[43]     c27       1
    x[43]     c34       1
    x[43]     OBJ       1
    x[44]     c19       1
    x[44]     c26       1
    x[44]     c27       1
    x[44]     c28       1
    x[44]     c35       1
    x[44]     OBJ       1
    x[45]     c20       1
    x[45]     c27       1
    x[45]     c28       1
    x[45]     c29       1
    x[45]     c36       1
    x[45]     OBJ       1
    x[46]     c21       1
    x[46]     c28       1
    x[46]     c29       1
    x[46]     c30       1
    x[46]     c37       1
    x[46]     OBJ       1
    x[47]     c22       1
    x[47]     c29       1
    x[47]     c30       1
    x[47]     c31       1
    x[47]     c38       1
    x[47]     OBJ       1
    x[48]     c23       1
    x[48]     c30       1
    x[48]     c31       1
    x[48]     c32       1
    x[48]     c39       1
    x[48]     OBJ       1
    x[49]     c24       1
    x[49]     c31       1
    x[49]     c32       1
    x[49]     c40       1
    x[49]     c92       1
    x[49]     OBJ       1
    x[50]     c32       1
    x[50]     c91       1
    x[50]     c92       1
    x[50]     c93       1
    x[50]     OBJ       1
    x[51]     c33       1
    x[51]     c84       1
    x[51]     c85       1
    x[51]     c86       1
    x[51]     OBJ       1
    x[52]     c25       1
    x[52]     c33       1
    x[52]     c34       1
    x[52]     c41       1
    x[52]     c85       1
    x[52]     OBJ       1
    x[53]     c26       1
    x[53]     c33       1
    x[53]     c34       1
    x[53]     c35       1
    x[53]     c42       1
    x[53]     OBJ       1
    x[54]     c27       1
    x[54]     c34       1
    x[54]     c35       1
    x[54]     c36       1
    x[54]     c43       1
    x[54]     OBJ       1
    x[55]     c28       1
    x[55]     c35       1
    x[55]     c36       1
    x[55]     c37       1
    x[55]     c44       1
    x[55]     OBJ       1
    x[56]     c29       1
    x[56]     c36       1
    x[56]     c37       1
    x[56]     c38       1
    x[56]     c45       1
    x[56]     OBJ       1
    x[57]     c30       1
    x[57]     c37       1
    x[57]     c38       1
    x[57]     c39       1
    x[57]     c46       1
    x[57]     OBJ       1
    x[58]     c31       1
    x[58]     c38       1
    x[58]     c39       1
    x[58]     c40       1
    x[58]     c47       1
    x[58]     OBJ       1
    x[59]     c32       1
    x[59]     c39       1
    x[59]     c40       1
    x[59]     c48       1
    x[59]     c93       1
    x[59]     OBJ       1
    x[60]     c40       1
    x[60]     c92       1
    x[60]     c93       1
    x[60]     c94       1
    x[60]     OBJ       1
    x[61]     c41       1
    x[61]     c85       1
    x[61]     c86       1
    x[61]     c87       1
    x[61]     OBJ       1
    x[62]     c33       1
    x[62]     c41       1
    x[62]     c42       1
    x[62]     c49       1
    x[62]     c86       1
    x[62]     OBJ       1
    x[63]     c34       1
    x[63]     c41       1
    x[63]     c42       1
    x[63]     c43       1
    x[63]     c50       1
    x[63]     OBJ       1
    x[64]     c35       1
    x[64]     c42       1
    x[64]     c43       1
    x[64]     c44       1
    x[64]     c51       1
    x[64]     OBJ       1
    x[65]     c36       1
    x[65]     c43       1
    x[65]     c44       1
    x[65]     c45       1
    x[65]     c52       1
    x[65]     OBJ       1
    x[66]     c37       1
    x[66]     c44       1
    x[66]     c45       1
    x[66]     c46       1
    x[66]     c53       1
    x[66]     OBJ       1
    x[67]     c38       1
    x[67]     c45       1
    x[67]     c46       1
    x[67]     c47       1
    x[67]     c54       1
    x[67]     OBJ       1
    x[68]     c39       1
    x[68]     c46       1
    x[68]     c47       1
    x[68]     c48       1
    x[68]     c55       1
    x[68]     OBJ       1
    x[69]     c40       1
    x[69]     c47       1
    x[69]     c48       1
    x[69]     c56       1
    x[69]     c94       1
    x[69]     OBJ       1
    x[70]     c48       1
    x[70]     c93       1
    x[70]     c94       1
    x[70]     c95       1
    x[70]     OBJ       1
    x[71]     c49       1
    x[71]     c86       1
    x[71]     c87       1
    x[71]     c88       1
    x[71]     OBJ       1
    x[72]     c41       1
    x[72]     c49       1
    x[72]     c50       1
    x[72]     c57       1
    x[72]     c87       1
    x[72]     OBJ       1
    x[73]     c42       1
    x[73]     c49       1
    x[73]     c50       1
    x[73]     c51       1
    x[73]     c58       1
    x[73]     OBJ       1
    x[74]     c43       1
    x[74]     c50       1
    x[74]     c51       1
    x[74]     c52       1
    x[74]     c59       1
    x[74]     OBJ       1
    x[75]     c44       1
    x[75]     c51       1
    x[75]     c52       1
    x[75]     c53       1
    x[75]     c60       1
    x[75]     OBJ       1
    x[76]     c45       1
    x[76]     c52       1
    x[76]     c53       1
    x[76]     c54       1
    x[76]     c61       1
    x[76]     OBJ       1
    x[77]     c46       1
    x[77]     c53       1
    x[77]     c54       1
    x[77]     c55       1
    x[77]     c62       1
    x[77]     OBJ       1
    x[78]     c47       1
    x[78]     c54       1
    x[78]     c55       1
    x[78]     c56       1
    x[78]     c63       1
    x[78]     OBJ       1
    x[79]     c48       1
    x[79]     c55       1
    x[79]     c56       1
    x[79]     c64       1
    x[79]     c95       1
    x[79]     OBJ       1
    x[80]     c56       1
    x[80]     c94       1
    x[80]     c95       1
    x[80]     c96       1
    x[80]     OBJ       1
    x[81]     c57       1
    x[81]     c87       1
    x[81]     c88       1
    x[81]     c98       1
    x[81]     OBJ       1
    x[82]     c49       1
    x[82]     c57       1
    x[82]     c58       1
    x[82]     c73       1
    x[82]     c88       1
    x[82]     OBJ       1
    x[83]     c50       1
    x[83]     c57       1
    x[83]     c58       1
    x[83]     c59       1
    x[83]     c74       1
    x[83]     OBJ       1
    x[84]     c51       1
    x[84]     c58       1
    x[84]     c59       1
    x[84]     c60       1
    x[84]     c75       1
    x[84]     OBJ       1
    x[85]     c52       1
    x[85]     c59       1
    x[85]     c60       1
    x[85]     c61       1
    x[85]     c76       1
    x[85]     OBJ       1
    x[86]     c53       1
    x[86]     c60       1
    x[86]     c61       1
    x[86]     c62       1
    x[86]     c77       1
    x[86]     OBJ       1
    x[87]     c54       1
    x[87]     c61       1
    x[87]     c62       1
    x[87]     c63       1
    x[87]     c78       1
    x[87]     OBJ       1
    x[88]     c55       1
    x[88]     c62       1
    x[88]     c63       1
    x[88]     c64       1
    x[88]     c79       1
    x[88]     OBJ       1
    x[89]     c56       1
    x[89]     c63       1
    x[89]     c64       1
    x[89]     c80       1
    x[89]     c96       1
    x[89]     OBJ       1
    x[90]     c64       1
    x[90]     c95       1
    x[90]     c96       1
    x[90]     c100      1
    x[90]     OBJ       1
    x[91]     c73       1
    x[91]     c88       1
    x[91]     c98       1
    x[91]     OBJ       1
    x[92]     c57       1
    x[92]     c73       1
    x[92]     c74       1
    x[92]     c98       1
    x[92]     OBJ       1
    x[93]     c58       1
    x[93]     c73       1
    x[93]     c74       1
    x[93]     c75       1
    x[93]     OBJ       1
    x[94]     c59       1
    x[94]     c74       1
    x[94]     c75       1
    x[94]     c76       1
    x[94]     OBJ       1
    x[95]     c60       1
    x[95]     c75       1
    x[95]     c76       1
    x[95]     c77       1
    x[95]     OBJ       1
    x[96]     c61       1
    x[96]     c76       1
    x[96]     c77       1
    x[96]     c78       1
    x[96]     OBJ       1
    x[97]     c62       1
    x[97]     c77       1
    x[97]     c78       1
    x[97]     c79       1
    x[97]     OBJ       1
    x[98]     c63       1
    x[98]     c78       1
    x[98]     c79       1
    x[98]     c80       1
    x[98]     OBJ       1
    x[99]     c64       1
    x[99]     c79       1
    x[99]     c80       1
    x[99]     c100      1
    x[99]     OBJ       1
    x[100]    c80       1
    x[100]    c96       1
    x[100]    c100      1
    x[100]    OBJ       1
    x[101]    c1        -2
    x[102]    c2        -2
    x[103]    c3        -2
    x[104]    c4        -2
    x[105]    c5        -2
    x[106]    c6        -2
    x[107]    c7        -2
    x[108]    c8        -2
    x[109]    c9        -2
    x[110]    c10       -2
    x[111]    c11       -2
    x[112]    c12       -2
    x[113]    c13       -2
    x[114]    c14       -2
    x[115]    c15       -2
    x[116]    c16       -2
    x[117]    c17       -2
    x[118]    c18       -2
    x[119]    c19       -2
    x[120]    c20       -2
    x[121]    c21       -2
    x[122]    c22       -2
    x[123]    c23       -2
    x[124]    c24       -2
    x[125]    c25       -2
    x[126]    c26       -2
    x[127]    c27       -2
    x[128]    c28       -2
    x[129]    c29       -2
    x[130]    c30       -2
    x[131]    c31       -2
    x[132]    c32       -2
    x[133]    c33       -2
    x[134]    c34       -2
    x[135]    c35       -2
    x[136]    c36       -2
    x[137]    c37       -2
    x[138]    c38       -2
    x[139]    c39       -2
    x[140]    c40       -2
    x[141]    c41       -2
    x[142]    c42       -2
    x[143]    c43       -2
    x[144]    c44       -2
    x[145]    c45       -2
    x[146]    c46       -2
    x[147]    c47       -2
    x[148]    c48       -2
    x[149]    c49       -2
    x[150]    c50       -2
    x[151]    c51       -2
    x[152]    c52       -2
    x[153]    c53       -2
    x[154]    c54       -2
    x[155]    c55       -2
    x[156]    c56       -2
    x[157]    c57       -2
    x[158]    c58       -2
    x[159]    c59       -2
    x[160]    c60       -2
    x[161]    c61       -2
    x[162]    c62       -2
    x[163]    c63       -2
    x[164]    c64       -2
    x[165]    c65       -2
    x[166]    c66       -2
    x[167]    c67       -2
    x[168]    c68       -2
    x[169]    c69       -2
    x[170]    c70       -2
    x[171]    c71       -2
    x[172]    c72       -2
    x[173]    c73       -2
    x[174]    c74       -2
    x[175]    c75       -2
    x[176]    c76       -2
    x[177]    c77       -2
    x[178]    c78       -2
    x[179]    c79       -2
    x[180]    c80       -2
    x[181]    c81       -2
    x[182]    c82       -2
    x[183]    c83       -2
    x[184]    c84       -2
    x[185]    c85       -2
    x[186]    c86       -2
    x[187]    c87       -2
    x[188]    c88       -2
    x[189]    c89       -2
    x[190]    c90       -2
    x[191]    c91       -2
    x[192]    c92       -2
    x[193]    c93       -2
    x[194]    c94       -2
    x[195]    c95       -2
    x[196]    c96       -2
    x[197]    c97       -2
    x[198]    c98       -2
    x[199]    c99       -2
    x[200]    c100      -2
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        -1
    rhs       c7        0
    rhs       c8        0
    rhs       c9        -1
    rhs       c10       0
    rhs       c11       0
    rhs       c12       -1
    rhs       c13       -1
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       -1
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       -1
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       -1
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       -1
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       -1
    rhs       c44       0
    rhs       c45       0
    rhs       c46       -1
    rhs       c47       0
    rhs       c48       -1
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       -1
    rhs       c53       0
    rhs       c54       0
    rhs       c55       -1
    rhs       c56       0
    rhs       c57       -1
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       -1
    rhs       c63       -1
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       -1
    rhs       c72       0
    rhs       c73       0
    rhs       c74       -1
    rhs       c75       -1
    rhs       c76       -1
    rhs       c77       0
    rhs       c78       -1
    rhs       c79       0
    rhs       c80       -1
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       -1
    rhs       c85       0
    rhs       c86       0
    rhs       c87       -1
    rhs       c88       0
    rhs       c89       0
    rhs       c90       -1
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       -1
    rhs       c96       -1
    rhs       c97       -1
    rhs       c98       -1
    rhs       c99       0
    rhs       c100      0
RANGES
BOUNDS
 BV bounds    x[1]
 BV bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 BV bounds    x[75]
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 BV bounds    x[80]
 BV bounds    x[81]
 BV bounds    x[82]
 BV bounds    x[83]
 BV bounds    x[84]
 BV bounds    x[85]
 BV bounds    x[86]
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 BV bounds    x[90]
 BV bounds    x[91]
 BV bounds    x[92]
 BV bounds    x[93]
 BV bounds    x[94]
 BV bounds    x[95]
 BV bounds    x[96]
 BV bounds    x[97]
 BV bounds    x[98]
 BV bounds    x[99]
 BV bounds    x[100]
 LO bounds    x[101]    0
 UP bounds    x[101]    2
 LO bounds    x[102]    0
 UP bounds    x[102]    2
 LO bounds    x[103]    0
 UP bounds    x[103]    2
 LO bounds    x[104]    0
 UP bounds    x[104]    2
 LO bounds    x[105]    0
 UP bounds    x[105]    2
 LO bounds    x[106]    1
 UP bounds    x[106]    3
 LO bounds    x[107]    0
 UP bounds    x[107]    2
 LO bounds    x[108]    0
 UP bounds    x[108]    2
 LO bounds    x[109]    1
 UP bounds    x[109]    3
 LO bounds    x[110]    0
 UP bounds    x[110]    2
 LO bounds    x[111]    0
 UP bounds    x[111]    2
 LO bounds    x[112]    1
 UP bounds    x[112]    3
 LO bounds    x[113]    1
 UP bounds    x[113]    3
 LO bounds    x[114]    0
 UP bounds    x[114]    2
 LO bounds    x[115]    0
 UP bounds    x[115]    2
 LO bounds    x[116]    0
 UP bounds    x[116]    2
 LO bounds    x[117]    0
 UP bounds    x[117]    2
 LO bounds    x[118]    0
 UP bounds    x[118]    2
 LO bounds    x[119]    0
 UP bounds    x[119]    2
 LO bounds    x[120]    0
 UP bounds    x[120]    2
 LO bounds    x[121]    0
 UP bounds    x[121]    2
 LO bounds    x[122]    0
 UP bounds    x[122]    2
 LO bounds    x[123]    1
 UP bounds    x[123]    3
 LO bounds    x[124]    0
 UP bounds    x[124]    2
 LO bounds    x[125]    0
 UP bounds    x[125]    2
 LO bounds    x[126]    0
 UP bounds    x[126]    2
 LO bounds    x[127]    0
 UP bounds    x[127]    2
 LO bounds    x[128]    0
 UP bounds    x[128]    2
 LO bounds    x[129]    1
 UP bounds    x[129]    3
 LO bounds    x[130]    0
 UP bounds    x[130]    2
 LO bounds    x[131]    0
 UP bounds    x[131]    2
 LO bounds    x[132]    0
 UP bounds    x[132]    2
 LO bounds    x[133]    0
 UP bounds    x[133]    2
 LO bounds    x[134]    1
 UP bounds    x[134]    3
 LO bounds    x[135]    0
 UP bounds    x[135]    2
 LO bounds    x[136]    0
 UP bounds    x[136]    2
 LO bounds    x[137]    0
 UP bounds    x[137]    2
 LO bounds    x[138]    0
 UP bounds    x[138]    2
 LO bounds    x[139]    1
 UP bounds    x[139]    3
 LO bounds    x[140]    0
 UP bounds    x[140]    2
 LO bounds    x[141]    0
 UP bounds    x[141]    2
 LO bounds    x[142]    0
 UP bounds    x[142]    2
 LO bounds    x[143]    1
 UP bounds    x[143]    3
 LO bounds    x[144]    0
 UP bounds    x[144]    2
 LO bounds    x[145]    0
 UP bounds    x[145]    2
 LO bounds    x[146]    1
 UP bounds    x[146]    3
 LO bounds    x[147]    0
 UP bounds    x[147]    2
 LO bounds    x[148]    1
 UP bounds    x[148]    3
 LO bounds    x[149]    0
 UP bounds    x[149]    2
 LO bounds    x[150]    0
 UP bounds    x[150]    2
 LO bounds    x[151]    0
 UP bounds    x[151]    2
 LO bounds    x[152]    1
 UP bounds    x[152]    3
 LO bounds    x[153]    0
 UP bounds    x[153]    2
 LO bounds    x[154]    0
 UP bounds    x[154]    2
 LO bounds    x[155]    0
 UP bounds    x[155]    3
 LO bounds    x[156]    0
 UP bounds    x[156]    2
 LO bounds    x[157]    0
 UP bounds    x[157]    3
 LO bounds    x[158]    0
 UP bounds    x[158]    2
 LO bounds    x[159]    0
 UP bounds    x[159]    2
 LO bounds    x[160]    0
 UP bounds    x[160]    2
 LO bounds    x[161]    0
 UP bounds    x[161]    2
 LO bounds    x[162]    0
 UP bounds    x[162]    3
 LO bounds    x[163]    0
 UP bounds    x[163]    3
 LO bounds    x[164]    0
 UP bounds    x[164]    2
 LO bounds    x[165]    0
 UP bounds    x[165]    2
 LO bounds    x[166]    0
 UP bounds    x[166]    2
 LO bounds    x[167]    0
 UP bounds    x[167]    2
 LO bounds    x[168]    0
 UP bounds    x[168]    2
 LO bounds    x[169]    0
 UP bounds    x[169]    2
 LO bounds    x[170]    0
 UP bounds    x[170]    2
 LO bounds    x[171]    1
 UP bounds    x[171]    2
 LO bounds    x[172]    0
 UP bounds    x[172]    2
 LO bounds    x[173]    0
 UP bounds    x[173]    2
 LO bounds    x[174]    0
 UP bounds    x[174]    2
 LO bounds    x[175]    0
 UP bounds    x[175]    2
 LO bounds    x[176]    0
 UP bounds    x[176]    2
 LO bounds    x[177]    0
 UP bounds    x[177]    2
 LO bounds    x[178]    0
 UP bounds    x[178]    2
 LO bounds    x[179]    0
 UP bounds    x[179]    2
 LO bounds    x[180]    0
 UP bounds    x[180]    2
 LO bounds    x[181]    0
 UP bounds    x[181]    2
 LO bounds    x[182]    0
 UP bounds    x[182]    2
 LO bounds    x[183]    0
 UP bounds    x[183]    2
 LO bounds    x[184]    1
 UP bounds    x[184]    2
 LO bounds    x[185]    0
 UP bounds    x[185]    2
 LO bounds    x[186]    0
 UP bounds    x[186]    2
 LO bounds    x[187]    0
 UP bounds    x[187]    2
 LO bounds    x[188]    0
 UP bounds    x[188]    2
 LO bounds    x[189]    0
 UP bounds    x[189]    2
 LO bounds    x[190]    1
 UP bounds    x[190]    2
 LO bounds    x[191]    0
 UP bounds    x[191]    2
 LO bounds    x[192]    0
 UP bounds    x[192]    2
 LO bounds    x[193]    0
 UP bounds    x[193]    2
 LO bounds    x[194]    0
 UP bounds    x[194]    2
 LO bounds    x[195]    0
 UP bounds    x[195]    2
 LO bounds    x[196]    0
 UP bounds    x[196]    2
 LO bounds    x[197]    1
 UP bounds    x[197]    2
 LO bounds    x[198]    0
 UP bounds    x[198]    2
 LO bounds    x[199]    0
 UP bounds    x[199]    1
 LO bounds    x[200]    0
 UP bounds    x[200]    1
ENDATA
