NAME
ROWS
 N  OBJ
 L  c1_2
 L  c2_2
 L  c3_2
 L  c4_2
 L  c5_2
 L  c6_2
 L  c7_2
 L  c8_2
 L  c9_2
 L  c10_2
 L  c11_2
 L  c12_2
 L  c13_2
 L  c14_2
 L  c15_2
 L  c16_2
 L  c17_2
 L  c18_2
 L  c19_2
 L  c20_2
 L  c21_2
 L  c22_2
 L  c23_2
 L  c24_2
 L  c25_2
 L  c26_2
 L  c27_2
 L  c28_2
 L  c29_2
 L  c30_2
 L  c31_2
 L  c32_2
 L  c33_2
 L  c34_2
 L  c35_2
 L  c36_2
 L  c37_2
 L  c38_2
 L  c39_2
 L  c40_2
 L  c41_2
 L  c42_2
 L  c43_2
 L  c44_2
 L  c45_2
 L  c46_2
 L  c47_2
 L  c48_2
 L  c49_2
 L  c50_2
 L  c51_2
 L  c52_2
 L  c53_2
 L  c54_2
 L  c55_2
 L  c56_2
 L  c57_2
 L  c58_2
 L  c59_2
 L  c60_2
 L  c61_2
 L  c62_2
 L  c63_2
 L  c64_2
 L  c65_2
 L  c66_2
 L  c67_2
 L  c68_2
 L  c69_2
 L  c70_2
 L  c71_2
 L  c72_2
 L  c73_2
 L  c74_2
 L  c75_2
 L  c76_2
 L  c77_2
 L  c78_2
 L  c79_2
 L  c80_2
 L  c81_2
 L  c82_2
 L  c83_2
 L  c84_2
 L  c85_2
 L  c86_2
 L  c87_2
 L  c88_2
 L  c89_2
 L  c90_2
 L  c91_2
 L  c92_2
 L  c93_2
 L  c94_2
 L  c95_2
 L  c96_2
 L  c97_2
 L  c98_2
 L  c99_2
 L  c100_2
 L  c101_2
 L  c102_2
 L  c103_2
 L  c104_2
 L  c105_2
 L  c106_2
 L  c107_2
 L  c108_2
 L  c109_2
 L  c110_2
 L  c111_2
 L  c112_2
 L  c113_2
 L  c114_2
 L  c115_2
 L  c116_2
 L  c117_2
 L  c118_2
 L  c119_2
 L  c120_2
 L  c121_2
 L  c122_2
 L  c123_2
 L  c124_2
 L  c125_2
 L  c126_2
 L  c127_2
 L  c128_2
 L  c129_2
 L  c130_2
 L  c131_2
 L  c132_2
 L  c133_2
 L  c134_2
 L  c135_2
 L  c136_2
 L  c137_2
 L  c138_2
 L  c139_2
 L  c140_2
 L  c141_2
 L  c142_2
 L  c143_2
 L  c144_2
 L  c145_2
 L  c146_2
 L  c147_2
 L  c148_2
 L  c149_2
 L  c150_2
 L  c151_2
 L  c152_2
 L  c153_2
 L  c154_2
 L  c155_2
 L  c156_2
 L  c157_2
 L  c158_2
 L  c159_2
 L  c160_2
 L  c161_2
 L  c162_2
 L  c163_2
 L  c164_2
 L  c165_2
 L  c166_2
 L  c167_2
 L  c168_2
 L  c169_2
 L  c170_2
 L  c171_2
 L  c172_2
 L  c173_2
 L  c174_2
 L  c175_2
 L  c176_2
 L  c177_2
 L  c178_2
 L  c179_2
 L  c180_2
 L  c181_2
 L  c182_2
 L  c183_2
 L  c184_2
 L  c185_2
 L  c186_2
 L  c187_2
 L  c188_2
 L  c189_2
 L  c190_2
 L  c191_2
 L  c192_2
 L  c193_2
 L  c194_2
 L  c195_2
 L  c196_2
 L  c197_2
 L  c198_2
 L  c199_2
 L  c200_2
 L  c201_2
 L  c202_2
 L  c203_2
 L  c204_2
 L  c205_2
 L  c206_2
 L  c207_2
 L  c208_2
 L  c209_2
 L  c210_2
 L  c211_2
 L  c212_2
 L  c213_2
 L  c214_2
 L  c215_2
 L  c216_2
 L  c217_2
 L  c218_2
 L  c219_2
 L  c220_2
 L  c221_2
 L  c222_2
 L  c223_2
 L  c224_2
 L  c225_2
 L  c226_2
 L  c227_2
 L  c228_2
 L  c229_2
 L  c230_2
 L  c231_2
 L  c232_2
 L  c233_2
 L  c234_2
 L  c235_2
 L  c236_2
 L  c237_2
 L  c238_2
 L  c239_2
 L  c240_2
 L  c241_2
 L  c242_2
 L  c243_2
 L  c244_2
 L  c245_2
 L  c246_2
 L  c247_2
 L  c248_2
 L  c249_2
 L  c250_2
 L  c251_2
 L  c252_2
 L  c253_2
 L  c254_2
 L  c255_2
 L  c256_2
 L  c257_2
 L  c258_2
 L  c259_2
 L  c260_2
 L  c261_2
 L  c262_2
 L  c263_2
 L  c264_2
 L  c265_2
 L  c266_2
 L  c267_2
 L  c268_2
 L  c269_2
 L  c270_2
 L  c271_2
 L  c272_1
 L  c273_1
 L  c274_1
 L  c275_1
 L  c276_1
 L  c277_1
 L  c278_1
 L  c279_1
 L  c280_1
 L  c281_1
 L  c282_1
 L  c283_1
 L  c284_1
 L  c285_1
 L  c286_1
 L  c287_1
 L  c288_1
 L  c289_1
 L  c290_1
 L  c291_1
 L  c292_1
 L  c293_1
 L  c294_1
 L  c295_1
 L  c296_1
 L  c297_1
 L  c298_1
 L  c299_1
 L  c300_1
 L  c301_1
 L  c302_1
 L  c303_1
 L  c304_1
 L  c305_1
 L  c306_1
 L  c307_1
 L  c308_1
 L  c309_1
 L  c310_1
 L  c311_1
 L  c312_1
 L  c313_1
 L  c314_1
 L  c315_1
 L  c316_1
 L  c317_1
 L  c318_1
 L  c319_1
 L  c320_1
 L  c321_1
 L  c322_1
 L  c323_1
 L  c324_1
 L  c325_1
 L  c326_1
 L  c327_1
 L  c328_1
 L  c329_1
 L  c330_1
 L  c331_1
 L  c332_1
 L  c333_1
 L  c334_1
 L  c335_1
 L  c336_1
 G  c1_1
 G  c2_1
 G  c3_1
 G  c4_1
 G  c5_1
 G  c6_1
 G  c7_1
 G  c8_1
 G  c9_1
 G  c10_1
 G  c11_1
 G  c12_1
 G  c13_1
 G  c14_1
 G  c15_1
 G  c16_1
 G  c17_1
 G  c18_1
 G  c19_1
 G  c20_1
 G  c21_1
 G  c22_1
 G  c23_1
 G  c24_1
 G  c25_1
 G  c26_1
 G  c27_1
 G  c28_1
 G  c29_1
 G  c30_1
 G  c31_1
 G  c32_1
 G  c33_1
 G  c34_1
 G  c35_1
 G  c36_1
 G  c37_1
 G  c38_1
 G  c39_1
 G  c40_1
 G  c41_1
 G  c42_1
 G  c43_1
 G  c44_1
 G  c45_1
 G  c46_1
 G  c47_1
 G  c48_1
 G  c49_1
 G  c50_1
 G  c51_1
 G  c52_1
 G  c53_1
 G  c54_1
 G  c55_1
 G  c56_1
 G  c57_1
 G  c58_1
 G  c59_1
 G  c60_1
 G  c61_1
 G  c62_1
 G  c63_1
 G  c64_1
 G  c65_1
 G  c66_1
 G  c67_1
 G  c68_1
 G  c69_1
 G  c70_1
 G  c71_1
 G  c72_1
 G  c73_1
 G  c74_1
 G  c75_1
 G  c76_1
 G  c77_1
 G  c78_1
 G  c79_1
 G  c80_1
 G  c81_1
 G  c82_1
 G  c83_1
 G  c84_1
 G  c85_1
 G  c86_1
 G  c87_1
 G  c88_1
 G  c89_1
 G  c90_1
 G  c91_1
 G  c92_1
 G  c93_1
 G  c94_1
 G  c95_1
 G  c96_1
 G  c97_1
 G  c98_1
 G  c99_1
 G  c100_1
 G  c101_1
 G  c102_1
 G  c103_1
 G  c104_1
 G  c105_1
 G  c106_1
 G  c107_1
 G  c108_1
 G  c109_1
 G  c110_1
 G  c111_1
 G  c112_1
 G  c113_1
 G  c114_1
 G  c115_1
 G  c116_1
 G  c117_1
 G  c118_1
 G  c119_1
 G  c120_1
 G  c121_1
 G  c122_1
 G  c123_1
 G  c124_1
 G  c125_1
 G  c126_1
 G  c127_1
 G  c128_1
 G  c129_1
 G  c130_1
 G  c131_1
 G  c132_1
 G  c133_1
 G  c134_1
 G  c135_1
 G  c136_1
 G  c137_1
 G  c138_1
 G  c139_1
 G  c140_1
 G  c141_1
 G  c142_1
 G  c143_1
 G  c144_1
 G  c145_1
 G  c146_1
 G  c147_1
 G  c148_1
 G  c149_1
 G  c150_1
 G  c151_1
 G  c152_1
 G  c153_1
 G  c154_1
 G  c155_1
 G  c156_1
 G  c157_1
 G  c158_1
 G  c159_1
 G  c160_1
 G  c161_1
 G  c162_1
 G  c163_1
 G  c164_1
 G  c165_1
 G  c166_1
 G  c167_1
 G  c168_1
 G  c169_1
 G  c170_1
 G  c171_1
 G  c172_1
 G  c173_1
 G  c174_1
 G  c175_1
 G  c176_1
 G  c177_1
 G  c178_1
 G  c179_1
 G  c180_1
 G  c181_1
 G  c182_1
 G  c183_1
 G  c184_1
 G  c185_1
 G  c186_1
 G  c187_1
 G  c188_1
 G  c189_1
 G  c190_1
 G  c191_1
 G  c192_1
 G  c193_1
 G  c194_1
 G  c195_1
 G  c196_1
 G  c197_1
 G  c198_1
 G  c199_1
 G  c200_1
 G  c201_1
 G  c202_1
 G  c203_1
 G  c204_1
 G  c205_1
 G  c206_1
 G  c207_1
 G  c208_1
 G  c209_1
 G  c210_1
 G  c211_1
 G  c212_1
 G  c213_1
 G  c214_1
 G  c215_1
 G  c216_1
 G  c217_1
 G  c218_1
 G  c219_1
 G  c220_1
 G  c221_1
 G  c222_1
 G  c223_1
 G  c224_1
 G  c225_1
 G  c226_1
 G  c227_1
 G  c228_1
 G  c229_1
 G  c230_1
 G  c231_1
 G  c232_1
 G  c233_1
 G  c234_1
 G  c235_1
 G  c236_1
 G  c237_1
 G  c238_1
 G  c239_1
 G  c240_1
 G  c241_1
 G  c242_1
 G  c243_1
 G  c244_1
 G  c245_1
 G  c246_1
 G  c247_1
 G  c248_1
 G  c249_1
 G  c250_1
 G  c251_1
 G  c252_1
 G  c253_1
 G  c254_1
 G  c255_1
 G  c256_1
 G  c257_1
 G  c258_1
 G  c259_1
 G  c260_1
 G  c261_1
 G  c262_1
 G  c263_1
 G  c264_1
 G  c265_1
 G  c266_1
 G  c267_1
 G  c268_1
 G  c269_1
 G  c270_1
 G  c271_1
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
 E  c625
 E  c626
 E  c627
 E  c628
 E  c629
 E  c630
 E  c631
 E  c632
 E  c633
 E  c634
 E  c635
 E  c636
 E  c637
 E  c638
 E  c639
 E  c640
 E  c641
 E  c642
 E  c643
 E  c644
 E  c645
 E  c646
 E  c647
 E  c648
 E  c649
 E  c650
 E  c651
 E  c652
 E  c653
 E  c654
 E  c655
 E  c656
 E  c657
 E  c658
 E  c659
 E  c660
 E  c661
 E  c662
 E  c663
 E  c664
 E  c665
 E  c666
 E  c667
 E  c668
 E  c669
 E  c670
 E  c671
 E  c672
 E  c673
 E  c674
 E  c675
 E  c676
 E  c677
 E  c678
 E  c679
 E  c680
 E  c681
 E  c682
 E  c683
 E  c684
 E  c685
 E  c686
 E  c687
 E  c688
 E  c689
 E  c690
 E  c691
 E  c692
 E  c693
 E  c694
 E  c695
 E  c696
 E  c697
 E  c698
 E  c699
 E  c700
 E  c701
 E  c702
 E  c703
 E  c704
 E  c705
 E  c706
 E  c707
 E  c708
 E  c709
 E  c710
 E  c711
 E  c712
 E  c713
 E  c714
 E  c715
 E  c716
 E  c717
 E  c718
 E  c719
 E  c720
 E  c721
 E  c722
 E  c723
 E  c724
 E  c725
 E  c726
 E  c727
 E  c728
 E  c729
 E  c730
 E  c731
 E  c732
 E  c733
 E  c734
 E  c735
 E  c736
 E  c737
 E  c738
 E  c739
 E  c740
 E  c741
 E  c742
 E  c743
 E  c744
 E  c745
 E  c746
 E  c747
 E  c748
 E  c749
 E  c750
 E  c751
 E  c752
 E  c753
 E  c754
 E  c755
 E  c756
 E  c757
 E  c758
 E  c759
 E  c760
 E  c761
 E  c762
 E  c763
 E  c764
 E  c765
 E  c766
 E  c767
 E  c768
 E  c769
 E  c770
 E  c771
 E  c772
 E  c773
 E  c774
 E  c775
 E  c776
 E  c777
 E  c778
 E  c779
 E  c780
 E  c781
 E  c782
 E  c783
 E  c784
 E  c785
 E  c786
 E  c787
 E  c788
 E  c789
 E  c790
 E  c791
 E  c792
 E  c793
 E  c794
 E  c795
 E  c796
 E  c797
 E  c798
 E  c799
 E  c800
 E  c801
 E  c802
 E  c803
 E  c804
 E  c805
 E  c806
 E  c807
 E  c808
 E  c809
 E  c810
 E  c811
 E  c812
 E  c813
 E  c814
 E  c815
 E  c816
 E  c817
 E  c818
 E  c819
 E  c820
 E  c821
 E  c822
 E  c823
 E  c824
 E  c825
 E  c826
 E  c827
 E  c828
 E  c829
 E  c830
 E  c831
 E  c832
 E  c833
 E  c834
 E  c835
 E  c836
 E  c837
 E  c838
 E  c839
 E  c840
 E  c841
 E  c842
 E  c843
 E  c844
 E  c845
 E  c846
 E  c847
 E  c848
 E  c849
 E  c850
 E  c851
 E  c852
 E  c853
 E  c854
 E  c855
 E  c856
 E  c857
 E  c858
 E  c859
 E  c860
 E  c861
 E  c862
 E  c863
 E  c864
 E  c865
 E  c866
 E  c867
 E  c868
 E  c869
 E  c870
 E  c871
 E  c872
 E  c873
 E  c874
 E  c875
 E  c876
 E  c877
 E  c878
 E  c879
 E  c880
 E  c881
 E  c882
 E  c883
 E  c884
 E  c885
 E  c886
 E  c887
 E  c888
 E  c889
 E  c890
 E  c891
 E  c892
 E  c893
 E  c894
 E  c895
 E  c896
 E  c897
 E  c898
 E  c899
 E  c900
 E  c901
 E  c902
 E  c903
 E  c904
 E  c905
 E  c906
 E  c907
 E  c908
 E  c909
 E  c910
 E  c911
 E  c912
 E  c913
 E  c914
 E  c915
 E  c916
 E  c917
 E  c918
 E  c919
 E  c920
 E  c921
 E  c922
 E  c923
 E  c924
 E  c925
 E  c926
 E  c927
 E  c928
 E  c929
 E  c930
 E  c931
 E  c932
 E  c933
 E  c934
 E  c935
 E  c936
 E  c937
 E  c938
 E  c939
 E  c940
 E  c941
 E  c942
 E  c943
 E  c944
 E  c945
 E  c946
 E  c947
 E  c948
 E  c949
 E  c950
 E  c951
 E  c952
 E  c953
 E  c954
 E  c955
 E  c956
 E  c957
 E  c958
 E  c959
 E  c960
 E  c961
 E  c962
 E  c963
 E  c964
 E  c965
 E  c966
 E  c967
 E  c968
 E  c969
 E  c970
 E  c971
 E  c972
 E  c973
 E  c974
 E  c975
 E  c976
 E  c977
 E  c978
 E  c979
 E  c980
 E  c981
 E  c982
 E  c983
 E  c984
 E  c985
 E  c986
 E  c987
 E  c988
 E  c989
 E  c990
 E  c991
 E  c992
 E  c993
 E  c994
 E  c995
 E  c996
 E  c997
 E  c998
 E  c999
 E  c1000
 E  c1001
 E  c1002
 E  c1003
 E  c1004
 E  c1005
 E  c1006
 E  c1007
 E  c1008
 E  c1009
 E  c1010
 E  c1011
 E  c1012
 E  c1013
 E  c1014
 E  c1015
 E  c1016
 E  c1017
 E  c1018
 E  c1019
 E  c1020
 E  c1021
 E  c1022
 E  c1023
 E  c1024
 E  c1025
 E  c1026
 E  c1027
 E  c1028
 E  c1029
 E  c1030
 E  c1031
 E  c1032
 E  c1033
 E  c1034
 E  c1035
 E  c1036
 E  c1037
 E  c1038
 E  c1039
 E  c1040
 E  c1041
 E  c1042
 E  c1043
 E  c1044
 E  c1045
 E  c1046
 E  c1047
 E  c1048
 E  c1049
 E  c1050
 E  c1051
 E  c1052
 E  c1053
 E  c1054
 E  c1055
 E  c1056
 E  c1057
 E  c1058
 E  c1059
 E  c1060
 E  c1061
 E  c1062
 E  c1063
 E  c1064
 E  c1065
 E  c1066
 E  c1067
 E  c1068
 E  c1069
 E  c1070
 E  c1071
 E  c1072
 E  c1073
 E  c1074
 E  c1075
 E  c1076
 E  c1077
 E  c1078
 E  c1079
 E  c1080
 E  c1081
 E  c1082
 E  c1083
 E  c1084
 E  c1085
 E  c1086
 E  c1087
 E  c1088
 E  c1089
 E  c1090
 E  c1091
 E  c1092
 E  c1093
 E  c1094
 E  c1095
 E  c1096
 E  c1097
 E  c1098
 E  c1099
 E  c1100
 E  c1101
 E  c1102
 E  c1103
 E  c1104
 E  c1105
 E  c1106
 E  c1107
 E  c1108
 E  c1109
 E  c1110
 E  c1111
 E  c1112
 E  c1113
 E  c1114
 E  c1115
 E  c1116
 E  c1117
 E  c1118
 E  c1119
 E  c1120
 E  c1121
 E  c1122
 E  c1123
 E  c1124
 E  c1125
 E  c1126
 E  c1127
 E  c1128
 E  c1129
 E  c1130
 E  c1131
 E  c1132
 E  c1133
 E  c1134
 E  c1135
 E  c1136
 E  c1137
 E  c1138
 E  c1139
 E  c1140
 E  c1141
 E  c1142
 E  c1143
 E  c1144
 E  c1145
 E  c1146
 E  c1147
 E  c1148
 E  c1149
 E  c1150
 E  c1151
 E  c1152
 E  c1153
 E  c1154
 E  c1155
 E  c1156
 E  c1157
 E  c1158
 E  c1159
 E  c1160
 E  c1161
 E  c1162
 E  c1163
 E  c1164
 E  c1165
 E  c1166
 E  c1167
 E  c1168
 E  c1169
 E  c1170
 E  c1171
 E  c1172
 E  c1173
 E  c1174
 E  c1175
 E  c1176
 E  c1177
 E  c1178
 E  c1179
 E  c1180
 E  c1181
 E  c1182
 E  c1183
 E  c1184
 E  c1185
 E  c1186
 E  c1187
 E  c1188
 E  c1189
 E  c1190
 E  c1191
 E  c1192
 E  c1193
 E  c1194
 E  c1195
 E  c1196
 E  c1197
 E  c1198
 E  c1199
 E  c1200
 E  c1201
 E  c1202
 E  c1203
 E  c1204
 E  c1205
 E  c1206
 E  c1207
 E  c1208
 E  c1209
 E  c1210
 E  c1211
 E  c1212
 E  c1213
 E  c1214
 E  c1215
 E  c1216
 E  c1217
 E  c1218
 E  c1219
 E  c1220
 E  c1221
 E  c1222
 E  c1223
 E  c1224
 E  c1225
 E  c1226
 E  c1227
 E  c1228
 E  c1229
 E  c1230
 E  c1231
 E  c1232
 E  c1233
 E  c1234
 E  c1235
 E  c1236
 E  c1237
 E  c1238
 E  c1239
 E  c1240
 E  c1241
 E  c1242
 E  c1243
 E  c1244
 E  c1245
 E  c1246
 E  c1247
 E  c1248
 E  c1249
 E  c1250
 E  c1251
 E  c1252
 E  c1253
 E  c1254
 E  c1255
 E  c1256
 E  c1257
 E  c1258
 E  c1259
 E  c1260
 E  c1261
 E  c1262
 E  c1263
 E  c1264
 E  c1265
 E  c1266
 E  c1267
 E  c1268
 E  c1269
 E  c1270
 E  c1271
 E  c1272
 E  c1273
 E  c1274
 E  c1275
 E  c1276
 E  c1277
 E  c1278
 E  c1279
 E  c1280
 E  c1281
 E  c1282
 E  c1283
 E  c1284
 E  c1285
 E  c1286
 E  c1287
 E  c1288
 E  c1289
 E  c1290
 E  c1291
 E  c1292
 E  c1293
 E  c1294
 E  c1295
 E  c1296
 E  c1297
 E  c1298
 E  c1299
 E  c1300
 E  c1301
 E  c1302
 E  c1303
 E  c1304
 E  c1305
 E  c1306
 E  c1307
 E  c1308
 E  c1309
 E  c1310
 E  c1311
 E  c1312
 E  c1313
 E  c1314
 E  c1315
 E  c1316
 E  c1317
 E  c1318
 E  c1319
 E  c1320
 E  c1321
 E  c1322
 E  c1323
 E  c1324
 E  c1325
 E  c1326
 E  c1327
 E  c1328
 E  c1329
 E  c1330
 E  c1331
 E  c1332
 E  c1333
 E  c1334
 E  c1335
 E  c1336
 E  c1337
 E  c1338
 E  c1339
 E  c1340
 E  c1341
 E  c1342
 E  c1343
 E  c1344
 E  c1345
 E  c1346
 E  c1347
 E  c1348
 E  c1349
 E  c1350
 E  c1351
 E  c1352
 E  c1353
 E  c1354
 E  c1355
 E  c1356
 E  c1357
 E  c1358
 E  c1359
 E  c1360
 E  c1361
 E  c1362
 E  c1363
 E  c1364
 E  c1365
 E  c1366
 E  c1367
 E  c1368
 E  c1369
 E  c1370
 E  c1371
 E  c1372
 E  c1373
 E  c1374
 E  c1375
 E  c1376
 E  c1377
 E  c1378
 E  c1379
 E  c1380
 E  c1381
 E  c1382
 E  c1383
 E  c1384
 E  c1385
 E  c1386
 E  c1387
 E  c1388
 E  c1389
 E  c1390
 E  c1391
 E  c1392
 E  c1393
 E  c1394
 E  c1395
 E  c1396
 E  c1397
 E  c1398
 E  c1399
 E  c1400
 E  c1401
 E  c1402
 E  c1403
 E  c1404
 E  c1405
 E  c1406
 E  c1407
 E  c1408
 E  c1409
 E  c1410
 E  c1411
 E  c1412
 E  c1413
 E  c1414
 E  c1415
 E  c1416
 E  c1417
 E  c1418
 E  c1419
 E  c1420
 E  c1421
 E  c1422
 E  c1423
 E  c1424
 E  c1425
 E  c1426
 E  c1427
 E  c1428
 E  c1429
 E  c1430
 E  c1431
 E  c1432
 E  c1433
 E  c1434
 E  c1435
 E  c1436
 E  c1437
 E  c1438
 E  c1439
 E  c1440
 E  c1441
 E  c1442
 E  c1443
 E  c1444
 E  c1445
 E  c1446
 E  c1447
 E  c1448
 E  c1449
 E  c1450
 E  c1451
 E  c1452
 E  c1453
 E  c1454
 E  c1455
 E  c1456
 E  c1457
 E  c1458
 E  c1459
 E  c1460
 E  c1461
 E  c1462
 E  c1463
 E  c1464
 E  c1465
 E  c1466
 E  c1467
 E  c1468
 E  c1469
 E  c1470
 E  c1471
 E  c1472
 E  c1473
 E  c1474
 E  c1475
 E  c1476
 E  c1477
 E  c1478
 E  c1479
 E  c1480
 E  c1481
 E  c1482
 E  c1483
 E  c1484
 E  c1485
 E  c1486
 E  c1487
 E  c1488
 E  c1489
 E  c1490
 E  c1491
 E  c1492
 E  c1493
 E  c1494
 E  c1495
 E  c1496
 E  c1497
 E  c1498
 E  c1499
 E  c1500
 E  c1501
 E  c1502
 E  c1503
 E  c1504
 E  c1505
 E  c1506
 E  c1507
 E  c1508
 E  c1509
 E  c1510
 E  c1511
 E  c1512
 E  c1513
 E  c1514
 E  c1515
 E  c1516
 E  c1517
 E  c1518
 E  c1519
 E  c1520
 E  c1521
 E  c1522
 E  c1523
 E  c1524
 E  c1525
 E  c1526
 E  c1527
 E  c1528
 E  c1529
 E  c1530
 E  c1531
 E  c1532
 E  c1533
 E  c1534
 E  c1535
 E  c1536
 E  c1537
 E  c1538
 E  c1539
 E  c1540
 E  c1541
 E  c1542
 E  c1543
 E  c1544
 E  c1545
 E  c1546
 E  c1547
 E  c1548
 E  c1549
 E  c1550
 E  c1551
 E  c1552
 E  c1553
 E  c1554
 E  c1555
 E  c1556
 E  c1557
 E  c1558
 E  c1559
 E  c1560
 E  c1561
 E  c1562
 E  c1563
 E  c1564
 E  c1565
 E  c1566
 E  c1567
 E  c1568
 E  c1569
 E  c1570
 E  c1571
 E  c1572
 E  c1573
 E  c1574
 E  c1575
 E  c1576
 E  c1577
 E  c1578
 E  c1579
 E  c1580
 E  c1581
 E  c1582
 E  c1583
 E  c1584
 E  c1585
 E  c1586
 E  c1587
 E  c1588
 E  c1589
 E  c1590
 E  c1591
 E  c1592
 E  c1593
 E  c1594
 E  c1595
 E  c1596
 E  c1597
 E  c1598
 E  c1599
 E  c1600
 E  c1601
 E  c1602
 E  c1603
 E  c1604
 E  c1605
 E  c1606
 E  c1607
 E  c1608
 E  c1609
 E  c1610
 E  c1611
 E  c1612
 E  c1613
 E  c1614
 E  c1615
 E  c1616
 E  c1617
 E  c1618
 E  c1619
 E  c1620
 E  c1621
 E  c1622
 E  c1623
 E  c1624
 E  c1625
 E  c1626
 E  c1627
 E  c1628
 E  c1629
 E  c1630
 E  c1631
 E  c1632
 E  c1633
 E  c1634
 E  c1635
 E  c1636
 E  c1637
 E  c1638
 E  c1639
 E  c1640
 E  c1641
 E  c1642
 E  c1643
 E  c1644
 E  c1645
 E  c1646
 E  c1647
 E  c1648
 E  c1649
 E  c1650
 E  c1651
 E  c1652
 E  c1653
 E  c1654
 E  c1655
 E  c1656
 E  c1657
 E  c1658
 E  c1659
 E  c1660
 E  c1661
 E  c1662
 E  c1663
 E  c1664
 E  c1665
 E  c1666
 E  c1667
 E  c1668
 E  c1669
 E  c1670
 E  c1671
 E  c1672
 E  c1673
 E  c1674
 E  c1675
 E  c1676
 E  c1677
 E  c1678
 E  c1679
 E  c1680
 E  c1681
 E  c1682
 E  c1683
 E  c1684
 E  c1685
 E  c1686
 E  c1687
 E  c1688
 E  c1689
 E  c1690
 E  c1691
 E  c1692
 E  c1693
 E  c1694
 E  c1695
 E  c1696
 E  c1697
 E  c1698
 E  c1699
 E  c1700
 E  c1701
 E  c1702
 E  c1703
 E  c1704
 E  c1705
 E  c1706
 E  c1707
 E  c1708
 E  c1709
 E  c1710
 E  c1711
 E  c1712
 E  c1713
 E  c1714
 E  c1715
 E  c1716
 E  c1717
 E  c1718
 E  c1719
 E  c1720
 E  c1721
 E  c1722
 E  c1723
 E  c1724
 E  c1725
 E  c1726
 E  c1727
 E  c1728
 E  c1729
 E  c1730
 E  c1731
 E  c1732
 E  c1733
 E  c1734
 E  c1735
 E  c1736
 E  c1737
 E  c1738
 E  c1739
 E  c1740
 E  c1741
 E  c1742
 E  c1743
 E  c1744
 E  c1745
 E  c1746
 E  c1747
 E  c1748
 E  c1749
 E  c1750
 E  c1751
 E  c1752
 E  c1753
 E  c1754
 E  c1755
 E  c1756
 E  c1757
 E  c1758
 E  c1759
 E  c1760
 E  c1761
 E  c1762
 E  c1763
 E  c1764
 E  c1765
 E  c1766
 E  c1767
 E  c1768
 E  c1769
 E  c1770
 E  c1771
 E  c1772
 E  c1773
 E  c1774
 E  c1775
 E  c1776
 E  c1777
 E  c1778
 E  c1779
 E  c1780
 E  c1781
 E  c1782
 E  c1783
 E  c1784
 E  c1785
 E  c1786
 E  c1787
 E  c1788
 E  c1789
 E  c1790
 E  c1791
 E  c1792
 E  c1793
 E  c1794
 E  c1795
 E  c1796
 E  c1797
 E  c1798
 E  c1799
 E  c1800
 E  c1801
 E  c1802
 E  c1803
 E  c1804
 E  c1805
 E  c1806
 E  c1807
 E  c1808
 E  c1809
 E  c1810
 E  c1811
 E  c1812
 E  c1813
 E  c1814
 E  c1815
 E  c1816
 E  c1817
 E  c1818
 E  c1819
 E  c1820
 E  c1821
 E  c1822
 E  c1823
 E  c1824
 E  c1825
 E  c1826
 E  c1827
 E  c1828
 E  c1829
 E  c1830
 E  c1831
 E  c1832
 E  c1833
 E  c1834
 E  c1835
 E  c1836
 E  c1837
 E  c1838
 E  c1839
 E  c1840
 E  c1841
 E  c1842
 E  c1843
 E  c1844
 E  c1845
 E  c1846
 E  c1847
 E  c1848
 E  c1849
 E  c1850
 E  c1851
 E  c1852
 E  c1853
 E  c1854
 E  c1855
 E  c1856
 E  c1857
 E  c1858
 E  c1859
 E  c1860
 E  c1861
 E  c1862
 E  c1863
 E  c1864
 E  c1865
 E  c1866
 E  c1867
 E  c1868
 E  c1869
 E  c1870
 E  c1871
 E  c1872
 E  c1873
 E  c1874
 E  c1875
 E  c1876
 E  c1877
 E  c1878
 E  c1879
 E  c1880
 E  c1881
 E  c1882
 E  c1883
 E  c1884
 E  c1885
 E  c1886
 E  c1887
 E  c1888
 E  c1889
 E  c1890
 E  c1891
 E  c1892
 E  c1893
 E  c1894
 E  c1895
 E  c1896
 E  c1897
 E  c1898
 E  c1899
 E  c1900
 E  c1901
 E  c1902
 E  c1903
 E  c1904
 E  c1905
 E  c1906
 E  c1907
 E  c1908
 E  c1909
 E  c1910
 E  c1911
 E  c1912
 E  c1913
 E  c1914
 E  c1915
 E  c1916
 E  c1917
 E  c1918
 E  c1919
 E  c1920
 E  c1921
 E  c1922
 E  c1923
 E  c1924
 E  c1925
 E  c1926
 E  c1927
 E  c1928
 E  c1929
 E  c1930
 E  c1931
 E  c1932
 E  c1933
 E  c1934
 E  c1935
 E  c1936
 E  c1937
 E  c1938
 E  c1939
 E  c1940
 E  c1941
 E  c1942
 E  c1943
 E  c1944
 E  c1945
 E  c1946
 E  c1947
 E  c1948
 E  c1949
 E  c1950
 E  c1951
 E  c1952
 E  c1953
 E  c1954
 E  c1955
 E  c1956
 E  c1957
 E  c1958
 E  c1959
 E  c1960
 E  c1961
 E  c1962
 E  c1963
 E  c1964
 E  c1965
 E  c1966
 E  c1967
 E  c1968
 E  c1969
 E  c1970
 E  c1971
 E  c1972
 E  c1973
 E  c1974
 E  c1975
 E  c1976
 E  c1977
 E  c1978
 E  c1979
 E  c1980
 E  c1981
 E  c1982
 E  c1983
 E  c1984
 E  c1985
 E  c1986
 E  c1987
 E  c1988
 E  c1989
 E  c1990
 E  c1991
 E  c1992
 E  c1993
 E  c1994
 E  c1995
 E  c1996
 E  c1997
 E  c1998
 E  c1999
 E  c2000
 E  c2001
 E  c2002
 E  c2003
 E  c2004
 E  c2005
 E  c2006
 E  c2007
 E  c2008
 E  c2009
 E  c2010
 E  c2011
 E  c2012
 E  c2013
 E  c2014
 E  c2015
 E  c2016
 E  c2017
 E  c2018
 E  c2019
 E  c2020
 E  c2021
 E  c2022
 E  c2023
 E  c2024
 E  c2025
 E  c2026
 E  c2027
 E  c2028
 E  c2029
 E  c2030
 E  c2031
 E  c2032
 E  c2033
 E  c2034
 E  c2035
 E  c2036
 E  c2037
 E  c2038
 E  c2039
 E  c2040
 E  c2041
 E  c2042
 E  c2043
 E  c2044
 E  c2045
 E  c2046
 E  c2047
 E  c2048
 E  c2049
 E  c2050
 E  c2051
 E  c2052
 E  c2053
 E  c2054
 E  c2055
 E  c2056
 E  c2057
 E  c2058
 E  c2059
 E  c2060
 E  c2061
 E  c2062
 E  c2063
 E  c2064
 E  c2065
 E  c2066
 E  c2067
 E  c2068
 E  c2069
 E  c2070
 E  c2071
 E  c2072
 E  c2073
 E  c2074
 E  c2075
 E  c2076
 E  c2077
 E  c2078
 E  c2079
 E  c2080
 E  c2081
 E  c2082
 E  c2083
 E  c2084
 E  c2085
 E  c2086
 E  c2087
 E  c2088
 E  c2089
 E  c2090
 E  c2091
 E  c2092
 E  c2093
 E  c2094
 E  c2095
 E  c2096
 E  c2097
 E  c2098
 E  c2099
 E  c2100
 E  c2101
 E  c2102
 E  c2103
 E  c2104
 E  c2105
 E  c2106
 E  c2107
 E  c2108
 E  c2109
 E  c2110
 E  c2111
 E  c2112
 E  c2113
 E  c2114
 E  c2115
 E  c2116
 E  c2117
 E  c2118
 E  c2119
 E  c2120
 E  c2121
 E  c2122
 E  c2123
 E  c2124
 E  c2125
 E  c2126
 E  c2127
 E  c2128
 E  c2129
 E  c2130
 E  c2131
 E  c2132
 E  c2133
 E  c2134
 E  c2135
 E  c2136
 E  c2137
 E  c2138
 E  c2139
 E  c2140
 E  c2141
 E  c2142
 E  c2143
 E  c2144
 E  c2145
 E  c2146
 E  c2147
 E  c2148
 E  c2149
 E  c2150
 E  c2151
 E  c2152
 E  c2153
 E  c2154
 E  c2155
 E  c2156
 E  c2157
 E  c2158
 E  c2159
 E  c2160
 E  c2161
 E  c2162
 E  c2163
 E  c2164
 E  c2165
 E  c2166
 E  c2167
 E  c2168
 E  c2169
 E  c2170
 E  c2171
 E  c2172
 E  c2173
 E  c2174
 E  c2175
 E  c2176
 E  c2177
 E  c2178
 E  c2179
 E  c2180
 E  c2181
 E  c2182
 E  c2183
 E  c2184
 E  c2185
 E  c2186
 E  c2187
 E  c2188
 E  c2189
 E  c2190
 E  c2191
 E  c2192
 E  c2193
 E  c2194
 E  c2195
 E  c2196
 E  c2197
 E  c2198
 E  c2199
 E  c2200
 E  c2201
 E  c2202
 E  c2203
 E  c2204
 E  c2205
 E  c2206
 E  c2207
 E  c2208
 E  c2209
 E  c2210
 E  c2211
 E  c2212
 E  c2213
 E  c2214
 E  c2215
 E  c2216
 E  c2217
 E  c2218
 E  c2219
 E  c2220
 E  c2221
 E  c2222
 E  c2223
 E  c2224
 E  c2225
 E  c2226
 E  c2227
 E  c2228
 E  c2229
 E  c2230
 E  c2231
 E  c2232
 E  c2233
 E  c2234
 E  c2235
 E  c2236
 E  c2237
 E  c2238
 E  c2239
 E  c2240
 E  c2241
 E  c2242
 E  c2243
 E  c2244
 E  c2245
 E  c2246
 E  c2247
 E  c2248
 E  c2249
 E  c2250
 E  c2251
 E  c2252
 E  c2253
 E  c2254
 E  c2255
 E  c2256
 E  c2257
 E  c2258
 E  c2259
 E  c2260
 E  c2261
 E  c2262
 E  c2263
 E  c2264
 E  c2265
 E  c2266
 E  c2267
 E  c2268
 E  c2269
 E  c2270
 E  c2271
 E  c2272
 E  c2273
 E  c2274
 E  c2275
 E  c2276
 E  c2277
 E  c2278
 E  c2279
 E  c2280
 E  c2281
 E  c2282
 E  c2283
 E  c2284
 E  c2285
 E  c2286
 E  c2287
 E  c2288
 E  c2289
 E  c2290
 E  c2291
 E  c2292
 E  c2293
 E  c2294
 E  c2295
 E  c2296
 E  c2297
 E  c2298
 E  c2299
 E  c2300
 E  c2301
 E  c2302
 E  c2303
 E  c2304
 E  c2305
 E  c2306
 E  c2307
 E  c2308
 E  c2309
 E  c2310
 E  c2311
 E  c2312
 E  c2313
 E  c2314
 E  c2315
 E  c2316
 E  c2317
 E  c2318
 E  c2319
 E  c2320
 E  c2321
 E  c2322
 E  c2323
 E  c2324
 E  c2325
 E  c2326
 E  c2327
 E  c2328
 E  c2329
 E  c2330
 E  c2331
 E  c2332
 E  c2333
 E  c2334
 E  c2335
 E  c2336
 E  c2337
 E  c2338
 E  c2339
 E  c2340
 E  c2341
 E  c2342
 E  c2343
 E  c2344
 E  c2345
 E  c2346
 E  c2347
 E  c2348
 E  c2349
 E  c2350
 E  c2351
 E  c2352
 E  c2353
 E  c2354
 E  c2355
 E  c2356
 E  c2357
 E  c2358
 E  c2359
 E  c2360
 E  c2361
 E  c2362
 E  c2363
 E  c2364
 E  c2365
 E  c2366
 E  c2367
 E  c2368
 E  c2369
 E  c2370
 E  c2371
 E  c2372
 E  c2373
 E  c2374
 E  c2375
 E  c2376
 E  c2377
 E  c2378
 E  c2379
 E  c2380
 E  c2381
 E  c2382
 E  c2383
 E  c2384
 E  c2385
 E  c2386
 E  c2387
 E  c2388
 E  c2389
 E  c2390
 E  c2391
 E  c2392
 E  c2393
 E  c2394
 E  c2395
 E  c2396
 E  c2397
 E  c2398
 E  c2399
 E  c2400
 E  c2401
 E  c2402
 E  c2403
 E  c2404
 E  c2405
 E  c2406
 E  c2407
 E  c2408
 E  c2409
 E  c2410
 E  c2411
 E  c2412
 E  c2413
 E  c2414
 E  c2415
 E  c2416
 E  c2417
 E  c2418
 E  c2419
 E  c2420
 E  c2421
 E  c2422
 E  c2423
 E  c2424
 E  c2425
 E  c2426
 E  c2427
 E  c2428
 E  c2429
 E  c2430
 E  c2431
 E  c2432
 E  c2433
 E  c2434
 E  c2435
 E  c2436
 E  c2437
 E  c2438
 E  c2439
 E  c2440
 E  c2441
 E  c2442
 E  c2443
 E  c2444
 E  c2445
 E  c2446
 E  c2447
 E  c2448
 E  c2449
 E  c2450
 E  c2451
 E  c2452
 E  c2453
 E  c2454
 E  c2455
 E  c2456
 E  c2457
 E  c2458
 E  c2459
 E  c2460
 E  c2461
 E  c2462
 E  c2463
 E  c2464
 E  c2465
 E  c2466
 E  c2467
 E  c2468
 E  c2469
 E  c2470
 E  c2471
 E  c2472
 E  c2473
 E  c2474
 E  c2475
 E  c2476
 E  c2477
 E  c2478
 E  c2479
 E  c2480
 E  c2481
 E  c2482
 E  c2483
 E  c2484
 E  c2485
 E  c2486
 E  c2487
 E  c2488
 E  c2489
 E  c2490
 E  c2491
 E  c2492
 E  c2493
 E  c2494
 E  c2495
 E  c2496
 E  c2497
 E  c2498
 E  c2499
 E  c2500
 E  c2501
 E  c2502
 E  c2503
 E  c2504
 E  c2505
 E  c2506
 E  c2507
 E  c2508
 E  c2509
 E  c2510
 E  c2511
 E  c2512
 E  c2513
 E  c2514
 E  c2515
 E  c2516
 E  c2517
 E  c2518
 E  c2519
 E  c2520
 E  c2521
 E  c2522
 E  c2523
 E  c2524
 E  c2525
 E  c2526
 E  c2527
 E  c2528
 E  c2529
 E  c2530
 E  c2531
 E  c2532
 E  c2533
 E  c2534
 E  c2535
 E  c2536
 E  c2537
 E  c2538
 E  c2539
 E  c2540
 E  c2541
 E  c2542
 E  c2543
 E  c2544
 E  c2545
 E  c2546
 E  c2547
 E  c2548
 E  c2549
 E  c2550
 E  c2551
 E  c2552
 E  c2553
 E  c2554
 E  c2555
 E  c2556
 E  c2557
 E  c2558
 E  c2559
 E  c2560
 E  c2561
 E  c2562
 E  c2563
 E  c2564
 E  c2565
 E  c2566
 E  c2567
 E  c2568
 E  c2569
 E  c2570
 E  c2571
 E  c2572
 E  c2573
 E  c2574
 E  c2575
 E  c2576
 E  c2577
 E  c2578
 E  c2579
 E  c2580
 E  c2581
 E  c2582
 E  c2583
 E  c2584
 E  c2585
 E  c2586
 E  c2587
 E  c2588
 E  c2589
 E  c2590
 E  c2591
 E  c2592
 E  c2593
 E  c2594
 E  c2595
 E  c2596
 E  c2597
 E  c2598
 E  c2599
 E  c2600
 E  c2601
 E  c2602
 E  c2603
 E  c2604
 E  c2605
 E  c2606
 E  c2607
 E  c2608
 E  c2609
 E  c2610
 E  c2611
 E  c2612
 E  c2613
 E  c2614
 E  c2615
 E  c2616
 E  c2617
 E  c2618
 E  c2619
 E  c2620
 E  c2621
 E  c2622
 E  c2623
 E  c2624
 E  c2625
 E  c2626
 E  c2627
 E  c2628
 E  c2629
 E  c2630
 E  c2631
 E  c2632
 E  c2633
 E  c2634
 E  c2635
 E  c2636
 E  c2637
 E  c2638
 E  c2639
 E  c2640
 E  c2641
 E  c2642
 E  c2643
 E  c2644
 E  c2645
 E  c2646
 E  c2647
 E  c2648
 E  c2649
 E  c2650
 E  c2651
 E  c2652
 E  c2653
 E  c2654
 E  c2655
 E  c2656
 E  c2657
 E  c2658
 E  c2659
 E  c2660
 E  c2661
 E  c2662
 E  c2663
 E  c2664
 E  c2665
 E  c2666
 E  c2667
 E  c2668
 E  c2669
 E  c2670
 E  c2671
 E  c2672
 E  c2673
 E  c2674
 E  c2675
 E  c2676
 E  c2677
 E  c2678
 E  c2679
 E  c2680
 E  c2681
 E  c2682
 E  c2683
 E  c2684
 E  c2685
 E  c2686
 E  c2687
 E  c2688
 E  c2689
 E  c2690
 E  c2691
 E  c2692
 E  c2693
 E  c2694
 E  c2695
 E  c2696
 E  c2697
 E  c2698
 E  c2699
 E  c2700
 E  c2701
 E  c2702
 E  c2703
 E  c2704
 E  c2705
 E  c2706
 E  c2707
 E  c2708
 E  c2709
 E  c2710
 E  c2711
 E  c2712
 E  c2713
 E  c2714
 E  c2715
 E  c2716
 E  c2717
 E  c2718
 E  c2719
 E  c2720
 E  c2721
 E  c2722
 E  c2723
 E  c2724
 E  c2725
 E  c2726
 E  c2727
 E  c2728
 E  c2729
 E  c2730
 E  c2731
 E  c2732
 E  c2733
 E  c2734
 E  c2735
 E  c2736
 E  c2737
 E  c2738
 E  c2739
 E  c2740
 E  c2741
 E  c2742
 E  c2743
 E  c2744
 E  c2745
 E  c2746
 E  c2747
 E  c2748
 E  c2749
 E  c2750
 E  c2751
 E  c2752
 E  c2753
 E  c2754
 E  c2755
 E  c2756
 E  c2757
 E  c2758
 E  c2759
 E  c2760
 E  c2761
 E  c2762
 E  c2763
 E  c2764
 E  c2765
 E  c2766
 E  c2767
 E  c2768
 E  c2769
 E  c2770
 E  c2771
 E  c2772
 E  c2773
 E  c2774
 E  c2775
 E  c2776
 E  c2777
 E  c2778
 E  c2779
 E  c2780
 E  c2781
 E  c2782
 E  c2783
 E  c2784
 E  c2785
 E  c2786
 E  c2787
 E  c2788
 E  c2789
 E  c2790
 E  c2791
 E  c2792
 E  c2793
 E  c2794
 E  c2795
 E  c2796
 E  c2797
 E  c2798
 E  c2799
 E  c2800
 E  c2801
 E  c2802
 E  c2803
 E  c2804
 E  c2805
 E  c2806
 E  c2807
 E  c2808
 E  c2809
 E  c2810
 E  c2811
 E  c2812
 E  c2813
 E  c2814
 E  c2815
 E  c2816
 E  c2817
 E  c2818
 E  c2819
 E  c2820
 E  c2821
 E  c2822
 E  c2823
 E  c2824
 E  c2825
 E  c2826
 E  c2827
 E  c2828
 E  c2829
 E  c2830
 E  c2831
 E  c2832
 E  c2833
 E  c2834
 E  c2835
 E  c2836
 E  c2837
 E  c2838
 E  c2839
 E  c2840
 E  c2841
 E  c2842
 E  c2843
 E  c2844
 E  c2845
 E  c2846
 E  c2847
 E  c2848
 E  c2849
 E  c2850
 E  c2851
 E  c2852
 E  c2853
 E  c2854
 E  c2855
 E  c2856
 E  c2857
 E  c2858
 E  c2859
 E  c2860
 E  c2861
 E  c2862
 E  c2863
 E  c2864
 E  c2865
 E  c2866
 E  c2867
 E  c2868
 E  c2869
 E  c2870
 E  c2871
 E  c2872
 E  c2873
 E  c2874
 E  c2875
 E  c2876
 E  c2877
 E  c2878
 E  c2879
 E  c2880
 E  c2881
 E  c2882
 E  c2883
 E  c2884
 E  c2885
 E  c2886
 E  c2887
 E  c2888
 E  c2889
 E  c2890
 E  c2891
 E  c2892
 E  c2893
 E  c2894
 E  c2895
 E  c2896
 E  c2897
 E  c2898
 E  c2899
 E  c2900
 E  c2901
 E  c2902
 E  c2903
 E  c2904
 E  c2905
 E  c2906
 E  c2907
 E  c2908
 E  c2909
 E  c2910
 E  c2911
 E  c2912
 E  c2913
 E  c2914
 E  c2915
 E  c2916
 E  c2917
 E  c2918
 E  c2919
 E  c2920
 E  c2921
 E  c2922
 E  c2923
 E  c2924
 E  c2925
 E  c2926
 E  c2927
 E  c2928
 E  c2929
 E  c2930
 E  c2931
 E  c2932
 E  c2933
 E  c2934
 E  c2935
 E  c2936
 E  c2937
 E  c2938
 E  c2939
 E  c2940
 E  c2941
 E  c2942
 E  c2943
 E  c2944
 E  c2945
 E  c2946
 E  c2947
 E  c2948
 E  c2949
 E  c2950
 E  c2951
 E  c2952
 E  c2953
 E  c2954
 E  c2955
 E  c2956
 E  c2957
 E  c2958
 E  c2959
 E  c2960
 E  c2961
 E  c2962
 E  c2963
 E  c2964
 E  c2965
 E  c2966
 E  c2967
 E  c2968
 E  c2969
 E  c2970
 E  c2971
 E  c2972
 E  c2973
 E  c2974
 E  c2975
 E  c2976
 E  c2977
 E  c2978
 E  c2979
 E  c2980
 E  c2981
 E  c2982
 E  c2983
 E  c2984
 E  c2985
 E  c2986
 E  c2987
 E  c2988
 E  c2989
 E  c2990
 E  c2991
 E  c2992
 E  c2993
 E  c2994
 E  c2995
 E  c2996
 E  c2997
 E  c2998
 E  c2999
 E  c3000
 E  c3001
 E  c3002
 E  c3003
 E  c3004
 E  c3005
 E  c3006
 E  c3007
 E  c3008
 E  c3009
 E  c3010
 E  c3011
 E  c3012
 E  c3013
 E  c3014
 E  c3015
 E  c3016
 E  c3017
 E  c3018
 E  c3019
 E  c3020
 E  c3021
 E  c3022
 E  c3023
 E  c3024
 E  c3025
 E  c3026
 E  c3027
 E  c3028
 E  c3029
 E  c3030
 E  c3031
 E  c3032
 E  c3033
 E  c3034
 E  c3035
 E  c3036
 E  c3037
 E  c3038
 E  c3039
 E  c3040
 E  c3041
 E  c3042
 E  c3043
 E  c3044
 E  c3045
 E  c3046
 E  c3047
 E  c3048
 E  c3049
 E  c3050
 E  c3051
 E  c3052
 E  c3053
 E  c3054
 E  c3055
 E  c3056
 E  c3057
 E  c3058
 E  c3059
 E  c3060
 E  c3061
 E  c3062
 E  c3063
 E  c3064
 E  c3065
 E  c3066
 E  c3067
 E  c3068
 E  c3069
 E  c3070
 E  c3071
 E  c3072
 E  c3073
 E  c3074
 E  c3075
 E  c3076
 E  c3077
 E  c3078
 E  c3079
 E  c3080
 E  c3081
 E  c3082
 E  c3083
 E  c3084
 E  c3085
 E  c3086
 E  c3087
 E  c3088
 E  c3089
 E  c3090
 E  c3091
 E  c3092
 E  c3093
 E  c3094
 E  c3095
 E  c3096
 E  c3097
 E  c3098
 E  c3099
 E  c3100
 E  c3101
 E  c3102
 E  c3103
 E  c3104
 E  c3105
 E  c3106
 E  c3107
 E  c3108
 E  c3109
 E  c3110
 E  c3111
 E  c3112
 E  c3113
 E  c3114
 E  c3115
 E  c3116
 E  c3117
 E  c3118
 E  c3119
 E  c3120
 E  c3121
 E  c3122
 E  c3123
 E  c3124
 E  c3125
 E  c3126
 E  c3127
 E  c3128
 E  c3129
 E  c3130
 E  c3131
 E  c3132
 E  c3133
 E  c3134
 E  c3135
 E  c3136
 E  c3137
 E  c3138
 E  c3139
 E  c3140
 E  c3141
 E  c3142
 E  c3143
 E  c3144
 E  c3145
 E  c3146
 E  c3147
 E  c3148
 E  c3149
 E  c3150
 E  c3151
 E  c3152
 E  c3153
 E  c3154
 E  c3155
 E  c3156
 E  c3157
 E  c3158
 E  c3159
 E  c3160
 E  c3161
 E  c3162
 E  c3163
 E  c3164
 E  c3165
 E  c3166
 E  c3167
 E  c3168
 E  c3169
 E  c3170
 E  c3171
 E  c3172
 E  c3173
 E  c3174
 E  c3175
 E  c3176
 E  c3177
 E  c3178
 E  c3179
 E  c3180
 E  c3181
 E  c3182
 E  c3183
 E  c3184
 E  c3185
 E  c3186
 E  c3187
 E  c3188
 E  c3189
 E  c3190
 E  c3191
 E  c3192
 E  c3193
 E  c3194
 E  c3195
 E  c3196
 E  c3197
 E  c3198
 E  c3199
 E  c3200
 E  c3201
 E  c3202
 E  c3203
 E  c3204
 E  c3205
 E  c3206
 E  c3207
 E  c3208
 E  c3209
 E  c3210
 E  c3211
 E  c3212
 E  c3213
 E  c3214
 E  c3215
 E  c3216
 E  c3217
 E  c3218
 E  c3219
 E  c3220
 E  c3221
 E  c3222
 E  c3223
 E  c3224
 E  c3225
 E  c3226
 E  c3227
 E  c3228
 E  c3229
 E  c3230
 E  c3231
 E  c3232
 E  c3233
 E  c3234
 E  c3235
 E  c3236
 E  c3237
 E  c3238
 E  c3239
 E  c3240
 E  c3241
 E  c3242
 E  c3243
 E  c3244
 E  c3245
 E  c3246
 E  c3247
 E  c3248
 E  c3249
 E  c3250
 E  c3251
 E  c3252
 E  c3253
 E  c3254
 E  c3255
 E  c3256
 E  c3257
 E  c3258
 E  c3259
 E  c3260
 E  c3261
 E  c3262
 E  c3263
 E  c3264
 E  c3265
 E  c3266
 E  c3267
 E  c3268
 E  c3269
 E  c3270
 E  c3271
 E  c3272
 E  c3273
 E  c3274
 E  c3275
 E  c3276
 E  c3277
 E  c3278
 E  c3279
 E  c3280
 E  c3281
 E  c3282
 E  c3283
 E  c3284
 E  c3285
 E  c3286
 E  c3287
 E  c3288
 E  c3289
 E  c3290
 E  c3291
 E  c3292
 E  c3293
 E  c3294
 E  c3295
 E  c3296
 E  c3297
 E  c3298
 E  c3299
 E  c3300
 E  c3301
 E  c3302
 E  c3303
 E  c3304
 E  c3305
 E  c3306
 E  c3307
 E  c3308
 E  c3309
 E  c3310
 E  c3311
 E  c3312
 E  c3313
 E  c3314
 E  c3315
 E  c3316
 E  c3317
 E  c3318
 E  c3319
 E  c3320
 E  c3321
 E  c3322
 E  c3323
 E  c3324
 E  c3325
 E  c3326
 E  c3327
 E  c3328
 E  c3329
 E  c3330
 E  c3331
 E  c3332
 E  c3333
 E  c3334
 E  c3335
 E  c3336
 E  c3337
 E  c3338
 E  c3339
 E  c3340
 E  c3341
 E  c3342
 E  c3343
 E  c3344
 E  c3345
 E  c3346
 E  c3347
 E  c3348
 E  c3349
 E  c3350
 E  c3351
 E  c3352
 E  c3353
 E  c3354
 E  c3355
 E  c3356
 E  c3357
 E  c3358
 E  c3359
 E  c3360
 E  c3361
 E  c3362
 E  c3363
 E  c3364
 E  c3365
 E  c3366
 E  c3367
 E  c3368
 E  c3369
 E  c3370
 E  c3371
 E  c3372
 E  c3373
 E  c3374
 E  c3375
 E  c3376
 E  c3377
 E  c3378
 E  c3379
 E  c3380
 E  c3381
 E  c3382
 E  c3383
 E  c3384
 E  c3385
 E  c3386
 E  c3387
 E  c3388
 E  c3389
 E  c3390
 E  c3391
 E  c3392
 E  c3393
 E  c3394
 E  c3395
 E  c3396
 E  c3397
 E  c3398
 E  c3399
 E  c3400
 E  c3401
 E  c3402
 E  c3403
 E  c3404
 E  c3405
 E  c3406
 E  c3407
 E  c3408
 E  c3409
 E  c3410
 E  c3411
 E  c3412
 E  c3413
 E  c3414
 E  c3415
 E  c3416
 E  c3417
 E  c3418
 E  c3419
 E  c3420
 E  c3421
 E  c3422
 E  c3423
 E  c3424
 E  c3425
 E  c3426
 E  c3427
 E  c3428
 E  c3429
 E  c3430
 E  c3431
 E  c3432
 E  c3433
 E  c3434
 E  c3435
 E  c3436
 E  c3437
 E  c3438
 E  c3439
 E  c3440
 E  c3441
 E  c3442
 E  c3443
 E  c3444
 E  c3445
 E  c3446
 E  c3447
 E  c3448
 E  c3449
 E  c3450
 E  c3451
 E  c3452
 E  c3453
 E  c3454
 E  c3455
 E  c3456
 E  c3457
 E  c3458
 E  c3459
 E  c3460
 E  c3461
 E  c3462
 E  c3463
 E  c3464
 E  c3465
 E  c3466
 E  c3467
 E  c3468
 E  c3469
 E  c3470
 E  c3471
 E  c3472
 E  c3473
 E  c3474
 E  c3475
 E  c3476
 E  c3477
 E  c3478
 E  c3479
 E  c3480
 E  c3481
 E  c3482
 E  c3483
 E  c3484
 E  c3485
 E  c3486
 E  c3487
 E  c3488
 E  c3489
 E  c3490
 E  c3491
 E  c3492
 E  c3493
 E  c3494
 E  c3495
 E  c3496
 E  c3497
 E  c3498
 E  c3499
 E  c3500
 E  c3501
 E  c3502
 E  c3503
 E  c3504
 E  c3505
 E  c3506
 E  c3507
 E  c3508
 E  c3509
 E  c3510
 E  c3511
 E  c3512
 E  c3513
 E  c3514
 E  c3515
 E  c3516
 E  c3517
 E  c3518
 E  c3519
 E  c3520
 E  c3521
 E  c3522
 E  c3523
 E  c3524
 E  c3525
 E  c3526
 E  c3527
 E  c3528
 E  c3529
 E  c3530
 E  c3531
 E  c3532
 E  c3533
 E  c3534
 E  c3535
 E  c3536
 E  c3537
 E  c3538
 E  c3539
 E  c3540
 E  c3541
 E  c3542
 E  c3543
 E  c3544
 E  c3545
 E  c3546
 E  c3547
 E  c3548
 E  c3549
 E  c3550
 E  c3551
 E  c3552
 E  c3553
 E  c3554
 E  c3555
 E  c3556
 E  c3557
 E  c3558
 E  c3559
 E  c3560
 E  c3561
 E  c3562
 E  c3563
 E  c3564
 E  c3565
 E  c3566
 E  c3567
 E  c3568
 E  c3569
 E  c3570
 E  c3571
 E  c3572
 E  c3573
 E  c3574
 E  c3575
 E  c3576
 E  c3577
 E  c3578
 E  c3579
 E  c3580
 E  c3581
 E  c3582
 E  c3583
 E  c3584
 E  c3585
 E  c3586
 E  c3587
 E  c3588
 E  c3589
 E  c3590
 E  c3591
 E  c3592
 E  c3593
 E  c3594
 E  c3595
 E  c3596
 E  c3597
 E  c3598
 E  c3599
 E  c3600
 E  c3601
 E  c3602
 E  c3603
 E  c3604
 E  c3605
 E  c3606
 E  c3607
 E  c3608
 E  c3609
 E  c3610
 E  c3611
 E  c3612
 E  c3613
 E  c3614
 E  c3615
 E  c3616
 E  c3617
 E  c3618
 E  c3619
 E  c3620
 E  c3621
 E  c3622
 E  c3623
 E  c3624
 E  c3625
 E  c3626
 E  c3627
 E  c3628
 E  c3629
 E  c3630
 E  c3631
 E  c3632
 E  c3633
 E  c3634
 E  c3635
 E  c3636
 E  c3637
 E  c3638
 E  c3639
 E  c3640
 E  c3641
 E  c3642
 E  c3643
 E  c3644
 E  c3645
 E  c3646
 E  c3647
 E  c3648
 E  c3649
 E  c3650
 E  c3651
 E  c3652
 E  c3653
 E  c3654
 E  c3655
 E  c3656
 E  c3657
 E  c3658
 E  c3659
 E  c3660
 E  c3661
 E  c3662
 E  c3663
 E  c3664
 E  c3665
 E  c3666
 E  c3667
 E  c3668
 E  c3669
 E  c3670
 E  c3671
 E  c3672
 E  c3673
 E  c3674
 E  c3675
 E  c3676
 E  c3677
 E  c3678
 E  c3679
 E  c3680
 E  c3681
 E  c3682
 E  c3683
 E  c3684
 E  c3685
 E  c3686
 E  c3687
 E  c3688
 E  c3689
 E  c3690
 E  c3691
 E  c3692
 E  c3693
 E  c3694
 E  c3695
 E  c3696
 E  c3697
 E  c3698
 E  c3699
 E  c3700
 E  c3701
 E  c3702
 E  c3703
 E  c3704
 E  c3705
 E  c3706
 E  c3707
 E  c3708
 E  c3709
 E  c3710
 E  c3711
 E  c3712
 E  c3713
 E  c3714
 E  c3715
 E  c3716
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c271_1    1
    x[1]      c1396     1
    x[1]      OBJ       1
    x[2]      c190_1    -186
    x[2]      c235_1    -14
    x[2]      c1        1
    x[3]      c191_1    -186
    x[3]      c236_1    -14
    x[3]      c2        1
    x[4]      c192_1    -186
    x[4]      c237_1    -14
    x[4]      c3        1
    x[5]      c193_1    -186
    x[5]      c238_1    -14
    x[5]      c4        1
    x[6]      c194_1    -186
    x[6]      c239_1    -14
    x[6]      c5        1
    x[7]      c195_1    -186
    x[7]      c240_1    -14
    x[7]      c6        1
    x[8]      c196_1    -186
    x[8]      c241_1    -14
    x[8]      c7        1
    x[9]      c197_1    -186
    x[9]      c242_1    -14
    x[9]      c8        1
    x[10]     c181_1    -14
    x[10]     c226_1    -186
    x[10]     c9        1
    x[11]     c182_1    -14
    x[11]     c227_1    -186
    x[11]     c10       1
    x[12]     c183_1    -14
    x[12]     c228_1    -186
    x[12]     c11       1
    x[13]     c184_1    -14
    x[13]     c229_1    -186
    x[13]     c12       1
    x[14]     c185_1    -14
    x[14]     c230_1    -186
    x[14]     c13       1
    x[15]     c186_1    -14
    x[15]     c231_1    -186
    x[15]     c14       1
    x[16]     c187_1    -14
    x[16]     c232_1    -186
    x[16]     c15       1
    x[17]     c188_1    -14
    x[17]     c233_1    -186
    x[17]     c16       1
    x[18]     c189_1    -14
    x[18]     c234_1    -186
    x[18]     c17       1
    x[19]     c181_1    -186
    x[19]     c226_1    -14
    x[19]     c18       1
    x[19]     c19       1
    x[20]     c182_1    -186
    x[20]     c227_1    -14
    x[20]     c18       1
    x[20]     c20       1
    x[21]     c183_1    -186
    x[21]     c228_1    -14
    x[21]     c18       1
    x[21]     c21       1
    x[22]     c184_1    -186
    x[22]     c229_1    -14
    x[22]     c18       1
    x[22]     c22       1
    x[23]     c185_1    -186
    x[23]     c230_1    -14
    x[23]     c18       1
    x[23]     c23       1
    x[24]     c186_1    -186
    x[24]     c231_1    -14
    x[24]     c18       1
    x[24]     c24       1
    x[25]     c187_1    -186
    x[25]     c232_1    -14
    x[25]     c18       1
    x[25]     c25       1
    x[26]     c188_1    -186
    x[26]     c233_1    -14
    x[26]     c18       1
    x[26]     c26       1
    x[27]     c189_1    -186
    x[27]     c234_1    -14
    x[27]     c18       1
    x[27]     c27       1
    x[28]     c16_2     1
    x[28]     c17_2     1
    x[28]     c18_2     1
    x[28]     c190_1    -14
    x[28]     c235_1    -186
    x[28]     c19       1
    x[28]     c20       -1
    x[29]     c16_2     1
    x[29]     c191_1    -14
    x[29]     c236_1    -186
    x[29]     c19       1
    x[29]     c21       -1
    x[30]     c17_2     1
    x[30]     c192_1    -14
    x[30]     c237_1    -186
    x[30]     c19       1
    x[30]     c22       -1
    x[31]     c18_2     1
    x[31]     c193_1    -14
    x[31]     c238_1    -186
    x[31]     c19       1
    x[31]     c23       -1
    x[32]     c194_1    -14
    x[32]     c239_1    -186
    x[32]     c19       1
    x[32]     c24       -1
    x[33]     c195_1    -14
    x[33]     c240_1    -186
    x[33]     c19       1
    x[33]     c25       -1
    x[34]     c196_1    -14
    x[34]     c241_1    -186
    x[34]     c19       1
    x[34]     c26       -1
    x[35]     c197_1    -14
    x[35]     c242_1    -186
    x[35]     c19       1
    x[35]     c27       -1
    x[36]     c198_1    -14
    x[36]     c243_1    -186
    x[36]     c20       1
    x[36]     c21       -1
    x[37]     c199_1    -14
    x[37]     c244_1    -186
    x[37]     c20       1
    x[37]     c22       -1
    x[38]     c200_1    -14
    x[38]     c245_1    -186
    x[38]     c20       1
    x[38]     c23       -1
    x[39]     c201_1    -14
    x[39]     c246_1    -186
    x[39]     c20       1
    x[39]     c24       -1
    x[40]     c202_1    -14
    x[40]     c247_1    -186
    x[40]     c20       1
    x[40]     c25       -1
    x[41]     c203_1    -14
    x[41]     c248_1    -186
    x[41]     c20       1
    x[41]     c26       -1
    x[42]     c204_1    -14
    x[42]     c249_1    -186
    x[42]     c20       1
    x[42]     c27       -1
    x[43]     c198_1    -186
    x[43]     c243_1    -14
    x[43]     c20       -1
    x[43]     c21       1
    x[44]     c199_1    -186
    x[44]     c244_1    -14
    x[44]     c20       -1
    x[44]     c22       1
    x[45]     c200_1    -186
    x[45]     c245_1    -14
    x[45]     c20       -1
    x[45]     c23       1
    x[46]     c201_1    -186
    x[46]     c246_1    -14
    x[46]     c20       -1
    x[46]     c24       1
    x[47]     c202_1    -186
    x[47]     c247_1    -14
    x[47]     c20       -1
    x[47]     c25       1
    x[48]     c203_1    -186
    x[48]     c248_1    -14
    x[48]     c20       -1
    x[48]     c26       1
    x[49]     c204_1    -186
    x[49]     c249_1    -14
    x[49]     c20       -1
    x[49]     c27       1
    x[50]     c205_1    -14
    x[50]     c250_1    -186
    x[50]     c21       1
    x[50]     c22       -1
    x[51]     c206_1    -14
    x[51]     c251_1    -186
    x[51]     c21       1
    x[51]     c23       -1
    x[52]     c207_1    -14
    x[52]     c252_1    -186
    x[52]     c21       1
    x[52]     c24       -1
    x[53]     c208_1    -14
    x[53]     c253_1    -186
    x[53]     c21       1
    x[53]     c25       -1
    x[54]     c209_1    -14
    x[54]     c254_1    -186
    x[54]     c21       1
    x[54]     c26       -1
    x[55]     c210_1    -14
    x[55]     c255_1    -186
    x[55]     c21       1
    x[55]     c27       -1
    x[56]     c205_1    -186
    x[56]     c250_1    -14
    x[56]     c21       -1
    x[56]     c22       1
    x[57]     c206_1    -186
    x[57]     c251_1    -14
    x[57]     c21       -1
    x[57]     c23       1
    x[58]     c207_1    -186
    x[58]     c252_1    -14
    x[58]     c21       -1
    x[58]     c24       1
    x[59]     c208_1    -186
    x[59]     c253_1    -14
    x[59]     c21       -1
    x[59]     c25       1
    x[60]     c209_1    -186
    x[60]     c254_1    -14
    x[60]     c21       -1
    x[60]     c26       1
    x[61]     c210_1    -186
    x[61]     c255_1    -14
    x[61]     c21       -1
    x[61]     c27       1
    x[62]     c211_1    -14
    x[62]     c256_1    -186
    x[62]     c22       1
    x[62]     c23       -1
    x[63]     c212_1    -14
    x[63]     c257_1    -186
    x[63]     c22       1
    x[63]     c24       -1
    x[64]     c213_1    -14
    x[64]     c258_1    -186
    x[64]     c22       1
    x[64]     c25       -1
    x[65]     c214_1    -14
    x[65]     c259_1    -186
    x[65]     c22       1
    x[65]     c26       -1
    x[66]     c215_1    -14
    x[66]     c260_1    -186
    x[66]     c22       1
    x[66]     c27       -1
    x[67]     c211_1    -186
    x[67]     c256_1    -14
    x[67]     c22       -1
    x[67]     c23       1
    x[68]     c212_1    -186
    x[68]     c257_1    -14
    x[68]     c22       -1
    x[68]     c24       1
    x[69]     c213_1    -186
    x[69]     c258_1    -14
    x[69]     c22       -1
    x[69]     c25       1
    x[70]     c214_1    -186
    x[70]     c259_1    -14
    x[70]     c22       -1
    x[70]     c26       1
    x[71]     c215_1    -186
    x[71]     c260_1    -14
    x[71]     c22       -1
    x[71]     c27       1
    x[72]     c216_1    -14
    x[72]     c261_1    -186
    x[72]     c23       1
    x[72]     c24       -1
    x[73]     c217_1    -14
    x[73]     c262_1    -186
    x[73]     c23       1
    x[73]     c25       -1
    x[74]     c218_1    -14
    x[74]     c263_1    -186
    x[74]     c23       1
    x[74]     c26       -1
    x[75]     c219_1    -14
    x[75]     c264_1    -186
    x[75]     c23       1
    x[75]     c27       -1
    x[76]     c216_1    -186
    x[76]     c261_1    -14
    x[76]     c23       -1
    x[76]     c24       1
    x[77]     c217_1    -186
    x[77]     c262_1    -14
    x[77]     c23       -1
    x[77]     c25       1
    x[78]     c218_1    -186
    x[78]     c263_1    -14
    x[78]     c23       -1
    x[78]     c26       1
    x[79]     c219_1    -186
    x[79]     c264_1    -14
    x[79]     c23       -1
    x[79]     c27       1
    x[80]     c220_1    -14
    x[80]     c265_1    -186
    x[80]     c24       1
    x[80]     c25       -1
    x[81]     c221_1    -14
    x[81]     c266_1    -186
    x[81]     c24       1
    x[81]     c26       -1
    x[82]     c222_1    -14
    x[82]     c267_1    -186
    x[82]     c24       1
    x[82]     c27       -1
    x[83]     c220_1    -186
    x[83]     c265_1    -14
    x[83]     c24       -1
    x[83]     c25       1
    x[84]     c221_1    -186
    x[84]     c266_1    -14
    x[84]     c24       -1
    x[84]     c26       1
    x[85]     c222_1    -186
    x[85]     c267_1    -14
    x[85]     c24       -1
    x[85]     c27       1
    x[86]     c223_1    -14
    x[86]     c268_1    -186
    x[86]     c25       1
    x[86]     c26       -1
    x[87]     c224_1    -14
    x[87]     c269_1    -186
    x[87]     c25       1
    x[87]     c27       -1
    x[88]     c223_1    -186
    x[88]     c268_1    -14
    x[88]     c25       -1
    x[88]     c26       1
    x[89]     c224_1    -186
    x[89]     c269_1    -14
    x[89]     c25       -1
    x[89]     c27       1
    x[90]     c225_1    -14
    x[90]     c270_1    -186
    x[90]     c26       1
    x[90]     c27       -1
    x[91]     c225_1    -186
    x[91]     c270_1    -14
    x[91]     c26       -1
    x[91]     c27       1
    x[92]     c198_1    -42
    x[92]     c243_1    -158
    x[92]     c28       1
    x[93]     c199_1    -42
    x[93]     c244_1    -158
    x[93]     c29       1
    x[94]     c200_1    -42
    x[94]     c245_1    -158
    x[94]     c30       1
    x[95]     c201_1    -42
    x[95]     c246_1    -158
    x[95]     c31       1
    x[96]     c202_1    -42
    x[96]     c247_1    -158
    x[96]     c32       1
    x[97]     c203_1    -42
    x[97]     c248_1    -158
    x[97]     c33       1
    x[98]     c204_1    -42
    x[98]     c249_1    -158
    x[98]     c34       1
    x[99]     c181_1    -158
    x[99]     c226_1    -42
    x[99]     c35       1
    x[100]    c182_1    -158
    x[100]    c227_1    -42
    x[100]    c36       1
    x[101]    c183_1    -158
    x[101]    c228_1    -42
    x[101]    c37       1
    x[102]    c184_1    -158
    x[102]    c229_1    -42
    x[102]    c38       1
    x[103]    c185_1    -158
    x[103]    c230_1    -42
    x[103]    c39       1
    x[104]    c186_1    -158
    x[104]    c231_1    -42
    x[104]    c40       1
    x[105]    c187_1    -158
    x[105]    c232_1    -42
    x[105]    c41       1
    x[106]    c188_1    -158
    x[106]    c233_1    -42
    x[106]    c42       1
    x[107]    c189_1    -158
    x[107]    c234_1    -42
    x[107]    c43       1
    x[108]    c190_1    -158
    x[108]    c235_1    -42
    x[108]    c44       1
    x[109]    c25_2     1
    x[109]    c30_2     1
    x[109]    c181_1    -42
    x[109]    c226_1    -158
    x[109]    c45       1
    x[109]    c47       1
    x[110]    c25_2     1
    x[110]    c26_2     1
    x[110]    c27_2     1
    x[110]    c28_2     1
    x[110]    c29_2     1
    x[110]    c182_1    -42
    x[110]    c227_1    -158
    x[110]    c45       1
    x[110]    c46       1
    x[111]    c30_2     1
    x[111]    c183_1    -42
    x[111]    c228_1    -158
    x[111]    c45       1
    x[111]    c48       1
    x[112]    c26_2     1
    x[112]    c184_1    -42
    x[112]    c229_1    -158
    x[112]    c45       1
    x[112]    c49       1
    x[113]    c185_1    -42
    x[113]    c230_1    -158
    x[113]    c45       1
    x[113]    c50       1
    x[114]    c27_2     1
    x[114]    c186_1    -42
    x[114]    c231_1    -158
    x[114]    c45       1
    x[114]    c51       1
    x[115]    c187_1    -42
    x[115]    c232_1    -158
    x[115]    c45       1
    x[115]    c52       1
    x[116]    c28_2     1
    x[116]    c188_1    -42
    x[116]    c233_1    -158
    x[116]    c45       1
    x[116]    c53       1
    x[117]    c29_2     1
    x[117]    c189_1    -42
    x[117]    c234_1    -158
    x[117]    c45       1
    x[117]    c54       1
    x[118]    c47_2     1
    x[118]    c48_2     1
    x[118]    c49_2     1
    x[118]    c190_1    -42
    x[118]    c235_1    -158
    x[118]    c46       1
    x[118]    c47       -1
    x[119]    c198_1    -158
    x[119]    c243_1    -42
    x[119]    c46       1
    x[119]    c48       -1
    x[120]    c199_1    -158
    x[120]    c244_1    -42
    x[120]    c46       1
    x[120]    c49       -1
    x[121]    c47_2     1
    x[121]    c200_1    -158
    x[121]    c245_1    -42
    x[121]    c46       1
    x[121]    c50       -1
    x[122]    c201_1    -158
    x[122]    c246_1    -42
    x[122]    c46       1
    x[122]    c51       -1
    x[123]    c48_2     1
    x[123]    c202_1    -158
    x[123]    c247_1    -42
    x[123]    c46       1
    x[123]    c52       -1
    x[124]    c203_1    -158
    x[124]    c248_1    -42
    x[124]    c46       1
    x[124]    c53       -1
    x[125]    c49_2     1
    x[125]    c204_1    -158
    x[125]    c249_1    -42
    x[125]    c46       1
    x[125]    c54       -1
    x[126]    c191_1    -158
    x[126]    c236_1    -42
    x[126]    c47       1
    x[126]    c48       -1
    x[127]    c192_1    -158
    x[127]    c237_1    -42
    x[127]    c47       1
    x[127]    c49       -1
    x[128]    c193_1    -158
    x[128]    c238_1    -42
    x[128]    c47       1
    x[128]    c50       -1
    x[129]    c194_1    -158
    x[129]    c239_1    -42
    x[129]    c47       1
    x[129]    c51       -1
    x[130]    c195_1    -158
    x[130]    c240_1    -42
    x[130]    c47       1
    x[130]    c52       -1
    x[131]    c196_1    -158
    x[131]    c241_1    -42
    x[131]    c47       1
    x[131]    c53       -1
    x[132]    c197_1    -158
    x[132]    c242_1    -42
    x[132]    c47       1
    x[132]    c54       -1
    x[133]    c191_1    -42
    x[133]    c236_1    -158
    x[133]    c47       -1
    x[133]    c48       1
    x[134]    c192_1    -42
    x[134]    c237_1    -158
    x[134]    c47       -1
    x[134]    c49       1
    x[135]    c193_1    -42
    x[135]    c238_1    -158
    x[135]    c47       -1
    x[135]    c50       1
    x[136]    c194_1    -42
    x[136]    c239_1    -158
    x[136]    c47       -1
    x[136]    c51       1
    x[137]    c195_1    -42
    x[137]    c240_1    -158
    x[137]    c47       -1
    x[137]    c52       1
    x[138]    c196_1    -42
    x[138]    c241_1    -158
    x[138]    c47       -1
    x[138]    c53       1
    x[139]    c197_1    -42
    x[139]    c242_1    -158
    x[139]    c47       -1
    x[139]    c54       1
    x[140]    c205_1    -158
    x[140]    c250_1    -42
    x[140]    c48       1
    x[140]    c49       -1
    x[141]    c206_1    -158
    x[141]    c251_1    -42
    x[141]    c48       1
    x[141]    c50       -1
    x[142]    c207_1    -158
    x[142]    c252_1    -42
    x[142]    c48       1
    x[142]    c51       -1
    x[143]    c208_1    -158
    x[143]    c253_1    -42
    x[143]    c48       1
    x[143]    c52       -1
    x[144]    c209_1    -158
    x[144]    c254_1    -42
    x[144]    c48       1
    x[144]    c53       -1
    x[145]    c210_1    -158
    x[145]    c255_1    -42
    x[145]    c48       1
    x[145]    c54       -1
    x[146]    c205_1    -42
    x[146]    c250_1    -158
    x[146]    c48       -1
    x[146]    c49       1
    x[147]    c206_1    -42
    x[147]    c251_1    -158
    x[147]    c48       -1
    x[147]    c50       1
    x[148]    c207_1    -42
    x[148]    c252_1    -158
    x[148]    c48       -1
    x[148]    c51       1
    x[149]    c208_1    -42
    x[149]    c253_1    -158
    x[149]    c48       -1
    x[149]    c52       1
    x[150]    c209_1    -42
    x[150]    c254_1    -158
    x[150]    c48       -1
    x[150]    c53       1
    x[151]    c210_1    -42
    x[151]    c255_1    -158
    x[151]    c48       -1
    x[151]    c54       1
    x[152]    c211_1    -158
    x[152]    c256_1    -42
    x[152]    c49       1
    x[152]    c50       -1
    x[153]    c212_1    -158
    x[153]    c257_1    -42
    x[153]    c49       1
    x[153]    c51       -1
    x[154]    c213_1    -158
    x[154]    c258_1    -42
    x[154]    c49       1
    x[154]    c52       -1
    x[155]    c214_1    -158
    x[155]    c259_1    -42
    x[155]    c49       1
    x[155]    c53       -1
    x[156]    c215_1    -158
    x[156]    c260_1    -42
    x[156]    c49       1
    x[156]    c54       -1
    x[157]    c211_1    -42
    x[157]    c256_1    -158
    x[157]    c49       -1
    x[157]    c50       1
    x[158]    c212_1    -42
    x[158]    c257_1    -158
    x[158]    c49       -1
    x[158]    c51       1
    x[159]    c213_1    -42
    x[159]    c258_1    -158
    x[159]    c49       -1
    x[159]    c52       1
    x[160]    c214_1    -42
    x[160]    c259_1    -158
    x[160]    c49       -1
    x[160]    c53       1
    x[161]    c215_1    -42
    x[161]    c260_1    -158
    x[161]    c49       -1
    x[161]    c54       1
    x[162]    c216_1    -158
    x[162]    c261_1    -42
    x[162]    c50       1
    x[162]    c51       -1
    x[163]    c217_1    -158
    x[163]    c262_1    -42
    x[163]    c50       1
    x[163]    c52       -1
    x[164]    c218_1    -158
    x[164]    c263_1    -42
    x[164]    c50       1
    x[164]    c53       -1
    x[165]    c219_1    -158
    x[165]    c264_1    -42
    x[165]    c50       1
    x[165]    c54       -1
    x[166]    c216_1    -42
    x[166]    c261_1    -158
    x[166]    c50       -1
    x[166]    c51       1
    x[167]    c217_1    -42
    x[167]    c262_1    -158
    x[167]    c50       -1
    x[167]    c52       1
    x[168]    c218_1    -42
    x[168]    c263_1    -158
    x[168]    c50       -1
    x[168]    c53       1
    x[169]    c219_1    -42
    x[169]    c264_1    -158
    x[169]    c50       -1
    x[169]    c54       1
    x[170]    c220_1    -158
    x[170]    c265_1    -42
    x[170]    c51       1
    x[170]    c52       -1
    x[171]    c221_1    -158
    x[171]    c266_1    -42
    x[171]    c51       1
    x[171]    c53       -1
    x[172]    c222_1    -158
    x[172]    c267_1    -42
    x[172]    c51       1
    x[172]    c54       -1
    x[173]    c220_1    -42
    x[173]    c265_1    -158
    x[173]    c51       -1
    x[173]    c52       1
    x[174]    c221_1    -42
    x[174]    c266_1    -158
    x[174]    c51       -1
    x[174]    c53       1
    x[175]    c222_1    -42
    x[175]    c267_1    -158
    x[175]    c51       -1
    x[175]    c54       1
    x[176]    c223_1    -158
    x[176]    c268_1    -42
    x[176]    c52       1
    x[176]    c53       -1
    x[177]    c224_1    -158
    x[177]    c269_1    -42
    x[177]    c52       1
    x[177]    c54       -1
    x[178]    c223_1    -42
    x[178]    c268_1    -158
    x[178]    c52       -1
    x[178]    c53       1
    x[179]    c224_1    -42
    x[179]    c269_1    -158
    x[179]    c52       -1
    x[179]    c54       1
    x[180]    c225_1    -158
    x[180]    c270_1    -42
    x[180]    c53       1
    x[180]    c54       -1
    x[181]    c225_1    -42
    x[181]    c270_1    -158
    x[181]    c53       -1
    x[181]    c54       1
    x[182]    c205_1    -127
    x[182]    c250_1    -140
    x[182]    c55       1
    x[183]    c206_1    -127
    x[183]    c251_1    -140
    x[183]    c56       1
    x[184]    c207_1    -127
    x[184]    c252_1    -140
    x[184]    c57       1
    x[185]    c208_1    -127
    x[185]    c253_1    -140
    x[185]    c58       1
    x[186]    c209_1    -127
    x[186]    c254_1    -140
    x[186]    c59       1
    x[187]    c210_1    -127
    x[187]    c255_1    -140
    x[187]    c60       1
    x[188]    c181_1    -140
    x[188]    c226_1    -127
    x[188]    c61       1
    x[189]    c182_1    -140
    x[189]    c227_1    -127
    x[189]    c62       1
    x[190]    c183_1    -140
    x[190]    c228_1    -127
    x[190]    c63       1
    x[191]    c184_1    -140
    x[191]    c229_1    -127
    x[191]    c64       1
    x[192]    c185_1    -140
    x[192]    c230_1    -127
    x[192]    c65       1
    x[193]    c186_1    -140
    x[193]    c231_1    -127
    x[193]    c66       1
    x[194]    c187_1    -140
    x[194]    c232_1    -127
    x[194]    c67       1
    x[195]    c188_1    -140
    x[195]    c233_1    -127
    x[195]    c68       1
    x[196]    c189_1    -140
    x[196]    c234_1    -127
    x[196]    c69       1
    x[197]    c191_1    -140
    x[197]    c236_1    -127
    x[197]    c70       1
    x[198]    c198_1    -140
    x[198]    c243_1    -127
    x[198]    c71       1
    x[199]    c181_1    -127
    x[199]    c226_1    -140
    x[199]    c72       1
    x[199]    c74       1
    x[200]    c182_1    -127
    x[200]    c227_1    -140
    x[200]    c72       1
    x[200]    c75       1
    x[201]    c183_1    -127
    x[201]    c228_1    -140
    x[201]    c72       1
    x[201]    c73       1
    x[202]    c184_1    -127
    x[202]    c229_1    -140
    x[202]    c72       1
    x[202]    c76       1
    x[203]    c185_1    -127
    x[203]    c230_1    -140
    x[203]    c72       1
    x[203]    c77       1
    x[204]    c186_1    -127
    x[204]    c231_1    -140
    x[204]    c72       1
    x[204]    c78       1
    x[205]    c187_1    -127
    x[205]    c232_1    -140
    x[205]    c72       1
    x[205]    c79       1
    x[206]    c188_1    -127
    x[206]    c233_1    -140
    x[206]    c72       1
    x[206]    c80       1
    x[207]    c189_1    -127
    x[207]    c234_1    -140
    x[207]    c72       1
    x[207]    c81       1
    x[208]    c191_1    -127
    x[208]    c236_1    -140
    x[208]    c73       1
    x[208]    c74       -1
    x[209]    c198_1    -127
    x[209]    c243_1    -140
    x[209]    c73       1
    x[209]    c75       -1
    x[210]    c205_1    -140
    x[210]    c250_1    -127
    x[210]    c73       1
    x[210]    c76       -1
    x[211]    c206_1    -140
    x[211]    c251_1    -127
    x[211]    c73       1
    x[211]    c77       -1
    x[212]    c207_1    -140
    x[212]    c252_1    -127
    x[212]    c73       1
    x[212]    c78       -1
    x[213]    c208_1    -140
    x[213]    c253_1    -127
    x[213]    c73       1
    x[213]    c79       -1
    x[214]    c209_1    -140
    x[214]    c254_1    -127
    x[214]    c73       1
    x[214]    c80       -1
    x[215]    c210_1    -140
    x[215]    c255_1    -127
    x[215]    c73       1
    x[215]    c81       -1
    x[216]    c190_1    -140
    x[216]    c235_1    -127
    x[216]    c74       1
    x[216]    c75       -1
    x[217]    c192_1    -140
    x[217]    c237_1    -127
    x[217]    c74       1
    x[217]    c76       -1
    x[218]    c193_1    -140
    x[218]    c238_1    -127
    x[218]    c74       1
    x[218]    c77       -1
    x[219]    c194_1    -140
    x[219]    c239_1    -127
    x[219]    c74       1
    x[219]    c78       -1
    x[220]    c195_1    -140
    x[220]    c240_1    -127
    x[220]    c74       1
    x[220]    c79       -1
    x[221]    c196_1    -140
    x[221]    c241_1    -127
    x[221]    c74       1
    x[221]    c80       -1
    x[222]    c197_1    -140
    x[222]    c242_1    -127
    x[222]    c74       1
    x[222]    c81       -1
    x[223]    c190_1    -127
    x[223]    c235_1    -140
    x[223]    c74       -1
    x[223]    c75       1
    x[224]    c192_1    -127
    x[224]    c237_1    -140
    x[224]    c74       -1
    x[224]    c76       1
    x[225]    c193_1    -127
    x[225]    c238_1    -140
    x[225]    c74       -1
    x[225]    c77       1
    x[226]    c194_1    -127
    x[226]    c239_1    -140
    x[226]    c74       -1
    x[226]    c78       1
    x[227]    c195_1    -127
    x[227]    c240_1    -140
    x[227]    c74       -1
    x[227]    c79       1
    x[228]    c196_1    -127
    x[228]    c241_1    -140
    x[228]    c74       -1
    x[228]    c80       1
    x[229]    c197_1    -127
    x[229]    c242_1    -140
    x[229]    c74       -1
    x[229]    c81       1
    x[230]    c199_1    -140
    x[230]    c244_1    -127
    x[230]    c75       1
    x[230]    c76       -1
    x[231]    c200_1    -140
    x[231]    c245_1    -127
    x[231]    c75       1
    x[231]    c77       -1
    x[232]    c201_1    -140
    x[232]    c246_1    -127
    x[232]    c75       1
    x[232]    c78       -1
    x[233]    c202_1    -140
    x[233]    c247_1    -127
    x[233]    c75       1
    x[233]    c79       -1
    x[234]    c203_1    -140
    x[234]    c248_1    -127
    x[234]    c75       1
    x[234]    c80       -1
    x[235]    c204_1    -140
    x[235]    c249_1    -127
    x[235]    c75       1
    x[235]    c81       -1
    x[236]    c199_1    -127
    x[236]    c244_1    -140
    x[236]    c75       -1
    x[236]    c76       1
    x[237]    c200_1    -127
    x[237]    c245_1    -140
    x[237]    c75       -1
    x[237]    c77       1
    x[238]    c201_1    -127
    x[238]    c246_1    -140
    x[238]    c75       -1
    x[238]    c78       1
    x[239]    c202_1    -127
    x[239]    c247_1    -140
    x[239]    c75       -1
    x[239]    c79       1
    x[240]    c203_1    -127
    x[240]    c248_1    -140
    x[240]    c75       -1
    x[240]    c80       1
    x[241]    c204_1    -127
    x[241]    c249_1    -140
    x[241]    c75       -1
    x[241]    c81       1
    x[242]    c211_1    -140
    x[242]    c256_1    -127
    x[242]    c76       1
    x[242]    c77       -1
    x[243]    c212_1    -140
    x[243]    c257_1    -127
    x[243]    c76       1
    x[243]    c78       -1
    x[244]    c213_1    -140
    x[244]    c258_1    -127
    x[244]    c76       1
    x[244]    c79       -1
    x[245]    c214_1    -140
    x[245]    c259_1    -127
    x[245]    c76       1
    x[245]    c80       -1
    x[246]    c215_1    -140
    x[246]    c260_1    -127
    x[246]    c76       1
    x[246]    c81       -1
    x[247]    c211_1    -127
    x[247]    c256_1    -140
    x[247]    c76       -1
    x[247]    c77       1
    x[248]    c212_1    -127
    x[248]    c257_1    -140
    x[248]    c76       -1
    x[248]    c78       1
    x[249]    c213_1    -127
    x[249]    c258_1    -140
    x[249]    c76       -1
    x[249]    c79       1
    x[250]    c214_1    -127
    x[250]    c259_1    -140
    x[250]    c76       -1
    x[250]    c80       1
    x[251]    c215_1    -127
    x[251]    c260_1    -140
    x[251]    c76       -1
    x[251]    c81       1
    x[252]    c216_1    -140
    x[252]    c261_1    -127
    x[252]    c77       1
    x[252]    c78       -1
    x[253]    c217_1    -140
    x[253]    c262_1    -127
    x[253]    c77       1
    x[253]    c79       -1
    x[254]    c218_1    -140
    x[254]    c263_1    -127
    x[254]    c77       1
    x[254]    c80       -1
    x[255]    c219_1    -140
    x[255]    c264_1    -127
    x[255]    c77       1
    x[255]    c81       -1
    x[256]    c216_1    -127
    x[256]    c261_1    -140
    x[256]    c77       -1
    x[256]    c78       1
    x[257]    c217_1    -127
    x[257]    c262_1    -140
    x[257]    c77       -1
    x[257]    c79       1
    x[258]    c218_1    -127
    x[258]    c263_1    -140
    x[258]    c77       -1
    x[258]    c80       1
    x[259]    c219_1    -127
    x[259]    c264_1    -140
    x[259]    c77       -1
    x[259]    c81       1
    x[260]    c220_1    -140
    x[260]    c265_1    -127
    x[260]    c78       1
    x[260]    c79       -1
    x[261]    c221_1    -140
    x[261]    c266_1    -127
    x[261]    c78       1
    x[261]    c80       -1
    x[262]    c222_1    -140
    x[262]    c267_1    -127
    x[262]    c78       1
    x[262]    c81       -1
    x[263]    c220_1    -127
    x[263]    c265_1    -140
    x[263]    c78       -1
    x[263]    c79       1
    x[264]    c221_1    -127
    x[264]    c266_1    -140
    x[264]    c78       -1
    x[264]    c80       1
    x[265]    c222_1    -127
    x[265]    c267_1    -140
    x[265]    c78       -1
    x[265]    c81       1
    x[266]    c223_1    -140
    x[266]    c268_1    -127
    x[266]    c79       1
    x[266]    c80       -1
    x[267]    c224_1    -140
    x[267]    c269_1    -127
    x[267]    c79       1
    x[267]    c81       -1
    x[268]    c223_1    -127
    x[268]    c268_1    -140
    x[268]    c79       -1
    x[268]    c80       1
    x[269]    c224_1    -127
    x[269]    c269_1    -140
    x[269]    c79       -1
    x[269]    c81       1
    x[270]    c225_1    -140
    x[270]    c270_1    -127
    x[270]    c80       1
    x[270]    c81       -1
    x[271]    c225_1    -127
    x[271]    c270_1    -140
    x[271]    c80       -1
    x[271]    c81       1
    x[272]    c211_1    -39
    x[272]    c256_1    -139
    x[272]    c82       1
    x[273]    c212_1    -39
    x[273]    c257_1    -139
    x[273]    c83       1
    x[274]    c213_1    -39
    x[274]    c258_1    -139
    x[274]    c84       1
    x[275]    c214_1    -39
    x[275]    c259_1    -139
    x[275]    c85       1
    x[276]    c215_1    -39
    x[276]    c260_1    -139
    x[276]    c86       1
    x[277]    c181_1    -139
    x[277]    c226_1    -39
    x[277]    c87       1
    x[278]    c182_1    -139
    x[278]    c227_1    -39
    x[278]    c88       1
    x[279]    c183_1    -139
    x[279]    c228_1    -39
    x[279]    c89       1
    x[280]    c184_1    -139
    x[280]    c229_1    -39
    x[280]    c90       1
    x[281]    c185_1    -139
    x[281]    c230_1    -39
    x[281]    c91       1
    x[282]    c186_1    -139
    x[282]    c231_1    -39
    x[282]    c92       1
    x[283]    c187_1    -139
    x[283]    c232_1    -39
    x[283]    c93       1
    x[284]    c188_1    -139
    x[284]    c233_1    -39
    x[284]    c94       1
    x[285]    c189_1    -139
    x[285]    c234_1    -39
    x[285]    c95       1
    x[286]    c192_1    -139
    x[286]    c237_1    -39
    x[286]    c96       1
    x[287]    c199_1    -139
    x[287]    c244_1    -39
    x[287]    c97       1
    x[288]    c205_1    -139
    x[288]    c250_1    -39
    x[288]    c98       1
    x[289]    c105_2    1
    x[289]    c116_2    1
    x[289]    c181_1    -39
    x[289]    c226_1    -139
    x[289]    c99       1
    x[289]    c101      1
    x[290]    c106_2    1
    x[290]    c182_1    -39
    x[290]    c227_1    -139
    x[290]    c99       1
    x[290]    c102      1
    x[291]    c183_1    -39
    x[291]    c228_1    -139
    x[291]    c99       1
    x[291]    c103      1
    x[292]    c105_2    1
    x[292]    c106_2    1
    x[292]    c107_2    1
    x[292]    c184_1    -39
    x[292]    c229_1    -139
    x[292]    c99       1
    x[292]    c100      1
    x[293]    c116_2    1
    x[293]    c185_1    -39
    x[293]    c230_1    -139
    x[293]    c99       1
    x[293]    c104      1
    x[294]    c186_1    -39
    x[294]    c231_1    -139
    x[294]    c99       1
    x[294]    c105      1
    x[295]    c187_1    -39
    x[295]    c232_1    -139
    x[295]    c99       1
    x[295]    c106      1
    x[296]    c107_2    1
    x[296]    c188_1    -39
    x[296]    c233_1    -139
    x[296]    c99       1
    x[296]    c107      1
    x[297]    c189_1    -39
    x[297]    c234_1    -139
    x[297]    c99       1
    x[297]    c108      1
    x[298]    c134_2    1
    x[298]    c135_2    1
    x[298]    c136_2    1
    x[298]    c137_2    1
    x[298]    c138_2    1
    x[298]    c192_1    -39
    x[298]    c237_1    -139
    x[298]    c100      1
    x[298]    c101      -1
    x[299]    c134_2    1
    x[299]    c199_1    -39
    x[299]    c244_1    -139
    x[299]    c100      1
    x[299]    c102      -1
    x[300]    c205_1    -39
    x[300]    c250_1    -139
    x[300]    c100      1
    x[300]    c103      -1
    x[301]    c135_2    1
    x[301]    c211_1    -139
    x[301]    c256_1    -39
    x[301]    c100      1
    x[301]    c104      -1
    x[302]    c136_2    1
    x[302]    c212_1    -139
    x[302]    c257_1    -39
    x[302]    c100      1
    x[302]    c105      -1
    x[303]    c137_2    1
    x[303]    c213_1    -139
    x[303]    c258_1    -39
    x[303]    c100      1
    x[303]    c106      -1
    x[304]    c138_2    1
    x[304]    c214_1    -139
    x[304]    c259_1    -39
    x[304]    c100      1
    x[304]    c107      -1
    x[305]    c215_1    -139
    x[305]    c260_1    -39
    x[305]    c100      1
    x[305]    c108      -1
    x[306]    c190_1    -139
    x[306]    c235_1    -39
    x[306]    c101      1
    x[306]    c102      -1
    x[307]    c191_1    -139
    x[307]    c236_1    -39
    x[307]    c101      1
    x[307]    c103      -1
    x[308]    c193_1    -139
    x[308]    c238_1    -39
    x[308]    c101      1
    x[308]    c104      -1
    x[309]    c194_1    -139
    x[309]    c239_1    -39
    x[309]    c101      1
    x[309]    c105      -1
    x[310]    c195_1    -139
    x[310]    c240_1    -39
    x[310]    c101      1
    x[310]    c106      -1
    x[311]    c196_1    -139
    x[311]    c241_1    -39
    x[311]    c101      1
    x[311]    c107      -1
    x[312]    c197_1    -139
    x[312]    c242_1    -39
    x[312]    c101      1
    x[312]    c108      -1
    x[313]    c190_1    -39
    x[313]    c235_1    -139
    x[313]    c101      -1
    x[313]    c102      1
    x[314]    c191_1    -39
    x[314]    c236_1    -139
    x[314]    c101      -1
    x[314]    c103      1
    x[315]    c193_1    -39
    x[315]    c238_1    -139
    x[315]    c101      -1
    x[315]    c104      1
    x[316]    c194_1    -39
    x[316]    c239_1    -139
    x[316]    c101      -1
    x[316]    c105      1
    x[317]    c195_1    -39
    x[317]    c240_1    -139
    x[317]    c101      -1
    x[317]    c106      1
    x[318]    c196_1    -39
    x[318]    c241_1    -139
    x[318]    c101      -1
    x[318]    c107      1
    x[319]    c197_1    -39
    x[319]    c242_1    -139
    x[319]    c101      -1
    x[319]    c108      1
    x[320]    c198_1    -139
    x[320]    c243_1    -39
    x[320]    c102      1
    x[320]    c103      -1
    x[321]    c200_1    -139
    x[321]    c245_1    -39
    x[321]    c102      1
    x[321]    c104      -1
    x[322]    c201_1    -139
    x[322]    c246_1    -39
    x[322]    c102      1
    x[322]    c105      -1
    x[323]    c202_1    -139
    x[323]    c247_1    -39
    x[323]    c102      1
    x[323]    c106      -1
    x[324]    c203_1    -139
    x[324]    c248_1    -39
    x[324]    c102      1
    x[324]    c107      -1
    x[325]    c204_1    -139
    x[325]    c249_1    -39
    x[325]    c102      1
    x[325]    c108      -1
    x[326]    c198_1    -39
    x[326]    c243_1    -139
    x[326]    c102      -1
    x[326]    c103      1
    x[327]    c200_1    -39
    x[327]    c245_1    -139
    x[327]    c102      -1
    x[327]    c104      1
    x[328]    c201_1    -39
    x[328]    c246_1    -139
    x[328]    c102      -1
    x[328]    c105      1
    x[329]    c202_1    -39
    x[329]    c247_1    -139
    x[329]    c102      -1
    x[329]    c106      1
    x[330]    c203_1    -39
    x[330]    c248_1    -139
    x[330]    c102      -1
    x[330]    c107      1
    x[331]    c204_1    -39
    x[331]    c249_1    -139
    x[331]    c102      -1
    x[331]    c108      1
    x[332]    c206_1    -139
    x[332]    c251_1    -39
    x[332]    c103      1
    x[332]    c104      -1
    x[333]    c207_1    -139
    x[333]    c252_1    -39
    x[333]    c103      1
    x[333]    c105      -1
    x[334]    c208_1    -139
    x[334]    c253_1    -39
    x[334]    c103      1
    x[334]    c106      -1
    x[335]    c209_1    -139
    x[335]    c254_1    -39
    x[335]    c103      1
    x[335]    c107      -1
    x[336]    c210_1    -139
    x[336]    c255_1    -39
    x[336]    c103      1
    x[336]    c108      -1
    x[337]    c206_1    -39
    x[337]    c251_1    -139
    x[337]    c103      -1
    x[337]    c104      1
    x[338]    c207_1    -39
    x[338]    c252_1    -139
    x[338]    c103      -1
    x[338]    c105      1
    x[339]    c208_1    -39
    x[339]    c253_1    -139
    x[339]    c103      -1
    x[339]    c106      1
    x[340]    c209_1    -39
    x[340]    c254_1    -139
    x[340]    c103      -1
    x[340]    c107      1
    x[341]    c210_1    -39
    x[341]    c255_1    -139
    x[341]    c103      -1
    x[341]    c108      1
    x[342]    c216_1    -139
    x[342]    c261_1    -39
    x[342]    c104      1
    x[342]    c105      -1
    x[343]    c217_1    -139
    x[343]    c262_1    -39
    x[343]    c104      1
    x[343]    c106      -1
    x[344]    c218_1    -139
    x[344]    c263_1    -39
    x[344]    c104      1
    x[344]    c107      -1
    x[345]    c219_1    -139
    x[345]    c264_1    -39
    x[345]    c104      1
    x[345]    c108      -1
    x[346]    c216_1    -39
    x[346]    c261_1    -139
    x[346]    c104      -1
    x[346]    c105      1
    x[347]    c217_1    -39
    x[347]    c262_1    -139
    x[347]    c104      -1
    x[347]    c106      1
    x[348]    c218_1    -39
    x[348]    c263_1    -139
    x[348]    c104      -1
    x[348]    c107      1
    x[349]    c219_1    -39
    x[349]    c264_1    -139
    x[349]    c104      -1
    x[349]    c108      1
    x[350]    c220_1    -139
    x[350]    c265_1    -39
    x[350]    c105      1
    x[350]    c106      -1
    x[351]    c221_1    -139
    x[351]    c266_1    -39
    x[351]    c105      1
    x[351]    c107      -1
    x[352]    c222_1    -139
    x[352]    c267_1    -39
    x[352]    c105      1
    x[352]    c108      -1
    x[353]    c220_1    -39
    x[353]    c265_1    -139
    x[353]    c105      -1
    x[353]    c106      1
    x[354]    c221_1    -39
    x[354]    c266_1    -139
    x[354]    c105      -1
    x[354]    c107      1
    x[355]    c222_1    -39
    x[355]    c267_1    -139
    x[355]    c105      -1
    x[355]    c108      1
    x[356]    c223_1    -139
    x[356]    c268_1    -39
    x[356]    c106      1
    x[356]    c107      -1
    x[357]    c224_1    -139
    x[357]    c269_1    -39
    x[357]    c106      1
    x[357]    c108      -1
    x[358]    c223_1    -39
    x[358]    c268_1    -139
    x[358]    c106      -1
    x[358]    c107      1
    x[359]    c224_1    -39
    x[359]    c269_1    -139
    x[359]    c106      -1
    x[359]    c108      1
    x[360]    c225_1    -139
    x[360]    c270_1    -39
    x[360]    c107      1
    x[360]    c108      -1
    x[361]    c225_1    -39
    x[361]    c270_1    -139
    x[361]    c107      -1
    x[361]    c108      1
    x[362]    c216_1    -132
    x[362]    c261_1    -41
    x[362]    c109      1
    x[363]    c217_1    -132
    x[363]    c262_1    -41
    x[363]    c110      1
    x[364]    c218_1    -132
    x[364]    c263_1    -41
    x[364]    c111      1
    x[365]    c219_1    -132
    x[365]    c264_1    -41
    x[365]    c112      1
    x[366]    c181_1    -41
    x[366]    c226_1    -132
    x[366]    c113      1
    x[367]    c182_1    -41
    x[367]    c227_1    -132
    x[367]    c114      1
    x[368]    c183_1    -41
    x[368]    c228_1    -132
    x[368]    c115      1
    x[369]    c184_1    -41
    x[369]    c229_1    -132
    x[369]    c116      1
    x[370]    c185_1    -41
    x[370]    c230_1    -132
    x[370]    c117      1
    x[371]    c186_1    -41
    x[371]    c231_1    -132
    x[371]    c118      1
    x[372]    c187_1    -41
    x[372]    c232_1    -132
    x[372]    c119      1
    x[373]    c188_1    -41
    x[373]    c233_1    -132
    x[373]    c120      1
    x[374]    c189_1    -41
    x[374]    c234_1    -132
    x[374]    c121      1
    x[375]    c193_1    -41
    x[375]    c238_1    -132
    x[375]    c122      1
    x[376]    c200_1    -41
    x[376]    c245_1    -132
    x[376]    c123      1
    x[377]    c206_1    -41
    x[377]    c251_1    -132
    x[377]    c124      1
    x[378]    c211_1    -41
    x[378]    c256_1    -132
    x[378]    c125      1
    x[379]    c159_2    1
    x[379]    c181_1    -132
    x[379]    c226_1    -41
    x[379]    c126      1
    x[379]    c128      1
    x[380]    c182_1    -132
    x[380]    c227_1    -41
    x[380]    c126      1
    x[380]    c129      1
    x[381]    c148_2    1
    x[381]    c183_1    -132
    x[381]    c228_1    -41
    x[381]    c126      1
    x[381]    c130      1
    x[382]    c184_1    -132
    x[382]    c229_1    -41
    x[382]    c126      1
    x[382]    c131      1
    x[383]    c148_2    1
    x[383]    c149_2    1
    x[383]    c150_2    1
    x[383]    c151_2    1
    x[383]    c185_1    -132
    x[383]    c230_1    -41
    x[383]    c126      1
    x[383]    c127      1
    x[384]    c159_2    1
    x[384]    c186_1    -132
    x[384]    c231_1    -41
    x[384]    c126      1
    x[384]    c132      1
    x[385]    c149_2    1
    x[385]    c187_1    -132
    x[385]    c232_1    -41
    x[385]    c126      1
    x[385]    c133      1
    x[386]    c150_2    1
    x[386]    c188_1    -132
    x[386]    c233_1    -41
    x[386]    c126      1
    x[386]    c134      1
    x[387]    c151_2    1
    x[387]    c189_1    -132
    x[387]    c234_1    -41
    x[387]    c126      1
    x[387]    c135      1
    x[388]    c191_2    1
    x[388]    c193_1    -132
    x[388]    c238_1    -41
    x[388]    c127      1
    x[388]    c128      -1
    x[389]    c200_1    -132
    x[389]    c245_1    -41
    x[389]    c127      1
    x[389]    c129      -1
    x[390]    c191_2    1
    x[390]    c206_1    -132
    x[390]    c251_1    -41
    x[390]    c127      1
    x[390]    c130      -1
    x[391]    c211_1    -132
    x[391]    c256_1    -41
    x[391]    c127      1
    x[391]    c131      -1
    x[392]    c216_1    -41
    x[392]    c261_1    -132
    x[392]    c127      1
    x[392]    c132      -1
    x[393]    c217_1    -41
    x[393]    c262_1    -132
    x[393]    c127      1
    x[393]    c133      -1
    x[394]    c218_1    -41
    x[394]    c263_1    -132
    x[394]    c127      1
    x[394]    c134      -1
    x[395]    c219_1    -41
    x[395]    c264_1    -132
    x[395]    c127      1
    x[395]    c135      -1
    x[396]    c190_1    -41
    x[396]    c235_1    -132
    x[396]    c128      1
    x[396]    c129      -1
    x[397]    c191_1    -41
    x[397]    c236_1    -132
    x[397]    c128      1
    x[397]    c130      -1
    x[398]    c192_1    -41
    x[398]    c237_1    -132
    x[398]    c128      1
    x[398]    c131      -1
    x[399]    c194_1    -41
    x[399]    c239_1    -132
    x[399]    c128      1
    x[399]    c132      -1
    x[400]    c195_1    -41
    x[400]    c240_1    -132
    x[400]    c128      1
    x[400]    c133      -1
    x[401]    c196_1    -41
    x[401]    c241_1    -132
    x[401]    c128      1
    x[401]    c134      -1
    x[402]    c197_1    -41
    x[402]    c242_1    -132
    x[402]    c128      1
    x[402]    c135      -1
    x[403]    c190_1    -132
    x[403]    c235_1    -41
    x[403]    c128      -1
    x[403]    c129      1
    x[404]    c191_1    -132
    x[404]    c236_1    -41
    x[404]    c128      -1
    x[404]    c130      1
    x[405]    c192_1    -132
    x[405]    c237_1    -41
    x[405]    c128      -1
    x[405]    c131      1
    x[406]    c194_1    -132
    x[406]    c239_1    -41
    x[406]    c128      -1
    x[406]    c132      1
    x[407]    c195_1    -132
    x[407]    c240_1    -41
    x[407]    c128      -1
    x[407]    c133      1
    x[408]    c196_1    -132
    x[408]    c241_1    -41
    x[408]    c128      -1
    x[408]    c134      1
    x[409]    c197_1    -132
    x[409]    c242_1    -41
    x[409]    c128      -1
    x[409]    c135      1
    x[410]    c198_1    -41
    x[410]    c243_1    -132
    x[410]    c129      1
    x[410]    c130      -1
    x[411]    c199_1    -41
    x[411]    c244_1    -132
    x[411]    c129      1
    x[411]    c131      -1
    x[412]    c201_1    -41
    x[412]    c246_1    -132
    x[412]    c129      1
    x[412]    c132      -1
    x[413]    c202_1    -41
    x[413]    c247_1    -132
    x[413]    c129      1
    x[413]    c133      -1
    x[414]    c203_1    -41
    x[414]    c248_1    -132
    x[414]    c129      1
    x[414]    c134      -1
    x[415]    c204_1    -41
    x[415]    c249_1    -132
    x[415]    c129      1
    x[415]    c135      -1
    x[416]    c198_1    -132
    x[416]    c243_1    -41
    x[416]    c129      -1
    x[416]    c130      1
    x[417]    c199_1    -132
    x[417]    c244_1    -41
    x[417]    c129      -1
    x[417]    c131      1
    x[418]    c201_1    -132
    x[418]    c246_1    -41
    x[418]    c129      -1
    x[418]    c132      1
    x[419]    c202_1    -132
    x[419]    c247_1    -41
    x[419]    c129      -1
    x[419]    c133      1
    x[420]    c203_1    -132
    x[420]    c248_1    -41
    x[420]    c129      -1
    x[420]    c134      1
    x[421]    c204_1    -132
    x[421]    c249_1    -41
    x[421]    c129      -1
    x[421]    c135      1
    x[422]    c205_1    -41
    x[422]    c250_1    -132
    x[422]    c130      1
    x[422]    c131      -1
    x[423]    c207_1    -41
    x[423]    c252_1    -132
    x[423]    c130      1
    x[423]    c132      -1
    x[424]    c208_1    -41
    x[424]    c253_1    -132
    x[424]    c130      1
    x[424]    c133      -1
    x[425]    c209_1    -41
    x[425]    c254_1    -132
    x[425]    c130      1
    x[425]    c134      -1
    x[426]    c210_1    -41
    x[426]    c255_1    -132
    x[426]    c130      1
    x[426]    c135      -1
    x[427]    c205_1    -132
    x[427]    c250_1    -41
    x[427]    c130      -1
    x[427]    c131      1
    x[428]    c207_1    -132
    x[428]    c252_1    -41
    x[428]    c130      -1
    x[428]    c132      1
    x[429]    c208_1    -132
    x[429]    c253_1    -41
    x[429]    c130      -1
    x[429]    c133      1
    x[430]    c209_1    -132
    x[430]    c254_1    -41
    x[430]    c130      -1
    x[430]    c134      1
    x[431]    c210_1    -132
    x[431]    c255_1    -41
    x[431]    c130      -1
    x[431]    c135      1
    x[432]    c212_1    -41
    x[432]    c257_1    -132
    x[432]    c131      1
    x[432]    c132      -1
    x[433]    c213_1    -41
    x[433]    c258_1    -132
    x[433]    c131      1
    x[433]    c133      -1
    x[434]    c214_1    -41
    x[434]    c259_1    -132
    x[434]    c131      1
    x[434]    c134      -1
    x[435]    c215_1    -41
    x[435]    c260_1    -132
    x[435]    c131      1
    x[435]    c135      -1
    x[436]    c212_1    -132
    x[436]    c257_1    -41
    x[436]    c131      -1
    x[436]    c132      1
    x[437]    c213_1    -132
    x[437]    c258_1    -41
    x[437]    c131      -1
    x[437]    c133      1
    x[438]    c214_1    -132
    x[438]    c259_1    -41
    x[438]    c131      -1
    x[438]    c134      1
    x[439]    c215_1    -132
    x[439]    c260_1    -41
    x[439]    c131      -1
    x[439]    c135      1
    x[440]    c220_1    -41
    x[440]    c265_1    -132
    x[440]    c132      1
    x[440]    c133      -1
    x[441]    c221_1    -41
    x[441]    c266_1    -132
    x[441]    c132      1
    x[441]    c134      -1
    x[442]    c222_1    -41
    x[442]    c267_1    -132
    x[442]    c132      1
    x[442]    c135      -1
    x[443]    c220_1    -132
    x[443]    c265_1    -41
    x[443]    c132      -1
    x[443]    c133      1
    x[444]    c221_1    -132
    x[444]    c266_1    -41
    x[444]    c132      -1
    x[444]    c134      1
    x[445]    c222_1    -132
    x[445]    c267_1    -41
    x[445]    c132      -1
    x[445]    c135      1
    x[446]    c223_1    -41
    x[446]    c268_1    -132
    x[446]    c133      1
    x[446]    c134      -1
    x[447]    c224_1    -41
    x[447]    c269_1    -132
    x[447]    c133      1
    x[447]    c135      -1
    x[448]    c223_1    -132
    x[448]    c268_1    -41
    x[448]    c133      -1
    x[448]    c134      1
    x[449]    c224_1    -132
    x[449]    c269_1    -41
    x[449]    c133      -1
    x[449]    c135      1
    x[450]    c225_1    -41
    x[450]    c270_1    -132
    x[450]    c134      1
    x[450]    c135      -1
    x[451]    c225_1    -132
    x[451]    c270_1    -41
    x[451]    c134      -1
    x[451]    c135      1
    x[452]    c223_1    -186
    x[452]    c268_1    -82
    x[452]    c136      1
    x[453]    c224_1    -186
    x[453]    c269_1    -82
    x[453]    c137      1
    x[454]    c181_1    -82
    x[454]    c226_1    -186
    x[454]    c138      1
    x[455]    c182_1    -82
    x[455]    c227_1    -186
    x[455]    c139      1
    x[456]    c183_1    -82
    x[456]    c228_1    -186
    x[456]    c140      1
    x[457]    c184_1    -82
    x[457]    c229_1    -186
    x[457]    c141      1
    x[458]    c185_1    -82
    x[458]    c230_1    -186
    x[458]    c142      1
    x[459]    c186_1    -82
    x[459]    c231_1    -186
    x[459]    c143      1
    x[460]    c187_1    -82
    x[460]    c232_1    -186
    x[460]    c144      1
    x[461]    c188_1    -82
    x[461]    c233_1    -186
    x[461]    c145      1
    x[462]    c189_1    -82
    x[462]    c234_1    -186
    x[462]    c146      1
    x[463]    c195_1    -82
    x[463]    c240_1    -186
    x[463]    c147      1
    x[464]    c202_1    -82
    x[464]    c247_1    -186
    x[464]    c148      1
    x[465]    c208_1    -82
    x[465]    c253_1    -186
    x[465]    c149      1
    x[466]    c213_1    -82
    x[466]    c258_1    -186
    x[466]    c150      1
    x[467]    c217_1    -82
    x[467]    c262_1    -186
    x[467]    c151      1
    x[468]    c220_1    -82
    x[468]    c265_1    -186
    x[468]    c152      1
    x[469]    c197_2    1
    x[469]    c200_2    1
    x[469]    c181_1    -186
    x[469]    c226_1    -82
    x[469]    c153      1
    x[469]    c155      1
    x[470]    c198_2    1
    x[470]    c182_1    -186
    x[470]    c227_1    -82
    x[470]    c153      1
    x[470]    c156      1
    x[471]    c199_2    1
    x[471]    c183_1    -186
    x[471]    c228_1    -82
    x[471]    c153      1
    x[471]    c157      1
    x[472]    c184_1    -186
    x[472]    c229_1    -82
    x[472]    c153      1
    x[472]    c158      1
    x[473]    c185_1    -186
    x[473]    c230_1    -82
    x[473]    c153      1
    x[473]    c159      1
    x[474]    c186_1    -186
    x[474]    c231_1    -82
    x[474]    c153      1
    x[474]    c160      1
    x[475]    c197_2    1
    x[475]    c198_2    1
    x[475]    c199_2    1
    x[475]    c187_1    -186
    x[475]    c232_1    -82
    x[475]    c153      1
    x[475]    c154      1
    x[476]    c200_2    1
    x[476]    c188_1    -186
    x[476]    c233_1    -82
    x[476]    c153      1
    x[476]    c161      1
    x[477]    c189_1    -186
    x[477]    c234_1    -82
    x[477]    c153      1
    x[477]    c162      1
    x[478]    c234_2    1
    x[478]    c235_2    1
    x[478]    c195_1    -186
    x[478]    c240_1    -82
    x[478]    c154      1
    x[478]    c155      -1
    x[479]    c234_2    1
    x[479]    c202_1    -186
    x[479]    c247_1    -82
    x[479]    c154      1
    x[479]    c156      -1
    x[480]    c208_1    -186
    x[480]    c253_1    -82
    x[480]    c154      1
    x[480]    c157      -1
    x[481]    c235_2    1
    x[481]    c213_1    -186
    x[481]    c258_1    -82
    x[481]    c154      1
    x[481]    c158      -1
    x[482]    c217_1    -186
    x[482]    c262_1    -82
    x[482]    c154      1
    x[482]    c159      -1
    x[483]    c220_1    -186
    x[483]    c265_1    -82
    x[483]    c154      1
    x[483]    c160      -1
    x[484]    c223_1    -82
    x[484]    c268_1    -186
    x[484]    c154      1
    x[484]    c161      -1
    x[485]    c224_1    -82
    x[485]    c269_1    -186
    x[485]    c154      1
    x[485]    c162      -1
    x[486]    c190_1    -82
    x[486]    c235_1    -186
    x[486]    c155      1
    x[486]    c156      -1
    x[487]    c191_1    -82
    x[487]    c236_1    -186
    x[487]    c155      1
    x[487]    c157      -1
    x[488]    c192_1    -82
    x[488]    c237_1    -186
    x[488]    c155      1
    x[488]    c158      -1
    x[489]    c193_1    -82
    x[489]    c238_1    -186
    x[489]    c155      1
    x[489]    c159      -1
    x[490]    c194_1    -82
    x[490]    c239_1    -186
    x[490]    c155      1
    x[490]    c160      -1
    x[491]    c196_1    -82
    x[491]    c241_1    -186
    x[491]    c155      1
    x[491]    c161      -1
    x[492]    c197_1    -82
    x[492]    c242_1    -186
    x[492]    c155      1
    x[492]    c162      -1
    x[493]    c190_1    -186
    x[493]    c235_1    -82
    x[493]    c155      -1
    x[493]    c156      1
    x[494]    c191_1    -186
    x[494]    c236_1    -82
    x[494]    c155      -1
    x[494]    c157      1
    x[495]    c192_1    -186
    x[495]    c237_1    -82
    x[495]    c155      -1
    x[495]    c158      1
    x[496]    c193_1    -186
    x[496]    c238_1    -82
    x[496]    c155      -1
    x[496]    c159      1
    x[497]    c194_1    -186
    x[497]    c239_1    -82
    x[497]    c155      -1
    x[497]    c160      1
    x[498]    c196_1    -186
    x[498]    c241_1    -82
    x[498]    c155      -1
    x[498]    c161      1
    x[499]    c197_1    -186
    x[499]    c242_1    -82
    x[499]    c155      -1
    x[499]    c162      1
    x[500]    c198_1    -82
    x[500]    c243_1    -186
    x[500]    c156      1
    x[500]    c157      -1
    x[501]    c199_1    -82
    x[501]    c244_1    -186
    x[501]    c156      1
    x[501]    c158      -1
    x[502]    c200_1    -82
    x[502]    c245_1    -186
    x[502]    c156      1
    x[502]    c159      -1
    x[503]    c201_1    -82
    x[503]    c246_1    -186
    x[503]    c156      1
    x[503]    c160      -1
    x[504]    c203_1    -82
    x[504]    c248_1    -186
    x[504]    c156      1
    x[504]    c161      -1
    x[505]    c204_1    -82
    x[505]    c249_1    -186
    x[505]    c156      1
    x[505]    c162      -1
    x[506]    c198_1    -186
    x[506]    c243_1    -82
    x[506]    c156      -1
    x[506]    c157      1
    x[507]    c199_1    -186
    x[507]    c244_1    -82
    x[507]    c156      -1
    x[507]    c158      1
    x[508]    c200_1    -186
    x[508]    c245_1    -82
    x[508]    c156      -1
    x[508]    c159      1
    x[509]    c201_1    -186
    x[509]    c246_1    -82
    x[509]    c156      -1
    x[509]    c160      1
    x[510]    c203_1    -186
    x[510]    c248_1    -82
    x[510]    c156      -1
    x[510]    c161      1
    x[511]    c204_1    -186
    x[511]    c249_1    -82
    x[511]    c156      -1
    x[511]    c162      1
    x[512]    c205_1    -82
    x[512]    c250_1    -186
    x[512]    c157      1
    x[512]    c158      -1
    x[513]    c206_1    -82
    x[513]    c251_1    -186
    x[513]    c157      1
    x[513]    c159      -1
    x[514]    c207_1    -82
    x[514]    c252_1    -186
    x[514]    c157      1
    x[514]    c160      -1
    x[515]    c209_1    -82
    x[515]    c254_1    -186
    x[515]    c157      1
    x[515]    c161      -1
    x[516]    c210_1    -82
    x[516]    c255_1    -186
    x[516]    c157      1
    x[516]    c162      -1
    x[517]    c205_1    -186
    x[517]    c250_1    -82
    x[517]    c157      -1
    x[517]    c158      1
    x[518]    c206_1    -186
    x[518]    c251_1    -82
    x[518]    c157      -1
    x[518]    c159      1
    x[519]    c207_1    -186
    x[519]    c252_1    -82
    x[519]    c157      -1
    x[519]    c160      1
    x[520]    c209_1    -186
    x[520]    c254_1    -82
    x[520]    c157      -1
    x[520]    c161      1
    x[521]    c210_1    -186
    x[521]    c255_1    -82
    x[521]    c157      -1
    x[521]    c162      1
    x[522]    c211_1    -82
    x[522]    c256_1    -186
    x[522]    c158      1
    x[522]    c159      -1
    x[523]    c212_1    -82
    x[523]    c257_1    -186
    x[523]    c158      1
    x[523]    c160      -1
    x[524]    c214_1    -82
    x[524]    c259_1    -186
    x[524]    c158      1
    x[524]    c161      -1
    x[525]    c215_1    -82
    x[525]    c260_1    -186
    x[525]    c158      1
    x[525]    c162      -1
    x[526]    c211_1    -186
    x[526]    c256_1    -82
    x[526]    c158      -1
    x[526]    c159      1
    x[527]    c212_1    -186
    x[527]    c257_1    -82
    x[527]    c158      -1
    x[527]    c160      1
    x[528]    c214_1    -186
    x[528]    c259_1    -82
    x[528]    c158      -1
    x[528]    c161      1
    x[529]    c215_1    -186
    x[529]    c260_1    -82
    x[529]    c158      -1
    x[529]    c162      1
    x[530]    c216_1    -82
    x[530]    c261_1    -186
    x[530]    c159      1
    x[530]    c160      -1
    x[531]    c218_1    -82
    x[531]    c263_1    -186
    x[531]    c159      1
    x[531]    c161      -1
    x[532]    c219_1    -82
    x[532]    c264_1    -186
    x[532]    c159      1
    x[532]    c162      -1
    x[533]    c216_1    -186
    x[533]    c261_1    -82
    x[533]    c159      -1
    x[533]    c160      1
    x[534]    c218_1    -186
    x[534]    c263_1    -82
    x[534]    c159      -1
    x[534]    c161      1
    x[535]    c219_1    -186
    x[535]    c264_1    -82
    x[535]    c159      -1
    x[535]    c162      1
    x[536]    c221_1    -82
    x[536]    c266_1    -186
    x[536]    c160      1
    x[536]    c161      -1
    x[537]    c222_1    -82
    x[537]    c267_1    -186
    x[537]    c160      1
    x[537]    c162      -1
    x[538]    c221_1    -186
    x[538]    c266_1    -82
    x[538]    c160      -1
    x[538]    c161      1
    x[539]    c222_1    -186
    x[539]    c267_1    -82
    x[539]    c160      -1
    x[539]    c162      1
    x[540]    c225_1    -82
    x[540]    c270_1    -186
    x[540]    c161      1
    x[540]    c162      -1
    x[541]    c225_1    -186
    x[541]    c270_1    -82
    x[541]    c161      -1
    x[541]    c162      1
    x[542]    c225_1    -178
    x[542]    c270_1    -27
    x[542]    c163      1
    x[543]    c181_1    -27
    x[543]    c226_1    -178
    x[543]    c164      1
    x[544]    c182_1    -27
    x[544]    c227_1    -178
    x[544]    c165      1
    x[545]    c183_1    -27
    x[545]    c228_1    -178
    x[545]    c166      1
    x[546]    c184_1    -27
    x[546]    c229_1    -178
    x[546]    c167      1
    x[547]    c185_1    -27
    x[547]    c230_1    -178
    x[547]    c168      1
    x[548]    c186_1    -27
    x[548]    c231_1    -178
    x[548]    c169      1
    x[549]    c187_1    -27
    x[549]    c232_1    -178
    x[549]    c170      1
    x[550]    c188_1    -27
    x[550]    c233_1    -178
    x[550]    c171      1
    x[551]    c189_1    -27
    x[551]    c234_1    -178
    x[551]    c172      1
    x[552]    c196_1    -27
    x[552]    c241_1    -178
    x[552]    c173      1
    x[553]    c203_1    -27
    x[553]    c248_1    -178
    x[553]    c174      1
    x[554]    c209_1    -27
    x[554]    c254_1    -178
    x[554]    c175      1
    x[555]    c214_1    -27
    x[555]    c259_1    -178
    x[555]    c176      1
    x[556]    c218_1    -27
    x[556]    c263_1    -178
    x[556]    c177      1
    x[557]    c221_1    -27
    x[557]    c266_1    -178
    x[557]    c178      1
    x[558]    c223_1    -27
    x[558]    c268_1    -178
    x[558]    c179      1
    x[559]    c244_2    1
    x[559]    c260_2    1
    x[559]    c181_1    -178
    x[559]    c226_1    -27
    x[559]    c180      1
    x[559]    c182      1
    x[560]    c245_2    1
    x[560]    c182_1    -178
    x[560]    c227_1    -27
    x[560]    c180      1
    x[560]    c183      1
    x[561]    c183_1    -178
    x[561]    c228_1    -27
    x[561]    c180      1
    x[561]    c184      1
    x[562]    c184_1    -178
    x[562]    c229_1    -27
    x[562]    c180      1
    x[562]    c185      1
    x[563]    c246_2    1
    x[563]    c185_1    -178
    x[563]    c230_1    -27
    x[563]    c180      1
    x[563]    c186      1
    x[564]    c247_2    1
    x[564]    c186_1    -178
    x[564]    c231_1    -27
    x[564]    c180      1
    x[564]    c187      1
    x[565]    c187_1    -178
    x[565]    c232_1    -27
    x[565]    c180      1
    x[565]    c188      1
    x[566]    c244_2    1
    x[566]    c245_2    1
    x[566]    c246_2    1
    x[566]    c247_2    1
    x[566]    c188_1    -178
    x[566]    c233_1    -27
    x[566]    c180      1
    x[566]    c181      1
    x[567]    c260_2    1
    x[567]    c189_1    -178
    x[567]    c234_1    -27
    x[567]    c180      1
    x[567]    c189      1
    x[568]    c281_1    1
    x[568]    c282_1    1
    x[568]    c283_1    1
    x[568]    c284_1    1
    x[568]    c285_1    1
    x[568]    c196_1    -178
    x[568]    c241_1    -27
    x[568]    c181      1
    x[568]    c182      -1
    x[569]    c203_1    -178
    x[569]    c248_1    -27
    x[569]    c181      1
    x[569]    c183      -1
    x[570]    c281_1    1
    x[570]    c209_1    -178
    x[570]    c254_1    -27
    x[570]    c181      1
    x[570]    c184      -1
    x[571]    c282_1    1
    x[571]    c214_1    -178
    x[571]    c259_1    -27
    x[571]    c181      1
    x[571]    c185      -1
    x[572]    c283_1    1
    x[572]    c218_1    -178
    x[572]    c263_1    -27
    x[572]    c181      1
    x[572]    c186      -1
    x[573]    c221_1    -178
    x[573]    c266_1    -27
    x[573]    c181      1
    x[573]    c187      -1
    x[574]    c284_1    1
    x[574]    c223_1    -178
    x[574]    c268_1    -27
    x[574]    c181      1
    x[574]    c188      -1
    x[575]    c285_1    1
    x[575]    c225_1    -27
    x[575]    c270_1    -178
    x[575]    c181      1
    x[575]    c189      -1
    x[576]    c190_1    -27
    x[576]    c235_1    -178
    x[576]    c182      1
    x[576]    c183      -1
    x[577]    c191_1    -27
    x[577]    c236_1    -178
    x[577]    c182      1
    x[577]    c184      -1
    x[578]    c192_1    -27
    x[578]    c237_1    -178
    x[578]    c182      1
    x[578]    c185      -1
    x[579]    c193_1    -27
    x[579]    c238_1    -178
    x[579]    c182      1
    x[579]    c186      -1
    x[580]    c194_1    -27
    x[580]    c239_1    -178
    x[580]    c182      1
    x[580]    c187      -1
    x[581]    c195_1    -27
    x[581]    c240_1    -178
    x[581]    c182      1
    x[581]    c188      -1
    x[582]    c197_1    -27
    x[582]    c242_1    -178
    x[582]    c182      1
    x[582]    c189      -1
    x[583]    c190_1    -178
    x[583]    c235_1    -27
    x[583]    c182      -1
    x[583]    c183      1
    x[584]    c191_1    -178
    x[584]    c236_1    -27
    x[584]    c182      -1
    x[584]    c184      1
    x[585]    c192_1    -178
    x[585]    c237_1    -27
    x[585]    c182      -1
    x[585]    c185      1
    x[586]    c193_1    -178
    x[586]    c238_1    -27
    x[586]    c182      -1
    x[586]    c186      1
    x[587]    c194_1    -178
    x[587]    c239_1    -27
    x[587]    c182      -1
    x[587]    c187      1
    x[588]    c195_1    -178
    x[588]    c240_1    -27
    x[588]    c182      -1
    x[588]    c188      1
    x[589]    c197_1    -178
    x[589]    c242_1    -27
    x[589]    c182      -1
    x[589]    c189      1
    x[590]    c198_1    -27
    x[590]    c243_1    -178
    x[590]    c183      1
    x[590]    c184      -1
    x[591]    c199_1    -27
    x[591]    c244_1    -178
    x[591]    c183      1
    x[591]    c185      -1
    x[592]    c200_1    -27
    x[592]    c245_1    -178
    x[592]    c183      1
    x[592]    c186      -1
    x[593]    c201_1    -27
    x[593]    c246_1    -178
    x[593]    c183      1
    x[593]    c187      -1
    x[594]    c202_1    -27
    x[594]    c247_1    -178
    x[594]    c183      1
    x[594]    c188      -1
    x[595]    c204_1    -27
    x[595]    c249_1    -178
    x[595]    c183      1
    x[595]    c189      -1
    x[596]    c198_1    -178
    x[596]    c243_1    -27
    x[596]    c183      -1
    x[596]    c184      1
    x[597]    c199_1    -178
    x[597]    c244_1    -27
    x[597]    c183      -1
    x[597]    c185      1
    x[598]    c200_1    -178
    x[598]    c245_1    -27
    x[598]    c183      -1
    x[598]    c186      1
    x[599]    c201_1    -178
    x[599]    c246_1    -27
    x[599]    c183      -1
    x[599]    c187      1
    x[600]    c202_1    -178
    x[600]    c247_1    -27
    x[600]    c183      -1
    x[600]    c188      1
    x[601]    c204_1    -178
    x[601]    c249_1    -27
    x[601]    c183      -1
    x[601]    c189      1
    x[602]    c205_1    -27
    x[602]    c250_1    -178
    x[602]    c184      1
    x[602]    c185      -1
    x[603]    c206_1    -27
    x[603]    c251_1    -178
    x[603]    c184      1
    x[603]    c186      -1
    x[604]    c207_1    -27
    x[604]    c252_1    -178
    x[604]    c184      1
    x[604]    c187      -1
    x[605]    c208_1    -27
    x[605]    c253_1    -178
    x[605]    c184      1
    x[605]    c188      -1
    x[606]    c210_1    -27
    x[606]    c255_1    -178
    x[606]    c184      1
    x[606]    c189      -1
    x[607]    c205_1    -178
    x[607]    c250_1    -27
    x[607]    c184      -1
    x[607]    c185      1
    x[608]    c206_1    -178
    x[608]    c251_1    -27
    x[608]    c184      -1
    x[608]    c186      1
    x[609]    c207_1    -178
    x[609]    c252_1    -27
    x[609]    c184      -1
    x[609]    c187      1
    x[610]    c208_1    -178
    x[610]    c253_1    -27
    x[610]    c184      -1
    x[610]    c188      1
    x[611]    c210_1    -178
    x[611]    c255_1    -27
    x[611]    c184      -1
    x[611]    c189      1
    x[612]    c211_1    -27
    x[612]    c256_1    -178
    x[612]    c185      1
    x[612]    c186      -1
    x[613]    c212_1    -27
    x[613]    c257_1    -178
    x[613]    c185      1
    x[613]    c187      -1
    x[614]    c213_1    -27
    x[614]    c258_1    -178
    x[614]    c185      1
    x[614]    c188      -1
    x[615]    c215_1    -27
    x[615]    c260_1    -178
    x[615]    c185      1
    x[615]    c189      -1
    x[616]    c211_1    -178
    x[616]    c256_1    -27
    x[616]    c185      -1
    x[616]    c186      1
    x[617]    c212_1    -178
    x[617]    c257_1    -27
    x[617]    c185      -1
    x[617]    c187      1
    x[618]    c213_1    -178
    x[618]    c258_1    -27
    x[618]    c185      -1
    x[618]    c188      1
    x[619]    c215_1    -178
    x[619]    c260_1    -27
    x[619]    c185      -1
    x[619]    c189      1
    x[620]    c216_1    -27
    x[620]    c261_1    -178
    x[620]    c186      1
    x[620]    c187      -1
    x[621]    c217_1    -27
    x[621]    c262_1    -178
    x[621]    c186      1
    x[621]    c188      -1
    x[622]    c219_1    -27
    x[622]    c264_1    -178
    x[622]    c186      1
    x[622]    c189      -1
    x[623]    c216_1    -178
    x[623]    c261_1    -27
    x[623]    c186      -1
    x[623]    c187      1
    x[624]    c217_1    -178
    x[624]    c262_1    -27
    x[624]    c186      -1
    x[624]    c188      1
    x[625]    c219_1    -178
    x[625]    c264_1    -27
    x[625]    c186      -1
    x[625]    c189      1
    x[626]    c220_1    -27
    x[626]    c265_1    -178
    x[626]    c187      1
    x[626]    c188      -1
    x[627]    c222_1    -27
    x[627]    c267_1    -178
    x[627]    c187      1
    x[627]    c189      -1
    x[628]    c220_1    -178
    x[628]    c265_1    -27
    x[628]    c187      -1
    x[628]    c188      1
    x[629]    c222_1    -178
    x[629]    c267_1    -27
    x[629]    c187      -1
    x[629]    c189      1
    x[630]    c224_1    -27
    x[630]    c269_1    -178
    x[630]    c188      1
    x[630]    c189      -1
    x[631]    c224_1    -178
    x[631]    c269_1    -27
    x[631]    c188      -1
    x[631]    c189      1
    x[632]    c181_1    -187
    x[632]    c226_1    -168
    x[632]    c190      1
    x[633]    c182_1    -187
    x[633]    c227_1    -168
    x[633]    c191      1
    x[634]    c183_1    -187
    x[634]    c228_1    -168
    x[634]    c192      1
    x[635]    c184_1    -187
    x[635]    c229_1    -168
    x[635]    c193      1
    x[636]    c185_1    -187
    x[636]    c230_1    -168
    x[636]    c194      1
    x[637]    c186_1    -187
    x[637]    c231_1    -168
    x[637]    c195      1
    x[638]    c187_1    -187
    x[638]    c232_1    -168
    x[638]    c196      1
    x[639]    c188_1    -187
    x[639]    c233_1    -168
    x[639]    c197      1
    x[640]    c189_1    -187
    x[640]    c234_1    -168
    x[640]    c198      1
    x[641]    c197_1    -187
    x[641]    c242_1    -168
    x[641]    c199      1
    x[642]    c204_1    -187
    x[642]    c249_1    -168
    x[642]    c200      1
    x[643]    c210_1    -187
    x[643]    c255_1    -168
    x[643]    c201      1
    x[644]    c215_1    -187
    x[644]    c260_1    -168
    x[644]    c202      1
    x[645]    c219_1    -187
    x[645]    c264_1    -168
    x[645]    c203      1
    x[646]    c222_1    -187
    x[646]    c267_1    -168
    x[646]    c204      1
    x[647]    c224_1    -187
    x[647]    c269_1    -168
    x[647]    c205      1
    x[648]    c225_1    -187
    x[648]    c270_1    -168
    x[648]    c206      1
    x[649]    c291_1    1
    x[649]    c181_1    -168
    x[649]    c226_1    -187
    x[649]    c207      1
    x[649]    c209      1
    x[650]    c292_1    1
    x[650]    c182_1    -168
    x[650]    c227_1    -187
    x[650]    c207      1
    x[650]    c210      1
    x[651]    c183_1    -168
    x[651]    c228_1    -187
    x[651]    c207      1
    x[651]    c211      1
    x[652]    c293_1    1
    x[652]    c184_1    -168
    x[652]    c229_1    -187
    x[652]    c207      1
    x[652]    c212      1
    x[653]    c185_1    -168
    x[653]    c230_1    -187
    x[653]    c207      1
    x[653]    c213      1
    x[654]    c294_1    1
    x[654]    c186_1    -168
    x[654]    c231_1    -187
    x[654]    c207      1
    x[654]    c214      1
    x[655]    c295_1    1
    x[655]    c187_1    -168
    x[655]    c232_1    -187
    x[655]    c207      1
    x[655]    c215      1
    x[656]    c188_1    -168
    x[656]    c233_1    -187
    x[656]    c207      1
    x[656]    c216      1
    x[657]    c291_1    1
    x[657]    c292_1    1
    x[657]    c293_1    1
    x[657]    c294_1    1
    x[657]    c295_1    1
    x[657]    c189_1    -168
    x[657]    c234_1    -187
    x[657]    c207      1
    x[657]    c208      1
    x[658]    c322_1    1
    x[658]    c323_1    1
    x[658]    c324_1    1
    x[658]    c325_1    1
    x[658]    c197_1    -168
    x[658]    c242_1    -187
    x[658]    c208      1
    x[658]    c209      -1
    x[659]    c322_1    1
    x[659]    c204_1    -168
    x[659]    c249_1    -187
    x[659]    c208      1
    x[659]    c210      -1
    x[660]    c323_1    1
    x[660]    c210_1    -168
    x[660]    c255_1    -187
    x[660]    c208      1
    x[660]    c211      -1
    x[661]    c215_1    -168
    x[661]    c260_1    -187
    x[661]    c208      1
    x[661]    c212      -1
    x[662]    c219_1    -168
    x[662]    c264_1    -187
    x[662]    c208      1
    x[662]    c213      -1
    x[663]    c324_1    1
    x[663]    c222_1    -168
    x[663]    c267_1    -187
    x[663]    c208      1
    x[663]    c214      -1
    x[664]    c325_1    1
    x[664]    c224_1    -168
    x[664]    c269_1    -187
    x[664]    c208      1
    x[664]    c215      -1
    x[665]    c225_1    -168
    x[665]    c270_1    -187
    x[665]    c208      1
    x[665]    c216      -1
    x[666]    c190_1    -187
    x[666]    c235_1    -168
    x[666]    c209      1
    x[666]    c210      -1
    x[667]    c191_1    -187
    x[667]    c236_1    -168
    x[667]    c209      1
    x[667]    c211      -1
    x[668]    c192_1    -187
    x[668]    c237_1    -168
    x[668]    c209      1
    x[668]    c212      -1
    x[669]    c193_1    -187
    x[669]    c238_1    -168
    x[669]    c209      1
    x[669]    c213      -1
    x[670]    c194_1    -187
    x[670]    c239_1    -168
    x[670]    c209      1
    x[670]    c214      -1
    x[671]    c195_1    -187
    x[671]    c240_1    -168
    x[671]    c209      1
    x[671]    c215      -1
    x[672]    c196_1    -187
    x[672]    c241_1    -168
    x[672]    c209      1
    x[672]    c216      -1
    x[673]    c190_1    -168
    x[673]    c235_1    -187
    x[673]    c209      -1
    x[673]    c210      1
    x[674]    c191_1    -168
    x[674]    c236_1    -187
    x[674]    c209      -1
    x[674]    c211      1
    x[675]    c192_1    -168
    x[675]    c237_1    -187
    x[675]    c209      -1
    x[675]    c212      1
    x[676]    c193_1    -168
    x[676]    c238_1    -187
    x[676]    c209      -1
    x[676]    c213      1
    x[677]    c194_1    -168
    x[677]    c239_1    -187
    x[677]    c209      -1
    x[677]    c214      1
    x[678]    c195_1    -168
    x[678]    c240_1    -187
    x[678]    c209      -1
    x[678]    c215      1
    x[679]    c196_1    -168
    x[679]    c241_1    -187
    x[679]    c209      -1
    x[679]    c216      1
    x[680]    c198_1    -187
    x[680]    c243_1    -168
    x[680]    c210      1
    x[680]    c211      -1
    x[681]    c199_1    -187
    x[681]    c244_1    -168
    x[681]    c210      1
    x[681]    c212      -1
    x[682]    c200_1    -187
    x[682]    c245_1    -168
    x[682]    c210      1
    x[682]    c213      -1
    x[683]    c201_1    -187
    x[683]    c246_1    -168
    x[683]    c210      1
    x[683]    c214      -1
    x[684]    c202_1    -187
    x[684]    c247_1    -168
    x[684]    c210      1
    x[684]    c215      -1
    x[685]    c203_1    -187
    x[685]    c248_1    -168
    x[685]    c210      1
    x[685]    c216      -1
    x[686]    c198_1    -168
    x[686]    c243_1    -187
    x[686]    c210      -1
    x[686]    c211      1
    x[687]    c199_1    -168
    x[687]    c244_1    -187
    x[687]    c210      -1
    x[687]    c212      1
    x[688]    c200_1    -168
    x[688]    c245_1    -187
    x[688]    c210      -1
    x[688]    c213      1
    x[689]    c201_1    -168
    x[689]    c246_1    -187
    x[689]    c210      -1
    x[689]    c214      1
    x[690]    c202_1    -168
    x[690]    c247_1    -187
    x[690]    c210      -1
    x[690]    c215      1
    x[691]    c203_1    -168
    x[691]    c248_1    -187
    x[691]    c210      -1
    x[691]    c216      1
    x[692]    c205_1    -187
    x[692]    c250_1    -168
    x[692]    c211      1
    x[692]    c212      -1
    x[693]    c206_1    -187
    x[693]    c251_1    -168
    x[693]    c211      1
    x[693]    c213      -1
    x[694]    c207_1    -187
    x[694]    c252_1    -168
    x[694]    c211      1
    x[694]    c214      -1
    x[695]    c208_1    -187
    x[695]    c253_1    -168
    x[695]    c211      1
    x[695]    c215      -1
    x[696]    c209_1    -187
    x[696]    c254_1    -168
    x[696]    c211      1
    x[696]    c216      -1
    x[697]    c205_1    -168
    x[697]    c250_1    -187
    x[697]    c211      -1
    x[697]    c212      1
    x[698]    c206_1    -168
    x[698]    c251_1    -187
    x[698]    c211      -1
    x[698]    c213      1
    x[699]    c207_1    -168
    x[699]    c252_1    -187
    x[699]    c211      -1
    x[699]    c214      1
    x[700]    c208_1    -168
    x[700]    c253_1    -187
    x[700]    c211      -1
    x[700]    c215      1
    x[701]    c209_1    -168
    x[701]    c254_1    -187
    x[701]    c211      -1
    x[701]    c216      1
    x[702]    c211_1    -187
    x[702]    c256_1    -168
    x[702]    c212      1
    x[702]    c213      -1
    x[703]    c212_1    -187
    x[703]    c257_1    -168
    x[703]    c212      1
    x[703]    c214      -1
    x[704]    c213_1    -187
    x[704]    c258_1    -168
    x[704]    c212      1
    x[704]    c215      -1
    x[705]    c214_1    -187
    x[705]    c259_1    -168
    x[705]    c212      1
    x[705]    c216      -1
    x[706]    c211_1    -168
    x[706]    c256_1    -187
    x[706]    c212      -1
    x[706]    c213      1
    x[707]    c212_1    -168
    x[707]    c257_1    -187
    x[707]    c212      -1
    x[707]    c214      1
    x[708]    c213_1    -168
    x[708]    c258_1    -187
    x[708]    c212      -1
    x[708]    c215      1
    x[709]    c214_1    -168
    x[709]    c259_1    -187
    x[709]    c212      -1
    x[709]    c216      1
    x[710]    c216_1    -187
    x[710]    c261_1    -168
    x[710]    c213      1
    x[710]    c214      -1
    x[711]    c217_1    -187
    x[711]    c262_1    -168
    x[711]    c213      1
    x[711]    c215      -1
    x[712]    c218_1    -187
    x[712]    c263_1    -168
    x[712]    c213      1
    x[712]    c216      -1
    x[713]    c216_1    -168
    x[713]    c261_1    -187
    x[713]    c213      -1
    x[713]    c214      1
    x[714]    c217_1    -168
    x[714]    c262_1    -187
    x[714]    c213      -1
    x[714]    c215      1
    x[715]    c218_1    -168
    x[715]    c263_1    -187
    x[715]    c213      -1
    x[715]    c216      1
    x[716]    c220_1    -187
    x[716]    c265_1    -168
    x[716]    c214      1
    x[716]    c215      -1
    x[717]    c221_1    -187
    x[717]    c266_1    -168
    x[717]    c214      1
    x[717]    c216      -1
    x[718]    c220_1    -168
    x[718]    c265_1    -187
    x[718]    c214      -1
    x[718]    c215      1
    x[719]    c221_1    -168
    x[719]    c266_1    -187
    x[719]    c214      -1
    x[719]    c216      1
    x[720]    c223_1    -187
    x[720]    c268_1    -168
    x[720]    c215      1
    x[720]    c216      -1
    x[721]    c223_1    -168
    x[721]    c268_1    -187
    x[721]    c215      -1
    x[721]    c216      1
    x[722]    c189_1    -128
    x[722]    c234_1    -128
    x[722]    c217      1
    x[723]    c197_1    -128
    x[723]    c242_1    -128
    x[723]    c218      1
    x[724]    c204_1    -128
    x[724]    c249_1    -128
    x[724]    c219      1
    x[725]    c210_1    -128
    x[725]    c255_1    -128
    x[725]    c220      1
    x[726]    c215_1    -128
    x[726]    c260_1    -128
    x[726]    c221      1
    x[727]    c219_1    -128
    x[727]    c264_1    -128
    x[727]    c222      1
    x[728]    c222_1    -128
    x[728]    c267_1    -128
    x[728]    c223      1
    x[729]    c224_1    -128
    x[729]    c269_1    -128
    x[729]    c224      1
    x[730]    c225_1    -128
    x[730]    c270_1    -128
    x[730]    c225      1
    x[731]    c188_1    -128
    x[731]    c233_1    -128
    x[731]    c226      1
    x[732]    c196_1    -128
    x[732]    c241_1    -128
    x[732]    c227      1
    x[733]    c203_1    -128
    x[733]    c248_1    -128
    x[733]    c228      1
    x[734]    c209_1    -128
    x[734]    c254_1    -128
    x[734]    c229      1
    x[735]    c214_1    -128
    x[735]    c259_1    -128
    x[735]    c230      1
    x[736]    c218_1    -128
    x[736]    c263_1    -128
    x[736]    c231      1
    x[737]    c221_1    -128
    x[737]    c266_1    -128
    x[737]    c232      1
    x[738]    c223_1    -128
    x[738]    c268_1    -128
    x[738]    c233      1
    x[739]    c1_2      1
    x[739]    c189_1    -128
    x[739]    c234_1    -128
    x[739]    c234      1
    x[739]    c236      1
    x[740]    c197_1    -128
    x[740]    c242_1    -128
    x[740]    c234      1
    x[740]    c237      1
    x[741]    c2_2      1
    x[741]    c204_1    -128
    x[741]    c249_1    -128
    x[741]    c234      1
    x[741]    c238      1
    x[742]    c210_1    -128
    x[742]    c255_1    -128
    x[742]    c234      1
    x[742]    c239      1
    x[743]    c3_2      1
    x[743]    c215_1    -128
    x[743]    c260_1    -128
    x[743]    c234      1
    x[743]    c240      1
    x[744]    c4_2      1
    x[744]    c219_1    -128
    x[744]    c264_1    -128
    x[744]    c234      1
    x[744]    c241      1
    x[745]    c222_1    -128
    x[745]    c267_1    -128
    x[745]    c234      1
    x[745]    c242      1
    x[746]    c224_1    -128
    x[746]    c269_1    -128
    x[746]    c234      1
    x[746]    c243      1
    x[747]    c1_2      1
    x[747]    c2_2      1
    x[747]    c3_2      1
    x[747]    c4_2      1
    x[747]    c225_1    -128
    x[747]    c270_1    -128
    x[747]    c234      1
    x[747]    c235      1
    x[748]    c50_2     1
    x[748]    c51_2     1
    x[748]    c52_2     1
    x[748]    c53_2     1
    x[748]    c188_1    -128
    x[748]    c233_1    -128
    x[748]    c235      1
    x[748]    c236      -1
    x[749]    c50_2     1
    x[749]    c196_1    -128
    x[749]    c241_1    -128
    x[749]    c235      1
    x[749]    c237      -1
    x[750]    c203_1    -128
    x[750]    c248_1    -128
    x[750]    c235      1
    x[750]    c238      -1
    x[751]    c209_1    -128
    x[751]    c254_1    -128
    x[751]    c235      1
    x[751]    c239      -1
    x[752]    c51_2     1
    x[752]    c214_1    -128
    x[752]    c259_1    -128
    x[752]    c235      1
    x[752]    c240      -1
    x[753]    c52_2     1
    x[753]    c218_1    -128
    x[753]    c263_1    -128
    x[753]    c235      1
    x[753]    c241      -1
    x[754]    c221_1    -128
    x[754]    c266_1    -128
    x[754]    c235      1
    x[754]    c242      -1
    x[755]    c53_2     1
    x[755]    c223_1    -128
    x[755]    c268_1    -128
    x[755]    c235      1
    x[755]    c243      -1
    x[756]    c181_1    -128
    x[756]    c226_1    -128
    x[756]    c236      1
    x[756]    c237      -1
    x[757]    c182_1    -128
    x[757]    c227_1    -128
    x[757]    c236      1
    x[757]    c238      -1
    x[758]    c183_1    -128
    x[758]    c228_1    -128
    x[758]    c236      1
    x[758]    c239      -1
    x[759]    c184_1    -128
    x[759]    c229_1    -128
    x[759]    c236      1
    x[759]    c240      -1
    x[760]    c185_1    -128
    x[760]    c230_1    -128
    x[760]    c236      1
    x[760]    c241      -1
    x[761]    c186_1    -128
    x[761]    c231_1    -128
    x[761]    c236      1
    x[761]    c242      -1
    x[762]    c187_1    -128
    x[762]    c232_1    -128
    x[762]    c236      1
    x[762]    c243      -1
    x[763]    c181_1    -128
    x[763]    c226_1    -128
    x[763]    c236      -1
    x[763]    c237      1
    x[764]    c182_1    -128
    x[764]    c227_1    -128
    x[764]    c236      -1
    x[764]    c238      1
    x[765]    c183_1    -128
    x[765]    c228_1    -128
    x[765]    c236      -1
    x[765]    c239      1
    x[766]    c184_1    -128
    x[766]    c229_1    -128
    x[766]    c236      -1
    x[766]    c240      1
    x[767]    c185_1    -128
    x[767]    c230_1    -128
    x[767]    c236      -1
    x[767]    c241      1
    x[768]    c186_1    -128
    x[768]    c231_1    -128
    x[768]    c236      -1
    x[768]    c242      1
    x[769]    c187_1    -128
    x[769]    c232_1    -128
    x[769]    c236      -1
    x[769]    c243      1
    x[770]    c190_1    -128
    x[770]    c235_1    -128
    x[770]    c237      1
    x[770]    c238      -1
    x[771]    c191_1    -128
    x[771]    c236_1    -128
    x[771]    c237      1
    x[771]    c239      -1
    x[772]    c192_1    -128
    x[772]    c237_1    -128
    x[772]    c237      1
    x[772]    c240      -1
    x[773]    c193_1    -128
    x[773]    c238_1    -128
    x[773]    c237      1
    x[773]    c241      -1
    x[774]    c194_1    -128
    x[774]    c239_1    -128
    x[774]    c237      1
    x[774]    c242      -1
    x[775]    c195_1    -128
    x[775]    c240_1    -128
    x[775]    c237      1
    x[775]    c243      -1
    x[776]    c190_1    -128
    x[776]    c235_1    -128
    x[776]    c237      -1
    x[776]    c238      1
    x[777]    c191_1    -128
    x[777]    c236_1    -128
    x[777]    c237      -1
    x[777]    c239      1
    x[778]    c192_1    -128
    x[778]    c237_1    -128
    x[778]    c237      -1
    x[778]    c240      1
    x[779]    c193_1    -128
    x[779]    c238_1    -128
    x[779]    c237      -1
    x[779]    c241      1
    x[780]    c194_1    -128
    x[780]    c239_1    -128
    x[780]    c237      -1
    x[780]    c242      1
    x[781]    c195_1    -128
    x[781]    c240_1    -128
    x[781]    c237      -1
    x[781]    c243      1
    x[782]    c198_1    -128
    x[782]    c243_1    -128
    x[782]    c238      1
    x[782]    c239      -1
    x[783]    c199_1    -128
    x[783]    c244_1    -128
    x[783]    c238      1
    x[783]    c240      -1
    x[784]    c200_1    -128
    x[784]    c245_1    -128
    x[784]    c238      1
    x[784]    c241      -1
    x[785]    c201_1    -128
    x[785]    c246_1    -128
    x[785]    c238      1
    x[785]    c242      -1
    x[786]    c202_1    -128
    x[786]    c247_1    -128
    x[786]    c238      1
    x[786]    c243      -1
    x[787]    c198_1    -128
    x[787]    c243_1    -128
    x[787]    c238      -1
    x[787]    c239      1
    x[788]    c199_1    -128
    x[788]    c244_1    -128
    x[788]    c238      -1
    x[788]    c240      1
    x[789]    c200_1    -128
    x[789]    c245_1    -128
    x[789]    c238      -1
    x[789]    c241      1
    x[790]    c201_1    -128
    x[790]    c246_1    -128
    x[790]    c238      -1
    x[790]    c242      1
    x[791]    c202_1    -128
    x[791]    c247_1    -128
    x[791]    c238      -1
    x[791]    c243      1
    x[792]    c205_1    -128
    x[792]    c250_1    -128
    x[792]    c239      1
    x[792]    c240      -1
    x[793]    c206_1    -128
    x[793]    c251_1    -128
    x[793]    c239      1
    x[793]    c241      -1
    x[794]    c207_1    -128
    x[794]    c252_1    -128
    x[794]    c239      1
    x[794]    c242      -1
    x[795]    c208_1    -128
    x[795]    c253_1    -128
    x[795]    c239      1
    x[795]    c243      -1
    x[796]    c205_1    -128
    x[796]    c250_1    -128
    x[796]    c239      -1
    x[796]    c240      1
    x[797]    c206_1    -128
    x[797]    c251_1    -128
    x[797]    c239      -1
    x[797]    c241      1
    x[798]    c207_1    -128
    x[798]    c252_1    -128
    x[798]    c239      -1
    x[798]    c242      1
    x[799]    c208_1    -128
    x[799]    c253_1    -128
    x[799]    c239      -1
    x[799]    c243      1
    x[800]    c211_1    -128
    x[800]    c256_1    -128
    x[800]    c240      1
    x[800]    c241      -1
    x[801]    c212_1    -128
    x[801]    c257_1    -128
    x[801]    c240      1
    x[801]    c242      -1
    x[802]    c213_1    -128
    x[802]    c258_1    -128
    x[802]    c240      1
    x[802]    c243      -1
    x[803]    c211_1    -128
    x[803]    c256_1    -128
    x[803]    c240      -1
    x[803]    c241      1
    x[804]    c212_1    -128
    x[804]    c257_1    -128
    x[804]    c240      -1
    x[804]    c242      1
    x[805]    c213_1    -128
    x[805]    c258_1    -128
    x[805]    c240      -1
    x[805]    c243      1
    x[806]    c216_1    -128
    x[806]    c261_1    -128
    x[806]    c241      1
    x[806]    c242      -1
    x[807]    c217_1    -128
    x[807]    c262_1    -128
    x[807]    c241      1
    x[807]    c243      -1
    x[808]    c216_1    -128
    x[808]    c261_1    -128
    x[808]    c241      -1
    x[808]    c242      1
    x[809]    c217_1    -128
    x[809]    c262_1    -128
    x[809]    c241      -1
    x[809]    c243      1
    x[810]    c220_1    -128
    x[810]    c265_1    -128
    x[810]    c242      1
    x[810]    c243      -1
    x[811]    c220_1    -128
    x[811]    c265_1    -128
    x[811]    c242      -1
    x[811]    c243      1
    x[812]    c181_1    -73
    x[812]    c226_1    -136
    x[812]    c244      1
    x[813]    c198_1    -73
    x[813]    c243_1    -136
    x[813]    c245      1
    x[814]    c199_1    -73
    x[814]    c244_1    -136
    x[814]    c246      1
    x[815]    c200_1    -73
    x[815]    c245_1    -136
    x[815]    c247      1
    x[816]    c201_1    -73
    x[816]    c246_1    -136
    x[816]    c248      1
    x[817]    c202_1    -73
    x[817]    c247_1    -136
    x[817]    c249      1
    x[818]    c203_1    -73
    x[818]    c248_1    -136
    x[818]    c250      1
    x[819]    c204_1    -73
    x[819]    c249_1    -136
    x[819]    c251      1
    x[820]    c182_1    -136
    x[820]    c227_1    -73
    x[820]    c252      1
    x[821]    c190_1    -136
    x[821]    c235_1    -73
    x[821]    c253      1
    x[822]    c191_1    -136
    x[822]    c236_1    -73
    x[822]    c254      1
    x[823]    c192_1    -136
    x[823]    c237_1    -73
    x[823]    c255      1
    x[824]    c193_1    -136
    x[824]    c238_1    -73
    x[824]    c256      1
    x[825]    c194_1    -136
    x[825]    c239_1    -73
    x[825]    c257      1
    x[826]    c195_1    -136
    x[826]    c240_1    -73
    x[826]    c258      1
    x[827]    c196_1    -136
    x[827]    c241_1    -73
    x[827]    c259      1
    x[828]    c197_1    -136
    x[828]    c242_1    -73
    x[828]    c260      1
    x[829]    c83_2     1
    x[829]    c84_2     1
    x[829]    c85_2     1
    x[829]    c86_2     1
    x[829]    c87_2     1
    x[829]    c88_2     1
    x[829]    c190_1    -73
    x[829]    c235_1    -136
    x[829]    c261      1
    x[829]    c262      1
    x[830]    c191_1    -73
    x[830]    c236_1    -136
    x[830]    c261      1
    x[830]    c264      1
    x[831]    c192_1    -73
    x[831]    c237_1    -136
    x[831]    c261      1
    x[831]    c265      1
    x[832]    c83_2     1
    x[832]    c193_1    -73
    x[832]    c238_1    -136
    x[832]    c261      1
    x[832]    c266      1
    x[833]    c84_2     1
    x[833]    c194_1    -73
    x[833]    c239_1    -136
    x[833]    c261      1
    x[833]    c267      1
    x[834]    c85_2     1
    x[834]    c195_1    -73
    x[834]    c240_1    -136
    x[834]    c261      1
    x[834]    c268      1
    x[835]    c86_2     1
    x[835]    c196_1    -73
    x[835]    c241_1    -136
    x[835]    c261      1
    x[835]    c269      1
    x[836]    c87_2     1
    x[836]    c197_1    -73
    x[836]    c242_1    -136
    x[836]    c261      1
    x[836]    c270      1
    x[837]    c88_2     1
    x[837]    c181_1    -136
    x[837]    c226_1    -73
    x[837]    c261      1
    x[837]    c263      1
    x[838]    c139_2    1
    x[838]    c140_2    1
    x[838]    c141_2    1
    x[838]    c142_2    1
    x[838]    c143_2    1
    x[838]    c182_1    -73
    x[838]    c227_1    -136
    x[838]    c262      1
    x[838]    c263      -1
    x[839]    c139_2    1
    x[839]    c198_1    -136
    x[839]    c243_1    -73
    x[839]    c262      1
    x[839]    c264      -1
    x[840]    c199_1    -136
    x[840]    c244_1    -73
    x[840]    c262      1
    x[840]    c265      -1
    x[841]    c140_2    1
    x[841]    c200_1    -136
    x[841]    c245_1    -73
    x[841]    c262      1
    x[841]    c266      -1
    x[842]    c141_2    1
    x[842]    c201_1    -136
    x[842]    c246_1    -73
    x[842]    c262      1
    x[842]    c267      -1
    x[843]    c142_2    1
    x[843]    c202_1    -136
    x[843]    c247_1    -73
    x[843]    c262      1
    x[843]    c268      -1
    x[844]    c143_2    1
    x[844]    c203_1    -136
    x[844]    c248_1    -73
    x[844]    c262      1
    x[844]    c269      -1
    x[845]    c204_1    -136
    x[845]    c249_1    -73
    x[845]    c262      1
    x[845]    c270      -1
    x[846]    c183_1    -136
    x[846]    c228_1    -73
    x[846]    c263      1
    x[846]    c264      -1
    x[847]    c184_1    -136
    x[847]    c229_1    -73
    x[847]    c263      1
    x[847]    c265      -1
    x[848]    c185_1    -136
    x[848]    c230_1    -73
    x[848]    c263      1
    x[848]    c266      -1
    x[849]    c186_1    -136
    x[849]    c231_1    -73
    x[849]    c263      1
    x[849]    c267      -1
    x[850]    c187_1    -136
    x[850]    c232_1    -73
    x[850]    c263      1
    x[850]    c268      -1
    x[851]    c188_1    -136
    x[851]    c233_1    -73
    x[851]    c263      1
    x[851]    c269      -1
    x[852]    c189_1    -136
    x[852]    c234_1    -73
    x[852]    c263      1
    x[852]    c270      -1
    x[853]    c183_1    -73
    x[853]    c228_1    -136
    x[853]    c263      -1
    x[853]    c264      1
    x[854]    c184_1    -73
    x[854]    c229_1    -136
    x[854]    c263      -1
    x[854]    c265      1
    x[855]    c185_1    -73
    x[855]    c230_1    -136
    x[855]    c263      -1
    x[855]    c266      1
    x[856]    c186_1    -73
    x[856]    c231_1    -136
    x[856]    c263      -1
    x[856]    c267      1
    x[857]    c187_1    -73
    x[857]    c232_1    -136
    x[857]    c263      -1
    x[857]    c268      1
    x[858]    c188_1    -73
    x[858]    c233_1    -136
    x[858]    c263      -1
    x[858]    c269      1
    x[859]    c189_1    -73
    x[859]    c234_1    -136
    x[859]    c263      -1
    x[859]    c270      1
    x[860]    c205_1    -136
    x[860]    c250_1    -73
    x[860]    c264      1
    x[860]    c265      -1
    x[861]    c206_1    -136
    x[861]    c251_1    -73
    x[861]    c264      1
    x[861]    c266      -1
    x[862]    c207_1    -136
    x[862]    c252_1    -73
    x[862]    c264      1
    x[862]    c267      -1
    x[863]    c208_1    -136
    x[863]    c253_1    -73
    x[863]    c264      1
    x[863]    c268      -1
    x[864]    c209_1    -136
    x[864]    c254_1    -73
    x[864]    c264      1
    x[864]    c269      -1
    x[865]    c210_1    -136
    x[865]    c255_1    -73
    x[865]    c264      1
    x[865]    c270      -1
    x[866]    c205_1    -73
    x[866]    c250_1    -136
    x[866]    c264      -1
    x[866]    c265      1
    x[867]    c206_1    -73
    x[867]    c251_1    -136
    x[867]    c264      -1
    x[867]    c266      1
    x[868]    c207_1    -73
    x[868]    c252_1    -136
    x[868]    c264      -1
    x[868]    c267      1
    x[869]    c208_1    -73
    x[869]    c253_1    -136
    x[869]    c264      -1
    x[869]    c268      1
    x[870]    c209_1    -73
    x[870]    c254_1    -136
    x[870]    c264      -1
    x[870]    c269      1
    x[871]    c210_1    -73
    x[871]    c255_1    -136
    x[871]    c264      -1
    x[871]    c270      1
    x[872]    c211_1    -136
    x[872]    c256_1    -73
    x[872]    c265      1
    x[872]    c266      -1
    x[873]    c212_1    -136
    x[873]    c257_1    -73
    x[873]    c265      1
    x[873]    c267      -1
    x[874]    c213_1    -136
    x[874]    c258_1    -73
    x[874]    c265      1
    x[874]    c268      -1
    x[875]    c214_1    -136
    x[875]    c259_1    -73
    x[875]    c265      1
    x[875]    c269      -1
    x[876]    c215_1    -136
    x[876]    c260_1    -73
    x[876]    c265      1
    x[876]    c270      -1
    x[877]    c211_1    -73
    x[877]    c256_1    -136
    x[877]    c265      -1
    x[877]    c266      1
    x[878]    c212_1    -73
    x[878]    c257_1    -136
    x[878]    c265      -1
    x[878]    c267      1
    x[879]    c213_1    -73
    x[879]    c258_1    -136
    x[879]    c265      -1
    x[879]    c268      1
    x[880]    c214_1    -73
    x[880]    c259_1    -136
    x[880]    c265      -1
    x[880]    c269      1
    x[881]    c215_1    -73
    x[881]    c260_1    -136
    x[881]    c265      -1
    x[881]    c270      1
    x[882]    c216_1    -136
    x[882]    c261_1    -73
    x[882]    c266      1
    x[882]    c267      -1
    x[883]    c217_1    -136
    x[883]    c262_1    -73
    x[883]    c266      1
    x[883]    c268      -1
    x[884]    c218_1    -136
    x[884]    c263_1    -73
    x[884]    c266      1
    x[884]    c269      -1
    x[885]    c219_1    -136
    x[885]    c264_1    -73
    x[885]    c266      1
    x[885]    c270      -1
    x[886]    c216_1    -73
    x[886]    c261_1    -136
    x[886]    c266      -1
    x[886]    c267      1
    x[887]    c217_1    -73
    x[887]    c262_1    -136
    x[887]    c266      -1
    x[887]    c268      1
    x[888]    c218_1    -73
    x[888]    c263_1    -136
    x[888]    c266      -1
    x[888]    c269      1
    x[889]    c219_1    -73
    x[889]    c264_1    -136
    x[889]    c266      -1
    x[889]    c270      1
    x[890]    c220_1    -136
    x[890]    c265_1    -73
    x[890]    c267      1
    x[890]    c268      -1
    x[891]    c221_1    -136
    x[891]    c266_1    -73
    x[891]    c267      1
    x[891]    c269      -1
    x[892]    c222_1    -136
    x[892]    c267_1    -73
    x[892]    c267      1
    x[892]    c270      -1
    x[893]    c220_1    -73
    x[893]    c265_1    -136
    x[893]    c267      -1
    x[893]    c268      1
    x[894]    c221_1    -73
    x[894]    c266_1    -136
    x[894]    c267      -1
    x[894]    c269      1
    x[895]    c222_1    -73
    x[895]    c267_1    -136
    x[895]    c267      -1
    x[895]    c270      1
    x[896]    c223_1    -136
    x[896]    c268_1    -73
    x[896]    c268      1
    x[896]    c269      -1
    x[897]    c224_1    -136
    x[897]    c269_1    -73
    x[897]    c268      1
    x[897]    c270      -1
    x[898]    c223_1    -73
    x[898]    c268_1    -136
    x[898]    c268      -1
    x[898]    c269      1
    x[899]    c224_1    -73
    x[899]    c269_1    -136
    x[899]    c268      -1
    x[899]    c270      1
    x[900]    c225_1    -136
    x[900]    c270_1    -73
    x[900]    c269      1
    x[900]    c270      -1
    x[901]    c225_1    -73
    x[901]    c270_1    -136
    x[901]    c269      -1
    x[901]    c270      1
    x[902]    c181_1    -73
    x[902]    c271      1
    x[903]    c205_1    -73
    x[903]    c272      1
    x[904]    c206_1    -73
    x[904]    c273      1
    x[905]    c207_1    -73
    x[905]    c274      1
    x[906]    c208_1    -73
    x[906]    c275      1
    x[907]    c209_1    -73
    x[907]    c276      1
    x[908]    c210_1    -73
    x[908]    c277      1
    x[909]    c228_1    -73
    x[909]    c278      1
    x[910]    c235_1    -73
    x[910]    c279      1
    x[911]    c236_1    -73
    x[911]    c280      1
    x[912]    c237_1    -73
    x[912]    c281      1
    x[913]    c238_1    -73
    x[913]    c282      1
    x[914]    c239_1    -73
    x[914]    c283      1
    x[915]    c240_1    -73
    x[915]    c284      1
    x[916]    c241_1    -73
    x[916]    c285      1
    x[917]    c242_1    -73
    x[917]    c286      1
    x[918]    c243_1    -73
    x[918]    c287      1
    x[919]    c190_1    -73
    x[919]    c288      1
    x[919]    c291      1
    x[920]    c176_2    1
    x[920]    c177_2    1
    x[920]    c178_2    1
    x[920]    c179_2    1
    x[920]    c180_2    1
    x[920]    c191_1    -73
    x[920]    c288      1
    x[920]    c289      1
    x[921]    c176_2    1
    x[921]    c192_1    -73
    x[921]    c288      1
    x[921]    c292      1
    x[922]    c193_1    -73
    x[922]    c288      1
    x[922]    c293      1
    x[923]    c177_2    1
    x[923]    c194_1    -73
    x[923]    c288      1
    x[923]    c294      1
    x[924]    c178_2    1
    x[924]    c195_1    -73
    x[924]    c288      1
    x[924]    c295      1
    x[925]    c196_1    -73
    x[925]    c288      1
    x[925]    c296      1
    x[926]    c179_2    1
    x[926]    c197_1    -73
    x[926]    c288      1
    x[926]    c297      1
    x[927]    c180_2    1
    x[927]    c226_1    -73
    x[927]    c288      1
    x[927]    c290      1
    x[928]    c240_2    1
    x[928]    c241_2    1
    x[928]    c183_1    -73
    x[928]    c289      1
    x[928]    c290      -1
    x[929]    c240_2    1
    x[929]    c198_1    -73
    x[929]    c289      1
    x[929]    c291      -1
    x[930]    c241_2    1
    x[930]    c250_1    -73
    x[930]    c289      1
    x[930]    c292      -1
    x[931]    c251_1    -73
    x[931]    c289      1
    x[931]    c293      -1
    x[932]    c252_1    -73
    x[932]    c289      1
    x[932]    c294      -1
    x[933]    c253_1    -73
    x[933]    c289      1
    x[933]    c295      -1
    x[934]    c254_1    -73
    x[934]    c289      1
    x[934]    c296      -1
    x[935]    c255_1    -73
    x[935]    c289      1
    x[935]    c297      -1
    x[936]    c227_1    -73
    x[936]    c290      1
    x[936]    c291      -1
    x[937]    c229_1    -73
    x[937]    c290      1
    x[937]    c292      -1
    x[938]    c230_1    -73
    x[938]    c290      1
    x[938]    c293      -1
    x[939]    c231_1    -73
    x[939]    c290      1
    x[939]    c294      -1
    x[940]    c232_1    -73
    x[940]    c290      1
    x[940]    c295      -1
    x[941]    c233_1    -73
    x[941]    c290      1
    x[941]    c296      -1
    x[942]    c234_1    -73
    x[942]    c290      1
    x[942]    c297      -1
    x[943]    c182_1    -73
    x[943]    c290      -1
    x[943]    c291      1
    x[944]    c184_1    -73
    x[944]    c290      -1
    x[944]    c292      1
    x[945]    c185_1    -73
    x[945]    c290      -1
    x[945]    c293      1
    x[946]    c186_1    -73
    x[946]    c290      -1
    x[946]    c294      1
    x[947]    c187_1    -73
    x[947]    c290      -1
    x[947]    c295      1
    x[948]    c188_1    -73
    x[948]    c290      -1
    x[948]    c296      1
    x[949]    c189_1    -73
    x[949]    c290      -1
    x[949]    c297      1
    x[950]    c244_1    -73
    x[950]    c291      1
    x[950]    c292      -1
    x[951]    c245_1    -73
    x[951]    c291      1
    x[951]    c293      -1
    x[952]    c246_1    -73
    x[952]    c291      1
    x[952]    c294      -1
    x[953]    c247_1    -73
    x[953]    c291      1
    x[953]    c295      -1
    x[954]    c248_1    -73
    x[954]    c291      1
    x[954]    c296      -1
    x[955]    c249_1    -73
    x[955]    c291      1
    x[955]    c297      -1
    x[956]    c199_1    -73
    x[956]    c291      -1
    x[956]    c292      1
    x[957]    c200_1    -73
    x[957]    c291      -1
    x[957]    c293      1
    x[958]    c201_1    -73
    x[958]    c291      -1
    x[958]    c294      1
    x[959]    c202_1    -73
    x[959]    c291      -1
    x[959]    c295      1
    x[960]    c203_1    -73
    x[960]    c291      -1
    x[960]    c296      1
    x[961]    c204_1    -73
    x[961]    c291      -1
    x[961]    c297      1
    x[962]    c256_1    -73
    x[962]    c292      1
    x[962]    c293      -1
    x[963]    c257_1    -73
    x[963]    c292      1
    x[963]    c294      -1
    x[964]    c258_1    -73
    x[964]    c292      1
    x[964]    c295      -1
    x[965]    c259_1    -73
    x[965]    c292      1
    x[965]    c296      -1
    x[966]    c260_1    -73
    x[966]    c292      1
    x[966]    c297      -1
    x[967]    c211_1    -73
    x[967]    c292      -1
    x[967]    c293      1
    x[968]    c212_1    -73
    x[968]    c292      -1
    x[968]    c294      1
    x[969]    c213_1    -73
    x[969]    c292      -1
    x[969]    c295      1
    x[970]    c214_1    -73
    x[970]    c292      -1
    x[970]    c296      1
    x[971]    c215_1    -73
    x[971]    c292      -1
    x[971]    c297      1
    x[972]    c261_1    -73
    x[972]    c293      1
    x[972]    c294      -1
    x[973]    c262_1    -73
    x[973]    c293      1
    x[973]    c295      -1
    x[974]    c263_1    -73
    x[974]    c293      1
    x[974]    c296      -1
    x[975]    c264_1    -73
    x[975]    c293      1
    x[975]    c297      -1
    x[976]    c216_1    -73
    x[976]    c293      -1
    x[976]    c294      1
    x[977]    c217_1    -73
    x[977]    c293      -1
    x[977]    c295      1
    x[978]    c218_1    -73
    x[978]    c293      -1
    x[978]    c296      1
    x[979]    c219_1    -73
    x[979]    c293      -1
    x[979]    c297      1
    x[980]    c265_1    -73
    x[980]    c294      1
    x[980]    c295      -1
    x[981]    c266_1    -73
    x[981]    c294      1
    x[981]    c296      -1
    x[982]    c267_1    -73
    x[982]    c294      1
    x[982]    c297      -1
    x[983]    c220_1    -73
    x[983]    c294      -1
    x[983]    c295      1
    x[984]    c221_1    -73
    x[984]    c294      -1
    x[984]    c296      1
    x[985]    c222_1    -73
    x[985]    c294      -1
    x[985]    c297      1
    x[986]    c268_1    -73
    x[986]    c295      1
    x[986]    c296      -1
    x[987]    c269_1    -73
    x[987]    c295      1
    x[987]    c297      -1
    x[988]    c223_1    -73
    x[988]    c295      -1
    x[988]    c296      1
    x[989]    c224_1    -73
    x[989]    c295      -1
    x[989]    c297      1
    x[990]    c270_1    -73
    x[990]    c296      1
    x[990]    c297      -1
    x[991]    c225_1    -73
    x[991]    c296      -1
    x[991]    c297      1
    x[992]    c181_1    -72
    x[992]    c226_1    -134
    x[992]    c298      1
    x[993]    c211_1    -72
    x[993]    c256_1    -134
    x[993]    c299      1
    x[994]    c212_1    -72
    x[994]    c257_1    -134
    x[994]    c300      1
    x[995]    c213_1    -72
    x[995]    c258_1    -134
    x[995]    c301      1
    x[996]    c214_1    -72
    x[996]    c259_1    -134
    x[996]    c302      1
    x[997]    c215_1    -72
    x[997]    c260_1    -134
    x[997]    c303      1
    x[998]    c184_1    -134
    x[998]    c229_1    -72
    x[998]    c304      1
    x[999]    c190_1    -134
    x[999]    c235_1    -72
    x[999]    c305      1
    x[1000]   c191_1    -134
    x[1000]   c236_1    -72
    x[1000]   c306      1
    x[1001]   c192_1    -134
    x[1001]   c237_1    -72
    x[1001]   c307      1
    x[1002]   c193_1    -134
    x[1002]   c238_1    -72
    x[1002]   c308      1
    x[1003]   c194_1    -134
    x[1003]   c239_1    -72
    x[1003]   c309      1
    x[1004]   c195_1    -134
    x[1004]   c240_1    -72
    x[1004]   c310      1
    x[1005]   c196_1    -134
    x[1005]   c241_1    -72
    x[1005]   c311      1
    x[1006]   c197_1    -134
    x[1006]   c242_1    -72
    x[1006]   c312      1
    x[1007]   c199_1    -134
    x[1007]   c244_1    -72
    x[1007]   c313      1
    x[1008]   c205_1    -134
    x[1008]   c250_1    -72
    x[1008]   c314      1
    x[1009]   c270_2    1
    x[1009]   c286_1    1
    x[1009]   c190_1    -72
    x[1009]   c235_1    -134
    x[1009]   c315      1
    x[1009]   c318      1
    x[1010]   c271_2    1
    x[1010]   c191_1    -72
    x[1010]   c236_1    -134
    x[1010]   c315      1
    x[1010]   c319      1
    x[1011]   c270_2    1
    x[1011]   c271_2    1
    x[1011]   c272_1    1
    x[1011]   c273_1    1
    x[1011]   c274_1    1
    x[1011]   c192_1    -72
    x[1011]   c237_1    -134
    x[1011]   c315      1
    x[1011]   c316      1
    x[1012]   c286_1    1
    x[1012]   c193_1    -72
    x[1012]   c238_1    -134
    x[1012]   c315      1
    x[1012]   c320      1
    x[1013]   c194_1    -72
    x[1013]   c239_1    -134
    x[1013]   c315      1
    x[1013]   c321      1
    x[1014]   c272_1    1
    x[1014]   c195_1    -72
    x[1014]   c240_1    -134
    x[1014]   c315      1
    x[1014]   c322      1
    x[1015]   c196_1    -72
    x[1015]   c241_1    -134
    x[1015]   c315      1
    x[1015]   c323      1
    x[1016]   c273_1    1
    x[1016]   c197_1    -72
    x[1016]   c242_1    -134
    x[1016]   c315      1
    x[1016]   c324      1
    x[1017]   c274_1    1
    x[1017]   c181_1    -134
    x[1017]   c226_1    -72
    x[1017]   c315      1
    x[1017]   c317      1
    x[1018]   c326_1    1
    x[1018]   c327_1    1
    x[1018]   c328_1    1
    x[1018]   c184_1    -72
    x[1018]   c229_1    -134
    x[1018]   c316      1
    x[1018]   c317      -1
    x[1019]   c326_1    1
    x[1019]   c199_1    -72
    x[1019]   c244_1    -134
    x[1019]   c316      1
    x[1019]   c318      -1
    x[1020]   c327_1    1
    x[1020]   c205_1    -72
    x[1020]   c250_1    -134
    x[1020]   c316      1
    x[1020]   c319      -1
    x[1021]   c211_1    -134
    x[1021]   c256_1    -72
    x[1021]   c316      1
    x[1021]   c320      -1
    x[1022]   c328_1    1
    x[1022]   c212_1    -134
    x[1022]   c257_1    -72
    x[1022]   c316      1
    x[1022]   c321      -1
    x[1023]   c213_1    -134
    x[1023]   c258_1    -72
    x[1023]   c316      1
    x[1023]   c322      -1
    x[1024]   c214_1    -134
    x[1024]   c259_1    -72
    x[1024]   c316      1
    x[1024]   c323      -1
    x[1025]   c215_1    -134
    x[1025]   c260_1    -72
    x[1025]   c316      1
    x[1025]   c324      -1
    x[1026]   c182_1    -134
    x[1026]   c227_1    -72
    x[1026]   c317      1
    x[1026]   c318      -1
    x[1027]   c183_1    -134
    x[1027]   c228_1    -72
    x[1027]   c317      1
    x[1027]   c319      -1
    x[1028]   c185_1    -134
    x[1028]   c230_1    -72
    x[1028]   c317      1
    x[1028]   c320      -1
    x[1029]   c186_1    -134
    x[1029]   c231_1    -72
    x[1029]   c317      1
    x[1029]   c321      -1
    x[1030]   c187_1    -134
    x[1030]   c232_1    -72
    x[1030]   c317      1
    x[1030]   c322      -1
    x[1031]   c188_1    -134
    x[1031]   c233_1    -72
    x[1031]   c317      1
    x[1031]   c323      -1
    x[1032]   c189_1    -134
    x[1032]   c234_1    -72
    x[1032]   c317      1
    x[1032]   c324      -1
    x[1033]   c182_1    -72
    x[1033]   c227_1    -134
    x[1033]   c317      -1
    x[1033]   c318      1
    x[1034]   c183_1    -72
    x[1034]   c228_1    -134
    x[1034]   c317      -1
    x[1034]   c319      1
    x[1035]   c185_1    -72
    x[1035]   c230_1    -134
    x[1035]   c317      -1
    x[1035]   c320      1
    x[1036]   c186_1    -72
    x[1036]   c231_1    -134
    x[1036]   c317      -1
    x[1036]   c321      1
    x[1037]   c187_1    -72
    x[1037]   c232_1    -134
    x[1037]   c317      -1
    x[1037]   c322      1
    x[1038]   c188_1    -72
    x[1038]   c233_1    -134
    x[1038]   c317      -1
    x[1038]   c323      1
    x[1039]   c189_1    -72
    x[1039]   c234_1    -134
    x[1039]   c317      -1
    x[1039]   c324      1
    x[1040]   c198_1    -134
    x[1040]   c243_1    -72
    x[1040]   c318      1
    x[1040]   c319      -1
    x[1041]   c200_1    -134
    x[1041]   c245_1    -72
    x[1041]   c318      1
    x[1041]   c320      -1
    x[1042]   c201_1    -134
    x[1042]   c246_1    -72
    x[1042]   c318      1
    x[1042]   c321      -1
    x[1043]   c202_1    -134
    x[1043]   c247_1    -72
    x[1043]   c318      1
    x[1043]   c322      -1
    x[1044]   c203_1    -134
    x[1044]   c248_1    -72
    x[1044]   c318      1
    x[1044]   c323      -1
    x[1045]   c204_1    -134
    x[1045]   c249_1    -72
    x[1045]   c318      1
    x[1045]   c324      -1
    x[1046]   c198_1    -72
    x[1046]   c243_1    -134
    x[1046]   c318      -1
    x[1046]   c319      1
    x[1047]   c200_1    -72
    x[1047]   c245_1    -134
    x[1047]   c318      -1
    x[1047]   c320      1
    x[1048]   c201_1    -72
    x[1048]   c246_1    -134
    x[1048]   c318      -1
    x[1048]   c321      1
    x[1049]   c202_1    -72
    x[1049]   c247_1    -134
    x[1049]   c318      -1
    x[1049]   c322      1
    x[1050]   c203_1    -72
    x[1050]   c248_1    -134
    x[1050]   c318      -1
    x[1050]   c323      1
    x[1051]   c204_1    -72
    x[1051]   c249_1    -134
    x[1051]   c318      -1
    x[1051]   c324      1
    x[1052]   c206_1    -134
    x[1052]   c251_1    -72
    x[1052]   c319      1
    x[1052]   c320      -1
    x[1053]   c207_1    -134
    x[1053]   c252_1    -72
    x[1053]   c319      1
    x[1053]   c321      -1
    x[1054]   c208_1    -134
    x[1054]   c253_1    -72
    x[1054]   c319      1
    x[1054]   c322      -1
    x[1055]   c209_1    -134
    x[1055]   c254_1    -72
    x[1055]   c319      1
    x[1055]   c323      -1
    x[1056]   c210_1    -134
    x[1056]   c255_1    -72
    x[1056]   c319      1
    x[1056]   c324      -1
    x[1057]   c206_1    -72
    x[1057]   c251_1    -134
    x[1057]   c319      -1
    x[1057]   c320      1
    x[1058]   c207_1    -72
    x[1058]   c252_1    -134
    x[1058]   c319      -1
    x[1058]   c321      1
    x[1059]   c208_1    -72
    x[1059]   c253_1    -134
    x[1059]   c319      -1
    x[1059]   c322      1
    x[1060]   c209_1    -72
    x[1060]   c254_1    -134
    x[1060]   c319      -1
    x[1060]   c323      1
    x[1061]   c210_1    -72
    x[1061]   c255_1    -134
    x[1061]   c319      -1
    x[1061]   c324      1
    x[1062]   c216_1    -134
    x[1062]   c261_1    -72
    x[1062]   c320      1
    x[1062]   c321      -1
    x[1063]   c217_1    -134
    x[1063]   c262_1    -72
    x[1063]   c320      1
    x[1063]   c322      -1
    x[1064]   c218_1    -134
    x[1064]   c263_1    -72
    x[1064]   c320      1
    x[1064]   c323      -1
    x[1065]   c219_1    -134
    x[1065]   c264_1    -72
    x[1065]   c320      1
    x[1065]   c324      -1
    x[1066]   c216_1    -72
    x[1066]   c261_1    -134
    x[1066]   c320      -1
    x[1066]   c321      1
    x[1067]   c217_1    -72
    x[1067]   c262_1    -134
    x[1067]   c320      -1
    x[1067]   c322      1
    x[1068]   c218_1    -72
    x[1068]   c263_1    -134
    x[1068]   c320      -1
    x[1068]   c323      1
    x[1069]   c219_1    -72
    x[1069]   c264_1    -134
    x[1069]   c320      -1
    x[1069]   c324      1
    x[1070]   c220_1    -134
    x[1070]   c265_1    -72
    x[1070]   c321      1
    x[1070]   c322      -1
    x[1071]   c221_1    -134
    x[1071]   c266_1    -72
    x[1071]   c321      1
    x[1071]   c323      -1
    x[1072]   c222_1    -134
    x[1072]   c267_1    -72
    x[1072]   c321      1
    x[1072]   c324      -1
    x[1073]   c220_1    -72
    x[1073]   c265_1    -134
    x[1073]   c321      -1
    x[1073]   c322      1
    x[1074]   c221_1    -72
    x[1074]   c266_1    -134
    x[1074]   c321      -1
    x[1074]   c323      1
    x[1075]   c222_1    -72
    x[1075]   c267_1    -134
    x[1075]   c321      -1
    x[1075]   c324      1
    x[1076]   c223_1    -134
    x[1076]   c268_1    -72
    x[1076]   c322      1
    x[1076]   c323      -1
    x[1077]   c224_1    -134
    x[1077]   c269_1    -72
    x[1077]   c322      1
    x[1077]   c324      -1
    x[1078]   c223_1    -72
    x[1078]   c268_1    -134
    x[1078]   c322      -1
    x[1078]   c323      1
    x[1079]   c224_1    -72
    x[1079]   c269_1    -134
    x[1079]   c322      -1
    x[1079]   c324      1
    x[1080]   c225_1    -134
    x[1080]   c270_1    -72
    x[1080]   c323      1
    x[1080]   c324      -1
    x[1081]   c225_1    -72
    x[1081]   c270_1    -134
    x[1081]   c323      -1
    x[1081]   c324      1
    x[1082]   c181_1    -62
    x[1082]   c226_1    -182
    x[1082]   c325      1
    x[1083]   c216_1    -62
    x[1083]   c261_1    -182
    x[1083]   c326      1
    x[1084]   c217_1    -62
    x[1084]   c262_1    -182
    x[1084]   c327      1
    x[1085]   c218_1    -62
    x[1085]   c263_1    -182
    x[1085]   c328      1
    x[1086]   c219_1    -62
    x[1086]   c264_1    -182
    x[1086]   c329      1
    x[1087]   c185_1    -182
    x[1087]   c230_1    -62
    x[1087]   c330      1
    x[1088]   c190_1    -182
    x[1088]   c235_1    -62
    x[1088]   c331      1
    x[1089]   c191_1    -182
    x[1089]   c236_1    -62
    x[1089]   c332      1
    x[1090]   c192_1    -182
    x[1090]   c237_1    -62
    x[1090]   c333      1
    x[1091]   c193_1    -182
    x[1091]   c238_1    -62
    x[1091]   c334      1
    x[1092]   c194_1    -182
    x[1092]   c239_1    -62
    x[1092]   c335      1
    x[1093]   c195_1    -182
    x[1093]   c240_1    -62
    x[1093]   c336      1
    x[1094]   c196_1    -182
    x[1094]   c241_1    -62
    x[1094]   c337      1
    x[1095]   c197_1    -182
    x[1095]   c242_1    -62
    x[1095]   c338      1
    x[1096]   c200_1    -182
    x[1096]   c245_1    -62
    x[1096]   c339      1
    x[1097]   c206_1    -182
    x[1097]   c251_1    -62
    x[1097]   c340      1
    x[1098]   c211_1    -182
    x[1098]   c256_1    -62
    x[1098]   c341      1
    x[1099]   c190_1    -62
    x[1099]   c235_1    -182
    x[1099]   c342      1
    x[1099]   c345      1
    x[1100]   c191_1    -62
    x[1100]   c236_1    -182
    x[1100]   c342      1
    x[1100]   c346      1
    x[1101]   c192_1    -62
    x[1101]   c237_1    -182
    x[1101]   c342      1
    x[1101]   c347      1
    x[1102]   c193_1    -62
    x[1102]   c238_1    -182
    x[1102]   c342      1
    x[1102]   c343      1
    x[1103]   c194_1    -62
    x[1103]   c239_1    -182
    x[1103]   c342      1
    x[1103]   c348      1
    x[1104]   c195_1    -62
    x[1104]   c240_1    -182
    x[1104]   c342      1
    x[1104]   c349      1
    x[1105]   c196_1    -62
    x[1105]   c241_1    -182
    x[1105]   c342      1
    x[1105]   c350      1
    x[1106]   c197_1    -62
    x[1106]   c242_1    -182
    x[1106]   c342      1
    x[1106]   c351      1
    x[1107]   c181_1    -182
    x[1107]   c226_1    -62
    x[1107]   c342      1
    x[1107]   c344      1
    x[1108]   c31_2     1
    x[1108]   c185_1    -62
    x[1108]   c230_1    -182
    x[1108]   c343      1
    x[1108]   c344      -1
    x[1109]   c200_1    -62
    x[1109]   c245_1    -182
    x[1109]   c343      1
    x[1109]   c345      -1
    x[1110]   c206_1    -62
    x[1110]   c251_1    -182
    x[1110]   c343      1
    x[1110]   c346      -1
    x[1111]   c211_1    -62
    x[1111]   c256_1    -182
    x[1111]   c343      1
    x[1111]   c347      -1
    x[1112]   c216_1    -182
    x[1112]   c261_1    -62
    x[1112]   c343      1
    x[1112]   c348      -1
    x[1113]   c217_1    -182
    x[1113]   c262_1    -62
    x[1113]   c343      1
    x[1113]   c349      -1
    x[1114]   c218_1    -182
    x[1114]   c263_1    -62
    x[1114]   c343      1
    x[1114]   c350      -1
    x[1115]   c31_2     1
    x[1115]   c219_1    -182
    x[1115]   c264_1    -62
    x[1115]   c343      1
    x[1115]   c351      -1
    x[1116]   c182_1    -182
    x[1116]   c227_1    -62
    x[1116]   c344      1
    x[1116]   c345      -1
    x[1117]   c183_1    -182
    x[1117]   c228_1    -62
    x[1117]   c344      1
    x[1117]   c346      -1
    x[1118]   c184_1    -182
    x[1118]   c229_1    -62
    x[1118]   c344      1
    x[1118]   c347      -1
    x[1119]   c186_1    -182
    x[1119]   c231_1    -62
    x[1119]   c344      1
    x[1119]   c348      -1
    x[1120]   c187_1    -182
    x[1120]   c232_1    -62
    x[1120]   c344      1
    x[1120]   c349      -1
    x[1121]   c188_1    -182
    x[1121]   c233_1    -62
    x[1121]   c344      1
    x[1121]   c350      -1
    x[1122]   c189_1    -182
    x[1122]   c234_1    -62
    x[1122]   c344      1
    x[1122]   c351      -1
    x[1123]   c182_1    -62
    x[1123]   c227_1    -182
    x[1123]   c344      -1
    x[1123]   c345      1
    x[1124]   c183_1    -62
    x[1124]   c228_1    -182
    x[1124]   c344      -1
    x[1124]   c346      1
    x[1125]   c184_1    -62
    x[1125]   c229_1    -182
    x[1125]   c344      -1
    x[1125]   c347      1
    x[1126]   c186_1    -62
    x[1126]   c231_1    -182
    x[1126]   c344      -1
    x[1126]   c348      1
    x[1127]   c187_1    -62
    x[1127]   c232_1    -182
    x[1127]   c344      -1
    x[1127]   c349      1
    x[1128]   c188_1    -62
    x[1128]   c233_1    -182
    x[1128]   c344      -1
    x[1128]   c350      1
    x[1129]   c189_1    -62
    x[1129]   c234_1    -182
    x[1129]   c344      -1
    x[1129]   c351      1
    x[1130]   c198_1    -182
    x[1130]   c243_1    -62
    x[1130]   c345      1
    x[1130]   c346      -1
    x[1131]   c199_1    -182
    x[1131]   c244_1    -62
    x[1131]   c345      1
    x[1131]   c347      -1
    x[1132]   c201_1    -182
    x[1132]   c246_1    -62
    x[1132]   c345      1
    x[1132]   c348      -1
    x[1133]   c202_1    -182
    x[1133]   c247_1    -62
    x[1133]   c345      1
    x[1133]   c349      -1
    x[1134]   c203_1    -182
    x[1134]   c248_1    -62
    x[1134]   c345      1
    x[1134]   c350      -1
    x[1135]   c204_1    -182
    x[1135]   c249_1    -62
    x[1135]   c345      1
    x[1135]   c351      -1
    x[1136]   c198_1    -62
    x[1136]   c243_1    -182
    x[1136]   c345      -1
    x[1136]   c346      1
    x[1137]   c199_1    -62
    x[1137]   c244_1    -182
    x[1137]   c345      -1
    x[1137]   c347      1
    x[1138]   c201_1    -62
    x[1138]   c246_1    -182
    x[1138]   c345      -1
    x[1138]   c348      1
    x[1139]   c202_1    -62
    x[1139]   c247_1    -182
    x[1139]   c345      -1
    x[1139]   c349      1
    x[1140]   c203_1    -62
    x[1140]   c248_1    -182
    x[1140]   c345      -1
    x[1140]   c350      1
    x[1141]   c204_1    -62
    x[1141]   c249_1    -182
    x[1141]   c345      -1
    x[1141]   c351      1
    x[1142]   c205_1    -182
    x[1142]   c250_1    -62
    x[1142]   c346      1
    x[1142]   c347      -1
    x[1143]   c207_1    -182
    x[1143]   c252_1    -62
    x[1143]   c346      1
    x[1143]   c348      -1
    x[1144]   c208_1    -182
    x[1144]   c253_1    -62
    x[1144]   c346      1
    x[1144]   c349      -1
    x[1145]   c209_1    -182
    x[1145]   c254_1    -62
    x[1145]   c346      1
    x[1145]   c350      -1
    x[1146]   c210_1    -182
    x[1146]   c255_1    -62
    x[1146]   c346      1
    x[1146]   c351      -1
    x[1147]   c205_1    -62
    x[1147]   c250_1    -182
    x[1147]   c346      -1
    x[1147]   c347      1
    x[1148]   c207_1    -62
    x[1148]   c252_1    -182
    x[1148]   c346      -1
    x[1148]   c348      1
    x[1149]   c208_1    -62
    x[1149]   c253_1    -182
    x[1149]   c346      -1
    x[1149]   c349      1
    x[1150]   c209_1    -62
    x[1150]   c254_1    -182
    x[1150]   c346      -1
    x[1150]   c350      1
    x[1151]   c210_1    -62
    x[1151]   c255_1    -182
    x[1151]   c346      -1
    x[1151]   c351      1
    x[1152]   c212_1    -182
    x[1152]   c257_1    -62
    x[1152]   c347      1
    x[1152]   c348      -1
    x[1153]   c213_1    -182
    x[1153]   c258_1    -62
    x[1153]   c347      1
    x[1153]   c349      -1
    x[1154]   c214_1    -182
    x[1154]   c259_1    -62
    x[1154]   c347      1
    x[1154]   c350      -1
    x[1155]   c215_1    -182
    x[1155]   c260_1    -62
    x[1155]   c347      1
    x[1155]   c351      -1
    x[1156]   c212_1    -62
    x[1156]   c257_1    -182
    x[1156]   c347      -1
    x[1156]   c348      1
    x[1157]   c213_1    -62
    x[1157]   c258_1    -182
    x[1157]   c347      -1
    x[1157]   c349      1
    x[1158]   c214_1    -62
    x[1158]   c259_1    -182
    x[1158]   c347      -1
    x[1158]   c350      1
    x[1159]   c215_1    -62
    x[1159]   c260_1    -182
    x[1159]   c347      -1
    x[1159]   c351      1
    x[1160]   c220_1    -182
    x[1160]   c265_1    -62
    x[1160]   c348      1
    x[1160]   c349      -1
    x[1161]   c221_1    -182
    x[1161]   c266_1    -62
    x[1161]   c348      1
    x[1161]   c350      -1
    x[1162]   c222_1    -182
    x[1162]   c267_1    -62
    x[1162]   c348      1
    x[1162]   c351      -1
    x[1163]   c220_1    -62
    x[1163]   c265_1    -182
    x[1163]   c348      -1
    x[1163]   c349      1
    x[1164]   c221_1    -62
    x[1164]   c266_1    -182
    x[1164]   c348      -1
    x[1164]   c350      1
    x[1165]   c222_1    -62
    x[1165]   c267_1    -182
    x[1165]   c348      -1
    x[1165]   c351      1
    x[1166]   c223_1    -182
    x[1166]   c268_1    -62
    x[1166]   c349      1
    x[1166]   c350      -1
    x[1167]   c224_1    -182
    x[1167]   c269_1    -62
    x[1167]   c349      1
    x[1167]   c351      -1
    x[1168]   c223_1    -62
    x[1168]   c268_1    -182
    x[1168]   c349      -1
    x[1168]   c350      1
    x[1169]   c224_1    -62
    x[1169]   c269_1    -182
    x[1169]   c349      -1
    x[1169]   c351      1
    x[1170]   c225_1    -182
    x[1170]   c270_1    -62
    x[1170]   c350      1
    x[1170]   c351      -1
    x[1171]   c225_1    -62
    x[1171]   c270_1    -182
    x[1171]   c350      -1
    x[1171]   c351      1
    x[1172]   c181_1    -41
    x[1172]   c226_1    -144
    x[1172]   c352      1
    x[1173]   c220_1    -41
    x[1173]   c265_1    -144
    x[1173]   c353      1
    x[1174]   c221_1    -41
    x[1174]   c266_1    -144
    x[1174]   c354      1
    x[1175]   c222_1    -41
    x[1175]   c267_1    -144
    x[1175]   c355      1
    x[1176]   c186_1    -144
    x[1176]   c231_1    -41
    x[1176]   c356      1
    x[1177]   c190_1    -144
    x[1177]   c235_1    -41
    x[1177]   c357      1
    x[1178]   c191_1    -144
    x[1178]   c236_1    -41
    x[1178]   c358      1
    x[1179]   c192_1    -144
    x[1179]   c237_1    -41
    x[1179]   c359      1
    x[1180]   c193_1    -144
    x[1180]   c238_1    -41
    x[1180]   c360      1
    x[1181]   c194_1    -144
    x[1181]   c239_1    -41
    x[1181]   c361      1
    x[1182]   c195_1    -144
    x[1182]   c240_1    -41
    x[1182]   c362      1
    x[1183]   c196_1    -144
    x[1183]   c241_1    -41
    x[1183]   c363      1
    x[1184]   c197_1    -144
    x[1184]   c242_1    -41
    x[1184]   c364      1
    x[1185]   c201_1    -144
    x[1185]   c246_1    -41
    x[1185]   c365      1
    x[1186]   c207_1    -144
    x[1186]   c252_1    -41
    x[1186]   c366      1
    x[1187]   c212_1    -144
    x[1187]   c257_1    -41
    x[1187]   c367      1
    x[1188]   c216_1    -144
    x[1188]   c261_1    -41
    x[1188]   c368      1
    x[1189]   c64_2     1
    x[1189]   c72_2     1
    x[1189]   c190_1    -41
    x[1189]   c235_1    -144
    x[1189]   c369      1
    x[1189]   c372      1
    x[1190]   c65_2     1
    x[1190]   c191_1    -41
    x[1190]   c236_1    -144
    x[1190]   c369      1
    x[1190]   c373      1
    x[1191]   c192_1    -41
    x[1191]   c237_1    -144
    x[1191]   c369      1
    x[1191]   c374      1
    x[1192]   c66_2     1
    x[1192]   c193_1    -41
    x[1192]   c238_1    -144
    x[1192]   c369      1
    x[1192]   c375      1
    x[1193]   c64_2     1
    x[1193]   c65_2     1
    x[1193]   c66_2     1
    x[1193]   c67_2     1
    x[1193]   c194_1    -41
    x[1193]   c239_1    -144
    x[1193]   c369      1
    x[1193]   c370      1
    x[1194]   c72_2     1
    x[1194]   c195_1    -41
    x[1194]   c240_1    -144
    x[1194]   c369      1
    x[1194]   c376      1
    x[1195]   c196_1    -41
    x[1195]   c241_1    -144
    x[1195]   c369      1
    x[1195]   c377      1
    x[1196]   c67_2     1
    x[1196]   c197_1    -41
    x[1196]   c242_1    -144
    x[1196]   c369      1
    x[1196]   c378      1
    x[1197]   c181_1    -144
    x[1197]   c226_1    -41
    x[1197]   c369      1
    x[1197]   c371      1
    x[1198]   c117_2    1
    x[1198]   c118_2    1
    x[1198]   c186_1    -41
    x[1198]   c231_1    -144
    x[1198]   c370      1
    x[1198]   c371      -1
    x[1199]   c119_2    1
    x[1199]   c201_1    -41
    x[1199]   c246_1    -144
    x[1199]   c370      1
    x[1199]   c372      -1
    x[1200]   c119_2    1
    x[1200]   c207_1    -41
    x[1200]   c252_1    -144
    x[1200]   c370      1
    x[1200]   c373      -1
    x[1201]   c212_1    -41
    x[1201]   c257_1    -144
    x[1201]   c370      1
    x[1201]   c374      -1
    x[1202]   c117_2    1
    x[1202]   c216_1    -41
    x[1202]   c261_1    -144
    x[1202]   c370      1
    x[1202]   c375      -1
    x[1203]   c220_1    -144
    x[1203]   c265_1    -41
    x[1203]   c370      1
    x[1203]   c376      -1
    x[1204]   c118_2    1
    x[1204]   c221_1    -144
    x[1204]   c266_1    -41
    x[1204]   c370      1
    x[1204]   c377      -1
    x[1205]   c222_1    -144
    x[1205]   c267_1    -41
    x[1205]   c370      1
    x[1205]   c378      -1
    x[1206]   c182_1    -144
    x[1206]   c227_1    -41
    x[1206]   c371      1
    x[1206]   c372      -1
    x[1207]   c183_1    -144
    x[1207]   c228_1    -41
    x[1207]   c371      1
    x[1207]   c373      -1
    x[1208]   c184_1    -144
    x[1208]   c229_1    -41
    x[1208]   c371      1
    x[1208]   c374      -1
    x[1209]   c185_1    -144
    x[1209]   c230_1    -41
    x[1209]   c371      1
    x[1209]   c375      -1
    x[1210]   c187_1    -144
    x[1210]   c232_1    -41
    x[1210]   c371      1
    x[1210]   c376      -1
    x[1211]   c188_1    -144
    x[1211]   c233_1    -41
    x[1211]   c371      1
    x[1211]   c377      -1
    x[1212]   c189_1    -144
    x[1212]   c234_1    -41
    x[1212]   c371      1
    x[1212]   c378      -1
    x[1213]   c182_1    -41
    x[1213]   c227_1    -144
    x[1213]   c371      -1
    x[1213]   c372      1
    x[1214]   c183_1    -41
    x[1214]   c228_1    -144
    x[1214]   c371      -1
    x[1214]   c373      1
    x[1215]   c184_1    -41
    x[1215]   c229_1    -144
    x[1215]   c371      -1
    x[1215]   c374      1
    x[1216]   c185_1    -41
    x[1216]   c230_1    -144
    x[1216]   c371      -1
    x[1216]   c375      1
    x[1217]   c187_1    -41
    x[1217]   c232_1    -144
    x[1217]   c371      -1
    x[1217]   c376      1
    x[1218]   c188_1    -41
    x[1218]   c233_1    -144
    x[1218]   c371      -1
    x[1218]   c377      1
    x[1219]   c189_1    -41
    x[1219]   c234_1    -144
    x[1219]   c371      -1
    x[1219]   c378      1
    x[1220]   c198_1    -144
    x[1220]   c243_1    -41
    x[1220]   c372      1
    x[1220]   c373      -1
    x[1221]   c199_1    -144
    x[1221]   c244_1    -41
    x[1221]   c372      1
    x[1221]   c374      -1
    x[1222]   c200_1    -144
    x[1222]   c245_1    -41
    x[1222]   c372      1
    x[1222]   c375      -1
    x[1223]   c202_1    -144
    x[1223]   c247_1    -41
    x[1223]   c372      1
    x[1223]   c376      -1
    x[1224]   c203_1    -144
    x[1224]   c248_1    -41
    x[1224]   c372      1
    x[1224]   c377      -1
    x[1225]   c204_1    -144
    x[1225]   c249_1    -41
    x[1225]   c372      1
    x[1225]   c378      -1
    x[1226]   c198_1    -41
    x[1226]   c243_1    -144
    x[1226]   c372      -1
    x[1226]   c373      1
    x[1227]   c199_1    -41
    x[1227]   c244_1    -144
    x[1227]   c372      -1
    x[1227]   c374      1
    x[1228]   c200_1    -41
    x[1228]   c245_1    -144
    x[1228]   c372      -1
    x[1228]   c375      1
    x[1229]   c202_1    -41
    x[1229]   c247_1    -144
    x[1229]   c372      -1
    x[1229]   c376      1
    x[1230]   c203_1    -41
    x[1230]   c248_1    -144
    x[1230]   c372      -1
    x[1230]   c377      1
    x[1231]   c204_1    -41
    x[1231]   c249_1    -144
    x[1231]   c372      -1
    x[1231]   c378      1
    x[1232]   c205_1    -144
    x[1232]   c250_1    -41
    x[1232]   c373      1
    x[1232]   c374      -1
    x[1233]   c206_1    -144
    x[1233]   c251_1    -41
    x[1233]   c373      1
    x[1233]   c375      -1
    x[1234]   c208_1    -144
    x[1234]   c253_1    -41
    x[1234]   c373      1
    x[1234]   c376      -1
    x[1235]   c209_1    -144
    x[1235]   c254_1    -41
    x[1235]   c373      1
    x[1235]   c377      -1
    x[1236]   c210_1    -144
    x[1236]   c255_1    -41
    x[1236]   c373      1
    x[1236]   c378      -1
    x[1237]   c205_1    -41
    x[1237]   c250_1    -144
    x[1237]   c373      -1
    x[1237]   c374      1
    x[1238]   c206_1    -41
    x[1238]   c251_1    -144
    x[1238]   c373      -1
    x[1238]   c375      1
    x[1239]   c208_1    -41
    x[1239]   c253_1    -144
    x[1239]   c373      -1
    x[1239]   c376      1
    x[1240]   c209_1    -41
    x[1240]   c254_1    -144
    x[1240]   c373      -1
    x[1240]   c377      1
    x[1241]   c210_1    -41
    x[1241]   c255_1    -144
    x[1241]   c373      -1
    x[1241]   c378      1
    x[1242]   c211_1    -144
    x[1242]   c256_1    -41
    x[1242]   c374      1
    x[1242]   c375      -1
    x[1243]   c213_1    -144
    x[1243]   c258_1    -41
    x[1243]   c374      1
    x[1243]   c376      -1
    x[1244]   c214_1    -144
    x[1244]   c259_1    -41
    x[1244]   c374      1
    x[1244]   c377      -1
    x[1245]   c215_1    -144
    x[1245]   c260_1    -41
    x[1245]   c374      1
    x[1245]   c378      -1
    x[1246]   c211_1    -41
    x[1246]   c256_1    -144
    x[1246]   c374      -1
    x[1246]   c375      1
    x[1247]   c213_1    -41
    x[1247]   c258_1    -144
    x[1247]   c374      -1
    x[1247]   c376      1
    x[1248]   c214_1    -41
    x[1248]   c259_1    -144
    x[1248]   c374      -1
    x[1248]   c377      1
    x[1249]   c215_1    -41
    x[1249]   c260_1    -144
    x[1249]   c374      -1
    x[1249]   c378      1
    x[1250]   c217_1    -144
    x[1250]   c262_1    -41
    x[1250]   c375      1
    x[1250]   c376      -1
    x[1251]   c218_1    -144
    x[1251]   c263_1    -41
    x[1251]   c375      1
    x[1251]   c377      -1
    x[1252]   c219_1    -144
    x[1252]   c264_1    -41
    x[1252]   c375      1
    x[1252]   c378      -1
    x[1253]   c217_1    -41
    x[1253]   c262_1    -144
    x[1253]   c375      -1
    x[1253]   c376      1
    x[1254]   c218_1    -41
    x[1254]   c263_1    -144
    x[1254]   c375      -1
    x[1254]   c377      1
    x[1255]   c219_1    -41
    x[1255]   c264_1    -144
    x[1255]   c375      -1
    x[1255]   c378      1
    x[1256]   c223_1    -144
    x[1256]   c268_1    -41
    x[1256]   c376      1
    x[1256]   c377      -1
    x[1257]   c224_1    -144
    x[1257]   c269_1    -41
    x[1257]   c376      1
    x[1257]   c378      -1
    x[1258]   c223_1    -41
    x[1258]   c268_1    -144
    x[1258]   c376      -1
    x[1258]   c377      1
    x[1259]   c224_1    -41
    x[1259]   c269_1    -144
    x[1259]   c376      -1
    x[1259]   c378      1
    x[1260]   c225_1    -144
    x[1260]   c270_1    -41
    x[1260]   c377      1
    x[1260]   c378      -1
    x[1261]   c225_1    -41
    x[1261]   c270_1    -144
    x[1261]   c377      -1
    x[1261]   c378      1
    x[1262]   c181_1    -47
    x[1262]   c226_1    -178
    x[1262]   c379      1
    x[1263]   c223_1    -47
    x[1263]   c268_1    -178
    x[1263]   c380      1
    x[1264]   c224_1    -47
    x[1264]   c269_1    -178
    x[1264]   c381      1
    x[1265]   c187_1    -178
    x[1265]   c232_1    -47
    x[1265]   c382      1
    x[1266]   c190_1    -178
    x[1266]   c235_1    -47
    x[1266]   c383      1
    x[1267]   c191_1    -178
    x[1267]   c236_1    -47
    x[1267]   c384      1
    x[1268]   c192_1    -178
    x[1268]   c237_1    -47
    x[1268]   c385      1
    x[1269]   c193_1    -178
    x[1269]   c238_1    -47
    x[1269]   c386      1
    x[1270]   c194_1    -178
    x[1270]   c239_1    -47
    x[1270]   c387      1
    x[1271]   c195_1    -178
    x[1271]   c240_1    -47
    x[1271]   c388      1
    x[1272]   c196_1    -178
    x[1272]   c241_1    -47
    x[1272]   c389      1
    x[1273]   c197_1    -178
    x[1273]   c242_1    -47
    x[1273]   c390      1
    x[1274]   c202_1    -178
    x[1274]   c247_1    -47
    x[1274]   c391      1
    x[1275]   c208_1    -178
    x[1275]   c253_1    -47
    x[1275]   c392      1
    x[1276]   c213_1    -178
    x[1276]   c258_1    -47
    x[1276]   c393      1
    x[1277]   c217_1    -178
    x[1277]   c262_1    -47
    x[1277]   c394      1
    x[1278]   c220_1    -178
    x[1278]   c265_1    -47
    x[1278]   c395      1
    x[1279]   c152_2    1
    x[1279]   c160_2    1
    x[1279]   c190_1    -47
    x[1279]   c235_1    -178
    x[1279]   c396      1
    x[1279]   c399      1
    x[1280]   c153_2    1
    x[1280]   c191_1    -47
    x[1280]   c236_1    -178
    x[1280]   c396      1
    x[1280]   c400      1
    x[1281]   c192_1    -47
    x[1281]   c237_1    -178
    x[1281]   c396      1
    x[1281]   c401      1
    x[1282]   c193_1    -47
    x[1282]   c238_1    -178
    x[1282]   c396      1
    x[1282]   c402      1
    x[1283]   c154_2    1
    x[1283]   c194_1    -47
    x[1283]   c239_1    -178
    x[1283]   c396      1
    x[1283]   c403      1
    x[1284]   c152_2    1
    x[1284]   c153_2    1
    x[1284]   c154_2    1
    x[1284]   c155_2    1
    x[1284]   c195_1    -47
    x[1284]   c240_1    -178
    x[1284]   c396      1
    x[1284]   c397      1
    x[1285]   c160_2    1
    x[1285]   c196_1    -47
    x[1285]   c241_1    -178
    x[1285]   c396      1
    x[1285]   c404      1
    x[1286]   c155_2    1
    x[1286]   c197_1    -47
    x[1286]   c242_1    -178
    x[1286]   c396      1
    x[1286]   c405      1
    x[1287]   c181_1    -178
    x[1287]   c226_1    -47
    x[1287]   c396      1
    x[1287]   c398      1
    x[1288]   c201_2    1
    x[1288]   c202_2    1
    x[1288]   c187_1    -47
    x[1288]   c232_1    -178
    x[1288]   c397      1
    x[1288]   c398      -1
    x[1289]   c203_2    1
    x[1289]   c202_1    -47
    x[1289]   c247_1    -178
    x[1289]   c397      1
    x[1289]   c399      -1
    x[1290]   c201_2    1
    x[1290]   c203_2    1
    x[1290]   c208_1    -47
    x[1290]   c253_1    -178
    x[1290]   c397      1
    x[1290]   c400      -1
    x[1291]   c213_1    -47
    x[1291]   c258_1    -178
    x[1291]   c397      1
    x[1291]   c401      -1
    x[1292]   c217_1    -47
    x[1292]   c262_1    -178
    x[1292]   c397      1
    x[1292]   c402      -1
    x[1293]   c220_1    -47
    x[1293]   c265_1    -178
    x[1293]   c397      1
    x[1293]   c403      -1
    x[1294]   c202_2    1
    x[1294]   c223_1    -178
    x[1294]   c268_1    -47
    x[1294]   c397      1
    x[1294]   c404      -1
    x[1295]   c224_1    -178
    x[1295]   c269_1    -47
    x[1295]   c397      1
    x[1295]   c405      -1
    x[1296]   c182_1    -178
    x[1296]   c227_1    -47
    x[1296]   c398      1
    x[1296]   c399      -1
    x[1297]   c183_1    -178
    x[1297]   c228_1    -47
    x[1297]   c398      1
    x[1297]   c400      -1
    x[1298]   c184_1    -178
    x[1298]   c229_1    -47
    x[1298]   c398      1
    x[1298]   c401      -1
    x[1299]   c185_1    -178
    x[1299]   c230_1    -47
    x[1299]   c398      1
    x[1299]   c402      -1
    x[1300]   c186_1    -178
    x[1300]   c231_1    -47
    x[1300]   c398      1
    x[1300]   c403      -1
    x[1301]   c188_1    -178
    x[1301]   c233_1    -47
    x[1301]   c398      1
    x[1301]   c404      -1
    x[1302]   c189_1    -178
    x[1302]   c234_1    -47
    x[1302]   c398      1
    x[1302]   c405      -1
    x[1303]   c182_1    -47
    x[1303]   c227_1    -178
    x[1303]   c398      -1
    x[1303]   c399      1
    x[1304]   c183_1    -47
    x[1304]   c228_1    -178
    x[1304]   c398      -1
    x[1304]   c400      1
    x[1305]   c184_1    -47
    x[1305]   c229_1    -178
    x[1305]   c398      -1
    x[1305]   c401      1
    x[1306]   c185_1    -47
    x[1306]   c230_1    -178
    x[1306]   c398      -1
    x[1306]   c402      1
    x[1307]   c186_1    -47
    x[1307]   c231_1    -178
    x[1307]   c398      -1
    x[1307]   c403      1
    x[1308]   c188_1    -47
    x[1308]   c233_1    -178
    x[1308]   c398      -1
    x[1308]   c404      1
    x[1309]   c189_1    -47
    x[1309]   c234_1    -178
    x[1309]   c398      -1
    x[1309]   c405      1
    x[1310]   c198_1    -178
    x[1310]   c243_1    -47
    x[1310]   c399      1
    x[1310]   c400      -1
    x[1311]   c199_1    -178
    x[1311]   c244_1    -47
    x[1311]   c399      1
    x[1311]   c401      -1
    x[1312]   c200_1    -178
    x[1312]   c245_1    -47
    x[1312]   c399      1
    x[1312]   c402      -1
    x[1313]   c201_1    -178
    x[1313]   c246_1    -47
    x[1313]   c399      1
    x[1313]   c403      -1
    x[1314]   c203_1    -178
    x[1314]   c248_1    -47
    x[1314]   c399      1
    x[1314]   c404      -1
    x[1315]   c204_1    -178
    x[1315]   c249_1    -47
    x[1315]   c399      1
    x[1315]   c405      -1
    x[1316]   c198_1    -47
    x[1316]   c243_1    -178
    x[1316]   c399      -1
    x[1316]   c400      1
    x[1317]   c199_1    -47
    x[1317]   c244_1    -178
    x[1317]   c399      -1
    x[1317]   c401      1
    x[1318]   c200_1    -47
    x[1318]   c245_1    -178
    x[1318]   c399      -1
    x[1318]   c402      1
    x[1319]   c201_1    -47
    x[1319]   c246_1    -178
    x[1319]   c399      -1
    x[1319]   c403      1
    x[1320]   c203_1    -47
    x[1320]   c248_1    -178
    x[1320]   c399      -1
    x[1320]   c404      1
    x[1321]   c204_1    -47
    x[1321]   c249_1    -178
    x[1321]   c399      -1
    x[1321]   c405      1
    x[1322]   c205_1    -178
    x[1322]   c250_1    -47
    x[1322]   c400      1
    x[1322]   c401      -1
    x[1323]   c206_1    -178
    x[1323]   c251_1    -47
    x[1323]   c400      1
    x[1323]   c402      -1
    x[1324]   c207_1    -178
    x[1324]   c252_1    -47
    x[1324]   c400      1
    x[1324]   c403      -1
    x[1325]   c209_1    -178
    x[1325]   c254_1    -47
    x[1325]   c400      1
    x[1325]   c404      -1
    x[1326]   c210_1    -178
    x[1326]   c255_1    -47
    x[1326]   c400      1
    x[1326]   c405      -1
    x[1327]   c205_1    -47
    x[1327]   c250_1    -178
    x[1327]   c400      -1
    x[1327]   c401      1
    x[1328]   c206_1    -47
    x[1328]   c251_1    -178
    x[1328]   c400      -1
    x[1328]   c402      1
    x[1329]   c207_1    -47
    x[1329]   c252_1    -178
    x[1329]   c400      -1
    x[1329]   c403      1
    x[1330]   c209_1    -47
    x[1330]   c254_1    -178
    x[1330]   c400      -1
    x[1330]   c404      1
    x[1331]   c210_1    -47
    x[1331]   c255_1    -178
    x[1331]   c400      -1
    x[1331]   c405      1
    x[1332]   c211_1    -178
    x[1332]   c256_1    -47
    x[1332]   c401      1
    x[1332]   c402      -1
    x[1333]   c212_1    -178
    x[1333]   c257_1    -47
    x[1333]   c401      1
    x[1333]   c403      -1
    x[1334]   c214_1    -178
    x[1334]   c259_1    -47
    x[1334]   c401      1
    x[1334]   c404      -1
    x[1335]   c215_1    -178
    x[1335]   c260_1    -47
    x[1335]   c401      1
    x[1335]   c405      -1
    x[1336]   c211_1    -47
    x[1336]   c256_1    -178
    x[1336]   c401      -1
    x[1336]   c402      1
    x[1337]   c212_1    -47
    x[1337]   c257_1    -178
    x[1337]   c401      -1
    x[1337]   c403      1
    x[1338]   c214_1    -47
    x[1338]   c259_1    -178
    x[1338]   c401      -1
    x[1338]   c404      1
    x[1339]   c215_1    -47
    x[1339]   c260_1    -178
    x[1339]   c401      -1
    x[1339]   c405      1
    x[1340]   c216_1    -178
    x[1340]   c261_1    -47
    x[1340]   c402      1
    x[1340]   c403      -1
    x[1341]   c218_1    -178
    x[1341]   c263_1    -47
    x[1341]   c402      1
    x[1341]   c404      -1
    x[1342]   c219_1    -178
    x[1342]   c264_1    -47
    x[1342]   c402      1
    x[1342]   c405      -1
    x[1343]   c216_1    -47
    x[1343]   c261_1    -178
    x[1343]   c402      -1
    x[1343]   c403      1
    x[1344]   c218_1    -47
    x[1344]   c263_1    -178
    x[1344]   c402      -1
    x[1344]   c404      1
    x[1345]   c219_1    -47
    x[1345]   c264_1    -178
    x[1345]   c402      -1
    x[1345]   c405      1
    x[1346]   c221_1    -178
    x[1346]   c266_1    -47
    x[1346]   c403      1
    x[1346]   c404      -1
    x[1347]   c222_1    -178
    x[1347]   c267_1    -47
    x[1347]   c403      1
    x[1347]   c405      -1
    x[1348]   c221_1    -47
    x[1348]   c266_1    -178
    x[1348]   c403      -1
    x[1348]   c404      1
    x[1349]   c222_1    -47
    x[1349]   c267_1    -178
    x[1349]   c403      -1
    x[1349]   c405      1
    x[1350]   c225_1    -178
    x[1350]   c270_1    -47
    x[1350]   c404      1
    x[1350]   c405      -1
    x[1351]   c225_1    -47
    x[1351]   c270_1    -178
    x[1351]   c404      -1
    x[1351]   c405      1
    x[1352]   c181_1    -90
    x[1352]   c226_1    -45
    x[1352]   c406      1
    x[1353]   c225_1    -90
    x[1353]   c270_1    -45
    x[1353]   c407      1
    x[1354]   c188_1    -45
    x[1354]   c233_1    -90
    x[1354]   c408      1
    x[1355]   c190_1    -45
    x[1355]   c235_1    -90
    x[1355]   c409      1
    x[1356]   c191_1    -45
    x[1356]   c236_1    -90
    x[1356]   c410      1
    x[1357]   c192_1    -45
    x[1357]   c237_1    -90
    x[1357]   c411      1
    x[1358]   c193_1    -45
    x[1358]   c238_1    -90
    x[1358]   c412      1
    x[1359]   c194_1    -45
    x[1359]   c239_1    -90
    x[1359]   c413      1
    x[1360]   c195_1    -45
    x[1360]   c240_1    -90
    x[1360]   c414      1
    x[1361]   c196_1    -45
    x[1361]   c241_1    -90
    x[1361]   c415      1
    x[1362]   c197_1    -45
    x[1362]   c242_1    -90
    x[1362]   c416      1
    x[1363]   c203_1    -45
    x[1363]   c248_1    -90
    x[1363]   c417      1
    x[1364]   c209_1    -45
    x[1364]   c254_1    -90
    x[1364]   c418      1
    x[1365]   c214_1    -45
    x[1365]   c259_1    -90
    x[1365]   c419      1
    x[1366]   c218_1    -45
    x[1366]   c263_1    -90
    x[1366]   c420      1
    x[1367]   c221_1    -45
    x[1367]   c266_1    -90
    x[1367]   c421      1
    x[1368]   c223_1    -45
    x[1368]   c268_1    -90
    x[1368]   c422      1
    x[1369]   c248_2    1
    x[1369]   c261_2    1
    x[1369]   c190_1    -90
    x[1369]   c235_1    -45
    x[1369]   c423      1
    x[1369]   c426      1
    x[1370]   c191_1    -90
    x[1370]   c236_1    -45
    x[1370]   c423      1
    x[1370]   c427      1
    x[1371]   c192_1    -90
    x[1371]   c237_1    -45
    x[1371]   c423      1
    x[1371]   c428      1
    x[1372]   c249_2    1
    x[1372]   c193_1    -90
    x[1372]   c238_1    -45
    x[1372]   c423      1
    x[1372]   c429      1
    x[1373]   c250_2    1
    x[1373]   c194_1    -90
    x[1373]   c239_1    -45
    x[1373]   c423      1
    x[1373]   c430      1
    x[1374]   c195_1    -90
    x[1374]   c240_1    -45
    x[1374]   c423      1
    x[1374]   c431      1
    x[1375]   c248_2    1
    x[1375]   c249_2    1
    x[1375]   c250_2    1
    x[1375]   c196_1    -90
    x[1375]   c241_1    -45
    x[1375]   c423      1
    x[1375]   c424      1
    x[1376]   c261_2    1
    x[1376]   c197_1    -90
    x[1376]   c242_1    -45
    x[1376]   c423      1
    x[1376]   c432      1
    x[1377]   c181_1    -45
    x[1377]   c226_1    -90
    x[1377]   c423      1
    x[1377]   c425      1
    x[1378]   c300_1    1
    x[1378]   c188_1    -90
    x[1378]   c233_1    -45
    x[1378]   c424      1
    x[1378]   c425      -1
    x[1379]   c203_1    -90
    x[1379]   c248_1    -45
    x[1379]   c424      1
    x[1379]   c426      -1
    x[1380]   c209_1    -90
    x[1380]   c254_1    -45
    x[1380]   c424      1
    x[1380]   c427      -1
    x[1381]   c214_1    -90
    x[1381]   c259_1    -45
    x[1381]   c424      1
    x[1381]   c428      -1
    x[1382]   c218_1    -90
    x[1382]   c263_1    -45
    x[1382]   c424      1
    x[1382]   c429      -1
    x[1383]   c300_1    1
    x[1383]   c221_1    -90
    x[1383]   c266_1    -45
    x[1383]   c424      1
    x[1383]   c430      -1
    x[1384]   c223_1    -90
    x[1384]   c268_1    -45
    x[1384]   c424      1
    x[1384]   c431      -1
    x[1385]   c225_1    -45
    x[1385]   c270_1    -90
    x[1385]   c424      1
    x[1385]   c432      -1
    x[1386]   c182_1    -45
    x[1386]   c227_1    -90
    x[1386]   c425      1
    x[1386]   c426      -1
    x[1387]   c183_1    -45
    x[1387]   c228_1    -90
    x[1387]   c425      1
    x[1387]   c427      -1
    x[1388]   c184_1    -45
    x[1388]   c229_1    -90
    x[1388]   c425      1
    x[1388]   c428      -1
    x[1389]   c185_1    -45
    x[1389]   c230_1    -90
    x[1389]   c425      1
    x[1389]   c429      -1
    x[1390]   c186_1    -45
    x[1390]   c231_1    -90
    x[1390]   c425      1
    x[1390]   c430      -1
    x[1391]   c187_1    -45
    x[1391]   c232_1    -90
    x[1391]   c425      1
    x[1391]   c431      -1
    x[1392]   c189_1    -45
    x[1392]   c234_1    -90
    x[1392]   c425      1
    x[1392]   c432      -1
    x[1393]   c182_1    -90
    x[1393]   c227_1    -45
    x[1393]   c425      -1
    x[1393]   c426      1
    x[1394]   c183_1    -90
    x[1394]   c228_1    -45
    x[1394]   c425      -1
    x[1394]   c427      1
    x[1395]   c184_1    -90
    x[1395]   c229_1    -45
    x[1395]   c425      -1
    x[1395]   c428      1
    x[1396]   c185_1    -90
    x[1396]   c230_1    -45
    x[1396]   c425      -1
    x[1396]   c429      1
    x[1397]   c186_1    -90
    x[1397]   c231_1    -45
    x[1397]   c425      -1
    x[1397]   c430      1
    x[1398]   c187_1    -90
    x[1398]   c232_1    -45
    x[1398]   c425      -1
    x[1398]   c431      1
    x[1399]   c189_1    -90
    x[1399]   c234_1    -45
    x[1399]   c425      -1
    x[1399]   c432      1
    x[1400]   c198_1    -45
    x[1400]   c243_1    -90
    x[1400]   c426      1
    x[1400]   c427      -1
    x[1401]   c199_1    -45
    x[1401]   c244_1    -90
    x[1401]   c426      1
    x[1401]   c428      -1
    x[1402]   c200_1    -45
    x[1402]   c245_1    -90
    x[1402]   c426      1
    x[1402]   c429      -1
    x[1403]   c201_1    -45
    x[1403]   c246_1    -90
    x[1403]   c426      1
    x[1403]   c430      -1
    x[1404]   c202_1    -45
    x[1404]   c247_1    -90
    x[1404]   c426      1
    x[1404]   c431      -1
    x[1405]   c204_1    -45
    x[1405]   c249_1    -90
    x[1405]   c426      1
    x[1405]   c432      -1
    x[1406]   c198_1    -90
    x[1406]   c243_1    -45
    x[1406]   c426      -1
    x[1406]   c427      1
    x[1407]   c199_1    -90
    x[1407]   c244_1    -45
    x[1407]   c426      -1
    x[1407]   c428      1
    x[1408]   c200_1    -90
    x[1408]   c245_1    -45
    x[1408]   c426      -1
    x[1408]   c429      1
    x[1409]   c201_1    -90
    x[1409]   c246_1    -45
    x[1409]   c426      -1
    x[1409]   c430      1
    x[1410]   c202_1    -90
    x[1410]   c247_1    -45
    x[1410]   c426      -1
    x[1410]   c431      1
    x[1411]   c204_1    -90
    x[1411]   c249_1    -45
    x[1411]   c426      -1
    x[1411]   c432      1
    x[1412]   c205_1    -45
    x[1412]   c250_1    -90
    x[1412]   c427      1
    x[1412]   c428      -1
    x[1413]   c206_1    -45
    x[1413]   c251_1    -90
    x[1413]   c427      1
    x[1413]   c429      -1
    x[1414]   c207_1    -45
    x[1414]   c252_1    -90
    x[1414]   c427      1
    x[1414]   c430      -1
    x[1415]   c208_1    -45
    x[1415]   c253_1    -90
    x[1415]   c427      1
    x[1415]   c431      -1
    x[1416]   c210_1    -45
    x[1416]   c255_1    -90
    x[1416]   c427      1
    x[1416]   c432      -1
    x[1417]   c205_1    -90
    x[1417]   c250_1    -45
    x[1417]   c427      -1
    x[1417]   c428      1
    x[1418]   c206_1    -90
    x[1418]   c251_1    -45
    x[1418]   c427      -1
    x[1418]   c429      1
    x[1419]   c207_1    -90
    x[1419]   c252_1    -45
    x[1419]   c427      -1
    x[1419]   c430      1
    x[1420]   c208_1    -90
    x[1420]   c253_1    -45
    x[1420]   c427      -1
    x[1420]   c431      1
    x[1421]   c210_1    -90
    x[1421]   c255_1    -45
    x[1421]   c427      -1
    x[1421]   c432      1
    x[1422]   c211_1    -45
    x[1422]   c256_1    -90
    x[1422]   c428      1
    x[1422]   c429      -1
    x[1423]   c212_1    -45
    x[1423]   c257_1    -90
    x[1423]   c428      1
    x[1423]   c430      -1
    x[1424]   c213_1    -45
    x[1424]   c258_1    -90
    x[1424]   c428      1
    x[1424]   c431      -1
    x[1425]   c215_1    -45
    x[1425]   c260_1    -90
    x[1425]   c428      1
    x[1425]   c432      -1
    x[1426]   c211_1    -90
    x[1426]   c256_1    -45
    x[1426]   c428      -1
    x[1426]   c429      1
    x[1427]   c212_1    -90
    x[1427]   c257_1    -45
    x[1427]   c428      -1
    x[1427]   c430      1
    x[1428]   c213_1    -90
    x[1428]   c258_1    -45
    x[1428]   c428      -1
    x[1428]   c431      1
    x[1429]   c215_1    -90
    x[1429]   c260_1    -45
    x[1429]   c428      -1
    x[1429]   c432      1
    x[1430]   c216_1    -45
    x[1430]   c261_1    -90
    x[1430]   c429      1
    x[1430]   c430      -1
    x[1431]   c217_1    -45
    x[1431]   c262_1    -90
    x[1431]   c429      1
    x[1431]   c431      -1
    x[1432]   c219_1    -45
    x[1432]   c264_1    -90
    x[1432]   c429      1
    x[1432]   c432      -1
    x[1433]   c216_1    -90
    x[1433]   c261_1    -45
    x[1433]   c429      -1
    x[1433]   c430      1
    x[1434]   c217_1    -90
    x[1434]   c262_1    -45
    x[1434]   c429      -1
    x[1434]   c431      1
    x[1435]   c219_1    -90
    x[1435]   c264_1    -45
    x[1435]   c429      -1
    x[1435]   c432      1
    x[1436]   c220_1    -45
    x[1436]   c265_1    -90
    x[1436]   c430      1
    x[1436]   c431      -1
    x[1437]   c222_1    -45
    x[1437]   c267_1    -90
    x[1437]   c430      1
    x[1437]   c432      -1
    x[1438]   c220_1    -90
    x[1438]   c265_1    -45
    x[1438]   c430      -1
    x[1438]   c431      1
    x[1439]   c222_1    -90
    x[1439]   c267_1    -45
    x[1439]   c430      -1
    x[1439]   c432      1
    x[1440]   c224_1    -45
    x[1440]   c269_1    -90
    x[1440]   c431      1
    x[1440]   c432      -1
    x[1441]   c224_1    -90
    x[1441]   c269_1    -45
    x[1441]   c431      -1
    x[1441]   c432      1
    x[1442]   c181_1    -16
    x[1442]   c226_1    -170
    x[1442]   c433      1
    x[1443]   c189_1    -170
    x[1443]   c234_1    -16
    x[1443]   c434      1
    x[1444]   c190_1    -170
    x[1444]   c235_1    -16
    x[1444]   c435      1
    x[1445]   c191_1    -170
    x[1445]   c236_1    -16
    x[1445]   c436      1
    x[1446]   c192_1    -170
    x[1446]   c237_1    -16
    x[1446]   c437      1
    x[1447]   c193_1    -170
    x[1447]   c238_1    -16
    x[1447]   c438      1
    x[1448]   c194_1    -170
    x[1448]   c239_1    -16
    x[1448]   c439      1
    x[1449]   c195_1    -170
    x[1449]   c240_1    -16
    x[1449]   c440      1
    x[1450]   c196_1    -170
    x[1450]   c241_1    -16
    x[1450]   c441      1
    x[1451]   c197_1    -170
    x[1451]   c242_1    -16
    x[1451]   c442      1
    x[1452]   c204_1    -170
    x[1452]   c249_1    -16
    x[1452]   c443      1
    x[1453]   c210_1    -170
    x[1453]   c255_1    -16
    x[1453]   c444      1
    x[1454]   c215_1    -170
    x[1454]   c260_1    -16
    x[1454]   c445      1
    x[1455]   c219_1    -170
    x[1455]   c264_1    -16
    x[1455]   c446      1
    x[1456]   c222_1    -170
    x[1456]   c267_1    -16
    x[1456]   c447      1
    x[1457]   c224_1    -170
    x[1457]   c269_1    -16
    x[1457]   c448      1
    x[1458]   c225_1    -170
    x[1458]   c270_1    -16
    x[1458]   c449      1
    x[1459]   c41_2     1
    x[1459]   c54_2     1
    x[1459]   c190_1    -16
    x[1459]   c235_1    -170
    x[1459]   c450      1
    x[1459]   c453      1
    x[1460]   c191_1    -16
    x[1460]   c236_1    -170
    x[1460]   c450      1
    x[1460]   c454      1
    x[1461]   c192_1    -16
    x[1461]   c237_1    -170
    x[1461]   c450      1
    x[1461]   c455      1
    x[1462]   c42_2     1
    x[1462]   c193_1    -16
    x[1462]   c238_1    -170
    x[1462]   c450      1
    x[1462]   c456      1
    x[1463]   c194_1    -16
    x[1463]   c239_1    -170
    x[1463]   c450      1
    x[1463]   c457      1
    x[1464]   c43_2     1
    x[1464]   c195_1    -16
    x[1464]   c240_1    -170
    x[1464]   c450      1
    x[1464]   c458      1
    x[1465]   c196_1    -16
    x[1465]   c241_1    -170
    x[1465]   c450      1
    x[1465]   c459      1
    x[1466]   c41_2     1
    x[1466]   c42_2     1
    x[1466]   c43_2     1
    x[1466]   c197_1    -16
    x[1466]   c242_1    -170
    x[1466]   c450      1
    x[1466]   c451      1
    x[1467]   c54_2     1
    x[1467]   c181_1    -170
    x[1467]   c226_1    -16
    x[1467]   c450      1
    x[1467]   c452      1
    x[1468]   c189_1    -16
    x[1468]   c234_1    -170
    x[1468]   c451      1
    x[1468]   c452      -1
    x[1469]   c204_1    -16
    x[1469]   c249_1    -170
    x[1469]   c451      1
    x[1469]   c453      -1
    x[1470]   c210_1    -16
    x[1470]   c255_1    -170
    x[1470]   c451      1
    x[1470]   c454      -1
    x[1471]   c215_1    -16
    x[1471]   c260_1    -170
    x[1471]   c451      1
    x[1471]   c455      -1
    x[1472]   c219_1    -16
    x[1472]   c264_1    -170
    x[1472]   c451      1
    x[1472]   c456      -1
    x[1473]   c222_1    -16
    x[1473]   c267_1    -170
    x[1473]   c451      1
    x[1473]   c457      -1
    x[1474]   c224_1    -16
    x[1474]   c269_1    -170
    x[1474]   c451      1
    x[1474]   c458      -1
    x[1475]   c225_1    -16
    x[1475]   c270_1    -170
    x[1475]   c451      1
    x[1475]   c459      -1
    x[1476]   c182_1    -170
    x[1476]   c227_1    -16
    x[1476]   c452      1
    x[1476]   c453      -1
    x[1477]   c183_1    -170
    x[1477]   c228_1    -16
    x[1477]   c452      1
    x[1477]   c454      -1
    x[1478]   c184_1    -170
    x[1478]   c229_1    -16
    x[1478]   c452      1
    x[1478]   c455      -1
    x[1479]   c185_1    -170
    x[1479]   c230_1    -16
    x[1479]   c452      1
    x[1479]   c456      -1
    x[1480]   c186_1    -170
    x[1480]   c231_1    -16
    x[1480]   c452      1
    x[1480]   c457      -1
    x[1481]   c187_1    -170
    x[1481]   c232_1    -16
    x[1481]   c452      1
    x[1481]   c458      -1
    x[1482]   c188_1    -170
    x[1482]   c233_1    -16
    x[1482]   c452      1
    x[1482]   c459      -1
    x[1483]   c182_1    -16
    x[1483]   c227_1    -170
    x[1483]   c452      -1
    x[1483]   c453      1
    x[1484]   c183_1    -16
    x[1484]   c228_1    -170
    x[1484]   c452      -1
    x[1484]   c454      1
    x[1485]   c184_1    -16
    x[1485]   c229_1    -170
    x[1485]   c452      -1
    x[1485]   c455      1
    x[1486]   c185_1    -16
    x[1486]   c230_1    -170
    x[1486]   c452      -1
    x[1486]   c456      1
    x[1487]   c186_1    -16
    x[1487]   c231_1    -170
    x[1487]   c452      -1
    x[1487]   c457      1
    x[1488]   c187_1    -16
    x[1488]   c232_1    -170
    x[1488]   c452      -1
    x[1488]   c458      1
    x[1489]   c188_1    -16
    x[1489]   c233_1    -170
    x[1489]   c452      -1
    x[1489]   c459      1
    x[1490]   c198_1    -170
    x[1490]   c243_1    -16
    x[1490]   c453      1
    x[1490]   c454      -1
    x[1491]   c199_1    -170
    x[1491]   c244_1    -16
    x[1491]   c453      1
    x[1491]   c455      -1
    x[1492]   c200_1    -170
    x[1492]   c245_1    -16
    x[1492]   c453      1
    x[1492]   c456      -1
    x[1493]   c201_1    -170
    x[1493]   c246_1    -16
    x[1493]   c453      1
    x[1493]   c457      -1
    x[1494]   c202_1    -170
    x[1494]   c247_1    -16
    x[1494]   c453      1
    x[1494]   c458      -1
    x[1495]   c203_1    -170
    x[1495]   c248_1    -16
    x[1495]   c453      1
    x[1495]   c459      -1
    x[1496]   c198_1    -16
    x[1496]   c243_1    -170
    x[1496]   c453      -1
    x[1496]   c454      1
    x[1497]   c199_1    -16
    x[1497]   c244_1    -170
    x[1497]   c453      -1
    x[1497]   c455      1
    x[1498]   c200_1    -16
    x[1498]   c245_1    -170
    x[1498]   c453      -1
    x[1498]   c456      1
    x[1499]   c201_1    -16
    x[1499]   c246_1    -170
    x[1499]   c453      -1
    x[1499]   c457      1
    x[1500]   c202_1    -16
    x[1500]   c247_1    -170
    x[1500]   c453      -1
    x[1500]   c458      1
    x[1501]   c203_1    -16
    x[1501]   c248_1    -170
    x[1501]   c453      -1
    x[1501]   c459      1
    x[1502]   c205_1    -170
    x[1502]   c250_1    -16
    x[1502]   c454      1
    x[1502]   c455      -1
    x[1503]   c206_1    -170
    x[1503]   c251_1    -16
    x[1503]   c454      1
    x[1503]   c456      -1
    x[1504]   c207_1    -170
    x[1504]   c252_1    -16
    x[1504]   c454      1
    x[1504]   c457      -1
    x[1505]   c208_1    -170
    x[1505]   c253_1    -16
    x[1505]   c454      1
    x[1505]   c458      -1
    x[1506]   c209_1    -170
    x[1506]   c254_1    -16
    x[1506]   c454      1
    x[1506]   c459      -1
    x[1507]   c205_1    -16
    x[1507]   c250_1    -170
    x[1507]   c454      -1
    x[1507]   c455      1
    x[1508]   c206_1    -16
    x[1508]   c251_1    -170
    x[1508]   c454      -1
    x[1508]   c456      1
    x[1509]   c207_1    -16
    x[1509]   c252_1    -170
    x[1509]   c454      -1
    x[1509]   c457      1
    x[1510]   c208_1    -16
    x[1510]   c253_1    -170
    x[1510]   c454      -1
    x[1510]   c458      1
    x[1511]   c209_1    -16
    x[1511]   c254_1    -170
    x[1511]   c454      -1
    x[1511]   c459      1
    x[1512]   c211_1    -170
    x[1512]   c256_1    -16
    x[1512]   c455      1
    x[1512]   c456      -1
    x[1513]   c212_1    -170
    x[1513]   c257_1    -16
    x[1513]   c455      1
    x[1513]   c457      -1
    x[1514]   c213_1    -170
    x[1514]   c258_1    -16
    x[1514]   c455      1
    x[1514]   c458      -1
    x[1515]   c214_1    -170
    x[1515]   c259_1    -16
    x[1515]   c455      1
    x[1515]   c459      -1
    x[1516]   c211_1    -16
    x[1516]   c256_1    -170
    x[1516]   c455      -1
    x[1516]   c456      1
    x[1517]   c212_1    -16
    x[1517]   c257_1    -170
    x[1517]   c455      -1
    x[1517]   c457      1
    x[1518]   c213_1    -16
    x[1518]   c258_1    -170
    x[1518]   c455      -1
    x[1518]   c458      1
    x[1519]   c214_1    -16
    x[1519]   c259_1    -170
    x[1519]   c455      -1
    x[1519]   c459      1
    x[1520]   c216_1    -170
    x[1520]   c261_1    -16
    x[1520]   c456      1
    x[1520]   c457      -1
    x[1521]   c217_1    -170
    x[1521]   c262_1    -16
    x[1521]   c456      1
    x[1521]   c458      -1
    x[1522]   c218_1    -170
    x[1522]   c263_1    -16
    x[1522]   c456      1
    x[1522]   c459      -1
    x[1523]   c216_1    -16
    x[1523]   c261_1    -170
    x[1523]   c456      -1
    x[1523]   c457      1
    x[1524]   c217_1    -16
    x[1524]   c262_1    -170
    x[1524]   c456      -1
    x[1524]   c458      1
    x[1525]   c218_1    -16
    x[1525]   c263_1    -170
    x[1525]   c456      -1
    x[1525]   c459      1
    x[1526]   c220_1    -170
    x[1526]   c265_1    -16
    x[1526]   c457      1
    x[1526]   c458      -1
    x[1527]   c221_1    -170
    x[1527]   c266_1    -16
    x[1527]   c457      1
    x[1527]   c459      -1
    x[1528]   c220_1    -16
    x[1528]   c265_1    -170
    x[1528]   c457      -1
    x[1528]   c458      1
    x[1529]   c221_1    -16
    x[1529]   c266_1    -170
    x[1529]   c457      -1
    x[1529]   c459      1
    x[1530]   c223_1    -170
    x[1530]   c268_1    -16
    x[1530]   c458      1
    x[1530]   c459      -1
    x[1531]   c223_1    -16
    x[1531]   c268_1    -170
    x[1531]   c458      -1
    x[1531]   c459      1
    x[1532]   c189_1    -67
    x[1532]   c234_1    -86
    x[1532]   c460      1
    x[1533]   c197_1    -67
    x[1533]   c242_1    -86
    x[1533]   c461      1
    x[1534]   c204_1    -67
    x[1534]   c249_1    -86
    x[1534]   c462      1
    x[1535]   c210_1    -67
    x[1535]   c255_1    -86
    x[1535]   c463      1
    x[1536]   c215_1    -67
    x[1536]   c260_1    -86
    x[1536]   c464      1
    x[1537]   c219_1    -67
    x[1537]   c264_1    -86
    x[1537]   c465      1
    x[1538]   c222_1    -67
    x[1538]   c267_1    -86
    x[1538]   c466      1
    x[1539]   c223_1    -67
    x[1539]   c268_1    -86
    x[1539]   c467      1
    x[1540]   c224_1    -67
    x[1540]   c269_1    -86
    x[1540]   c468      1
    x[1541]   c225_1    -67
    x[1541]   c270_1    -86
    x[1541]   c469      1
    x[1542]   c187_1    -86
    x[1542]   c232_1    -67
    x[1542]   c470      1
    x[1543]   c195_1    -86
    x[1543]   c240_1    -67
    x[1543]   c471      1
    x[1544]   c202_1    -86
    x[1544]   c247_1    -67
    x[1544]   c472      1
    x[1545]   c208_1    -86
    x[1545]   c253_1    -67
    x[1545]   c473      1
    x[1546]   c213_1    -86
    x[1546]   c258_1    -67
    x[1546]   c474      1
    x[1547]   c217_1    -86
    x[1547]   c262_1    -67
    x[1547]   c475      1
    x[1548]   c220_1    -86
    x[1548]   c265_1    -67
    x[1548]   c476      1
    x[1549]   c222_2    1
    x[1549]   c189_1    -86
    x[1549]   c234_1    -67
    x[1549]   c477      1
    x[1549]   c479      1
    x[1550]   c223_2    1
    x[1550]   c197_1    -86
    x[1550]   c242_1    -67
    x[1550]   c477      1
    x[1550]   c480      1
    x[1551]   c224_2    1
    x[1551]   c204_1    -86
    x[1551]   c249_1    -67
    x[1551]   c477      1
    x[1551]   c481      1
    x[1552]   c210_1    -86
    x[1552]   c255_1    -67
    x[1552]   c477      1
    x[1552]   c482      1
    x[1553]   c225_2    1
    x[1553]   c215_1    -86
    x[1553]   c260_1    -67
    x[1553]   c477      1
    x[1553]   c483      1
    x[1554]   c219_1    -86
    x[1554]   c264_1    -67
    x[1554]   c477      1
    x[1554]   c484      1
    x[1555]   c222_1    -86
    x[1555]   c267_1    -67
    x[1555]   c477      1
    x[1555]   c485      1
    x[1556]   c222_2    1
    x[1556]   c223_2    1
    x[1556]   c224_2    1
    x[1556]   c225_2    1
    x[1556]   c224_1    -86
    x[1556]   c269_1    -67
    x[1556]   c477      1
    x[1556]   c478      1
    x[1557]   c225_1    -86
    x[1557]   c270_1    -67
    x[1557]   c477      1
    x[1557]   c486      1
    x[1558]   c329_1    1
    x[1558]   c330_1    1
    x[1558]   c331_1    1
    x[1558]   c187_1    -67
    x[1558]   c232_1    -86
    x[1558]   c478      1
    x[1558]   c479      -1
    x[1559]   c329_1    1
    x[1559]   c195_1    -67
    x[1559]   c240_1    -86
    x[1559]   c478      1
    x[1559]   c480      -1
    x[1560]   c202_1    -67
    x[1560]   c247_1    -86
    x[1560]   c478      1
    x[1560]   c481      -1
    x[1561]   c330_1    1
    x[1561]   c208_1    -67
    x[1561]   c253_1    -86
    x[1561]   c478      1
    x[1561]   c482      -1
    x[1562]   c213_1    -67
    x[1562]   c258_1    -86
    x[1562]   c478      1
    x[1562]   c483      -1
    x[1563]   c217_1    -67
    x[1563]   c262_1    -86
    x[1563]   c478      1
    x[1563]   c484      -1
    x[1564]   c331_1    1
    x[1564]   c220_1    -67
    x[1564]   c265_1    -86
    x[1564]   c478      1
    x[1564]   c485      -1
    x[1565]   c223_1    -86
    x[1565]   c268_1    -67
    x[1565]   c478      1
    x[1565]   c486      -1
    x[1566]   c181_1    -86
    x[1566]   c226_1    -67
    x[1566]   c479      1
    x[1566]   c480      -1
    x[1567]   c182_1    -86
    x[1567]   c227_1    -67
    x[1567]   c479      1
    x[1567]   c481      -1
    x[1568]   c183_1    -86
    x[1568]   c228_1    -67
    x[1568]   c479      1
    x[1568]   c482      -1
    x[1569]   c184_1    -86
    x[1569]   c229_1    -67
    x[1569]   c479      1
    x[1569]   c483      -1
    x[1570]   c185_1    -86
    x[1570]   c230_1    -67
    x[1570]   c479      1
    x[1570]   c484      -1
    x[1571]   c186_1    -86
    x[1571]   c231_1    -67
    x[1571]   c479      1
    x[1571]   c485      -1
    x[1572]   c188_1    -86
    x[1572]   c233_1    -67
    x[1572]   c479      1
    x[1572]   c486      -1
    x[1573]   c181_1    -67
    x[1573]   c226_1    -86
    x[1573]   c479      -1
    x[1573]   c480      1
    x[1574]   c182_1    -67
    x[1574]   c227_1    -86
    x[1574]   c479      -1
    x[1574]   c481      1
    x[1575]   c183_1    -67
    x[1575]   c228_1    -86
    x[1575]   c479      -1
    x[1575]   c482      1
    x[1576]   c184_1    -67
    x[1576]   c229_1    -86
    x[1576]   c479      -1
    x[1576]   c483      1
    x[1577]   c185_1    -67
    x[1577]   c230_1    -86
    x[1577]   c479      -1
    x[1577]   c484      1
    x[1578]   c186_1    -67
    x[1578]   c231_1    -86
    x[1578]   c479      -1
    x[1578]   c485      1
    x[1579]   c188_1    -67
    x[1579]   c233_1    -86
    x[1579]   c479      -1
    x[1579]   c486      1
    x[1580]   c190_1    -86
    x[1580]   c235_1    -67
    x[1580]   c480      1
    x[1580]   c481      -1
    x[1581]   c191_1    -86
    x[1581]   c236_1    -67
    x[1581]   c480      1
    x[1581]   c482      -1
    x[1582]   c192_1    -86
    x[1582]   c237_1    -67
    x[1582]   c480      1
    x[1582]   c483      -1
    x[1583]   c193_1    -86
    x[1583]   c238_1    -67
    x[1583]   c480      1
    x[1583]   c484      -1
    x[1584]   c194_1    -86
    x[1584]   c239_1    -67
    x[1584]   c480      1
    x[1584]   c485      -1
    x[1585]   c196_1    -86
    x[1585]   c241_1    -67
    x[1585]   c480      1
    x[1585]   c486      -1
    x[1586]   c190_1    -67
    x[1586]   c235_1    -86
    x[1586]   c480      -1
    x[1586]   c481      1
    x[1587]   c191_1    -67
    x[1587]   c236_1    -86
    x[1587]   c480      -1
    x[1587]   c482      1
    x[1588]   c192_1    -67
    x[1588]   c237_1    -86
    x[1588]   c480      -1
    x[1588]   c483      1
    x[1589]   c193_1    -67
    x[1589]   c238_1    -86
    x[1589]   c480      -1
    x[1589]   c484      1
    x[1590]   c194_1    -67
    x[1590]   c239_1    -86
    x[1590]   c480      -1
    x[1590]   c485      1
    x[1591]   c196_1    -67
    x[1591]   c241_1    -86
    x[1591]   c480      -1
    x[1591]   c486      1
    x[1592]   c198_1    -86
    x[1592]   c243_1    -67
    x[1592]   c481      1
    x[1592]   c482      -1
    x[1593]   c199_1    -86
    x[1593]   c244_1    -67
    x[1593]   c481      1
    x[1593]   c483      -1
    x[1594]   c200_1    -86
    x[1594]   c245_1    -67
    x[1594]   c481      1
    x[1594]   c484      -1
    x[1595]   c201_1    -86
    x[1595]   c246_1    -67
    x[1595]   c481      1
    x[1595]   c485      -1
    x[1596]   c203_1    -86
    x[1596]   c248_1    -67
    x[1596]   c481      1
    x[1596]   c486      -1
    x[1597]   c198_1    -67
    x[1597]   c243_1    -86
    x[1597]   c481      -1
    x[1597]   c482      1
    x[1598]   c199_1    -67
    x[1598]   c244_1    -86
    x[1598]   c481      -1
    x[1598]   c483      1
    x[1599]   c200_1    -67
    x[1599]   c245_1    -86
    x[1599]   c481      -1
    x[1599]   c484      1
    x[1600]   c201_1    -67
    x[1600]   c246_1    -86
    x[1600]   c481      -1
    x[1600]   c485      1
    x[1601]   c203_1    -67
    x[1601]   c248_1    -86
    x[1601]   c481      -1
    x[1601]   c486      1
    x[1602]   c205_1    -86
    x[1602]   c250_1    -67
    x[1602]   c482      1
    x[1602]   c483      -1
    x[1603]   c206_1    -86
    x[1603]   c251_1    -67
    x[1603]   c482      1
    x[1603]   c484      -1
    x[1604]   c207_1    -86
    x[1604]   c252_1    -67
    x[1604]   c482      1
    x[1604]   c485      -1
    x[1605]   c209_1    -86
    x[1605]   c254_1    -67
    x[1605]   c482      1
    x[1605]   c486      -1
    x[1606]   c205_1    -67
    x[1606]   c250_1    -86
    x[1606]   c482      -1
    x[1606]   c483      1
    x[1607]   c206_1    -67
    x[1607]   c251_1    -86
    x[1607]   c482      -1
    x[1607]   c484      1
    x[1608]   c207_1    -67
    x[1608]   c252_1    -86
    x[1608]   c482      -1
    x[1608]   c485      1
    x[1609]   c209_1    -67
    x[1609]   c254_1    -86
    x[1609]   c482      -1
    x[1609]   c486      1
    x[1610]   c211_1    -86
    x[1610]   c256_1    -67
    x[1610]   c483      1
    x[1610]   c484      -1
    x[1611]   c212_1    -86
    x[1611]   c257_1    -67
    x[1611]   c483      1
    x[1611]   c485      -1
    x[1612]   c214_1    -86
    x[1612]   c259_1    -67
    x[1612]   c483      1
    x[1612]   c486      -1
    x[1613]   c211_1    -67
    x[1613]   c256_1    -86
    x[1613]   c483      -1
    x[1613]   c484      1
    x[1614]   c212_1    -67
    x[1614]   c257_1    -86
    x[1614]   c483      -1
    x[1614]   c485      1
    x[1615]   c214_1    -67
    x[1615]   c259_1    -86
    x[1615]   c483      -1
    x[1615]   c486      1
    x[1616]   c216_1    -86
    x[1616]   c261_1    -67
    x[1616]   c484      1
    x[1616]   c485      -1
    x[1617]   c218_1    -86
    x[1617]   c263_1    -67
    x[1617]   c484      1
    x[1617]   c486      -1
    x[1618]   c216_1    -67
    x[1618]   c261_1    -86
    x[1618]   c484      -1
    x[1618]   c485      1
    x[1619]   c218_1    -67
    x[1619]   c263_1    -86
    x[1619]   c484      -1
    x[1619]   c486      1
    x[1620]   c221_1    -86
    x[1620]   c266_1    -67
    x[1620]   c485      1
    x[1620]   c486      -1
    x[1621]   c221_1    -67
    x[1621]   c266_1    -86
    x[1621]   c485      -1
    x[1621]   c486      1
    x[1622]   c188_1    -130
    x[1622]   c233_1    -51
    x[1622]   c487      1
    x[1623]   c196_1    -130
    x[1623]   c241_1    -51
    x[1623]   c488      1
    x[1624]   c198_1    -130
    x[1624]   c243_1    -51
    x[1624]   c489      1
    x[1625]   c199_1    -130
    x[1625]   c244_1    -51
    x[1625]   c490      1
    x[1626]   c200_1    -130
    x[1626]   c245_1    -51
    x[1626]   c491      1
    x[1627]   c201_1    -130
    x[1627]   c246_1    -51
    x[1627]   c492      1
    x[1628]   c202_1    -130
    x[1628]   c247_1    -51
    x[1628]   c493      1
    x[1629]   c203_1    -130
    x[1629]   c248_1    -51
    x[1629]   c494      1
    x[1630]   c204_1    -130
    x[1630]   c249_1    -51
    x[1630]   c495      1
    x[1631]   c209_1    -130
    x[1631]   c254_1    -51
    x[1631]   c496      1
    x[1632]   c214_1    -130
    x[1632]   c259_1    -51
    x[1632]   c497      1
    x[1633]   c218_1    -130
    x[1633]   c263_1    -51
    x[1633]   c498      1
    x[1634]   c221_1    -130
    x[1634]   c266_1    -51
    x[1634]   c499      1
    x[1635]   c223_1    -130
    x[1635]   c268_1    -51
    x[1635]   c500      1
    x[1636]   c182_1    -51
    x[1636]   c227_1    -130
    x[1636]   c501      1
    x[1637]   c190_1    -51
    x[1637]   c235_1    -130
    x[1637]   c502      1
    x[1638]   c225_1    -51
    x[1638]   c270_1    -130
    x[1638]   c503      1
    x[1639]   c5_2      1
    x[1639]   c225_1    -130
    x[1639]   c270_1    -51
    x[1639]   c504      1
    x[1639]   c513      1
    x[1640]   c6_2      1
    x[1640]   c188_1    -51
    x[1640]   c233_1    -130
    x[1640]   c504      1
    x[1640]   c506      1
    x[1641]   c196_1    -51
    x[1641]   c241_1    -130
    x[1641]   c504      1
    x[1641]   c507      1
    x[1642]   c5_2      1
    x[1642]   c6_2      1
    x[1642]   c7_2      1
    x[1642]   c8_2      1
    x[1642]   c203_1    -51
    x[1642]   c248_1    -130
    x[1642]   c504      1
    x[1642]   c505      1
    x[1643]   c209_1    -51
    x[1643]   c254_1    -130
    x[1643]   c504      1
    x[1643]   c508      1
    x[1644]   c7_2      1
    x[1644]   c214_1    -51
    x[1644]   c259_1    -130
    x[1644]   c504      1
    x[1644]   c509      1
    x[1645]   c8_2      1
    x[1645]   c218_1    -51
    x[1645]   c263_1    -130
    x[1645]   c504      1
    x[1645]   c510      1
    x[1646]   c221_1    -51
    x[1646]   c266_1    -130
    x[1646]   c504      1
    x[1646]   c511      1
    x[1647]   c223_1    -51
    x[1647]   c268_1    -130
    x[1647]   c504      1
    x[1647]   c512      1
    x[1648]   c32_2     1
    x[1648]   c33_2     1
    x[1648]   c34_2     1
    x[1648]   c35_2     1
    x[1648]   c182_1    -130
    x[1648]   c227_1    -51
    x[1648]   c505      1
    x[1648]   c506      -1
    x[1649]   c36_2     1
    x[1649]   c190_1    -130
    x[1649]   c235_1    -51
    x[1649]   c505      1
    x[1649]   c507      -1
    x[1650]   c32_2     1
    x[1650]   c36_2     1
    x[1650]   c198_1    -51
    x[1650]   c243_1    -130
    x[1650]   c505      1
    x[1650]   c508      -1
    x[1651]   c33_2     1
    x[1651]   c199_1    -51
    x[1651]   c244_1    -130
    x[1651]   c505      1
    x[1651]   c509      -1
    x[1652]   c200_1    -51
    x[1652]   c245_1    -130
    x[1652]   c505      1
    x[1652]   c510      -1
    x[1653]   c34_2     1
    x[1653]   c201_1    -51
    x[1653]   c246_1    -130
    x[1653]   c505      1
    x[1653]   c511      -1
    x[1654]   c202_1    -51
    x[1654]   c247_1    -130
    x[1654]   c505      1
    x[1654]   c512      -1
    x[1655]   c35_2     1
    x[1655]   c204_1    -51
    x[1655]   c249_1    -130
    x[1655]   c505      1
    x[1655]   c513      -1
    x[1656]   c181_1    -51
    x[1656]   c226_1    -130
    x[1656]   c506      1
    x[1656]   c507      -1
    x[1657]   c183_1    -51
    x[1657]   c228_1    -130
    x[1657]   c506      1
    x[1657]   c508      -1
    x[1658]   c184_1    -51
    x[1658]   c229_1    -130
    x[1658]   c506      1
    x[1658]   c509      -1
    x[1659]   c185_1    -51
    x[1659]   c230_1    -130
    x[1659]   c506      1
    x[1659]   c510      -1
    x[1660]   c186_1    -51
    x[1660]   c231_1    -130
    x[1660]   c506      1
    x[1660]   c511      -1
    x[1661]   c187_1    -51
    x[1661]   c232_1    -130
    x[1661]   c506      1
    x[1661]   c512      -1
    x[1662]   c189_1    -51
    x[1662]   c234_1    -130
    x[1662]   c506      1
    x[1662]   c513      -1
    x[1663]   c181_1    -130
    x[1663]   c226_1    -51
    x[1663]   c506      -1
    x[1663]   c507      1
    x[1664]   c183_1    -130
    x[1664]   c228_1    -51
    x[1664]   c506      -1
    x[1664]   c508      1
    x[1665]   c184_1    -130
    x[1665]   c229_1    -51
    x[1665]   c506      -1
    x[1665]   c509      1
    x[1666]   c185_1    -130
    x[1666]   c230_1    -51
    x[1666]   c506      -1
    x[1666]   c510      1
    x[1667]   c186_1    -130
    x[1667]   c231_1    -51
    x[1667]   c506      -1
    x[1667]   c511      1
    x[1668]   c187_1    -130
    x[1668]   c232_1    -51
    x[1668]   c506      -1
    x[1668]   c512      1
    x[1669]   c189_1    -130
    x[1669]   c234_1    -51
    x[1669]   c506      -1
    x[1669]   c513      1
    x[1670]   c191_1    -51
    x[1670]   c236_1    -130
    x[1670]   c507      1
    x[1670]   c508      -1
    x[1671]   c192_1    -51
    x[1671]   c237_1    -130
    x[1671]   c507      1
    x[1671]   c509      -1
    x[1672]   c193_1    -51
    x[1672]   c238_1    -130
    x[1672]   c507      1
    x[1672]   c510      -1
    x[1673]   c194_1    -51
    x[1673]   c239_1    -130
    x[1673]   c507      1
    x[1673]   c511      -1
    x[1674]   c195_1    -51
    x[1674]   c240_1    -130
    x[1674]   c507      1
    x[1674]   c512      -1
    x[1675]   c197_1    -51
    x[1675]   c242_1    -130
    x[1675]   c507      1
    x[1675]   c513      -1
    x[1676]   c191_1    -130
    x[1676]   c236_1    -51
    x[1676]   c507      -1
    x[1676]   c508      1
    x[1677]   c192_1    -130
    x[1677]   c237_1    -51
    x[1677]   c507      -1
    x[1677]   c509      1
    x[1678]   c193_1    -130
    x[1678]   c238_1    -51
    x[1678]   c507      -1
    x[1678]   c510      1
    x[1679]   c194_1    -130
    x[1679]   c239_1    -51
    x[1679]   c507      -1
    x[1679]   c511      1
    x[1680]   c195_1    -130
    x[1680]   c240_1    -51
    x[1680]   c507      -1
    x[1680]   c512      1
    x[1681]   c197_1    -130
    x[1681]   c242_1    -51
    x[1681]   c507      -1
    x[1681]   c513      1
    x[1682]   c205_1    -51
    x[1682]   c250_1    -130
    x[1682]   c508      1
    x[1682]   c509      -1
    x[1683]   c206_1    -51
    x[1683]   c251_1    -130
    x[1683]   c508      1
    x[1683]   c510      -1
    x[1684]   c207_1    -51
    x[1684]   c252_1    -130
    x[1684]   c508      1
    x[1684]   c511      -1
    x[1685]   c208_1    -51
    x[1685]   c253_1    -130
    x[1685]   c508      1
    x[1685]   c512      -1
    x[1686]   c210_1    -51
    x[1686]   c255_1    -130
    x[1686]   c508      1
    x[1686]   c513      -1
    x[1687]   c205_1    -130
    x[1687]   c250_1    -51
    x[1687]   c508      -1
    x[1687]   c509      1
    x[1688]   c206_1    -130
    x[1688]   c251_1    -51
    x[1688]   c508      -1
    x[1688]   c510      1
    x[1689]   c207_1    -130
    x[1689]   c252_1    -51
    x[1689]   c508      -1
    x[1689]   c511      1
    x[1690]   c208_1    -130
    x[1690]   c253_1    -51
    x[1690]   c508      -1
    x[1690]   c512      1
    x[1691]   c210_1    -130
    x[1691]   c255_1    -51
    x[1691]   c508      -1
    x[1691]   c513      1
    x[1692]   c211_1    -51
    x[1692]   c256_1    -130
    x[1692]   c509      1
    x[1692]   c510      -1
    x[1693]   c212_1    -51
    x[1693]   c257_1    -130
    x[1693]   c509      1
    x[1693]   c511      -1
    x[1694]   c213_1    -51
    x[1694]   c258_1    -130
    x[1694]   c509      1
    x[1694]   c512      -1
    x[1695]   c215_1    -51
    x[1695]   c260_1    -130
    x[1695]   c509      1
    x[1695]   c513      -1
    x[1696]   c211_1    -130
    x[1696]   c256_1    -51
    x[1696]   c509      -1
    x[1696]   c510      1
    x[1697]   c212_1    -130
    x[1697]   c257_1    -51
    x[1697]   c509      -1
    x[1697]   c511      1
    x[1698]   c213_1    -130
    x[1698]   c258_1    -51
    x[1698]   c509      -1
    x[1698]   c512      1
    x[1699]   c215_1    -130
    x[1699]   c260_1    -51
    x[1699]   c509      -1
    x[1699]   c513      1
    x[1700]   c216_1    -51
    x[1700]   c261_1    -130
    x[1700]   c510      1
    x[1700]   c511      -1
    x[1701]   c217_1    -51
    x[1701]   c262_1    -130
    x[1701]   c510      1
    x[1701]   c512      -1
    x[1702]   c219_1    -51
    x[1702]   c264_1    -130
    x[1702]   c510      1
    x[1702]   c513      -1
    x[1703]   c216_1    -130
    x[1703]   c261_1    -51
    x[1703]   c510      -1
    x[1703]   c511      1
    x[1704]   c217_1    -130
    x[1704]   c262_1    -51
    x[1704]   c510      -1
    x[1704]   c512      1
    x[1705]   c219_1    -130
    x[1705]   c264_1    -51
    x[1705]   c510      -1
    x[1705]   c513      1
    x[1706]   c220_1    -51
    x[1706]   c265_1    -130
    x[1706]   c511      1
    x[1706]   c512      -1
    x[1707]   c222_1    -51
    x[1707]   c267_1    -130
    x[1707]   c511      1
    x[1707]   c513      -1
    x[1708]   c220_1    -130
    x[1708]   c265_1    -51
    x[1708]   c511      -1
    x[1708]   c512      1
    x[1709]   c222_1    -130
    x[1709]   c267_1    -51
    x[1709]   c511      -1
    x[1709]   c513      1
    x[1710]   c224_1    -51
    x[1710]   c269_1    -130
    x[1710]   c512      1
    x[1710]   c513      -1
    x[1711]   c224_1    -130
    x[1711]   c269_1    -51
    x[1711]   c512      -1
    x[1711]   c513      1
    x[1712]   c182_1    -168
    x[1712]   c227_1    -180
    x[1712]   c514      1
    x[1713]   c190_1    -168
    x[1713]   c235_1    -180
    x[1713]   c515      1
    x[1714]   c205_1    -168
    x[1714]   c250_1    -180
    x[1714]   c516      1
    x[1715]   c206_1    -168
    x[1715]   c251_1    -180
    x[1715]   c517      1
    x[1716]   c207_1    -168
    x[1716]   c252_1    -180
    x[1716]   c518      1
    x[1717]   c208_1    -168
    x[1717]   c253_1    -180
    x[1717]   c519      1
    x[1718]   c209_1    -168
    x[1718]   c254_1    -180
    x[1718]   c520      1
    x[1719]   c210_1    -168
    x[1719]   c255_1    -180
    x[1719]   c521      1
    x[1720]   c183_1    -180
    x[1720]   c228_1    -168
    x[1720]   c522      1
    x[1721]   c191_1    -180
    x[1721]   c236_1    -168
    x[1721]   c523      1
    x[1722]   c198_1    -180
    x[1722]   c243_1    -168
    x[1722]   c524      1
    x[1723]   c199_1    -180
    x[1723]   c244_1    -168
    x[1723]   c525      1
    x[1724]   c200_1    -180
    x[1724]   c245_1    -168
    x[1724]   c526      1
    x[1725]   c201_1    -180
    x[1725]   c246_1    -168
    x[1725]   c527      1
    x[1726]   c202_1    -180
    x[1726]   c247_1    -168
    x[1726]   c528      1
    x[1727]   c203_1    -180
    x[1727]   c248_1    -168
    x[1727]   c529      1
    x[1728]   c204_1    -180
    x[1728]   c249_1    -168
    x[1728]   c530      1
    x[1729]   c89_2     1
    x[1729]   c90_2     1
    x[1729]   c91_2     1
    x[1729]   c92_2     1
    x[1729]   c93_2     1
    x[1729]   c94_2     1
    x[1729]   c198_1    -168
    x[1729]   c243_1    -180
    x[1729]   c531      1
    x[1729]   c532      1
    x[1730]   c199_1    -168
    x[1730]   c244_1    -180
    x[1730]   c531      1
    x[1730]   c535      1
    x[1731]   c89_2     1
    x[1731]   c200_1    -168
    x[1731]   c245_1    -180
    x[1731]   c531      1
    x[1731]   c536      1
    x[1732]   c90_2     1
    x[1732]   c201_1    -168
    x[1732]   c246_1    -180
    x[1732]   c531      1
    x[1732]   c537      1
    x[1733]   c91_2     1
    x[1733]   c202_1    -168
    x[1733]   c247_1    -180
    x[1733]   c531      1
    x[1733]   c538      1
    x[1734]   c92_2     1
    x[1734]   c203_1    -168
    x[1734]   c248_1    -180
    x[1734]   c531      1
    x[1734]   c539      1
    x[1735]   c93_2     1
    x[1735]   c204_1    -168
    x[1735]   c249_1    -180
    x[1735]   c531      1
    x[1735]   c540      1
    x[1736]   c94_2     1
    x[1736]   c182_1    -180
    x[1736]   c227_1    -168
    x[1736]   c531      1
    x[1736]   c533      1
    x[1737]   c190_1    -180
    x[1737]   c235_1    -168
    x[1737]   c531      1
    x[1737]   c534      1
    x[1738]   c120_2    1
    x[1738]   c121_2    1
    x[1738]   c183_1    -168
    x[1738]   c228_1    -180
    x[1738]   c532      1
    x[1738]   c533      -1
    x[1739]   c122_2    1
    x[1739]   c191_1    -168
    x[1739]   c236_1    -180
    x[1739]   c532      1
    x[1739]   c534      -1
    x[1740]   c122_2    1
    x[1740]   c205_1    -180
    x[1740]   c250_1    -168
    x[1740]   c532      1
    x[1740]   c535      -1
    x[1741]   c120_2    1
    x[1741]   c206_1    -180
    x[1741]   c251_1    -168
    x[1741]   c532      1
    x[1741]   c536      -1
    x[1742]   c207_1    -180
    x[1742]   c252_1    -168
    x[1742]   c532      1
    x[1742]   c537      -1
    x[1743]   c208_1    -180
    x[1743]   c253_1    -168
    x[1743]   c532      1
    x[1743]   c538      -1
    x[1744]   c121_2    1
    x[1744]   c209_1    -180
    x[1744]   c254_1    -168
    x[1744]   c532      1
    x[1744]   c539      -1
    x[1745]   c210_1    -180
    x[1745]   c255_1    -168
    x[1745]   c532      1
    x[1745]   c540      -1
    x[1746]   c181_1    -180
    x[1746]   c226_1    -168
    x[1746]   c533      1
    x[1746]   c534      -1
    x[1747]   c184_1    -180
    x[1747]   c229_1    -168
    x[1747]   c533      1
    x[1747]   c535      -1
    x[1748]   c185_1    -180
    x[1748]   c230_1    -168
    x[1748]   c533      1
    x[1748]   c536      -1
    x[1749]   c186_1    -180
    x[1749]   c231_1    -168
    x[1749]   c533      1
    x[1749]   c537      -1
    x[1750]   c187_1    -180
    x[1750]   c232_1    -168
    x[1750]   c533      1
    x[1750]   c538      -1
    x[1751]   c188_1    -180
    x[1751]   c233_1    -168
    x[1751]   c533      1
    x[1751]   c539      -1
    x[1752]   c189_1    -180
    x[1752]   c234_1    -168
    x[1752]   c533      1
    x[1752]   c540      -1
    x[1753]   c181_1    -168
    x[1753]   c226_1    -180
    x[1753]   c533      -1
    x[1753]   c534      1
    x[1754]   c184_1    -168
    x[1754]   c229_1    -180
    x[1754]   c533      -1
    x[1754]   c535      1
    x[1755]   c185_1    -168
    x[1755]   c230_1    -180
    x[1755]   c533      -1
    x[1755]   c536      1
    x[1756]   c186_1    -168
    x[1756]   c231_1    -180
    x[1756]   c533      -1
    x[1756]   c537      1
    x[1757]   c187_1    -168
    x[1757]   c232_1    -180
    x[1757]   c533      -1
    x[1757]   c538      1
    x[1758]   c188_1    -168
    x[1758]   c233_1    -180
    x[1758]   c533      -1
    x[1758]   c539      1
    x[1759]   c189_1    -168
    x[1759]   c234_1    -180
    x[1759]   c533      -1
    x[1759]   c540      1
    x[1760]   c192_1    -180
    x[1760]   c237_1    -168
    x[1760]   c534      1
    x[1760]   c535      -1
    x[1761]   c193_1    -180
    x[1761]   c238_1    -168
    x[1761]   c534      1
    x[1761]   c536      -1
    x[1762]   c194_1    -180
    x[1762]   c239_1    -168
    x[1762]   c534      1
    x[1762]   c537      -1
    x[1763]   c195_1    -180
    x[1763]   c240_1    -168
    x[1763]   c534      1
    x[1763]   c538      -1
    x[1764]   c196_1    -180
    x[1764]   c241_1    -168
    x[1764]   c534      1
    x[1764]   c539      -1
    x[1765]   c197_1    -180
    x[1765]   c242_1    -168
    x[1765]   c534      1
    x[1765]   c540      -1
    x[1766]   c192_1    -168
    x[1766]   c237_1    -180
    x[1766]   c534      -1
    x[1766]   c535      1
    x[1767]   c193_1    -168
    x[1767]   c238_1    -180
    x[1767]   c534      -1
    x[1767]   c536      1
    x[1768]   c194_1    -168
    x[1768]   c239_1    -180
    x[1768]   c534      -1
    x[1768]   c537      1
    x[1769]   c195_1    -168
    x[1769]   c240_1    -180
    x[1769]   c534      -1
    x[1769]   c538      1
    x[1770]   c196_1    -168
    x[1770]   c241_1    -180
    x[1770]   c534      -1
    x[1770]   c539      1
    x[1771]   c197_1    -168
    x[1771]   c242_1    -180
    x[1771]   c534      -1
    x[1771]   c540      1
    x[1772]   c211_1    -180
    x[1772]   c256_1    -168
    x[1772]   c535      1
    x[1772]   c536      -1
    x[1773]   c212_1    -180
    x[1773]   c257_1    -168
    x[1773]   c535      1
    x[1773]   c537      -1
    x[1774]   c213_1    -180
    x[1774]   c258_1    -168
    x[1774]   c535      1
    x[1774]   c538      -1
    x[1775]   c214_1    -180
    x[1775]   c259_1    -168
    x[1775]   c535      1
    x[1775]   c539      -1
    x[1776]   c215_1    -180
    x[1776]   c260_1    -168
    x[1776]   c535      1
    x[1776]   c540      -1
    x[1777]   c211_1    -168
    x[1777]   c256_1    -180
    x[1777]   c535      -1
    x[1777]   c536      1
    x[1778]   c212_1    -168
    x[1778]   c257_1    -180
    x[1778]   c535      -1
    x[1778]   c537      1
    x[1779]   c213_1    -168
    x[1779]   c258_1    -180
    x[1779]   c535      -1
    x[1779]   c538      1
    x[1780]   c214_1    -168
    x[1780]   c259_1    -180
    x[1780]   c535      -1
    x[1780]   c539      1
    x[1781]   c215_1    -168
    x[1781]   c260_1    -180
    x[1781]   c535      -1
    x[1781]   c540      1
    x[1782]   c216_1    -180
    x[1782]   c261_1    -168
    x[1782]   c536      1
    x[1782]   c537      -1
    x[1783]   c217_1    -180
    x[1783]   c262_1    -168
    x[1783]   c536      1
    x[1783]   c538      -1
    x[1784]   c218_1    -180
    x[1784]   c263_1    -168
    x[1784]   c536      1
    x[1784]   c539      -1
    x[1785]   c219_1    -180
    x[1785]   c264_1    -168
    x[1785]   c536      1
    x[1785]   c540      -1
    x[1786]   c216_1    -168
    x[1786]   c261_1    -180
    x[1786]   c536      -1
    x[1786]   c537      1
    x[1787]   c217_1    -168
    x[1787]   c262_1    -180
    x[1787]   c536      -1
    x[1787]   c538      1
    x[1788]   c218_1    -168
    x[1788]   c263_1    -180
    x[1788]   c536      -1
    x[1788]   c539      1
    x[1789]   c219_1    -168
    x[1789]   c264_1    -180
    x[1789]   c536      -1
    x[1789]   c540      1
    x[1790]   c220_1    -180
    x[1790]   c265_1    -168
    x[1790]   c537      1
    x[1790]   c538      -1
    x[1791]   c221_1    -180
    x[1791]   c266_1    -168
    x[1791]   c537      1
    x[1791]   c539      -1
    x[1792]   c222_1    -180
    x[1792]   c267_1    -168
    x[1792]   c537      1
    x[1792]   c540      -1
    x[1793]   c220_1    -168
    x[1793]   c265_1    -180
    x[1793]   c537      -1
    x[1793]   c538      1
    x[1794]   c221_1    -168
    x[1794]   c266_1    -180
    x[1794]   c537      -1
    x[1794]   c539      1
    x[1795]   c222_1    -168
    x[1795]   c267_1    -180
    x[1795]   c537      -1
    x[1795]   c540      1
    x[1796]   c223_1    -180
    x[1796]   c268_1    -168
    x[1796]   c538      1
    x[1796]   c539      -1
    x[1797]   c224_1    -180
    x[1797]   c269_1    -168
    x[1797]   c538      1
    x[1797]   c540      -1
    x[1798]   c223_1    -168
    x[1798]   c268_1    -180
    x[1798]   c538      -1
    x[1798]   c539      1
    x[1799]   c224_1    -168
    x[1799]   c269_1    -180
    x[1799]   c538      -1
    x[1799]   c540      1
    x[1800]   c225_1    -180
    x[1800]   c270_1    -168
    x[1800]   c539      1
    x[1800]   c540      -1
    x[1801]   c225_1    -168
    x[1801]   c270_1    -180
    x[1801]   c539      -1
    x[1801]   c540      1
    x[1802]   c182_1    -24
    x[1802]   c227_1    -152
    x[1802]   c541      1
    x[1803]   c190_1    -24
    x[1803]   c235_1    -152
    x[1803]   c542      1
    x[1804]   c211_1    -24
    x[1804]   c256_1    -152
    x[1804]   c543      1
    x[1805]   c212_1    -24
    x[1805]   c257_1    -152
    x[1805]   c544      1
    x[1806]   c213_1    -24
    x[1806]   c258_1    -152
    x[1806]   c545      1
    x[1807]   c214_1    -24
    x[1807]   c259_1    -152
    x[1807]   c546      1
    x[1808]   c215_1    -24
    x[1808]   c260_1    -152
    x[1808]   c547      1
    x[1809]   c184_1    -152
    x[1809]   c229_1    -24
    x[1809]   c548      1
    x[1810]   c192_1    -152
    x[1810]   c237_1    -24
    x[1810]   c549      1
    x[1811]   c198_1    -152
    x[1811]   c243_1    -24
    x[1811]   c550      1
    x[1812]   c199_1    -152
    x[1812]   c244_1    -24
    x[1812]   c551      1
    x[1813]   c200_1    -152
    x[1813]   c245_1    -24
    x[1813]   c552      1
    x[1814]   c201_1    -152
    x[1814]   c246_1    -24
    x[1814]   c553      1
    x[1815]   c202_1    -152
    x[1815]   c247_1    -24
    x[1815]   c554      1
    x[1816]   c203_1    -152
    x[1816]   c248_1    -24
    x[1816]   c555      1
    x[1817]   c204_1    -152
    x[1817]   c249_1    -24
    x[1817]   c556      1
    x[1818]   c205_1    -152
    x[1818]   c250_1    -24
    x[1818]   c557      1
    x[1819]   c181_2    1
    x[1819]   c198_1    -24
    x[1819]   c243_1    -152
    x[1819]   c558      1
    x[1819]   c562      1
    x[1820]   c181_2    1
    x[1820]   c182_2    1
    x[1820]   c183_2    1
    x[1820]   c184_2    1
    x[1820]   c185_2    1
    x[1820]   c199_1    -24
    x[1820]   c244_1    -152
    x[1820]   c558      1
    x[1820]   c559      1
    x[1821]   c200_1    -24
    x[1821]   c245_1    -152
    x[1821]   c558      1
    x[1821]   c563      1
    x[1822]   c182_2    1
    x[1822]   c201_1    -24
    x[1822]   c246_1    -152
    x[1822]   c558      1
    x[1822]   c564      1
    x[1823]   c183_2    1
    x[1823]   c202_1    -24
    x[1823]   c247_1    -152
    x[1823]   c558      1
    x[1823]   c565      1
    x[1824]   c203_1    -24
    x[1824]   c248_1    -152
    x[1824]   c558      1
    x[1824]   c566      1
    x[1825]   c184_2    1
    x[1825]   c204_1    -24
    x[1825]   c249_1    -152
    x[1825]   c558      1
    x[1825]   c567      1
    x[1826]   c185_2    1
    x[1826]   c182_1    -152
    x[1826]   c227_1    -24
    x[1826]   c558      1
    x[1826]   c560      1
    x[1827]   c190_1    -152
    x[1827]   c235_1    -24
    x[1827]   c558      1
    x[1827]   c561      1
    x[1828]   c204_2    1
    x[1828]   c205_2    1
    x[1828]   c184_1    -24
    x[1828]   c229_1    -152
    x[1828]   c559      1
    x[1828]   c560      -1
    x[1829]   c206_2    1
    x[1829]   c192_1    -24
    x[1829]   c237_1    -152
    x[1829]   c559      1
    x[1829]   c561      -1
    x[1830]   c204_2    1
    x[1830]   c206_2    1
    x[1830]   c205_1    -24
    x[1830]   c250_1    -152
    x[1830]   c559      1
    x[1830]   c562      -1
    x[1831]   c211_1    -152
    x[1831]   c256_1    -24
    x[1831]   c559      1
    x[1831]   c563      -1
    x[1832]   c212_1    -152
    x[1832]   c257_1    -24
    x[1832]   c559      1
    x[1832]   c564      -1
    x[1833]   c213_1    -152
    x[1833]   c258_1    -24
    x[1833]   c559      1
    x[1833]   c565      -1
    x[1834]   c205_2    1
    x[1834]   c214_1    -152
    x[1834]   c259_1    -24
    x[1834]   c559      1
    x[1834]   c566      -1
    x[1835]   c215_1    -152
    x[1835]   c260_1    -24
    x[1835]   c559      1
    x[1835]   c567      -1
    x[1836]   c181_1    -152
    x[1836]   c226_1    -24
    x[1836]   c560      1
    x[1836]   c561      -1
    x[1837]   c183_1    -152
    x[1837]   c228_1    -24
    x[1837]   c560      1
    x[1837]   c562      -1
    x[1838]   c185_1    -152
    x[1838]   c230_1    -24
    x[1838]   c560      1
    x[1838]   c563      -1
    x[1839]   c186_1    -152
    x[1839]   c231_1    -24
    x[1839]   c560      1
    x[1839]   c564      -1
    x[1840]   c187_1    -152
    x[1840]   c232_1    -24
    x[1840]   c560      1
    x[1840]   c565      -1
    x[1841]   c188_1    -152
    x[1841]   c233_1    -24
    x[1841]   c560      1
    x[1841]   c566      -1
    x[1842]   c189_1    -152
    x[1842]   c234_1    -24
    x[1842]   c560      1
    x[1842]   c567      -1
    x[1843]   c181_1    -24
    x[1843]   c226_1    -152
    x[1843]   c560      -1
    x[1843]   c561      1
    x[1844]   c183_1    -24
    x[1844]   c228_1    -152
    x[1844]   c560      -1
    x[1844]   c562      1
    x[1845]   c185_1    -24
    x[1845]   c230_1    -152
    x[1845]   c560      -1
    x[1845]   c563      1
    x[1846]   c186_1    -24
    x[1846]   c231_1    -152
    x[1846]   c560      -1
    x[1846]   c564      1
    x[1847]   c187_1    -24
    x[1847]   c232_1    -152
    x[1847]   c560      -1
    x[1847]   c565      1
    x[1848]   c188_1    -24
    x[1848]   c233_1    -152
    x[1848]   c560      -1
    x[1848]   c566      1
    x[1849]   c189_1    -24
    x[1849]   c234_1    -152
    x[1849]   c560      -1
    x[1849]   c567      1
    x[1850]   c191_1    -152
    x[1850]   c236_1    -24
    x[1850]   c561      1
    x[1850]   c562      -1
    x[1851]   c193_1    -152
    x[1851]   c238_1    -24
    x[1851]   c561      1
    x[1851]   c563      -1
    x[1852]   c194_1    -152
    x[1852]   c239_1    -24
    x[1852]   c561      1
    x[1852]   c564      -1
    x[1853]   c195_1    -152
    x[1853]   c240_1    -24
    x[1853]   c561      1
    x[1853]   c565      -1
    x[1854]   c196_1    -152
    x[1854]   c241_1    -24
    x[1854]   c561      1
    x[1854]   c566      -1
    x[1855]   c197_1    -152
    x[1855]   c242_1    -24
    x[1855]   c561      1
    x[1855]   c567      -1
    x[1856]   c191_1    -24
    x[1856]   c236_1    -152
    x[1856]   c561      -1
    x[1856]   c562      1
    x[1857]   c193_1    -24
    x[1857]   c238_1    -152
    x[1857]   c561      -1
    x[1857]   c563      1
    x[1858]   c194_1    -24
    x[1858]   c239_1    -152
    x[1858]   c561      -1
    x[1858]   c564      1
    x[1859]   c195_1    -24
    x[1859]   c240_1    -152
    x[1859]   c561      -1
    x[1859]   c565      1
    x[1860]   c196_1    -24
    x[1860]   c241_1    -152
    x[1860]   c561      -1
    x[1860]   c566      1
    x[1861]   c197_1    -24
    x[1861]   c242_1    -152
    x[1861]   c561      -1
    x[1861]   c567      1
    x[1862]   c206_1    -152
    x[1862]   c251_1    -24
    x[1862]   c562      1
    x[1862]   c563      -1
    x[1863]   c207_1    -152
    x[1863]   c252_1    -24
    x[1863]   c562      1
    x[1863]   c564      -1
    x[1864]   c208_1    -152
    x[1864]   c253_1    -24
    x[1864]   c562      1
    x[1864]   c565      -1
    x[1865]   c209_1    -152
    x[1865]   c254_1    -24
    x[1865]   c562      1
    x[1865]   c566      -1
    x[1866]   c210_1    -152
    x[1866]   c255_1    -24
    x[1866]   c562      1
    x[1866]   c567      -1
    x[1867]   c206_1    -24
    x[1867]   c251_1    -152
    x[1867]   c562      -1
    x[1867]   c563      1
    x[1868]   c207_1    -24
    x[1868]   c252_1    -152
    x[1868]   c562      -1
    x[1868]   c564      1
    x[1869]   c208_1    -24
    x[1869]   c253_1    -152
    x[1869]   c562      -1
    x[1869]   c565      1
    x[1870]   c209_1    -24
    x[1870]   c254_1    -152
    x[1870]   c562      -1
    x[1870]   c566      1
    x[1871]   c210_1    -24
    x[1871]   c255_1    -152
    x[1871]   c562      -1
    x[1871]   c567      1
    x[1872]   c216_1    -152
    x[1872]   c261_1    -24
    x[1872]   c563      1
    x[1872]   c564      -1
    x[1873]   c217_1    -152
    x[1873]   c262_1    -24
    x[1873]   c563      1
    x[1873]   c565      -1
    x[1874]   c218_1    -152
    x[1874]   c263_1    -24
    x[1874]   c563      1
    x[1874]   c566      -1
    x[1875]   c219_1    -152
    x[1875]   c264_1    -24
    x[1875]   c563      1
    x[1875]   c567      -1
    x[1876]   c216_1    -24
    x[1876]   c261_1    -152
    x[1876]   c563      -1
    x[1876]   c564      1
    x[1877]   c217_1    -24
    x[1877]   c262_1    -152
    x[1877]   c563      -1
    x[1877]   c565      1
    x[1878]   c218_1    -24
    x[1878]   c263_1    -152
    x[1878]   c563      -1
    x[1878]   c566      1
    x[1879]   c219_1    -24
    x[1879]   c264_1    -152
    x[1879]   c563      -1
    x[1879]   c567      1
    x[1880]   c220_1    -152
    x[1880]   c265_1    -24
    x[1880]   c564      1
    x[1880]   c565      -1
    x[1881]   c221_1    -152
    x[1881]   c266_1    -24
    x[1881]   c564      1
    x[1881]   c566      -1
    x[1882]   c222_1    -152
    x[1882]   c267_1    -24
    x[1882]   c564      1
    x[1882]   c567      -1
    x[1883]   c220_1    -24
    x[1883]   c265_1    -152
    x[1883]   c564      -1
    x[1883]   c565      1
    x[1884]   c221_1    -24
    x[1884]   c266_1    -152
    x[1884]   c564      -1
    x[1884]   c566      1
    x[1885]   c222_1    -24
    x[1885]   c267_1    -152
    x[1885]   c564      -1
    x[1885]   c567      1
    x[1886]   c223_1    -152
    x[1886]   c268_1    -24
    x[1886]   c565      1
    x[1886]   c566      -1
    x[1887]   c224_1    -152
    x[1887]   c269_1    -24
    x[1887]   c565      1
    x[1887]   c567      -1
    x[1888]   c223_1    -24
    x[1888]   c268_1    -152
    x[1888]   c565      -1
    x[1888]   c566      1
    x[1889]   c224_1    -24
    x[1889]   c269_1    -152
    x[1889]   c565      -1
    x[1889]   c567      1
    x[1890]   c225_1    -152
    x[1890]   c270_1    -24
    x[1890]   c566      1
    x[1890]   c567      -1
    x[1891]   c225_1    -24
    x[1891]   c270_1    -152
    x[1891]   c566      -1
    x[1891]   c567      1
    x[1892]   c182_1    -37
    x[1892]   c227_1    -33
    x[1892]   c568      1
    x[1893]   c190_1    -37
    x[1893]   c235_1    -33
    x[1893]   c569      1
    x[1894]   c216_1    -37
    x[1894]   c261_1    -33
    x[1894]   c570      1
    x[1895]   c217_1    -37
    x[1895]   c262_1    -33
    x[1895]   c571      1
    x[1896]   c218_1    -37
    x[1896]   c263_1    -33
    x[1896]   c572      1
    x[1897]   c219_1    -37
    x[1897]   c264_1    -33
    x[1897]   c573      1
    x[1898]   c185_1    -33
    x[1898]   c230_1    -37
    x[1898]   c574      1
    x[1899]   c193_1    -33
    x[1899]   c238_1    -37
    x[1899]   c575      1
    x[1900]   c198_1    -33
    x[1900]   c243_1    -37
    x[1900]   c576      1
    x[1901]   c199_1    -33
    x[1901]   c244_1    -37
    x[1901]   c577      1
    x[1902]   c200_1    -33
    x[1902]   c245_1    -37
    x[1902]   c578      1
    x[1903]   c201_1    -33
    x[1903]   c246_1    -37
    x[1903]   c579      1
    x[1904]   c202_1    -33
    x[1904]   c247_1    -37
    x[1904]   c580      1
    x[1905]   c203_1    -33
    x[1905]   c248_1    -37
    x[1905]   c581      1
    x[1906]   c204_1    -33
    x[1906]   c249_1    -37
    x[1906]   c582      1
    x[1907]   c206_1    -33
    x[1907]   c251_1    -37
    x[1907]   c583      1
    x[1908]   c211_1    -33
    x[1908]   c256_1    -37
    x[1908]   c584      1
    x[1909]   c275_1    1
    x[1909]   c198_1    -37
    x[1909]   c243_1    -33
    x[1909]   c585      1
    x[1909]   c589      1
    x[1910]   c276_1    1
    x[1910]   c199_1    -37
    x[1910]   c244_1    -33
    x[1910]   c585      1
    x[1910]   c590      1
    x[1911]   c275_1    1
    x[1911]   c276_1    1
    x[1911]   c277_1    1
    x[1911]   c278_1    1
    x[1911]   c279_1    1
    x[1911]   c200_1    -37
    x[1911]   c245_1    -33
    x[1911]   c585      1
    x[1911]   c586      1
    x[1912]   c201_1    -37
    x[1912]   c246_1    -33
    x[1912]   c585      1
    x[1912]   c591      1
    x[1913]   c277_1    1
    x[1913]   c202_1    -37
    x[1913]   c247_1    -33
    x[1913]   c585      1
    x[1913]   c592      1
    x[1914]   c203_1    -37
    x[1914]   c248_1    -33
    x[1914]   c585      1
    x[1914]   c593      1
    x[1915]   c278_1    1
    x[1915]   c204_1    -37
    x[1915]   c249_1    -33
    x[1915]   c585      1
    x[1915]   c594      1
    x[1916]   c279_1    1
    x[1916]   c182_1    -33
    x[1916]   c227_1    -37
    x[1916]   c585      1
    x[1916]   c587      1
    x[1917]   c190_1    -33
    x[1917]   c235_1    -37
    x[1917]   c585      1
    x[1917]   c588      1
    x[1918]   c301_1    1
    x[1918]   c302_1    1
    x[1918]   c303_1    1
    x[1918]   c185_1    -37
    x[1918]   c230_1    -33
    x[1918]   c586      1
    x[1918]   c587      -1
    x[1919]   c304_1    1
    x[1919]   c193_1    -37
    x[1919]   c238_1    -33
    x[1919]   c586      1
    x[1919]   c588      -1
    x[1920]   c304_1    1
    x[1920]   c206_1    -37
    x[1920]   c251_1    -33
    x[1920]   c586      1
    x[1920]   c589      -1
    x[1921]   c301_1    1
    x[1921]   c211_1    -37
    x[1921]   c256_1    -33
    x[1921]   c586      1
    x[1921]   c590      -1
    x[1922]   c302_1    1
    x[1922]   c216_1    -33
    x[1922]   c261_1    -37
    x[1922]   c586      1
    x[1922]   c591      -1
    x[1923]   c303_1    1
    x[1923]   c217_1    -33
    x[1923]   c262_1    -37
    x[1923]   c586      1
    x[1923]   c592      -1
    x[1924]   c218_1    -33
    x[1924]   c263_1    -37
    x[1924]   c586      1
    x[1924]   c593      -1
    x[1925]   c219_1    -33
    x[1925]   c264_1    -37
    x[1925]   c586      1
    x[1925]   c594      -1
    x[1926]   c181_1    -33
    x[1926]   c226_1    -37
    x[1926]   c587      1
    x[1926]   c588      -1
    x[1927]   c183_1    -33
    x[1927]   c228_1    -37
    x[1927]   c587      1
    x[1927]   c589      -1
    x[1928]   c184_1    -33
    x[1928]   c229_1    -37
    x[1928]   c587      1
    x[1928]   c590      -1
    x[1929]   c186_1    -33
    x[1929]   c231_1    -37
    x[1929]   c587      1
    x[1929]   c591      -1
    x[1930]   c187_1    -33
    x[1930]   c232_1    -37
    x[1930]   c587      1
    x[1930]   c592      -1
    x[1931]   c188_1    -33
    x[1931]   c233_1    -37
    x[1931]   c587      1
    x[1931]   c593      -1
    x[1932]   c189_1    -33
    x[1932]   c234_1    -37
    x[1932]   c587      1
    x[1932]   c594      -1
    x[1933]   c181_1    -37
    x[1933]   c226_1    -33
    x[1933]   c587      -1
    x[1933]   c588      1
    x[1934]   c183_1    -37
    x[1934]   c228_1    -33
    x[1934]   c587      -1
    x[1934]   c589      1
    x[1935]   c184_1    -37
    x[1935]   c229_1    -33
    x[1935]   c587      -1
    x[1935]   c590      1
    x[1936]   c186_1    -37
    x[1936]   c231_1    -33
    x[1936]   c587      -1
    x[1936]   c591      1
    x[1937]   c187_1    -37
    x[1937]   c232_1    -33
    x[1937]   c587      -1
    x[1937]   c592      1
    x[1938]   c188_1    -37
    x[1938]   c233_1    -33
    x[1938]   c587      -1
    x[1938]   c593      1
    x[1939]   c189_1    -37
    x[1939]   c234_1    -33
    x[1939]   c587      -1
    x[1939]   c594      1
    x[1940]   c191_1    -33
    x[1940]   c236_1    -37
    x[1940]   c588      1
    x[1940]   c589      -1
    x[1941]   c192_1    -33
    x[1941]   c237_1    -37
    x[1941]   c588      1
    x[1941]   c590      -1
    x[1942]   c194_1    -33
    x[1942]   c239_1    -37
    x[1942]   c588      1
    x[1942]   c591      -1
    x[1943]   c195_1    -33
    x[1943]   c240_1    -37
    x[1943]   c588      1
    x[1943]   c592      -1
    x[1944]   c196_1    -33
    x[1944]   c241_1    -37
    x[1944]   c588      1
    x[1944]   c593      -1
    x[1945]   c197_1    -33
    x[1945]   c242_1    -37
    x[1945]   c588      1
    x[1945]   c594      -1
    x[1946]   c191_1    -37
    x[1946]   c236_1    -33
    x[1946]   c588      -1
    x[1946]   c589      1
    x[1947]   c192_1    -37
    x[1947]   c237_1    -33
    x[1947]   c588      -1
    x[1947]   c590      1
    x[1948]   c194_1    -37
    x[1948]   c239_1    -33
    x[1948]   c588      -1
    x[1948]   c591      1
    x[1949]   c195_1    -37
    x[1949]   c240_1    -33
    x[1949]   c588      -1
    x[1949]   c592      1
    x[1950]   c196_1    -37
    x[1950]   c241_1    -33
    x[1950]   c588      -1
    x[1950]   c593      1
    x[1951]   c197_1    -37
    x[1951]   c242_1    -33
    x[1951]   c588      -1
    x[1951]   c594      1
    x[1952]   c205_1    -33
    x[1952]   c250_1    -37
    x[1952]   c589      1
    x[1952]   c590      -1
    x[1953]   c207_1    -33
    x[1953]   c252_1    -37
    x[1953]   c589      1
    x[1953]   c591      -1
    x[1954]   c208_1    -33
    x[1954]   c253_1    -37
    x[1954]   c589      1
    x[1954]   c592      -1
    x[1955]   c209_1    -33
    x[1955]   c254_1    -37
    x[1955]   c589      1
    x[1955]   c593      -1
    x[1956]   c210_1    -33
    x[1956]   c255_1    -37
    x[1956]   c589      1
    x[1956]   c594      -1
    x[1957]   c205_1    -37
    x[1957]   c250_1    -33
    x[1957]   c589      -1
    x[1957]   c590      1
    x[1958]   c207_1    -37
    x[1958]   c252_1    -33
    x[1958]   c589      -1
    x[1958]   c591      1
    x[1959]   c208_1    -37
    x[1959]   c253_1    -33
    x[1959]   c589      -1
    x[1959]   c592      1
    x[1960]   c209_1    -37
    x[1960]   c254_1    -33
    x[1960]   c589      -1
    x[1960]   c593      1
    x[1961]   c210_1    -37
    x[1961]   c255_1    -33
    x[1961]   c589      -1
    x[1961]   c594      1
    x[1962]   c212_1    -33
    x[1962]   c257_1    -37
    x[1962]   c590      1
    x[1962]   c591      -1
    x[1963]   c213_1    -33
    x[1963]   c258_1    -37
    x[1963]   c590      1
    x[1963]   c592      -1
    x[1964]   c214_1    -33
    x[1964]   c259_1    -37
    x[1964]   c590      1
    x[1964]   c593      -1
    x[1965]   c215_1    -33
    x[1965]   c260_1    -37
    x[1965]   c590      1
    x[1965]   c594      -1
    x[1966]   c212_1    -37
    x[1966]   c257_1    -33
    x[1966]   c590      -1
    x[1966]   c591      1
    x[1967]   c213_1    -37
    x[1967]   c258_1    -33
    x[1967]   c590      -1
    x[1967]   c592      1
    x[1968]   c214_1    -37
    x[1968]   c259_1    -33
    x[1968]   c590      -1
    x[1968]   c593      1
    x[1969]   c215_1    -37
    x[1969]   c260_1    -33
    x[1969]   c590      -1
    x[1969]   c594      1
    x[1970]   c220_1    -33
    x[1970]   c265_1    -37
    x[1970]   c591      1
    x[1970]   c592      -1
    x[1971]   c221_1    -33
    x[1971]   c266_1    -37
    x[1971]   c591      1
    x[1971]   c593      -1
    x[1972]   c222_1    -33
    x[1972]   c267_1    -37
    x[1972]   c591      1
    x[1972]   c594      -1
    x[1973]   c220_1    -37
    x[1973]   c265_1    -33
    x[1973]   c591      -1
    x[1973]   c592      1
    x[1974]   c221_1    -37
    x[1974]   c266_1    -33
    x[1974]   c591      -1
    x[1974]   c593      1
    x[1975]   c222_1    -37
    x[1975]   c267_1    -33
    x[1975]   c591      -1
    x[1975]   c594      1
    x[1976]   c223_1    -33
    x[1976]   c268_1    -37
    x[1976]   c592      1
    x[1976]   c593      -1
    x[1977]   c224_1    -33
    x[1977]   c269_1    -37
    x[1977]   c592      1
    x[1977]   c594      -1
    x[1978]   c223_1    -37
    x[1978]   c268_1    -33
    x[1978]   c592      -1
    x[1978]   c593      1
    x[1979]   c224_1    -37
    x[1979]   c269_1    -33
    x[1979]   c592      -1
    x[1979]   c594      1
    x[1980]   c225_1    -33
    x[1980]   c270_1    -37
    x[1980]   c593      1
    x[1980]   c594      -1
    x[1981]   c225_1    -37
    x[1981]   c270_1    -33
    x[1981]   c593      -1
    x[1981]   c594      1
    x[1982]   c182_1    -65
    x[1982]   c227_1    -29
    x[1982]   c595      1
    x[1983]   c190_1    -65
    x[1983]   c235_1    -29
    x[1983]   c596      1
    x[1984]   c220_1    -65
    x[1984]   c265_1    -29
    x[1984]   c597      1
    x[1985]   c221_1    -65
    x[1985]   c266_1    -29
    x[1985]   c598      1
    x[1986]   c222_1    -65
    x[1986]   c267_1    -29
    x[1986]   c599      1
    x[1987]   c186_1    -29
    x[1987]   c231_1    -65
    x[1987]   c600      1
    x[1988]   c194_1    -29
    x[1988]   c239_1    -65
    x[1988]   c601      1
    x[1989]   c198_1    -29
    x[1989]   c243_1    -65
    x[1989]   c602      1
    x[1990]   c199_1    -29
    x[1990]   c244_1    -65
    x[1990]   c603      1
    x[1991]   c200_1    -29
    x[1991]   c245_1    -65
    x[1991]   c604      1
    x[1992]   c201_1    -29
    x[1992]   c246_1    -65
    x[1992]   c605      1
    x[1993]   c202_1    -29
    x[1993]   c247_1    -65
    x[1993]   c606      1
    x[1994]   c203_1    -29
    x[1994]   c248_1    -65
    x[1994]   c607      1
    x[1995]   c204_1    -29
    x[1995]   c249_1    -65
    x[1995]   c608      1
    x[1996]   c207_1    -29
    x[1996]   c252_1    -65
    x[1996]   c609      1
    x[1997]   c212_1    -29
    x[1997]   c257_1    -65
    x[1997]   c610      1
    x[1998]   c216_1    -29
    x[1998]   c261_1    -65
    x[1998]   c611      1
    x[1999]   c198_1    -65
    x[1999]   c243_1    -29
    x[1999]   c612      1
    x[1999]   c616      1
    x[2000]   c199_1    -65
    x[2000]   c244_1    -29
    x[2000]   c612      1
    x[2000]   c617      1
    x[2001]   c200_1    -65
    x[2001]   c245_1    -29
    x[2001]   c612      1
    x[2001]   c618      1
    x[2002]   c201_1    -65
    x[2002]   c246_1    -29
    x[2002]   c612      1
    x[2002]   c613      1
    x[2003]   c202_1    -65
    x[2003]   c247_1    -29
    x[2003]   c612      1
    x[2003]   c619      1
    x[2004]   c203_1    -65
    x[2004]   c248_1    -29
    x[2004]   c612      1
    x[2004]   c620      1
    x[2005]   c204_1    -65
    x[2005]   c249_1    -29
    x[2005]   c612      1
    x[2005]   c621      1
    x[2006]   c182_1    -29
    x[2006]   c227_1    -65
    x[2006]   c612      1
    x[2006]   c614      1
    x[2007]   c190_1    -29
    x[2007]   c235_1    -65
    x[2007]   c612      1
    x[2007]   c615      1
    x[2008]   c73_2     1
    x[2008]   c74_2     1
    x[2008]   c75_2     1
    x[2008]   c76_2     1
    x[2008]   c186_1    -65
    x[2008]   c231_1    -29
    x[2008]   c613      1
    x[2008]   c614      -1
    x[2009]   c194_1    -65
    x[2009]   c239_1    -29
    x[2009]   c613      1
    x[2009]   c615      -1
    x[2010]   c73_2     1
    x[2010]   c207_1    -65
    x[2010]   c252_1    -29
    x[2010]   c613      1
    x[2010]   c616      -1
    x[2011]   c212_1    -65
    x[2011]   c257_1    -29
    x[2011]   c613      1
    x[2011]   c617      -1
    x[2012]   c74_2     1
    x[2012]   c216_1    -65
    x[2012]   c261_1    -29
    x[2012]   c613      1
    x[2012]   c618      -1
    x[2013]   c75_2     1
    x[2013]   c220_1    -29
    x[2013]   c265_1    -65
    x[2013]   c613      1
    x[2013]   c619      -1
    x[2014]   c221_1    -29
    x[2014]   c266_1    -65
    x[2014]   c613      1
    x[2014]   c620      -1
    x[2015]   c76_2     1
    x[2015]   c222_1    -29
    x[2015]   c267_1    -65
    x[2015]   c613      1
    x[2015]   c621      -1
    x[2016]   c181_1    -29
    x[2016]   c226_1    -65
    x[2016]   c614      1
    x[2016]   c615      -1
    x[2017]   c183_1    -29
    x[2017]   c228_1    -65
    x[2017]   c614      1
    x[2017]   c616      -1
    x[2018]   c184_1    -29
    x[2018]   c229_1    -65
    x[2018]   c614      1
    x[2018]   c617      -1
    x[2019]   c185_1    -29
    x[2019]   c230_1    -65
    x[2019]   c614      1
    x[2019]   c618      -1
    x[2020]   c187_1    -29
    x[2020]   c232_1    -65
    x[2020]   c614      1
    x[2020]   c619      -1
    x[2021]   c188_1    -29
    x[2021]   c233_1    -65
    x[2021]   c614      1
    x[2021]   c620      -1
    x[2022]   c189_1    -29
    x[2022]   c234_1    -65
    x[2022]   c614      1
    x[2022]   c621      -1
    x[2023]   c181_1    -65
    x[2023]   c226_1    -29
    x[2023]   c614      -1
    x[2023]   c615      1
    x[2024]   c183_1    -65
    x[2024]   c228_1    -29
    x[2024]   c614      -1
    x[2024]   c616      1
    x[2025]   c184_1    -65
    x[2025]   c229_1    -29
    x[2025]   c614      -1
    x[2025]   c617      1
    x[2026]   c185_1    -65
    x[2026]   c230_1    -29
    x[2026]   c614      -1
    x[2026]   c618      1
    x[2027]   c187_1    -65
    x[2027]   c232_1    -29
    x[2027]   c614      -1
    x[2027]   c619      1
    x[2028]   c188_1    -65
    x[2028]   c233_1    -29
    x[2028]   c614      -1
    x[2028]   c620      1
    x[2029]   c189_1    -65
    x[2029]   c234_1    -29
    x[2029]   c614      -1
    x[2029]   c621      1
    x[2030]   c191_1    -29
    x[2030]   c236_1    -65
    x[2030]   c615      1
    x[2030]   c616      -1
    x[2031]   c192_1    -29
    x[2031]   c237_1    -65
    x[2031]   c615      1
    x[2031]   c617      -1
    x[2032]   c193_1    -29
    x[2032]   c238_1    -65
    x[2032]   c615      1
    x[2032]   c618      -1
    x[2033]   c195_1    -29
    x[2033]   c240_1    -65
    x[2033]   c615      1
    x[2033]   c619      -1
    x[2034]   c196_1    -29
    x[2034]   c241_1    -65
    x[2034]   c615      1
    x[2034]   c620      -1
    x[2035]   c197_1    -29
    x[2035]   c242_1    -65
    x[2035]   c615      1
    x[2035]   c621      -1
    x[2036]   c191_1    -65
    x[2036]   c236_1    -29
    x[2036]   c615      -1
    x[2036]   c616      1
    x[2037]   c192_1    -65
    x[2037]   c237_1    -29
    x[2037]   c615      -1
    x[2037]   c617      1
    x[2038]   c193_1    -65
    x[2038]   c238_1    -29
    x[2038]   c615      -1
    x[2038]   c618      1
    x[2039]   c195_1    -65
    x[2039]   c240_1    -29
    x[2039]   c615      -1
    x[2039]   c619      1
    x[2040]   c196_1    -65
    x[2040]   c241_1    -29
    x[2040]   c615      -1
    x[2040]   c620      1
    x[2041]   c197_1    -65
    x[2041]   c242_1    -29
    x[2041]   c615      -1
    x[2041]   c621      1
    x[2042]   c205_1    -29
    x[2042]   c250_1    -65
    x[2042]   c616      1
    x[2042]   c617      -1
    x[2043]   c206_1    -29
    x[2043]   c251_1    -65
    x[2043]   c616      1
    x[2043]   c618      -1
    x[2044]   c208_1    -29
    x[2044]   c253_1    -65
    x[2044]   c616      1
    x[2044]   c619      -1
    x[2045]   c209_1    -29
    x[2045]   c254_1    -65
    x[2045]   c616      1
    x[2045]   c620      -1
    x[2046]   c210_1    -29
    x[2046]   c255_1    -65
    x[2046]   c616      1
    x[2046]   c621      -1
    x[2047]   c205_1    -65
    x[2047]   c250_1    -29
    x[2047]   c616      -1
    x[2047]   c617      1
    x[2048]   c206_1    -65
    x[2048]   c251_1    -29
    x[2048]   c616      -1
    x[2048]   c618      1
    x[2049]   c208_1    -65
    x[2049]   c253_1    -29
    x[2049]   c616      -1
    x[2049]   c619      1
    x[2050]   c209_1    -65
    x[2050]   c254_1    -29
    x[2050]   c616      -1
    x[2050]   c620      1
    x[2051]   c210_1    -65
    x[2051]   c255_1    -29
    x[2051]   c616      -1
    x[2051]   c621      1
    x[2052]   c211_1    -29
    x[2052]   c256_1    -65
    x[2052]   c617      1
    x[2052]   c618      -1
    x[2053]   c213_1    -29
    x[2053]   c258_1    -65
    x[2053]   c617      1
    x[2053]   c619      -1
    x[2054]   c214_1    -29
    x[2054]   c259_1    -65
    x[2054]   c617      1
    x[2054]   c620      -1
    x[2055]   c215_1    -29
    x[2055]   c260_1    -65
    x[2055]   c617      1
    x[2055]   c621      -1
    x[2056]   c211_1    -65
    x[2056]   c256_1    -29
    x[2056]   c617      -1
    x[2056]   c618      1
    x[2057]   c213_1    -65
    x[2057]   c258_1    -29
    x[2057]   c617      -1
    x[2057]   c619      1
    x[2058]   c214_1    -65
    x[2058]   c259_1    -29
    x[2058]   c617      -1
    x[2058]   c620      1
    x[2059]   c215_1    -65
    x[2059]   c260_1    -29
    x[2059]   c617      -1
    x[2059]   c621      1
    x[2060]   c217_1    -29
    x[2060]   c262_1    -65
    x[2060]   c618      1
    x[2060]   c619      -1
    x[2061]   c218_1    -29
    x[2061]   c263_1    -65
    x[2061]   c618      1
    x[2061]   c620      -1
    x[2062]   c219_1    -29
    x[2062]   c264_1    -65
    x[2062]   c618      1
    x[2062]   c621      -1
    x[2063]   c217_1    -65
    x[2063]   c262_1    -29
    x[2063]   c618      -1
    x[2063]   c619      1
    x[2064]   c218_1    -65
    x[2064]   c263_1    -29
    x[2064]   c618      -1
    x[2064]   c620      1
    x[2065]   c219_1    -65
    x[2065]   c264_1    -29
    x[2065]   c618      -1
    x[2065]   c621      1
    x[2066]   c223_1    -29
    x[2066]   c268_1    -65
    x[2066]   c619      1
    x[2066]   c620      -1
    x[2067]   c224_1    -29
    x[2067]   c269_1    -65
    x[2067]   c619      1
    x[2067]   c621      -1
    x[2068]   c223_1    -65
    x[2068]   c268_1    -29
    x[2068]   c619      -1
    x[2068]   c620      1
    x[2069]   c224_1    -65
    x[2069]   c269_1    -29
    x[2069]   c619      -1
    x[2069]   c621      1
    x[2070]   c225_1    -29
    x[2070]   c270_1    -65
    x[2070]   c620      1
    x[2070]   c621      -1
    x[2071]   c225_1    -65
    x[2071]   c270_1    -29
    x[2071]   c620      -1
    x[2071]   c621      1
    x[2072]   c182_1    -176
    x[2072]   c227_1    -164
    x[2072]   c622      1
    x[2073]   c190_1    -176
    x[2073]   c235_1    -164
    x[2073]   c623      1
    x[2074]   c223_1    -176
    x[2074]   c268_1    -164
    x[2074]   c624      1
    x[2075]   c224_1    -176
    x[2075]   c269_1    -164
    x[2075]   c625      1
    x[2076]   c187_1    -164
    x[2076]   c232_1    -176
    x[2076]   c626      1
    x[2077]   c195_1    -164
    x[2077]   c240_1    -176
    x[2077]   c627      1
    x[2078]   c198_1    -164
    x[2078]   c243_1    -176
    x[2078]   c628      1
    x[2079]   c199_1    -164
    x[2079]   c244_1    -176
    x[2079]   c629      1
    x[2080]   c200_1    -164
    x[2080]   c245_1    -176
    x[2080]   c630      1
    x[2081]   c201_1    -164
    x[2081]   c246_1    -176
    x[2081]   c631      1
    x[2082]   c202_1    -164
    x[2082]   c247_1    -176
    x[2082]   c632      1
    x[2083]   c203_1    -164
    x[2083]   c248_1    -176
    x[2083]   c633      1
    x[2084]   c204_1    -164
    x[2084]   c249_1    -176
    x[2084]   c634      1
    x[2085]   c208_1    -164
    x[2085]   c253_1    -176
    x[2085]   c635      1
    x[2086]   c213_1    -164
    x[2086]   c258_1    -176
    x[2086]   c636      1
    x[2087]   c217_1    -164
    x[2087]   c262_1    -176
    x[2087]   c637      1
    x[2088]   c220_1    -164
    x[2088]   c265_1    -176
    x[2088]   c638      1
    x[2089]   c156_2    1
    x[2089]   c161_2    1
    x[2089]   c198_1    -176
    x[2089]   c243_1    -164
    x[2089]   c639      1
    x[2089]   c643      1
    x[2090]   c199_1    -176
    x[2090]   c244_1    -164
    x[2090]   c639      1
    x[2090]   c644      1
    x[2091]   c200_1    -176
    x[2091]   c245_1    -164
    x[2091]   c639      1
    x[2091]   c645      1
    x[2092]   c157_2    1
    x[2092]   c201_1    -176
    x[2092]   c246_1    -164
    x[2092]   c639      1
    x[2092]   c646      1
    x[2093]   c156_2    1
    x[2093]   c157_2    1
    x[2093]   c158_2    1
    x[2093]   c202_1    -176
    x[2093]   c247_1    -164
    x[2093]   c639      1
    x[2093]   c640      1
    x[2094]   c161_2    1
    x[2094]   c203_1    -176
    x[2094]   c248_1    -164
    x[2094]   c639      1
    x[2094]   c647      1
    x[2095]   c158_2    1
    x[2095]   c204_1    -176
    x[2095]   c249_1    -164
    x[2095]   c639      1
    x[2095]   c648      1
    x[2096]   c182_1    -164
    x[2096]   c227_1    -176
    x[2096]   c639      1
    x[2096]   c641      1
    x[2097]   c190_1    -164
    x[2097]   c235_1    -176
    x[2097]   c639      1
    x[2097]   c642      1
    x[2098]   c262_2    1
    x[2098]   c263_2    1
    x[2098]   c264_2    1
    x[2098]   c265_2    1
    x[2098]   c187_1    -176
    x[2098]   c232_1    -164
    x[2098]   c640      1
    x[2098]   c641      -1
    x[2099]   c195_1    -176
    x[2099]   c240_1    -164
    x[2099]   c640      1
    x[2099]   c642      -1
    x[2100]   c208_1    -176
    x[2100]   c253_1    -164
    x[2100]   c640      1
    x[2100]   c643      -1
    x[2101]   c213_1    -176
    x[2101]   c258_1    -164
    x[2101]   c640      1
    x[2101]   c644      -1
    x[2102]   c262_2    1
    x[2102]   c217_1    -176
    x[2102]   c262_1    -164
    x[2102]   c640      1
    x[2102]   c645      -1
    x[2103]   c263_2    1
    x[2103]   c220_1    -176
    x[2103]   c265_1    -164
    x[2103]   c640      1
    x[2103]   c646      -1
    x[2104]   c264_2    1
    x[2104]   c223_1    -164
    x[2104]   c268_1    -176
    x[2104]   c640      1
    x[2104]   c647      -1
    x[2105]   c265_2    1
    x[2105]   c224_1    -164
    x[2105]   c269_1    -176
    x[2105]   c640      1
    x[2105]   c648      -1
    x[2106]   c181_1    -164
    x[2106]   c226_1    -176
    x[2106]   c641      1
    x[2106]   c642      -1
    x[2107]   c183_1    -164
    x[2107]   c228_1    -176
    x[2107]   c641      1
    x[2107]   c643      -1
    x[2108]   c184_1    -164
    x[2108]   c229_1    -176
    x[2108]   c641      1
    x[2108]   c644      -1
    x[2109]   c185_1    -164
    x[2109]   c230_1    -176
    x[2109]   c641      1
    x[2109]   c645      -1
    x[2110]   c186_1    -164
    x[2110]   c231_1    -176
    x[2110]   c641      1
    x[2110]   c646      -1
    x[2111]   c188_1    -164
    x[2111]   c233_1    -176
    x[2111]   c641      1
    x[2111]   c647      -1
    x[2112]   c189_1    -164
    x[2112]   c234_1    -176
    x[2112]   c641      1
    x[2112]   c648      -1
    x[2113]   c181_1    -176
    x[2113]   c226_1    -164
    x[2113]   c641      -1
    x[2113]   c642      1
    x[2114]   c183_1    -176
    x[2114]   c228_1    -164
    x[2114]   c641      -1
    x[2114]   c643      1
    x[2115]   c184_1    -176
    x[2115]   c229_1    -164
    x[2115]   c641      -1
    x[2115]   c644      1
    x[2116]   c185_1    -176
    x[2116]   c230_1    -164
    x[2116]   c641      -1
    x[2116]   c645      1
    x[2117]   c186_1    -176
    x[2117]   c231_1    -164
    x[2117]   c641      -1
    x[2117]   c646      1
    x[2118]   c188_1    -176
    x[2118]   c233_1    -164
    x[2118]   c641      -1
    x[2118]   c647      1
    x[2119]   c189_1    -176
    x[2119]   c234_1    -164
    x[2119]   c641      -1
    x[2119]   c648      1
    x[2120]   c191_1    -164
    x[2120]   c236_1    -176
    x[2120]   c642      1
    x[2120]   c643      -1
    x[2121]   c192_1    -164
    x[2121]   c237_1    -176
    x[2121]   c642      1
    x[2121]   c644      -1
    x[2122]   c193_1    -164
    x[2122]   c238_1    -176
    x[2122]   c642      1
    x[2122]   c645      -1
    x[2123]   c194_1    -164
    x[2123]   c239_1    -176
    x[2123]   c642      1
    x[2123]   c646      -1
    x[2124]   c196_1    -164
    x[2124]   c241_1    -176
    x[2124]   c642      1
    x[2124]   c647      -1
    x[2125]   c197_1    -164
    x[2125]   c242_1    -176
    x[2125]   c642      1
    x[2125]   c648      -1
    x[2126]   c191_1    -176
    x[2126]   c236_1    -164
    x[2126]   c642      -1
    x[2126]   c643      1
    x[2127]   c192_1    -176
    x[2127]   c237_1    -164
    x[2127]   c642      -1
    x[2127]   c644      1
    x[2128]   c193_1    -176
    x[2128]   c238_1    -164
    x[2128]   c642      -1
    x[2128]   c645      1
    x[2129]   c194_1    -176
    x[2129]   c239_1    -164
    x[2129]   c642      -1
    x[2129]   c646      1
    x[2130]   c196_1    -176
    x[2130]   c241_1    -164
    x[2130]   c642      -1
    x[2130]   c647      1
    x[2131]   c197_1    -176
    x[2131]   c242_1    -164
    x[2131]   c642      -1
    x[2131]   c648      1
    x[2132]   c205_1    -164
    x[2132]   c250_1    -176
    x[2132]   c643      1
    x[2132]   c644      -1
    x[2133]   c206_1    -164
    x[2133]   c251_1    -176
    x[2133]   c643      1
    x[2133]   c645      -1
    x[2134]   c207_1    -164
    x[2134]   c252_1    -176
    x[2134]   c643      1
    x[2134]   c646      -1
    x[2135]   c209_1    -164
    x[2135]   c254_1    -176
    x[2135]   c643      1
    x[2135]   c647      -1
    x[2136]   c210_1    -164
    x[2136]   c255_1    -176
    x[2136]   c643      1
    x[2136]   c648      -1
    x[2137]   c205_1    -176
    x[2137]   c250_1    -164
    x[2137]   c643      -1
    x[2137]   c644      1
    x[2138]   c206_1    -176
    x[2138]   c251_1    -164
    x[2138]   c643      -1
    x[2138]   c645      1
    x[2139]   c207_1    -176
    x[2139]   c252_1    -164
    x[2139]   c643      -1
    x[2139]   c646      1
    x[2140]   c209_1    -176
    x[2140]   c254_1    -164
    x[2140]   c643      -1
    x[2140]   c647      1
    x[2141]   c210_1    -176
    x[2141]   c255_1    -164
    x[2141]   c643      -1
    x[2141]   c648      1
    x[2142]   c211_1    -164
    x[2142]   c256_1    -176
    x[2142]   c644      1
    x[2142]   c645      -1
    x[2143]   c212_1    -164
    x[2143]   c257_1    -176
    x[2143]   c644      1
    x[2143]   c646      -1
    x[2144]   c214_1    -164
    x[2144]   c259_1    -176
    x[2144]   c644      1
    x[2144]   c647      -1
    x[2145]   c215_1    -164
    x[2145]   c260_1    -176
    x[2145]   c644      1
    x[2145]   c648      -1
    x[2146]   c211_1    -176
    x[2146]   c256_1    -164
    x[2146]   c644      -1
    x[2146]   c645      1
    x[2147]   c212_1    -176
    x[2147]   c257_1    -164
    x[2147]   c644      -1
    x[2147]   c646      1
    x[2148]   c214_1    -176
    x[2148]   c259_1    -164
    x[2148]   c644      -1
    x[2148]   c647      1
    x[2149]   c215_1    -176
    x[2149]   c260_1    -164
    x[2149]   c644      -1
    x[2149]   c648      1
    x[2150]   c216_1    -164
    x[2150]   c261_1    -176
    x[2150]   c645      1
    x[2150]   c646      -1
    x[2151]   c218_1    -164
    x[2151]   c263_1    -176
    x[2151]   c645      1
    x[2151]   c647      -1
    x[2152]   c219_1    -164
    x[2152]   c264_1    -176
    x[2152]   c645      1
    x[2152]   c648      -1
    x[2153]   c216_1    -176
    x[2153]   c261_1    -164
    x[2153]   c645      -1
    x[2153]   c646      1
    x[2154]   c218_1    -176
    x[2154]   c263_1    -164
    x[2154]   c645      -1
    x[2154]   c647      1
    x[2155]   c219_1    -176
    x[2155]   c264_1    -164
    x[2155]   c645      -1
    x[2155]   c648      1
    x[2156]   c221_1    -164
    x[2156]   c266_1    -176
    x[2156]   c646      1
    x[2156]   c647      -1
    x[2157]   c222_1    -164
    x[2157]   c267_1    -176
    x[2157]   c646      1
    x[2157]   c648      -1
    x[2158]   c221_1    -176
    x[2158]   c266_1    -164
    x[2158]   c646      -1
    x[2158]   c647      1
    x[2159]   c222_1    -176
    x[2159]   c267_1    -164
    x[2159]   c646      -1
    x[2159]   c648      1
    x[2160]   c225_1    -164
    x[2160]   c270_1    -176
    x[2160]   c647      1
    x[2160]   c648      -1
    x[2161]   c225_1    -176
    x[2161]   c270_1    -164
    x[2161]   c647      -1
    x[2161]   c648      1
    x[2162]   c189_1    -44
    x[2162]   c234_1    -198
    x[2162]   c649      1
    x[2163]   c197_1    -44
    x[2163]   c242_1    -198
    x[2163]   c650      1
    x[2164]   c198_1    -44
    x[2164]   c243_1    -198
    x[2164]   c651      1
    x[2165]   c199_1    -44
    x[2165]   c244_1    -198
    x[2165]   c652      1
    x[2166]   c200_1    -44
    x[2166]   c245_1    -198
    x[2166]   c653      1
    x[2167]   c201_1    -44
    x[2167]   c246_1    -198
    x[2167]   c654      1
    x[2168]   c202_1    -44
    x[2168]   c247_1    -198
    x[2168]   c655      1
    x[2169]   c203_1    -44
    x[2169]   c248_1    -198
    x[2169]   c656      1
    x[2170]   c204_1    -44
    x[2170]   c249_1    -198
    x[2170]   c657      1
    x[2171]   c210_1    -44
    x[2171]   c255_1    -198
    x[2171]   c658      1
    x[2172]   c215_1    -44
    x[2172]   c260_1    -198
    x[2172]   c659      1
    x[2173]   c219_1    -44
    x[2173]   c264_1    -198
    x[2173]   c660      1
    x[2174]   c222_1    -44
    x[2174]   c267_1    -198
    x[2174]   c661      1
    x[2175]   c224_1    -44
    x[2175]   c269_1    -198
    x[2175]   c662      1
    x[2176]   c225_1    -44
    x[2176]   c270_1    -198
    x[2176]   c663      1
    x[2177]   c182_1    -198
    x[2177]   c227_1    -44
    x[2177]   c664      1
    x[2178]   c190_1    -198
    x[2178]   c235_1    -44
    x[2178]   c665      1
    x[2179]   c189_1    -198
    x[2179]   c234_1    -44
    x[2179]   c666      1
    x[2179]   c668      1
    x[2180]   c197_1    -198
    x[2180]   c242_1    -44
    x[2180]   c666      1
    x[2180]   c669      1
    x[2181]   c204_1    -198
    x[2181]   c249_1    -44
    x[2181]   c666      1
    x[2181]   c667      1
    x[2182]   c210_1    -198
    x[2182]   c255_1    -44
    x[2182]   c666      1
    x[2182]   c670      1
    x[2183]   c215_1    -198
    x[2183]   c260_1    -44
    x[2183]   c666      1
    x[2183]   c671      1
    x[2184]   c219_1    -198
    x[2184]   c264_1    -44
    x[2184]   c666      1
    x[2184]   c672      1
    x[2185]   c222_1    -198
    x[2185]   c267_1    -44
    x[2185]   c666      1
    x[2185]   c673      1
    x[2186]   c224_1    -198
    x[2186]   c269_1    -44
    x[2186]   c666      1
    x[2186]   c674      1
    x[2187]   c225_1    -198
    x[2187]   c270_1    -44
    x[2187]   c666      1
    x[2187]   c675      1
    x[2188]   c332_1    1
    x[2188]   c333_1    1
    x[2188]   c334_1    1
    x[2188]   c182_1    -44
    x[2188]   c227_1    -198
    x[2188]   c667      1
    x[2188]   c668      -1
    x[2189]   c332_1    1
    x[2189]   c190_1    -44
    x[2189]   c235_1    -198
    x[2189]   c667      1
    x[2189]   c669      -1
    x[2190]   c333_1    1
    x[2190]   c198_1    -198
    x[2190]   c243_1    -44
    x[2190]   c667      1
    x[2190]   c670      -1
    x[2191]   c199_1    -198
    x[2191]   c244_1    -44
    x[2191]   c667      1
    x[2191]   c671      -1
    x[2192]   c200_1    -198
    x[2192]   c245_1    -44
    x[2192]   c667      1
    x[2192]   c672      -1
    x[2193]   c334_1    1
    x[2193]   c201_1    -198
    x[2193]   c246_1    -44
    x[2193]   c667      1
    x[2193]   c673      -1
    x[2194]   c202_1    -198
    x[2194]   c247_1    -44
    x[2194]   c667      1
    x[2194]   c674      -1
    x[2195]   c203_1    -198
    x[2195]   c248_1    -44
    x[2195]   c667      1
    x[2195]   c675      -1
    x[2196]   c181_1    -198
    x[2196]   c226_1    -44
    x[2196]   c668      1
    x[2196]   c669      -1
    x[2197]   c183_1    -198
    x[2197]   c228_1    -44
    x[2197]   c668      1
    x[2197]   c670      -1
    x[2198]   c184_1    -198
    x[2198]   c229_1    -44
    x[2198]   c668      1
    x[2198]   c671      -1
    x[2199]   c185_1    -198
    x[2199]   c230_1    -44
    x[2199]   c668      1
    x[2199]   c672      -1
    x[2200]   c186_1    -198
    x[2200]   c231_1    -44
    x[2200]   c668      1
    x[2200]   c673      -1
    x[2201]   c187_1    -198
    x[2201]   c232_1    -44
    x[2201]   c668      1
    x[2201]   c674      -1
    x[2202]   c188_1    -198
    x[2202]   c233_1    -44
    x[2202]   c668      1
    x[2202]   c675      -1
    x[2203]   c181_1    -44
    x[2203]   c226_1    -198
    x[2203]   c668      -1
    x[2203]   c669      1
    x[2204]   c183_1    -44
    x[2204]   c228_1    -198
    x[2204]   c668      -1
    x[2204]   c670      1
    x[2205]   c184_1    -44
    x[2205]   c229_1    -198
    x[2205]   c668      -1
    x[2205]   c671      1
    x[2206]   c185_1    -44
    x[2206]   c230_1    -198
    x[2206]   c668      -1
    x[2206]   c672      1
    x[2207]   c186_1    -44
    x[2207]   c231_1    -198
    x[2207]   c668      -1
    x[2207]   c673      1
    x[2208]   c187_1    -44
    x[2208]   c232_1    -198
    x[2208]   c668      -1
    x[2208]   c674      1
    x[2209]   c188_1    -44
    x[2209]   c233_1    -198
    x[2209]   c668      -1
    x[2209]   c675      1
    x[2210]   c191_1    -198
    x[2210]   c236_1    -44
    x[2210]   c669      1
    x[2210]   c670      -1
    x[2211]   c192_1    -198
    x[2211]   c237_1    -44
    x[2211]   c669      1
    x[2211]   c671      -1
    x[2212]   c193_1    -198
    x[2212]   c238_1    -44
    x[2212]   c669      1
    x[2212]   c672      -1
    x[2213]   c194_1    -198
    x[2213]   c239_1    -44
    x[2213]   c669      1
    x[2213]   c673      -1
    x[2214]   c195_1    -198
    x[2214]   c240_1    -44
    x[2214]   c669      1
    x[2214]   c674      -1
    x[2215]   c196_1    -198
    x[2215]   c241_1    -44
    x[2215]   c669      1
    x[2215]   c675      -1
    x[2216]   c191_1    -44
    x[2216]   c236_1    -198
    x[2216]   c669      -1
    x[2216]   c670      1
    x[2217]   c192_1    -44
    x[2217]   c237_1    -198
    x[2217]   c669      -1
    x[2217]   c671      1
    x[2218]   c193_1    -44
    x[2218]   c238_1    -198
    x[2218]   c669      -1
    x[2218]   c672      1
    x[2219]   c194_1    -44
    x[2219]   c239_1    -198
    x[2219]   c669      -1
    x[2219]   c673      1
    x[2220]   c195_1    -44
    x[2220]   c240_1    -198
    x[2220]   c669      -1
    x[2220]   c674      1
    x[2221]   c196_1    -44
    x[2221]   c241_1    -198
    x[2221]   c669      -1
    x[2221]   c675      1
    x[2222]   c205_1    -198
    x[2222]   c250_1    -44
    x[2222]   c670      1
    x[2222]   c671      -1
    x[2223]   c206_1    -198
    x[2223]   c251_1    -44
    x[2223]   c670      1
    x[2223]   c672      -1
    x[2224]   c207_1    -198
    x[2224]   c252_1    -44
    x[2224]   c670      1
    x[2224]   c673      -1
    x[2225]   c208_1    -198
    x[2225]   c253_1    -44
    x[2225]   c670      1
    x[2225]   c674      -1
    x[2226]   c209_1    -198
    x[2226]   c254_1    -44
    x[2226]   c670      1
    x[2226]   c675      -1
    x[2227]   c205_1    -44
    x[2227]   c250_1    -198
    x[2227]   c670      -1
    x[2227]   c671      1
    x[2228]   c206_1    -44
    x[2228]   c251_1    -198
    x[2228]   c670      -1
    x[2228]   c672      1
    x[2229]   c207_1    -44
    x[2229]   c252_1    -198
    x[2229]   c670      -1
    x[2229]   c673      1
    x[2230]   c208_1    -44
    x[2230]   c253_1    -198
    x[2230]   c670      -1
    x[2230]   c674      1
    x[2231]   c209_1    -44
    x[2231]   c254_1    -198
    x[2231]   c670      -1
    x[2231]   c675      1
    x[2232]   c211_1    -198
    x[2232]   c256_1    -44
    x[2232]   c671      1
    x[2232]   c672      -1
    x[2233]   c212_1    -198
    x[2233]   c257_1    -44
    x[2233]   c671      1
    x[2233]   c673      -1
    x[2234]   c213_1    -198
    x[2234]   c258_1    -44
    x[2234]   c671      1
    x[2234]   c674      -1
    x[2235]   c214_1    -198
    x[2235]   c259_1    -44
    x[2235]   c671      1
    x[2235]   c675      -1
    x[2236]   c211_1    -44
    x[2236]   c256_1    -198
    x[2236]   c671      -1
    x[2236]   c672      1
    x[2237]   c212_1    -44
    x[2237]   c257_1    -198
    x[2237]   c671      -1
    x[2237]   c673      1
    x[2238]   c213_1    -44
    x[2238]   c258_1    -198
    x[2238]   c671      -1
    x[2238]   c674      1
    x[2239]   c214_1    -44
    x[2239]   c259_1    -198
    x[2239]   c671      -1
    x[2239]   c675      1
    x[2240]   c216_1    -198
    x[2240]   c261_1    -44
    x[2240]   c672      1
    x[2240]   c673      -1
    x[2241]   c217_1    -198
    x[2241]   c262_1    -44
    x[2241]   c672      1
    x[2241]   c674      -1
    x[2242]   c218_1    -198
    x[2242]   c263_1    -44
    x[2242]   c672      1
    x[2242]   c675      -1
    x[2243]   c216_1    -44
    x[2243]   c261_1    -198
    x[2243]   c672      -1
    x[2243]   c673      1
    x[2244]   c217_1    -44
    x[2244]   c262_1    -198
    x[2244]   c672      -1
    x[2244]   c674      1
    x[2245]   c218_1    -44
    x[2245]   c263_1    -198
    x[2245]   c672      -1
    x[2245]   c675      1
    x[2246]   c220_1    -198
    x[2246]   c265_1    -44
    x[2246]   c673      1
    x[2246]   c674      -1
    x[2247]   c221_1    -198
    x[2247]   c266_1    -44
    x[2247]   c673      1
    x[2247]   c675      -1
    x[2248]   c220_1    -44
    x[2248]   c265_1    -198
    x[2248]   c673      -1
    x[2248]   c674      1
    x[2249]   c221_1    -44
    x[2249]   c266_1    -198
    x[2249]   c673      -1
    x[2249]   c675      1
    x[2250]   c223_1    -198
    x[2250]   c268_1    -44
    x[2250]   c674      1
    x[2250]   c675      -1
    x[2251]   c223_1    -44
    x[2251]   c268_1    -198
    x[2251]   c674      -1
    x[2251]   c675      1
    x[2252]   c187_1    -38
    x[2252]   c232_1    -84
    x[2252]   c676      1
    x[2253]   c195_1    -38
    x[2253]   c240_1    -84
    x[2253]   c677      1
    x[2254]   c202_1    -38
    x[2254]   c247_1    -84
    x[2254]   c678      1
    x[2255]   c205_1    -38
    x[2255]   c250_1    -84
    x[2255]   c679      1
    x[2256]   c206_1    -38
    x[2256]   c251_1    -84
    x[2256]   c680      1
    x[2257]   c207_1    -38
    x[2257]   c252_1    -84
    x[2257]   c681      1
    x[2258]   c208_1    -38
    x[2258]   c253_1    -84
    x[2258]   c682      1
    x[2259]   c209_1    -38
    x[2259]   c254_1    -84
    x[2259]   c683      1
    x[2260]   c210_1    -38
    x[2260]   c255_1    -84
    x[2260]   c684      1
    x[2261]   c213_1    -38
    x[2261]   c258_1    -84
    x[2261]   c685      1
    x[2262]   c217_1    -38
    x[2262]   c262_1    -84
    x[2262]   c686      1
    x[2263]   c220_1    -38
    x[2263]   c265_1    -84
    x[2263]   c687      1
    x[2264]   c183_1    -84
    x[2264]   c228_1    -38
    x[2264]   c688      1
    x[2265]   c191_1    -84
    x[2265]   c236_1    -38
    x[2265]   c689      1
    x[2266]   c198_1    -84
    x[2266]   c243_1    -38
    x[2266]   c690      1
    x[2267]   c223_1    -84
    x[2267]   c268_1    -38
    x[2267]   c691      1
    x[2268]   c224_1    -84
    x[2268]   c269_1    -38
    x[2268]   c692      1
    x[2269]   c223_1    -38
    x[2269]   c268_1    -84
    x[2269]   c693      1
    x[2269]   c701      1
    x[2270]   c224_1    -38
    x[2270]   c269_1    -84
    x[2270]   c693      1
    x[2270]   c702      1
    x[2271]   c187_1    -84
    x[2271]   c232_1    -38
    x[2271]   c693      1
    x[2271]   c695      1
    x[2272]   c195_1    -84
    x[2272]   c240_1    -38
    x[2272]   c693      1
    x[2272]   c696      1
    x[2273]   c202_1    -84
    x[2273]   c247_1    -38
    x[2273]   c693      1
    x[2273]   c697      1
    x[2274]   c208_1    -84
    x[2274]   c253_1    -38
    x[2274]   c693      1
    x[2274]   c694      1
    x[2275]   c213_1    -84
    x[2275]   c258_1    -38
    x[2275]   c693      1
    x[2275]   c698      1
    x[2276]   c217_1    -84
    x[2276]   c262_1    -38
    x[2276]   c693      1
    x[2276]   c699      1
    x[2277]   c220_1    -84
    x[2277]   c265_1    -38
    x[2277]   c693      1
    x[2277]   c700      1
    x[2278]   c55_2     1
    x[2278]   c56_2     1
    x[2278]   c57_2     1
    x[2278]   c183_1    -38
    x[2278]   c228_1    -84
    x[2278]   c694      1
    x[2278]   c695      -1
    x[2279]   c55_2     1
    x[2279]   c191_1    -38
    x[2279]   c236_1    -84
    x[2279]   c694      1
    x[2279]   c696      -1
    x[2280]   c198_1    -38
    x[2280]   c243_1    -84
    x[2280]   c694      1
    x[2280]   c697      -1
    x[2281]   c205_1    -84
    x[2281]   c250_1    -38
    x[2281]   c694      1
    x[2281]   c698      -1
    x[2282]   c56_2     1
    x[2282]   c206_1    -84
    x[2282]   c251_1    -38
    x[2282]   c694      1
    x[2282]   c699      -1
    x[2283]   c207_1    -84
    x[2283]   c252_1    -38
    x[2283]   c694      1
    x[2283]   c700      -1
    x[2284]   c209_1    -84
    x[2284]   c254_1    -38
    x[2284]   c694      1
    x[2284]   c701      -1
    x[2285]   c57_2     1
    x[2285]   c210_1    -84
    x[2285]   c255_1    -38
    x[2285]   c694      1
    x[2285]   c702      -1
    x[2286]   c181_1    -84
    x[2286]   c226_1    -38
    x[2286]   c695      1
    x[2286]   c696      -1
    x[2287]   c182_1    -84
    x[2287]   c227_1    -38
    x[2287]   c695      1
    x[2287]   c697      -1
    x[2288]   c184_1    -84
    x[2288]   c229_1    -38
    x[2288]   c695      1
    x[2288]   c698      -1
    x[2289]   c185_1    -84
    x[2289]   c230_1    -38
    x[2289]   c695      1
    x[2289]   c699      -1
    x[2290]   c186_1    -84
    x[2290]   c231_1    -38
    x[2290]   c695      1
    x[2290]   c700      -1
    x[2291]   c188_1    -84
    x[2291]   c233_1    -38
    x[2291]   c695      1
    x[2291]   c701      -1
    x[2292]   c189_1    -84
    x[2292]   c234_1    -38
    x[2292]   c695      1
    x[2292]   c702      -1
    x[2293]   c181_1    -38
    x[2293]   c226_1    -84
    x[2293]   c695      -1
    x[2293]   c696      1
    x[2294]   c182_1    -38
    x[2294]   c227_1    -84
    x[2294]   c695      -1
    x[2294]   c697      1
    x[2295]   c184_1    -38
    x[2295]   c229_1    -84
    x[2295]   c695      -1
    x[2295]   c698      1
    x[2296]   c185_1    -38
    x[2296]   c230_1    -84
    x[2296]   c695      -1
    x[2296]   c699      1
    x[2297]   c186_1    -38
    x[2297]   c231_1    -84
    x[2297]   c695      -1
    x[2297]   c700      1
    x[2298]   c188_1    -38
    x[2298]   c233_1    -84
    x[2298]   c695      -1
    x[2298]   c701      1
    x[2299]   c189_1    -38
    x[2299]   c234_1    -84
    x[2299]   c695      -1
    x[2299]   c702      1
    x[2300]   c190_1    -84
    x[2300]   c235_1    -38
    x[2300]   c696      1
    x[2300]   c697      -1
    x[2301]   c192_1    -84
    x[2301]   c237_1    -38
    x[2301]   c696      1
    x[2301]   c698      -1
    x[2302]   c193_1    -84
    x[2302]   c238_1    -38
    x[2302]   c696      1
    x[2302]   c699      -1
    x[2303]   c194_1    -84
    x[2303]   c239_1    -38
    x[2303]   c696      1
    x[2303]   c700      -1
    x[2304]   c196_1    -84
    x[2304]   c241_1    -38
    x[2304]   c696      1
    x[2304]   c701      -1
    x[2305]   c197_1    -84
    x[2305]   c242_1    -38
    x[2305]   c696      1
    x[2305]   c702      -1
    x[2306]   c190_1    -38
    x[2306]   c235_1    -84
    x[2306]   c696      -1
    x[2306]   c697      1
    x[2307]   c192_1    -38
    x[2307]   c237_1    -84
    x[2307]   c696      -1
    x[2307]   c698      1
    x[2308]   c193_1    -38
    x[2308]   c238_1    -84
    x[2308]   c696      -1
    x[2308]   c699      1
    x[2309]   c194_1    -38
    x[2309]   c239_1    -84
    x[2309]   c696      -1
    x[2309]   c700      1
    x[2310]   c196_1    -38
    x[2310]   c241_1    -84
    x[2310]   c696      -1
    x[2310]   c701      1
    x[2311]   c197_1    -38
    x[2311]   c242_1    -84
    x[2311]   c696      -1
    x[2311]   c702      1
    x[2312]   c199_1    -84
    x[2312]   c244_1    -38
    x[2312]   c697      1
    x[2312]   c698      -1
    x[2313]   c200_1    -84
    x[2313]   c245_1    -38
    x[2313]   c697      1
    x[2313]   c699      -1
    x[2314]   c201_1    -84
    x[2314]   c246_1    -38
    x[2314]   c697      1
    x[2314]   c700      -1
    x[2315]   c203_1    -84
    x[2315]   c248_1    -38
    x[2315]   c697      1
    x[2315]   c701      -1
    x[2316]   c204_1    -84
    x[2316]   c249_1    -38
    x[2316]   c697      1
    x[2316]   c702      -1
    x[2317]   c199_1    -38
    x[2317]   c244_1    -84
    x[2317]   c697      -1
    x[2317]   c698      1
    x[2318]   c200_1    -38
    x[2318]   c245_1    -84
    x[2318]   c697      -1
    x[2318]   c699      1
    x[2319]   c201_1    -38
    x[2319]   c246_1    -84
    x[2319]   c697      -1
    x[2319]   c700      1
    x[2320]   c203_1    -38
    x[2320]   c248_1    -84
    x[2320]   c697      -1
    x[2320]   c701      1
    x[2321]   c204_1    -38
    x[2321]   c249_1    -84
    x[2321]   c697      -1
    x[2321]   c702      1
    x[2322]   c211_1    -84
    x[2322]   c256_1    -38
    x[2322]   c698      1
    x[2322]   c699      -1
    x[2323]   c212_1    -84
    x[2323]   c257_1    -38
    x[2323]   c698      1
    x[2323]   c700      -1
    x[2324]   c214_1    -84
    x[2324]   c259_1    -38
    x[2324]   c698      1
    x[2324]   c701      -1
    x[2325]   c215_1    -84
    x[2325]   c260_1    -38
    x[2325]   c698      1
    x[2325]   c702      -1
    x[2326]   c211_1    -38
    x[2326]   c256_1    -84
    x[2326]   c698      -1
    x[2326]   c699      1
    x[2327]   c212_1    -38
    x[2327]   c257_1    -84
    x[2327]   c698      -1
    x[2327]   c700      1
    x[2328]   c214_1    -38
    x[2328]   c259_1    -84
    x[2328]   c698      -1
    x[2328]   c701      1
    x[2329]   c215_1    -38
    x[2329]   c260_1    -84
    x[2329]   c698      -1
    x[2329]   c702      1
    x[2330]   c216_1    -84
    x[2330]   c261_1    -38
    x[2330]   c699      1
    x[2330]   c700      -1
    x[2331]   c218_1    -84
    x[2331]   c263_1    -38
    x[2331]   c699      1
    x[2331]   c701      -1
    x[2332]   c219_1    -84
    x[2332]   c264_1    -38
    x[2332]   c699      1
    x[2332]   c702      -1
    x[2333]   c216_1    -38
    x[2333]   c261_1    -84
    x[2333]   c699      -1
    x[2333]   c700      1
    x[2334]   c218_1    -38
    x[2334]   c263_1    -84
    x[2334]   c699      -1
    x[2334]   c701      1
    x[2335]   c219_1    -38
    x[2335]   c264_1    -84
    x[2335]   c699      -1
    x[2335]   c702      1
    x[2336]   c221_1    -84
    x[2336]   c266_1    -38
    x[2336]   c700      1
    x[2336]   c701      -1
    x[2337]   c222_1    -84
    x[2337]   c267_1    -38
    x[2337]   c700      1
    x[2337]   c702      -1
    x[2338]   c221_1    -38
    x[2338]   c266_1    -84
    x[2338]   c700      -1
    x[2338]   c701      1
    x[2339]   c222_1    -38
    x[2339]   c267_1    -84
    x[2339]   c700      -1
    x[2339]   c702      1
    x[2340]   c225_1    -84
    x[2340]   c270_1    -38
    x[2340]   c701      1
    x[2340]   c702      -1
    x[2341]   c225_1    -38
    x[2341]   c270_1    -84
    x[2341]   c701      -1
    x[2341]   c702      1
    x[2342]   c189_1    -171
    x[2342]   c703      1
    x[2343]   c197_1    -171
    x[2343]   c704      1
    x[2344]   c204_1    -171
    x[2344]   c705      1
    x[2345]   c210_1    -171
    x[2345]   c706      1
    x[2346]   c215_1    -171
    x[2346]   c707      1
    x[2347]   c219_1    -171
    x[2347]   c708      1
    x[2348]   c220_1    -171
    x[2348]   c709      1
    x[2349]   c221_1    -171
    x[2349]   c710      1
    x[2350]   c222_1    -171
    x[2350]   c711      1
    x[2351]   c224_1    -171
    x[2351]   c712      1
    x[2352]   c225_1    -171
    x[2352]   c713      1
    x[2353]   c231_1    -171
    x[2353]   c714      1
    x[2354]   c239_1    -171
    x[2354]   c715      1
    x[2355]   c246_1    -171
    x[2355]   c716      1
    x[2356]   c252_1    -171
    x[2356]   c717      1
    x[2357]   c257_1    -171
    x[2357]   c718      1
    x[2358]   c261_1    -171
    x[2358]   c719      1
    x[2359]   c234_1    -171
    x[2359]   c720      1
    x[2359]   c722      1
    x[2360]   c108_2    1
    x[2360]   c242_1    -171
    x[2360]   c720      1
    x[2360]   c723      1
    x[2361]   c109_2    1
    x[2361]   c249_1    -171
    x[2361]   c720      1
    x[2361]   c724      1
    x[2362]   c255_1    -171
    x[2362]   c720      1
    x[2362]   c725      1
    x[2363]   c260_1    -171
    x[2363]   c720      1
    x[2363]   c726      1
    x[2364]   c110_2    1
    x[2364]   c264_1    -171
    x[2364]   c720      1
    x[2364]   c727      1
    x[2365]   c108_2    1
    x[2365]   c109_2    1
    x[2365]   c110_2    1
    x[2365]   c111_2    1
    x[2365]   c267_1    -171
    x[2365]   c720      1
    x[2365]   c721      1
    x[2366]   c269_1    -171
    x[2366]   c720      1
    x[2366]   c728      1
    x[2367]   c111_2    1
    x[2367]   c270_1    -171
    x[2367]   c720      1
    x[2367]   c729      1
    x[2368]   c215_2    1
    x[2368]   c216_2    1
    x[2368]   c217_2    1
    x[2368]   c218_2    1
    x[2368]   c186_1    -171
    x[2368]   c721      1
    x[2368]   c722      -1
    x[2369]   c219_2    1
    x[2369]   c194_1    -171
    x[2369]   c721      1
    x[2369]   c723      -1
    x[2370]   c215_2    1
    x[2370]   c219_2    1
    x[2370]   c201_1    -171
    x[2370]   c721      1
    x[2370]   c724      -1
    x[2371]   c216_2    1
    x[2371]   c207_1    -171
    x[2371]   c721      1
    x[2371]   c725      -1
    x[2372]   c212_1    -171
    x[2372]   c721      1
    x[2372]   c726      -1
    x[2373]   c217_2    1
    x[2373]   c216_1    -171
    x[2373]   c721      1
    x[2373]   c727      -1
    x[2374]   c265_1    -171
    x[2374]   c721      1
    x[2374]   c728      -1
    x[2375]   c218_2    1
    x[2375]   c266_1    -171
    x[2375]   c721      1
    x[2375]   c729      -1
    x[2376]   c226_1    -171
    x[2376]   c722      1
    x[2376]   c723      -1
    x[2377]   c227_1    -171
    x[2377]   c722      1
    x[2377]   c724      -1
    x[2378]   c228_1    -171
    x[2378]   c722      1
    x[2378]   c725      -1
    x[2379]   c229_1    -171
    x[2379]   c722      1
    x[2379]   c726      -1
    x[2380]   c230_1    -171
    x[2380]   c722      1
    x[2380]   c727      -1
    x[2381]   c232_1    -171
    x[2381]   c722      1
    x[2381]   c728      -1
    x[2382]   c233_1    -171
    x[2382]   c722      1
    x[2382]   c729      -1
    x[2383]   c181_1    -171
    x[2383]   c722      -1
    x[2383]   c723      1
    x[2384]   c182_1    -171
    x[2384]   c722      -1
    x[2384]   c724      1
    x[2385]   c183_1    -171
    x[2385]   c722      -1
    x[2385]   c725      1
    x[2386]   c184_1    -171
    x[2386]   c722      -1
    x[2386]   c726      1
    x[2387]   c185_1    -171
    x[2387]   c722      -1
    x[2387]   c727      1
    x[2388]   c187_1    -171
    x[2388]   c722      -1
    x[2388]   c728      1
    x[2389]   c188_1    -171
    x[2389]   c722      -1
    x[2389]   c729      1
    x[2390]   c235_1    -171
    x[2390]   c723      1
    x[2390]   c724      -1
    x[2391]   c236_1    -171
    x[2391]   c723      1
    x[2391]   c725      -1
    x[2392]   c237_1    -171
    x[2392]   c723      1
    x[2392]   c726      -1
    x[2393]   c238_1    -171
    x[2393]   c723      1
    x[2393]   c727      -1
    x[2394]   c240_1    -171
    x[2394]   c723      1
    x[2394]   c728      -1
    x[2395]   c241_1    -171
    x[2395]   c723      1
    x[2395]   c729      -1
    x[2396]   c190_1    -171
    x[2396]   c723      -1
    x[2396]   c724      1
    x[2397]   c191_1    -171
    x[2397]   c723      -1
    x[2397]   c725      1
    x[2398]   c192_1    -171
    x[2398]   c723      -1
    x[2398]   c726      1
    x[2399]   c193_1    -171
    x[2399]   c723      -1
    x[2399]   c727      1
    x[2400]   c195_1    -171
    x[2400]   c723      -1
    x[2400]   c728      1
    x[2401]   c196_1    -171
    x[2401]   c723      -1
    x[2401]   c729      1
    x[2402]   c243_1    -171
    x[2402]   c724      1
    x[2402]   c725      -1
    x[2403]   c244_1    -171
    x[2403]   c724      1
    x[2403]   c726      -1
    x[2404]   c245_1    -171
    x[2404]   c724      1
    x[2404]   c727      -1
    x[2405]   c247_1    -171
    x[2405]   c724      1
    x[2405]   c728      -1
    x[2406]   c248_1    -171
    x[2406]   c724      1
    x[2406]   c729      -1
    x[2407]   c198_1    -171
    x[2407]   c724      -1
    x[2407]   c725      1
    x[2408]   c199_1    -171
    x[2408]   c724      -1
    x[2408]   c726      1
    x[2409]   c200_1    -171
    x[2409]   c724      -1
    x[2409]   c727      1
    x[2410]   c202_1    -171
    x[2410]   c724      -1
    x[2410]   c728      1
    x[2411]   c203_1    -171
    x[2411]   c724      -1
    x[2411]   c729      1
    x[2412]   c250_1    -171
    x[2412]   c725      1
    x[2412]   c726      -1
    x[2413]   c251_1    -171
    x[2413]   c725      1
    x[2413]   c727      -1
    x[2414]   c253_1    -171
    x[2414]   c725      1
    x[2414]   c728      -1
    x[2415]   c254_1    -171
    x[2415]   c725      1
    x[2415]   c729      -1
    x[2416]   c205_1    -171
    x[2416]   c725      -1
    x[2416]   c726      1
    x[2417]   c206_1    -171
    x[2417]   c725      -1
    x[2417]   c727      1
    x[2418]   c208_1    -171
    x[2418]   c725      -1
    x[2418]   c728      1
    x[2419]   c209_1    -171
    x[2419]   c725      -1
    x[2419]   c729      1
    x[2420]   c256_1    -171
    x[2420]   c726      1
    x[2420]   c727      -1
    x[2421]   c258_1    -171
    x[2421]   c726      1
    x[2421]   c728      -1
    x[2422]   c259_1    -171
    x[2422]   c726      1
    x[2422]   c729      -1
    x[2423]   c211_1    -171
    x[2423]   c726      -1
    x[2423]   c727      1
    x[2424]   c213_1    -171
    x[2424]   c726      -1
    x[2424]   c728      1
    x[2425]   c214_1    -171
    x[2425]   c726      -1
    x[2425]   c729      1
    x[2426]   c262_1    -171
    x[2426]   c727      1
    x[2426]   c728      -1
    x[2427]   c263_1    -171
    x[2427]   c727      1
    x[2427]   c729      -1
    x[2428]   c217_1    -171
    x[2428]   c727      -1
    x[2428]   c728      1
    x[2429]   c218_1    -171
    x[2429]   c727      -1
    x[2429]   c729      1
    x[2430]   c268_1    -171
    x[2430]   c728      1
    x[2430]   c729      -1
    x[2431]   c223_1    -171
    x[2431]   c728      -1
    x[2431]   c729      1
    x[2432]   c188_1    -108
    x[2432]   c233_1    -34
    x[2432]   c730      1
    x[2433]   c196_1    -108
    x[2433]   c241_1    -34
    x[2433]   c731      1
    x[2434]   c203_1    -108
    x[2434]   c248_1    -34
    x[2434]   c732      1
    x[2435]   c205_1    -108
    x[2435]   c250_1    -34
    x[2435]   c733      1
    x[2436]   c206_1    -108
    x[2436]   c251_1    -34
    x[2436]   c734      1
    x[2437]   c207_1    -108
    x[2437]   c252_1    -34
    x[2437]   c735      1
    x[2438]   c208_1    -108
    x[2438]   c253_1    -34
    x[2438]   c736      1
    x[2439]   c209_1    -108
    x[2439]   c254_1    -34
    x[2439]   c737      1
    x[2440]   c210_1    -108
    x[2440]   c255_1    -34
    x[2440]   c738      1
    x[2441]   c214_1    -108
    x[2441]   c259_1    -34
    x[2441]   c739      1
    x[2442]   c218_1    -108
    x[2442]   c263_1    -34
    x[2442]   c740      1
    x[2443]   c221_1    -108
    x[2443]   c266_1    -34
    x[2443]   c741      1
    x[2444]   c223_1    -108
    x[2444]   c268_1    -34
    x[2444]   c742      1
    x[2445]   c183_1    -34
    x[2445]   c228_1    -108
    x[2445]   c743      1
    x[2446]   c191_1    -34
    x[2446]   c236_1    -108
    x[2446]   c744      1
    x[2447]   c198_1    -34
    x[2447]   c243_1    -108
    x[2447]   c745      1
    x[2448]   c225_1    -34
    x[2448]   c270_1    -108
    x[2448]   c746      1
    x[2449]   c236_2    1
    x[2449]   c225_1    -108
    x[2449]   c270_1    -34
    x[2449]   c747      1
    x[2449]   c756      1
    x[2450]   c226_2    1
    x[2450]   c188_1    -34
    x[2450]   c233_1    -108
    x[2450]   c747      1
    x[2450]   c749      1
    x[2451]   c227_2    1
    x[2451]   c196_1    -34
    x[2451]   c241_1    -108
    x[2451]   c747      1
    x[2451]   c750      1
    x[2452]   c228_2    1
    x[2452]   c203_1    -34
    x[2452]   c248_1    -108
    x[2452]   c747      1
    x[2452]   c751      1
    x[2453]   c226_2    1
    x[2453]   c227_2    1
    x[2453]   c228_2    1
    x[2453]   c229_2    1
    x[2453]   c209_1    -34
    x[2453]   c254_1    -108
    x[2453]   c747      1
    x[2453]   c748      1
    x[2454]   c236_2    1
    x[2454]   c214_1    -34
    x[2454]   c259_1    -108
    x[2454]   c747      1
    x[2454]   c752      1
    x[2455]   c229_2    1
    x[2455]   c218_1    -34
    x[2455]   c263_1    -108
    x[2455]   c747      1
    x[2455]   c753      1
    x[2456]   c221_1    -34
    x[2456]   c266_1    -108
    x[2456]   c747      1
    x[2456]   c754      1
    x[2457]   c223_1    -34
    x[2457]   c268_1    -108
    x[2457]   c747      1
    x[2457]   c755      1
    x[2458]   c305_1    1
    x[2458]   c306_1    1
    x[2458]   c307_1    1
    x[2458]   c308_1    1
    x[2458]   c183_1    -108
    x[2458]   c228_1    -34
    x[2458]   c748      1
    x[2458]   c749      -1
    x[2459]   c309_1    1
    x[2459]   c191_1    -108
    x[2459]   c236_1    -34
    x[2459]   c748      1
    x[2459]   c750      -1
    x[2460]   c305_1    1
    x[2460]   c309_1    1
    x[2460]   c198_1    -108
    x[2460]   c243_1    -34
    x[2460]   c748      1
    x[2460]   c751      -1
    x[2461]   c306_1    1
    x[2461]   c205_1    -34
    x[2461]   c250_1    -108
    x[2461]   c748      1
    x[2461]   c752      -1
    x[2462]   c206_1    -34
    x[2462]   c251_1    -108
    x[2462]   c748      1
    x[2462]   c753      -1
    x[2463]   c307_1    1
    x[2463]   c207_1    -34
    x[2463]   c252_1    -108
    x[2463]   c748      1
    x[2463]   c754      -1
    x[2464]   c308_1    1
    x[2464]   c208_1    -34
    x[2464]   c253_1    -108
    x[2464]   c748      1
    x[2464]   c755      -1
    x[2465]   c210_1    -34
    x[2465]   c255_1    -108
    x[2465]   c748      1
    x[2465]   c756      -1
    x[2466]   c181_1    -34
    x[2466]   c226_1    -108
    x[2466]   c749      1
    x[2466]   c750      -1
    x[2467]   c182_1    -34
    x[2467]   c227_1    -108
    x[2467]   c749      1
    x[2467]   c751      -1
    x[2468]   c184_1    -34
    x[2468]   c229_1    -108
    x[2468]   c749      1
    x[2468]   c752      -1
    x[2469]   c185_1    -34
    x[2469]   c230_1    -108
    x[2469]   c749      1
    x[2469]   c753      -1
    x[2470]   c186_1    -34
    x[2470]   c231_1    -108
    x[2470]   c749      1
    x[2470]   c754      -1
    x[2471]   c187_1    -34
    x[2471]   c232_1    -108
    x[2471]   c749      1
    x[2471]   c755      -1
    x[2472]   c189_1    -34
    x[2472]   c234_1    -108
    x[2472]   c749      1
    x[2472]   c756      -1
    x[2473]   c181_1    -108
    x[2473]   c226_1    -34
    x[2473]   c749      -1
    x[2473]   c750      1
    x[2474]   c182_1    -108
    x[2474]   c227_1    -34
    x[2474]   c749      -1
    x[2474]   c751      1
    x[2475]   c184_1    -108
    x[2475]   c229_1    -34
    x[2475]   c749      -1
    x[2475]   c752      1
    x[2476]   c185_1    -108
    x[2476]   c230_1    -34
    x[2476]   c749      -1
    x[2476]   c753      1
    x[2477]   c186_1    -108
    x[2477]   c231_1    -34
    x[2477]   c749      -1
    x[2477]   c754      1
    x[2478]   c187_1    -108
    x[2478]   c232_1    -34
    x[2478]   c749      -1
    x[2478]   c755      1
    x[2479]   c189_1    -108
    x[2479]   c234_1    -34
    x[2479]   c749      -1
    x[2479]   c756      1
    x[2480]   c190_1    -34
    x[2480]   c235_1    -108
    x[2480]   c750      1
    x[2480]   c751      -1
    x[2481]   c192_1    -34
    x[2481]   c237_1    -108
    x[2481]   c750      1
    x[2481]   c752      -1
    x[2482]   c193_1    -34
    x[2482]   c238_1    -108
    x[2482]   c750      1
    x[2482]   c753      -1
    x[2483]   c194_1    -34
    x[2483]   c239_1    -108
    x[2483]   c750      1
    x[2483]   c754      -1
    x[2484]   c195_1    -34
    x[2484]   c240_1    -108
    x[2484]   c750      1
    x[2484]   c755      -1
    x[2485]   c197_1    -34
    x[2485]   c242_1    -108
    x[2485]   c750      1
    x[2485]   c756      -1
    x[2486]   c190_1    -108
    x[2486]   c235_1    -34
    x[2486]   c750      -1
    x[2486]   c751      1
    x[2487]   c192_1    -108
    x[2487]   c237_1    -34
    x[2487]   c750      -1
    x[2487]   c752      1
    x[2488]   c193_1    -108
    x[2488]   c238_1    -34
    x[2488]   c750      -1
    x[2488]   c753      1
    x[2489]   c194_1    -108
    x[2489]   c239_1    -34
    x[2489]   c750      -1
    x[2489]   c754      1
    x[2490]   c195_1    -108
    x[2490]   c240_1    -34
    x[2490]   c750      -1
    x[2490]   c755      1
    x[2491]   c197_1    -108
    x[2491]   c242_1    -34
    x[2491]   c750      -1
    x[2491]   c756      1
    x[2492]   c199_1    -34
    x[2492]   c244_1    -108
    x[2492]   c751      1
    x[2492]   c752      -1
    x[2493]   c200_1    -34
    x[2493]   c245_1    -108
    x[2493]   c751      1
    x[2493]   c753      -1
    x[2494]   c201_1    -34
    x[2494]   c246_1    -108
    x[2494]   c751      1
    x[2494]   c754      -1
    x[2495]   c202_1    -34
    x[2495]   c247_1    -108
    x[2495]   c751      1
    x[2495]   c755      -1
    x[2496]   c204_1    -34
    x[2496]   c249_1    -108
    x[2496]   c751      1
    x[2496]   c756      -1
    x[2497]   c199_1    -108
    x[2497]   c244_1    -34
    x[2497]   c751      -1
    x[2497]   c752      1
    x[2498]   c200_1    -108
    x[2498]   c245_1    -34
    x[2498]   c751      -1
    x[2498]   c753      1
    x[2499]   c201_1    -108
    x[2499]   c246_1    -34
    x[2499]   c751      -1
    x[2499]   c754      1
    x[2500]   c202_1    -108
    x[2500]   c247_1    -34
    x[2500]   c751      -1
    x[2500]   c755      1
    x[2501]   c204_1    -108
    x[2501]   c249_1    -34
    x[2501]   c751      -1
    x[2501]   c756      1
    x[2502]   c211_1    -34
    x[2502]   c256_1    -108
    x[2502]   c752      1
    x[2502]   c753      -1
    x[2503]   c212_1    -34
    x[2503]   c257_1    -108
    x[2503]   c752      1
    x[2503]   c754      -1
    x[2504]   c213_1    -34
    x[2504]   c258_1    -108
    x[2504]   c752      1
    x[2504]   c755      -1
    x[2505]   c215_1    -34
    x[2505]   c260_1    -108
    x[2505]   c752      1
    x[2505]   c756      -1
    x[2506]   c211_1    -108
    x[2506]   c256_1    -34
    x[2506]   c752      -1
    x[2506]   c753      1
    x[2507]   c212_1    -108
    x[2507]   c257_1    -34
    x[2507]   c752      -1
    x[2507]   c754      1
    x[2508]   c213_1    -108
    x[2508]   c258_1    -34
    x[2508]   c752      -1
    x[2508]   c755      1
    x[2509]   c215_1    -108
    x[2509]   c260_1    -34
    x[2509]   c752      -1
    x[2509]   c756      1
    x[2510]   c216_1    -34
    x[2510]   c261_1    -108
    x[2510]   c753      1
    x[2510]   c754      -1
    x[2511]   c217_1    -34
    x[2511]   c262_1    -108
    x[2511]   c753      1
    x[2511]   c755      -1
    x[2512]   c219_1    -34
    x[2512]   c264_1    -108
    x[2512]   c753      1
    x[2512]   c756      -1
    x[2513]   c216_1    -108
    x[2513]   c261_1    -34
    x[2513]   c753      -1
    x[2513]   c754      1
    x[2514]   c217_1    -108
    x[2514]   c262_1    -34
    x[2514]   c753      -1
    x[2514]   c755      1
    x[2515]   c219_1    -108
    x[2515]   c264_1    -34
    x[2515]   c753      -1
    x[2515]   c756      1
    x[2516]   c220_1    -34
    x[2516]   c265_1    -108
    x[2516]   c754      1
    x[2516]   c755      -1
    x[2517]   c222_1    -34
    x[2517]   c267_1    -108
    x[2517]   c754      1
    x[2517]   c756      -1
    x[2518]   c220_1    -108
    x[2518]   c265_1    -34
    x[2518]   c754      -1
    x[2518]   c755      1
    x[2519]   c222_1    -108
    x[2519]   c267_1    -34
    x[2519]   c754      -1
    x[2519]   c756      1
    x[2520]   c224_1    -34
    x[2520]   c269_1    -108
    x[2520]   c755      1
    x[2520]   c756      -1
    x[2521]   c224_1    -108
    x[2521]   c269_1    -34
    x[2521]   c755      -1
    x[2521]   c756      1
    x[2522]   c183_1    -104
    x[2522]   c228_1    -187
    x[2522]   c757      1
    x[2523]   c191_1    -104
    x[2523]   c236_1    -187
    x[2523]   c758      1
    x[2524]   c198_1    -104
    x[2524]   c243_1    -187
    x[2524]   c759      1
    x[2525]   c211_1    -104
    x[2525]   c256_1    -187
    x[2525]   c760      1
    x[2526]   c212_1    -104
    x[2526]   c257_1    -187
    x[2526]   c761      1
    x[2527]   c213_1    -104
    x[2527]   c258_1    -187
    x[2527]   c762      1
    x[2528]   c214_1    -104
    x[2528]   c259_1    -187
    x[2528]   c763      1
    x[2529]   c215_1    -104
    x[2529]   c260_1    -187
    x[2529]   c764      1
    x[2530]   c184_1    -187
    x[2530]   c229_1    -104
    x[2530]   c765      1
    x[2531]   c192_1    -187
    x[2531]   c237_1    -104
    x[2531]   c766      1
    x[2532]   c199_1    -187
    x[2532]   c244_1    -104
    x[2532]   c767      1
    x[2533]   c205_1    -187
    x[2533]   c250_1    -104
    x[2533]   c768      1
    x[2534]   c206_1    -187
    x[2534]   c251_1    -104
    x[2534]   c769      1
    x[2535]   c207_1    -187
    x[2535]   c252_1    -104
    x[2535]   c770      1
    x[2536]   c208_1    -187
    x[2536]   c253_1    -104
    x[2536]   c771      1
    x[2537]   c209_1    -187
    x[2537]   c254_1    -104
    x[2537]   c772      1
    x[2538]   c210_1    -187
    x[2538]   c255_1    -104
    x[2538]   c773      1
    x[2539]   c9_2      1
    x[2539]   c10_2     1
    x[2539]   c11_2     1
    x[2539]   c205_1    -104
    x[2539]   c250_1    -187
    x[2539]   c774      1
    x[2539]   c775      1
    x[2540]   c9_2      1
    x[2540]   c206_1    -104
    x[2540]   c251_1    -187
    x[2540]   c774      1
    x[2540]   c779      1
    x[2541]   c207_1    -104
    x[2541]   c252_1    -187
    x[2541]   c774      1
    x[2541]   c780      1
    x[2542]   c208_1    -104
    x[2542]   c253_1    -187
    x[2542]   c774      1
    x[2542]   c781      1
    x[2543]   c209_1    -104
    x[2543]   c254_1    -187
    x[2543]   c774      1
    x[2543]   c782      1
    x[2544]   c210_1    -104
    x[2544]   c255_1    -187
    x[2544]   c774      1
    x[2544]   c783      1
    x[2545]   c10_2     1
    x[2545]   c183_1    -187
    x[2545]   c228_1    -104
    x[2545]   c774      1
    x[2545]   c776      1
    x[2546]   c191_1    -187
    x[2546]   c236_1    -104
    x[2546]   c774      1
    x[2546]   c777      1
    x[2547]   c11_2     1
    x[2547]   c198_1    -187
    x[2547]   c243_1    -104
    x[2547]   c774      1
    x[2547]   c778      1
    x[2548]   c77_2     1
    x[2548]   c78_2     1
    x[2548]   c79_2     1
    x[2548]   c80_2     1
    x[2548]   c184_1    -104
    x[2548]   c229_1    -187
    x[2548]   c775      1
    x[2548]   c776      -1
    x[2549]   c192_1    -104
    x[2549]   c237_1    -187
    x[2549]   c775      1
    x[2549]   c777      -1
    x[2550]   c77_2     1
    x[2550]   c199_1    -104
    x[2550]   c244_1    -187
    x[2550]   c775      1
    x[2550]   c778      -1
    x[2551]   c78_2     1
    x[2551]   c211_1    -187
    x[2551]   c256_1    -104
    x[2551]   c775      1
    x[2551]   c779      -1
    x[2552]   c212_1    -187
    x[2552]   c257_1    -104
    x[2552]   c775      1
    x[2552]   c780      -1
    x[2553]   c79_2     1
    x[2553]   c213_1    -187
    x[2553]   c258_1    -104
    x[2553]   c775      1
    x[2553]   c781      -1
    x[2554]   c214_1    -187
    x[2554]   c259_1    -104
    x[2554]   c775      1
    x[2554]   c782      -1
    x[2555]   c80_2     1
    x[2555]   c215_1    -187
    x[2555]   c260_1    -104
    x[2555]   c775      1
    x[2555]   c783      -1
    x[2556]   c181_1    -187
    x[2556]   c226_1    -104
    x[2556]   c776      1
    x[2556]   c777      -1
    x[2557]   c182_1    -187
    x[2557]   c227_1    -104
    x[2557]   c776      1
    x[2557]   c778      -1
    x[2558]   c185_1    -187
    x[2558]   c230_1    -104
    x[2558]   c776      1
    x[2558]   c779      -1
    x[2559]   c186_1    -187
    x[2559]   c231_1    -104
    x[2559]   c776      1
    x[2559]   c780      -1
    x[2560]   c187_1    -187
    x[2560]   c232_1    -104
    x[2560]   c776      1
    x[2560]   c781      -1
    x[2561]   c188_1    -187
    x[2561]   c233_1    -104
    x[2561]   c776      1
    x[2561]   c782      -1
    x[2562]   c189_1    -187
    x[2562]   c234_1    -104
    x[2562]   c776      1
    x[2562]   c783      -1
    x[2563]   c181_1    -104
    x[2563]   c226_1    -187
    x[2563]   c776      -1
    x[2563]   c777      1
    x[2564]   c182_1    -104
    x[2564]   c227_1    -187
    x[2564]   c776      -1
    x[2564]   c778      1
    x[2565]   c185_1    -104
    x[2565]   c230_1    -187
    x[2565]   c776      -1
    x[2565]   c779      1
    x[2566]   c186_1    -104
    x[2566]   c231_1    -187
    x[2566]   c776      -1
    x[2566]   c780      1
    x[2567]   c187_1    -104
    x[2567]   c232_1    -187
    x[2567]   c776      -1
    x[2567]   c781      1
    x[2568]   c188_1    -104
    x[2568]   c233_1    -187
    x[2568]   c776      -1
    x[2568]   c782      1
    x[2569]   c189_1    -104
    x[2569]   c234_1    -187
    x[2569]   c776      -1
    x[2569]   c783      1
    x[2570]   c190_1    -187
    x[2570]   c235_1    -104
    x[2570]   c777      1
    x[2570]   c778      -1
    x[2571]   c193_1    -187
    x[2571]   c238_1    -104
    x[2571]   c777      1
    x[2571]   c779      -1
    x[2572]   c194_1    -187
    x[2572]   c239_1    -104
    x[2572]   c777      1
    x[2572]   c780      -1
    x[2573]   c195_1    -187
    x[2573]   c240_1    -104
    x[2573]   c777      1
    x[2573]   c781      -1
    x[2574]   c196_1    -187
    x[2574]   c241_1    -104
    x[2574]   c777      1
    x[2574]   c782      -1
    x[2575]   c197_1    -187
    x[2575]   c242_1    -104
    x[2575]   c777      1
    x[2575]   c783      -1
    x[2576]   c190_1    -104
    x[2576]   c235_1    -187
    x[2576]   c777      -1
    x[2576]   c778      1
    x[2577]   c193_1    -104
    x[2577]   c238_1    -187
    x[2577]   c777      -1
    x[2577]   c779      1
    x[2578]   c194_1    -104
    x[2578]   c239_1    -187
    x[2578]   c777      -1
    x[2578]   c780      1
    x[2579]   c195_1    -104
    x[2579]   c240_1    -187
    x[2579]   c777      -1
    x[2579]   c781      1
    x[2580]   c196_1    -104
    x[2580]   c241_1    -187
    x[2580]   c777      -1
    x[2580]   c782      1
    x[2581]   c197_1    -104
    x[2581]   c242_1    -187
    x[2581]   c777      -1
    x[2581]   c783      1
    x[2582]   c200_1    -187
    x[2582]   c245_1    -104
    x[2582]   c778      1
    x[2582]   c779      -1
    x[2583]   c201_1    -187
    x[2583]   c246_1    -104
    x[2583]   c778      1
    x[2583]   c780      -1
    x[2584]   c202_1    -187
    x[2584]   c247_1    -104
    x[2584]   c778      1
    x[2584]   c781      -1
    x[2585]   c203_1    -187
    x[2585]   c248_1    -104
    x[2585]   c778      1
    x[2585]   c782      -1
    x[2586]   c204_1    -187
    x[2586]   c249_1    -104
    x[2586]   c778      1
    x[2586]   c783      -1
    x[2587]   c200_1    -104
    x[2587]   c245_1    -187
    x[2587]   c778      -1
    x[2587]   c779      1
    x[2588]   c201_1    -104
    x[2588]   c246_1    -187
    x[2588]   c778      -1
    x[2588]   c780      1
    x[2589]   c202_1    -104
    x[2589]   c247_1    -187
    x[2589]   c778      -1
    x[2589]   c781      1
    x[2590]   c203_1    -104
    x[2590]   c248_1    -187
    x[2590]   c778      -1
    x[2590]   c782      1
    x[2591]   c204_1    -104
    x[2591]   c249_1    -187
    x[2591]   c778      -1
    x[2591]   c783      1
    x[2592]   c216_1    -187
    x[2592]   c261_1    -104
    x[2592]   c779      1
    x[2592]   c780      -1
    x[2593]   c217_1    -187
    x[2593]   c262_1    -104
    x[2593]   c779      1
    x[2593]   c781      -1
    x[2594]   c218_1    -187
    x[2594]   c263_1    -104
    x[2594]   c779      1
    x[2594]   c782      -1
    x[2595]   c219_1    -187
    x[2595]   c264_1    -104
    x[2595]   c779      1
    x[2595]   c783      -1
    x[2596]   c216_1    -104
    x[2596]   c261_1    -187
    x[2596]   c779      -1
    x[2596]   c780      1
    x[2597]   c217_1    -104
    x[2597]   c262_1    -187
    x[2597]   c779      -1
    x[2597]   c781      1
    x[2598]   c218_1    -104
    x[2598]   c263_1    -187
    x[2598]   c779      -1
    x[2598]   c782      1
    x[2599]   c219_1    -104
    x[2599]   c264_1    -187
    x[2599]   c779      -1
    x[2599]   c783      1
    x[2600]   c220_1    -187
    x[2600]   c265_1    -104
    x[2600]   c780      1
    x[2600]   c781      -1
    x[2601]   c221_1    -187
    x[2601]   c266_1    -104
    x[2601]   c780      1
    x[2601]   c782      -1
    x[2602]   c222_1    -187
    x[2602]   c267_1    -104
    x[2602]   c780      1
    x[2602]   c783      -1
    x[2603]   c220_1    -104
    x[2603]   c265_1    -187
    x[2603]   c780      -1
    x[2603]   c781      1
    x[2604]   c221_1    -104
    x[2604]   c266_1    -187
    x[2604]   c780      -1
    x[2604]   c782      1
    x[2605]   c222_1    -104
    x[2605]   c267_1    -187
    x[2605]   c780      -1
    x[2605]   c783      1
    x[2606]   c223_1    -187
    x[2606]   c268_1    -104
    x[2606]   c781      1
    x[2606]   c782      -1
    x[2607]   c224_1    -187
    x[2607]   c269_1    -104
    x[2607]   c781      1
    x[2607]   c783      -1
    x[2608]   c223_1    -104
    x[2608]   c268_1    -187
    x[2608]   c781      -1
    x[2608]   c782      1
    x[2609]   c224_1    -104
    x[2609]   c269_1    -187
    x[2609]   c781      -1
    x[2609]   c783      1
    x[2610]   c225_1    -187
    x[2610]   c270_1    -104
    x[2610]   c782      1
    x[2610]   c783      -1
    x[2611]   c225_1    -104
    x[2611]   c270_1    -187
    x[2611]   c782      -1
    x[2611]   c783      1
    x[2612]   c183_1    -43
    x[2612]   c228_1    -176
    x[2612]   c784      1
    x[2613]   c191_1    -43
    x[2613]   c236_1    -176
    x[2613]   c785      1
    x[2614]   c198_1    -43
    x[2614]   c243_1    -176
    x[2614]   c786      1
    x[2615]   c216_1    -43
    x[2615]   c261_1    -176
    x[2615]   c787      1
    x[2616]   c217_1    -43
    x[2616]   c262_1    -176
    x[2616]   c788      1
    x[2617]   c218_1    -43
    x[2617]   c263_1    -176
    x[2617]   c789      1
    x[2618]   c219_1    -43
    x[2618]   c264_1    -176
    x[2618]   c790      1
    x[2619]   c185_1    -176
    x[2619]   c230_1    -43
    x[2619]   c791      1
    x[2620]   c193_1    -176
    x[2620]   c238_1    -43
    x[2620]   c792      1
    x[2621]   c200_1    -176
    x[2621]   c245_1    -43
    x[2621]   c793      1
    x[2622]   c205_1    -176
    x[2622]   c250_1    -43
    x[2622]   c794      1
    x[2623]   c206_1    -176
    x[2623]   c251_1    -43
    x[2623]   c795      1
    x[2624]   c207_1    -176
    x[2624]   c252_1    -43
    x[2624]   c796      1
    x[2625]   c208_1    -176
    x[2625]   c253_1    -43
    x[2625]   c797      1
    x[2626]   c209_1    -176
    x[2626]   c254_1    -43
    x[2626]   c798      1
    x[2627]   c210_1    -176
    x[2627]   c255_1    -43
    x[2627]   c799      1
    x[2628]   c211_1    -176
    x[2628]   c256_1    -43
    x[2628]   c800      1
    x[2629]   c205_1    -43
    x[2629]   c250_1    -176
    x[2629]   c801      1
    x[2629]   c806      1
    x[2630]   c95_2     1
    x[2630]   c206_1    -43
    x[2630]   c251_1    -176
    x[2630]   c801      1
    x[2630]   c802      1
    x[2631]   c207_1    -43
    x[2631]   c252_1    -176
    x[2631]   c801      1
    x[2631]   c807      1
    x[2632]   c208_1    -43
    x[2632]   c253_1    -176
    x[2632]   c801      1
    x[2632]   c808      1
    x[2633]   c209_1    -43
    x[2633]   c254_1    -176
    x[2633]   c801      1
    x[2633]   c809      1
    x[2634]   c210_1    -43
    x[2634]   c255_1    -176
    x[2634]   c801      1
    x[2634]   c810      1
    x[2635]   c95_2     1
    x[2635]   c183_1    -176
    x[2635]   c228_1    -43
    x[2635]   c801      1
    x[2635]   c803      1
    x[2636]   c191_1    -176
    x[2636]   c236_1    -43
    x[2636]   c801      1
    x[2636]   c804      1
    x[2637]   c198_1    -176
    x[2637]   c243_1    -43
    x[2637]   c801      1
    x[2637]   c805      1
    x[2638]   c192_2    1
    x[2638]   c185_1    -43
    x[2638]   c230_1    -176
    x[2638]   c802      1
    x[2638]   c803      -1
    x[2639]   c192_2    1
    x[2639]   c193_1    -43
    x[2639]   c238_1    -176
    x[2639]   c802      1
    x[2639]   c804      -1
    x[2640]   c200_1    -43
    x[2640]   c245_1    -176
    x[2640]   c802      1
    x[2640]   c805      -1
    x[2641]   c211_1    -43
    x[2641]   c256_1    -176
    x[2641]   c802      1
    x[2641]   c806      -1
    x[2642]   c216_1    -176
    x[2642]   c261_1    -43
    x[2642]   c802      1
    x[2642]   c807      -1
    x[2643]   c217_1    -176
    x[2643]   c262_1    -43
    x[2643]   c802      1
    x[2643]   c808      -1
    x[2644]   c218_1    -176
    x[2644]   c263_1    -43
    x[2644]   c802      1
    x[2644]   c809      -1
    x[2645]   c219_1    -176
    x[2645]   c264_1    -43
    x[2645]   c802      1
    x[2645]   c810      -1
    x[2646]   c181_1    -176
    x[2646]   c226_1    -43
    x[2646]   c803      1
    x[2646]   c804      -1
    x[2647]   c182_1    -176
    x[2647]   c227_1    -43
    x[2647]   c803      1
    x[2647]   c805      -1
    x[2648]   c184_1    -176
    x[2648]   c229_1    -43
    x[2648]   c803      1
    x[2648]   c806      -1
    x[2649]   c186_1    -176
    x[2649]   c231_1    -43
    x[2649]   c803      1
    x[2649]   c807      -1
    x[2650]   c187_1    -176
    x[2650]   c232_1    -43
    x[2650]   c803      1
    x[2650]   c808      -1
    x[2651]   c188_1    -176
    x[2651]   c233_1    -43
    x[2651]   c803      1
    x[2651]   c809      -1
    x[2652]   c189_1    -176
    x[2652]   c234_1    -43
    x[2652]   c803      1
    x[2652]   c810      -1
    x[2653]   c181_1    -43
    x[2653]   c226_1    -176
    x[2653]   c803      -1
    x[2653]   c804      1
    x[2654]   c182_1    -43
    x[2654]   c227_1    -176
    x[2654]   c803      -1
    x[2654]   c805      1
    x[2655]   c184_1    -43
    x[2655]   c229_1    -176
    x[2655]   c803      -1
    x[2655]   c806      1
    x[2656]   c186_1    -43
    x[2656]   c231_1    -176
    x[2656]   c803      -1
    x[2656]   c807      1
    x[2657]   c187_1    -43
    x[2657]   c232_1    -176
    x[2657]   c803      -1
    x[2657]   c808      1
    x[2658]   c188_1    -43
    x[2658]   c233_1    -176
    x[2658]   c803      -1
    x[2658]   c809      1
    x[2659]   c189_1    -43
    x[2659]   c234_1    -176
    x[2659]   c803      -1
    x[2659]   c810      1
    x[2660]   c190_1    -176
    x[2660]   c235_1    -43
    x[2660]   c804      1
    x[2660]   c805      -1
    x[2661]   c192_1    -176
    x[2661]   c237_1    -43
    x[2661]   c804      1
    x[2661]   c806      -1
    x[2662]   c194_1    -176
    x[2662]   c239_1    -43
    x[2662]   c804      1
    x[2662]   c807      -1
    x[2663]   c195_1    -176
    x[2663]   c240_1    -43
    x[2663]   c804      1
    x[2663]   c808      -1
    x[2664]   c196_1    -176
    x[2664]   c241_1    -43
    x[2664]   c804      1
    x[2664]   c809      -1
    x[2665]   c197_1    -176
    x[2665]   c242_1    -43
    x[2665]   c804      1
    x[2665]   c810      -1
    x[2666]   c190_1    -43
    x[2666]   c235_1    -176
    x[2666]   c804      -1
    x[2666]   c805      1
    x[2667]   c192_1    -43
    x[2667]   c237_1    -176
    x[2667]   c804      -1
    x[2667]   c806      1
    x[2668]   c194_1    -43
    x[2668]   c239_1    -176
    x[2668]   c804      -1
    x[2668]   c807      1
    x[2669]   c195_1    -43
    x[2669]   c240_1    -176
    x[2669]   c804      -1
    x[2669]   c808      1
    x[2670]   c196_1    -43
    x[2670]   c241_1    -176
    x[2670]   c804      -1
    x[2670]   c809      1
    x[2671]   c197_1    -43
    x[2671]   c242_1    -176
    x[2671]   c804      -1
    x[2671]   c810      1
    x[2672]   c199_1    -176
    x[2672]   c244_1    -43
    x[2672]   c805      1
    x[2672]   c806      -1
    x[2673]   c201_1    -176
    x[2673]   c246_1    -43
    x[2673]   c805      1
    x[2673]   c807      -1
    x[2674]   c202_1    -176
    x[2674]   c247_1    -43
    x[2674]   c805      1
    x[2674]   c808      -1
    x[2675]   c203_1    -176
    x[2675]   c248_1    -43
    x[2675]   c805      1
    x[2675]   c809      -1
    x[2676]   c204_1    -176
    x[2676]   c249_1    -43
    x[2676]   c805      1
    x[2676]   c810      -1
    x[2677]   c199_1    -43
    x[2677]   c244_1    -176
    x[2677]   c805      -1
    x[2677]   c806      1
    x[2678]   c201_1    -43
    x[2678]   c246_1    -176
    x[2678]   c805      -1
    x[2678]   c807      1
    x[2679]   c202_1    -43
    x[2679]   c247_1    -176
    x[2679]   c805      -1
    x[2679]   c808      1
    x[2680]   c203_1    -43
    x[2680]   c248_1    -176
    x[2680]   c805      -1
    x[2680]   c809      1
    x[2681]   c204_1    -43
    x[2681]   c249_1    -176
    x[2681]   c805      -1
    x[2681]   c810      1
    x[2682]   c212_1    -176
    x[2682]   c257_1    -43
    x[2682]   c806      1
    x[2682]   c807      -1
    x[2683]   c213_1    -176
    x[2683]   c258_1    -43
    x[2683]   c806      1
    x[2683]   c808      -1
    x[2684]   c214_1    -176
    x[2684]   c259_1    -43
    x[2684]   c806      1
    x[2684]   c809      -1
    x[2685]   c215_1    -176
    x[2685]   c260_1    -43
    x[2685]   c806      1
    x[2685]   c810      -1
    x[2686]   c212_1    -43
    x[2686]   c257_1    -176
    x[2686]   c806      -1
    x[2686]   c807      1
    x[2687]   c213_1    -43
    x[2687]   c258_1    -176
    x[2687]   c806      -1
    x[2687]   c808      1
    x[2688]   c214_1    -43
    x[2688]   c259_1    -176
    x[2688]   c806      -1
    x[2688]   c809      1
    x[2689]   c215_1    -43
    x[2689]   c260_1    -176
    x[2689]   c806      -1
    x[2689]   c810      1
    x[2690]   c220_1    -176
    x[2690]   c265_1    -43
    x[2690]   c807      1
    x[2690]   c808      -1
    x[2691]   c221_1    -176
    x[2691]   c266_1    -43
    x[2691]   c807      1
    x[2691]   c809      -1
    x[2692]   c222_1    -176
    x[2692]   c267_1    -43
    x[2692]   c807      1
    x[2692]   c810      -1
    x[2693]   c220_1    -43
    x[2693]   c265_1    -176
    x[2693]   c807      -1
    x[2693]   c808      1
    x[2694]   c221_1    -43
    x[2694]   c266_1    -176
    x[2694]   c807      -1
    x[2694]   c809      1
    x[2695]   c222_1    -43
    x[2695]   c267_1    -176
    x[2695]   c807      -1
    x[2695]   c810      1
    x[2696]   c223_1    -176
    x[2696]   c268_1    -43
    x[2696]   c808      1
    x[2696]   c809      -1
    x[2697]   c224_1    -176
    x[2697]   c269_1    -43
    x[2697]   c808      1
    x[2697]   c810      -1
    x[2698]   c223_1    -43
    x[2698]   c268_1    -176
    x[2698]   c808      -1
    x[2698]   c809      1
    x[2699]   c224_1    -43
    x[2699]   c269_1    -176
    x[2699]   c808      -1
    x[2699]   c810      1
    x[2700]   c225_1    -176
    x[2700]   c270_1    -43
    x[2700]   c809      1
    x[2700]   c810      -1
    x[2701]   c225_1    -43
    x[2701]   c270_1    -176
    x[2701]   c809      -1
    x[2701]   c810      1
    x[2702]   c183_1    -68
    x[2702]   c228_1    -181
    x[2702]   c811      1
    x[2703]   c191_1    -68
    x[2703]   c236_1    -181
    x[2703]   c812      1
    x[2704]   c198_1    -68
    x[2704]   c243_1    -181
    x[2704]   c813      1
    x[2705]   c220_1    -68
    x[2705]   c265_1    -181
    x[2705]   c814      1
    x[2706]   c221_1    -68
    x[2706]   c266_1    -181
    x[2706]   c815      1
    x[2707]   c222_1    -68
    x[2707]   c267_1    -181
    x[2707]   c816      1
    x[2708]   c186_1    -181
    x[2708]   c231_1    -68
    x[2708]   c817      1
    x[2709]   c194_1    -181
    x[2709]   c239_1    -68
    x[2709]   c818      1
    x[2710]   c201_1    -181
    x[2710]   c246_1    -68
    x[2710]   c819      1
    x[2711]   c205_1    -181
    x[2711]   c250_1    -68
    x[2711]   c820      1
    x[2712]   c206_1    -181
    x[2712]   c251_1    -68
    x[2712]   c821      1
    x[2713]   c207_1    -181
    x[2713]   c252_1    -68
    x[2713]   c822      1
    x[2714]   c208_1    -181
    x[2714]   c253_1    -68
    x[2714]   c823      1
    x[2715]   c209_1    -181
    x[2715]   c254_1    -68
    x[2715]   c824      1
    x[2716]   c210_1    -181
    x[2716]   c255_1    -68
    x[2716]   c825      1
    x[2717]   c212_1    -181
    x[2717]   c257_1    -68
    x[2717]   c826      1
    x[2718]   c216_1    -181
    x[2718]   c261_1    -68
    x[2718]   c827      1
    x[2719]   c251_2    1
    x[2719]   c205_1    -68
    x[2719]   c250_1    -181
    x[2719]   c828      1
    x[2719]   c833      1
    x[2720]   c252_2    1
    x[2720]   c206_1    -68
    x[2720]   c251_1    -181
    x[2720]   c828      1
    x[2720]   c834      1
    x[2721]   c251_2    1
    x[2721]   c252_2    1
    x[2721]   c253_2    1
    x[2721]   c254_2    1
    x[2721]   c255_2    1
    x[2721]   c207_1    -68
    x[2721]   c252_1    -181
    x[2721]   c828      1
    x[2721]   c829      1
    x[2722]   c208_1    -68
    x[2722]   c253_1    -181
    x[2722]   c828      1
    x[2722]   c835      1
    x[2723]   c253_2    1
    x[2723]   c209_1    -68
    x[2723]   c254_1    -181
    x[2723]   c828      1
    x[2723]   c836      1
    x[2724]   c254_2    1
    x[2724]   c210_1    -68
    x[2724]   c255_1    -181
    x[2724]   c828      1
    x[2724]   c837      1
    x[2725]   c183_1    -181
    x[2725]   c228_1    -68
    x[2725]   c828      1
    x[2725]   c830      1
    x[2726]   c191_1    -181
    x[2726]   c236_1    -68
    x[2726]   c828      1
    x[2726]   c831      1
    x[2727]   c255_2    1
    x[2727]   c198_1    -181
    x[2727]   c243_1    -68
    x[2727]   c828      1
    x[2727]   c832      1
    x[2728]   c186_1    -68
    x[2728]   c231_1    -181
    x[2728]   c829      1
    x[2728]   c830      -1
    x[2729]   c194_1    -68
    x[2729]   c239_1    -181
    x[2729]   c829      1
    x[2729]   c831      -1
    x[2730]   c201_1    -68
    x[2730]   c246_1    -181
    x[2730]   c829      1
    x[2730]   c832      -1
    x[2731]   c212_1    -68
    x[2731]   c257_1    -181
    x[2731]   c829      1
    x[2731]   c833      -1
    x[2732]   c216_1    -68
    x[2732]   c261_1    -181
    x[2732]   c829      1
    x[2732]   c834      -1
    x[2733]   c220_1    -181
    x[2733]   c265_1    -68
    x[2733]   c829      1
    x[2733]   c835      -1
    x[2734]   c221_1    -181
    x[2734]   c266_1    -68
    x[2734]   c829      1
    x[2734]   c836      -1
    x[2735]   c222_1    -181
    x[2735]   c267_1    -68
    x[2735]   c829      1
    x[2735]   c837      -1
    x[2736]   c181_1    -181
    x[2736]   c226_1    -68
    x[2736]   c830      1
    x[2736]   c831      -1
    x[2737]   c182_1    -181
    x[2737]   c227_1    -68
    x[2737]   c830      1
    x[2737]   c832      -1
    x[2738]   c184_1    -181
    x[2738]   c229_1    -68
    x[2738]   c830      1
    x[2738]   c833      -1
    x[2739]   c185_1    -181
    x[2739]   c230_1    -68
    x[2739]   c830      1
    x[2739]   c834      -1
    x[2740]   c187_1    -181
    x[2740]   c232_1    -68
    x[2740]   c830      1
    x[2740]   c835      -1
    x[2741]   c188_1    -181
    x[2741]   c233_1    -68
    x[2741]   c830      1
    x[2741]   c836      -1
    x[2742]   c189_1    -181
    x[2742]   c234_1    -68
    x[2742]   c830      1
    x[2742]   c837      -1
    x[2743]   c181_1    -68
    x[2743]   c226_1    -181
    x[2743]   c830      -1
    x[2743]   c831      1
    x[2744]   c182_1    -68
    x[2744]   c227_1    -181
    x[2744]   c830      -1
    x[2744]   c832      1
    x[2745]   c184_1    -68
    x[2745]   c229_1    -181
    x[2745]   c830      -1
    x[2745]   c833      1
    x[2746]   c185_1    -68
    x[2746]   c230_1    -181
    x[2746]   c830      -1
    x[2746]   c834      1
    x[2747]   c187_1    -68
    x[2747]   c232_1    -181
    x[2747]   c830      -1
    x[2747]   c835      1
    x[2748]   c188_1    -68
    x[2748]   c233_1    -181
    x[2748]   c830      -1
    x[2748]   c836      1
    x[2749]   c189_1    -68
    x[2749]   c234_1    -181
    x[2749]   c830      -1
    x[2749]   c837      1
    x[2750]   c190_1    -181
    x[2750]   c235_1    -68
    x[2750]   c831      1
    x[2750]   c832      -1
    x[2751]   c192_1    -181
    x[2751]   c237_1    -68
    x[2751]   c831      1
    x[2751]   c833      -1
    x[2752]   c193_1    -181
    x[2752]   c238_1    -68
    x[2752]   c831      1
    x[2752]   c834      -1
    x[2753]   c195_1    -181
    x[2753]   c240_1    -68
    x[2753]   c831      1
    x[2753]   c835      -1
    x[2754]   c196_1    -181
    x[2754]   c241_1    -68
    x[2754]   c831      1
    x[2754]   c836      -1
    x[2755]   c197_1    -181
    x[2755]   c242_1    -68
    x[2755]   c831      1
    x[2755]   c837      -1
    x[2756]   c190_1    -68
    x[2756]   c235_1    -181
    x[2756]   c831      -1
    x[2756]   c832      1
    x[2757]   c192_1    -68
    x[2757]   c237_1    -181
    x[2757]   c831      -1
    x[2757]   c833      1
    x[2758]   c193_1    -68
    x[2758]   c238_1    -181
    x[2758]   c831      -1
    x[2758]   c834      1
    x[2759]   c195_1    -68
    x[2759]   c240_1    -181
    x[2759]   c831      -1
    x[2759]   c835      1
    x[2760]   c196_1    -68
    x[2760]   c241_1    -181
    x[2760]   c831      -1
    x[2760]   c836      1
    x[2761]   c197_1    -68
    x[2761]   c242_1    -181
    x[2761]   c831      -1
    x[2761]   c837      1
    x[2762]   c199_1    -181
    x[2762]   c244_1    -68
    x[2762]   c832      1
    x[2762]   c833      -1
    x[2763]   c200_1    -181
    x[2763]   c245_1    -68
    x[2763]   c832      1
    x[2763]   c834      -1
    x[2764]   c202_1    -181
    x[2764]   c247_1    -68
    x[2764]   c832      1
    x[2764]   c835      -1
    x[2765]   c203_1    -181
    x[2765]   c248_1    -68
    x[2765]   c832      1
    x[2765]   c836      -1
    x[2766]   c204_1    -181
    x[2766]   c249_1    -68
    x[2766]   c832      1
    x[2766]   c837      -1
    x[2767]   c199_1    -68
    x[2767]   c244_1    -181
    x[2767]   c832      -1
    x[2767]   c833      1
    x[2768]   c200_1    -68
    x[2768]   c245_1    -181
    x[2768]   c832      -1
    x[2768]   c834      1
    x[2769]   c202_1    -68
    x[2769]   c247_1    -181
    x[2769]   c832      -1
    x[2769]   c835      1
    x[2770]   c203_1    -68
    x[2770]   c248_1    -181
    x[2770]   c832      -1
    x[2770]   c836      1
    x[2771]   c204_1    -68
    x[2771]   c249_1    -181
    x[2771]   c832      -1
    x[2771]   c837      1
    x[2772]   c211_1    -181
    x[2772]   c256_1    -68
    x[2772]   c833      1
    x[2772]   c834      -1
    x[2773]   c213_1    -181
    x[2773]   c258_1    -68
    x[2773]   c833      1
    x[2773]   c835      -1
    x[2774]   c214_1    -181
    x[2774]   c259_1    -68
    x[2774]   c833      1
    x[2774]   c836      -1
    x[2775]   c215_1    -181
    x[2775]   c260_1    -68
    x[2775]   c833      1
    x[2775]   c837      -1
    x[2776]   c211_1    -68
    x[2776]   c256_1    -181
    x[2776]   c833      -1
    x[2776]   c834      1
    x[2777]   c213_1    -68
    x[2777]   c258_1    -181
    x[2777]   c833      -1
    x[2777]   c835      1
    x[2778]   c214_1    -68
    x[2778]   c259_1    -181
    x[2778]   c833      -1
    x[2778]   c836      1
    x[2779]   c215_1    -68
    x[2779]   c260_1    -181
    x[2779]   c833      -1
    x[2779]   c837      1
    x[2780]   c217_1    -181
    x[2780]   c262_1    -68
    x[2780]   c834      1
    x[2780]   c835      -1
    x[2781]   c218_1    -181
    x[2781]   c263_1    -68
    x[2781]   c834      1
    x[2781]   c836      -1
    x[2782]   c219_1    -181
    x[2782]   c264_1    -68
    x[2782]   c834      1
    x[2782]   c837      -1
    x[2783]   c217_1    -68
    x[2783]   c262_1    -181
    x[2783]   c834      -1
    x[2783]   c835      1
    x[2784]   c218_1    -68
    x[2784]   c263_1    -181
    x[2784]   c834      -1
    x[2784]   c836      1
    x[2785]   c219_1    -68
    x[2785]   c264_1    -181
    x[2785]   c834      -1
    x[2785]   c837      1
    x[2786]   c223_1    -181
    x[2786]   c268_1    -68
    x[2786]   c835      1
    x[2786]   c836      -1
    x[2787]   c224_1    -181
    x[2787]   c269_1    -68
    x[2787]   c835      1
    x[2787]   c837      -1
    x[2788]   c223_1    -68
    x[2788]   c268_1    -181
    x[2788]   c835      -1
    x[2788]   c836      1
    x[2789]   c224_1    -68
    x[2789]   c269_1    -181
    x[2789]   c835      -1
    x[2789]   c837      1
    x[2790]   c225_1    -181
    x[2790]   c270_1    -68
    x[2790]   c836      1
    x[2790]   c837      -1
    x[2791]   c225_1    -68
    x[2791]   c270_1    -181
    x[2791]   c836      -1
    x[2791]   c837      1
    x[2792]   c187_1    -191
    x[2792]   c232_1    -156
    x[2792]   c838      1
    x[2793]   c195_1    -191
    x[2793]   c240_1    -156
    x[2793]   c839      1
    x[2794]   c202_1    -191
    x[2794]   c247_1    -156
    x[2794]   c840      1
    x[2795]   c208_1    -191
    x[2795]   c253_1    -156
    x[2795]   c841      1
    x[2796]   c211_1    -191
    x[2796]   c256_1    -156
    x[2796]   c842      1
    x[2797]   c212_1    -191
    x[2797]   c257_1    -156
    x[2797]   c843      1
    x[2798]   c213_1    -191
    x[2798]   c258_1    -156
    x[2798]   c844      1
    x[2799]   c214_1    -191
    x[2799]   c259_1    -156
    x[2799]   c845      1
    x[2800]   c215_1    -191
    x[2800]   c260_1    -156
    x[2800]   c846      1
    x[2801]   c217_1    -191
    x[2801]   c262_1    -156
    x[2801]   c847      1
    x[2802]   c220_1    -191
    x[2802]   c265_1    -156
    x[2802]   c848      1
    x[2803]   c184_1    -156
    x[2803]   c229_1    -191
    x[2803]   c849      1
    x[2804]   c192_1    -156
    x[2804]   c237_1    -191
    x[2804]   c850      1
    x[2805]   c199_1    -156
    x[2805]   c244_1    -191
    x[2805]   c851      1
    x[2806]   c205_1    -156
    x[2806]   c250_1    -191
    x[2806]   c852      1
    x[2807]   c223_1    -156
    x[2807]   c268_1    -191
    x[2807]   c853      1
    x[2808]   c224_1    -156
    x[2808]   c269_1    -191
    x[2808]   c854      1
    x[2809]   c223_1    -191
    x[2809]   c268_1    -156
    x[2809]   c855      1
    x[2809]   c863      1
    x[2810]   c224_1    -191
    x[2810]   c269_1    -156
    x[2810]   c855      1
    x[2810]   c864      1
    x[2811]   c187_1    -156
    x[2811]   c232_1    -191
    x[2811]   c855      1
    x[2811]   c857      1
    x[2812]   c195_1    -156
    x[2812]   c240_1    -191
    x[2812]   c855      1
    x[2812]   c858      1
    x[2813]   c202_1    -156
    x[2813]   c247_1    -191
    x[2813]   c855      1
    x[2813]   c859      1
    x[2814]   c208_1    -156
    x[2814]   c253_1    -191
    x[2814]   c855      1
    x[2814]   c860      1
    x[2815]   c213_1    -156
    x[2815]   c258_1    -191
    x[2815]   c855      1
    x[2815]   c856      1
    x[2816]   c217_1    -156
    x[2816]   c262_1    -191
    x[2816]   c855      1
    x[2816]   c861      1
    x[2817]   c220_1    -156
    x[2817]   c265_1    -191
    x[2817]   c855      1
    x[2817]   c862      1
    x[2818]   c162_2    1
    x[2818]   c163_2    1
    x[2818]   c164_2    1
    x[2818]   c165_2    1
    x[2818]   c166_2    1
    x[2818]   c184_1    -191
    x[2818]   c229_1    -156
    x[2818]   c856      1
    x[2818]   c857      -1
    x[2819]   c192_1    -191
    x[2819]   c237_1    -156
    x[2819]   c856      1
    x[2819]   c858      -1
    x[2820]   c199_1    -191
    x[2820]   c244_1    -156
    x[2820]   c856      1
    x[2820]   c859      -1
    x[2821]   c162_2    1
    x[2821]   c205_1    -191
    x[2821]   c250_1    -156
    x[2821]   c856      1
    x[2821]   c860      -1
    x[2822]   c163_2    1
    x[2822]   c211_1    -156
    x[2822]   c256_1    -191
    x[2822]   c856      1
    x[2822]   c861      -1
    x[2823]   c164_2    1
    x[2823]   c212_1    -156
    x[2823]   c257_1    -191
    x[2823]   c856      1
    x[2823]   c862      -1
    x[2824]   c165_2    1
    x[2824]   c214_1    -156
    x[2824]   c259_1    -191
    x[2824]   c856      1
    x[2824]   c863      -1
    x[2825]   c166_2    1
    x[2825]   c215_1    -156
    x[2825]   c260_1    -191
    x[2825]   c856      1
    x[2825]   c864      -1
    x[2826]   c181_1    -156
    x[2826]   c226_1    -191
    x[2826]   c857      1
    x[2826]   c858      -1
    x[2827]   c182_1    -156
    x[2827]   c227_1    -191
    x[2827]   c857      1
    x[2827]   c859      -1
    x[2828]   c183_1    -156
    x[2828]   c228_1    -191
    x[2828]   c857      1
    x[2828]   c860      -1
    x[2829]   c185_1    -156
    x[2829]   c230_1    -191
    x[2829]   c857      1
    x[2829]   c861      -1
    x[2830]   c186_1    -156
    x[2830]   c231_1    -191
    x[2830]   c857      1
    x[2830]   c862      -1
    x[2831]   c188_1    -156
    x[2831]   c233_1    -191
    x[2831]   c857      1
    x[2831]   c863      -1
    x[2832]   c189_1    -156
    x[2832]   c234_1    -191
    x[2832]   c857      1
    x[2832]   c864      -1
    x[2833]   c181_1    -191
    x[2833]   c226_1    -156
    x[2833]   c857      -1
    x[2833]   c858      1
    x[2834]   c182_1    -191
    x[2834]   c227_1    -156
    x[2834]   c857      -1
    x[2834]   c859      1
    x[2835]   c183_1    -191
    x[2835]   c228_1    -156
    x[2835]   c857      -1
    x[2835]   c860      1
    x[2836]   c185_1    -191
    x[2836]   c230_1    -156
    x[2836]   c857      -1
    x[2836]   c861      1
    x[2837]   c186_1    -191
    x[2837]   c231_1    -156
    x[2837]   c857      -1
    x[2837]   c862      1
    x[2838]   c188_1    -191
    x[2838]   c233_1    -156
    x[2838]   c857      -1
    x[2838]   c863      1
    x[2839]   c189_1    -191
    x[2839]   c234_1    -156
    x[2839]   c857      -1
    x[2839]   c864      1
    x[2840]   c190_1    -156
    x[2840]   c235_1    -191
    x[2840]   c858      1
    x[2840]   c859      -1
    x[2841]   c191_1    -156
    x[2841]   c236_1    -191
    x[2841]   c858      1
    x[2841]   c860      -1
    x[2842]   c193_1    -156
    x[2842]   c238_1    -191
    x[2842]   c858      1
    x[2842]   c861      -1
    x[2843]   c194_1    -156
    x[2843]   c239_1    -191
    x[2843]   c858      1
    x[2843]   c862      -1
    x[2844]   c196_1    -156
    x[2844]   c241_1    -191
    x[2844]   c858      1
    x[2844]   c863      -1
    x[2845]   c197_1    -156
    x[2845]   c242_1    -191
    x[2845]   c858      1
    x[2845]   c864      -1
    x[2846]   c190_1    -191
    x[2846]   c235_1    -156
    x[2846]   c858      -1
    x[2846]   c859      1
    x[2847]   c191_1    -191
    x[2847]   c236_1    -156
    x[2847]   c858      -1
    x[2847]   c860      1
    x[2848]   c193_1    -191
    x[2848]   c238_1    -156
    x[2848]   c858      -1
    x[2848]   c861      1
    x[2849]   c194_1    -191
    x[2849]   c239_1    -156
    x[2849]   c858      -1
    x[2849]   c862      1
    x[2850]   c196_1    -191
    x[2850]   c241_1    -156
    x[2850]   c858      -1
    x[2850]   c863      1
    x[2851]   c197_1    -191
    x[2851]   c242_1    -156
    x[2851]   c858      -1
    x[2851]   c864      1
    x[2852]   c198_1    -156
    x[2852]   c243_1    -191
    x[2852]   c859      1
    x[2852]   c860      -1
    x[2853]   c200_1    -156
    x[2853]   c245_1    -191
    x[2853]   c859      1
    x[2853]   c861      -1
    x[2854]   c201_1    -156
    x[2854]   c246_1    -191
    x[2854]   c859      1
    x[2854]   c862      -1
    x[2855]   c203_1    -156
    x[2855]   c248_1    -191
    x[2855]   c859      1
    x[2855]   c863      -1
    x[2856]   c204_1    -156
    x[2856]   c249_1    -191
    x[2856]   c859      1
    x[2856]   c864      -1
    x[2857]   c198_1    -191
    x[2857]   c243_1    -156
    x[2857]   c859      -1
    x[2857]   c860      1
    x[2858]   c200_1    -191
    x[2858]   c245_1    -156
    x[2858]   c859      -1
    x[2858]   c861      1
    x[2859]   c201_1    -191
    x[2859]   c246_1    -156
    x[2859]   c859      -1
    x[2859]   c862      1
    x[2860]   c203_1    -191
    x[2860]   c248_1    -156
    x[2860]   c859      -1
    x[2860]   c863      1
    x[2861]   c204_1    -191
    x[2861]   c249_1    -156
    x[2861]   c859      -1
    x[2861]   c864      1
    x[2862]   c206_1    -156
    x[2862]   c251_1    -191
    x[2862]   c860      1
    x[2862]   c861      -1
    x[2863]   c207_1    -156
    x[2863]   c252_1    -191
    x[2863]   c860      1
    x[2863]   c862      -1
    x[2864]   c209_1    -156
    x[2864]   c254_1    -191
    x[2864]   c860      1
    x[2864]   c863      -1
    x[2865]   c210_1    -156
    x[2865]   c255_1    -191
    x[2865]   c860      1
    x[2865]   c864      -1
    x[2866]   c206_1    -191
    x[2866]   c251_1    -156
    x[2866]   c860      -1
    x[2866]   c861      1
    x[2867]   c207_1    -191
    x[2867]   c252_1    -156
    x[2867]   c860      -1
    x[2867]   c862      1
    x[2868]   c209_1    -191
    x[2868]   c254_1    -156
    x[2868]   c860      -1
    x[2868]   c863      1
    x[2869]   c210_1    -191
    x[2869]   c255_1    -156
    x[2869]   c860      -1
    x[2869]   c864      1
    x[2870]   c216_1    -156
    x[2870]   c261_1    -191
    x[2870]   c861      1
    x[2870]   c862      -1
    x[2871]   c218_1    -156
    x[2871]   c263_1    -191
    x[2871]   c861      1
    x[2871]   c863      -1
    x[2872]   c219_1    -156
    x[2872]   c264_1    -191
    x[2872]   c861      1
    x[2872]   c864      -1
    x[2873]   c216_1    -191
    x[2873]   c261_1    -156
    x[2873]   c861      -1
    x[2873]   c862      1
    x[2874]   c218_1    -191
    x[2874]   c263_1    -156
    x[2874]   c861      -1
    x[2874]   c863      1
    x[2875]   c219_1    -191
    x[2875]   c264_1    -156
    x[2875]   c861      -1
    x[2875]   c864      1
    x[2876]   c221_1    -156
    x[2876]   c266_1    -191
    x[2876]   c862      1
    x[2876]   c863      -1
    x[2877]   c222_1    -156
    x[2877]   c267_1    -191
    x[2877]   c862      1
    x[2877]   c864      -1
    x[2878]   c221_1    -191
    x[2878]   c266_1    -156
    x[2878]   c862      -1
    x[2878]   c863      1
    x[2879]   c222_1    -191
    x[2879]   c267_1    -156
    x[2879]   c862      -1
    x[2879]   c864      1
    x[2880]   c225_1    -156
    x[2880]   c270_1    -191
    x[2880]   c863      1
    x[2880]   c864      -1
    x[2881]   c225_1    -191
    x[2881]   c270_1    -156
    x[2881]   c863      -1
    x[2881]   c864      1
    x[2882]   c188_1    -44
    x[2882]   c233_1    -23
    x[2882]   c865      1
    x[2883]   c196_1    -44
    x[2883]   c241_1    -23
    x[2883]   c866      1
    x[2884]   c203_1    -44
    x[2884]   c248_1    -23
    x[2884]   c867      1
    x[2885]   c209_1    -44
    x[2885]   c254_1    -23
    x[2885]   c868      1
    x[2886]   c211_1    -44
    x[2886]   c256_1    -23
    x[2886]   c869      1
    x[2887]   c212_1    -44
    x[2887]   c257_1    -23
    x[2887]   c870      1
    x[2888]   c213_1    -44
    x[2888]   c258_1    -23
    x[2888]   c871      1
    x[2889]   c214_1    -44
    x[2889]   c259_1    -23
    x[2889]   c872      1
    x[2890]   c215_1    -44
    x[2890]   c260_1    -23
    x[2890]   c873      1
    x[2891]   c218_1    -44
    x[2891]   c263_1    -23
    x[2891]   c874      1
    x[2892]   c221_1    -44
    x[2892]   c266_1    -23
    x[2892]   c875      1
    x[2893]   c223_1    -44
    x[2893]   c268_1    -23
    x[2893]   c876      1
    x[2894]   c184_1    -23
    x[2894]   c229_1    -44
    x[2894]   c877      1
    x[2895]   c192_1    -23
    x[2895]   c237_1    -44
    x[2895]   c878      1
    x[2896]   c199_1    -23
    x[2896]   c244_1    -44
    x[2896]   c879      1
    x[2897]   c205_1    -23
    x[2897]   c250_1    -44
    x[2897]   c880      1
    x[2898]   c225_1    -23
    x[2898]   c270_1    -44
    x[2898]   c881      1
    x[2899]   c225_1    -44
    x[2899]   c270_1    -23
    x[2899]   c882      1
    x[2899]   c891      1
    x[2900]   c314_1    1
    x[2900]   c188_1    -23
    x[2900]   c233_1    -44
    x[2900]   c882      1
    x[2900]   c884      1
    x[2901]   c315_1    1
    x[2901]   c196_1    -23
    x[2901]   c241_1    -44
    x[2901]   c882      1
    x[2901]   c885      1
    x[2902]   c203_1    -23
    x[2902]   c248_1    -44
    x[2902]   c882      1
    x[2902]   c886      1
    x[2903]   c316_1    1
    x[2903]   c209_1    -23
    x[2903]   c254_1    -44
    x[2903]   c882      1
    x[2903]   c887      1
    x[2904]   c314_1    1
    x[2904]   c315_1    1
    x[2904]   c316_1    1
    x[2904]   c317_1    1
    x[2904]   c214_1    -23
    x[2904]   c259_1    -44
    x[2904]   c882      1
    x[2904]   c883      1
    x[2905]   c218_1    -23
    x[2905]   c263_1    -44
    x[2905]   c882      1
    x[2905]   c888      1
    x[2906]   c317_1    1
    x[2906]   c221_1    -23
    x[2906]   c266_1    -44
    x[2906]   c882      1
    x[2906]   c889      1
    x[2907]   c223_1    -23
    x[2907]   c268_1    -44
    x[2907]   c882      1
    x[2907]   c890      1
    x[2908]   c58_2     1
    x[2908]   c59_2     1
    x[2908]   c60_2     1
    x[2908]   c61_2     1
    x[2908]   c184_1    -44
    x[2908]   c229_1    -23
    x[2908]   c883      1
    x[2908]   c884      -1
    x[2909]   c58_2     1
    x[2909]   c192_1    -44
    x[2909]   c237_1    -23
    x[2909]   c883      1
    x[2909]   c885      -1
    x[2910]   c199_1    -44
    x[2910]   c244_1    -23
    x[2910]   c883      1
    x[2910]   c886      -1
    x[2911]   c205_1    -44
    x[2911]   c250_1    -23
    x[2911]   c883      1
    x[2911]   c887      -1
    x[2912]   c59_2     1
    x[2912]   c211_1    -23
    x[2912]   c256_1    -44
    x[2912]   c883      1
    x[2912]   c888      -1
    x[2913]   c212_1    -23
    x[2913]   c257_1    -44
    x[2913]   c883      1
    x[2913]   c889      -1
    x[2914]   c60_2     1
    x[2914]   c213_1    -23
    x[2914]   c258_1    -44
    x[2914]   c883      1
    x[2914]   c890      -1
    x[2915]   c61_2     1
    x[2915]   c215_1    -23
    x[2915]   c260_1    -44
    x[2915]   c883      1
    x[2915]   c891      -1
    x[2916]   c181_1    -23
    x[2916]   c226_1    -44
    x[2916]   c884      1
    x[2916]   c885      -1
    x[2917]   c182_1    -23
    x[2917]   c227_1    -44
    x[2917]   c884      1
    x[2917]   c886      -1
    x[2918]   c183_1    -23
    x[2918]   c228_1    -44
    x[2918]   c884      1
    x[2918]   c887      -1
    x[2919]   c185_1    -23
    x[2919]   c230_1    -44
    x[2919]   c884      1
    x[2919]   c888      -1
    x[2920]   c186_1    -23
    x[2920]   c231_1    -44
    x[2920]   c884      1
    x[2920]   c889      -1
    x[2921]   c187_1    -23
    x[2921]   c232_1    -44
    x[2921]   c884      1
    x[2921]   c890      -1
    x[2922]   c189_1    -23
    x[2922]   c234_1    -44
    x[2922]   c884      1
    x[2922]   c891      -1
    x[2923]   c181_1    -44
    x[2923]   c226_1    -23
    x[2923]   c884      -1
    x[2923]   c885      1
    x[2924]   c182_1    -44
    x[2924]   c227_1    -23
    x[2924]   c884      -1
    x[2924]   c886      1
    x[2925]   c183_1    -44
    x[2925]   c228_1    -23
    x[2925]   c884      -1
    x[2925]   c887      1
    x[2926]   c185_1    -44
    x[2926]   c230_1    -23
    x[2926]   c884      -1
    x[2926]   c888      1
    x[2927]   c186_1    -44
    x[2927]   c231_1    -23
    x[2927]   c884      -1
    x[2927]   c889      1
    x[2928]   c187_1    -44
    x[2928]   c232_1    -23
    x[2928]   c884      -1
    x[2928]   c890      1
    x[2929]   c189_1    -44
    x[2929]   c234_1    -23
    x[2929]   c884      -1
    x[2929]   c891      1
    x[2930]   c190_1    -23
    x[2930]   c235_1    -44
    x[2930]   c885      1
    x[2930]   c886      -1
    x[2931]   c191_1    -23
    x[2931]   c236_1    -44
    x[2931]   c885      1
    x[2931]   c887      -1
    x[2932]   c193_1    -23
    x[2932]   c238_1    -44
    x[2932]   c885      1
    x[2932]   c888      -1
    x[2933]   c194_1    -23
    x[2933]   c239_1    -44
    x[2933]   c885      1
    x[2933]   c889      -1
    x[2934]   c195_1    -23
    x[2934]   c240_1    -44
    x[2934]   c885      1
    x[2934]   c890      -1
    x[2935]   c197_1    -23
    x[2935]   c242_1    -44
    x[2935]   c885      1
    x[2935]   c891      -1
    x[2936]   c190_1    -44
    x[2936]   c235_1    -23
    x[2936]   c885      -1
    x[2936]   c886      1
    x[2937]   c191_1    -44
    x[2937]   c236_1    -23
    x[2937]   c885      -1
    x[2937]   c887      1
    x[2938]   c193_1    -44
    x[2938]   c238_1    -23
    x[2938]   c885      -1
    x[2938]   c888      1
    x[2939]   c194_1    -44
    x[2939]   c239_1    -23
    x[2939]   c885      -1
    x[2939]   c889      1
    x[2940]   c195_1    -44
    x[2940]   c240_1    -23
    x[2940]   c885      -1
    x[2940]   c890      1
    x[2941]   c197_1    -44
    x[2941]   c242_1    -23
    x[2941]   c885      -1
    x[2941]   c891      1
    x[2942]   c198_1    -23
    x[2942]   c243_1    -44
    x[2942]   c886      1
    x[2942]   c887      -1
    x[2943]   c200_1    -23
    x[2943]   c245_1    -44
    x[2943]   c886      1
    x[2943]   c888      -1
    x[2944]   c201_1    -23
    x[2944]   c246_1    -44
    x[2944]   c886      1
    x[2944]   c889      -1
    x[2945]   c202_1    -23
    x[2945]   c247_1    -44
    x[2945]   c886      1
    x[2945]   c890      -1
    x[2946]   c204_1    -23
    x[2946]   c249_1    -44
    x[2946]   c886      1
    x[2946]   c891      -1
    x[2947]   c198_1    -44
    x[2947]   c243_1    -23
    x[2947]   c886      -1
    x[2947]   c887      1
    x[2948]   c200_1    -44
    x[2948]   c245_1    -23
    x[2948]   c886      -1
    x[2948]   c888      1
    x[2949]   c201_1    -44
    x[2949]   c246_1    -23
    x[2949]   c886      -1
    x[2949]   c889      1
    x[2950]   c202_1    -44
    x[2950]   c247_1    -23
    x[2950]   c886      -1
    x[2950]   c890      1
    x[2951]   c204_1    -44
    x[2951]   c249_1    -23
    x[2951]   c886      -1
    x[2951]   c891      1
    x[2952]   c206_1    -23
    x[2952]   c251_1    -44
    x[2952]   c887      1
    x[2952]   c888      -1
    x[2953]   c207_1    -23
    x[2953]   c252_1    -44
    x[2953]   c887      1
    x[2953]   c889      -1
    x[2954]   c208_1    -23
    x[2954]   c253_1    -44
    x[2954]   c887      1
    x[2954]   c890      -1
    x[2955]   c210_1    -23
    x[2955]   c255_1    -44
    x[2955]   c887      1
    x[2955]   c891      -1
    x[2956]   c206_1    -44
    x[2956]   c251_1    -23
    x[2956]   c887      -1
    x[2956]   c888      1
    x[2957]   c207_1    -44
    x[2957]   c252_1    -23
    x[2957]   c887      -1
    x[2957]   c889      1
    x[2958]   c208_1    -44
    x[2958]   c253_1    -23
    x[2958]   c887      -1
    x[2958]   c890      1
    x[2959]   c210_1    -44
    x[2959]   c255_1    -23
    x[2959]   c887      -1
    x[2959]   c891      1
    x[2960]   c216_1    -23
    x[2960]   c261_1    -44
    x[2960]   c888      1
    x[2960]   c889      -1
    x[2961]   c217_1    -23
    x[2961]   c262_1    -44
    x[2961]   c888      1
    x[2961]   c890      -1
    x[2962]   c219_1    -23
    x[2962]   c264_1    -44
    x[2962]   c888      1
    x[2962]   c891      -1
    x[2963]   c216_1    -44
    x[2963]   c261_1    -23
    x[2963]   c888      -1
    x[2963]   c889      1
    x[2964]   c217_1    -44
    x[2964]   c262_1    -23
    x[2964]   c888      -1
    x[2964]   c890      1
    x[2965]   c219_1    -44
    x[2965]   c264_1    -23
    x[2965]   c888      -1
    x[2965]   c891      1
    x[2966]   c220_1    -23
    x[2966]   c265_1    -44
    x[2966]   c889      1
    x[2966]   c890      -1
    x[2967]   c222_1    -23
    x[2967]   c267_1    -44
    x[2967]   c889      1
    x[2967]   c891      -1
    x[2968]   c220_1    -44
    x[2968]   c265_1    -23
    x[2968]   c889      -1
    x[2968]   c890      1
    x[2969]   c222_1    -44
    x[2969]   c267_1    -23
    x[2969]   c889      -1
    x[2969]   c891      1
    x[2970]   c224_1    -23
    x[2970]   c269_1    -44
    x[2970]   c890      1
    x[2970]   c891      -1
    x[2971]   c224_1    -44
    x[2971]   c269_1    -23
    x[2971]   c890      -1
    x[2971]   c891      1
    x[2972]   c183_1    -83
    x[2972]   c228_1    -96
    x[2972]   c892      1
    x[2973]   c191_1    -83
    x[2973]   c236_1    -96
    x[2973]   c893      1
    x[2974]   c198_1    -83
    x[2974]   c243_1    -96
    x[2974]   c894      1
    x[2975]   c189_1    -96
    x[2975]   c234_1    -83
    x[2975]   c895      1
    x[2976]   c197_1    -96
    x[2976]   c242_1    -83
    x[2976]   c896      1
    x[2977]   c204_1    -96
    x[2977]   c249_1    -83
    x[2977]   c897      1
    x[2978]   c205_1    -96
    x[2978]   c250_1    -83
    x[2978]   c898      1
    x[2979]   c206_1    -96
    x[2979]   c251_1    -83
    x[2979]   c899      1
    x[2980]   c207_1    -96
    x[2980]   c252_1    -83
    x[2980]   c900      1
    x[2981]   c208_1    -96
    x[2981]   c253_1    -83
    x[2981]   c901      1
    x[2982]   c209_1    -96
    x[2982]   c254_1    -83
    x[2982]   c902      1
    x[2983]   c210_1    -96
    x[2983]   c255_1    -83
    x[2983]   c903      1
    x[2984]   c215_1    -96
    x[2984]   c260_1    -83
    x[2984]   c904      1
    x[2985]   c219_1    -96
    x[2985]   c264_1    -83
    x[2985]   c905      1
    x[2986]   c222_1    -96
    x[2986]   c267_1    -83
    x[2986]   c906      1
    x[2987]   c224_1    -96
    x[2987]   c269_1    -83
    x[2987]   c907      1
    x[2988]   c225_1    -96
    x[2988]   c270_1    -83
    x[2988]   c908      1
    x[2989]   c144_2    1
    x[2989]   c205_1    -83
    x[2989]   c250_1    -96
    x[2989]   c909      1
    x[2989]   c914      1
    x[2990]   c129_2    1
    x[2990]   c206_1    -83
    x[2990]   c251_1    -96
    x[2990]   c909      1
    x[2990]   c915      1
    x[2991]   c130_2    1
    x[2991]   c207_1    -83
    x[2991]   c252_1    -96
    x[2991]   c909      1
    x[2991]   c916      1
    x[2992]   c131_2    1
    x[2992]   c208_1    -83
    x[2992]   c253_1    -96
    x[2992]   c909      1
    x[2992]   c917      1
    x[2993]   c132_2    1
    x[2993]   c209_1    -83
    x[2993]   c254_1    -96
    x[2993]   c909      1
    x[2993]   c918      1
    x[2994]   c129_2    1
    x[2994]   c130_2    1
    x[2994]   c131_2    1
    x[2994]   c132_2    1
    x[2994]   c133_2    1
    x[2994]   c210_1    -83
    x[2994]   c255_1    -96
    x[2994]   c909      1
    x[2994]   c910      1
    x[2995]   c144_2    1
    x[2995]   c183_1    -96
    x[2995]   c228_1    -83
    x[2995]   c909      1
    x[2995]   c911      1
    x[2996]   c133_2    1
    x[2996]   c191_1    -96
    x[2996]   c236_1    -83
    x[2996]   c909      1
    x[2996]   c912      1
    x[2997]   c198_1    -96
    x[2997]   c243_1    -83
    x[2997]   c909      1
    x[2997]   c913      1
    x[2998]   c207_2    1
    x[2998]   c208_2    1
    x[2998]   c209_2    1
    x[2998]   c189_1    -83
    x[2998]   c234_1    -96
    x[2998]   c910      1
    x[2998]   c911      -1
    x[2999]   c210_2    1
    x[2999]   c197_1    -83
    x[2999]   c242_1    -96
    x[2999]   c910      1
    x[2999]   c912      -1
    x[3000]   c207_2    1
    x[3000]   c210_2    1
    x[3000]   c204_1    -83
    x[3000]   c249_1    -96
    x[3000]   c910      1
    x[3000]   c913      -1
    x[3001]   c215_1    -83
    x[3001]   c260_1    -96
    x[3001]   c910      1
    x[3001]   c914      -1
    x[3002]   c219_1    -83
    x[3002]   c264_1    -96
    x[3002]   c910      1
    x[3002]   c915      -1
    x[3003]   c208_2    1
    x[3003]   c222_1    -83
    x[3003]   c267_1    -96
    x[3003]   c910      1
    x[3003]   c916      -1
    x[3004]   c224_1    -83
    x[3004]   c269_1    -96
    x[3004]   c910      1
    x[3004]   c917      -1
    x[3005]   c209_2    1
    x[3005]   c225_1    -83
    x[3005]   c270_1    -96
    x[3005]   c910      1
    x[3005]   c918      -1
    x[3006]   c181_1    -96
    x[3006]   c226_1    -83
    x[3006]   c911      1
    x[3006]   c912      -1
    x[3007]   c182_1    -96
    x[3007]   c227_1    -83
    x[3007]   c911      1
    x[3007]   c913      -1
    x[3008]   c184_1    -96
    x[3008]   c229_1    -83
    x[3008]   c911      1
    x[3008]   c914      -1
    x[3009]   c185_1    -96
    x[3009]   c230_1    -83
    x[3009]   c911      1
    x[3009]   c915      -1
    x[3010]   c186_1    -96
    x[3010]   c231_1    -83
    x[3010]   c911      1
    x[3010]   c916      -1
    x[3011]   c187_1    -96
    x[3011]   c232_1    -83
    x[3011]   c911      1
    x[3011]   c917      -1
    x[3012]   c188_1    -96
    x[3012]   c233_1    -83
    x[3012]   c911      1
    x[3012]   c918      -1
    x[3013]   c181_1    -83
    x[3013]   c226_1    -96
    x[3013]   c911      -1
    x[3013]   c912      1
    x[3014]   c182_1    -83
    x[3014]   c227_1    -96
    x[3014]   c911      -1
    x[3014]   c913      1
    x[3015]   c184_1    -83
    x[3015]   c229_1    -96
    x[3015]   c911      -1
    x[3015]   c914      1
    x[3016]   c185_1    -83
    x[3016]   c230_1    -96
    x[3016]   c911      -1
    x[3016]   c915      1
    x[3017]   c186_1    -83
    x[3017]   c231_1    -96
    x[3017]   c911      -1
    x[3017]   c916      1
    x[3018]   c187_1    -83
    x[3018]   c232_1    -96
    x[3018]   c911      -1
    x[3018]   c917      1
    x[3019]   c188_1    -83
    x[3019]   c233_1    -96
    x[3019]   c911      -1
    x[3019]   c918      1
    x[3020]   c190_1    -96
    x[3020]   c235_1    -83
    x[3020]   c912      1
    x[3020]   c913      -1
    x[3021]   c192_1    -96
    x[3021]   c237_1    -83
    x[3021]   c912      1
    x[3021]   c914      -1
    x[3022]   c193_1    -96
    x[3022]   c238_1    -83
    x[3022]   c912      1
    x[3022]   c915      -1
    x[3023]   c194_1    -96
    x[3023]   c239_1    -83
    x[3023]   c912      1
    x[3023]   c916      -1
    x[3024]   c195_1    -96
    x[3024]   c240_1    -83
    x[3024]   c912      1
    x[3024]   c917      -1
    x[3025]   c196_1    -96
    x[3025]   c241_1    -83
    x[3025]   c912      1
    x[3025]   c918      -1
    x[3026]   c190_1    -83
    x[3026]   c235_1    -96
    x[3026]   c912      -1
    x[3026]   c913      1
    x[3027]   c192_1    -83
    x[3027]   c237_1    -96
    x[3027]   c912      -1
    x[3027]   c914      1
    x[3028]   c193_1    -83
    x[3028]   c238_1    -96
    x[3028]   c912      -1
    x[3028]   c915      1
    x[3029]   c194_1    -83
    x[3029]   c239_1    -96
    x[3029]   c912      -1
    x[3029]   c916      1
    x[3030]   c195_1    -83
    x[3030]   c240_1    -96
    x[3030]   c912      -1
    x[3030]   c917      1
    x[3031]   c196_1    -83
    x[3031]   c241_1    -96
    x[3031]   c912      -1
    x[3031]   c918      1
    x[3032]   c199_1    -96
    x[3032]   c244_1    -83
    x[3032]   c913      1
    x[3032]   c914      -1
    x[3033]   c200_1    -96
    x[3033]   c245_1    -83
    x[3033]   c913      1
    x[3033]   c915      -1
    x[3034]   c201_1    -96
    x[3034]   c246_1    -83
    x[3034]   c913      1
    x[3034]   c916      -1
    x[3035]   c202_1    -96
    x[3035]   c247_1    -83
    x[3035]   c913      1
    x[3035]   c917      -1
    x[3036]   c203_1    -96
    x[3036]   c248_1    -83
    x[3036]   c913      1
    x[3036]   c918      -1
    x[3037]   c199_1    -83
    x[3037]   c244_1    -96
    x[3037]   c913      -1
    x[3037]   c914      1
    x[3038]   c200_1    -83
    x[3038]   c245_1    -96
    x[3038]   c913      -1
    x[3038]   c915      1
    x[3039]   c201_1    -83
    x[3039]   c246_1    -96
    x[3039]   c913      -1
    x[3039]   c916      1
    x[3040]   c202_1    -83
    x[3040]   c247_1    -96
    x[3040]   c913      -1
    x[3040]   c917      1
    x[3041]   c203_1    -83
    x[3041]   c248_1    -96
    x[3041]   c913      -1
    x[3041]   c918      1
    x[3042]   c211_1    -96
    x[3042]   c256_1    -83
    x[3042]   c914      1
    x[3042]   c915      -1
    x[3043]   c212_1    -96
    x[3043]   c257_1    -83
    x[3043]   c914      1
    x[3043]   c916      -1
    x[3044]   c213_1    -96
    x[3044]   c258_1    -83
    x[3044]   c914      1
    x[3044]   c917      -1
    x[3045]   c214_1    -96
    x[3045]   c259_1    -83
    x[3045]   c914      1
    x[3045]   c918      -1
    x[3046]   c211_1    -83
    x[3046]   c256_1    -96
    x[3046]   c914      -1
    x[3046]   c915      1
    x[3047]   c212_1    -83
    x[3047]   c257_1    -96
    x[3047]   c914      -1
    x[3047]   c916      1
    x[3048]   c213_1    -83
    x[3048]   c258_1    -96
    x[3048]   c914      -1
    x[3048]   c917      1
    x[3049]   c214_1    -83
    x[3049]   c259_1    -96
    x[3049]   c914      -1
    x[3049]   c918      1
    x[3050]   c216_1    -96
    x[3050]   c261_1    -83
    x[3050]   c915      1
    x[3050]   c916      -1
    x[3051]   c217_1    -96
    x[3051]   c262_1    -83
    x[3051]   c915      1
    x[3051]   c917      -1
    x[3052]   c218_1    -96
    x[3052]   c263_1    -83
    x[3052]   c915      1
    x[3052]   c918      -1
    x[3053]   c216_1    -83
    x[3053]   c261_1    -96
    x[3053]   c915      -1
    x[3053]   c916      1
    x[3054]   c217_1    -83
    x[3054]   c262_1    -96
    x[3054]   c915      -1
    x[3054]   c917      1
    x[3055]   c218_1    -83
    x[3055]   c263_1    -96
    x[3055]   c915      -1
    x[3055]   c918      1
    x[3056]   c220_1    -96
    x[3056]   c265_1    -83
    x[3056]   c916      1
    x[3056]   c917      -1
    x[3057]   c221_1    -96
    x[3057]   c266_1    -83
    x[3057]   c916      1
    x[3057]   c918      -1
    x[3058]   c220_1    -83
    x[3058]   c265_1    -96
    x[3058]   c916      -1
    x[3058]   c917      1
    x[3059]   c221_1    -83
    x[3059]   c266_1    -96
    x[3059]   c916      -1
    x[3059]   c918      1
    x[3060]   c223_1    -96
    x[3060]   c268_1    -83
    x[3060]   c917      1
    x[3060]   c918      -1
    x[3061]   c223_1    -83
    x[3061]   c268_1    -96
    x[3061]   c917      -1
    x[3061]   c918      1
    x[3062]   c189_1    -24
    x[3062]   c234_1    -69
    x[3062]   c919      1
    x[3063]   c197_1    -24
    x[3063]   c242_1    -69
    x[3063]   c920      1
    x[3064]   c204_1    -24
    x[3064]   c249_1    -69
    x[3064]   c921      1
    x[3065]   c210_1    -24
    x[3065]   c255_1    -69
    x[3065]   c922      1
    x[3066]   c215_1    -24
    x[3066]   c260_1    -69
    x[3066]   c923      1
    x[3067]   c216_1    -24
    x[3067]   c261_1    -69
    x[3067]   c924      1
    x[3068]   c217_1    -24
    x[3068]   c262_1    -69
    x[3068]   c925      1
    x[3069]   c218_1    -24
    x[3069]   c263_1    -69
    x[3069]   c926      1
    x[3070]   c219_1    -24
    x[3070]   c264_1    -69
    x[3070]   c927      1
    x[3071]   c222_1    -24
    x[3071]   c267_1    -69
    x[3071]   c928      1
    x[3072]   c224_1    -24
    x[3072]   c269_1    -69
    x[3072]   c929      1
    x[3073]   c225_1    -24
    x[3073]   c270_1    -69
    x[3073]   c930      1
    x[3074]   c185_1    -69
    x[3074]   c230_1    -24
    x[3074]   c931      1
    x[3075]   c193_1    -69
    x[3075]   c238_1    -24
    x[3075]   c932      1
    x[3076]   c200_1    -69
    x[3076]   c245_1    -24
    x[3076]   c933      1
    x[3077]   c206_1    -69
    x[3077]   c251_1    -24
    x[3077]   c934      1
    x[3078]   c211_1    -69
    x[3078]   c256_1    -24
    x[3078]   c935      1
    x[3079]   c310_1    1
    x[3079]   c189_1    -69
    x[3079]   c234_1    -24
    x[3079]   c936      1
    x[3079]   c938      1
    x[3080]   c296_1    1
    x[3080]   c197_1    -69
    x[3080]   c242_1    -24
    x[3080]   c936      1
    x[3080]   c939      1
    x[3081]   c297_1    1
    x[3081]   c204_1    -69
    x[3081]   c249_1    -24
    x[3081]   c936      1
    x[3081]   c940      1
    x[3082]   c210_1    -69
    x[3082]   c255_1    -24
    x[3082]   c936      1
    x[3082]   c941      1
    x[3083]   c298_1    1
    x[3083]   c215_1    -69
    x[3083]   c260_1    -24
    x[3083]   c936      1
    x[3083]   c942      1
    x[3084]   c296_1    1
    x[3084]   c297_1    1
    x[3084]   c298_1    1
    x[3084]   c299_1    1
    x[3084]   c219_1    -69
    x[3084]   c264_1    -24
    x[3084]   c936      1
    x[3084]   c937      1
    x[3085]   c310_1    1
    x[3085]   c222_1    -69
    x[3085]   c267_1    -24
    x[3085]   c936      1
    x[3085]   c943      1
    x[3086]   c299_1    1
    x[3086]   c224_1    -69
    x[3086]   c269_1    -24
    x[3086]   c936      1
    x[3086]   c944      1
    x[3087]   c225_1    -69
    x[3087]   c270_1    -24
    x[3087]   c936      1
    x[3087]   c945      1
    x[3088]   c185_1    -24
    x[3088]   c230_1    -69
    x[3088]   c937      1
    x[3088]   c938      -1
    x[3089]   c37_2     1
    x[3089]   c193_1    -24
    x[3089]   c238_1    -69
    x[3089]   c937      1
    x[3089]   c939      -1
    x[3090]   c37_2     1
    x[3090]   c200_1    -24
    x[3090]   c245_1    -69
    x[3090]   c937      1
    x[3090]   c940      -1
    x[3091]   c206_1    -24
    x[3091]   c251_1    -69
    x[3091]   c937      1
    x[3091]   c941      -1
    x[3092]   c211_1    -24
    x[3092]   c256_1    -69
    x[3092]   c937      1
    x[3092]   c942      -1
    x[3093]   c216_1    -69
    x[3093]   c261_1    -24
    x[3093]   c937      1
    x[3093]   c943      -1
    x[3094]   c217_1    -69
    x[3094]   c262_1    -24
    x[3094]   c937      1
    x[3094]   c944      -1
    x[3095]   c218_1    -69
    x[3095]   c263_1    -24
    x[3095]   c937      1
    x[3095]   c945      -1
    x[3096]   c181_1    -69
    x[3096]   c226_1    -24
    x[3096]   c938      1
    x[3096]   c939      -1
    x[3097]   c182_1    -69
    x[3097]   c227_1    -24
    x[3097]   c938      1
    x[3097]   c940      -1
    x[3098]   c183_1    -69
    x[3098]   c228_1    -24
    x[3098]   c938      1
    x[3098]   c941      -1
    x[3099]   c184_1    -69
    x[3099]   c229_1    -24
    x[3099]   c938      1
    x[3099]   c942      -1
    x[3100]   c186_1    -69
    x[3100]   c231_1    -24
    x[3100]   c938      1
    x[3100]   c943      -1
    x[3101]   c187_1    -69
    x[3101]   c232_1    -24
    x[3101]   c938      1
    x[3101]   c944      -1
    x[3102]   c188_1    -69
    x[3102]   c233_1    -24
    x[3102]   c938      1
    x[3102]   c945      -1
    x[3103]   c181_1    -24
    x[3103]   c226_1    -69
    x[3103]   c938      -1
    x[3103]   c939      1
    x[3104]   c182_1    -24
    x[3104]   c227_1    -69
    x[3104]   c938      -1
    x[3104]   c940      1
    x[3105]   c183_1    -24
    x[3105]   c228_1    -69
    x[3105]   c938      -1
    x[3105]   c941      1
    x[3106]   c184_1    -24
    x[3106]   c229_1    -69
    x[3106]   c938      -1
    x[3106]   c942      1
    x[3107]   c186_1    -24
    x[3107]   c231_1    -69
    x[3107]   c938      -1
    x[3107]   c943      1
    x[3108]   c187_1    -24
    x[3108]   c232_1    -69
    x[3108]   c938      -1
    x[3108]   c944      1
    x[3109]   c188_1    -24
    x[3109]   c233_1    -69
    x[3109]   c938      -1
    x[3109]   c945      1
    x[3110]   c190_1    -69
    x[3110]   c235_1    -24
    x[3110]   c939      1
    x[3110]   c940      -1
    x[3111]   c191_1    -69
    x[3111]   c236_1    -24
    x[3111]   c939      1
    x[3111]   c941      -1
    x[3112]   c192_1    -69
    x[3112]   c237_1    -24
    x[3112]   c939      1
    x[3112]   c942      -1
    x[3113]   c194_1    -69
    x[3113]   c239_1    -24
    x[3113]   c939      1
    x[3113]   c943      -1
    x[3114]   c195_1    -69
    x[3114]   c240_1    -24
    x[3114]   c939      1
    x[3114]   c944      -1
    x[3115]   c196_1    -69
    x[3115]   c241_1    -24
    x[3115]   c939      1
    x[3115]   c945      -1
    x[3116]   c190_1    -24
    x[3116]   c235_1    -69
    x[3116]   c939      -1
    x[3116]   c940      1
    x[3117]   c191_1    -24
    x[3117]   c236_1    -69
    x[3117]   c939      -1
    x[3117]   c941      1
    x[3118]   c192_1    -24
    x[3118]   c237_1    -69
    x[3118]   c939      -1
    x[3118]   c942      1
    x[3119]   c194_1    -24
    x[3119]   c239_1    -69
    x[3119]   c939      -1
    x[3119]   c943      1
    x[3120]   c195_1    -24
    x[3120]   c240_1    -69
    x[3120]   c939      -1
    x[3120]   c944      1
    x[3121]   c196_1    -24
    x[3121]   c241_1    -69
    x[3121]   c939      -1
    x[3121]   c945      1
    x[3122]   c198_1    -69
    x[3122]   c243_1    -24
    x[3122]   c940      1
    x[3122]   c941      -1
    x[3123]   c199_1    -69
    x[3123]   c244_1    -24
    x[3123]   c940      1
    x[3123]   c942      -1
    x[3124]   c201_1    -69
    x[3124]   c246_1    -24
    x[3124]   c940      1
    x[3124]   c943      -1
    x[3125]   c202_1    -69
    x[3125]   c247_1    -24
    x[3125]   c940      1
    x[3125]   c944      -1
    x[3126]   c203_1    -69
    x[3126]   c248_1    -24
    x[3126]   c940      1
    x[3126]   c945      -1
    x[3127]   c198_1    -24
    x[3127]   c243_1    -69
    x[3127]   c940      -1
    x[3127]   c941      1
    x[3128]   c199_1    -24
    x[3128]   c244_1    -69
    x[3128]   c940      -1
    x[3128]   c942      1
    x[3129]   c201_1    -24
    x[3129]   c246_1    -69
    x[3129]   c940      -1
    x[3129]   c943      1
    x[3130]   c202_1    -24
    x[3130]   c247_1    -69
    x[3130]   c940      -1
    x[3130]   c944      1
    x[3131]   c203_1    -24
    x[3131]   c248_1    -69
    x[3131]   c940      -1
    x[3131]   c945      1
    x[3132]   c205_1    -69
    x[3132]   c250_1    -24
    x[3132]   c941      1
    x[3132]   c942      -1
    x[3133]   c207_1    -69
    x[3133]   c252_1    -24
    x[3133]   c941      1
    x[3133]   c943      -1
    x[3134]   c208_1    -69
    x[3134]   c253_1    -24
    x[3134]   c941      1
    x[3134]   c944      -1
    x[3135]   c209_1    -69
    x[3135]   c254_1    -24
    x[3135]   c941      1
    x[3135]   c945      -1
    x[3136]   c205_1    -24
    x[3136]   c250_1    -69
    x[3136]   c941      -1
    x[3136]   c942      1
    x[3137]   c207_1    -24
    x[3137]   c252_1    -69
    x[3137]   c941      -1
    x[3137]   c943      1
    x[3138]   c208_1    -24
    x[3138]   c253_1    -69
    x[3138]   c941      -1
    x[3138]   c944      1
    x[3139]   c209_1    -24
    x[3139]   c254_1    -69
    x[3139]   c941      -1
    x[3139]   c945      1
    x[3140]   c212_1    -69
    x[3140]   c257_1    -24
    x[3140]   c942      1
    x[3140]   c943      -1
    x[3141]   c213_1    -69
    x[3141]   c258_1    -24
    x[3141]   c942      1
    x[3141]   c944      -1
    x[3142]   c214_1    -69
    x[3142]   c259_1    -24
    x[3142]   c942      1
    x[3142]   c945      -1
    x[3143]   c212_1    -24
    x[3143]   c257_1    -69
    x[3143]   c942      -1
    x[3143]   c943      1
    x[3144]   c213_1    -24
    x[3144]   c258_1    -69
    x[3144]   c942      -1
    x[3144]   c944      1
    x[3145]   c214_1    -24
    x[3145]   c259_1    -69
    x[3145]   c942      -1
    x[3145]   c945      1
    x[3146]   c220_1    -69
    x[3146]   c265_1    -24
    x[3146]   c943      1
    x[3146]   c944      -1
    x[3147]   c221_1    -69
    x[3147]   c266_1    -24
    x[3147]   c943      1
    x[3147]   c945      -1
    x[3148]   c220_1    -24
    x[3148]   c265_1    -69
    x[3148]   c943      -1
    x[3148]   c944      1
    x[3149]   c221_1    -24
    x[3149]   c266_1    -69
    x[3149]   c943      -1
    x[3149]   c945      1
    x[3150]   c223_1    -69
    x[3150]   c268_1    -24
    x[3150]   c944      1
    x[3150]   c945      -1
    x[3151]   c223_1    -24
    x[3151]   c268_1    -69
    x[3151]   c944      -1
    x[3151]   c945      1
    x[3152]   c188_1    -148
    x[3152]   c233_1    -124
    x[3152]   c946      1
    x[3153]   c196_1    -148
    x[3153]   c241_1    -124
    x[3153]   c947      1
    x[3154]   c203_1    -148
    x[3154]   c248_1    -124
    x[3154]   c948      1
    x[3155]   c209_1    -148
    x[3155]   c254_1    -124
    x[3155]   c949      1
    x[3156]   c214_1    -148
    x[3156]   c259_1    -124
    x[3156]   c950      1
    x[3157]   c218_1    -148
    x[3157]   c263_1    -124
    x[3157]   c951      1
    x[3158]   c221_1    -148
    x[3158]   c266_1    -124
    x[3158]   c952      1
    x[3159]   c223_1    -148
    x[3159]   c268_1    -124
    x[3159]   c953      1
    x[3160]   c224_1    -148
    x[3160]   c269_1    -124
    x[3160]   c954      1
    x[3161]   c187_1    -124
    x[3161]   c232_1    -148
    x[3161]   c955      1
    x[3162]   c195_1    -124
    x[3162]   c240_1    -148
    x[3162]   c956      1
    x[3163]   c202_1    -124
    x[3163]   c247_1    -148
    x[3163]   c957      1
    x[3164]   c208_1    -124
    x[3164]   c253_1    -148
    x[3164]   c958      1
    x[3165]   c213_1    -124
    x[3165]   c258_1    -148
    x[3165]   c959      1
    x[3166]   c217_1    -124
    x[3166]   c262_1    -148
    x[3166]   c960      1
    x[3167]   c220_1    -124
    x[3167]   c265_1    -148
    x[3167]   c961      1
    x[3168]   c225_1    -124
    x[3168]   c270_1    -148
    x[3168]   c962      1
    x[3169]   c68_2     1
    x[3169]   c225_1    -148
    x[3169]   c270_1    -124
    x[3169]   c963      1
    x[3169]   c972      1
    x[3170]   c188_1    -124
    x[3170]   c233_1    -148
    x[3170]   c963      1
    x[3170]   c965      1
    x[3171]   c196_1    -124
    x[3171]   c241_1    -148
    x[3171]   c963      1
    x[3171]   c966      1
    x[3172]   c69_2     1
    x[3172]   c203_1    -124
    x[3172]   c248_1    -148
    x[3172]   c963      1
    x[3172]   c967      1
    x[3173]   c70_2     1
    x[3173]   c209_1    -124
    x[3173]   c254_1    -148
    x[3173]   c963      1
    x[3173]   c968      1
    x[3174]   c214_1    -124
    x[3174]   c259_1    -148
    x[3174]   c963      1
    x[3174]   c969      1
    x[3175]   c71_2     1
    x[3175]   c218_1    -124
    x[3175]   c263_1    -148
    x[3175]   c963      1
    x[3175]   c970      1
    x[3176]   c221_1    -124
    x[3176]   c266_1    -148
    x[3176]   c963      1
    x[3176]   c971      1
    x[3177]   c68_2     1
    x[3177]   c69_2     1
    x[3177]   c70_2     1
    x[3177]   c71_2     1
    x[3177]   c223_1    -124
    x[3177]   c268_1    -148
    x[3177]   c963      1
    x[3177]   c964      1
    x[3178]   c123_2    1
    x[3178]   c124_2    1
    x[3178]   c187_1    -148
    x[3178]   c232_1    -124
    x[3178]   c964      1
    x[3178]   c965      -1
    x[3179]   c125_2    1
    x[3179]   c195_1    -148
    x[3179]   c240_1    -124
    x[3179]   c964      1
    x[3179]   c966      -1
    x[3180]   c123_2    1
    x[3180]   c125_2    1
    x[3180]   c202_1    -148
    x[3180]   c247_1    -124
    x[3180]   c964      1
    x[3180]   c967      -1
    x[3181]   c208_1    -148
    x[3181]   c253_1    -124
    x[3181]   c964      1
    x[3181]   c968      -1
    x[3182]   c213_1    -148
    x[3182]   c258_1    -124
    x[3182]   c964      1
    x[3182]   c969      -1
    x[3183]   c124_2    1
    x[3183]   c217_1    -148
    x[3183]   c262_1    -124
    x[3183]   c964      1
    x[3183]   c970      -1
    x[3184]   c220_1    -148
    x[3184]   c265_1    -124
    x[3184]   c964      1
    x[3184]   c971      -1
    x[3185]   c224_1    -124
    x[3185]   c269_1    -148
    x[3185]   c964      1
    x[3185]   c972      -1
    x[3186]   c181_1    -124
    x[3186]   c226_1    -148
    x[3186]   c965      1
    x[3186]   c966      -1
    x[3187]   c182_1    -124
    x[3187]   c227_1    -148
    x[3187]   c965      1
    x[3187]   c967      -1
    x[3188]   c183_1    -124
    x[3188]   c228_1    -148
    x[3188]   c965      1
    x[3188]   c968      -1
    x[3189]   c184_1    -124
    x[3189]   c229_1    -148
    x[3189]   c965      1
    x[3189]   c969      -1
    x[3190]   c185_1    -124
    x[3190]   c230_1    -148
    x[3190]   c965      1
    x[3190]   c970      -1
    x[3191]   c186_1    -124
    x[3191]   c231_1    -148
    x[3191]   c965      1
    x[3191]   c971      -1
    x[3192]   c189_1    -124
    x[3192]   c234_1    -148
    x[3192]   c965      1
    x[3192]   c972      -1
    x[3193]   c181_1    -148
    x[3193]   c226_1    -124
    x[3193]   c965      -1
    x[3193]   c966      1
    x[3194]   c182_1    -148
    x[3194]   c227_1    -124
    x[3194]   c965      -1
    x[3194]   c967      1
    x[3195]   c183_1    -148
    x[3195]   c228_1    -124
    x[3195]   c965      -1
    x[3195]   c968      1
    x[3196]   c184_1    -148
    x[3196]   c229_1    -124
    x[3196]   c965      -1
    x[3196]   c969      1
    x[3197]   c185_1    -148
    x[3197]   c230_1    -124
    x[3197]   c965      -1
    x[3197]   c970      1
    x[3198]   c186_1    -148
    x[3198]   c231_1    -124
    x[3198]   c965      -1
    x[3198]   c971      1
    x[3199]   c189_1    -148
    x[3199]   c234_1    -124
    x[3199]   c965      -1
    x[3199]   c972      1
    x[3200]   c190_1    -124
    x[3200]   c235_1    -148
    x[3200]   c966      1
    x[3200]   c967      -1
    x[3201]   c191_1    -124
    x[3201]   c236_1    -148
    x[3201]   c966      1
    x[3201]   c968      -1
    x[3202]   c192_1    -124
    x[3202]   c237_1    -148
    x[3202]   c966      1
    x[3202]   c969      -1
    x[3203]   c193_1    -124
    x[3203]   c238_1    -148
    x[3203]   c966      1
    x[3203]   c970      -1
    x[3204]   c194_1    -124
    x[3204]   c239_1    -148
    x[3204]   c966      1
    x[3204]   c971      -1
    x[3205]   c197_1    -124
    x[3205]   c242_1    -148
    x[3205]   c966      1
    x[3205]   c972      -1
    x[3206]   c190_1    -148
    x[3206]   c235_1    -124
    x[3206]   c966      -1
    x[3206]   c967      1
    x[3207]   c191_1    -148
    x[3207]   c236_1    -124
    x[3207]   c966      -1
    x[3207]   c968      1
    x[3208]   c192_1    -148
    x[3208]   c237_1    -124
    x[3208]   c966      -1
    x[3208]   c969      1
    x[3209]   c193_1    -148
    x[3209]   c238_1    -124
    x[3209]   c966      -1
    x[3209]   c970      1
    x[3210]   c194_1    -148
    x[3210]   c239_1    -124
    x[3210]   c966      -1
    x[3210]   c971      1
    x[3211]   c197_1    -148
    x[3211]   c242_1    -124
    x[3211]   c966      -1
    x[3211]   c972      1
    x[3212]   c198_1    -124
    x[3212]   c243_1    -148
    x[3212]   c967      1
    x[3212]   c968      -1
    x[3213]   c199_1    -124
    x[3213]   c244_1    -148
    x[3213]   c967      1
    x[3213]   c969      -1
    x[3214]   c200_1    -124
    x[3214]   c245_1    -148
    x[3214]   c967      1
    x[3214]   c970      -1
    x[3215]   c201_1    -124
    x[3215]   c246_1    -148
    x[3215]   c967      1
    x[3215]   c971      -1
    x[3216]   c204_1    -124
    x[3216]   c249_1    -148
    x[3216]   c967      1
    x[3216]   c972      -1
    x[3217]   c198_1    -148
    x[3217]   c243_1    -124
    x[3217]   c967      -1
    x[3217]   c968      1
    x[3218]   c199_1    -148
    x[3218]   c244_1    -124
    x[3218]   c967      -1
    x[3218]   c969      1
    x[3219]   c200_1    -148
    x[3219]   c245_1    -124
    x[3219]   c967      -1
    x[3219]   c970      1
    x[3220]   c201_1    -148
    x[3220]   c246_1    -124
    x[3220]   c967      -1
    x[3220]   c971      1
    x[3221]   c204_1    -148
    x[3221]   c249_1    -124
    x[3221]   c967      -1
    x[3221]   c972      1
    x[3222]   c205_1    -124
    x[3222]   c250_1    -148
    x[3222]   c968      1
    x[3222]   c969      -1
    x[3223]   c206_1    -124
    x[3223]   c251_1    -148
    x[3223]   c968      1
    x[3223]   c970      -1
    x[3224]   c207_1    -124
    x[3224]   c252_1    -148
    x[3224]   c968      1
    x[3224]   c971      -1
    x[3225]   c210_1    -124
    x[3225]   c255_1    -148
    x[3225]   c968      1
    x[3225]   c972      -1
    x[3226]   c205_1    -148
    x[3226]   c250_1    -124
    x[3226]   c968      -1
    x[3226]   c969      1
    x[3227]   c206_1    -148
    x[3227]   c251_1    -124
    x[3227]   c968      -1
    x[3227]   c970      1
    x[3228]   c207_1    -148
    x[3228]   c252_1    -124
    x[3228]   c968      -1
    x[3228]   c971      1
    x[3229]   c210_1    -148
    x[3229]   c255_1    -124
    x[3229]   c968      -1
    x[3229]   c972      1
    x[3230]   c211_1    -124
    x[3230]   c256_1    -148
    x[3230]   c969      1
    x[3230]   c970      -1
    x[3231]   c212_1    -124
    x[3231]   c257_1    -148
    x[3231]   c969      1
    x[3231]   c971      -1
    x[3232]   c215_1    -124
    x[3232]   c260_1    -148
    x[3232]   c969      1
    x[3232]   c972      -1
    x[3233]   c211_1    -148
    x[3233]   c256_1    -124
    x[3233]   c969      -1
    x[3233]   c970      1
    x[3234]   c212_1    -148
    x[3234]   c257_1    -124
    x[3234]   c969      -1
    x[3234]   c971      1
    x[3235]   c215_1    -148
    x[3235]   c260_1    -124
    x[3235]   c969      -1
    x[3235]   c972      1
    x[3236]   c216_1    -124
    x[3236]   c261_1    -148
    x[3236]   c970      1
    x[3236]   c971      -1
    x[3237]   c219_1    -124
    x[3237]   c264_1    -148
    x[3237]   c970      1
    x[3237]   c972      -1
    x[3238]   c216_1    -148
    x[3238]   c261_1    -124
    x[3238]   c970      -1
    x[3238]   c971      1
    x[3239]   c219_1    -148
    x[3239]   c264_1    -124
    x[3239]   c970      -1
    x[3239]   c972      1
    x[3240]   c222_1    -124
    x[3240]   c267_1    -148
    x[3240]   c971      1
    x[3240]   c972      -1
    x[3241]   c222_1    -148
    x[3241]   c267_1    -124
    x[3241]   c971      -1
    x[3241]   c972      1
    x[3242]   c188_1    -70
    x[3242]   c233_1    -27
    x[3242]   c973      1
    x[3243]   c196_1    -70
    x[3243]   c241_1    -27
    x[3243]   c974      1
    x[3244]   c203_1    -70
    x[3244]   c248_1    -27
    x[3244]   c975      1
    x[3245]   c209_1    -70
    x[3245]   c254_1    -27
    x[3245]   c976      1
    x[3246]   c214_1    -70
    x[3246]   c259_1    -27
    x[3246]   c977      1
    x[3247]   c216_1    -70
    x[3247]   c261_1    -27
    x[3247]   c978      1
    x[3248]   c217_1    -70
    x[3248]   c262_1    -27
    x[3248]   c979      1
    x[3249]   c218_1    -70
    x[3249]   c263_1    -27
    x[3249]   c980      1
    x[3250]   c219_1    -70
    x[3250]   c264_1    -27
    x[3250]   c981      1
    x[3251]   c221_1    -70
    x[3251]   c266_1    -27
    x[3251]   c982      1
    x[3252]   c223_1    -70
    x[3252]   c268_1    -27
    x[3252]   c983      1
    x[3253]   c185_1    -27
    x[3253]   c230_1    -70
    x[3253]   c984      1
    x[3254]   c193_1    -27
    x[3254]   c238_1    -70
    x[3254]   c985      1
    x[3255]   c200_1    -27
    x[3255]   c245_1    -70
    x[3255]   c986      1
    x[3256]   c206_1    -27
    x[3256]   c251_1    -70
    x[3256]   c987      1
    x[3257]   c211_1    -27
    x[3257]   c256_1    -70
    x[3257]   c988      1
    x[3258]   c225_1    -27
    x[3258]   c270_1    -70
    x[3258]   c989      1
    x[3259]   c186_2    1
    x[3259]   c193_2    1
    x[3259]   c225_1    -70
    x[3259]   c270_1    -27
    x[3259]   c990      1
    x[3259]   c999      1
    x[3260]   c187_2    1
    x[3260]   c188_1    -27
    x[3260]   c233_1    -70
    x[3260]   c990      1
    x[3260]   c992      1
    x[3261]   c196_1    -27
    x[3261]   c241_1    -70
    x[3261]   c990      1
    x[3261]   c993      1
    x[3262]   c203_1    -27
    x[3262]   c248_1    -70
    x[3262]   c990      1
    x[3262]   c994      1
    x[3263]   c188_2    1
    x[3263]   c209_1    -27
    x[3263]   c254_1    -70
    x[3263]   c990      1
    x[3263]   c995      1
    x[3264]   c189_2    1
    x[3264]   c214_1    -27
    x[3264]   c259_1    -70
    x[3264]   c990      1
    x[3264]   c996      1
    x[3265]   c186_2    1
    x[3265]   c187_2    1
    x[3265]   c188_2    1
    x[3265]   c189_2    1
    x[3265]   c190_2    1
    x[3265]   c218_1    -27
    x[3265]   c263_1    -70
    x[3265]   c990      1
    x[3265]   c991      1
    x[3266]   c193_2    1
    x[3266]   c221_1    -27
    x[3266]   c266_1    -70
    x[3266]   c990      1
    x[3266]   c997      1
    x[3267]   c190_2    1
    x[3267]   c223_1    -27
    x[3267]   c268_1    -70
    x[3267]   c990      1
    x[3267]   c998      1
    x[3268]   c237_2    1
    x[3268]   c238_2    1
    x[3268]   c239_2    1
    x[3268]   c185_1    -70
    x[3268]   c230_1    -27
    x[3268]   c991      1
    x[3268]   c992      -1
    x[3269]   c237_2    1
    x[3269]   c193_1    -70
    x[3269]   c238_1    -27
    x[3269]   c991      1
    x[3269]   c993      -1
    x[3270]   c238_2    1
    x[3270]   c200_1    -70
    x[3270]   c245_1    -27
    x[3270]   c991      1
    x[3270]   c994      -1
    x[3271]   c206_1    -70
    x[3271]   c251_1    -27
    x[3271]   c991      1
    x[3271]   c995      -1
    x[3272]   c239_2    1
    x[3272]   c211_1    -70
    x[3272]   c256_1    -27
    x[3272]   c991      1
    x[3272]   c996      -1
    x[3273]   c216_1    -27
    x[3273]   c261_1    -70
    x[3273]   c991      1
    x[3273]   c997      -1
    x[3274]   c217_1    -27
    x[3274]   c262_1    -70
    x[3274]   c991      1
    x[3274]   c998      -1
    x[3275]   c219_1    -27
    x[3275]   c264_1    -70
    x[3275]   c991      1
    x[3275]   c999      -1
    x[3276]   c181_1    -27
    x[3276]   c226_1    -70
    x[3276]   c992      1
    x[3276]   c993      -1
    x[3277]   c182_1    -27
    x[3277]   c227_1    -70
    x[3277]   c992      1
    x[3277]   c994      -1
    x[3278]   c183_1    -27
    x[3278]   c228_1    -70
    x[3278]   c992      1
    x[3278]   c995      -1
    x[3279]   c184_1    -27
    x[3279]   c229_1    -70
    x[3279]   c992      1
    x[3279]   c996      -1
    x[3280]   c186_1    -27
    x[3280]   c231_1    -70
    x[3280]   c992      1
    x[3280]   c997      -1
    x[3281]   c187_1    -27
    x[3281]   c232_1    -70
    x[3281]   c992      1
    x[3281]   c998      -1
    x[3282]   c189_1    -27
    x[3282]   c234_1    -70
    x[3282]   c992      1
    x[3282]   c999      -1
    x[3283]   c181_1    -70
    x[3283]   c226_1    -27
    x[3283]   c992      -1
    x[3283]   c993      1
    x[3284]   c182_1    -70
    x[3284]   c227_1    -27
    x[3284]   c992      -1
    x[3284]   c994      1
    x[3285]   c183_1    -70
    x[3285]   c228_1    -27
    x[3285]   c992      -1
    x[3285]   c995      1
    x[3286]   c184_1    -70
    x[3286]   c229_1    -27
    x[3286]   c992      -1
    x[3286]   c996      1
    x[3287]   c186_1    -70
    x[3287]   c231_1    -27
    x[3287]   c992      -1
    x[3287]   c997      1
    x[3288]   c187_1    -70
    x[3288]   c232_1    -27
    x[3288]   c992      -1
    x[3288]   c998      1
    x[3289]   c189_1    -70
    x[3289]   c234_1    -27
    x[3289]   c992      -1
    x[3289]   c999      1
    x[3290]   c190_1    -27
    x[3290]   c235_1    -70
    x[3290]   c993      1
    x[3290]   c994      -1
    x[3291]   c191_1    -27
    x[3291]   c236_1    -70
    x[3291]   c993      1
    x[3291]   c995      -1
    x[3292]   c192_1    -27
    x[3292]   c237_1    -70
    x[3292]   c993      1
    x[3292]   c996      -1
    x[3293]   c194_1    -27
    x[3293]   c239_1    -70
    x[3293]   c993      1
    x[3293]   c997      -1
    x[3294]   c195_1    -27
    x[3294]   c240_1    -70
    x[3294]   c993      1
    x[3294]   c998      -1
    x[3295]   c197_1    -27
    x[3295]   c242_1    -70
    x[3295]   c993      1
    x[3295]   c999      -1
    x[3296]   c190_1    -70
    x[3296]   c235_1    -27
    x[3296]   c993      -1
    x[3296]   c994      1
    x[3297]   c191_1    -70
    x[3297]   c236_1    -27
    x[3297]   c993      -1
    x[3297]   c995      1
    x[3298]   c192_1    -70
    x[3298]   c237_1    -27
    x[3298]   c993      -1
    x[3298]   c996      1
    x[3299]   c194_1    -70
    x[3299]   c239_1    -27
    x[3299]   c993      -1
    x[3299]   c997      1
    x[3300]   c195_1    -70
    x[3300]   c240_1    -27
    x[3300]   c993      -1
    x[3300]   c998      1
    x[3301]   c197_1    -70
    x[3301]   c242_1    -27
    x[3301]   c993      -1
    x[3301]   c999      1
    x[3302]   c198_1    -27
    x[3302]   c243_1    -70
    x[3302]   c994      1
    x[3302]   c995      -1
    x[3303]   c199_1    -27
    x[3303]   c244_1    -70
    x[3303]   c994      1
    x[3303]   c996      -1
    x[3304]   c201_1    -27
    x[3304]   c246_1    -70
    x[3304]   c994      1
    x[3304]   c997      -1
    x[3305]   c202_1    -27
    x[3305]   c247_1    -70
    x[3305]   c994      1
    x[3305]   c998      -1
    x[3306]   c204_1    -27
    x[3306]   c249_1    -70
    x[3306]   c994      1
    x[3306]   c999      -1
    x[3307]   c198_1    -70
    x[3307]   c243_1    -27
    x[3307]   c994      -1
    x[3307]   c995      1
    x[3308]   c199_1    -70
    x[3308]   c244_1    -27
    x[3308]   c994      -1
    x[3308]   c996      1
    x[3309]   c201_1    -70
    x[3309]   c246_1    -27
    x[3309]   c994      -1
    x[3309]   c997      1
    x[3310]   c202_1    -70
    x[3310]   c247_1    -27
    x[3310]   c994      -1
    x[3310]   c998      1
    x[3311]   c204_1    -70
    x[3311]   c249_1    -27
    x[3311]   c994      -1
    x[3311]   c999      1
    x[3312]   c205_1    -27
    x[3312]   c250_1    -70
    x[3312]   c995      1
    x[3312]   c996      -1
    x[3313]   c207_1    -27
    x[3313]   c252_1    -70
    x[3313]   c995      1
    x[3313]   c997      -1
    x[3314]   c208_1    -27
    x[3314]   c253_1    -70
    x[3314]   c995      1
    x[3314]   c998      -1
    x[3315]   c210_1    -27
    x[3315]   c255_1    -70
    x[3315]   c995      1
    x[3315]   c999      -1
    x[3316]   c205_1    -70
    x[3316]   c250_1    -27
    x[3316]   c995      -1
    x[3316]   c996      1
    x[3317]   c207_1    -70
    x[3317]   c252_1    -27
    x[3317]   c995      -1
    x[3317]   c997      1
    x[3318]   c208_1    -70
    x[3318]   c253_1    -27
    x[3318]   c995      -1
    x[3318]   c998      1
    x[3319]   c210_1    -70
    x[3319]   c255_1    -27
    x[3319]   c995      -1
    x[3319]   c999      1
    x[3320]   c212_1    -27
    x[3320]   c257_1    -70
    x[3320]   c996      1
    x[3320]   c997      -1
    x[3321]   c213_1    -27
    x[3321]   c258_1    -70
    x[3321]   c996      1
    x[3321]   c998      -1
    x[3322]   c215_1    -27
    x[3322]   c260_1    -70
    x[3322]   c996      1
    x[3322]   c999      -1
    x[3323]   c212_1    -70
    x[3323]   c257_1    -27
    x[3323]   c996      -1
    x[3323]   c997      1
    x[3324]   c213_1    -70
    x[3324]   c258_1    -27
    x[3324]   c996      -1
    x[3324]   c998      1
    x[3325]   c215_1    -70
    x[3325]   c260_1    -27
    x[3325]   c996      -1
    x[3325]   c999      1
    x[3326]   c220_1    -27
    x[3326]   c265_1    -70
    x[3326]   c997      1
    x[3326]   c998      -1
    x[3327]   c222_1    -27
    x[3327]   c267_1    -70
    x[3327]   c997      1
    x[3327]   c999      -1
    x[3328]   c220_1    -70
    x[3328]   c265_1    -27
    x[3328]   c997      -1
    x[3328]   c998      1
    x[3329]   c222_1    -70
    x[3329]   c267_1    -27
    x[3329]   c997      -1
    x[3329]   c999      1
    x[3330]   c224_1    -27
    x[3330]   c269_1    -70
    x[3330]   c998      1
    x[3330]   c999      -1
    x[3331]   c224_1    -70
    x[3331]   c269_1    -27
    x[3331]   c998      -1
    x[3331]   c999      1
    x[3332]   c186_1    -115
    x[3332]   c231_1    -104
    x[3332]   c1000     1
    x[3333]   c194_1    -115
    x[3333]   c239_1    -104
    x[3333]   c1001     1
    x[3334]   c201_1    -115
    x[3334]   c246_1    -104
    x[3334]   c1002     1
    x[3335]   c207_1    -115
    x[3335]   c252_1    -104
    x[3335]   c1003     1
    x[3336]   c212_1    -115
    x[3336]   c257_1    -104
    x[3336]   c1004     1
    x[3337]   c216_1    -115
    x[3337]   c261_1    -104
    x[3337]   c1005     1
    x[3338]   c223_1    -115
    x[3338]   c268_1    -104
    x[3338]   c1006     1
    x[3339]   c224_1    -115
    x[3339]   c269_1    -104
    x[3339]   c1007     1
    x[3340]   c187_1    -104
    x[3340]   c232_1    -115
    x[3340]   c1008     1
    x[3341]   c195_1    -104
    x[3341]   c240_1    -115
    x[3341]   c1009     1
    x[3342]   c202_1    -104
    x[3342]   c247_1    -115
    x[3342]   c1010     1
    x[3343]   c208_1    -104
    x[3343]   c253_1    -115
    x[3343]   c1011     1
    x[3344]   c213_1    -104
    x[3344]   c258_1    -115
    x[3344]   c1012     1
    x[3345]   c217_1    -104
    x[3345]   c262_1    -115
    x[3345]   c1013     1
    x[3346]   c220_1    -104
    x[3346]   c265_1    -115
    x[3346]   c1014     1
    x[3347]   c221_1    -104
    x[3347]   c266_1    -115
    x[3347]   c1015     1
    x[3348]   c222_1    -104
    x[3348]   c267_1    -115
    x[3348]   c1016     1
    x[3349]   c280_1    1
    x[3349]   c220_1    -115
    x[3349]   c265_1    -104
    x[3349]   c1017     1
    x[3349]   c1018     1
    x[3350]   c221_1    -115
    x[3350]   c266_1    -104
    x[3350]   c1017     1
    x[3350]   c1025     1
    x[3351]   c222_1    -115
    x[3351]   c267_1    -104
    x[3351]   c1017     1
    x[3351]   c1026     1
    x[3352]   c186_1    -104
    x[3352]   c231_1    -115
    x[3352]   c1017     1
    x[3352]   c1019     1
    x[3353]   c194_1    -104
    x[3353]   c239_1    -115
    x[3353]   c1017     1
    x[3353]   c1020     1
    x[3354]   c201_1    -104
    x[3354]   c246_1    -115
    x[3354]   c1017     1
    x[3354]   c1021     1
    x[3355]   c280_1    1
    x[3355]   c207_1    -104
    x[3355]   c252_1    -115
    x[3355]   c1017     1
    x[3355]   c1022     1
    x[3356]   c212_1    -104
    x[3356]   c257_1    -115
    x[3356]   c1017     1
    x[3356]   c1023     1
    x[3357]   c216_1    -104
    x[3357]   c261_1    -115
    x[3357]   c1017     1
    x[3357]   c1024     1
    x[3358]   c19_2     1
    x[3358]   c20_2     1
    x[3358]   c21_2     1
    x[3358]   c22_2     1
    x[3358]   c187_1    -115
    x[3358]   c232_1    -104
    x[3358]   c1018     1
    x[3358]   c1019     -1
    x[3359]   c19_2     1
    x[3359]   c195_1    -115
    x[3359]   c240_1    -104
    x[3359]   c1018     1
    x[3359]   c1020     -1
    x[3360]   c20_2     1
    x[3360]   c202_1    -115
    x[3360]   c247_1    -104
    x[3360]   c1018     1
    x[3360]   c1021     -1
    x[3361]   c208_1    -115
    x[3361]   c253_1    -104
    x[3361]   c1018     1
    x[3361]   c1022     -1
    x[3362]   c21_2     1
    x[3362]   c213_1    -115
    x[3362]   c258_1    -104
    x[3362]   c1018     1
    x[3362]   c1023     -1
    x[3363]   c22_2     1
    x[3363]   c217_1    -115
    x[3363]   c262_1    -104
    x[3363]   c1018     1
    x[3363]   c1024     -1
    x[3364]   c223_1    -104
    x[3364]   c268_1    -115
    x[3364]   c1018     1
    x[3364]   c1025     -1
    x[3365]   c224_1    -104
    x[3365]   c269_1    -115
    x[3365]   c1018     1
    x[3365]   c1026     -1
    x[3366]   c181_1    -104
    x[3366]   c226_1    -115
    x[3366]   c1019     1
    x[3366]   c1020     -1
    x[3367]   c182_1    -104
    x[3367]   c227_1    -115
    x[3367]   c1019     1
    x[3367]   c1021     -1
    x[3368]   c183_1    -104
    x[3368]   c228_1    -115
    x[3368]   c1019     1
    x[3368]   c1022     -1
    x[3369]   c184_1    -104
    x[3369]   c229_1    -115
    x[3369]   c1019     1
    x[3369]   c1023     -1
    x[3370]   c185_1    -104
    x[3370]   c230_1    -115
    x[3370]   c1019     1
    x[3370]   c1024     -1
    x[3371]   c188_1    -104
    x[3371]   c233_1    -115
    x[3371]   c1019     1
    x[3371]   c1025     -1
    x[3372]   c189_1    -104
    x[3372]   c234_1    -115
    x[3372]   c1019     1
    x[3372]   c1026     -1
    x[3373]   c181_1    -115
    x[3373]   c226_1    -104
    x[3373]   c1019     -1
    x[3373]   c1020     1
    x[3374]   c182_1    -115
    x[3374]   c227_1    -104
    x[3374]   c1019     -1
    x[3374]   c1021     1
    x[3375]   c183_1    -115
    x[3375]   c228_1    -104
    x[3375]   c1019     -1
    x[3375]   c1022     1
    x[3376]   c184_1    -115
    x[3376]   c229_1    -104
    x[3376]   c1019     -1
    x[3376]   c1023     1
    x[3377]   c185_1    -115
    x[3377]   c230_1    -104
    x[3377]   c1019     -1
    x[3377]   c1024     1
    x[3378]   c188_1    -115
    x[3378]   c233_1    -104
    x[3378]   c1019     -1
    x[3378]   c1025     1
    x[3379]   c189_1    -115
    x[3379]   c234_1    -104
    x[3379]   c1019     -1
    x[3379]   c1026     1
    x[3380]   c190_1    -104
    x[3380]   c235_1    -115
    x[3380]   c1020     1
    x[3380]   c1021     -1
    x[3381]   c191_1    -104
    x[3381]   c236_1    -115
    x[3381]   c1020     1
    x[3381]   c1022     -1
    x[3382]   c192_1    -104
    x[3382]   c237_1    -115
    x[3382]   c1020     1
    x[3382]   c1023     -1
    x[3383]   c193_1    -104
    x[3383]   c238_1    -115
    x[3383]   c1020     1
    x[3383]   c1024     -1
    x[3384]   c196_1    -104
    x[3384]   c241_1    -115
    x[3384]   c1020     1
    x[3384]   c1025     -1
    x[3385]   c197_1    -104
    x[3385]   c242_1    -115
    x[3385]   c1020     1
    x[3385]   c1026     -1
    x[3386]   c190_1    -115
    x[3386]   c235_1    -104
    x[3386]   c1020     -1
    x[3386]   c1021     1
    x[3387]   c191_1    -115
    x[3387]   c236_1    -104
    x[3387]   c1020     -1
    x[3387]   c1022     1
    x[3388]   c192_1    -115
    x[3388]   c237_1    -104
    x[3388]   c1020     -1
    x[3388]   c1023     1
    x[3389]   c193_1    -115
    x[3389]   c238_1    -104
    x[3389]   c1020     -1
    x[3389]   c1024     1
    x[3390]   c196_1    -115
    x[3390]   c241_1    -104
    x[3390]   c1020     -1
    x[3390]   c1025     1
    x[3391]   c197_1    -115
    x[3391]   c242_1    -104
    x[3391]   c1020     -1
    x[3391]   c1026     1
    x[3392]   c198_1    -104
    x[3392]   c243_1    -115
    x[3392]   c1021     1
    x[3392]   c1022     -1
    x[3393]   c199_1    -104
    x[3393]   c244_1    -115
    x[3393]   c1021     1
    x[3393]   c1023     -1
    x[3394]   c200_1    -104
    x[3394]   c245_1    -115
    x[3394]   c1021     1
    x[3394]   c1024     -1
    x[3395]   c203_1    -104
    x[3395]   c248_1    -115
    x[3395]   c1021     1
    x[3395]   c1025     -1
    x[3396]   c204_1    -104
    x[3396]   c249_1    -115
    x[3396]   c1021     1
    x[3396]   c1026     -1
    x[3397]   c198_1    -115
    x[3397]   c243_1    -104
    x[3397]   c1021     -1
    x[3397]   c1022     1
    x[3398]   c199_1    -115
    x[3398]   c244_1    -104
    x[3398]   c1021     -1
    x[3398]   c1023     1
    x[3399]   c200_1    -115
    x[3399]   c245_1    -104
    x[3399]   c1021     -1
    x[3399]   c1024     1
    x[3400]   c203_1    -115
    x[3400]   c248_1    -104
    x[3400]   c1021     -1
    x[3400]   c1025     1
    x[3401]   c204_1    -115
    x[3401]   c249_1    -104
    x[3401]   c1021     -1
    x[3401]   c1026     1
    x[3402]   c205_1    -104
    x[3402]   c250_1    -115
    x[3402]   c1022     1
    x[3402]   c1023     -1
    x[3403]   c206_1    -104
    x[3403]   c251_1    -115
    x[3403]   c1022     1
    x[3403]   c1024     -1
    x[3404]   c209_1    -104
    x[3404]   c254_1    -115
    x[3404]   c1022     1
    x[3404]   c1025     -1
    x[3405]   c210_1    -104
    x[3405]   c255_1    -115
    x[3405]   c1022     1
    x[3405]   c1026     -1
    x[3406]   c205_1    -115
    x[3406]   c250_1    -104
    x[3406]   c1022     -1
    x[3406]   c1023     1
    x[3407]   c206_1    -115
    x[3407]   c251_1    -104
    x[3407]   c1022     -1
    x[3407]   c1024     1
    x[3408]   c209_1    -115
    x[3408]   c254_1    -104
    x[3408]   c1022     -1
    x[3408]   c1025     1
    x[3409]   c210_1    -115
    x[3409]   c255_1    -104
    x[3409]   c1022     -1
    x[3409]   c1026     1
    x[3410]   c211_1    -104
    x[3410]   c256_1    -115
    x[3410]   c1023     1
    x[3410]   c1024     -1
    x[3411]   c214_1    -104
    x[3411]   c259_1    -115
    x[3411]   c1023     1
    x[3411]   c1025     -1
    x[3412]   c215_1    -104
    x[3412]   c260_1    -115
    x[3412]   c1023     1
    x[3412]   c1026     -1
    x[3413]   c211_1    -115
    x[3413]   c256_1    -104
    x[3413]   c1023     -1
    x[3413]   c1024     1
    x[3414]   c214_1    -115
    x[3414]   c259_1    -104
    x[3414]   c1023     -1
    x[3414]   c1025     1
    x[3415]   c215_1    -115
    x[3415]   c260_1    -104
    x[3415]   c1023     -1
    x[3415]   c1026     1
    x[3416]   c218_1    -104
    x[3416]   c263_1    -115
    x[3416]   c1024     1
    x[3416]   c1025     -1
    x[3417]   c219_1    -104
    x[3417]   c264_1    -115
    x[3417]   c1024     1
    x[3417]   c1026     -1
    x[3418]   c218_1    -115
    x[3418]   c263_1    -104
    x[3418]   c1024     -1
    x[3418]   c1025     1
    x[3419]   c219_1    -115
    x[3419]   c264_1    -104
    x[3419]   c1024     -1
    x[3419]   c1026     1
    x[3420]   c225_1    -104
    x[3420]   c270_1    -115
    x[3420]   c1025     1
    x[3420]   c1026     -1
    x[3421]   c225_1    -115
    x[3421]   c270_1    -104
    x[3421]   c1025     -1
    x[3421]   c1026     1
    x[3422]   c184_1    -119
    x[3422]   c229_1    -51
    x[3422]   c1027     1
    x[3423]   c192_1    -119
    x[3423]   c237_1    -51
    x[3423]   c1028     1
    x[3424]   c199_1    -119
    x[3424]   c244_1    -51
    x[3424]   c1029     1
    x[3425]   c205_1    -119
    x[3425]   c250_1    -51
    x[3425]   c1030     1
    x[3426]   c216_1    -119
    x[3426]   c261_1    -51
    x[3426]   c1031     1
    x[3427]   c217_1    -119
    x[3427]   c262_1    -51
    x[3427]   c1032     1
    x[3428]   c218_1    -119
    x[3428]   c263_1    -51
    x[3428]   c1033     1
    x[3429]   c219_1    -119
    x[3429]   c264_1    -51
    x[3429]   c1034     1
    x[3430]   c185_1    -51
    x[3430]   c230_1    -119
    x[3430]   c1035     1
    x[3431]   c193_1    -51
    x[3431]   c238_1    -119
    x[3431]   c1036     1
    x[3432]   c200_1    -51
    x[3432]   c245_1    -119
    x[3432]   c1037     1
    x[3433]   c206_1    -51
    x[3433]   c251_1    -119
    x[3433]   c1038     1
    x[3434]   c211_1    -51
    x[3434]   c256_1    -119
    x[3434]   c1039     1
    x[3435]   c212_1    -51
    x[3435]   c257_1    -119
    x[3435]   c1040     1
    x[3436]   c213_1    -51
    x[3436]   c258_1    -119
    x[3436]   c1041     1
    x[3437]   c214_1    -51
    x[3437]   c259_1    -119
    x[3437]   c1042     1
    x[3438]   c215_1    -51
    x[3438]   c260_1    -119
    x[3438]   c1043     1
    x[3439]   c96_2     1
    x[3439]   c97_2     1
    x[3439]   c98_2     1
    x[3439]   c99_2     1
    x[3439]   c100_2    1
    x[3439]   c211_1    -119
    x[3439]   c256_1    -51
    x[3439]   c1044     1
    x[3439]   c1045     1
    x[3440]   c96_2     1
    x[3440]   c212_1    -119
    x[3440]   c257_1    -51
    x[3440]   c1044     1
    x[3440]   c1050     1
    x[3441]   c97_2     1
    x[3441]   c213_1    -119
    x[3441]   c258_1    -51
    x[3441]   c1044     1
    x[3441]   c1051     1
    x[3442]   c98_2     1
    x[3442]   c214_1    -119
    x[3442]   c259_1    -51
    x[3442]   c1044     1
    x[3442]   c1052     1
    x[3443]   c99_2     1
    x[3443]   c215_1    -119
    x[3443]   c260_1    -51
    x[3443]   c1044     1
    x[3443]   c1053     1
    x[3444]   c100_2    1
    x[3444]   c184_1    -51
    x[3444]   c229_1    -119
    x[3444]   c1044     1
    x[3444]   c1046     1
    x[3445]   c192_1    -51
    x[3445]   c237_1    -119
    x[3445]   c1044     1
    x[3445]   c1047     1
    x[3446]   c199_1    -51
    x[3446]   c244_1    -119
    x[3446]   c1044     1
    x[3446]   c1048     1
    x[3447]   c205_1    -51
    x[3447]   c250_1    -119
    x[3447]   c1044     1
    x[3447]   c1049     1
    x[3448]   c167_2    1
    x[3448]   c168_2    1
    x[3448]   c169_2    1
    x[3448]   c170_2    1
    x[3448]   c171_2    1
    x[3448]   c185_1    -119
    x[3448]   c230_1    -51
    x[3448]   c1045     1
    x[3448]   c1046     -1
    x[3449]   c193_1    -119
    x[3449]   c238_1    -51
    x[3449]   c1045     1
    x[3449]   c1047     -1
    x[3450]   c200_1    -119
    x[3450]   c245_1    -51
    x[3450]   c1045     1
    x[3450]   c1048     -1
    x[3451]   c167_2    1
    x[3451]   c206_1    -119
    x[3451]   c251_1    -51
    x[3451]   c1045     1
    x[3451]   c1049     -1
    x[3452]   c168_2    1
    x[3452]   c216_1    -51
    x[3452]   c261_1    -119
    x[3452]   c1045     1
    x[3452]   c1050     -1
    x[3453]   c169_2    1
    x[3453]   c217_1    -51
    x[3453]   c262_1    -119
    x[3453]   c1045     1
    x[3453]   c1051     -1
    x[3454]   c170_2    1
    x[3454]   c218_1    -51
    x[3454]   c263_1    -119
    x[3454]   c1045     1
    x[3454]   c1052     -1
    x[3455]   c171_2    1
    x[3455]   c219_1    -51
    x[3455]   c264_1    -119
    x[3455]   c1045     1
    x[3455]   c1053     -1
    x[3456]   c181_1    -51
    x[3456]   c226_1    -119
    x[3456]   c1046     1
    x[3456]   c1047     -1
    x[3457]   c182_1    -51
    x[3457]   c227_1    -119
    x[3457]   c1046     1
    x[3457]   c1048     -1
    x[3458]   c183_1    -51
    x[3458]   c228_1    -119
    x[3458]   c1046     1
    x[3458]   c1049     -1
    x[3459]   c186_1    -51
    x[3459]   c231_1    -119
    x[3459]   c1046     1
    x[3459]   c1050     -1
    x[3460]   c187_1    -51
    x[3460]   c232_1    -119
    x[3460]   c1046     1
    x[3460]   c1051     -1
    x[3461]   c188_1    -51
    x[3461]   c233_1    -119
    x[3461]   c1046     1
    x[3461]   c1052     -1
    x[3462]   c189_1    -51
    x[3462]   c234_1    -119
    x[3462]   c1046     1
    x[3462]   c1053     -1
    x[3463]   c181_1    -119
    x[3463]   c226_1    -51
    x[3463]   c1046     -1
    x[3463]   c1047     1
    x[3464]   c182_1    -119
    x[3464]   c227_1    -51
    x[3464]   c1046     -1
    x[3464]   c1048     1
    x[3465]   c183_1    -119
    x[3465]   c228_1    -51
    x[3465]   c1046     -1
    x[3465]   c1049     1
    x[3466]   c186_1    -119
    x[3466]   c231_1    -51
    x[3466]   c1046     -1
    x[3466]   c1050     1
    x[3467]   c187_1    -119
    x[3467]   c232_1    -51
    x[3467]   c1046     -1
    x[3467]   c1051     1
    x[3468]   c188_1    -119
    x[3468]   c233_1    -51
    x[3468]   c1046     -1
    x[3468]   c1052     1
    x[3469]   c189_1    -119
    x[3469]   c234_1    -51
    x[3469]   c1046     -1
    x[3469]   c1053     1
    x[3470]   c190_1    -51
    x[3470]   c235_1    -119
    x[3470]   c1047     1
    x[3470]   c1048     -1
    x[3471]   c191_1    -51
    x[3471]   c236_1    -119
    x[3471]   c1047     1
    x[3471]   c1049     -1
    x[3472]   c194_1    -51
    x[3472]   c239_1    -119
    x[3472]   c1047     1
    x[3472]   c1050     -1
    x[3473]   c195_1    -51
    x[3473]   c240_1    -119
    x[3473]   c1047     1
    x[3473]   c1051     -1
    x[3474]   c196_1    -51
    x[3474]   c241_1    -119
    x[3474]   c1047     1
    x[3474]   c1052     -1
    x[3475]   c197_1    -51
    x[3475]   c242_1    -119
    x[3475]   c1047     1
    x[3475]   c1053     -1
    x[3476]   c190_1    -119
    x[3476]   c235_1    -51
    x[3476]   c1047     -1
    x[3476]   c1048     1
    x[3477]   c191_1    -119
    x[3477]   c236_1    -51
    x[3477]   c1047     -1
    x[3477]   c1049     1
    x[3478]   c194_1    -119
    x[3478]   c239_1    -51
    x[3478]   c1047     -1
    x[3478]   c1050     1
    x[3479]   c195_1    -119
    x[3479]   c240_1    -51
    x[3479]   c1047     -1
    x[3479]   c1051     1
    x[3480]   c196_1    -119
    x[3480]   c241_1    -51
    x[3480]   c1047     -1
    x[3480]   c1052     1
    x[3481]   c197_1    -119
    x[3481]   c242_1    -51
    x[3481]   c1047     -1
    x[3481]   c1053     1
    x[3482]   c198_1    -51
    x[3482]   c243_1    -119
    x[3482]   c1048     1
    x[3482]   c1049     -1
    x[3483]   c201_1    -51
    x[3483]   c246_1    -119
    x[3483]   c1048     1
    x[3483]   c1050     -1
    x[3484]   c202_1    -51
    x[3484]   c247_1    -119
    x[3484]   c1048     1
    x[3484]   c1051     -1
    x[3485]   c203_1    -51
    x[3485]   c248_1    -119
    x[3485]   c1048     1
    x[3485]   c1052     -1
    x[3486]   c204_1    -51
    x[3486]   c249_1    -119
    x[3486]   c1048     1
    x[3486]   c1053     -1
    x[3487]   c198_1    -119
    x[3487]   c243_1    -51
    x[3487]   c1048     -1
    x[3487]   c1049     1
    x[3488]   c201_1    -119
    x[3488]   c246_1    -51
    x[3488]   c1048     -1
    x[3488]   c1050     1
    x[3489]   c202_1    -119
    x[3489]   c247_1    -51
    x[3489]   c1048     -1
    x[3489]   c1051     1
    x[3490]   c203_1    -119
    x[3490]   c248_1    -51
    x[3490]   c1048     -1
    x[3490]   c1052     1
    x[3491]   c204_1    -119
    x[3491]   c249_1    -51
    x[3491]   c1048     -1
    x[3491]   c1053     1
    x[3492]   c207_1    -51
    x[3492]   c252_1    -119
    x[3492]   c1049     1
    x[3492]   c1050     -1
    x[3493]   c208_1    -51
    x[3493]   c253_1    -119
    x[3493]   c1049     1
    x[3493]   c1051     -1
    x[3494]   c209_1    -51
    x[3494]   c254_1    -119
    x[3494]   c1049     1
    x[3494]   c1052     -1
    x[3495]   c210_1    -51
    x[3495]   c255_1    -119
    x[3495]   c1049     1
    x[3495]   c1053     -1
    x[3496]   c207_1    -119
    x[3496]   c252_1    -51
    x[3496]   c1049     -1
    x[3496]   c1050     1
    x[3497]   c208_1    -119
    x[3497]   c253_1    -51
    x[3497]   c1049     -1
    x[3497]   c1051     1
    x[3498]   c209_1    -119
    x[3498]   c254_1    -51
    x[3498]   c1049     -1
    x[3498]   c1052     1
    x[3499]   c210_1    -119
    x[3499]   c255_1    -51
    x[3499]   c1049     -1
    x[3499]   c1053     1
    x[3500]   c220_1    -51
    x[3500]   c265_1    -119
    x[3500]   c1050     1
    x[3500]   c1051     -1
    x[3501]   c221_1    -51
    x[3501]   c266_1    -119
    x[3501]   c1050     1
    x[3501]   c1052     -1
    x[3502]   c222_1    -51
    x[3502]   c267_1    -119
    x[3502]   c1050     1
    x[3502]   c1053     -1
    x[3503]   c220_1    -119
    x[3503]   c265_1    -51
    x[3503]   c1050     -1
    x[3503]   c1051     1
    x[3504]   c221_1    -119
    x[3504]   c266_1    -51
    x[3504]   c1050     -1
    x[3504]   c1052     1
    x[3505]   c222_1    -119
    x[3505]   c267_1    -51
    x[3505]   c1050     -1
    x[3505]   c1053     1
    x[3506]   c223_1    -51
    x[3506]   c268_1    -119
    x[3506]   c1051     1
    x[3506]   c1052     -1
    x[3507]   c224_1    -51
    x[3507]   c269_1    -119
    x[3507]   c1051     1
    x[3507]   c1053     -1
    x[3508]   c223_1    -119
    x[3508]   c268_1    -51
    x[3508]   c1051     -1
    x[3508]   c1052     1
    x[3509]   c224_1    -119
    x[3509]   c269_1    -51
    x[3509]   c1051     -1
    x[3509]   c1053     1
    x[3510]   c225_1    -51
    x[3510]   c270_1    -119
    x[3510]   c1052     1
    x[3510]   c1053     -1
    x[3511]   c225_1    -119
    x[3511]   c270_1    -51
    x[3511]   c1052     -1
    x[3511]   c1053     1
    x[3512]   c184_1    -170
    x[3512]   c229_1    -111
    x[3512]   c1054     1
    x[3513]   c192_1    -170
    x[3513]   c237_1    -111
    x[3513]   c1055     1
    x[3514]   c199_1    -170
    x[3514]   c244_1    -111
    x[3514]   c1056     1
    x[3515]   c205_1    -170
    x[3515]   c250_1    -111
    x[3515]   c1057     1
    x[3516]   c220_1    -170
    x[3516]   c265_1    -111
    x[3516]   c1058     1
    x[3517]   c221_1    -170
    x[3517]   c266_1    -111
    x[3517]   c1059     1
    x[3518]   c222_1    -170
    x[3518]   c267_1    -111
    x[3518]   c1060     1
    x[3519]   c186_1    -111
    x[3519]   c231_1    -170
    x[3519]   c1061     1
    x[3520]   c194_1    -111
    x[3520]   c239_1    -170
    x[3520]   c1062     1
    x[3521]   c201_1    -111
    x[3521]   c246_1    -170
    x[3521]   c1063     1
    x[3522]   c207_1    -111
    x[3522]   c252_1    -170
    x[3522]   c1064     1
    x[3523]   c211_1    -111
    x[3523]   c256_1    -170
    x[3523]   c1065     1
    x[3524]   c212_1    -111
    x[3524]   c257_1    -170
    x[3524]   c1066     1
    x[3525]   c213_1    -111
    x[3525]   c258_1    -170
    x[3525]   c1067     1
    x[3526]   c214_1    -111
    x[3526]   c259_1    -170
    x[3526]   c1068     1
    x[3527]   c215_1    -111
    x[3527]   c260_1    -170
    x[3527]   c1069     1
    x[3528]   c216_1    -111
    x[3528]   c261_1    -170
    x[3528]   c1070     1
    x[3529]   c256_2    1
    x[3529]   c211_1    -170
    x[3529]   c256_1    -111
    x[3529]   c1071     1
    x[3529]   c1077     1
    x[3530]   c256_2    1
    x[3530]   c257_2    1
    x[3530]   c258_2    1
    x[3530]   c259_2    1
    x[3530]   c212_1    -170
    x[3530]   c257_1    -111
    x[3530]   c1071     1
    x[3530]   c1072     1
    x[3531]   c213_1    -170
    x[3531]   c258_1    -111
    x[3531]   c1071     1
    x[3531]   c1078     1
    x[3532]   c257_2    1
    x[3532]   c214_1    -170
    x[3532]   c259_1    -111
    x[3532]   c1071     1
    x[3532]   c1079     1
    x[3533]   c258_2    1
    x[3533]   c215_1    -170
    x[3533]   c260_1    -111
    x[3533]   c1071     1
    x[3533]   c1080     1
    x[3534]   c184_1    -111
    x[3534]   c229_1    -170
    x[3534]   c1071     1
    x[3534]   c1073     1
    x[3535]   c192_1    -111
    x[3535]   c237_1    -170
    x[3535]   c1071     1
    x[3535]   c1074     1
    x[3536]   c259_2    1
    x[3536]   c199_1    -111
    x[3536]   c244_1    -170
    x[3536]   c1071     1
    x[3536]   c1075     1
    x[3537]   c205_1    -111
    x[3537]   c250_1    -170
    x[3537]   c1071     1
    x[3537]   c1076     1
    x[3538]   c186_1    -170
    x[3538]   c231_1    -111
    x[3538]   c1072     1
    x[3538]   c1073     -1
    x[3539]   c194_1    -170
    x[3539]   c239_1    -111
    x[3539]   c1072     1
    x[3539]   c1074     -1
    x[3540]   c201_1    -170
    x[3540]   c246_1    -111
    x[3540]   c1072     1
    x[3540]   c1075     -1
    x[3541]   c207_1    -170
    x[3541]   c252_1    -111
    x[3541]   c1072     1
    x[3541]   c1076     -1
    x[3542]   c216_1    -170
    x[3542]   c261_1    -111
    x[3542]   c1072     1
    x[3542]   c1077     -1
    x[3543]   c220_1    -111
    x[3543]   c265_1    -170
    x[3543]   c1072     1
    x[3543]   c1078     -1
    x[3544]   c221_1    -111
    x[3544]   c266_1    -170
    x[3544]   c1072     1
    x[3544]   c1079     -1
    x[3545]   c222_1    -111
    x[3545]   c267_1    -170
    x[3545]   c1072     1
    x[3545]   c1080     -1
    x[3546]   c181_1    -111
    x[3546]   c226_1    -170
    x[3546]   c1073     1
    x[3546]   c1074     -1
    x[3547]   c182_1    -111
    x[3547]   c227_1    -170
    x[3547]   c1073     1
    x[3547]   c1075     -1
    x[3548]   c183_1    -111
    x[3548]   c228_1    -170
    x[3548]   c1073     1
    x[3548]   c1076     -1
    x[3549]   c185_1    -111
    x[3549]   c230_1    -170
    x[3549]   c1073     1
    x[3549]   c1077     -1
    x[3550]   c187_1    -111
    x[3550]   c232_1    -170
    x[3550]   c1073     1
    x[3550]   c1078     -1
    x[3551]   c188_1    -111
    x[3551]   c233_1    -170
    x[3551]   c1073     1
    x[3551]   c1079     -1
    x[3552]   c189_1    -111
    x[3552]   c234_1    -170
    x[3552]   c1073     1
    x[3552]   c1080     -1
    x[3553]   c181_1    -170
    x[3553]   c226_1    -111
    x[3553]   c1073     -1
    x[3553]   c1074     1
    x[3554]   c182_1    -170
    x[3554]   c227_1    -111
    x[3554]   c1073     -1
    x[3554]   c1075     1
    x[3555]   c183_1    -170
    x[3555]   c228_1    -111
    x[3555]   c1073     -1
    x[3555]   c1076     1
    x[3556]   c185_1    -170
    x[3556]   c230_1    -111
    x[3556]   c1073     -1
    x[3556]   c1077     1
    x[3557]   c187_1    -170
    x[3557]   c232_1    -111
    x[3557]   c1073     -1
    x[3557]   c1078     1
    x[3558]   c188_1    -170
    x[3558]   c233_1    -111
    x[3558]   c1073     -1
    x[3558]   c1079     1
    x[3559]   c189_1    -170
    x[3559]   c234_1    -111
    x[3559]   c1073     -1
    x[3559]   c1080     1
    x[3560]   c190_1    -111
    x[3560]   c235_1    -170
    x[3560]   c1074     1
    x[3560]   c1075     -1
    x[3561]   c191_1    -111
    x[3561]   c236_1    -170
    x[3561]   c1074     1
    x[3561]   c1076     -1
    x[3562]   c193_1    -111
    x[3562]   c238_1    -170
    x[3562]   c1074     1
    x[3562]   c1077     -1
    x[3563]   c195_1    -111
    x[3563]   c240_1    -170
    x[3563]   c1074     1
    x[3563]   c1078     -1
    x[3564]   c196_1    -111
    x[3564]   c241_1    -170
    x[3564]   c1074     1
    x[3564]   c1079     -1
    x[3565]   c197_1    -111
    x[3565]   c242_1    -170
    x[3565]   c1074     1
    x[3565]   c1080     -1
    x[3566]   c190_1    -170
    x[3566]   c235_1    -111
    x[3566]   c1074     -1
    x[3566]   c1075     1
    x[3567]   c191_1    -170
    x[3567]   c236_1    -111
    x[3567]   c1074     -1
    x[3567]   c1076     1
    x[3568]   c193_1    -170
    x[3568]   c238_1    -111
    x[3568]   c1074     -1
    x[3568]   c1077     1
    x[3569]   c195_1    -170
    x[3569]   c240_1    -111
    x[3569]   c1074     -1
    x[3569]   c1078     1
    x[3570]   c196_1    -170
    x[3570]   c241_1    -111
    x[3570]   c1074     -1
    x[3570]   c1079     1
    x[3571]   c197_1    -170
    x[3571]   c242_1    -111
    x[3571]   c1074     -1
    x[3571]   c1080     1
    x[3572]   c198_1    -111
    x[3572]   c243_1    -170
    x[3572]   c1075     1
    x[3572]   c1076     -1
    x[3573]   c200_1    -111
    x[3573]   c245_1    -170
    x[3573]   c1075     1
    x[3573]   c1077     -1
    x[3574]   c202_1    -111
    x[3574]   c247_1    -170
    x[3574]   c1075     1
    x[3574]   c1078     -1
    x[3575]   c203_1    -111
    x[3575]   c248_1    -170
    x[3575]   c1075     1
    x[3575]   c1079     -1
    x[3576]   c204_1    -111
    x[3576]   c249_1    -170
    x[3576]   c1075     1
    x[3576]   c1080     -1
    x[3577]   c198_1    -170
    x[3577]   c243_1    -111
    x[3577]   c1075     -1
    x[3577]   c1076     1
    x[3578]   c200_1    -170
    x[3578]   c245_1    -111
    x[3578]   c1075     -1
    x[3578]   c1077     1
    x[3579]   c202_1    -170
    x[3579]   c247_1    -111
    x[3579]   c1075     -1
    x[3579]   c1078     1
    x[3580]   c203_1    -170
    x[3580]   c248_1    -111
    x[3580]   c1075     -1
    x[3580]   c1079     1
    x[3581]   c204_1    -170
    x[3581]   c249_1    -111
    x[3581]   c1075     -1
    x[3581]   c1080     1
    x[3582]   c206_1    -111
    x[3582]   c251_1    -170
    x[3582]   c1076     1
    x[3582]   c1077     -1
    x[3583]   c208_1    -111
    x[3583]   c253_1    -170
    x[3583]   c1076     1
    x[3583]   c1078     -1
    x[3584]   c209_1    -111
    x[3584]   c254_1    -170
    x[3584]   c1076     1
    x[3584]   c1079     -1
    x[3585]   c210_1    -111
    x[3585]   c255_1    -170
    x[3585]   c1076     1
    x[3585]   c1080     -1
    x[3586]   c206_1    -170
    x[3586]   c251_1    -111
    x[3586]   c1076     -1
    x[3586]   c1077     1
    x[3587]   c208_1    -170
    x[3587]   c253_1    -111
    x[3587]   c1076     -1
    x[3587]   c1078     1
    x[3588]   c209_1    -170
    x[3588]   c254_1    -111
    x[3588]   c1076     -1
    x[3588]   c1079     1
    x[3589]   c210_1    -170
    x[3589]   c255_1    -111
    x[3589]   c1076     -1
    x[3589]   c1080     1
    x[3590]   c217_1    -111
    x[3590]   c262_1    -170
    x[3590]   c1077     1
    x[3590]   c1078     -1
    x[3591]   c218_1    -111
    x[3591]   c263_1    -170
    x[3591]   c1077     1
    x[3591]   c1079     -1
    x[3592]   c219_1    -111
    x[3592]   c264_1    -170
    x[3592]   c1077     1
    x[3592]   c1080     -1
    x[3593]   c217_1    -170
    x[3593]   c262_1    -111
    x[3593]   c1077     -1
    x[3593]   c1078     1
    x[3594]   c218_1    -170
    x[3594]   c263_1    -111
    x[3594]   c1077     -1
    x[3594]   c1079     1
    x[3595]   c219_1    -170
    x[3595]   c264_1    -111
    x[3595]   c1077     -1
    x[3595]   c1080     1
    x[3596]   c223_1    -111
    x[3596]   c268_1    -170
    x[3596]   c1078     1
    x[3596]   c1079     -1
    x[3597]   c224_1    -111
    x[3597]   c269_1    -170
    x[3597]   c1078     1
    x[3597]   c1080     -1
    x[3598]   c223_1    -170
    x[3598]   c268_1    -111
    x[3598]   c1078     -1
    x[3598]   c1079     1
    x[3599]   c224_1    -170
    x[3599]   c269_1    -111
    x[3599]   c1078     -1
    x[3599]   c1080     1
    x[3600]   c225_1    -111
    x[3600]   c270_1    -170
    x[3600]   c1079     1
    x[3600]   c1080     -1
    x[3601]   c225_1    -170
    x[3601]   c270_1    -111
    x[3601]   c1079     -1
    x[3601]   c1080     1
    x[3602]   c186_1    -88
    x[3602]   c231_1    -72
    x[3602]   c1081     1
    x[3603]   c194_1    -88
    x[3603]   c239_1    -72
    x[3603]   c1082     1
    x[3604]   c201_1    -88
    x[3604]   c246_1    -72
    x[3604]   c1083     1
    x[3605]   c207_1    -88
    x[3605]   c252_1    -72
    x[3605]   c1084     1
    x[3606]   c212_1    -88
    x[3606]   c257_1    -72
    x[3606]   c1085     1
    x[3607]   c216_1    -88
    x[3607]   c261_1    -72
    x[3607]   c1086     1
    x[3608]   c217_1    -88
    x[3608]   c262_1    -72
    x[3608]   c1087     1
    x[3609]   c218_1    -88
    x[3609]   c263_1    -72
    x[3609]   c1088     1
    x[3610]   c219_1    -88
    x[3610]   c264_1    -72
    x[3610]   c1089     1
    x[3611]   c185_1    -72
    x[3611]   c230_1    -88
    x[3611]   c1090     1
    x[3612]   c193_1    -72
    x[3612]   c238_1    -88
    x[3612]   c1091     1
    x[3613]   c200_1    -72
    x[3613]   c245_1    -88
    x[3613]   c1092     1
    x[3614]   c206_1    -72
    x[3614]   c251_1    -88
    x[3614]   c1093     1
    x[3615]   c211_1    -72
    x[3615]   c256_1    -88
    x[3615]   c1094     1
    x[3616]   c220_1    -72
    x[3616]   c265_1    -88
    x[3616]   c1095     1
    x[3617]   c221_1    -72
    x[3617]   c266_1    -88
    x[3617]   c1096     1
    x[3618]   c222_1    -72
    x[3618]   c267_1    -88
    x[3618]   c1097     1
    x[3619]   c44_2     1
    x[3619]   c220_1    -88
    x[3619]   c265_1    -72
    x[3619]   c1098     1
    x[3619]   c1105     1
    x[3620]   c221_1    -88
    x[3620]   c266_1    -72
    x[3620]   c1098     1
    x[3620]   c1106     1
    x[3621]   c45_2     1
    x[3621]   c222_1    -88
    x[3621]   c267_1    -72
    x[3621]   c1098     1
    x[3621]   c1107     1
    x[3622]   c46_2     1
    x[3622]   c186_1    -72
    x[3622]   c231_1    -88
    x[3622]   c1098     1
    x[3622]   c1100     1
    x[3623]   c194_1    -72
    x[3623]   c239_1    -88
    x[3623]   c1098     1
    x[3623]   c1101     1
    x[3624]   c201_1    -72
    x[3624]   c246_1    -88
    x[3624]   c1098     1
    x[3624]   c1102     1
    x[3625]   c207_1    -72
    x[3625]   c252_1    -88
    x[3625]   c1098     1
    x[3625]   c1103     1
    x[3626]   c212_1    -72
    x[3626]   c257_1    -88
    x[3626]   c1098     1
    x[3626]   c1104     1
    x[3627]   c44_2     1
    x[3627]   c45_2     1
    x[3627]   c46_2     1
    x[3627]   c216_1    -72
    x[3627]   c261_1    -88
    x[3627]   c1098     1
    x[3627]   c1099     1
    x[3628]   c211_2    1
    x[3628]   c212_2    1
    x[3628]   c213_2    1
    x[3628]   c185_1    -88
    x[3628]   c230_1    -72
    x[3628]   c1099     1
    x[3628]   c1100     -1
    x[3629]   c214_2    1
    x[3629]   c193_1    -88
    x[3629]   c238_1    -72
    x[3629]   c1099     1
    x[3629]   c1101     -1
    x[3630]   c211_2    1
    x[3630]   c214_2    1
    x[3630]   c200_1    -88
    x[3630]   c245_1    -72
    x[3630]   c1099     1
    x[3630]   c1102     -1
    x[3631]   c212_2    1
    x[3631]   c206_1    -88
    x[3631]   c251_1    -72
    x[3631]   c1099     1
    x[3631]   c1103     -1
    x[3632]   c211_1    -88
    x[3632]   c256_1    -72
    x[3632]   c1099     1
    x[3632]   c1104     -1
    x[3633]   c217_1    -72
    x[3633]   c262_1    -88
    x[3633]   c1099     1
    x[3633]   c1105     -1
    x[3634]   c213_2    1
    x[3634]   c218_1    -72
    x[3634]   c263_1    -88
    x[3634]   c1099     1
    x[3634]   c1106     -1
    x[3635]   c219_1    -72
    x[3635]   c264_1    -88
    x[3635]   c1099     1
    x[3635]   c1107     -1
    x[3636]   c181_1    -72
    x[3636]   c226_1    -88
    x[3636]   c1100     1
    x[3636]   c1101     -1
    x[3637]   c182_1    -72
    x[3637]   c227_1    -88
    x[3637]   c1100     1
    x[3637]   c1102     -1
    x[3638]   c183_1    -72
    x[3638]   c228_1    -88
    x[3638]   c1100     1
    x[3638]   c1103     -1
    x[3639]   c184_1    -72
    x[3639]   c229_1    -88
    x[3639]   c1100     1
    x[3639]   c1104     -1
    x[3640]   c187_1    -72
    x[3640]   c232_1    -88
    x[3640]   c1100     1
    x[3640]   c1105     -1
    x[3641]   c188_1    -72
    x[3641]   c233_1    -88
    x[3641]   c1100     1
    x[3641]   c1106     -1
    x[3642]   c189_1    -72
    x[3642]   c234_1    -88
    x[3642]   c1100     1
    x[3642]   c1107     -1
    x[3643]   c181_1    -88
    x[3643]   c226_1    -72
    x[3643]   c1100     -1
    x[3643]   c1101     1
    x[3644]   c182_1    -88
    x[3644]   c227_1    -72
    x[3644]   c1100     -1
    x[3644]   c1102     1
    x[3645]   c183_1    -88
    x[3645]   c228_1    -72
    x[3645]   c1100     -1
    x[3645]   c1103     1
    x[3646]   c184_1    -88
    x[3646]   c229_1    -72
    x[3646]   c1100     -1
    x[3646]   c1104     1
    x[3647]   c187_1    -88
    x[3647]   c232_1    -72
    x[3647]   c1100     -1
    x[3647]   c1105     1
    x[3648]   c188_1    -88
    x[3648]   c233_1    -72
    x[3648]   c1100     -1
    x[3648]   c1106     1
    x[3649]   c189_1    -88
    x[3649]   c234_1    -72
    x[3649]   c1100     -1
    x[3649]   c1107     1
    x[3650]   c190_1    -72
    x[3650]   c235_1    -88
    x[3650]   c1101     1
    x[3650]   c1102     -1
    x[3651]   c191_1    -72
    x[3651]   c236_1    -88
    x[3651]   c1101     1
    x[3651]   c1103     -1
    x[3652]   c192_1    -72
    x[3652]   c237_1    -88
    x[3652]   c1101     1
    x[3652]   c1104     -1
    x[3653]   c195_1    -72
    x[3653]   c240_1    -88
    x[3653]   c1101     1
    x[3653]   c1105     -1
    x[3654]   c196_1    -72
    x[3654]   c241_1    -88
    x[3654]   c1101     1
    x[3654]   c1106     -1
    x[3655]   c197_1    -72
    x[3655]   c242_1    -88
    x[3655]   c1101     1
    x[3655]   c1107     -1
    x[3656]   c190_1    -88
    x[3656]   c235_1    -72
    x[3656]   c1101     -1
    x[3656]   c1102     1
    x[3657]   c191_1    -88
    x[3657]   c236_1    -72
    x[3657]   c1101     -1
    x[3657]   c1103     1
    x[3658]   c192_1    -88
    x[3658]   c237_1    -72
    x[3658]   c1101     -1
    x[3658]   c1104     1
    x[3659]   c195_1    -88
    x[3659]   c240_1    -72
    x[3659]   c1101     -1
    x[3659]   c1105     1
    x[3660]   c196_1    -88
    x[3660]   c241_1    -72
    x[3660]   c1101     -1
    x[3660]   c1106     1
    x[3661]   c197_1    -88
    x[3661]   c242_1    -72
    x[3661]   c1101     -1
    x[3661]   c1107     1
    x[3662]   c198_1    -72
    x[3662]   c243_1    -88
    x[3662]   c1102     1
    x[3662]   c1103     -1
    x[3663]   c199_1    -72
    x[3663]   c244_1    -88
    x[3663]   c1102     1
    x[3663]   c1104     -1
    x[3664]   c202_1    -72
    x[3664]   c247_1    -88
    x[3664]   c1102     1
    x[3664]   c1105     -1
    x[3665]   c203_1    -72
    x[3665]   c248_1    -88
    x[3665]   c1102     1
    x[3665]   c1106     -1
    x[3666]   c204_1    -72
    x[3666]   c249_1    -88
    x[3666]   c1102     1
    x[3666]   c1107     -1
    x[3667]   c198_1    -88
    x[3667]   c243_1    -72
    x[3667]   c1102     -1
    x[3667]   c1103     1
    x[3668]   c199_1    -88
    x[3668]   c244_1    -72
    x[3668]   c1102     -1
    x[3668]   c1104     1
    x[3669]   c202_1    -88
    x[3669]   c247_1    -72
    x[3669]   c1102     -1
    x[3669]   c1105     1
    x[3670]   c203_1    -88
    x[3670]   c248_1    -72
    x[3670]   c1102     -1
    x[3670]   c1106     1
    x[3671]   c204_1    -88
    x[3671]   c249_1    -72
    x[3671]   c1102     -1
    x[3671]   c1107     1
    x[3672]   c205_1    -72
    x[3672]   c250_1    -88
    x[3672]   c1103     1
    x[3672]   c1104     -1
    x[3673]   c208_1    -72
    x[3673]   c253_1    -88
    x[3673]   c1103     1
    x[3673]   c1105     -1
    x[3674]   c209_1    -72
    x[3674]   c254_1    -88
    x[3674]   c1103     1
    x[3674]   c1106     -1
    x[3675]   c210_1    -72
    x[3675]   c255_1    -88
    x[3675]   c1103     1
    x[3675]   c1107     -1
    x[3676]   c205_1    -88
    x[3676]   c250_1    -72
    x[3676]   c1103     -1
    x[3676]   c1104     1
    x[3677]   c208_1    -88
    x[3677]   c253_1    -72
    x[3677]   c1103     -1
    x[3677]   c1105     1
    x[3678]   c209_1    -88
    x[3678]   c254_1    -72
    x[3678]   c1103     -1
    x[3678]   c1106     1
    x[3679]   c210_1    -88
    x[3679]   c255_1    -72
    x[3679]   c1103     -1
    x[3679]   c1107     1
    x[3680]   c213_1    -72
    x[3680]   c258_1    -88
    x[3680]   c1104     1
    x[3680]   c1105     -1
    x[3681]   c214_1    -72
    x[3681]   c259_1    -88
    x[3681]   c1104     1
    x[3681]   c1106     -1
    x[3682]   c215_1    -72
    x[3682]   c260_1    -88
    x[3682]   c1104     1
    x[3682]   c1107     -1
    x[3683]   c213_1    -88
    x[3683]   c258_1    -72
    x[3683]   c1104     -1
    x[3683]   c1105     1
    x[3684]   c214_1    -88
    x[3684]   c259_1    -72
    x[3684]   c1104     -1
    x[3684]   c1106     1
    x[3685]   c215_1    -88
    x[3685]   c260_1    -72
    x[3685]   c1104     -1
    x[3685]   c1107     1
    x[3686]   c223_1    -72
    x[3686]   c268_1    -88
    x[3686]   c1105     1
    x[3686]   c1106     -1
    x[3687]   c224_1    -72
    x[3687]   c269_1    -88
    x[3687]   c1105     1
    x[3687]   c1107     -1
    x[3688]   c223_1    -88
    x[3688]   c268_1    -72
    x[3688]   c1105     -1
    x[3688]   c1106     1
    x[3689]   c224_1    -88
    x[3689]   c269_1    -72
    x[3689]   c1105     -1
    x[3689]   c1107     1
    x[3690]   c225_1    -72
    x[3690]   c270_1    -88
    x[3690]   c1106     1
    x[3690]   c1107     -1
    x[3691]   c225_1    -88
    x[3691]   c270_1    -72
    x[3691]   c1106     -1
    x[3691]   c1107     1
    x[3692]   c185_1    -87
    x[3692]   c230_1    -195
    x[3692]   c1108     1
    x[3693]   c193_1    -87
    x[3693]   c238_1    -195
    x[3693]   c1109     1
    x[3694]   c200_1    -87
    x[3694]   c245_1    -195
    x[3694]   c1110     1
    x[3695]   c206_1    -87
    x[3695]   c251_1    -195
    x[3695]   c1111     1
    x[3696]   c211_1    -87
    x[3696]   c256_1    -195
    x[3696]   c1112     1
    x[3697]   c223_1    -87
    x[3697]   c268_1    -195
    x[3697]   c1113     1
    x[3698]   c224_1    -87
    x[3698]   c269_1    -195
    x[3698]   c1114     1
    x[3699]   c187_1    -195
    x[3699]   c232_1    -87
    x[3699]   c1115     1
    x[3700]   c195_1    -195
    x[3700]   c240_1    -87
    x[3700]   c1116     1
    x[3701]   c202_1    -195
    x[3701]   c247_1    -87
    x[3701]   c1117     1
    x[3702]   c208_1    -195
    x[3702]   c253_1    -87
    x[3702]   c1118     1
    x[3703]   c213_1    -195
    x[3703]   c258_1    -87
    x[3703]   c1119     1
    x[3704]   c216_1    -195
    x[3704]   c261_1    -87
    x[3704]   c1120     1
    x[3705]   c217_1    -195
    x[3705]   c262_1    -87
    x[3705]   c1121     1
    x[3706]   c218_1    -195
    x[3706]   c263_1    -87
    x[3706]   c1122     1
    x[3707]   c219_1    -195
    x[3707]   c264_1    -87
    x[3707]   c1123     1
    x[3708]   c220_1    -195
    x[3708]   c265_1    -87
    x[3708]   c1124     1
    x[3709]   c318_1    1
    x[3709]   c216_1    -87
    x[3709]   c261_1    -195
    x[3709]   c1125     1
    x[3709]   c1132     1
    x[3710]   c318_1    1
    x[3710]   c319_1    1
    x[3710]   c320_1    1
    x[3710]   c321_1    1
    x[3710]   c217_1    -87
    x[3710]   c262_1    -195
    x[3710]   c1125     1
    x[3710]   c1126     1
    x[3711]   c218_1    -87
    x[3711]   c263_1    -195
    x[3711]   c1125     1
    x[3711]   c1133     1
    x[3712]   c219_1    -87
    x[3712]   c264_1    -195
    x[3712]   c1125     1
    x[3712]   c1134     1
    x[3713]   c319_1    1
    x[3713]   c185_1    -195
    x[3713]   c230_1    -87
    x[3713]   c1125     1
    x[3713]   c1127     1
    x[3714]   c320_1    1
    x[3714]   c193_1    -195
    x[3714]   c238_1    -87
    x[3714]   c1125     1
    x[3714]   c1128     1
    x[3715]   c200_1    -195
    x[3715]   c245_1    -87
    x[3715]   c1125     1
    x[3715]   c1129     1
    x[3716]   c321_1    1
    x[3716]   c206_1    -195
    x[3716]   c251_1    -87
    x[3716]   c1125     1
    x[3716]   c1130     1
    x[3717]   c211_1    -195
    x[3717]   c256_1    -87
    x[3717]   c1125     1
    x[3717]   c1131     1
    x[3718]   c187_1    -87
    x[3718]   c232_1    -195
    x[3718]   c1126     1
    x[3718]   c1127     -1
    x[3719]   c195_1    -87
    x[3719]   c240_1    -195
    x[3719]   c1126     1
    x[3719]   c1128     -1
    x[3720]   c202_1    -87
    x[3720]   c247_1    -195
    x[3720]   c1126     1
    x[3720]   c1129     -1
    x[3721]   c208_1    -87
    x[3721]   c253_1    -195
    x[3721]   c1126     1
    x[3721]   c1130     -1
    x[3722]   c213_1    -87
    x[3722]   c258_1    -195
    x[3722]   c1126     1
    x[3722]   c1131     -1
    x[3723]   c220_1    -87
    x[3723]   c265_1    -195
    x[3723]   c1126     1
    x[3723]   c1132     -1
    x[3724]   c223_1    -195
    x[3724]   c268_1    -87
    x[3724]   c1126     1
    x[3724]   c1133     -1
    x[3725]   c224_1    -195
    x[3725]   c269_1    -87
    x[3725]   c1126     1
    x[3725]   c1134     -1
    x[3726]   c181_1    -195
    x[3726]   c226_1    -87
    x[3726]   c1127     1
    x[3726]   c1128     -1
    x[3727]   c182_1    -195
    x[3727]   c227_1    -87
    x[3727]   c1127     1
    x[3727]   c1129     -1
    x[3728]   c183_1    -195
    x[3728]   c228_1    -87
    x[3728]   c1127     1
    x[3728]   c1130     -1
    x[3729]   c184_1    -195
    x[3729]   c229_1    -87
    x[3729]   c1127     1
    x[3729]   c1131     -1
    x[3730]   c186_1    -195
    x[3730]   c231_1    -87
    x[3730]   c1127     1
    x[3730]   c1132     -1
    x[3731]   c188_1    -195
    x[3731]   c233_1    -87
    x[3731]   c1127     1
    x[3731]   c1133     -1
    x[3732]   c189_1    -195
    x[3732]   c234_1    -87
    x[3732]   c1127     1
    x[3732]   c1134     -1
    x[3733]   c181_1    -87
    x[3733]   c226_1    -195
    x[3733]   c1127     -1
    x[3733]   c1128     1
    x[3734]   c182_1    -87
    x[3734]   c227_1    -195
    x[3734]   c1127     -1
    x[3734]   c1129     1
    x[3735]   c183_1    -87
    x[3735]   c228_1    -195
    x[3735]   c1127     -1
    x[3735]   c1130     1
    x[3736]   c184_1    -87
    x[3736]   c229_1    -195
    x[3736]   c1127     -1
    x[3736]   c1131     1
    x[3737]   c186_1    -87
    x[3737]   c231_1    -195
    x[3737]   c1127     -1
    x[3737]   c1132     1
    x[3738]   c188_1    -87
    x[3738]   c233_1    -195
    x[3738]   c1127     -1
    x[3738]   c1133     1
    x[3739]   c189_1    -87
    x[3739]   c234_1    -195
    x[3739]   c1127     -1
    x[3739]   c1134     1
    x[3740]   c190_1    -195
    x[3740]   c235_1    -87
    x[3740]   c1128     1
    x[3740]   c1129     -1
    x[3741]   c191_1    -195
    x[3741]   c236_1    -87
    x[3741]   c1128     1
    x[3741]   c1130     -1
    x[3742]   c192_1    -195
    x[3742]   c237_1    -87
    x[3742]   c1128     1
    x[3742]   c1131     -1
    x[3743]   c194_1    -195
    x[3743]   c239_1    -87
    x[3743]   c1128     1
    x[3743]   c1132     -1
    x[3744]   c196_1    -195
    x[3744]   c241_1    -87
    x[3744]   c1128     1
    x[3744]   c1133     -1
    x[3745]   c197_1    -195
    x[3745]   c242_1    -87
    x[3745]   c1128     1
    x[3745]   c1134     -1
    x[3746]   c190_1    -87
    x[3746]   c235_1    -195
    x[3746]   c1128     -1
    x[3746]   c1129     1
    x[3747]   c191_1    -87
    x[3747]   c236_1    -195
    x[3747]   c1128     -1
    x[3747]   c1130     1
    x[3748]   c192_1    -87
    x[3748]   c237_1    -195
    x[3748]   c1128     -1
    x[3748]   c1131     1
    x[3749]   c194_1    -87
    x[3749]   c239_1    -195
    x[3749]   c1128     -1
    x[3749]   c1132     1
    x[3750]   c196_1    -87
    x[3750]   c241_1    -195
    x[3750]   c1128     -1
    x[3750]   c1133     1
    x[3751]   c197_1    -87
    x[3751]   c242_1    -195
    x[3751]   c1128     -1
    x[3751]   c1134     1
    x[3752]   c198_1    -195
    x[3752]   c243_1    -87
    x[3752]   c1129     1
    x[3752]   c1130     -1
    x[3753]   c199_1    -195
    x[3753]   c244_1    -87
    x[3753]   c1129     1
    x[3753]   c1131     -1
    x[3754]   c201_1    -195
    x[3754]   c246_1    -87
    x[3754]   c1129     1
    x[3754]   c1132     -1
    x[3755]   c203_1    -195
    x[3755]   c248_1    -87
    x[3755]   c1129     1
    x[3755]   c1133     -1
    x[3756]   c204_1    -195
    x[3756]   c249_1    -87
    x[3756]   c1129     1
    x[3756]   c1134     -1
    x[3757]   c198_1    -87
    x[3757]   c243_1    -195
    x[3757]   c1129     -1
    x[3757]   c1130     1
    x[3758]   c199_1    -87
    x[3758]   c244_1    -195
    x[3758]   c1129     -1
    x[3758]   c1131     1
    x[3759]   c201_1    -87
    x[3759]   c246_1    -195
    x[3759]   c1129     -1
    x[3759]   c1132     1
    x[3760]   c203_1    -87
    x[3760]   c248_1    -195
    x[3760]   c1129     -1
    x[3760]   c1133     1
    x[3761]   c204_1    -87
    x[3761]   c249_1    -195
    x[3761]   c1129     -1
    x[3761]   c1134     1
    x[3762]   c205_1    -195
    x[3762]   c250_1    -87
    x[3762]   c1130     1
    x[3762]   c1131     -1
    x[3763]   c207_1    -195
    x[3763]   c252_1    -87
    x[3763]   c1130     1
    x[3763]   c1132     -1
    x[3764]   c209_1    -195
    x[3764]   c254_1    -87
    x[3764]   c1130     1
    x[3764]   c1133     -1
    x[3765]   c210_1    -195
    x[3765]   c255_1    -87
    x[3765]   c1130     1
    x[3765]   c1134     -1
    x[3766]   c205_1    -87
    x[3766]   c250_1    -195
    x[3766]   c1130     -1
    x[3766]   c1131     1
    x[3767]   c207_1    -87
    x[3767]   c252_1    -195
    x[3767]   c1130     -1
    x[3767]   c1132     1
    x[3768]   c209_1    -87
    x[3768]   c254_1    -195
    x[3768]   c1130     -1
    x[3768]   c1133     1
    x[3769]   c210_1    -87
    x[3769]   c255_1    -195
    x[3769]   c1130     -1
    x[3769]   c1134     1
    x[3770]   c212_1    -195
    x[3770]   c257_1    -87
    x[3770]   c1131     1
    x[3770]   c1132     -1
    x[3771]   c214_1    -195
    x[3771]   c259_1    -87
    x[3771]   c1131     1
    x[3771]   c1133     -1
    x[3772]   c215_1    -195
    x[3772]   c260_1    -87
    x[3772]   c1131     1
    x[3772]   c1134     -1
    x[3773]   c212_1    -87
    x[3773]   c257_1    -195
    x[3773]   c1131     -1
    x[3773]   c1132     1
    x[3774]   c214_1    -87
    x[3774]   c259_1    -195
    x[3774]   c1131     -1
    x[3774]   c1133     1
    x[3775]   c215_1    -87
    x[3775]   c260_1    -195
    x[3775]   c1131     -1
    x[3775]   c1134     1
    x[3776]   c221_1    -195
    x[3776]   c266_1    -87
    x[3776]   c1132     1
    x[3776]   c1133     -1
    x[3777]   c222_1    -195
    x[3777]   c267_1    -87
    x[3777]   c1132     1
    x[3777]   c1134     -1
    x[3778]   c221_1    -87
    x[3778]   c266_1    -195
    x[3778]   c1132     -1
    x[3778]   c1133     1
    x[3779]   c222_1    -87
    x[3779]   c267_1    -195
    x[3779]   c1132     -1
    x[3779]   c1134     1
    x[3780]   c225_1    -195
    x[3780]   c270_1    -87
    x[3780]   c1133     1
    x[3780]   c1134     -1
    x[3781]   c225_1    -87
    x[3781]   c270_1    -195
    x[3781]   c1133     -1
    x[3781]   c1134     1
    x[3782]   c184_1    -27
    x[3782]   c229_1    -161
    x[3782]   c1135     1
    x[3783]   c192_1    -27
    x[3783]   c237_1    -161
    x[3783]   c1136     1
    x[3784]   c199_1    -27
    x[3784]   c244_1    -161
    x[3784]   c1137     1
    x[3785]   c205_1    -27
    x[3785]   c250_1    -161
    x[3785]   c1138     1
    x[3786]   c189_1    -161
    x[3786]   c234_1    -27
    x[3786]   c1139     1
    x[3787]   c197_1    -161
    x[3787]   c242_1    -27
    x[3787]   c1140     1
    x[3788]   c204_1    -161
    x[3788]   c249_1    -27
    x[3788]   c1141     1
    x[3789]   c210_1    -161
    x[3789]   c255_1    -27
    x[3789]   c1142     1
    x[3790]   c211_1    -161
    x[3790]   c256_1    -27
    x[3790]   c1143     1
    x[3791]   c212_1    -161
    x[3791]   c257_1    -27
    x[3791]   c1144     1
    x[3792]   c213_1    -161
    x[3792]   c258_1    -27
    x[3792]   c1145     1
    x[3793]   c214_1    -161
    x[3793]   c259_1    -27
    x[3793]   c1146     1
    x[3794]   c215_1    -161
    x[3794]   c260_1    -27
    x[3794]   c1147     1
    x[3795]   c219_1    -161
    x[3795]   c264_1    -27
    x[3795]   c1148     1
    x[3796]   c222_1    -161
    x[3796]   c267_1    -27
    x[3796]   c1149     1
    x[3797]   c224_1    -161
    x[3797]   c269_1    -27
    x[3797]   c1150     1
    x[3798]   c225_1    -161
    x[3798]   c270_1    -27
    x[3798]   c1151     1
    x[3799]   c112_2    1
    x[3799]   c211_1    -27
    x[3799]   c256_1    -161
    x[3799]   c1152     1
    x[3799]   c1158     1
    x[3800]   c212_1    -27
    x[3800]   c257_1    -161
    x[3800]   c1152     1
    x[3800]   c1159     1
    x[3801]   c213_1    -27
    x[3801]   c258_1    -161
    x[3801]   c1152     1
    x[3801]   c1160     1
    x[3802]   c113_2    1
    x[3802]   c214_1    -27
    x[3802]   c259_1    -161
    x[3802]   c1152     1
    x[3802]   c1161     1
    x[3803]   c112_2    1
    x[3803]   c113_2    1
    x[3803]   c114_2    1
    x[3803]   c115_2    1
    x[3803]   c215_1    -27
    x[3803]   c260_1    -161
    x[3803]   c1152     1
    x[3803]   c1153     1
    x[3804]   c184_1    -161
    x[3804]   c229_1    -27
    x[3804]   c1152     1
    x[3804]   c1154     1
    x[3805]   c114_2    1
    x[3805]   c192_1    -161
    x[3805]   c237_1    -27
    x[3805]   c1152     1
    x[3805]   c1155     1
    x[3806]   c115_2    1
    x[3806]   c199_1    -161
    x[3806]   c244_1    -27
    x[3806]   c1152     1
    x[3806]   c1156     1
    x[3807]   c205_1    -161
    x[3807]   c250_1    -27
    x[3807]   c1152     1
    x[3807]   c1157     1
    x[3808]   c189_1    -27
    x[3808]   c234_1    -161
    x[3808]   c1153     1
    x[3808]   c1154     -1
    x[3809]   c197_1    -27
    x[3809]   c242_1    -161
    x[3809]   c1153     1
    x[3809]   c1155     -1
    x[3810]   c204_1    -27
    x[3810]   c249_1    -161
    x[3810]   c1153     1
    x[3810]   c1156     -1
    x[3811]   c210_1    -27
    x[3811]   c255_1    -161
    x[3811]   c1153     1
    x[3811]   c1157     -1
    x[3812]   c219_1    -27
    x[3812]   c264_1    -161
    x[3812]   c1153     1
    x[3812]   c1158     -1
    x[3813]   c222_1    -27
    x[3813]   c267_1    -161
    x[3813]   c1153     1
    x[3813]   c1159     -1
    x[3814]   c224_1    -27
    x[3814]   c269_1    -161
    x[3814]   c1153     1
    x[3814]   c1160     -1
    x[3815]   c225_1    -27
    x[3815]   c270_1    -161
    x[3815]   c1153     1
    x[3815]   c1161     -1
    x[3816]   c181_1    -161
    x[3816]   c226_1    -27
    x[3816]   c1154     1
    x[3816]   c1155     -1
    x[3817]   c182_1    -161
    x[3817]   c227_1    -27
    x[3817]   c1154     1
    x[3817]   c1156     -1
    x[3818]   c183_1    -161
    x[3818]   c228_1    -27
    x[3818]   c1154     1
    x[3818]   c1157     -1
    x[3819]   c185_1    -161
    x[3819]   c230_1    -27
    x[3819]   c1154     1
    x[3819]   c1158     -1
    x[3820]   c186_1    -161
    x[3820]   c231_1    -27
    x[3820]   c1154     1
    x[3820]   c1159     -1
    x[3821]   c187_1    -161
    x[3821]   c232_1    -27
    x[3821]   c1154     1
    x[3821]   c1160     -1
    x[3822]   c188_1    -161
    x[3822]   c233_1    -27
    x[3822]   c1154     1
    x[3822]   c1161     -1
    x[3823]   c181_1    -27
    x[3823]   c226_1    -161
    x[3823]   c1154     -1
    x[3823]   c1155     1
    x[3824]   c182_1    -27
    x[3824]   c227_1    -161
    x[3824]   c1154     -1
    x[3824]   c1156     1
    x[3825]   c183_1    -27
    x[3825]   c228_1    -161
    x[3825]   c1154     -1
    x[3825]   c1157     1
    x[3826]   c185_1    -27
    x[3826]   c230_1    -161
    x[3826]   c1154     -1
    x[3826]   c1158     1
    x[3827]   c186_1    -27
    x[3827]   c231_1    -161
    x[3827]   c1154     -1
    x[3827]   c1159     1
    x[3828]   c187_1    -27
    x[3828]   c232_1    -161
    x[3828]   c1154     -1
    x[3828]   c1160     1
    x[3829]   c188_1    -27
    x[3829]   c233_1    -161
    x[3829]   c1154     -1
    x[3829]   c1161     1
    x[3830]   c190_1    -161
    x[3830]   c235_1    -27
    x[3830]   c1155     1
    x[3830]   c1156     -1
    x[3831]   c191_1    -161
    x[3831]   c236_1    -27
    x[3831]   c1155     1
    x[3831]   c1157     -1
    x[3832]   c193_1    -161
    x[3832]   c238_1    -27
    x[3832]   c1155     1
    x[3832]   c1158     -1
    x[3833]   c194_1    -161
    x[3833]   c239_1    -27
    x[3833]   c1155     1
    x[3833]   c1159     -1
    x[3834]   c195_1    -161
    x[3834]   c240_1    -27
    x[3834]   c1155     1
    x[3834]   c1160     -1
    x[3835]   c196_1    -161
    x[3835]   c241_1    -27
    x[3835]   c1155     1
    x[3835]   c1161     -1
    x[3836]   c190_1    -27
    x[3836]   c235_1    -161
    x[3836]   c1155     -1
    x[3836]   c1156     1
    x[3837]   c191_1    -27
    x[3837]   c236_1    -161
    x[3837]   c1155     -1
    x[3837]   c1157     1
    x[3838]   c193_1    -27
    x[3838]   c238_1    -161
    x[3838]   c1155     -1
    x[3838]   c1158     1
    x[3839]   c194_1    -27
    x[3839]   c239_1    -161
    x[3839]   c1155     -1
    x[3839]   c1159     1
    x[3840]   c195_1    -27
    x[3840]   c240_1    -161
    x[3840]   c1155     -1
    x[3840]   c1160     1
    x[3841]   c196_1    -27
    x[3841]   c241_1    -161
    x[3841]   c1155     -1
    x[3841]   c1161     1
    x[3842]   c198_1    -161
    x[3842]   c243_1    -27
    x[3842]   c1156     1
    x[3842]   c1157     -1
    x[3843]   c200_1    -161
    x[3843]   c245_1    -27
    x[3843]   c1156     1
    x[3843]   c1158     -1
    x[3844]   c201_1    -161
    x[3844]   c246_1    -27
    x[3844]   c1156     1
    x[3844]   c1159     -1
    x[3845]   c202_1    -161
    x[3845]   c247_1    -27
    x[3845]   c1156     1
    x[3845]   c1160     -1
    x[3846]   c203_1    -161
    x[3846]   c248_1    -27
    x[3846]   c1156     1
    x[3846]   c1161     -1
    x[3847]   c198_1    -27
    x[3847]   c243_1    -161
    x[3847]   c1156     -1
    x[3847]   c1157     1
    x[3848]   c200_1    -27
    x[3848]   c245_1    -161
    x[3848]   c1156     -1
    x[3848]   c1158     1
    x[3849]   c201_1    -27
    x[3849]   c246_1    -161
    x[3849]   c1156     -1
    x[3849]   c1159     1
    x[3850]   c202_1    -27
    x[3850]   c247_1    -161
    x[3850]   c1156     -1
    x[3850]   c1160     1
    x[3851]   c203_1    -27
    x[3851]   c248_1    -161
    x[3851]   c1156     -1
    x[3851]   c1161     1
    x[3852]   c206_1    -161
    x[3852]   c251_1    -27
    x[3852]   c1157     1
    x[3852]   c1158     -1
    x[3853]   c207_1    -161
    x[3853]   c252_1    -27
    x[3853]   c1157     1
    x[3853]   c1159     -1
    x[3854]   c208_1    -161
    x[3854]   c253_1    -27
    x[3854]   c1157     1
    x[3854]   c1160     -1
    x[3855]   c209_1    -161
    x[3855]   c254_1    -27
    x[3855]   c1157     1
    x[3855]   c1161     -1
    x[3856]   c206_1    -27
    x[3856]   c251_1    -161
    x[3856]   c1157     -1
    x[3856]   c1158     1
    x[3857]   c207_1    -27
    x[3857]   c252_1    -161
    x[3857]   c1157     -1
    x[3857]   c1159     1
    x[3858]   c208_1    -27
    x[3858]   c253_1    -161
    x[3858]   c1157     -1
    x[3858]   c1160     1
    x[3859]   c209_1    -27
    x[3859]   c254_1    -161
    x[3859]   c1157     -1
    x[3859]   c1161     1
    x[3860]   c216_1    -161
    x[3860]   c261_1    -27
    x[3860]   c1158     1
    x[3860]   c1159     -1
    x[3861]   c217_1    -161
    x[3861]   c262_1    -27
    x[3861]   c1158     1
    x[3861]   c1160     -1
    x[3862]   c218_1    -161
    x[3862]   c263_1    -27
    x[3862]   c1158     1
    x[3862]   c1161     -1
    x[3863]   c216_1    -27
    x[3863]   c261_1    -161
    x[3863]   c1158     -1
    x[3863]   c1159     1
    x[3864]   c217_1    -27
    x[3864]   c262_1    -161
    x[3864]   c1158     -1
    x[3864]   c1160     1
    x[3865]   c218_1    -27
    x[3865]   c263_1    -161
    x[3865]   c1158     -1
    x[3865]   c1161     1
    x[3866]   c220_1    -161
    x[3866]   c265_1    -27
    x[3866]   c1159     1
    x[3866]   c1160     -1
    x[3867]   c221_1    -161
    x[3867]   c266_1    -27
    x[3867]   c1159     1
    x[3867]   c1161     -1
    x[3868]   c220_1    -27
    x[3868]   c265_1    -161
    x[3868]   c1159     -1
    x[3868]   c1160     1
    x[3869]   c221_1    -27
    x[3869]   c266_1    -161
    x[3869]   c1159     -1
    x[3869]   c1161     1
    x[3870]   c223_1    -161
    x[3870]   c268_1    -27
    x[3870]   c1160     1
    x[3870]   c1161     -1
    x[3871]   c223_1    -27
    x[3871]   c268_1    -161
    x[3871]   c1160     -1
    x[3871]   c1161     1
    x[3872]   c186_1    -66
    x[3872]   c231_1    -169
    x[3872]   c1162     1
    x[3873]   c194_1    -66
    x[3873]   c239_1    -169
    x[3873]   c1163     1
    x[3874]   c201_1    -66
    x[3874]   c246_1    -169
    x[3874]   c1164     1
    x[3875]   c207_1    -66
    x[3875]   c252_1    -169
    x[3875]   c1165     1
    x[3876]   c212_1    -66
    x[3876]   c257_1    -169
    x[3876]   c1166     1
    x[3877]   c216_1    -66
    x[3877]   c261_1    -169
    x[3877]   c1167     1
    x[3878]   c225_1    -66
    x[3878]   c270_1    -169
    x[3878]   c1168     1
    x[3879]   c188_1    -169
    x[3879]   c233_1    -66
    x[3879]   c1169     1
    x[3880]   c196_1    -169
    x[3880]   c241_1    -66
    x[3880]   c1170     1
    x[3881]   c203_1    -169
    x[3881]   c248_1    -66
    x[3881]   c1171     1
    x[3882]   c209_1    -169
    x[3882]   c254_1    -66
    x[3882]   c1172     1
    x[3883]   c214_1    -169
    x[3883]   c259_1    -66
    x[3883]   c1173     1
    x[3884]   c218_1    -169
    x[3884]   c263_1    -66
    x[3884]   c1174     1
    x[3885]   c220_1    -169
    x[3885]   c265_1    -66
    x[3885]   c1175     1
    x[3886]   c221_1    -169
    x[3886]   c266_1    -66
    x[3886]   c1176     1
    x[3887]   c222_1    -169
    x[3887]   c267_1    -66
    x[3887]   c1177     1
    x[3888]   c223_1    -169
    x[3888]   c268_1    -66
    x[3888]   c1178     1
    x[3889]   c220_1    -66
    x[3889]   c265_1    -169
    x[3889]   c1179     1
    x[3889]   c1187     1
    x[3890]   c230_2    1
    x[3890]   c231_2    1
    x[3890]   c232_2    1
    x[3890]   c233_2    1
    x[3890]   c221_1    -66
    x[3890]   c266_1    -169
    x[3890]   c1179     1
    x[3890]   c1180     1
    x[3891]   c222_1    -66
    x[3891]   c267_1    -169
    x[3891]   c1179     1
    x[3891]   c1188     1
    x[3892]   c230_2    1
    x[3892]   c186_1    -169
    x[3892]   c231_1    -66
    x[3892]   c1179     1
    x[3892]   c1181     1
    x[3893]   c231_2    1
    x[3893]   c194_1    -169
    x[3893]   c239_1    -66
    x[3893]   c1179     1
    x[3893]   c1182     1
    x[3894]   c232_2    1
    x[3894]   c201_1    -169
    x[3894]   c246_1    -66
    x[3894]   c1179     1
    x[3894]   c1183     1
    x[3895]   c207_1    -169
    x[3895]   c252_1    -66
    x[3895]   c1179     1
    x[3895]   c1184     1
    x[3896]   c233_2    1
    x[3896]   c212_1    -169
    x[3896]   c257_1    -66
    x[3896]   c1179     1
    x[3896]   c1185     1
    x[3897]   c216_1    -169
    x[3897]   c261_1    -66
    x[3897]   c1179     1
    x[3897]   c1186     1
    x[3898]   c188_1    -66
    x[3898]   c233_1    -169
    x[3898]   c1180     1
    x[3898]   c1181     -1
    x[3899]   c311_1    1
    x[3899]   c196_1    -66
    x[3899]   c241_1    -169
    x[3899]   c1180     1
    x[3899]   c1182     -1
    x[3900]   c311_1    1
    x[3900]   c203_1    -66
    x[3900]   c248_1    -169
    x[3900]   c1180     1
    x[3900]   c1183     -1
    x[3901]   c209_1    -66
    x[3901]   c254_1    -169
    x[3901]   c1180     1
    x[3901]   c1184     -1
    x[3902]   c214_1    -66
    x[3902]   c259_1    -169
    x[3902]   c1180     1
    x[3902]   c1185     -1
    x[3903]   c218_1    -66
    x[3903]   c263_1    -169
    x[3903]   c1180     1
    x[3903]   c1186     -1
    x[3904]   c223_1    -66
    x[3904]   c268_1    -169
    x[3904]   c1180     1
    x[3904]   c1187     -1
    x[3905]   c225_1    -169
    x[3905]   c270_1    -66
    x[3905]   c1180     1
    x[3905]   c1188     -1
    x[3906]   c181_1    -169
    x[3906]   c226_1    -66
    x[3906]   c1181     1
    x[3906]   c1182     -1
    x[3907]   c182_1    -169
    x[3907]   c227_1    -66
    x[3907]   c1181     1
    x[3907]   c1183     -1
    x[3908]   c183_1    -169
    x[3908]   c228_1    -66
    x[3908]   c1181     1
    x[3908]   c1184     -1
    x[3909]   c184_1    -169
    x[3909]   c229_1    -66
    x[3909]   c1181     1
    x[3909]   c1185     -1
    x[3910]   c185_1    -169
    x[3910]   c230_1    -66
    x[3910]   c1181     1
    x[3910]   c1186     -1
    x[3911]   c187_1    -169
    x[3911]   c232_1    -66
    x[3911]   c1181     1
    x[3911]   c1187     -1
    x[3912]   c189_1    -169
    x[3912]   c234_1    -66
    x[3912]   c1181     1
    x[3912]   c1188     -1
    x[3913]   c181_1    -66
    x[3913]   c226_1    -169
    x[3913]   c1181     -1
    x[3913]   c1182     1
    x[3914]   c182_1    -66
    x[3914]   c227_1    -169
    x[3914]   c1181     -1
    x[3914]   c1183     1
    x[3915]   c183_1    -66
    x[3915]   c228_1    -169
    x[3915]   c1181     -1
    x[3915]   c1184     1
    x[3916]   c184_1    -66
    x[3916]   c229_1    -169
    x[3916]   c1181     -1
    x[3916]   c1185     1
    x[3917]   c185_1    -66
    x[3917]   c230_1    -169
    x[3917]   c1181     -1
    x[3917]   c1186     1
    x[3918]   c187_1    -66
    x[3918]   c232_1    -169
    x[3918]   c1181     -1
    x[3918]   c1187     1
    x[3919]   c189_1    -66
    x[3919]   c234_1    -169
    x[3919]   c1181     -1
    x[3919]   c1188     1
    x[3920]   c190_1    -169
    x[3920]   c235_1    -66
    x[3920]   c1182     1
    x[3920]   c1183     -1
    x[3921]   c191_1    -169
    x[3921]   c236_1    -66
    x[3921]   c1182     1
    x[3921]   c1184     -1
    x[3922]   c192_1    -169
    x[3922]   c237_1    -66
    x[3922]   c1182     1
    x[3922]   c1185     -1
    x[3923]   c193_1    -169
    x[3923]   c238_1    -66
    x[3923]   c1182     1
    x[3923]   c1186     -1
    x[3924]   c195_1    -169
    x[3924]   c240_1    -66
    x[3924]   c1182     1
    x[3924]   c1187     -1
    x[3925]   c197_1    -169
    x[3925]   c242_1    -66
    x[3925]   c1182     1
    x[3925]   c1188     -1
    x[3926]   c190_1    -66
    x[3926]   c235_1    -169
    x[3926]   c1182     -1
    x[3926]   c1183     1
    x[3927]   c191_1    -66
    x[3927]   c236_1    -169
    x[3927]   c1182     -1
    x[3927]   c1184     1
    x[3928]   c192_1    -66
    x[3928]   c237_1    -169
    x[3928]   c1182     -1
    x[3928]   c1185     1
    x[3929]   c193_1    -66
    x[3929]   c238_1    -169
    x[3929]   c1182     -1
    x[3929]   c1186     1
    x[3930]   c195_1    -66
    x[3930]   c240_1    -169
    x[3930]   c1182     -1
    x[3930]   c1187     1
    x[3931]   c197_1    -66
    x[3931]   c242_1    -169
    x[3931]   c1182     -1
    x[3931]   c1188     1
    x[3932]   c198_1    -169
    x[3932]   c243_1    -66
    x[3932]   c1183     1
    x[3932]   c1184     -1
    x[3933]   c199_1    -169
    x[3933]   c244_1    -66
    x[3933]   c1183     1
    x[3933]   c1185     -1
    x[3934]   c200_1    -169
    x[3934]   c245_1    -66
    x[3934]   c1183     1
    x[3934]   c1186     -1
    x[3935]   c202_1    -169
    x[3935]   c247_1    -66
    x[3935]   c1183     1
    x[3935]   c1187     -1
    x[3936]   c204_1    -169
    x[3936]   c249_1    -66
    x[3936]   c1183     1
    x[3936]   c1188     -1
    x[3937]   c198_1    -66
    x[3937]   c243_1    -169
    x[3937]   c1183     -1
    x[3937]   c1184     1
    x[3938]   c199_1    -66
    x[3938]   c244_1    -169
    x[3938]   c1183     -1
    x[3938]   c1185     1
    x[3939]   c200_1    -66
    x[3939]   c245_1    -169
    x[3939]   c1183     -1
    x[3939]   c1186     1
    x[3940]   c202_1    -66
    x[3940]   c247_1    -169
    x[3940]   c1183     -1
    x[3940]   c1187     1
    x[3941]   c204_1    -66
    x[3941]   c249_1    -169
    x[3941]   c1183     -1
    x[3941]   c1188     1
    x[3942]   c205_1    -169
    x[3942]   c250_1    -66
    x[3942]   c1184     1
    x[3942]   c1185     -1
    x[3943]   c206_1    -169
    x[3943]   c251_1    -66
    x[3943]   c1184     1
    x[3943]   c1186     -1
    x[3944]   c208_1    -169
    x[3944]   c253_1    -66
    x[3944]   c1184     1
    x[3944]   c1187     -1
    x[3945]   c210_1    -169
    x[3945]   c255_1    -66
    x[3945]   c1184     1
    x[3945]   c1188     -1
    x[3946]   c205_1    -66
    x[3946]   c250_1    -169
    x[3946]   c1184     -1
    x[3946]   c1185     1
    x[3947]   c206_1    -66
    x[3947]   c251_1    -169
    x[3947]   c1184     -1
    x[3947]   c1186     1
    x[3948]   c208_1    -66
    x[3948]   c253_1    -169
    x[3948]   c1184     -1
    x[3948]   c1187     1
    x[3949]   c210_1    -66
    x[3949]   c255_1    -169
    x[3949]   c1184     -1
    x[3949]   c1188     1
    x[3950]   c211_1    -169
    x[3950]   c256_1    -66
    x[3950]   c1185     1
    x[3950]   c1186     -1
    x[3951]   c213_1    -169
    x[3951]   c258_1    -66
    x[3951]   c1185     1
    x[3951]   c1187     -1
    x[3952]   c215_1    -169
    x[3952]   c260_1    -66
    x[3952]   c1185     1
    x[3952]   c1188     -1
    x[3953]   c211_1    -66
    x[3953]   c256_1    -169
    x[3953]   c1185     -1
    x[3953]   c1186     1
    x[3954]   c213_1    -66
    x[3954]   c258_1    -169
    x[3954]   c1185     -1
    x[3954]   c1187     1
    x[3955]   c215_1    -66
    x[3955]   c260_1    -169
    x[3955]   c1185     -1
    x[3955]   c1188     1
    x[3956]   c217_1    -169
    x[3956]   c262_1    -66
    x[3956]   c1186     1
    x[3956]   c1187     -1
    x[3957]   c219_1    -169
    x[3957]   c264_1    -66
    x[3957]   c1186     1
    x[3957]   c1188     -1
    x[3958]   c217_1    -66
    x[3958]   c262_1    -169
    x[3958]   c1186     -1
    x[3958]   c1187     1
    x[3959]   c219_1    -66
    x[3959]   c264_1    -169
    x[3959]   c1186     -1
    x[3959]   c1188     1
    x[3960]   c224_1    -169
    x[3960]   c269_1    -66
    x[3960]   c1187     1
    x[3960]   c1188     -1
    x[3961]   c224_1    -66
    x[3961]   c269_1    -169
    x[3961]   c1187     -1
    x[3961]   c1188     1
    x[3962]   c181_1    -187
    x[3962]   c1189     1
    x[3963]   c182_1    -187
    x[3963]   c1190     1
    x[3964]   c183_1    -187
    x[3964]   c1191     1
    x[3965]   c184_1    -187
    x[3965]   c1192     1
    x[3966]   c185_1    -187
    x[3966]   c1193     1
    x[3967]   c186_1    -187
    x[3967]   c1194     1
    x[3968]   c187_1    -187
    x[3968]   c1195     1
    x[3969]   c188_1    -187
    x[3969]   c1196     1
    x[3970]   c189_1    -187
    x[3970]   c1197     1
    x[3971]   c194_1    -187
    x[3971]   c1198     1
    x[3972]   c201_1    -187
    x[3972]   c1199     1
    x[3973]   c207_1    -187
    x[3973]   c1200     1
    x[3974]   c212_1    -187
    x[3974]   c1201     1
    x[3975]   c216_1    -187
    x[3975]   c1202     1
    x[3976]   c265_1    -187
    x[3976]   c1203     1
    x[3977]   c266_1    -187
    x[3977]   c1204     1
    x[3978]   c267_1    -187
    x[3978]   c1205     1
    x[3979]   c12_2     1
    x[3979]   c220_1    -187
    x[3979]   c1206     1
    x[3979]   c1213     1
    x[3980]   c221_1    -187
    x[3980]   c1206     1
    x[3980]   c1214     1
    x[3981]   c222_1    -187
    x[3981]   c1206     1
    x[3981]   c1215     1
    x[3982]   c12_2     1
    x[3982]   c13_2     1
    x[3982]   c14_2     1
    x[3982]   c15_2     1
    x[3982]   c231_1    -187
    x[3982]   c1206     1
    x[3982]   c1207     1
    x[3983]   c239_1    -187
    x[3983]   c1206     1
    x[3983]   c1208     1
    x[3984]   c13_2     1
    x[3984]   c246_1    -187
    x[3984]   c1206     1
    x[3984]   c1209     1
    x[3985]   c252_1    -187
    x[3985]   c1206     1
    x[3985]   c1210     1
    x[3986]   c14_2     1
    x[3986]   c257_1    -187
    x[3986]   c1206     1
    x[3986]   c1211     1
    x[3987]   c15_2     1
    x[3987]   c261_1    -187
    x[3987]   c1206     1
    x[3987]   c1212     1
    x[3988]   c226_1    -187
    x[3988]   c1207     1
    x[3988]   c1208     -1
    x[3989]   c227_1    -187
    x[3989]   c1207     1
    x[3989]   c1209     -1
    x[3990]   c228_1    -187
    x[3990]   c1207     1
    x[3990]   c1210     -1
    x[3991]   c229_1    -187
    x[3991]   c1207     1
    x[3991]   c1211     -1
    x[3992]   c230_1    -187
    x[3992]   c1207     1
    x[3992]   c1212     -1
    x[3993]   c232_1    -187
    x[3993]   c1207     1
    x[3993]   c1213     -1
    x[3994]   c233_1    -187
    x[3994]   c1207     1
    x[3994]   c1214     -1
    x[3995]   c234_1    -187
    x[3995]   c1207     1
    x[3995]   c1215     -1
    x[3996]   c235_1    -187
    x[3996]   c1208     1
    x[3996]   c1209     -1
    x[3997]   c236_1    -187
    x[3997]   c1208     1
    x[3997]   c1210     -1
    x[3998]   c237_1    -187
    x[3998]   c1208     1
    x[3998]   c1211     -1
    x[3999]   c238_1    -187
    x[3999]   c1208     1
    x[3999]   c1212     -1
    x[4000]   c240_1    -187
    x[4000]   c1208     1
    x[4000]   c1213     -1
    x[4001]   c241_1    -187
    x[4001]   c1208     1
    x[4001]   c1214     -1
    x[4002]   c242_1    -187
    x[4002]   c1208     1
    x[4002]   c1215     -1
    x[4003]   c190_1    -187
    x[4003]   c1208     -1
    x[4003]   c1209     1
    x[4004]   c191_1    -187
    x[4004]   c1208     -1
    x[4004]   c1210     1
    x[4005]   c192_1    -187
    x[4005]   c1208     -1
    x[4005]   c1211     1
    x[4006]   c193_1    -187
    x[4006]   c1208     -1
    x[4006]   c1212     1
    x[4007]   c195_1    -187
    x[4007]   c1208     -1
    x[4007]   c1213     1
    x[4008]   c196_1    -187
    x[4008]   c1208     -1
    x[4008]   c1214     1
    x[4009]   c197_1    -187
    x[4009]   c1208     -1
    x[4009]   c1215     1
    x[4010]   c243_1    -187
    x[4010]   c1209     1
    x[4010]   c1210     -1
    x[4011]   c244_1    -187
    x[4011]   c1209     1
    x[4011]   c1211     -1
    x[4012]   c245_1    -187
    x[4012]   c1209     1
    x[4012]   c1212     -1
    x[4013]   c247_1    -187
    x[4013]   c1209     1
    x[4013]   c1213     -1
    x[4014]   c248_1    -187
    x[4014]   c1209     1
    x[4014]   c1214     -1
    x[4015]   c249_1    -187
    x[4015]   c1209     1
    x[4015]   c1215     -1
    x[4016]   c198_1    -187
    x[4016]   c1209     -1
    x[4016]   c1210     1
    x[4017]   c199_1    -187
    x[4017]   c1209     -1
    x[4017]   c1211     1
    x[4018]   c200_1    -187
    x[4018]   c1209     -1
    x[4018]   c1212     1
    x[4019]   c202_1    -187
    x[4019]   c1209     -1
    x[4019]   c1213     1
    x[4020]   c203_1    -187
    x[4020]   c1209     -1
    x[4020]   c1214     1
    x[4021]   c204_1    -187
    x[4021]   c1209     -1
    x[4021]   c1215     1
    x[4022]   c250_1    -187
    x[4022]   c1210     1
    x[4022]   c1211     -1
    x[4023]   c251_1    -187
    x[4023]   c1210     1
    x[4023]   c1212     -1
    x[4024]   c253_1    -187
    x[4024]   c1210     1
    x[4024]   c1213     -1
    x[4025]   c254_1    -187
    x[4025]   c1210     1
    x[4025]   c1214     -1
    x[4026]   c255_1    -187
    x[4026]   c1210     1
    x[4026]   c1215     -1
    x[4027]   c205_1    -187
    x[4027]   c1210     -1
    x[4027]   c1211     1
    x[4028]   c206_1    -187
    x[4028]   c1210     -1
    x[4028]   c1212     1
    x[4029]   c208_1    -187
    x[4029]   c1210     -1
    x[4029]   c1213     1
    x[4030]   c209_1    -187
    x[4030]   c1210     -1
    x[4030]   c1214     1
    x[4031]   c210_1    -187
    x[4031]   c1210     -1
    x[4031]   c1215     1
    x[4032]   c256_1    -187
    x[4032]   c1211     1
    x[4032]   c1212     -1
    x[4033]   c258_1    -187
    x[4033]   c1211     1
    x[4033]   c1213     -1
    x[4034]   c259_1    -187
    x[4034]   c1211     1
    x[4034]   c1214     -1
    x[4035]   c260_1    -187
    x[4035]   c1211     1
    x[4035]   c1215     -1
    x[4036]   c211_1    -187
    x[4036]   c1211     -1
    x[4036]   c1212     1
    x[4037]   c213_1    -187
    x[4037]   c1211     -1
    x[4037]   c1213     1
    x[4038]   c214_1    -187
    x[4038]   c1211     -1
    x[4038]   c1214     1
    x[4039]   c215_1    -187
    x[4039]   c1211     -1
    x[4039]   c1215     1
    x[4040]   c262_1    -187
    x[4040]   c1212     1
    x[4040]   c1213     -1
    x[4041]   c263_1    -187
    x[4041]   c1212     1
    x[4041]   c1214     -1
    x[4042]   c264_1    -187
    x[4042]   c1212     1
    x[4042]   c1215     -1
    x[4043]   c217_1    -187
    x[4043]   c1212     -1
    x[4043]   c1213     1
    x[4044]   c218_1    -187
    x[4044]   c1212     -1
    x[4044]   c1214     1
    x[4045]   c219_1    -187
    x[4045]   c1212     -1
    x[4045]   c1215     1
    x[4046]   c268_1    -187
    x[4046]   c1213     1
    x[4046]   c1214     -1
    x[4047]   c269_1    -187
    x[4047]   c1213     1
    x[4047]   c1215     -1
    x[4048]   c223_1    -187
    x[4048]   c1213     -1
    x[4048]   c1214     1
    x[4049]   c224_1    -187
    x[4049]   c1213     -1
    x[4049]   c1215     1
    x[4050]   c270_1    -187
    x[4050]   c1214     1
    x[4050]   c1215     -1
    x[4051]   c225_1    -187
    x[4051]   c1214     -1
    x[4051]   c1215     1
    x[4052]   c172_2    -1
    x[4052]   c1_1      1
    x[4052]   c1217     -128
    x[4052]   c1218     -128
    x[4052]   c1219     -633
    x[4053]   c172_2    1
    x[4053]   c1_1      -1
    x[4053]   c2_1      1
    x[4053]   c1217     -384
    x[4053]   c1218     -384
    x[4053]   c1219     -1429
    x[4054]   c2_1      -1
    x[4054]   c3_1      1
    x[4054]   c1217     -256
    x[4054]   c1218     -256
    x[4054]   c1219     -1078
    x[4055]   c3_1      -1
    x[4055]   c4_1      1
    x[4055]   c1217     -256
    x[4055]   c1218     -256
    x[4055]   c1219     -163
    x[4056]   c4_1      -1
    x[4056]   c1217     -896
    x[4056]   c1218     -896
    x[4056]   c1219     -235
    x[4057]   c1216     1
    x[4058]   c181_1    1
    x[4058]   c1217     1
    x[4059]   c226_1    1
    x[4059]   c1218     1
    x[4060]   c1219     1
    x[4060]   c1396     -1
    x[4061]   c101_2    -1
    x[4061]   c5_1      1
    x[4061]   c1221     -128
    x[4061]   c1222     -128
    x[4061]   c1223     -516
    x[4062]   c101_2    1
    x[4062]   c5_1      -1
    x[4062]   c6_1      1
    x[4062]   c1221     -384
    x[4062]   c1222     -384
    x[4062]   c1223     -1096
    x[4063]   c6_1      -1
    x[4063]   c7_1      1
    x[4063]   c1221     -256
    x[4063]   c1222     -256
    x[4063]   c1223     -656
    x[4064]   c7_1      -1
    x[4064]   c8_1      1
    x[4064]   c1221     -256
    x[4064]   c1222     -256
    x[4064]   c1223     -79
    x[4065]   c8_1      -1
    x[4065]   c1221     -896
    x[4065]   c1222     -896
    x[4065]   c1223     -176
    x[4066]   c1220     1
    x[4067]   c182_1    1
    x[4067]   c1221     1
    x[4068]   c227_1    1
    x[4068]   c1222     1
    x[4069]   c1223     1
    x[4069]   c1396     -1
    x[4070]   c9_1      1
    x[4070]   c1225     -128
    x[4070]   c1226     -128
    x[4070]   c1227     -483
    x[4071]   c9_1      -1
    x[4071]   c10_1     1
    x[4071]   c1225     -384
    x[4071]   c1226     -384
    x[4071]   c1227     -996
    x[4072]   c10_1     -1
    x[4072]   c11_1     1
    x[4072]   c1225     -256
    x[4072]   c1226     -256
    x[4072]   c1227     -501
    x[4073]   c11_1     -1
    x[4073]   c12_1     1
    x[4073]   c1225     -256
    x[4073]   c1226     -256
    x[4073]   c1227     -65
    x[4074]   c12_1     -1
    x[4074]   c1225     -896
    x[4074]   c1226     -896
    x[4074]   c1227     -170
    x[4075]   c1224     1
    x[4076]   c183_1    1
    x[4076]   c1225     1
    x[4077]   c228_1    1
    x[4077]   c1226     1
    x[4078]   c1227     1
    x[4078]   c1396     -1
    x[4079]   c287_1    -1
    x[4079]   c13_1     1
    x[4079]   c1229     -128
    x[4079]   c1230     -128
    x[4079]   c1231     -467
    x[4080]   c287_1    1
    x[4080]   c13_1     -1
    x[4080]   c14_1     1
    x[4080]   c1229     -384
    x[4080]   c1230     -384
    x[4080]   c1231     -947
    x[4081]   c14_1     -1
    x[4081]   c15_1     1
    x[4081]   c1229     -256
    x[4081]   c1230     -256
    x[4081]   c1231     -425
    x[4082]   c15_1     -1
    x[4082]   c16_1     1
    x[4082]   c1229     -256
    x[4082]   c1230     -256
    x[4082]   c1231     -58
    x[4083]   c16_1     -1
    x[4083]   c1229     -896
    x[4083]   c1230     -896
    x[4083]   c1231     -166
    x[4084]   c1228     1
    x[4085]   c184_1    1
    x[4085]   c1229     1
    x[4086]   c229_1    1
    x[4086]   c1230     1
    x[4087]   c1231     1
    x[4087]   c1396     -1
    x[4088]   c266_2    -1
    x[4088]   c17_1     1
    x[4088]   c1233     -128
    x[4088]   c1234     -128
    x[4088]   c1235     -591
    x[4089]   c266_2    1
    x[4089]   c17_1     -1
    x[4089]   c18_1     1
    x[4089]   c1233     -384
    x[4089]   c1234     -384
    x[4089]   c1235     -1311
    x[4090]   c18_1     -1
    x[4090]   c19_1     1
    x[4090]   c1233     -256
    x[4090]   c1234     -256
    x[4090]   c1235     -939
    x[4091]   c19_1     -1
    x[4091]   c20_1     1
    x[4091]   c1233     -256
    x[4091]   c1234     -256
    x[4091]   c1235     -129
    x[4092]   c20_1     -1
    x[4092]   c1233     -896
    x[4092]   c1234     -896
    x[4092]   c1235     -211
    x[4093]   c1232     1
    x[4094]   c185_1    1
    x[4094]   c1233     1
    x[4095]   c230_1    1
    x[4095]   c1234     1
    x[4096]   c1235     1
    x[4096]   c1396     -1
    x[4097]   c194_2    -1
    x[4097]   c21_1     1
    x[4097]   c1237     -128
    x[4097]   c1238     -128
    x[4097]   c1239     -511
    x[4098]   c194_2    1
    x[4098]   c21_1     -1
    x[4098]   c22_1     1
    x[4098]   c1237     -384
    x[4098]   c1238     -384
    x[4098]   c1239     -1079
    x[4099]   c22_1     -1
    x[4099]   c23_1     1
    x[4099]   c1237     -256
    x[4099]   c1238     -256
    x[4099]   c1239     -630
    x[4100]   c23_1     -1
    x[4100]   c24_1     1
    x[4100]   c1237     -256
    x[4100]   c1238     -256
    x[4100]   c1239     -77
    x[4101]   c24_1     -1
    x[4101]   c1237     -896
    x[4101]   c1238     -896
    x[4101]   c1239     -175
    x[4102]   c1236     1
    x[4103]   c186_1    1
    x[4103]   c1237     1
    x[4104]   c231_1    1
    x[4104]   c1238     1
    x[4105]   c1239     1
    x[4105]   c1396     -1
    x[4106]   c173_2    -1
    x[4106]   c25_1     1
    x[4106]   c1241     -128
    x[4106]   c1242     -128
    x[4106]   c1243     -563
    x[4107]   c173_2    1
    x[4107]   c25_1     -1
    x[4107]   c26_1     1
    x[4107]   c1241     -384
    x[4107]   c1242     -384
    x[4107]   c1243     -1230
    x[4108]   c26_1     -1
    x[4108]   c27_1     1
    x[4108]   c1241     -256
    x[4108]   c1242     -256
    x[4108]   c1243     -843
    x[4109]   c27_1     -1
    x[4109]   c28_1     1
    x[4109]   c1241     -256
    x[4109]   c1242     -256
    x[4109]   c1243     -107
    x[4110]   c28_1     -1
    x[4110]   c1241     -896
    x[4110]   c1242     -896
    x[4110]   c1243     -194
    x[4111]   c1240     1
    x[4112]   c187_1    1
    x[4112]   c1241     1
    x[4113]   c232_1    1
    x[4113]   c1242     1
    x[4114]   c1243     1
    x[4114]   c1396     -1
    x[4115]   c102_2    -1
    x[4115]   c29_1     1
    x[4115]   c1245     -128
    x[4115]   c1246     -128
    x[4115]   c1247     -609
    x[4116]   c102_2    1
    x[4116]   c29_1     -1
    x[4116]   c30_1     1
    x[4116]   c1245     -384
    x[4116]   c1246     -384
    x[4116]   c1247     -1362
    x[4117]   c30_1     -1
    x[4117]   c31_1     1
    x[4117]   c1245     -256
    x[4117]   c1246     -256
    x[4117]   c1247     -998
    x[4118]   c31_1     -1
    x[4118]   c32_1     1
    x[4118]   c1245     -256
    x[4118]   c1246     -256
    x[4118]   c1247     -143
    x[4119]   c32_1     -1
    x[4119]   c1245     -896
    x[4119]   c1246     -896
    x[4119]   c1247     -222
    x[4120]   c1244     1
    x[4121]   c188_1    1
    x[4121]   c1245     1
    x[4122]   c233_1    1
    x[4122]   c1246     1
    x[4123]   c1247     1
    x[4123]   c1396     -1
    x[4124]   c288_1    -1
    x[4124]   c33_1     1
    x[4124]   c1249     -128
    x[4124]   c1250     -128
    x[4124]   c1251     -556
    x[4125]   c288_1    1
    x[4125]   c33_1     -1
    x[4125]   c34_1     1
    x[4125]   c1249     -384
    x[4125]   c1250     -384
    x[4125]   c1251     -1211
    x[4126]   c34_1     -1
    x[4126]   c35_1     1
    x[4126]   c1249     -256
    x[4126]   c1250     -256
    x[4126]   c1251     -820
    x[4127]   c35_1     -1
    x[4127]   c36_1     1
    x[4127]   c1249     -256
    x[4127]   c1250     -256
    x[4127]   c1251     -102
    x[4128]   c36_1     -1
    x[4128]   c1249     -896
    x[4128]   c1250     -896
    x[4128]   c1251     -190
    x[4129]   c1248     1
    x[4130]   c189_1    1
    x[4130]   c1249     1
    x[4131]   c234_1    1
    x[4131]   c1250     1
    x[4132]   c1251     1
    x[4132]   c1396     -1
    x[4133]   c145_2    -1
    x[4133]   c37_1     1
    x[4133]   c1253     -128
    x[4133]   c1254     -128
    x[4133]   c1255     -540
    x[4134]   c145_2    1
    x[4134]   c37_1     -1
    x[4134]   c38_1     1
    x[4134]   c1253     -384
    x[4134]   c1254     -384
    x[4134]   c1255     -1168
    x[4135]   c38_1     -1
    x[4135]   c39_1     1
    x[4135]   c1253     -256
    x[4135]   c1254     -256
    x[4135]   c1255     -767
    x[4136]   c39_1     -1
    x[4136]   c40_1     1
    x[4136]   c1253     -256
    x[4136]   c1254     -256
    x[4136]   c1255     -89
    x[4137]   c40_1     -1
    x[4137]   c1253     -896
    x[4137]   c1254     -896
    x[4137]   c1255     -181
    x[4138]   c1252     1
    x[4139]   c190_1    1
    x[4139]   c1253     1
    x[4140]   c235_1    1
    x[4140]   c1254     1
    x[4141]   c1255     1
    x[4141]   c1396     -1
    x[4142]   c267_2    -1
    x[4142]   c41_1     1
    x[4142]   c1257     -128
    x[4142]   c1258     -128
    x[4142]   c1259     -616
    x[4143]   c267_2    1
    x[4143]   c41_1     -1
    x[4143]   c42_1     1
    x[4143]   c1257     -384
    x[4143]   c1258     -384
    x[4143]   c1259     -1381
    x[4144]   c42_1     -1
    x[4144]   c43_1     1
    x[4144]   c1257     -256
    x[4144]   c1258     -256
    x[4144]   c1259     -1021
    x[4145]   c43_1     -1
    x[4145]   c44_1     1
    x[4145]   c1257     -256
    x[4145]   c1258     -256
    x[4145]   c1259     -150
    x[4146]   c44_1     -1
    x[4146]   c1257     -896
    x[4146]   c1258     -896
    x[4146]   c1259     -225
    x[4147]   c1256     1
    x[4148]   c191_1    1
    x[4148]   c1257     1
    x[4149]   c236_1    1
    x[4149]   c1258     1
    x[4150]   c1259     1
    x[4150]   c1396     -1
    x[4151]   c38_2     -1
    x[4151]   c45_1     1
    x[4151]   c1261     -128
    x[4151]   c1262     -128
    x[4151]   c1263     -699
    x[4152]   c38_2     1
    x[4152]   c45_1     -1
    x[4152]   c46_1     1
    x[4152]   c1261     -384
    x[4152]   c1262     -384
    x[4152]   c1263     -1612
    x[4153]   c46_1     -1
    x[4153]   c47_1     1
    x[4153]   c1261     -256
    x[4153]   c1262     -256
    x[4153]   c1263     -1296
    x[4154]   c47_1     -1
    x[4154]   c48_1     1
    x[4154]   c1261     -256
    x[4154]   c1262     -256
    x[4154]   c1263     -214
    x[4155]   c48_1     -1
    x[4155]   c1261     -896
    x[4155]   c1262     -896
    x[4155]   c1263     -274
    x[4156]   c1260     1
    x[4157]   c192_1    1
    x[4157]   c1261     1
    x[4158]   c237_1    1
    x[4158]   c1262     1
    x[4159]   c1263     1
    x[4159]   c1396     -1
    x[4160]   c126_2    -1
    x[4160]   c49_1     1
    x[4160]   c1265     -128
    x[4160]   c1266     -128
    x[4160]   c1267     -458
    x[4161]   c126_2    1
    x[4161]   c49_1     -1
    x[4161]   c50_1     1
    x[4161]   c1265     -384
    x[4161]   c1266     -384
    x[4161]   c1267     -918
    x[4162]   c50_1     -1
    x[4162]   c51_1     1
    x[4162]   c1265     -256
    x[4162]   c1266     -256
    x[4162]   c1267     -380
    x[4163]   c51_1     -1
    x[4163]   c52_1     1
    x[4163]   c1265     -256
    x[4163]   c1266     -256
    x[4163]   c1267     -54
    x[4164]   c52_1     -1
    x[4164]   c1265     -896
    x[4164]   c1266     -896
    x[4164]   c1267     -165
    x[4165]   c1264     1
    x[4166]   c193_1    1
    x[4166]   c1265     1
    x[4167]   c238_1    1
    x[4167]   c1266     1
    x[4168]   c1267     1
    x[4168]   c1396     -1
    x[4169]   c242_2    -1
    x[4169]   c53_1     1
    x[4169]   c1269     -128
    x[4169]   c1270     -128
    x[4169]   c1271     -623
    x[4170]   c242_2    1
    x[4170]   c53_1     -1
    x[4170]   c54_1     1
    x[4170]   c1269     -384
    x[4170]   c1270     -384
    x[4170]   c1271     -1397
    x[4171]   c54_1     -1
    x[4171]   c55_1     1
    x[4171]   c1269     -256
    x[4171]   c1270     -256
    x[4171]   c1271     -1042
    x[4172]   c55_1     -1
    x[4172]   c56_1     1
    x[4172]   c1269     -256
    x[4172]   c1270     -256
    x[4172]   c1271     -154
    x[4173]   c56_1     -1
    x[4173]   c1269     -896
    x[4173]   c1270     -896
    x[4173]   c1271     -229
    x[4174]   c1268     1
    x[4175]   c194_1    1
    x[4175]   c1269     1
    x[4176]   c239_1    1
    x[4176]   c1270     1
    x[4177]   c1271     1
    x[4177]   c1396     -1
    x[4178]   c57_1     1
    x[4178]   c1273     -128
    x[4178]   c1274     -128
    x[4178]   c1275     -519
    x[4179]   c57_1     -1
    x[4179]   c58_1     1
    x[4179]   c1273     -384
    x[4179]   c1274     -384
    x[4179]   c1275     -1102
    x[4180]   c58_1     -1
    x[4180]   c59_1     1
    x[4180]   c1273     -256
    x[4180]   c1274     -256
    x[4180]   c1275     -665
    x[4181]   c59_1     -1
    x[4181]   c60_1     1
    x[4181]   c1273     -256
    x[4181]   c1274     -256
    x[4181]   c1275     -80
    x[4182]   c60_1     -1
    x[4182]   c1273     -896
    x[4182]   c1274     -896
    x[4182]   c1275     -177
    x[4183]   c1272     1
    x[4184]   c195_1    1
    x[4184]   c1273     1
    x[4185]   c240_1    1
    x[4185]   c1274     1
    x[4186]   c1275     1
    x[4186]   c1396     -1
    x[4187]   c103_2    -1
    x[4187]   c61_1     1
    x[4187]   c1277     -128
    x[4187]   c1278     -128
    x[4187]   c1279     -523
    x[4188]   c103_2    1
    x[4188]   c61_1     -1
    x[4188]   c62_1     1
    x[4188]   c1277     -384
    x[4188]   c1278     -384
    x[4188]   c1279     -1115
    x[4189]   c62_1     -1
    x[4189]   c63_1     1
    x[4189]   c1277     -256
    x[4189]   c1278     -256
    x[4189]   c1279     -686
    x[4190]   c63_1     -1
    x[4190]   c64_1     1
    x[4190]   c1277     -256
    x[4190]   c1278     -256
    x[4190]   c1279     -82
    x[4191]   c64_1     -1
    x[4191]   c1277     -896
    x[4191]   c1278     -896
    x[4191]   c1279     -177
    x[4192]   c1276     1
    x[4193]   c196_1    1
    x[4193]   c1277     1
    x[4194]   c241_1    1
    x[4194]   c1278     1
    x[4195]   c1279     1
    x[4195]   c1396     -1
    x[4196]   c220_2    -1
    x[4196]   c65_1     1
    x[4196]   c1281     -128
    x[4196]   c1282     -128
    x[4196]   c1283     -534
    x[4197]   c220_2    1
    x[4197]   c65_1     -1
    x[4197]   c66_1     1
    x[4197]   c1281     -384
    x[4197]   c1282     -384
    x[4197]   c1283     -1150
    x[4198]   c66_1     -1
    x[4198]   c67_1     1
    x[4198]   c1281     -256
    x[4198]   c1282     -256
    x[4198]   c1283     -739
    x[4199]   c67_1     -1
    x[4199]   c68_1     1
    x[4199]   c1281     -256
    x[4199]   c1282     -256
    x[4199]   c1283     -87
    x[4200]   c68_1     -1
    x[4200]   c1281     -896
    x[4200]   c1282     -896
    x[4200]   c1283     -180
    x[4201]   c1280     1
    x[4202]   c197_1    1
    x[4202]   c1281     1
    x[4203]   c242_1    1
    x[4203]   c1282     1
    x[4204]   c1283     1
    x[4204]   c1396     -1
    x[4205]   c335_1    -1
    x[4205]   c69_1     1
    x[4205]   c1285     -128
    x[4205]   c1286     -128
    x[4205]   c1287     -503
    x[4206]   c335_1    1
    x[4206]   c69_1     -1
    x[4206]   c70_1     1
    x[4206]   c1285     -384
    x[4206]   c1286     -384
    x[4206]   c1287     -1055
    x[4207]   c70_1     -1
    x[4207]   c71_1     1
    x[4207]   c1285     -256
    x[4207]   c1286     -256
    x[4207]   c1287     -593
    x[4208]   c71_1     -1
    x[4208]   c72_1     1
    x[4208]   c1285     -256
    x[4208]   c1286     -256
    x[4208]   c1287     -73
    x[4209]   c72_1     -1
    x[4209]   c1285     -896
    x[4209]   c1286     -896
    x[4209]   c1287     -174
    x[4210]   c1284     1
    x[4211]   c198_1    1
    x[4211]   c1285     1
    x[4212]   c243_1    1
    x[4212]   c1286     1
    x[4213]   c1287     1
    x[4213]   c1396     -1
    x[4214]   c81_2     -1
    x[4214]   c73_1     1
    x[4214]   c1289     -128
    x[4214]   c1290     -128
    x[4214]   c1291     -592
    x[4215]   c81_2     1
    x[4215]   c73_1     -1
    x[4215]   c74_1     1
    x[4215]   c1289     -384
    x[4215]   c1290     -384
    x[4215]   c1291     -1314
    x[4216]   c74_1     -1
    x[4216]   c75_1     1
    x[4216]   c1289     -256
    x[4216]   c1290     -256
    x[4216]   c1291     -941
    x[4217]   c75_1     -1
    x[4217]   c76_1     1
    x[4217]   c1289     -256
    x[4217]   c1290     -256
    x[4217]   c1291     -130
    x[4218]   c76_1     -1
    x[4218]   c1289     -896
    x[4218]   c1290     -896
    x[4218]   c1291     -211
    x[4219]   c1288     1
    x[4220]   c199_1    1
    x[4220]   c1289     1
    x[4221]   c244_1    1
    x[4221]   c1290     1
    x[4222]   c1291     1
    x[4222]   c1396     -1
    x[4223]   c195_2    -1
    x[4223]   c77_1     1
    x[4223]   c1293     -128
    x[4223]   c1294     -128
    x[4223]   c1295     -487
    x[4224]   c195_2    1
    x[4224]   c77_1     -1
    x[4224]   c78_1     1
    x[4224]   c1293     -384
    x[4224]   c1294     -384
    x[4224]   c1295     -1008
    x[4225]   c78_1     -1
    x[4225]   c79_1     1
    x[4225]   c1293     -256
    x[4225]   c1294     -256
    x[4225]   c1295     -519
    x[4226]   c79_1     -1
    x[4226]   c80_1     1
    x[4226]   c1293     -256
    x[4226]   c1294     -256
    x[4226]   c1295     -66
    x[4227]   c80_1     -1
    x[4227]   c1293     -896
    x[4227]   c1294     -896
    x[4227]   c1295     -171
    x[4228]   c1292     1
    x[4229]   c200_1    1
    x[4229]   c1293     1
    x[4230]   c245_1    1
    x[4230]   c1294     1
    x[4231]   c1295     1
    x[4231]   c1396     -1
    x[4232]   c312_1    -1
    x[4232]   c81_1     1
    x[4232]   c1297     -128
    x[4232]   c1298     -128
    x[4232]   c1299     -546
    x[4233]   c312_1    1
    x[4233]   c81_1     -1
    x[4233]   c82_1     1
    x[4233]   c1297     -384
    x[4233]   c1298     -384
    x[4233]   c1299     -1185
    x[4234]   c82_1     -1
    x[4234]   c83_1     1
    x[4234]   c1297     -256
    x[4234]   c1298     -256
    x[4234]   c1299     -788
    x[4235]   c83_1     -1
    x[4235]   c84_1     1
    x[4235]   c1297     -256
    x[4235]   c1298     -256
    x[4235]   c1299     -94
    x[4236]   c84_1     -1
    x[4236]   c1297     -896
    x[4236]   c1298     -896
    x[4236]   c1299     -185
    x[4237]   c1296     1
    x[4238]   c201_1    1
    x[4238]   c1297     1
    x[4239]   c246_1    1
    x[4239]   c1298     1
    x[4240]   c1299     1
    x[4240]   c1396     -1
    x[4241]   c62_2     -1
    x[4241]   c85_1     1
    x[4241]   c1301     -128
    x[4241]   c1302     -128
    x[4241]   c1303     -467
    x[4242]   c62_2     1
    x[4242]   c85_1     -1
    x[4242]   c86_1     1
    x[4242]   c1301     -384
    x[4242]   c1302     -384
    x[4242]   c1303     -948
    x[4243]   c86_1     -1
    x[4243]   c87_1     1
    x[4243]   c1301     -256
    x[4243]   c1302     -256
    x[4243]   c1303     -425
    x[4244]   c87_1     -1
    x[4244]   c88_1     1
    x[4244]   c1301     -256
    x[4244]   c1302     -256
    x[4244]   c1303     -58
    x[4245]   c88_1     -1
    x[4245]   c1301     -896
    x[4245]   c1302     -896
    x[4245]   c1303     -167
    x[4246]   c1300     1
    x[4247]   c202_1    1
    x[4247]   c1301     1
    x[4248]   c247_1    1
    x[4248]   c1302     1
    x[4249]   c1303     1
    x[4249]   c1396     -1
    x[4250]   c174_2    -1
    x[4250]   c89_1     1
    x[4250]   c1305     -128
    x[4250]   c1306     -128
    x[4250]   c1307     -523
    x[4251]   c174_2    1
    x[4251]   c89_1     -1
    x[4251]   c90_1     1
    x[4251]   c1305     -384
    x[4251]   c1306     -384
    x[4251]   c1307     -1114
    x[4252]   c90_1     -1
    x[4252]   c91_1     1
    x[4252]   c1305     -256
    x[4252]   c1306     -256
    x[4252]   c1307     -684
    x[4253]   c91_1     -1
    x[4253]   c92_1     1
    x[4253]   c1305     -256
    x[4253]   c1306     -256
    x[4253]   c1307     -82
    x[4254]   c92_1     -1
    x[4254]   c1305     -896
    x[4254]   c1306     -896
    x[4254]   c1307     -177
    x[4255]   c1304     1
    x[4256]   c203_1    1
    x[4256]   c1305     1
    x[4257]   c248_1    1
    x[4257]   c1306     1
    x[4258]   c1307     1
    x[4258]   c1396     -1
    x[4259]   c289_1    -1
    x[4259]   c93_1     1
    x[4259]   c1309     -128
    x[4259]   c1310     -128
    x[4259]   c1311     -467
    x[4260]   c289_1    1
    x[4260]   c93_1     -1
    x[4260]   c94_1     1
    x[4260]   c1309     -384
    x[4260]   c1310     -384
    x[4260]   c1311     -946
    x[4261]   c94_1     -1
    x[4261]   c95_1     1
    x[4261]   c1309     -256
    x[4261]   c1310     -256
    x[4261]   c1311     -424
    x[4262]   c95_1     -1
    x[4262]   c96_1     1
    x[4262]   c1309     -256
    x[4262]   c1310     -256
    x[4262]   c1311     -58
    x[4263]   c96_1     -1
    x[4263]   c1309     -896
    x[4263]   c1310     -896
    x[4263]   c1311     -166
    x[4264]   c1308     1
    x[4265]   c204_1    1
    x[4265]   c1309     1
    x[4266]   c249_1    1
    x[4266]   c1310     1
    x[4267]   c1311     1
    x[4267]   c1396     -1
    x[4268]   c39_2     -1
    x[4268]   c97_1     1
    x[4268]   c1313     -128
    x[4268]   c1314     -128
    x[4268]   c1315     -553
    x[4269]   c39_2     1
    x[4269]   c97_1     -1
    x[4269]   c98_1     1
    x[4269]   c1313     -384
    x[4269]   c1314     -384
    x[4269]   c1315     -1204
    x[4270]   c98_1     -1
    x[4270]   c99_1     1
    x[4270]   c1313     -256
    x[4270]   c1314     -256
    x[4270]   c1315     -811
    x[4271]   c99_1     -1
    x[4271]   c100_1    1
    x[4271]   c1313     -256
    x[4271]   c1314     -256
    x[4271]   c1315     -100
    x[4272]   c100_1    -1
    x[4272]   c1313     -896
    x[4272]   c1314     -896
    x[4272]   c1315     -188
    x[4273]   c1312     1
    x[4274]   c205_1    1
    x[4274]   c1313     1
    x[4275]   c250_1    1
    x[4275]   c1314     1
    x[4276]   c1315     1
    x[4276]   c1396     -1
    x[4277]   c146_2    -1
    x[4277]   c101_1    1
    x[4277]   c1317     -128
    x[4277]   c1318     -128
    x[4277]   c1319     -596
    x[4278]   c146_2    1
    x[4278]   c101_1    -1
    x[4278]   c102_1    1
    x[4278]   c1317     -384
    x[4278]   c1318     -384
    x[4278]   c1319     -1324
    x[4279]   c102_1    -1
    x[4279]   c103_1    1
    x[4279]   c1317     -256
    x[4279]   c1318     -256
    x[4279]   c1319     -953
    x[4280]   c103_1    -1
    x[4280]   c104_1    1
    x[4280]   c1317     -256
    x[4280]   c1318     -256
    x[4280]   c1319     -133
    x[4281]   c104_1    -1
    x[4281]   c1317     -896
    x[4281]   c1318     -896
    x[4281]   c1319     -214
    x[4282]   c1316     1
    x[4283]   c206_1    1
    x[4283]   c1317     1
    x[4284]   c251_1    1
    x[4284]   c1318     1
    x[4285]   c1319     1
    x[4285]   c1396     -1
    x[4286]   c268_2    -1
    x[4286]   c105_1    1
    x[4286]   c1321     -128
    x[4286]   c1322     -128
    x[4286]   c1323     -587
    x[4287]   c268_2    1
    x[4287]   c105_1    -1
    x[4287]   c106_1    1
    x[4287]   c1321     -384
    x[4287]   c1322     -384
    x[4287]   c1323     -1297
    x[4288]   c106_1    -1
    x[4288]   c107_1    1
    x[4288]   c1321     -256
    x[4288]   c1322     -256
    x[4288]   c1323     -922
    x[4289]   c107_1    -1
    x[4289]   c108_1    1
    x[4289]   c1321     -256
    x[4289]   c1322     -256
    x[4289]   c1323     -125
    x[4290]   c108_1    -1
    x[4290]   c1321     -896
    x[4290]   c1322     -896
    x[4290]   c1323     -208
    x[4291]   c1320     1
    x[4292]   c207_1    1
    x[4292]   c1321     1
    x[4293]   c252_1    1
    x[4293]   c1322     1
    x[4294]   c1323     1
    x[4294]   c1396     -1
    x[4295]   c23_2     -1
    x[4295]   c109_1    1
    x[4295]   c1325     -128
    x[4295]   c1326     -128
    x[4295]   c1327     -582
    x[4296]   c23_2     1
    x[4296]   c109_1    -1
    x[4296]   c110_1    1
    x[4296]   c1325     -384
    x[4296]   c1326     -384
    x[4296]   c1327     -1283
    x[4297]   c110_1    -1
    x[4297]   c111_1    1
    x[4297]   c1325     -256
    x[4297]   c1326     -256
    x[4297]   c1327     -905
    x[4298]   c111_1    -1
    x[4298]   c112_1    1
    x[4298]   c1325     -256
    x[4298]   c1326     -256
    x[4298]   c1327     -122
    x[4299]   c112_1    -1
    x[4299]   c1325     -896
    x[4299]   c1326     -896
    x[4299]   c1327     -205
    x[4300]   c1324     1
    x[4301]   c208_1    1
    x[4301]   c1325     1
    x[4302]   c253_1    1
    x[4302]   c1326     1
    x[4303]   c1327     1
    x[4303]   c1396     -1
    x[4304]   c127_2    -1
    x[4304]   c113_1    1
    x[4304]   c1329     -128
    x[4304]   c1330     -128
    x[4304]   c1331     -558
    x[4305]   c127_2    1
    x[4305]   c113_1    -1
    x[4305]   c114_1    1
    x[4305]   c1329     -384
    x[4305]   c1330     -384
    x[4305]   c1331     -1217
    x[4306]   c114_1    -1
    x[4306]   c115_1    1
    x[4306]   c1329     -256
    x[4306]   c1330     -256
    x[4306]   c1331     -827
    x[4307]   c115_1    -1
    x[4307]   c116_1    1
    x[4307]   c1329     -256
    x[4307]   c1330     -256
    x[4307]   c1331     -103
    x[4308]   c116_1    -1
    x[4308]   c1329     -896
    x[4308]   c1330     -896
    x[4308]   c1331     -191
    x[4309]   c1328     1
    x[4310]   c209_1    1
    x[4310]   c1329     1
    x[4311]   c254_1    1
    x[4311]   c1330     1
    x[4312]   c1331     1
    x[4312]   c1396     -1
    x[4313]   c243_2    -1
    x[4313]   c117_1    1
    x[4313]   c1333     -128
    x[4313]   c1334     -128
    x[4313]   c1335     -579
    x[4314]   c243_2    1
    x[4314]   c117_1    -1
    x[4314]   c118_1    1
    x[4314]   c1333     -384
    x[4314]   c1334     -384
    x[4314]   c1335     -1275
    x[4315]   c118_1    -1
    x[4315]   c119_1    1
    x[4315]   c1333     -256
    x[4315]   c1334     -256
    x[4315]   c1335     -897
    x[4316]   c119_1    -1
    x[4316]   c120_1    1
    x[4316]   c1333     -256
    x[4316]   c1334     -256
    x[4316]   c1335     -119
    x[4317]   c120_1    -1
    x[4317]   c1333     -896
    x[4317]   c1334     -896
    x[4317]   c1335     -204
    x[4318]   c1332     1
    x[4319]   c210_1    1
    x[4319]   c1333     1
    x[4320]   c255_1    1
    x[4320]   c1334     1
    x[4321]   c1335     1
    x[4321]   c1396     -1
    x[4322]   c121_1    1
    x[4322]   c1337     -128
    x[4322]   c1338     -128
    x[4322]   c1339     -655
    x[4323]   c121_1    -1
    x[4323]   c122_1    1
    x[4323]   c1337     -384
    x[4323]   c1338     -384
    x[4323]   c1339     -1488
    x[4324]   c122_1    -1
    x[4324]   c123_1    1
    x[4324]   c1337     -256
    x[4324]   c1338     -256
    x[4324]   c1339     -1149
    x[4325]   c123_1    -1
    x[4325]   c124_1    1
    x[4325]   c1337     -256
    x[4325]   c1338     -256
    x[4325]   c1339     -179
    x[4326]   c124_1    -1
    x[4326]   c1337     -896
    x[4326]   c1338     -896
    x[4326]   c1339     -248
    x[4327]   c1336     1
    x[4328]   c211_1    1
    x[4328]   c1337     1
    x[4329]   c256_1    1
    x[4329]   c1338     1
    x[4330]   c1339     1
    x[4330]   c1396     -1
    x[4331]   c104_2    -1
    x[4331]   c125_1    1
    x[4331]   c1341     -128
    x[4331]   c1342     -128
    x[4331]   c1343     -559
    x[4332]   c104_2    1
    x[4332]   c125_1    -1
    x[4332]   c126_1    1
    x[4332]   c1341     -384
    x[4332]   c1342     -384
    x[4332]   c1343     -1218
    x[4333]   c126_1    -1
    x[4333]   c127_1    1
    x[4333]   c1341     -256
    x[4333]   c1342     -256
    x[4333]   c1343     -829
    x[4334]   c127_1    -1
    x[4334]   c128_1    1
    x[4334]   c1341     -256
    x[4334]   c1342     -256
    x[4334]   c1343     -104
    x[4335]   c128_1    -1
    x[4335]   c1341     -896
    x[4335]   c1342     -896
    x[4335]   c1343     -192
    x[4336]   c1340     1
    x[4337]   c212_1    1
    x[4337]   c1341     1
    x[4338]   c257_1    1
    x[4338]   c1342     1
    x[4339]   c1343     1
    x[4339]   c1396     -1
    x[4340]   c221_2    -1
    x[4340]   c129_1    1
    x[4340]   c1345     -128
    x[4340]   c1346     -128
    x[4340]   c1347     -624
    x[4341]   c221_2    1
    x[4341]   c129_1    -1
    x[4341]   c130_1    1
    x[4341]   c1345     -384
    x[4341]   c1346     -384
    x[4341]   c1347     -1401
    x[4342]   c130_1    -1
    x[4342]   c131_1    1
    x[4342]   c1345     -256
    x[4342]   c1346     -256
    x[4342]   c1347     -1045
    x[4343]   c131_1    -1
    x[4343]   c132_1    1
    x[4343]   c1345     -256
    x[4343]   c1346     -256
    x[4343]   c1347     -155
    x[4344]   c132_1    -1
    x[4344]   c1345     -896
    x[4344]   c1346     -896
    x[4344]   c1347     -229
    x[4345]   c1344     1
    x[4346]   c213_1    1
    x[4346]   c1345     1
    x[4347]   c258_1    1
    x[4347]   c1346     1
    x[4348]   c1347     1
    x[4348]   c1396     -1
    x[4349]   c336_1    -1
    x[4349]   c133_1    1
    x[4349]   c1349     -128
    x[4349]   c1350     -128
    x[4349]   c1351     -670
    x[4350]   c336_1    1
    x[4350]   c133_1    -1
    x[4350]   c134_1    1
    x[4350]   c1349     -384
    x[4350]   c1350     -384
    x[4350]   c1351     -1533
    x[4351]   c134_1    -1
    x[4351]   c135_1    1
    x[4351]   c1349     -256
    x[4351]   c1350     -256
    x[4351]   c1351     -1201
    x[4352]   c135_1    -1
    x[4352]   c136_1    1
    x[4352]   c1349     -256
    x[4352]   c1350     -256
    x[4352]   c1351     -192
    x[4353]   c136_1    -1
    x[4353]   c1349     -896
    x[4353]   c1350     -896
    x[4353]   c1351     -257
    x[4354]   c1348     1
    x[4355]   c214_1    1
    x[4355]   c1349     1
    x[4356]   c259_1    1
    x[4356]   c1350     1
    x[4357]   c1351     1
    x[4357]   c1396     -1
    x[4358]   c82_2     -1
    x[4358]   c137_1    1
    x[4358]   c1353     -128
    x[4358]   c1354     -128
    x[4358]   c1355     -616
    x[4359]   c82_2     1
    x[4359]   c137_1    -1
    x[4359]   c138_1    1
    x[4359]   c1353     -384
    x[4359]   c1354     -384
    x[4359]   c1355     -1379
    x[4360]   c138_1    -1
    x[4360]   c139_1    1
    x[4360]   c1353     -256
    x[4360]   c1354     -256
    x[4360]   c1355     -1019
    x[4361]   c139_1    -1
    x[4361]   c140_1    1
    x[4361]   c1353     -256
    x[4361]   c1354     -256
    x[4361]   c1355     -149
    x[4362]   c140_1    -1
    x[4362]   c1353     -896
    x[4362]   c1354     -896
    x[4362]   c1355     -225
    x[4363]   c1352     1
    x[4364]   c215_1    1
    x[4364]   c1353     1
    x[4365]   c260_1    1
    x[4365]   c1354     1
    x[4366]   c1355     1
    x[4366]   c1396     -1
    x[4367]   c196_2    -1
    x[4367]   c141_1    1
    x[4367]   c1357     -128
    x[4367]   c1358     -128
    x[4367]   c1359     -564
    x[4368]   c196_2    1
    x[4368]   c141_1    -1
    x[4368]   c142_1    1
    x[4368]   c1357     -384
    x[4368]   c1358     -384
    x[4368]   c1359     -1236
    x[4369]   c142_1    -1
    x[4369]   c143_1    1
    x[4369]   c1357     -256
    x[4369]   c1358     -256
    x[4369]   c1359     -848
    x[4370]   c143_1    -1
    x[4370]   c144_1    1
    x[4370]   c1357     -256
    x[4370]   c1358     -256
    x[4370]   c1359     -108
    x[4371]   c144_1    -1
    x[4371]   c1357     -896
    x[4371]   c1358     -896
    x[4371]   c1359     -195
    x[4372]   c1356     1
    x[4373]   c216_1    1
    x[4373]   c1357     1
    x[4374]   c261_1    1
    x[4374]   c1358     1
    x[4375]   c1359     1
    x[4375]   c1396     -1
    x[4376]   c313_1    -1
    x[4376]   c145_1    1
    x[4376]   c1361     -128
    x[4376]   c1362     -128
    x[4376]   c1363     -417
    x[4377]   c313_1    1
    x[4377]   c145_1    -1
    x[4377]   c146_1    1
    x[4377]   c1361     -384
    x[4377]   c1362     -384
    x[4377]   c1363     -794
    x[4378]   c146_1    -1
    x[4378]   c147_1    1
    x[4378]   c1361     -256
    x[4378]   c1362     -256
    x[4378]   c1363     -187
    x[4379]   c147_1    -1
    x[4379]   c148_1    1
    x[4379]   c1361     -256
    x[4379]   c1362     -256
    x[4379]   c1363     -37
    x[4380]   c148_1    -1
    x[4380]   c1361     -896
    x[4380]   c1362     -896
    x[4380]   c1363     -156
    x[4381]   c1360     1
    x[4382]   c217_1    1
    x[4382]   c1361     1
    x[4383]   c262_1    1
    x[4383]   c1362     1
    x[4384]   c1363     1
    x[4384]   c1396     -1
    x[4385]   c63_2     -1
    x[4385]   c149_1    1
    x[4385]   c1365     -128
    x[4385]   c1366     -128
    x[4385]   c1367     -557
    x[4386]   c63_2     1
    x[4386]   c149_1    -1
    x[4386]   c150_1    1
    x[4386]   c1365     -384
    x[4386]   c1366     -384
    x[4386]   c1367     -1213
    x[4387]   c150_1    -1
    x[4387]   c151_1    1
    x[4387]   c1365     -256
    x[4387]   c1366     -256
    x[4387]   c1367     -823
    x[4388]   c151_1    -1
    x[4388]   c152_1    1
    x[4388]   c1365     -256
    x[4388]   c1366     -256
    x[4388]   c1367     -102
    x[4389]   c152_1    -1
    x[4389]   c1365     -896
    x[4389]   c1366     -896
    x[4389]   c1367     -190
    x[4390]   c1364     1
    x[4391]   c218_1    1
    x[4391]   c1365     1
    x[4392]   c263_1    1
    x[4392]   c1366     1
    x[4393]   c1367     1
    x[4393]   c1396     -1
    x[4394]   c175_2    -1
    x[4394]   c153_1    1
    x[4394]   c1369     -128
    x[4394]   c1370     -128
    x[4394]   c1371     -433
    x[4395]   c175_2    1
    x[4395]   c153_1    -1
    x[4395]   c154_1    1
    x[4395]   c1369     -384
    x[4395]   c1370     -384
    x[4395]   c1371     -842
    x[4396]   c154_1    -1
    x[4396]   c155_1    1
    x[4396]   c1369     -256
    x[4396]   c1370     -256
    x[4396]   c1371     -264
    x[4397]   c155_1    -1
    x[4397]   c156_1    1
    x[4397]   c1369     -256
    x[4397]   c1370     -256
    x[4397]   c1371     -43
    x[4398]   c156_1    -1
    x[4398]   c1369     -896
    x[4398]   c1370     -896
    x[4398]   c1371     -160
    x[4399]   c1368     1
    x[4400]   c219_1    1
    x[4400]   c1369     1
    x[4401]   c264_1    1
    x[4401]   c1370     1
    x[4402]   c1371     1
    x[4402]   c1396     -1
    x[4403]   c290_1    -1
    x[4403]   c157_1    1
    x[4403]   c1373     -128
    x[4403]   c1374     -128
    x[4403]   c1375     -519
    x[4404]   c290_1    1
    x[4404]   c157_1    -1
    x[4404]   c158_1    1
    x[4404]   c1373     -384
    x[4404]   c1374     -384
    x[4404]   c1375     -1102
    x[4405]   c158_1    -1
    x[4405]   c159_1    1
    x[4405]   c1373     -256
    x[4405]   c1374     -256
    x[4405]   c1375     -667
    x[4406]   c159_1    -1
    x[4406]   c160_1    1
    x[4406]   c1373     -256
    x[4406]   c1374     -256
    x[4406]   c1375     -80
    x[4407]   c160_1    -1
    x[4407]   c1373     -896
    x[4407]   c1374     -896
    x[4407]   c1375     -177
    x[4408]   c1372     1
    x[4409]   c220_1    1
    x[4409]   c1373     1
    x[4410]   c265_1    1
    x[4410]   c1374     1
    x[4411]   c1375     1
    x[4411]   c1396     -1
    x[4412]   c40_2     -1
    x[4412]   c161_1    1
    x[4412]   c1377     -128
    x[4412]   c1378     -128
    x[4412]   c1379     -644
    x[4413]   c40_2     1
    x[4413]   c161_1    -1
    x[4413]   c162_1    1
    x[4413]   c1377     -384
    x[4413]   c1378     -384
    x[4413]   c1379     -1457
    x[4414]   c162_1    -1
    x[4414]   c163_1    1
    x[4414]   c1377     -256
    x[4414]   c1378     -256
    x[4414]   c1379     -1112
    x[4415]   c163_1    -1
    x[4415]   c164_1    1
    x[4415]   c1377     -256
    x[4415]   c1378     -256
    x[4415]   c1379     -171
    x[4416]   c164_1    -1
    x[4416]   c1377     -896
    x[4416]   c1378     -896
    x[4416]   c1379     -241
    x[4417]   c1376     1
    x[4418]   c221_1    1
    x[4418]   c1377     1
    x[4419]   c266_1    1
    x[4419]   c1378     1
    x[4420]   c1379     1
    x[4420]   c1396     -1
    x[4421]   c147_2    -1
    x[4421]   c165_1    1
    x[4421]   c1381     -128
    x[4421]   c1382     -128
    x[4421]   c1383     -503
    x[4422]   c147_2    1
    x[4422]   c165_1    -1
    x[4422]   c166_1    1
    x[4422]   c1381     -384
    x[4422]   c1382     -384
    x[4422]   c1383     -1054
    x[4423]   c166_1    -1
    x[4423]   c167_1    1
    x[4423]   c1381     -256
    x[4423]   c1382     -256
    x[4423]   c1383     -591
    x[4424]   c167_1    -1
    x[4424]   c168_1    1
    x[4424]   c1381     -256
    x[4424]   c1382     -256
    x[4424]   c1383     -73
    x[4425]   c168_1    -1
    x[4425]   c1381     -896
    x[4425]   c1382     -896
    x[4425]   c1383     -173
    x[4426]   c1380     1
    x[4427]   c222_1    1
    x[4427]   c1381     1
    x[4428]   c267_1    1
    x[4428]   c1382     1
    x[4429]   c1383     1
    x[4429]   c1396     -1
    x[4430]   c269_2    -1
    x[4430]   c169_1    1
    x[4430]   c1385     -128
    x[4430]   c1386     -128
    x[4430]   c1387     -573
    x[4431]   c269_2    1
    x[4431]   c169_1    -1
    x[4431]   c170_1    1
    x[4431]   c1385     -384
    x[4431]   c1386     -384
    x[4431]   c1387     -1260
    x[4432]   c170_1    -1
    x[4432]   c171_1    1
    x[4432]   c1385     -256
    x[4432]   c1386     -256
    x[4432]   c1387     -878
    x[4433]   c171_1    -1
    x[4433]   c172_1    1
    x[4433]   c1385     -256
    x[4433]   c1386     -256
    x[4433]   c1387     -116
    x[4434]   c172_1    -1
    x[4434]   c1385     -896
    x[4434]   c1386     -896
    x[4434]   c1387     -200
    x[4435]   c1384     1
    x[4436]   c223_1    1
    x[4436]   c1385     1
    x[4437]   c268_1    1
    x[4437]   c1386     1
    x[4438]   c1387     1
    x[4438]   c1396     -1
    x[4439]   c24_2     -1
    x[4439]   c173_1    1
    x[4439]   c1389     -128
    x[4439]   c1390     -128
    x[4439]   c1391     -318
    x[4440]   c24_2     1
    x[4440]   c173_1    -1
    x[4440]   c174_1    1
    x[4440]   c1389     -384
    x[4440]   c1390     -384
    x[4440]   c1391     -533
    x[4441]   c174_1    -1
    x[4441]   c175_1    1
    x[4441]   c1389     -256
    x[4441]   c1390     -256
    x[4441]   c1391     -28
    x[4442]   c175_1    -1
    x[4442]   c176_1    1
    x[4442]   c1389     -256
    x[4442]   c1390     -256
    x[4442]   c1391     -21
    x[4443]   c176_1    -1
    x[4443]   c1389     -896
    x[4443]   c1390     -896
    x[4443]   c1391     -94
    x[4444]   c1388     1
    x[4445]   c224_1    1
    x[4445]   c1389     1
    x[4446]   c269_1    1
    x[4446]   c1390     1
    x[4447]   c1391     1
    x[4447]   c1396     -1
    x[4448]   c128_2    -1
    x[4448]   c177_1    1
    x[4448]   c1393     -128
    x[4448]   c1394     -128
    x[4448]   c1395     -579
    x[4449]   c128_2    1
    x[4449]   c177_1    -1
    x[4449]   c178_1    1
    x[4449]   c1393     -384
    x[4449]   c1394     -384
    x[4449]   c1395     -1274
    x[4450]   c178_1    -1
    x[4450]   c179_1    1
    x[4450]   c1393     -256
    x[4450]   c1394     -256
    x[4450]   c1395     -896
    x[4451]   c179_1    -1
    x[4451]   c180_1    1
    x[4451]   c1393     -256
    x[4451]   c1394     -256
    x[4451]   c1395     -119
    x[4452]   c180_1    -1
    x[4452]   c1393     -896
    x[4452]   c1394     -896
    x[4452]   c1395     -203
    x[4453]   c1392     1
    x[4454]   c225_1    1
    x[4454]   c1393     1
    x[4455]   c270_1    1
    x[4455]   c1394     1
    x[4456]   c1395     1
    x[4456]   c1396     -1
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1_2      1
    rhs       c2_2      1
    rhs       c3_2      1
    rhs       c4_2      1
    rhs       c5_2      1
    rhs       c6_2      1
    rhs       c7_2      1
    rhs       c8_2      1
    rhs       c9_2      1
    rhs       c10_2     1
    rhs       c11_2     1
    rhs       c12_2     1
    rhs       c13_2     1
    rhs       c14_2     1
    rhs       c15_2     1
    rhs       c16_2     1
    rhs       c17_2     1
    rhs       c18_2     1
    rhs       c19_2     1
    rhs       c20_2     1
    rhs       c21_2     1
    rhs       c22_2     1
    rhs       c23_2     0
    rhs       c24_2     0
    rhs       c25_2     1
    rhs       c26_2     1
    rhs       c27_2     1
    rhs       c28_2     1
    rhs       c29_2     1
    rhs       c30_2     1
    rhs       c31_2     1
    rhs       c32_2     1
    rhs       c33_2     1
    rhs       c34_2     1
    rhs       c35_2     1
    rhs       c36_2     1
    rhs       c37_2     1
    rhs       c38_2     0
    rhs       c39_2     0
    rhs       c40_2     0
    rhs       c41_2     1
    rhs       c42_2     1
    rhs       c43_2     1
    rhs       c44_2     1
    rhs       c45_2     1
    rhs       c46_2     1
    rhs       c47_2     1
    rhs       c48_2     1
    rhs       c49_2     1
    rhs       c50_2     1
    rhs       c51_2     1
    rhs       c52_2     1
    rhs       c53_2     1
    rhs       c54_2     1
    rhs       c55_2     1
    rhs       c56_2     1
    rhs       c57_2     1
    rhs       c58_2     1
    rhs       c59_2     1
    rhs       c60_2     1
    rhs       c61_2     1
    rhs       c62_2     0
    rhs       c63_2     0
    rhs       c64_2     1
    rhs       c65_2     1
    rhs       c66_2     1
    rhs       c67_2     1
    rhs       c68_2     1
    rhs       c69_2     1
    rhs       c70_2     1
    rhs       c71_2     1
    rhs       c72_2     1
    rhs       c73_2     1
    rhs       c74_2     1
    rhs       c75_2     1
    rhs       c76_2     1
    rhs       c77_2     1
    rhs       c78_2     1
    rhs       c79_2     1
    rhs       c80_2     1
    rhs       c81_2     0
    rhs       c82_2     0
    rhs       c83_2     1
    rhs       c84_2     1
    rhs       c85_2     1
    rhs       c86_2     1
    rhs       c87_2     1
    rhs       c88_2     1
    rhs       c89_2     1
    rhs       c90_2     1
    rhs       c91_2     1
    rhs       c92_2     1
    rhs       c93_2     1
    rhs       c94_2     1
    rhs       c95_2     1
    rhs       c96_2     1
    rhs       c97_2     1
    rhs       c98_2     1
    rhs       c99_2     1
    rhs       c100_2    1
    rhs       c101_2    0
    rhs       c102_2    0
    rhs       c103_2    0
    rhs       c104_2    0
    rhs       c105_2    1
    rhs       c106_2    1
    rhs       c107_2    1
    rhs       c108_2    1
    rhs       c109_2    1
    rhs       c110_2    1
    rhs       c111_2    1
    rhs       c112_2    1
    rhs       c113_2    1
    rhs       c114_2    1
    rhs       c115_2    1
    rhs       c116_2    1
    rhs       c117_2    1
    rhs       c118_2    1
    rhs       c119_2    1
    rhs       c120_2    1
    rhs       c121_2    1
    rhs       c122_2    1
    rhs       c123_2    1
    rhs       c124_2    1
    rhs       c125_2    1
    rhs       c126_2    0
    rhs       c127_2    0
    rhs       c128_2    0
    rhs       c129_2    1
    rhs       c130_2    1
    rhs       c131_2    1
    rhs       c132_2    1
    rhs       c133_2    1
    rhs       c134_2    1
    rhs       c135_2    1
    rhs       c136_2    1
    rhs       c137_2    1
    rhs       c138_2    1
    rhs       c139_2    1
    rhs       c140_2    1
    rhs       c141_2    1
    rhs       c142_2    1
    rhs       c143_2    1
    rhs       c144_2    1
    rhs       c145_2    0
    rhs       c146_2    0
    rhs       c147_2    0
    rhs       c148_2    1
    rhs       c149_2    1
    rhs       c150_2    1
    rhs       c151_2    1
    rhs       c152_2    1
    rhs       c153_2    1
    rhs       c154_2    1
    rhs       c155_2    1
    rhs       c156_2    1
    rhs       c157_2    1
    rhs       c158_2    1
    rhs       c159_2    1
    rhs       c160_2    1
    rhs       c161_2    1
    rhs       c162_2    1
    rhs       c163_2    1
    rhs       c164_2    1
    rhs       c165_2    1
    rhs       c166_2    1
    rhs       c167_2    1
    rhs       c168_2    1
    rhs       c169_2    1
    rhs       c170_2    1
    rhs       c171_2    1
    rhs       c172_2    0
    rhs       c173_2    0
    rhs       c174_2    0
    rhs       c175_2    0
    rhs       c176_2    1
    rhs       c177_2    1
    rhs       c178_2    1
    rhs       c179_2    1
    rhs       c180_2    1
    rhs       c181_2    1
    rhs       c182_2    1
    rhs       c183_2    1
    rhs       c184_2    1
    rhs       c185_2    1
    rhs       c186_2    1
    rhs       c187_2    1
    rhs       c188_2    1
    rhs       c189_2    1
    rhs       c190_2    1
    rhs       c191_2    1
    rhs       c192_2    1
    rhs       c193_2    1
    rhs       c194_2    0
    rhs       c195_2    0
    rhs       c196_2    0
    rhs       c197_2    1
    rhs       c198_2    1
    rhs       c199_2    1
    rhs       c200_2    1
    rhs       c201_2    1
    rhs       c202_2    1
    rhs       c203_2    1
    rhs       c204_2    1
    rhs       c205_2    1
    rhs       c206_2    1
    rhs       c207_2    1
    rhs       c208_2    1
    rhs       c209_2    1
    rhs       c210_2    1
    rhs       c211_2    1
    rhs       c212_2    1
    rhs       c213_2    1
    rhs       c214_2    1
    rhs       c215_2    1
    rhs       c216_2    1
    rhs       c217_2    1
    rhs       c218_2    1
    rhs       c219_2    1
    rhs       c220_2    0
    rhs       c221_2    0
    rhs       c222_2    1
    rhs       c223_2    1
    rhs       c224_2    1
    rhs       c225_2    1
    rhs       c226_2    1
    rhs       c227_2    1
    rhs       c228_2    1
    rhs       c229_2    1
    rhs       c230_2    1
    rhs       c231_2    1
    rhs       c232_2    1
    rhs       c233_2    1
    rhs       c234_2    1
    rhs       c235_2    1
    rhs       c236_2    1
    rhs       c237_2    1
    rhs       c238_2    1
    rhs       c239_2    1
    rhs       c240_2    1
    rhs       c241_2    1
    rhs       c242_2    0
    rhs       c243_2    0
    rhs       c244_2    1
    rhs       c245_2    1
    rhs       c246_2    1
    rhs       c247_2    1
    rhs       c248_2    1
    rhs       c249_2    1
    rhs       c250_2    1
    rhs       c251_2    1
    rhs       c252_2    1
    rhs       c253_2    1
    rhs       c254_2    1
    rhs       c255_2    1
    rhs       c256_2    1
    rhs       c257_2    1
    rhs       c258_2    1
    rhs       c259_2    1
    rhs       c260_2    1
    rhs       c261_2    1
    rhs       c262_2    1
    rhs       c263_2    1
    rhs       c264_2    1
    rhs       c265_2    1
    rhs       c266_2    0
    rhs       c267_2    0
    rhs       c268_2    0
    rhs       c269_2    0
    rhs       c270_2    1
    rhs       c271_2    1
    rhs       c272_1    1
    rhs       c273_1    1
    rhs       c274_1    1
    rhs       c275_1    1
    rhs       c276_1    1
    rhs       c277_1    1
    rhs       c278_1    1
    rhs       c279_1    1
    rhs       c280_1    1
    rhs       c281_1    1
    rhs       c282_1    1
    rhs       c283_1    1
    rhs       c284_1    1
    rhs       c285_1    1
    rhs       c286_1    1
    rhs       c287_1    0
    rhs       c288_1    0
    rhs       c289_1    0
    rhs       c290_1    0
    rhs       c291_1    1
    rhs       c292_1    1
    rhs       c293_1    1
    rhs       c294_1    1
    rhs       c295_1    1
    rhs       c296_1    1
    rhs       c297_1    1
    rhs       c298_1    1
    rhs       c299_1    1
    rhs       c300_1    1
    rhs       c301_1    1
    rhs       c302_1    1
    rhs       c303_1    1
    rhs       c304_1    1
    rhs       c305_1    1
    rhs       c306_1    1
    rhs       c307_1    1
    rhs       c308_1    1
    rhs       c309_1    1
    rhs       c310_1    1
    rhs       c311_1    1
    rhs       c312_1    0
    rhs       c313_1    0
    rhs       c314_1    1
    rhs       c315_1    1
    rhs       c316_1    1
    rhs       c317_1    1
    rhs       c318_1    1
    rhs       c319_1    1
    rhs       c320_1    1
    rhs       c321_1    1
    rhs       c322_1    1
    rhs       c323_1    1
    rhs       c324_1    1
    rhs       c325_1    1
    rhs       c326_1    1
    rhs       c327_1    1
    rhs       c328_1    1
    rhs       c329_1    1
    rhs       c330_1    1
    rhs       c331_1    1
    rhs       c332_1    1
    rhs       c333_1    1
    rhs       c334_1    1
    rhs       c335_1    0
    rhs       c336_1    0
    rhs       c1_1      0
    rhs       c2_1      0
    rhs       c3_1      0
    rhs       c4_1      0
    rhs       c5_1      0
    rhs       c6_1      0
    rhs       c7_1      0
    rhs       c8_1      0
    rhs       c9_1      0
    rhs       c10_1     0
    rhs       c11_1     0
    rhs       c12_1     0
    rhs       c13_1     0
    rhs       c14_1     0
    rhs       c15_1     0
    rhs       c16_1     0
    rhs       c17_1     0
    rhs       c18_1     0
    rhs       c19_1     0
    rhs       c20_1     0
    rhs       c21_1     0
    rhs       c22_1     0
    rhs       c23_1     0
    rhs       c24_1     0
    rhs       c25_1     0
    rhs       c26_1     0
    rhs       c27_1     0
    rhs       c28_1     0
    rhs       c29_1     0
    rhs       c30_1     0
    rhs       c31_1     0
    rhs       c32_1     0
    rhs       c33_1     0
    rhs       c34_1     0
    rhs       c35_1     0
    rhs       c36_1     0
    rhs       c37_1     0
    rhs       c38_1     0
    rhs       c39_1     0
    rhs       c40_1     0
    rhs       c41_1     0
    rhs       c42_1     0
    rhs       c43_1     0
    rhs       c44_1     0
    rhs       c45_1     0
    rhs       c46_1     0
    rhs       c47_1     0
    rhs       c48_1     0
    rhs       c49_1     0
    rhs       c50_1     0
    rhs       c51_1     0
    rhs       c52_1     0
    rhs       c53_1     0
    rhs       c54_1     0
    rhs       c55_1     0
    rhs       c56_1     0
    rhs       c57_1     0
    rhs       c58_1     0
    rhs       c59_1     0
    rhs       c60_1     0
    rhs       c61_1     0
    rhs       c62_1     0
    rhs       c63_1     0
    rhs       c64_1     0
    rhs       c65_1     0
    rhs       c66_1     0
    rhs       c67_1     0
    rhs       c68_1     0
    rhs       c69_1     0
    rhs       c70_1     0
    rhs       c71_1     0
    rhs       c72_1     0
    rhs       c73_1     0
    rhs       c74_1     0
    rhs       c75_1     0
    rhs       c76_1     0
    rhs       c77_1     0
    rhs       c78_1     0
    rhs       c79_1     0
    rhs       c80_1     0
    rhs       c81_1     0
    rhs       c82_1     0
    rhs       c83_1     0
    rhs       c84_1     0
    rhs       c85_1     0
    rhs       c86_1     0
    rhs       c87_1     0
    rhs       c88_1     0
    rhs       c89_1     0
    rhs       c90_1     0
    rhs       c91_1     0
    rhs       c92_1     0
    rhs       c93_1     0
    rhs       c94_1     0
    rhs       c95_1     0
    rhs       c96_1     0
    rhs       c97_1     0
    rhs       c98_1     0
    rhs       c99_1     0
    rhs       c100_1    0
    rhs       c101_1    0
    rhs       c102_1    0
    rhs       c103_1    0
    rhs       c104_1    0
    rhs       c105_1    0
    rhs       c106_1    0
    rhs       c107_1    0
    rhs       c108_1    0
    rhs       c109_1    0
    rhs       c110_1    0
    rhs       c111_1    0
    rhs       c112_1    0
    rhs       c113_1    0
    rhs       c114_1    0
    rhs       c115_1    0
    rhs       c116_1    0
    rhs       c117_1    0
    rhs       c118_1    0
    rhs       c119_1    0
    rhs       c120_1    0
    rhs       c121_1    0
    rhs       c122_1    0
    rhs       c123_1    0
    rhs       c124_1    0
    rhs       c125_1    0
    rhs       c126_1    0
    rhs       c127_1    0
    rhs       c128_1    0
    rhs       c129_1    0
    rhs       c130_1    0
    rhs       c131_1    0
    rhs       c132_1    0
    rhs       c133_1    0
    rhs       c134_1    0
    rhs       c135_1    0
    rhs       c136_1    0
    rhs       c137_1    0
    rhs       c138_1    0
    rhs       c139_1    0
    rhs       c140_1    0
    rhs       c141_1    0
    rhs       c142_1    0
    rhs       c143_1    0
    rhs       c144_1    0
    rhs       c145_1    0
    rhs       c146_1    0
    rhs       c147_1    0
    rhs       c148_1    0
    rhs       c149_1    0
    rhs       c150_1    0
    rhs       c151_1    0
    rhs       c152_1    0
    rhs       c153_1    0
    rhs       c154_1    0
    rhs       c155_1    0
    rhs       c156_1    0
    rhs       c157_1    0
    rhs       c158_1    0
    rhs       c159_1    0
    rhs       c160_1    0
    rhs       c161_1    0
    rhs       c162_1    0
    rhs       c163_1    0
    rhs       c164_1    0
    rhs       c165_1    0
    rhs       c166_1    0
    rhs       c167_1    0
    rhs       c168_1    0
    rhs       c169_1    0
    rhs       c170_1    0
    rhs       c171_1    0
    rhs       c172_1    0
    rhs       c173_1    0
    rhs       c174_1    0
    rhs       c175_1    0
    rhs       c176_1    0
    rhs       c177_1    0
    rhs       c178_1    0
    rhs       c179_1    0
    rhs       c180_1    0
    rhs       c181_1    0
    rhs       c182_1    0
    rhs       c183_1    0
    rhs       c184_1    0
    rhs       c185_1    0
    rhs       c186_1    0
    rhs       c187_1    0
    rhs       c188_1    0
    rhs       c189_1    0
    rhs       c190_1    0
    rhs       c191_1    0
    rhs       c192_1    0
    rhs       c193_1    0
    rhs       c194_1    0
    rhs       c195_1    0
    rhs       c196_1    0
    rhs       c197_1    0
    rhs       c198_1    0
    rhs       c199_1    0
    rhs       c200_1    0
    rhs       c201_1    0
    rhs       c202_1    0
    rhs       c203_1    0
    rhs       c204_1    0
    rhs       c205_1    0
    rhs       c206_1    0
    rhs       c207_1    0
    rhs       c208_1    0
    rhs       c209_1    0
    rhs       c210_1    0
    rhs       c211_1    0
    rhs       c212_1    0
    rhs       c213_1    0
    rhs       c214_1    0
    rhs       c215_1    0
    rhs       c216_1    0
    rhs       c217_1    0
    rhs       c218_1    0
    rhs       c219_1    0
    rhs       c220_1    0
    rhs       c221_1    0
    rhs       c222_1    0
    rhs       c223_1    0
    rhs       c224_1    0
    rhs       c225_1    0
    rhs       c226_1    0
    rhs       c227_1    0
    rhs       c228_1    0
    rhs       c229_1    0
    rhs       c230_1    0
    rhs       c231_1    0
    rhs       c232_1    0
    rhs       c233_1    0
    rhs       c234_1    0
    rhs       c235_1    0
    rhs       c236_1    0
    rhs       c237_1    0
    rhs       c238_1    0
    rhs       c239_1    0
    rhs       c240_1    0
    rhs       c241_1    0
    rhs       c242_1    0
    rhs       c243_1    0
    rhs       c244_1    0
    rhs       c245_1    0
    rhs       c246_1    0
    rhs       c247_1    0
    rhs       c248_1    0
    rhs       c249_1    0
    rhs       c250_1    0
    rhs       c251_1    0
    rhs       c252_1    0
    rhs       c253_1    0
    rhs       c254_1    0
    rhs       c255_1    0
    rhs       c256_1    0
    rhs       c257_1    0
    rhs       c258_1    0
    rhs       c259_1    0
    rhs       c260_1    0
    rhs       c261_1    0
    rhs       c262_1    0
    rhs       c263_1    0
    rhs       c264_1    0
    rhs       c265_1    0
    rhs       c266_1    0
    rhs       c267_1    0
    rhs       c268_1    0
    rhs       c269_1    0
    rhs       c270_1    0
    rhs       c271_1    0
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       1
    rhs       c19       1
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       1
    rhs       c46       1
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       1
    rhs       c73       1
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       1
    rhs       c100      1
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      1
    rhs       c127      1
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      1
    rhs       c154      1
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      1
    rhs       c181      1
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      1
    rhs       c208      1
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      1
    rhs       c235      1
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      1
    rhs       c262      1
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      0
    rhs       c275      0
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      1
    rhs       c289      1
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      0
    rhs       c299      0
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      1
    rhs       c316      1
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      1
    rhs       c343      1
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      1
    rhs       c370      1
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      1
    rhs       c397      1
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      1
    rhs       c424      1
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      1
    rhs       c451      1
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      1
    rhs       c478      1
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      1
    rhs       c505      1
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      1
    rhs       c532      1
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      1
    rhs       c559      1
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      1
    rhs       c586      1
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      1
    rhs       c613      1
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      1
    rhs       c640      1
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      1
    rhs       c667      1
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      1
    rhs       c694      1
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      1
    rhs       c721      1
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      1
    rhs       c748      1
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      1
    rhs       c775      1
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      1
    rhs       c802      1
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      1
    rhs       c829      1
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      1
    rhs       c856      1
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      1
    rhs       c883      1
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      1
    rhs       c910      1
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      1
    rhs       c937      1
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      1
    rhs       c964      1
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      1
    rhs       c991      1
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     1
    rhs       c1018     1
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     1
    rhs       c1045     1
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     1
    rhs       c1072     1
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     1
    rhs       c1099     1
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     1
    rhs       c1126     1
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     1
    rhs       c1153     1
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     1
    rhs       c1180     1
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     1
    rhs       c1207     1
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     1
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     1
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     1
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     1
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     1
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     1
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     1
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     1
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     1
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     1
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     1
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     1
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     1
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     1
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     1
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     1
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     1
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     1
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     1
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     1
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     1
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     1
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     1
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     1
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     1
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     1
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     1
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     1
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     1
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     1
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     1
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     1
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     1
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     1
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     1
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     1
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     1
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     1
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     1
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     1
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     1
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     1
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     1
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     1
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     1
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
    rhs       c1981     0
    rhs       c1982     0
    rhs       c1983     0
    rhs       c1984     0
    rhs       c1985     0
    rhs       c1986     0
    rhs       c1987     0
    rhs       c1988     0
    rhs       c1989     0
    rhs       c1990     0
    rhs       c1991     0
    rhs       c1992     0
    rhs       c1993     0
    rhs       c1994     0
    rhs       c1995     0
    rhs       c1996     0
    rhs       c1997     0
    rhs       c1998     0
    rhs       c1999     0
    rhs       c2000     0
    rhs       c2001     0
    rhs       c2002     0
    rhs       c2003     0
    rhs       c2004     0
    rhs       c2005     0
    rhs       c2006     0
    rhs       c2007     0
    rhs       c2008     0
    rhs       c2009     0
    rhs       c2010     0
    rhs       c2011     0
    rhs       c2012     0
    rhs       c2013     0
    rhs       c2014     0
    rhs       c2015     0
    rhs       c2016     0
    rhs       c2017     0
    rhs       c2018     0
    rhs       c2019     0
    rhs       c2020     0
    rhs       c2021     0
    rhs       c2022     0
    rhs       c2023     0
    rhs       c2024     0
    rhs       c2025     0
    rhs       c2026     0
    rhs       c2027     0
    rhs       c2028     0
    rhs       c2029     0
    rhs       c2030     0
    rhs       c2031     0
    rhs       c2032     0
    rhs       c2033     0
    rhs       c2034     0
    rhs       c2035     0
    rhs       c2036     0
    rhs       c2037     0
    rhs       c2038     0
    rhs       c2039     0
    rhs       c2040     0
    rhs       c2041     0
    rhs       c2042     0
    rhs       c2043     0
    rhs       c2044     0
    rhs       c2045     0
    rhs       c2046     0
    rhs       c2047     0
    rhs       c2048     0
    rhs       c2049     0
    rhs       c2050     0
    rhs       c2051     0
    rhs       c2052     0
    rhs       c2053     0
    rhs       c2054     0
    rhs       c2055     0
    rhs       c2056     0
    rhs       c2057     0
    rhs       c2058     0
    rhs       c2059     0
    rhs       c2060     0
    rhs       c2061     0
    rhs       c2062     0
    rhs       c2063     0
    rhs       c2064     0
    rhs       c2065     0
    rhs       c2066     0
    rhs       c2067     0
    rhs       c2068     0
    rhs       c2069     0
    rhs       c2070     0
    rhs       c2071     0
    rhs       c2072     0
    rhs       c2073     0
    rhs       c2074     0
    rhs       c2075     0
    rhs       c2076     0
    rhs       c2077     0
    rhs       c2078     0
    rhs       c2079     0
    rhs       c2080     0
    rhs       c2081     0
    rhs       c2082     0
    rhs       c2083     0
    rhs       c2084     0
    rhs       c2085     0
    rhs       c2086     0
    rhs       c2087     0
    rhs       c2088     0
    rhs       c2089     0
    rhs       c2090     0
    rhs       c2091     0
    rhs       c2092     0
    rhs       c2093     0
    rhs       c2094     0
    rhs       c2095     0
    rhs       c2096     0
    rhs       c2097     0
    rhs       c2098     0
    rhs       c2099     0
    rhs       c2100     0
    rhs       c2101     0
    rhs       c2102     0
    rhs       c2103     0
    rhs       c2104     0
    rhs       c2105     0
    rhs       c2106     0
    rhs       c2107     0
    rhs       c2108     0
    rhs       c2109     0
    rhs       c2110     0
    rhs       c2111     0
    rhs       c2112     0
    rhs       c2113     0
    rhs       c2114     0
    rhs       c2115     0
    rhs       c2116     0
    rhs       c2117     0
    rhs       c2118     0
    rhs       c2119     0
    rhs       c2120     0
    rhs       c2121     0
    rhs       c2122     0
    rhs       c2123     0
    rhs       c2124     0
    rhs       c2125     0
    rhs       c2126     0
    rhs       c2127     0
    rhs       c2128     0
    rhs       c2129     0
    rhs       c2130     0
    rhs       c2131     0
    rhs       c2132     0
    rhs       c2133     0
    rhs       c2134     0
    rhs       c2135     0
    rhs       c2136     0
    rhs       c2137     0
    rhs       c2138     0
    rhs       c2139     0
    rhs       c2140     0
    rhs       c2141     0
    rhs       c2142     0
    rhs       c2143     0
    rhs       c2144     0
    rhs       c2145     0
    rhs       c2146     0
    rhs       c2147     0
    rhs       c2148     0
    rhs       c2149     0
    rhs       c2150     0
    rhs       c2151     0
    rhs       c2152     0
    rhs       c2153     0
    rhs       c2154     0
    rhs       c2155     0
    rhs       c2156     0
    rhs       c2157     0
    rhs       c2158     0
    rhs       c2159     0
    rhs       c2160     0
    rhs       c2161     0
    rhs       c2162     0
    rhs       c2163     0
    rhs       c2164     0
    rhs       c2165     0
    rhs       c2166     0
    rhs       c2167     0
    rhs       c2168     0
    rhs       c2169     0
    rhs       c2170     0
    rhs       c2171     0
    rhs       c2172     0
    rhs       c2173     0
    rhs       c2174     0
    rhs       c2175     0
    rhs       c2176     0
    rhs       c2177     0
    rhs       c2178     0
    rhs       c2179     0
    rhs       c2180     0
    rhs       c2181     0
    rhs       c2182     0
    rhs       c2183     0
    rhs       c2184     0
    rhs       c2185     0
    rhs       c2186     0
    rhs       c2187     0
    rhs       c2188     0
    rhs       c2189     0
    rhs       c2190     0
    rhs       c2191     0
    rhs       c2192     0
    rhs       c2193     0
    rhs       c2194     0
    rhs       c2195     0
    rhs       c2196     0
    rhs       c2197     0
    rhs       c2198     0
    rhs       c2199     0
    rhs       c2200     0
    rhs       c2201     0
    rhs       c2202     0
    rhs       c2203     0
    rhs       c2204     0
    rhs       c2205     0
    rhs       c2206     0
    rhs       c2207     0
    rhs       c2208     0
    rhs       c2209     0
    rhs       c2210     0
    rhs       c2211     0
    rhs       c2212     0
    rhs       c2213     0
    rhs       c2214     0
    rhs       c2215     0
    rhs       c2216     0
    rhs       c2217     0
    rhs       c2218     0
    rhs       c2219     0
    rhs       c2220     0
    rhs       c2221     0
    rhs       c2222     0
    rhs       c2223     0
    rhs       c2224     0
    rhs       c2225     0
    rhs       c2226     0
    rhs       c2227     0
    rhs       c2228     0
    rhs       c2229     0
    rhs       c2230     0
    rhs       c2231     0
    rhs       c2232     0
    rhs       c2233     0
    rhs       c2234     0
    rhs       c2235     0
    rhs       c2236     0
    rhs       c2237     0
    rhs       c2238     0
    rhs       c2239     0
    rhs       c2240     0
    rhs       c2241     0
    rhs       c2242     0
    rhs       c2243     0
    rhs       c2244     0
    rhs       c2245     0
    rhs       c2246     0
    rhs       c2247     0
    rhs       c2248     0
    rhs       c2249     0
    rhs       c2250     0
    rhs       c2251     0
    rhs       c2252     0
    rhs       c2253     0
    rhs       c2254     0
    rhs       c2255     0
    rhs       c2256     0
    rhs       c2257     0
    rhs       c2258     0
    rhs       c2259     0
    rhs       c2260     0
    rhs       c2261     0
    rhs       c2262     0
    rhs       c2263     0
    rhs       c2264     0
    rhs       c2265     0
    rhs       c2266     0
    rhs       c2267     0
    rhs       c2268     0
    rhs       c2269     0
    rhs       c2270     0
    rhs       c2271     0
    rhs       c2272     0
    rhs       c2273     0
    rhs       c2274     0
    rhs       c2275     0
    rhs       c2276     0
    rhs       c2277     0
    rhs       c2278     0
    rhs       c2279     0
    rhs       c2280     0
    rhs       c2281     0
    rhs       c2282     0
    rhs       c2283     0
    rhs       c2284     0
    rhs       c2285     0
    rhs       c2286     0
    rhs       c2287     0
    rhs       c2288     0
    rhs       c2289     0
    rhs       c2290     0
    rhs       c2291     0
    rhs       c2292     0
    rhs       c2293     0
    rhs       c2294     0
    rhs       c2295     0
    rhs       c2296     0
    rhs       c2297     0
    rhs       c2298     0
    rhs       c2299     0
    rhs       c2300     0
    rhs       c2301     0
    rhs       c2302     0
    rhs       c2303     0
    rhs       c2304     0
    rhs       c2305     0
    rhs       c2306     0
    rhs       c2307     0
    rhs       c2308     0
    rhs       c2309     0
    rhs       c2310     0
    rhs       c2311     0
    rhs       c2312     0
    rhs       c2313     0
    rhs       c2314     0
    rhs       c2315     0
    rhs       c2316     0
    rhs       c2317     0
    rhs       c2318     0
    rhs       c2319     0
    rhs       c2320     0
    rhs       c2321     0
    rhs       c2322     0
    rhs       c2323     0
    rhs       c2324     0
    rhs       c2325     0
    rhs       c2326     0
    rhs       c2327     0
    rhs       c2328     0
    rhs       c2329     0
    rhs       c2330     0
    rhs       c2331     0
    rhs       c2332     0
    rhs       c2333     0
    rhs       c2334     0
    rhs       c2335     0
    rhs       c2336     0
    rhs       c2337     0
    rhs       c2338     0
    rhs       c2339     0
    rhs       c2340     0
    rhs       c2341     0
    rhs       c2342     0
    rhs       c2343     0
    rhs       c2344     0
    rhs       c2345     0
    rhs       c2346     0
    rhs       c2347     0
    rhs       c2348     0
    rhs       c2349     0
    rhs       c2350     0
    rhs       c2351     0
    rhs       c2352     0
    rhs       c2353     0
    rhs       c2354     0
    rhs       c2355     0
    rhs       c2356     0
    rhs       c2357     0
    rhs       c2358     0
    rhs       c2359     0
    rhs       c2360     0
    rhs       c2361     0
    rhs       c2362     0
    rhs       c2363     0
    rhs       c2364     0
    rhs       c2365     0
    rhs       c2366     0
    rhs       c2367     0
    rhs       c2368     0
    rhs       c2369     0
    rhs       c2370     0
    rhs       c2371     0
    rhs       c2372     0
    rhs       c2373     0
    rhs       c2374     0
    rhs       c2375     0
    rhs       c2376     0
    rhs       c2377     0
    rhs       c2378     0
    rhs       c2379     0
    rhs       c2380     0
    rhs       c2381     0
    rhs       c2382     0
    rhs       c2383     0
    rhs       c2384     0
    rhs       c2385     0
    rhs       c2386     0
    rhs       c2387     0
    rhs       c2388     0
    rhs       c2389     0
    rhs       c2390     0
    rhs       c2391     0
    rhs       c2392     0
    rhs       c2393     0
    rhs       c2394     0
    rhs       c2395     0
    rhs       c2396     0
    rhs       c2397     0
    rhs       c2398     0
    rhs       c2399     0
    rhs       c2400     0
    rhs       c2401     0
    rhs       c2402     0
    rhs       c2403     0
    rhs       c2404     0
    rhs       c2405     0
    rhs       c2406     0
    rhs       c2407     0
    rhs       c2408     0
    rhs       c2409     0
    rhs       c2410     0
    rhs       c2411     0
    rhs       c2412     0
    rhs       c2413     0
    rhs       c2414     0
    rhs       c2415     0
    rhs       c2416     0
    rhs       c2417     0
    rhs       c2418     0
    rhs       c2419     0
    rhs       c2420     0
    rhs       c2421     0
    rhs       c2422     0
    rhs       c2423     0
    rhs       c2424     0
    rhs       c2425     0
    rhs       c2426     0
    rhs       c2427     0
    rhs       c2428     0
    rhs       c2429     0
    rhs       c2430     0
    rhs       c2431     0
    rhs       c2432     0
    rhs       c2433     0
    rhs       c2434     0
    rhs       c2435     0
    rhs       c2436     0
    rhs       c2437     0
    rhs       c2438     0
    rhs       c2439     0
    rhs       c2440     0
    rhs       c2441     0
    rhs       c2442     0
    rhs       c2443     0
    rhs       c2444     0
    rhs       c2445     0
    rhs       c2446     0
    rhs       c2447     0
    rhs       c2448     0
    rhs       c2449     0
    rhs       c2450     0
    rhs       c2451     0
    rhs       c2452     0
    rhs       c2453     0
    rhs       c2454     0
    rhs       c2455     0
    rhs       c2456     0
    rhs       c2457     0
    rhs       c2458     0
    rhs       c2459     0
    rhs       c2460     0
    rhs       c2461     0
    rhs       c2462     0
    rhs       c2463     0
    rhs       c2464     0
    rhs       c2465     0
    rhs       c2466     0
    rhs       c2467     0
    rhs       c2468     0
    rhs       c2469     0
    rhs       c2470     0
    rhs       c2471     0
    rhs       c2472     0
    rhs       c2473     0
    rhs       c2474     0
    rhs       c2475     0
    rhs       c2476     0
    rhs       c2477     0
    rhs       c2478     0
    rhs       c2479     0
    rhs       c2480     0
    rhs       c2481     0
    rhs       c2482     0
    rhs       c2483     0
    rhs       c2484     0
    rhs       c2485     0
    rhs       c2486     0
    rhs       c2487     0
    rhs       c2488     0
    rhs       c2489     0
    rhs       c2490     0
    rhs       c2491     0
    rhs       c2492     0
    rhs       c2493     0
    rhs       c2494     0
    rhs       c2495     0
    rhs       c2496     0
    rhs       c2497     0
    rhs       c2498     0
    rhs       c2499     0
    rhs       c2500     0
    rhs       c2501     0
    rhs       c2502     0
    rhs       c2503     0
    rhs       c2504     0
    rhs       c2505     0
    rhs       c2506     0
    rhs       c2507     0
    rhs       c2508     0
    rhs       c2509     0
    rhs       c2510     0
    rhs       c2511     0
    rhs       c2512     0
    rhs       c2513     0
    rhs       c2514     0
    rhs       c2515     0
    rhs       c2516     0
    rhs       c2517     0
    rhs       c2518     0
    rhs       c2519     0
    rhs       c2520     0
    rhs       c2521     0
    rhs       c2522     0
    rhs       c2523     0
    rhs       c2524     0
    rhs       c2525     0
    rhs       c2526     0
    rhs       c2527     0
    rhs       c2528     0
    rhs       c2529     0
    rhs       c2530     0
    rhs       c2531     0
    rhs       c2532     0
    rhs       c2533     0
    rhs       c2534     0
    rhs       c2535     0
    rhs       c2536     0
    rhs       c2537     0
    rhs       c2538     0
    rhs       c2539     0
    rhs       c2540     0
    rhs       c2541     0
    rhs       c2542     0
    rhs       c2543     0
    rhs       c2544     0
    rhs       c2545     0
    rhs       c2546     0
    rhs       c2547     0
    rhs       c2548     0
    rhs       c2549     0
    rhs       c2550     0
    rhs       c2551     0
    rhs       c2552     0
    rhs       c2553     0
    rhs       c2554     0
    rhs       c2555     0
    rhs       c2556     0
    rhs       c2557     0
    rhs       c2558     0
    rhs       c2559     0
    rhs       c2560     0
    rhs       c2561     0
    rhs       c2562     0
    rhs       c2563     0
    rhs       c2564     0
    rhs       c2565     0
    rhs       c2566     0
    rhs       c2567     0
    rhs       c2568     0
    rhs       c2569     0
    rhs       c2570     0
    rhs       c2571     0
    rhs       c2572     0
    rhs       c2573     0
    rhs       c2574     0
    rhs       c2575     0
    rhs       c2576     0
    rhs       c2577     0
    rhs       c2578     0
    rhs       c2579     0
    rhs       c2580     0
    rhs       c2581     0
    rhs       c2582     0
    rhs       c2583     0
    rhs       c2584     0
    rhs       c2585     0
    rhs       c2586     0
    rhs       c2587     0
    rhs       c2588     0
    rhs       c2589     0
    rhs       c2590     0
    rhs       c2591     0
    rhs       c2592     0
    rhs       c2593     0
    rhs       c2594     0
    rhs       c2595     0
    rhs       c2596     0
    rhs       c2597     0
    rhs       c2598     0
    rhs       c2599     0
    rhs       c2600     0
    rhs       c2601     0
    rhs       c2602     0
    rhs       c2603     0
    rhs       c2604     0
    rhs       c2605     0
    rhs       c2606     0
    rhs       c2607     0
    rhs       c2608     0
    rhs       c2609     0
    rhs       c2610     0
    rhs       c2611     0
    rhs       c2612     0
    rhs       c2613     0
    rhs       c2614     0
    rhs       c2615     0
    rhs       c2616     0
    rhs       c2617     0
    rhs       c2618     0
    rhs       c2619     0
    rhs       c2620     0
    rhs       c2621     0
    rhs       c2622     0
    rhs       c2623     0
    rhs       c2624     0
    rhs       c2625     0
    rhs       c2626     0
    rhs       c2627     0
    rhs       c2628     0
    rhs       c2629     0
    rhs       c2630     0
    rhs       c2631     0
    rhs       c2632     0
    rhs       c2633     0
    rhs       c2634     0
    rhs       c2635     0
    rhs       c2636     0
    rhs       c2637     0
    rhs       c2638     0
    rhs       c2639     0
    rhs       c2640     0
    rhs       c2641     0
    rhs       c2642     0
    rhs       c2643     0
    rhs       c2644     0
    rhs       c2645     0
    rhs       c2646     0
    rhs       c2647     0
    rhs       c2648     0
    rhs       c2649     0
    rhs       c2650     0
    rhs       c2651     0
    rhs       c2652     0
    rhs       c2653     0
    rhs       c2654     0
    rhs       c2655     0
    rhs       c2656     0
    rhs       c2657     0
    rhs       c2658     0
    rhs       c2659     0
    rhs       c2660     0
    rhs       c2661     0
    rhs       c2662     0
    rhs       c2663     0
    rhs       c2664     0
    rhs       c2665     0
    rhs       c2666     0
    rhs       c2667     0
    rhs       c2668     0
    rhs       c2669     0
    rhs       c2670     0
    rhs       c2671     0
    rhs       c2672     0
    rhs       c2673     0
    rhs       c2674     0
    rhs       c2675     0
    rhs       c2676     0
    rhs       c2677     0
    rhs       c2678     0
    rhs       c2679     0
    rhs       c2680     0
    rhs       c2681     0
    rhs       c2682     0
    rhs       c2683     0
    rhs       c2684     0
    rhs       c2685     0
    rhs       c2686     0
    rhs       c2687     0
    rhs       c2688     0
    rhs       c2689     0
    rhs       c2690     0
    rhs       c2691     0
    rhs       c2692     0
    rhs       c2693     0
    rhs       c2694     0
    rhs       c2695     0
    rhs       c2696     0
    rhs       c2697     0
    rhs       c2698     0
    rhs       c2699     0
    rhs       c2700     0
    rhs       c2701     0
    rhs       c2702     0
    rhs       c2703     0
    rhs       c2704     0
    rhs       c2705     0
    rhs       c2706     0
    rhs       c2707     0
    rhs       c2708     0
    rhs       c2709     0
    rhs       c2710     0
    rhs       c2711     0
    rhs       c2712     0
    rhs       c2713     0
    rhs       c2714     0
    rhs       c2715     0
    rhs       c2716     0
    rhs       c2717     0
    rhs       c2718     0
    rhs       c2719     0
    rhs       c2720     0
    rhs       c2721     0
    rhs       c2722     0
    rhs       c2723     0
    rhs       c2724     0
    rhs       c2725     0
    rhs       c2726     0
    rhs       c2727     0
    rhs       c2728     0
    rhs       c2729     0
    rhs       c2730     0
    rhs       c2731     0
    rhs       c2732     0
    rhs       c2733     0
    rhs       c2734     0
    rhs       c2735     0
    rhs       c2736     0
    rhs       c2737     0
    rhs       c2738     0
    rhs       c2739     0
    rhs       c2740     0
    rhs       c2741     0
    rhs       c2742     0
    rhs       c2743     0
    rhs       c2744     0
    rhs       c2745     0
    rhs       c2746     0
    rhs       c2747     0
    rhs       c2748     0
    rhs       c2749     0
    rhs       c2750     0
    rhs       c2751     0
    rhs       c2752     0
    rhs       c2753     0
    rhs       c2754     0
    rhs       c2755     0
    rhs       c2756     0
    rhs       c2757     0
    rhs       c2758     0
    rhs       c2759     0
    rhs       c2760     0
    rhs       c2761     0
    rhs       c2762     0
    rhs       c2763     0
    rhs       c2764     0
    rhs       c2765     0
    rhs       c2766     0
    rhs       c2767     0
    rhs       c2768     0
    rhs       c2769     0
    rhs       c2770     0
    rhs       c2771     0
    rhs       c2772     0
    rhs       c2773     0
    rhs       c2774     0
    rhs       c2775     0
    rhs       c2776     0
    rhs       c2777     0
    rhs       c2778     0
    rhs       c2779     0
    rhs       c2780     0
    rhs       c2781     0
    rhs       c2782     0
    rhs       c2783     0
    rhs       c2784     0
    rhs       c2785     0
    rhs       c2786     0
    rhs       c2787     0
    rhs       c2788     0
    rhs       c2789     0
    rhs       c2790     0
    rhs       c2791     0
    rhs       c2792     0
    rhs       c2793     0
    rhs       c2794     0
    rhs       c2795     0
    rhs       c2796     0
    rhs       c2797     0
    rhs       c2798     0
    rhs       c2799     0
    rhs       c2800     0
    rhs       c2801     0
    rhs       c2802     0
    rhs       c2803     0
    rhs       c2804     0
    rhs       c2805     0
    rhs       c2806     0
    rhs       c2807     0
    rhs       c2808     0
    rhs       c2809     0
    rhs       c2810     0
    rhs       c2811     0
    rhs       c2812     0
    rhs       c2813     0
    rhs       c2814     0
    rhs       c2815     0
    rhs       c2816     0
    rhs       c2817     0
    rhs       c2818     0
    rhs       c2819     0
    rhs       c2820     0
    rhs       c2821     0
    rhs       c2822     0
    rhs       c2823     0
    rhs       c2824     0
    rhs       c2825     0
    rhs       c2826     0
    rhs       c2827     0
    rhs       c2828     0
    rhs       c2829     0
    rhs       c2830     0
    rhs       c2831     0
    rhs       c2832     0
    rhs       c2833     0
    rhs       c2834     0
    rhs       c2835     0
    rhs       c2836     0
    rhs       c2837     0
    rhs       c2838     0
    rhs       c2839     0
    rhs       c2840     0
    rhs       c2841     0
    rhs       c2842     0
    rhs       c2843     0
    rhs       c2844     0
    rhs       c2845     0
    rhs       c2846     0
    rhs       c2847     0
    rhs       c2848     0
    rhs       c2849     0
    rhs       c2850     0
    rhs       c2851     0
    rhs       c2852     0
    rhs       c2853     0
    rhs       c2854     0
    rhs       c2855     0
    rhs       c2856     0
    rhs       c2857     0
    rhs       c2858     0
    rhs       c2859     0
    rhs       c2860     0
    rhs       c2861     0
    rhs       c2862     0
    rhs       c2863     0
    rhs       c2864     0
    rhs       c2865     0
    rhs       c2866     0
    rhs       c2867     0
    rhs       c2868     0
    rhs       c2869     0
    rhs       c2870     0
    rhs       c2871     0
    rhs       c2872     0
    rhs       c2873     0
    rhs       c2874     0
    rhs       c2875     0
    rhs       c2876     0
    rhs       c2877     0
    rhs       c2878     0
    rhs       c2879     0
    rhs       c2880     0
    rhs       c2881     0
    rhs       c2882     0
    rhs       c2883     0
    rhs       c2884     0
    rhs       c2885     0
    rhs       c2886     0
    rhs       c2887     0
    rhs       c2888     0
    rhs       c2889     0
    rhs       c2890     0
    rhs       c2891     0
    rhs       c2892     0
    rhs       c2893     0
    rhs       c2894     0
    rhs       c2895     0
    rhs       c2896     0
    rhs       c2897     0
    rhs       c2898     0
    rhs       c2899     0
    rhs       c2900     0
    rhs       c2901     0
    rhs       c2902     0
    rhs       c2903     0
    rhs       c2904     0
    rhs       c2905     0
    rhs       c2906     0
    rhs       c2907     0
    rhs       c2908     0
    rhs       c2909     0
    rhs       c2910     0
    rhs       c2911     0
    rhs       c2912     0
    rhs       c2913     0
    rhs       c2914     0
    rhs       c2915     0
    rhs       c2916     0
    rhs       c2917     0
    rhs       c2918     0
    rhs       c2919     0
    rhs       c2920     0
    rhs       c2921     0
    rhs       c2922     0
    rhs       c2923     0
    rhs       c2924     0
    rhs       c2925     0
    rhs       c2926     0
    rhs       c2927     0
    rhs       c2928     0
    rhs       c2929     0
    rhs       c2930     0
    rhs       c2931     0
    rhs       c2932     0
    rhs       c2933     0
    rhs       c2934     0
    rhs       c2935     0
    rhs       c2936     0
    rhs       c2937     0
    rhs       c2938     0
    rhs       c2939     0
    rhs       c2940     0
    rhs       c2941     0
    rhs       c2942     0
    rhs       c2943     0
    rhs       c2944     0
    rhs       c2945     0
    rhs       c2946     0
    rhs       c2947     0
    rhs       c2948     0
    rhs       c2949     0
    rhs       c2950     0
    rhs       c2951     0
    rhs       c2952     0
    rhs       c2953     0
    rhs       c2954     0
    rhs       c2955     0
    rhs       c2956     0
    rhs       c2957     0
    rhs       c2958     0
    rhs       c2959     0
    rhs       c2960     0
    rhs       c2961     0
    rhs       c2962     0
    rhs       c2963     0
    rhs       c2964     0
    rhs       c2965     0
    rhs       c2966     0
    rhs       c2967     0
    rhs       c2968     0
    rhs       c2969     0
    rhs       c2970     0
    rhs       c2971     0
    rhs       c2972     0
    rhs       c2973     0
    rhs       c2974     0
    rhs       c2975     0
    rhs       c2976     0
    rhs       c2977     0
    rhs       c2978     0
    rhs       c2979     0
    rhs       c2980     0
    rhs       c2981     0
    rhs       c2982     0
    rhs       c2983     0
    rhs       c2984     0
    rhs       c2985     0
    rhs       c2986     0
    rhs       c2987     0
    rhs       c2988     0
    rhs       c2989     0
    rhs       c2990     0
    rhs       c2991     0
    rhs       c2992     0
    rhs       c2993     0
    rhs       c2994     0
    rhs       c2995     0
    rhs       c2996     0
    rhs       c2997     0
    rhs       c2998     0
    rhs       c2999     0
    rhs       c3000     0
    rhs       c3001     0
    rhs       c3002     0
    rhs       c3003     0
    rhs       c3004     0
    rhs       c3005     0
    rhs       c3006     0
    rhs       c3007     0
    rhs       c3008     0
    rhs       c3009     0
    rhs       c3010     0
    rhs       c3011     0
    rhs       c3012     0
    rhs       c3013     0
    rhs       c3014     0
    rhs       c3015     0
    rhs       c3016     0
    rhs       c3017     0
    rhs       c3018     0
    rhs       c3019     0
    rhs       c3020     0
    rhs       c3021     0
    rhs       c3022     0
    rhs       c3023     0
    rhs       c3024     0
    rhs       c3025     0
    rhs       c3026     0
    rhs       c3027     0
    rhs       c3028     0
    rhs       c3029     0
    rhs       c3030     0
    rhs       c3031     0
    rhs       c3032     0
    rhs       c3033     0
    rhs       c3034     0
    rhs       c3035     0
    rhs       c3036     0
    rhs       c3037     0
    rhs       c3038     0
    rhs       c3039     0
    rhs       c3040     0
    rhs       c3041     0
    rhs       c3042     0
    rhs       c3043     0
    rhs       c3044     0
    rhs       c3045     0
    rhs       c3046     0
    rhs       c3047     0
    rhs       c3048     0
    rhs       c3049     0
    rhs       c3050     0
    rhs       c3051     0
    rhs       c3052     0
    rhs       c3053     0
    rhs       c3054     0
    rhs       c3055     0
    rhs       c3056     0
    rhs       c3057     0
    rhs       c3058     0
    rhs       c3059     0
    rhs       c3060     0
    rhs       c3061     0
    rhs       c3062     0
    rhs       c3063     0
    rhs       c3064     0
    rhs       c3065     0
    rhs       c3066     0
    rhs       c3067     0
    rhs       c3068     0
    rhs       c3069     0
    rhs       c3070     0
    rhs       c3071     0
    rhs       c3072     0
    rhs       c3073     0
    rhs       c3074     0
    rhs       c3075     0
    rhs       c3076     0
    rhs       c3077     0
    rhs       c3078     0
    rhs       c3079     0
    rhs       c3080     0
    rhs       c3081     0
    rhs       c3082     0
    rhs       c3083     0
    rhs       c3084     0
    rhs       c3085     0
    rhs       c3086     0
    rhs       c3087     0
    rhs       c3088     0
    rhs       c3089     0
    rhs       c3090     0
    rhs       c3091     0
    rhs       c3092     0
    rhs       c3093     0
    rhs       c3094     0
    rhs       c3095     0
    rhs       c3096     0
    rhs       c3097     0
    rhs       c3098     0
    rhs       c3099     0
    rhs       c3100     0
    rhs       c3101     0
    rhs       c3102     0
    rhs       c3103     0
    rhs       c3104     0
    rhs       c3105     0
    rhs       c3106     0
    rhs       c3107     0
    rhs       c3108     0
    rhs       c3109     0
    rhs       c3110     0
    rhs       c3111     0
    rhs       c3112     0
    rhs       c3113     0
    rhs       c3114     0
    rhs       c3115     0
    rhs       c3116     0
    rhs       c3117     0
    rhs       c3118     0
    rhs       c3119     0
    rhs       c3120     0
    rhs       c3121     0
    rhs       c3122     0
    rhs       c3123     0
    rhs       c3124     0
    rhs       c3125     0
    rhs       c3126     0
    rhs       c3127     0
    rhs       c3128     0
    rhs       c3129     0
    rhs       c3130     0
    rhs       c3131     0
    rhs       c3132     0
    rhs       c3133     0
    rhs       c3134     0
    rhs       c3135     0
    rhs       c3136     0
    rhs       c3137     0
    rhs       c3138     0
    rhs       c3139     0
    rhs       c3140     0
    rhs       c3141     0
    rhs       c3142     0
    rhs       c3143     0
    rhs       c3144     0
    rhs       c3145     0
    rhs       c3146     0
    rhs       c3147     0
    rhs       c3148     0
    rhs       c3149     0
    rhs       c3150     0
    rhs       c3151     0
    rhs       c3152     0
    rhs       c3153     0
    rhs       c3154     0
    rhs       c3155     0
    rhs       c3156     0
    rhs       c3157     0
    rhs       c3158     0
    rhs       c3159     0
    rhs       c3160     0
    rhs       c3161     0
    rhs       c3162     0
    rhs       c3163     0
    rhs       c3164     0
    rhs       c3165     0
    rhs       c3166     0
    rhs       c3167     0
    rhs       c3168     0
    rhs       c3169     0
    rhs       c3170     0
    rhs       c3171     0
    rhs       c3172     0
    rhs       c3173     0
    rhs       c3174     0
    rhs       c3175     0
    rhs       c3176     0
    rhs       c3177     0
    rhs       c3178     0
    rhs       c3179     0
    rhs       c3180     0
    rhs       c3181     0
    rhs       c3182     0
    rhs       c3183     0
    rhs       c3184     0
    rhs       c3185     0
    rhs       c3186     0
    rhs       c3187     0
    rhs       c3188     0
    rhs       c3189     0
    rhs       c3190     0
    rhs       c3191     0
    rhs       c3192     0
    rhs       c3193     0
    rhs       c3194     0
    rhs       c3195     0
    rhs       c3196     0
    rhs       c3197     0
    rhs       c3198     0
    rhs       c3199     0
    rhs       c3200     0
    rhs       c3201     0
    rhs       c3202     0
    rhs       c3203     0
    rhs       c3204     0
    rhs       c3205     0
    rhs       c3206     0
    rhs       c3207     0
    rhs       c3208     0
    rhs       c3209     0
    rhs       c3210     0
    rhs       c3211     0
    rhs       c3212     0
    rhs       c3213     0
    rhs       c3214     0
    rhs       c3215     0
    rhs       c3216     0
    rhs       c3217     0
    rhs       c3218     0
    rhs       c3219     0
    rhs       c3220     0
    rhs       c3221     0
    rhs       c3222     0
    rhs       c3223     0
    rhs       c3224     0
    rhs       c3225     0
    rhs       c3226     0
    rhs       c3227     0
    rhs       c3228     0
    rhs       c3229     0
    rhs       c3230     0
    rhs       c3231     0
    rhs       c3232     0
    rhs       c3233     0
    rhs       c3234     0
    rhs       c3235     0
    rhs       c3236     0
    rhs       c3237     0
    rhs       c3238     0
    rhs       c3239     0
    rhs       c3240     0
    rhs       c3241     0
    rhs       c3242     0
    rhs       c3243     0
    rhs       c3244     0
    rhs       c3245     0
    rhs       c3246     0
    rhs       c3247     0
    rhs       c3248     0
    rhs       c3249     0
    rhs       c3250     0
    rhs       c3251     0
    rhs       c3252     0
    rhs       c3253     0
    rhs       c3254     0
    rhs       c3255     0
    rhs       c3256     0
    rhs       c3257     0
    rhs       c3258     0
    rhs       c3259     0
    rhs       c3260     0
    rhs       c3261     0
    rhs       c3262     0
    rhs       c3263     0
    rhs       c3264     0
    rhs       c3265     0
    rhs       c3266     0
    rhs       c3267     0
    rhs       c3268     0
    rhs       c3269     0
    rhs       c3270     0
    rhs       c3271     0
    rhs       c3272     0
    rhs       c3273     0
    rhs       c3274     0
    rhs       c3275     0
    rhs       c3276     0
    rhs       c3277     0
    rhs       c3278     0
    rhs       c3279     0
    rhs       c3280     0
    rhs       c3281     0
    rhs       c3282     0
    rhs       c3283     0
    rhs       c3284     0
    rhs       c3285     0
    rhs       c3286     0
    rhs       c3287     0
    rhs       c3288     0
    rhs       c3289     0
    rhs       c3290     0
    rhs       c3291     0
    rhs       c3292     0
    rhs       c3293     0
    rhs       c3294     0
    rhs       c3295     0
    rhs       c3296     0
    rhs       c3297     0
    rhs       c3298     0
    rhs       c3299     0
    rhs       c3300     0
    rhs       c3301     0
    rhs       c3302     0
    rhs       c3303     0
    rhs       c3304     0
    rhs       c3305     0
    rhs       c3306     0
    rhs       c3307     0
    rhs       c3308     0
    rhs       c3309     0
    rhs       c3310     0
    rhs       c3311     0
    rhs       c3312     0
    rhs       c3313     0
    rhs       c3314     0
    rhs       c3315     0
    rhs       c3316     0
    rhs       c3317     0
    rhs       c3318     0
    rhs       c3319     0
    rhs       c3320     0
    rhs       c3321     0
    rhs       c3322     0
    rhs       c3323     0
    rhs       c3324     0
    rhs       c3325     0
    rhs       c3326     0
    rhs       c3327     0
    rhs       c3328     0
    rhs       c3329     0
    rhs       c3330     0
    rhs       c3331     0
    rhs       c3332     0
    rhs       c3333     0
    rhs       c3334     0
    rhs       c3335     0
    rhs       c3336     0
    rhs       c3337     0
    rhs       c3338     0
    rhs       c3339     0
    rhs       c3340     0
    rhs       c3341     0
    rhs       c3342     0
    rhs       c3343     0
    rhs       c3344     0
    rhs       c3345     0
    rhs       c3346     0
    rhs       c3347     0
    rhs       c3348     0
    rhs       c3349     0
    rhs       c3350     0
    rhs       c3351     0
    rhs       c3352     0
    rhs       c3353     0
    rhs       c3354     0
    rhs       c3355     0
    rhs       c3356     0
    rhs       c3357     0
    rhs       c3358     0
    rhs       c3359     0
    rhs       c3360     0
    rhs       c3361     0
    rhs       c3362     0
    rhs       c3363     0
    rhs       c3364     0
    rhs       c3365     0
    rhs       c3366     0
    rhs       c3367     0
    rhs       c3368     0
    rhs       c3369     0
    rhs       c3370     0
    rhs       c3371     0
    rhs       c3372     0
    rhs       c3373     0
    rhs       c3374     0
    rhs       c3375     0
    rhs       c3376     0
    rhs       c3377     0
    rhs       c3378     0
    rhs       c3379     0
    rhs       c3380     0
    rhs       c3381     0
    rhs       c3382     0
    rhs       c3383     0
    rhs       c3384     0
    rhs       c3385     0
    rhs       c3386     0
    rhs       c3387     0
    rhs       c3388     0
    rhs       c3389     0
    rhs       c3390     0
    rhs       c3391     0
    rhs       c3392     0
    rhs       c3393     0
    rhs       c3394     0
    rhs       c3395     0
    rhs       c3396     0
    rhs       c3397     0
    rhs       c3398     0
    rhs       c3399     0
    rhs       c3400     0
    rhs       c3401     0
    rhs       c3402     0
    rhs       c3403     0
    rhs       c3404     0
    rhs       c3405     0
    rhs       c3406     0
    rhs       c3407     0
    rhs       c3408     0
    rhs       c3409     0
    rhs       c3410     0
    rhs       c3411     0
    rhs       c3412     0
    rhs       c3413     0
    rhs       c3414     0
    rhs       c3415     0
    rhs       c3416     0
    rhs       c3417     0
    rhs       c3418     0
    rhs       c3419     0
    rhs       c3420     0
    rhs       c3421     0
    rhs       c3422     0
    rhs       c3423     0
    rhs       c3424     0
    rhs       c3425     0
    rhs       c3426     0
    rhs       c3427     0
    rhs       c3428     0
    rhs       c3429     0
    rhs       c3430     0
    rhs       c3431     0
    rhs       c3432     0
    rhs       c3433     0
    rhs       c3434     0
    rhs       c3435     0
    rhs       c3436     0
    rhs       c3437     0
    rhs       c3438     0
    rhs       c3439     0
    rhs       c3440     0
    rhs       c3441     0
    rhs       c3442     0
    rhs       c3443     0
    rhs       c3444     0
    rhs       c3445     0
    rhs       c3446     0
    rhs       c3447     0
    rhs       c3448     0
    rhs       c3449     0
    rhs       c3450     0
    rhs       c3451     0
    rhs       c3452     0
    rhs       c3453     0
    rhs       c3454     0
    rhs       c3455     0
    rhs       c3456     0
    rhs       c3457     0
    rhs       c3458     0
    rhs       c3459     0
    rhs       c3460     0
    rhs       c3461     0
    rhs       c3462     0
    rhs       c3463     0
    rhs       c3464     0
    rhs       c3465     0
    rhs       c3466     0
    rhs       c3467     0
    rhs       c3468     0
    rhs       c3469     0
    rhs       c3470     0
    rhs       c3471     0
    rhs       c3472     0
    rhs       c3473     0
    rhs       c3474     0
    rhs       c3475     0
    rhs       c3476     0
    rhs       c3477     0
    rhs       c3478     0
    rhs       c3479     0
    rhs       c3480     0
    rhs       c3481     0
    rhs       c3482     0
    rhs       c3483     0
    rhs       c3484     0
    rhs       c3485     0
    rhs       c3486     0
    rhs       c3487     0
    rhs       c3488     0
    rhs       c3489     0
    rhs       c3490     0
    rhs       c3491     0
    rhs       c3492     0
    rhs       c3493     0
    rhs       c3494     0
    rhs       c3495     0
    rhs       c3496     0
    rhs       c3497     0
    rhs       c3498     0
    rhs       c3499     0
    rhs       c3500     0
    rhs       c3501     0
    rhs       c3502     0
    rhs       c3503     0
    rhs       c3504     0
    rhs       c3505     0
    rhs       c3506     0
    rhs       c3507     0
    rhs       c3508     0
    rhs       c3509     0
    rhs       c3510     0
    rhs       c3511     0
    rhs       c3512     0
    rhs       c3513     0
    rhs       c3514     0
    rhs       c3515     0
    rhs       c3516     0
    rhs       c3517     0
    rhs       c3518     0
    rhs       c3519     0
    rhs       c3520     0
    rhs       c3521     0
    rhs       c3522     0
    rhs       c3523     0
    rhs       c3524     0
    rhs       c3525     0
    rhs       c3526     0
    rhs       c3527     0
    rhs       c3528     0
    rhs       c3529     0
    rhs       c3530     0
    rhs       c3531     0
    rhs       c3532     0
    rhs       c3533     0
    rhs       c3534     0
    rhs       c3535     0
    rhs       c3536     0
    rhs       c3537     0
    rhs       c3538     0
    rhs       c3539     0
    rhs       c3540     0
    rhs       c3541     0
    rhs       c3542     0
    rhs       c3543     0
    rhs       c3544     0
    rhs       c3545     0
    rhs       c3546     0
    rhs       c3547     0
    rhs       c3548     0
    rhs       c3549     0
    rhs       c3550     0
    rhs       c3551     0
    rhs       c3552     0
    rhs       c3553     0
    rhs       c3554     0
    rhs       c3555     0
    rhs       c3556     0
    rhs       c3557     0
    rhs       c3558     0
    rhs       c3559     0
    rhs       c3560     0
    rhs       c3561     0
    rhs       c3562     0
    rhs       c3563     0
    rhs       c3564     0
    rhs       c3565     0
    rhs       c3566     0
    rhs       c3567     0
    rhs       c3568     0
    rhs       c3569     0
    rhs       c3570     0
    rhs       c3571     0
    rhs       c3572     0
    rhs       c3573     0
    rhs       c3574     0
    rhs       c3575     0
    rhs       c3576     0
    rhs       c3577     0
    rhs       c3578     0
    rhs       c3579     0
    rhs       c3580     0
    rhs       c3581     0
    rhs       c3582     0
    rhs       c3583     0
    rhs       c3584     0
    rhs       c3585     0
    rhs       c3586     0
    rhs       c3587     0
    rhs       c3588     0
    rhs       c3589     0
    rhs       c3590     0
    rhs       c3591     0
    rhs       c3592     0
    rhs       c3593     0
    rhs       c3594     0
    rhs       c3595     0
    rhs       c3596     0
    rhs       c3597     0
    rhs       c3598     0
    rhs       c3599     0
    rhs       c3600     0
    rhs       c3601     0
    rhs       c3602     0
    rhs       c3603     0
    rhs       c3604     0
    rhs       c3605     0
    rhs       c3606     0
    rhs       c3607     0
    rhs       c3608     0
    rhs       c3609     0
    rhs       c3610     0
    rhs       c3611     0
    rhs       c3612     0
    rhs       c3613     0
    rhs       c3614     0
    rhs       c3615     0
    rhs       c3616     0
    rhs       c3617     0
    rhs       c3618     0
    rhs       c3619     0
    rhs       c3620     0
    rhs       c3621     0
    rhs       c3622     0
    rhs       c3623     0
    rhs       c3624     0
    rhs       c3625     0
    rhs       c3626     0
    rhs       c3627     0
    rhs       c3628     0
    rhs       c3629     0
    rhs       c3630     0
    rhs       c3631     0
    rhs       c3632     0
    rhs       c3633     0
    rhs       c3634     0
    rhs       c3635     0
    rhs       c3636     0
    rhs       c3637     0
    rhs       c3638     0
    rhs       c3639     0
    rhs       c3640     0
    rhs       c3641     0
    rhs       c3642     0
    rhs       c3643     0
    rhs       c3644     0
    rhs       c3645     0
    rhs       c3646     0
    rhs       c3647     0
    rhs       c3648     0
    rhs       c3649     0
    rhs       c3650     0
    rhs       c3651     0
    rhs       c3652     0
    rhs       c3653     0
    rhs       c3654     0
    rhs       c3655     0
    rhs       c3656     0
    rhs       c3657     0
    rhs       c3658     0
    rhs       c3659     0
    rhs       c3660     0
    rhs       c3661     0
    rhs       c3662     0
    rhs       c3663     0
    rhs       c3664     0
    rhs       c3665     0
    rhs       c3666     0
    rhs       c3667     0
    rhs       c3668     0
    rhs       c3669     0
    rhs       c3670     0
    rhs       c3671     0
    rhs       c3672     0
    rhs       c3673     0
    rhs       c3674     0
    rhs       c3675     0
    rhs       c3676     0
    rhs       c3677     0
    rhs       c3678     0
    rhs       c3679     0
    rhs       c3680     0
    rhs       c3681     0
    rhs       c3682     0
    rhs       c3683     0
    rhs       c3684     0
    rhs       c3685     0
    rhs       c3686     0
    rhs       c3687     0
    rhs       c3688     0
    rhs       c3689     0
    rhs       c3690     0
    rhs       c3691     0
    rhs       c3692     0
    rhs       c3693     0
    rhs       c3694     0
    rhs       c3695     0
    rhs       c3696     0
    rhs       c3697     0
    rhs       c3698     0
    rhs       c3699     0
    rhs       c3700     0
    rhs       c3701     0
    rhs       c3702     0
    rhs       c3703     0
    rhs       c3704     0
    rhs       c3705     0
    rhs       c3706     0
    rhs       c3707     0
    rhs       c3708     0
    rhs       c3709     0
    rhs       c3710     0
    rhs       c3711     0
    rhs       c3712     0
    rhs       c3713     0
    rhs       c3714     0
    rhs       c3715     0
    rhs       c3716     0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      126375
 FX bounds    x[2]      0
 FX bounds    x[3]      0
 FX bounds    x[4]      0
 FX bounds    x[5]      0
 FX bounds    x[6]      0
 FX bounds    x[7]      0
 FX bounds    x[8]      0
 FX bounds    x[9]      0
 FX bounds    x[10]     0
 FX bounds    x[11]     0
 FX bounds    x[12]     0
 FX bounds    x[13]     0
 FX bounds    x[14]     0
 FX bounds    x[15]     0
 FX bounds    x[16]     0
 FX bounds    x[17]     0
 FX bounds    x[18]     0
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 BV bounds    x[75]
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 BV bounds    x[80]
 BV bounds    x[81]
 BV bounds    x[82]
 BV bounds    x[83]
 BV bounds    x[84]
 BV bounds    x[85]
 BV bounds    x[86]
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 BV bounds    x[90]
 BV bounds    x[91]
 FX bounds    x[92]     0
 FX bounds    x[93]     0
 FX bounds    x[94]     0
 FX bounds    x[95]     0
 FX bounds    x[96]     0
 FX bounds    x[97]     0
 FX bounds    x[98]     0
 FX bounds    x[99]     0
 FX bounds    x[100]    0
 FX bounds    x[101]    0
 FX bounds    x[102]    0
 FX bounds    x[103]    0
 FX bounds    x[104]    0
 FX bounds    x[105]    0
 FX bounds    x[106]    0
 FX bounds    x[107]    0
 FX bounds    x[108]    0
 BV bounds    x[109]
 BV bounds    x[110]
 BV bounds    x[111]
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 BV bounds    x[119]
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 BV bounds    x[127]
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 BV bounds    x[135]
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 BV bounds    x[168]
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 BV bounds    x[178]
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 FX bounds    x[182]    0
 FX bounds    x[183]    0
 FX bounds    x[184]    0
 FX bounds    x[185]    0
 FX bounds    x[186]    0
 FX bounds    x[187]    0
 FX bounds    x[188]    0
 FX bounds    x[189]    0
 FX bounds    x[190]    0
 FX bounds    x[191]    0
 FX bounds    x[192]    0
 FX bounds    x[193]    0
 FX bounds    x[194]    0
 FX bounds    x[195]    0
 FX bounds    x[196]    0
 FX bounds    x[197]    0
 FX bounds    x[198]    0
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 BV bounds    x[248]
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 BV bounds    x[260]
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 FX bounds    x[272]    0
 FX bounds    x[273]    0
 FX bounds    x[274]    0
 FX bounds    x[275]    0
 FX bounds    x[276]    0
 FX bounds    x[277]    0
 FX bounds    x[278]    0
 FX bounds    x[279]    0
 FX bounds    x[280]    0
 FX bounds    x[281]    0
 FX bounds    x[282]    0
 FX bounds    x[283]    0
 FX bounds    x[284]    0
 FX bounds    x[285]    0
 FX bounds    x[286]    0
 FX bounds    x[287]    0
 FX bounds    x[288]    0
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 BV bounds    x[332]
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 BV bounds    x[341]
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 FX bounds    x[362]    0
 FX bounds    x[363]    0
 FX bounds    x[364]    0
 FX bounds    x[365]    0
 FX bounds    x[366]    0
 FX bounds    x[367]    0
 FX bounds    x[368]    0
 FX bounds    x[369]    0
 FX bounds    x[370]    0
 FX bounds    x[371]    0
 FX bounds    x[372]    0
 FX bounds    x[373]    0
 FX bounds    x[374]    0
 FX bounds    x[375]    0
 FX bounds    x[376]    0
 FX bounds    x[377]    0
 FX bounds    x[378]    0
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 BV bounds    x[411]
 BV bounds    x[412]
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 BV bounds    x[422]
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 FX bounds    x[452]    0
 FX bounds    x[453]    0
 FX bounds    x[454]    0
 FX bounds    x[455]    0
 FX bounds    x[456]    0
 FX bounds    x[457]    0
 FX bounds    x[458]    0
 FX bounds    x[459]    0
 FX bounds    x[460]    0
 FX bounds    x[461]    0
 FX bounds    x[462]    0
 FX bounds    x[463]    0
 FX bounds    x[464]    0
 FX bounds    x[465]    0
 FX bounds    x[466]    0
 FX bounds    x[467]    0
 FX bounds    x[468]    0
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 BV bounds    x[499]
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 BV bounds    x[510]
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 FX bounds    x[542]    0
 FX bounds    x[543]    0
 FX bounds    x[544]    0
 FX bounds    x[545]    0
 FX bounds    x[546]    0
 FX bounds    x[547]    0
 FX bounds    x[548]    0
 FX bounds    x[549]    0
 FX bounds    x[550]    0
 FX bounds    x[551]    0
 FX bounds    x[552]    0
 FX bounds    x[553]    0
 FX bounds    x[554]    0
 FX bounds    x[555]    0
 FX bounds    x[556]    0
 FX bounds    x[557]    0
 FX bounds    x[558]    0
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 BV bounds    x[588]
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 FX bounds    x[632]    0
 FX bounds    x[633]    0
 FX bounds    x[634]    0
 FX bounds    x[635]    0
 FX bounds    x[636]    0
 FX bounds    x[637]    0
 FX bounds    x[638]    0
 FX bounds    x[639]    0
 FX bounds    x[640]    0
 FX bounds    x[641]    0
 FX bounds    x[642]    0
 FX bounds    x[643]    0
 FX bounds    x[644]    0
 FX bounds    x[645]    0
 FX bounds    x[646]    0
 FX bounds    x[647]    0
 FX bounds    x[648]    0
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 BV bounds    x[668]
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 BV bounds    x[712]
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 FX bounds    x[722]    0
 FX bounds    x[723]    0
 FX bounds    x[724]    0
 FX bounds    x[725]    0
 FX bounds    x[726]    0
 FX bounds    x[727]    0
 FX bounds    x[728]    0
 FX bounds    x[729]    0
 FX bounds    x[730]    0
 FX bounds    x[731]    0
 FX bounds    x[732]    0
 FX bounds    x[733]    0
 FX bounds    x[734]    0
 FX bounds    x[735]    0
 FX bounds    x[736]    0
 FX bounds    x[737]    0
 FX bounds    x[738]    0
 BV bounds    x[739]
 BV bounds    x[740]
 BV bounds    x[741]
 BV bounds    x[742]
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 FX bounds    x[812]    0
 FX bounds    x[813]    0
 FX bounds    x[814]    0
 FX bounds    x[815]    0
 FX bounds    x[816]    0
 FX bounds    x[817]    0
 FX bounds    x[818]    0
 FX bounds    x[819]    0
 FX bounds    x[820]    0
 FX bounds    x[821]    0
 FX bounds    x[822]    0
 FX bounds    x[823]    0
 FX bounds    x[824]    0
 FX bounds    x[825]    0
 FX bounds    x[826]    0
 FX bounds    x[827]    0
 FX bounds    x[828]    0
 BV bounds    x[829]
 BV bounds    x[830]
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 FX bounds    x[902]    0
 FX bounds    x[903]    0
 FX bounds    x[904]    0
 FX bounds    x[905]    0
 FX bounds    x[906]    0
 FX bounds    x[907]    0
 FX bounds    x[908]    0
 FX bounds    x[909]    0
 FX bounds    x[910]    0
 FX bounds    x[911]    0
 FX bounds    x[912]    0
 FX bounds    x[913]    0
 FX bounds    x[914]    0
 FX bounds    x[915]    0
 FX bounds    x[916]    0
 FX bounds    x[917]    0
 FX bounds    x[918]    0
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 BV bounds    x[989]
 BV bounds    x[990]
 BV bounds    x[991]
 FX bounds    x[992]    0
 FX bounds    x[993]    0
 FX bounds    x[994]    0
 FX bounds    x[995]    0
 FX bounds    x[996]    0
 FX bounds    x[997]    0
 FX bounds    x[998]    0
 FX bounds    x[999]    0
 FX bounds    x[1000]   0
 FX bounds    x[1001]   0
 FX bounds    x[1002]   0
 FX bounds    x[1003]   0
 FX bounds    x[1004]   0
 FX bounds    x[1005]   0
 FX bounds    x[1006]   0
 FX bounds    x[1007]   0
 FX bounds    x[1008]   0
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 BV bounds    x[1017]
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 BV bounds    x[1071]
 BV bounds    x[1072]
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 FX bounds    x[1082]   0
 FX bounds    x[1083]   0
 FX bounds    x[1084]   0
 FX bounds    x[1085]   0
 FX bounds    x[1086]   0
 FX bounds    x[1087]   0
 FX bounds    x[1088]   0
 FX bounds    x[1089]   0
 FX bounds    x[1090]   0
 FX bounds    x[1091]   0
 FX bounds    x[1092]   0
 FX bounds    x[1093]   0
 FX bounds    x[1094]   0
 FX bounds    x[1095]   0
 FX bounds    x[1096]   0
 FX bounds    x[1097]   0
 FX bounds    x[1098]   0
 BV bounds    x[1099]
 BV bounds    x[1100]
 BV bounds    x[1101]
 BV bounds    x[1102]
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 BV bounds    x[1107]
 BV bounds    x[1108]
 BV bounds    x[1109]
 BV bounds    x[1110]
 BV bounds    x[1111]
 BV bounds    x[1112]
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 BV bounds    x[1150]
 BV bounds    x[1151]
 BV bounds    x[1152]
 BV bounds    x[1153]
 BV bounds    x[1154]
 BV bounds    x[1155]
 BV bounds    x[1156]
 BV bounds    x[1157]
 BV bounds    x[1158]
 BV bounds    x[1159]
 BV bounds    x[1160]
 BV bounds    x[1161]
 BV bounds    x[1162]
 BV bounds    x[1163]
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 BV bounds    x[1167]
 BV bounds    x[1168]
 BV bounds    x[1169]
 BV bounds    x[1170]
 BV bounds    x[1171]
 FX bounds    x[1172]   0
 FX bounds    x[1173]   0
 FX bounds    x[1174]   0
 FX bounds    x[1175]   0
 FX bounds    x[1176]   0
 FX bounds    x[1177]   0
 FX bounds    x[1178]   0
 FX bounds    x[1179]   0
 FX bounds    x[1180]   0
 FX bounds    x[1181]   0
 FX bounds    x[1182]   0
 FX bounds    x[1183]   0
 FX bounds    x[1184]   0
 FX bounds    x[1185]   0
 FX bounds    x[1186]   0
 FX bounds    x[1187]   0
 FX bounds    x[1188]   0
 BV bounds    x[1189]
 BV bounds    x[1190]
 BV bounds    x[1191]
 BV bounds    x[1192]
 BV bounds    x[1193]
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 BV bounds    x[1197]
 BV bounds    x[1198]
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 BV bounds    x[1203]
 BV bounds    x[1204]
 BV bounds    x[1205]
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 BV bounds    x[1209]
 BV bounds    x[1210]
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 BV bounds    x[1217]
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 BV bounds    x[1229]
 BV bounds    x[1230]
 BV bounds    x[1231]
 BV bounds    x[1232]
 BV bounds    x[1233]
 BV bounds    x[1234]
 BV bounds    x[1235]
 BV bounds    x[1236]
 BV bounds    x[1237]
 BV bounds    x[1238]
 BV bounds    x[1239]
 BV bounds    x[1240]
 BV bounds    x[1241]
 BV bounds    x[1242]
 BV bounds    x[1243]
 BV bounds    x[1244]
 BV bounds    x[1245]
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 BV bounds    x[1249]
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 BV bounds    x[1260]
 BV bounds    x[1261]
 FX bounds    x[1262]   0
 FX bounds    x[1263]   0
 FX bounds    x[1264]   0
 FX bounds    x[1265]   0
 FX bounds    x[1266]   0
 FX bounds    x[1267]   0
 FX bounds    x[1268]   0
 FX bounds    x[1269]   0
 FX bounds    x[1270]   0
 FX bounds    x[1271]   0
 FX bounds    x[1272]   0
 FX bounds    x[1273]   0
 FX bounds    x[1274]   0
 FX bounds    x[1275]   0
 FX bounds    x[1276]   0
 FX bounds    x[1277]   0
 FX bounds    x[1278]   0
 BV bounds    x[1279]
 BV bounds    x[1280]
 BV bounds    x[1281]
 BV bounds    x[1282]
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 BV bounds    x[1293]
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 BV bounds    x[1311]
 BV bounds    x[1312]
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 BV bounds    x[1317]
 BV bounds    x[1318]
 BV bounds    x[1319]
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 BV bounds    x[1323]
 BV bounds    x[1324]
 BV bounds    x[1325]
 BV bounds    x[1326]
 BV bounds    x[1327]
 BV bounds    x[1328]
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 BV bounds    x[1336]
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 BV bounds    x[1341]
 BV bounds    x[1342]
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 FX bounds    x[1352]   0
 FX bounds    x[1353]   0
 FX bounds    x[1354]   0
 FX bounds    x[1355]   0
 FX bounds    x[1356]   0
 FX bounds    x[1357]   0
 FX bounds    x[1358]   0
 FX bounds    x[1359]   0
 FX bounds    x[1360]   0
 FX bounds    x[1361]   0
 FX bounds    x[1362]   0
 FX bounds    x[1363]   0
 FX bounds    x[1364]   0
 FX bounds    x[1365]   0
 FX bounds    x[1366]   0
 FX bounds    x[1367]   0
 FX bounds    x[1368]   0
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 BV bounds    x[1401]
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 BV bounds    x[1409]
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 FX bounds    x[1442]   0
 FX bounds    x[1443]   0
 FX bounds    x[1444]   0
 FX bounds    x[1445]   0
 FX bounds    x[1446]   0
 FX bounds    x[1447]   0
 FX bounds    x[1448]   0
 FX bounds    x[1449]   0
 FX bounds    x[1450]   0
 FX bounds    x[1451]   0
 FX bounds    x[1452]   0
 FX bounds    x[1453]   0
 FX bounds    x[1454]   0
 FX bounds    x[1455]   0
 FX bounds    x[1456]   0
 FX bounds    x[1457]   0
 FX bounds    x[1458]   0
 BV bounds    x[1459]
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 BV bounds    x[1478]
 BV bounds    x[1479]
 BV bounds    x[1480]
 BV bounds    x[1481]
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 BV bounds    x[1485]
 BV bounds    x[1486]
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 BV bounds    x[1491]
 BV bounds    x[1492]
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 BV bounds    x[1515]
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 BV bounds    x[1521]
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 BV bounds    x[1527]
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 FX bounds    x[1532]   0
 FX bounds    x[1533]   0
 FX bounds    x[1534]   0
 FX bounds    x[1535]   0
 FX bounds    x[1536]   0
 FX bounds    x[1537]   0
 FX bounds    x[1538]   0
 FX bounds    x[1539]   0
 FX bounds    x[1540]   0
 FX bounds    x[1541]   0
 FX bounds    x[1542]   0
 FX bounds    x[1543]   0
 FX bounds    x[1544]   0
 FX bounds    x[1545]   0
 FX bounds    x[1546]   0
 FX bounds    x[1547]   0
 FX bounds    x[1548]   0
 BV bounds    x[1549]
 BV bounds    x[1550]
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 BV bounds    x[1566]
 BV bounds    x[1567]
 BV bounds    x[1568]
 BV bounds    x[1569]
 BV bounds    x[1570]
 BV bounds    x[1571]
 BV bounds    x[1572]
 BV bounds    x[1573]
 BV bounds    x[1574]
 BV bounds    x[1575]
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 BV bounds    x[1580]
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 BV bounds    x[1586]
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 BV bounds    x[1592]
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 BV bounds    x[1599]
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 BV bounds    x[1605]
 BV bounds    x[1606]
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 BV bounds    x[1611]
 BV bounds    x[1612]
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 BV bounds    x[1616]
 BV bounds    x[1617]
 BV bounds    x[1618]
 BV bounds    x[1619]
 BV bounds    x[1620]
 BV bounds    x[1621]
 FX bounds    x[1622]   0
 FX bounds    x[1623]   0
 FX bounds    x[1624]   0
 FX bounds    x[1625]   0
 FX bounds    x[1626]   0
 FX bounds    x[1627]   0
 FX bounds    x[1628]   0
 FX bounds    x[1629]   0
 FX bounds    x[1630]   0
 FX bounds    x[1631]   0
 FX bounds    x[1632]   0
 FX bounds    x[1633]   0
 FX bounds    x[1634]   0
 FX bounds    x[1635]   0
 FX bounds    x[1636]   0
 FX bounds    x[1637]   0
 FX bounds    x[1638]   0
 BV bounds    x[1639]
 BV bounds    x[1640]
 BV bounds    x[1641]
 BV bounds    x[1642]
 BV bounds    x[1643]
 BV bounds    x[1644]
 BV bounds    x[1645]
 BV bounds    x[1646]
 BV bounds    x[1647]
 BV bounds    x[1648]
 BV bounds    x[1649]
 BV bounds    x[1650]
 BV bounds    x[1651]
 BV bounds    x[1652]
 BV bounds    x[1653]
 BV bounds    x[1654]
 BV bounds    x[1655]
 BV bounds    x[1656]
 BV bounds    x[1657]
 BV bounds    x[1658]
 BV bounds    x[1659]
 BV bounds    x[1660]
 BV bounds    x[1661]
 BV bounds    x[1662]
 BV bounds    x[1663]
 BV bounds    x[1664]
 BV bounds    x[1665]
 BV bounds    x[1666]
 BV bounds    x[1667]
 BV bounds    x[1668]
 BV bounds    x[1669]
 BV bounds    x[1670]
 BV bounds    x[1671]
 BV bounds    x[1672]
 BV bounds    x[1673]
 BV bounds    x[1674]
 BV bounds    x[1675]
 BV bounds    x[1676]
 BV bounds    x[1677]
 BV bounds    x[1678]
 BV bounds    x[1679]
 BV bounds    x[1680]
 BV bounds    x[1681]
 BV bounds    x[1682]
 BV bounds    x[1683]
 BV bounds    x[1684]
 BV bounds    x[1685]
 BV bounds    x[1686]
 BV bounds    x[1687]
 BV bounds    x[1688]
 BV bounds    x[1689]
 BV bounds    x[1690]
 BV bounds    x[1691]
 BV bounds    x[1692]
 BV bounds    x[1693]
 BV bounds    x[1694]
 BV bounds    x[1695]
 BV bounds    x[1696]
 BV bounds    x[1697]
 BV bounds    x[1698]
 BV bounds    x[1699]
 BV bounds    x[1700]
 BV bounds    x[1701]
 BV bounds    x[1702]
 BV bounds    x[1703]
 BV bounds    x[1704]
 BV bounds    x[1705]
 BV bounds    x[1706]
 BV bounds    x[1707]
 BV bounds    x[1708]
 BV bounds    x[1709]
 BV bounds    x[1710]
 BV bounds    x[1711]
 FX bounds    x[1712]   0
 FX bounds    x[1713]   0
 FX bounds    x[1714]   0
 FX bounds    x[1715]   0
 FX bounds    x[1716]   0
 FX bounds    x[1717]   0
 FX bounds    x[1718]   0
 FX bounds    x[1719]   0
 FX bounds    x[1720]   0
 FX bounds    x[1721]   0
 FX bounds    x[1722]   0
 FX bounds    x[1723]   0
 FX bounds    x[1724]   0
 FX bounds    x[1725]   0
 FX bounds    x[1726]   0
 FX bounds    x[1727]   0
 FX bounds    x[1728]   0
 BV bounds    x[1729]
 BV bounds    x[1730]
 BV bounds    x[1731]
 BV bounds    x[1732]
 BV bounds    x[1733]
 BV bounds    x[1734]
 BV bounds    x[1735]
 BV bounds    x[1736]
 BV bounds    x[1737]
 BV bounds    x[1738]
 BV bounds    x[1739]
 BV bounds    x[1740]
 BV bounds    x[1741]
 BV bounds    x[1742]
 BV bounds    x[1743]
 BV bounds    x[1744]
 BV bounds    x[1745]
 BV bounds    x[1746]
 BV bounds    x[1747]
 BV bounds    x[1748]
 BV bounds    x[1749]
 BV bounds    x[1750]
 BV bounds    x[1751]
 BV bounds    x[1752]
 BV bounds    x[1753]
 BV bounds    x[1754]
 BV bounds    x[1755]
 BV bounds    x[1756]
 BV bounds    x[1757]
 BV bounds    x[1758]
 BV bounds    x[1759]
 BV bounds    x[1760]
 BV bounds    x[1761]
 BV bounds    x[1762]
 BV bounds    x[1763]
 BV bounds    x[1764]
 BV bounds    x[1765]
 BV bounds    x[1766]
 BV bounds    x[1767]
 BV bounds    x[1768]
 BV bounds    x[1769]
 BV bounds    x[1770]
 BV bounds    x[1771]
 BV bounds    x[1772]
 BV bounds    x[1773]
 BV bounds    x[1774]
 BV bounds    x[1775]
 BV bounds    x[1776]
 BV bounds    x[1777]
 BV bounds    x[1778]
 BV bounds    x[1779]
 BV bounds    x[1780]
 BV bounds    x[1781]
 BV bounds    x[1782]
 BV bounds    x[1783]
 BV bounds    x[1784]
 BV bounds    x[1785]
 BV bounds    x[1786]
 BV bounds    x[1787]
 BV bounds    x[1788]
 BV bounds    x[1789]
 BV bounds    x[1790]
 BV bounds    x[1791]
 BV bounds    x[1792]
 BV bounds    x[1793]
 BV bounds    x[1794]
 BV bounds    x[1795]
 BV bounds    x[1796]
 BV bounds    x[1797]
 BV bounds    x[1798]
 BV bounds    x[1799]
 BV bounds    x[1800]
 BV bounds    x[1801]
 FX bounds    x[1802]   0
 FX bounds    x[1803]   0
 FX bounds    x[1804]   0
 FX bounds    x[1805]   0
 FX bounds    x[1806]   0
 FX bounds    x[1807]   0
 FX bounds    x[1808]   0
 FX bounds    x[1809]   0
 FX bounds    x[1810]   0
 FX bounds    x[1811]   0
 FX bounds    x[1812]   0
 FX bounds    x[1813]   0
 FX bounds    x[1814]   0
 FX bounds    x[1815]   0
 FX bounds    x[1816]   0
 FX bounds    x[1817]   0
 FX bounds    x[1818]   0
 BV bounds    x[1819]
 BV bounds    x[1820]
 BV bounds    x[1821]
 BV bounds    x[1822]
 BV bounds    x[1823]
 BV bounds    x[1824]
 BV bounds    x[1825]
 BV bounds    x[1826]
 BV bounds    x[1827]
 BV bounds    x[1828]
 BV bounds    x[1829]
 BV bounds    x[1830]
 BV bounds    x[1831]
 BV bounds    x[1832]
 BV bounds    x[1833]
 BV bounds    x[1834]
 BV bounds    x[1835]
 BV bounds    x[1836]
 BV bounds    x[1837]
 BV bounds    x[1838]
 BV bounds    x[1839]
 BV bounds    x[1840]
 BV bounds    x[1841]
 BV bounds    x[1842]
 BV bounds    x[1843]
 BV bounds    x[1844]
 BV bounds    x[1845]
 BV bounds    x[1846]
 BV bounds    x[1847]
 BV bounds    x[1848]
 BV bounds    x[1849]
 BV bounds    x[1850]
 BV bounds    x[1851]
 BV bounds    x[1852]
 BV bounds    x[1853]
 BV bounds    x[1854]
 BV bounds    x[1855]
 BV bounds    x[1856]
 BV bounds    x[1857]
 BV bounds    x[1858]
 BV bounds    x[1859]
 BV bounds    x[1860]
 BV bounds    x[1861]
 BV bounds    x[1862]
 BV bounds    x[1863]
 BV bounds    x[1864]
 BV bounds    x[1865]
 BV bounds    x[1866]
 BV bounds    x[1867]
 BV bounds    x[1868]
 BV bounds    x[1869]
 BV bounds    x[1870]
 BV bounds    x[1871]
 BV bounds    x[1872]
 BV bounds    x[1873]
 BV bounds    x[1874]
 BV bounds    x[1875]
 BV bounds    x[1876]
 BV bounds    x[1877]
 BV bounds    x[1878]
 BV bounds    x[1879]
 BV bounds    x[1880]
 BV bounds    x[1881]
 BV bounds    x[1882]
 BV bounds    x[1883]
 BV bounds    x[1884]
 BV bounds    x[1885]
 BV bounds    x[1886]
 BV bounds    x[1887]
 BV bounds    x[1888]
 BV bounds    x[1889]
 BV bounds    x[1890]
 BV bounds    x[1891]
 FX bounds    x[1892]   0
 FX bounds    x[1893]   0
 FX bounds    x[1894]   0
 FX bounds    x[1895]   0
 FX bounds    x[1896]   0
 FX bounds    x[1897]   0
 FX bounds    x[1898]   0
 FX bounds    x[1899]   0
 FX bounds    x[1900]   0
 FX bounds    x[1901]   0
 FX bounds    x[1902]   0
 FX bounds    x[1903]   0
 FX bounds    x[1904]   0
 FX bounds    x[1905]   0
 FX bounds    x[1906]   0
 FX bounds    x[1907]   0
 FX bounds    x[1908]   0
 BV bounds    x[1909]
 BV bounds    x[1910]
 BV bounds    x[1911]
 BV bounds    x[1912]
 BV bounds    x[1913]
 BV bounds    x[1914]
 BV bounds    x[1915]
 BV bounds    x[1916]
 BV bounds    x[1917]
 BV bounds    x[1918]
 BV bounds    x[1919]
 BV bounds    x[1920]
 BV bounds    x[1921]
 BV bounds    x[1922]
 BV bounds    x[1923]
 BV bounds    x[1924]
 BV bounds    x[1925]
 BV bounds    x[1926]
 BV bounds    x[1927]
 BV bounds    x[1928]
 BV bounds    x[1929]
 BV bounds    x[1930]
 BV bounds    x[1931]
 BV bounds    x[1932]
 BV bounds    x[1933]
 BV bounds    x[1934]
 BV bounds    x[1935]
 BV bounds    x[1936]
 BV bounds    x[1937]
 BV bounds    x[1938]
 BV bounds    x[1939]
 BV bounds    x[1940]
 BV bounds    x[1941]
 BV bounds    x[1942]
 BV bounds    x[1943]
 BV bounds    x[1944]
 BV bounds    x[1945]
 BV bounds    x[1946]
 BV bounds    x[1947]
 BV bounds    x[1948]
 BV bounds    x[1949]
 BV bounds    x[1950]
 BV bounds    x[1951]
 BV bounds    x[1952]
 BV bounds    x[1953]
 BV bounds    x[1954]
 BV bounds    x[1955]
 BV bounds    x[1956]
 BV bounds    x[1957]
 BV bounds    x[1958]
 BV bounds    x[1959]
 BV bounds    x[1960]
 BV bounds    x[1961]
 BV bounds    x[1962]
 BV bounds    x[1963]
 BV bounds    x[1964]
 BV bounds    x[1965]
 BV bounds    x[1966]
 BV bounds    x[1967]
 BV bounds    x[1968]
 BV bounds    x[1969]
 BV bounds    x[1970]
 BV bounds    x[1971]
 BV bounds    x[1972]
 BV bounds    x[1973]
 BV bounds    x[1974]
 BV bounds    x[1975]
 BV bounds    x[1976]
 BV bounds    x[1977]
 BV bounds    x[1978]
 BV bounds    x[1979]
 BV bounds    x[1980]
 BV bounds    x[1981]
 FX bounds    x[1982]   0
 FX bounds    x[1983]   0
 FX bounds    x[1984]   0
 FX bounds    x[1985]   0
 FX bounds    x[1986]   0
 FX bounds    x[1987]   0
 FX bounds    x[1988]   0
 FX bounds    x[1989]   0
 FX bounds    x[1990]   0
 FX bounds    x[1991]   0
 FX bounds    x[1992]   0
 FX bounds    x[1993]   0
 FX bounds    x[1994]   0
 FX bounds    x[1995]   0
 FX bounds    x[1996]   0
 FX bounds    x[1997]   0
 FX bounds    x[1998]   0
 BV bounds    x[1999]
 BV bounds    x[2000]
 BV bounds    x[2001]
 BV bounds    x[2002]
 BV bounds    x[2003]
 BV bounds    x[2004]
 BV bounds    x[2005]
 BV bounds    x[2006]
 BV bounds    x[2007]
 BV bounds    x[2008]
 BV bounds    x[2009]
 BV bounds    x[2010]
 BV bounds    x[2011]
 BV bounds    x[2012]
 BV bounds    x[2013]
 BV bounds    x[2014]
 BV bounds    x[2015]
 BV bounds    x[2016]
 BV bounds    x[2017]
 BV bounds    x[2018]
 BV bounds    x[2019]
 BV bounds    x[2020]
 BV bounds    x[2021]
 BV bounds    x[2022]
 BV bounds    x[2023]
 BV bounds    x[2024]
 BV bounds    x[2025]
 BV bounds    x[2026]
 BV bounds    x[2027]
 BV bounds    x[2028]
 BV bounds    x[2029]
 BV bounds    x[2030]
 BV bounds    x[2031]
 BV bounds    x[2032]
 BV bounds    x[2033]
 BV bounds    x[2034]
 BV bounds    x[2035]
 BV bounds    x[2036]
 BV bounds    x[2037]
 BV bounds    x[2038]
 BV bounds    x[2039]
 BV bounds    x[2040]
 BV bounds    x[2041]
 BV bounds    x[2042]
 BV bounds    x[2043]
 BV bounds    x[2044]
 BV bounds    x[2045]
 BV bounds    x[2046]
 BV bounds    x[2047]
 BV bounds    x[2048]
 BV bounds    x[2049]
 BV bounds    x[2050]
 BV bounds    x[2051]
 BV bounds    x[2052]
 BV bounds    x[2053]
 BV bounds    x[2054]
 BV bounds    x[2055]
 BV bounds    x[2056]
 BV bounds    x[2057]
 BV bounds    x[2058]
 BV bounds    x[2059]
 BV bounds    x[2060]
 BV bounds    x[2061]
 BV bounds    x[2062]
 BV bounds    x[2063]
 BV bounds    x[2064]
 BV bounds    x[2065]
 BV bounds    x[2066]
 BV bounds    x[2067]
 BV bounds    x[2068]
 BV bounds    x[2069]
 BV bounds    x[2070]
 BV bounds    x[2071]
 FX bounds    x[2072]   0
 FX bounds    x[2073]   0
 FX bounds    x[2074]   0
 FX bounds    x[2075]   0
 FX bounds    x[2076]   0
 FX bounds    x[2077]   0
 FX bounds    x[2078]   0
 FX bounds    x[2079]   0
 FX bounds    x[2080]   0
 FX bounds    x[2081]   0
 FX bounds    x[2082]   0
 FX bounds    x[2083]   0
 FX bounds    x[2084]   0
 FX bounds    x[2085]   0
 FX bounds    x[2086]   0
 FX bounds    x[2087]   0
 FX bounds    x[2088]   0
 BV bounds    x[2089]
 BV bounds    x[2090]
 BV bounds    x[2091]
 BV bounds    x[2092]
 BV bounds    x[2093]
 BV bounds    x[2094]
 BV bounds    x[2095]
 BV bounds    x[2096]
 BV bounds    x[2097]
 BV bounds    x[2098]
 BV bounds    x[2099]
 BV bounds    x[2100]
 BV bounds    x[2101]
 BV bounds    x[2102]
 BV bounds    x[2103]
 BV bounds    x[2104]
 BV bounds    x[2105]
 BV bounds    x[2106]
 BV bounds    x[2107]
 BV bounds    x[2108]
 BV bounds    x[2109]
 BV bounds    x[2110]
 BV bounds    x[2111]
 BV bounds    x[2112]
 BV bounds    x[2113]
 BV bounds    x[2114]
 BV bounds    x[2115]
 BV bounds    x[2116]
 BV bounds    x[2117]
 BV bounds    x[2118]
 BV bounds    x[2119]
 BV bounds    x[2120]
 BV bounds    x[2121]
 BV bounds    x[2122]
 BV bounds    x[2123]
 BV bounds    x[2124]
 BV bounds    x[2125]
 BV bounds    x[2126]
 BV bounds    x[2127]
 BV bounds    x[2128]
 BV bounds    x[2129]
 BV bounds    x[2130]
 BV bounds    x[2131]
 BV bounds    x[2132]
 BV bounds    x[2133]
 BV bounds    x[2134]
 BV bounds    x[2135]
 BV bounds    x[2136]
 BV bounds    x[2137]
 BV bounds    x[2138]
 BV bounds    x[2139]
 BV bounds    x[2140]
 BV bounds    x[2141]
 BV bounds    x[2142]
 BV bounds    x[2143]
 BV bounds    x[2144]
 BV bounds    x[2145]
 BV bounds    x[2146]
 BV bounds    x[2147]
 BV bounds    x[2148]
 BV bounds    x[2149]
 BV bounds    x[2150]
 BV bounds    x[2151]
 BV bounds    x[2152]
 BV bounds    x[2153]
 BV bounds    x[2154]
 BV bounds    x[2155]
 BV bounds    x[2156]
 BV bounds    x[2157]
 BV bounds    x[2158]
 BV bounds    x[2159]
 BV bounds    x[2160]
 BV bounds    x[2161]
 FX bounds    x[2162]   0
 FX bounds    x[2163]   0
 FX bounds    x[2164]   0
 FX bounds    x[2165]   0
 FX bounds    x[2166]   0
 FX bounds    x[2167]   0
 FX bounds    x[2168]   0
 FX bounds    x[2169]   0
 FX bounds    x[2170]   0
 FX bounds    x[2171]   0
 FX bounds    x[2172]   0
 FX bounds    x[2173]   0
 FX bounds    x[2174]   0
 FX bounds    x[2175]   0
 FX bounds    x[2176]   0
 FX bounds    x[2177]   0
 FX bounds    x[2178]   0
 BV bounds    x[2179]
 BV bounds    x[2180]
 BV bounds    x[2181]
 BV bounds    x[2182]
 BV bounds    x[2183]
 BV bounds    x[2184]
 BV bounds    x[2185]
 BV bounds    x[2186]
 BV bounds    x[2187]
 BV bounds    x[2188]
 BV bounds    x[2189]
 BV bounds    x[2190]
 BV bounds    x[2191]
 BV bounds    x[2192]
 BV bounds    x[2193]
 BV bounds    x[2194]
 BV bounds    x[2195]
 BV bounds    x[2196]
 BV bounds    x[2197]
 BV bounds    x[2198]
 BV bounds    x[2199]
 BV bounds    x[2200]
 BV bounds    x[2201]
 BV bounds    x[2202]
 BV bounds    x[2203]
 BV bounds    x[2204]
 BV bounds    x[2205]
 BV bounds    x[2206]
 BV bounds    x[2207]
 BV bounds    x[2208]
 BV bounds    x[2209]
 BV bounds    x[2210]
 BV bounds    x[2211]
 BV bounds    x[2212]
 BV bounds    x[2213]
 BV bounds    x[2214]
 BV bounds    x[2215]
 BV bounds    x[2216]
 BV bounds    x[2217]
 BV bounds    x[2218]
 BV bounds    x[2219]
 BV bounds    x[2220]
 BV bounds    x[2221]
 BV bounds    x[2222]
 BV bounds    x[2223]
 BV bounds    x[2224]
 BV bounds    x[2225]
 BV bounds    x[2226]
 BV bounds    x[2227]
 BV bounds    x[2228]
 BV bounds    x[2229]
 BV bounds    x[2230]
 BV bounds    x[2231]
 BV bounds    x[2232]
 BV bounds    x[2233]
 BV bounds    x[2234]
 BV bounds    x[2235]
 BV bounds    x[2236]
 BV bounds    x[2237]
 BV bounds    x[2238]
 BV bounds    x[2239]
 BV bounds    x[2240]
 BV bounds    x[2241]
 BV bounds    x[2242]
 BV bounds    x[2243]
 BV bounds    x[2244]
 BV bounds    x[2245]
 BV bounds    x[2246]
 BV bounds    x[2247]
 BV bounds    x[2248]
 BV bounds    x[2249]
 BV bounds    x[2250]
 BV bounds    x[2251]
 FX bounds    x[2252]   0
 FX bounds    x[2253]   0
 FX bounds    x[2254]   0
 FX bounds    x[2255]   0
 FX bounds    x[2256]   0
 FX bounds    x[2257]   0
 FX bounds    x[2258]   0
 FX bounds    x[2259]   0
 FX bounds    x[2260]   0
 FX bounds    x[2261]   0
 FX bounds    x[2262]   0
 FX bounds    x[2263]   0
 FX bounds    x[2264]   0
 FX bounds    x[2265]   0
 FX bounds    x[2266]   0
 FX bounds    x[2267]   0
 FX bounds    x[2268]   0
 BV bounds    x[2269]
 BV bounds    x[2270]
 BV bounds    x[2271]
 BV bounds    x[2272]
 BV bounds    x[2273]
 BV bounds    x[2274]
 BV bounds    x[2275]
 BV bounds    x[2276]
 BV bounds    x[2277]
 BV bounds    x[2278]
 BV bounds    x[2279]
 BV bounds    x[2280]
 BV bounds    x[2281]
 BV bounds    x[2282]
 BV bounds    x[2283]
 BV bounds    x[2284]
 BV bounds    x[2285]
 BV bounds    x[2286]
 BV bounds    x[2287]
 BV bounds    x[2288]
 BV bounds    x[2289]
 BV bounds    x[2290]
 BV bounds    x[2291]
 BV bounds    x[2292]
 BV bounds    x[2293]
 BV bounds    x[2294]
 BV bounds    x[2295]
 BV bounds    x[2296]
 BV bounds    x[2297]
 BV bounds    x[2298]
 BV bounds    x[2299]
 BV bounds    x[2300]
 BV bounds    x[2301]
 BV bounds    x[2302]
 BV bounds    x[2303]
 BV bounds    x[2304]
 BV bounds    x[2305]
 BV bounds    x[2306]
 BV bounds    x[2307]
 BV bounds    x[2308]
 BV bounds    x[2309]
 BV bounds    x[2310]
 BV bounds    x[2311]
 BV bounds    x[2312]
 BV bounds    x[2313]
 BV bounds    x[2314]
 BV bounds    x[2315]
 BV bounds    x[2316]
 BV bounds    x[2317]
 BV bounds    x[2318]
 BV bounds    x[2319]
 BV bounds    x[2320]
 BV bounds    x[2321]
 BV bounds    x[2322]
 BV bounds    x[2323]
 BV bounds    x[2324]
 BV bounds    x[2325]
 BV bounds    x[2326]
 BV bounds    x[2327]
 BV bounds    x[2328]
 BV bounds    x[2329]
 BV bounds    x[2330]
 BV bounds    x[2331]
 BV bounds    x[2332]
 BV bounds    x[2333]
 BV bounds    x[2334]
 BV bounds    x[2335]
 BV bounds    x[2336]
 BV bounds    x[2337]
 BV bounds    x[2338]
 BV bounds    x[2339]
 BV bounds    x[2340]
 BV bounds    x[2341]
 FX bounds    x[2342]   0
 FX bounds    x[2343]   0
 FX bounds    x[2344]   0
 FX bounds    x[2345]   0
 FX bounds    x[2346]   0
 FX bounds    x[2347]   0
 FX bounds    x[2348]   0
 FX bounds    x[2349]   0
 FX bounds    x[2350]   0
 FX bounds    x[2351]   0
 FX bounds    x[2352]   0
 FX bounds    x[2353]   0
 FX bounds    x[2354]   0
 FX bounds    x[2355]   0
 FX bounds    x[2356]   0
 FX bounds    x[2357]   0
 FX bounds    x[2358]   0
 BV bounds    x[2359]
 BV bounds    x[2360]
 BV bounds    x[2361]
 BV bounds    x[2362]
 BV bounds    x[2363]
 BV bounds    x[2364]
 BV bounds    x[2365]
 BV bounds    x[2366]
 BV bounds    x[2367]
 BV bounds    x[2368]
 BV bounds    x[2369]
 BV bounds    x[2370]
 BV bounds    x[2371]
 BV bounds    x[2372]
 BV bounds    x[2373]
 BV bounds    x[2374]
 BV bounds    x[2375]
 BV bounds    x[2376]
 BV bounds    x[2377]
 BV bounds    x[2378]
 BV bounds    x[2379]
 BV bounds    x[2380]
 BV bounds    x[2381]
 BV bounds    x[2382]
 BV bounds    x[2383]
 BV bounds    x[2384]
 BV bounds    x[2385]
 BV bounds    x[2386]
 BV bounds    x[2387]
 BV bounds    x[2388]
 BV bounds    x[2389]
 BV bounds    x[2390]
 BV bounds    x[2391]
 BV bounds    x[2392]
 BV bounds    x[2393]
 BV bounds    x[2394]
 BV bounds    x[2395]
 BV bounds    x[2396]
 BV bounds    x[2397]
 BV bounds    x[2398]
 BV bounds    x[2399]
 BV bounds    x[2400]
 BV bounds    x[2401]
 BV bounds    x[2402]
 BV bounds    x[2403]
 BV bounds    x[2404]
 BV bounds    x[2405]
 BV bounds    x[2406]
 BV bounds    x[2407]
 BV bounds    x[2408]
 BV bounds    x[2409]
 BV bounds    x[2410]
 BV bounds    x[2411]
 BV bounds    x[2412]
 BV bounds    x[2413]
 BV bounds    x[2414]
 BV bounds    x[2415]
 BV bounds    x[2416]
 BV bounds    x[2417]
 BV bounds    x[2418]
 BV bounds    x[2419]
 BV bounds    x[2420]
 BV bounds    x[2421]
 BV bounds    x[2422]
 BV bounds    x[2423]
 BV bounds    x[2424]
 BV bounds    x[2425]
 BV bounds    x[2426]
 BV bounds    x[2427]
 BV bounds    x[2428]
 BV bounds    x[2429]
 BV bounds    x[2430]
 BV bounds    x[2431]
 FX bounds    x[2432]   0
 FX bounds    x[2433]   0
 FX bounds    x[2434]   0
 FX bounds    x[2435]   0
 FX bounds    x[2436]   0
 FX bounds    x[2437]   0
 FX bounds    x[2438]   0
 FX bounds    x[2439]   0
 FX bounds    x[2440]   0
 FX bounds    x[2441]   0
 FX bounds    x[2442]   0
 FX bounds    x[2443]   0
 FX bounds    x[2444]   0
 FX bounds    x[2445]   0
 FX bounds    x[2446]   0
 FX bounds    x[2447]   0
 FX bounds    x[2448]   0
 BV bounds    x[2449]
 BV bounds    x[2450]
 BV bounds    x[2451]
 BV bounds    x[2452]
 BV bounds    x[2453]
 BV bounds    x[2454]
 BV bounds    x[2455]
 BV bounds    x[2456]
 BV bounds    x[2457]
 BV bounds    x[2458]
 BV bounds    x[2459]
 BV bounds    x[2460]
 BV bounds    x[2461]
 BV bounds    x[2462]
 BV bounds    x[2463]
 BV bounds    x[2464]
 BV bounds    x[2465]
 BV bounds    x[2466]
 BV bounds    x[2467]
 BV bounds    x[2468]
 BV bounds    x[2469]
 BV bounds    x[2470]
 BV bounds    x[2471]
 BV bounds    x[2472]
 BV bounds    x[2473]
 BV bounds    x[2474]
 BV bounds    x[2475]
 BV bounds    x[2476]
 BV bounds    x[2477]
 BV bounds    x[2478]
 BV bounds    x[2479]
 BV bounds    x[2480]
 BV bounds    x[2481]
 BV bounds    x[2482]
 BV bounds    x[2483]
 BV bounds    x[2484]
 BV bounds    x[2485]
 BV bounds    x[2486]
 BV bounds    x[2487]
 BV bounds    x[2488]
 BV bounds    x[2489]
 BV bounds    x[2490]
 BV bounds    x[2491]
 BV bounds    x[2492]
 BV bounds    x[2493]
 BV bounds    x[2494]
 BV bounds    x[2495]
 BV bounds    x[2496]
 BV bounds    x[2497]
 BV bounds    x[2498]
 BV bounds    x[2499]
 BV bounds    x[2500]
 BV bounds    x[2501]
 BV bounds    x[2502]
 BV bounds    x[2503]
 BV bounds    x[2504]
 BV bounds    x[2505]
 BV bounds    x[2506]
 BV bounds    x[2507]
 BV bounds    x[2508]
 BV bounds    x[2509]
 BV bounds    x[2510]
 BV bounds    x[2511]
 BV bounds    x[2512]
 BV bounds    x[2513]
 BV bounds    x[2514]
 BV bounds    x[2515]
 BV bounds    x[2516]
 BV bounds    x[2517]
 BV bounds    x[2518]
 BV bounds    x[2519]
 BV bounds    x[2520]
 BV bounds    x[2521]
 FX bounds    x[2522]   0
 FX bounds    x[2523]   0
 FX bounds    x[2524]   0
 FX bounds    x[2525]   0
 FX bounds    x[2526]   0
 FX bounds    x[2527]   0
 FX bounds    x[2528]   0
 FX bounds    x[2529]   0
 FX bounds    x[2530]   0
 FX bounds    x[2531]   0
 FX bounds    x[2532]   0
 FX bounds    x[2533]   0
 FX bounds    x[2534]   0
 FX bounds    x[2535]   0
 FX bounds    x[2536]   0
 FX bounds    x[2537]   0
 FX bounds    x[2538]   0
 BV bounds    x[2539]
 BV bounds    x[2540]
 BV bounds    x[2541]
 BV bounds    x[2542]
 BV bounds    x[2543]
 BV bounds    x[2544]
 BV bounds    x[2545]
 BV bounds    x[2546]
 BV bounds    x[2547]
 BV bounds    x[2548]
 BV bounds    x[2549]
 BV bounds    x[2550]
 BV bounds    x[2551]
 BV bounds    x[2552]
 BV bounds    x[2553]
 BV bounds    x[2554]
 BV bounds    x[2555]
 BV bounds    x[2556]
 BV bounds    x[2557]
 BV bounds    x[2558]
 BV bounds    x[2559]
 BV bounds    x[2560]
 BV bounds    x[2561]
 BV bounds    x[2562]
 BV bounds    x[2563]
 BV bounds    x[2564]
 BV bounds    x[2565]
 BV bounds    x[2566]
 BV bounds    x[2567]
 BV bounds    x[2568]
 BV bounds    x[2569]
 BV bounds    x[2570]
 BV bounds    x[2571]
 BV bounds    x[2572]
 BV bounds    x[2573]
 BV bounds    x[2574]
 BV bounds    x[2575]
 BV bounds    x[2576]
 BV bounds    x[2577]
 BV bounds    x[2578]
 BV bounds    x[2579]
 BV bounds    x[2580]
 BV bounds    x[2581]
 BV bounds    x[2582]
 BV bounds    x[2583]
 BV bounds    x[2584]
 BV bounds    x[2585]
 BV bounds    x[2586]
 BV bounds    x[2587]
 BV bounds    x[2588]
 BV bounds    x[2589]
 BV bounds    x[2590]
 BV bounds    x[2591]
 BV bounds    x[2592]
 BV bounds    x[2593]
 BV bounds    x[2594]
 BV bounds    x[2595]
 BV bounds    x[2596]
 BV bounds    x[2597]
 BV bounds    x[2598]
 BV bounds    x[2599]
 BV bounds    x[2600]
 BV bounds    x[2601]
 BV bounds    x[2602]
 BV bounds    x[2603]
 BV bounds    x[2604]
 BV bounds    x[2605]
 BV bounds    x[2606]
 BV bounds    x[2607]
 BV bounds    x[2608]
 BV bounds    x[2609]
 BV bounds    x[2610]
 BV bounds    x[2611]
 FX bounds    x[2612]   0
 FX bounds    x[2613]   0
 FX bounds    x[2614]   0
 FX bounds    x[2615]   0
 FX bounds    x[2616]   0
 FX bounds    x[2617]   0
 FX bounds    x[2618]   0
 FX bounds    x[2619]   0
 FX bounds    x[2620]   0
 FX bounds    x[2621]   0
 FX bounds    x[2622]   0
 FX bounds    x[2623]   0
 FX bounds    x[2624]   0
 FX bounds    x[2625]   0
 FX bounds    x[2626]   0
 FX bounds    x[2627]   0
 FX bounds    x[2628]   0
 BV bounds    x[2629]
 BV bounds    x[2630]
 BV bounds    x[2631]
 BV bounds    x[2632]
 BV bounds    x[2633]
 BV bounds    x[2634]
 BV bounds    x[2635]
 BV bounds    x[2636]
 BV bounds    x[2637]
 BV bounds    x[2638]
 BV bounds    x[2639]
 BV bounds    x[2640]
 BV bounds    x[2641]
 BV bounds    x[2642]
 BV bounds    x[2643]
 BV bounds    x[2644]
 BV bounds    x[2645]
 BV bounds    x[2646]
 BV bounds    x[2647]
 BV bounds    x[2648]
 BV bounds    x[2649]
 BV bounds    x[2650]
 BV bounds    x[2651]
 BV bounds    x[2652]
 BV bounds    x[2653]
 BV bounds    x[2654]
 BV bounds    x[2655]
 BV bounds    x[2656]
 BV bounds    x[2657]
 BV bounds    x[2658]
 BV bounds    x[2659]
 BV bounds    x[2660]
 BV bounds    x[2661]
 BV bounds    x[2662]
 BV bounds    x[2663]
 BV bounds    x[2664]
 BV bounds    x[2665]
 BV bounds    x[2666]
 BV bounds    x[2667]
 BV bounds    x[2668]
 BV bounds    x[2669]
 BV bounds    x[2670]
 BV bounds    x[2671]
 BV bounds    x[2672]
 BV bounds    x[2673]
 BV bounds    x[2674]
 BV bounds    x[2675]
 BV bounds    x[2676]
 BV bounds    x[2677]
 BV bounds    x[2678]
 BV bounds    x[2679]
 BV bounds    x[2680]
 BV bounds    x[2681]
 BV bounds    x[2682]
 BV bounds    x[2683]
 BV bounds    x[2684]
 BV bounds    x[2685]
 BV bounds    x[2686]
 BV bounds    x[2687]
 BV bounds    x[2688]
 BV bounds    x[2689]
 BV bounds    x[2690]
 BV bounds    x[2691]
 BV bounds    x[2692]
 BV bounds    x[2693]
 BV bounds    x[2694]
 BV bounds    x[2695]
 BV bounds    x[2696]
 BV bounds    x[2697]
 BV bounds    x[2698]
 BV bounds    x[2699]
 BV bounds    x[2700]
 BV bounds    x[2701]
 FX bounds    x[2702]   0
 FX bounds    x[2703]   0
 FX bounds    x[2704]   0
 FX bounds    x[2705]   0
 FX bounds    x[2706]   0
 FX bounds    x[2707]   0
 FX bounds    x[2708]   0
 FX bounds    x[2709]   0
 FX bounds    x[2710]   0
 FX bounds    x[2711]   0
 FX bounds    x[2712]   0
 FX bounds    x[2713]   0
 FX bounds    x[2714]   0
 FX bounds    x[2715]   0
 FX bounds    x[2716]   0
 FX bounds    x[2717]   0
 FX bounds    x[2718]   0
 BV bounds    x[2719]
 BV bounds    x[2720]
 BV bounds    x[2721]
 BV bounds    x[2722]
 BV bounds    x[2723]
 BV bounds    x[2724]
 BV bounds    x[2725]
 BV bounds    x[2726]
 BV bounds    x[2727]
 BV bounds    x[2728]
 BV bounds    x[2729]
 BV bounds    x[2730]
 BV bounds    x[2731]
 BV bounds    x[2732]
 BV bounds    x[2733]
 BV bounds    x[2734]
 BV bounds    x[2735]
 BV bounds    x[2736]
 BV bounds    x[2737]
 BV bounds    x[2738]
 BV bounds    x[2739]
 BV bounds    x[2740]
 BV bounds    x[2741]
 BV bounds    x[2742]
 BV bounds    x[2743]
 BV bounds    x[2744]
 BV bounds    x[2745]
 BV bounds    x[2746]
 BV bounds    x[2747]
 BV bounds    x[2748]
 BV bounds    x[2749]
 BV bounds    x[2750]
 BV bounds    x[2751]
 BV bounds    x[2752]
 BV bounds    x[2753]
 BV bounds    x[2754]
 BV bounds    x[2755]
 BV bounds    x[2756]
 BV bounds    x[2757]
 BV bounds    x[2758]
 BV bounds    x[2759]
 BV bounds    x[2760]
 BV bounds    x[2761]
 BV bounds    x[2762]
 BV bounds    x[2763]
 BV bounds    x[2764]
 BV bounds    x[2765]
 BV bounds    x[2766]
 BV bounds    x[2767]
 BV bounds    x[2768]
 BV bounds    x[2769]
 BV bounds    x[2770]
 BV bounds    x[2771]
 BV bounds    x[2772]
 BV bounds    x[2773]
 BV bounds    x[2774]
 BV bounds    x[2775]
 BV bounds    x[2776]
 BV bounds    x[2777]
 BV bounds    x[2778]
 BV bounds    x[2779]
 BV bounds    x[2780]
 BV bounds    x[2781]
 BV bounds    x[2782]
 BV bounds    x[2783]
 BV bounds    x[2784]
 BV bounds    x[2785]
 BV bounds    x[2786]
 BV bounds    x[2787]
 BV bounds    x[2788]
 BV bounds    x[2789]
 BV bounds    x[2790]
 BV bounds    x[2791]
 FX bounds    x[2792]   0
 FX bounds    x[2793]   0
 FX bounds    x[2794]   0
 FX bounds    x[2795]   0
 FX bounds    x[2796]   0
 FX bounds    x[2797]   0
 FX bounds    x[2798]   0
 FX bounds    x[2799]   0
 FX bounds    x[2800]   0
 FX bounds    x[2801]   0
 FX bounds    x[2802]   0
 FX bounds    x[2803]   0
 FX bounds    x[2804]   0
 FX bounds    x[2805]   0
 FX bounds    x[2806]   0
 FX bounds    x[2807]   0
 FX bounds    x[2808]   0
 BV bounds    x[2809]
 BV bounds    x[2810]
 BV bounds    x[2811]
 BV bounds    x[2812]
 BV bounds    x[2813]
 BV bounds    x[2814]
 BV bounds    x[2815]
 BV bounds    x[2816]
 BV bounds    x[2817]
 BV bounds    x[2818]
 BV bounds    x[2819]
 BV bounds    x[2820]
 BV bounds    x[2821]
 BV bounds    x[2822]
 BV bounds    x[2823]
 BV bounds    x[2824]
 BV bounds    x[2825]
 BV bounds    x[2826]
 BV bounds    x[2827]
 BV bounds    x[2828]
 BV bounds    x[2829]
 BV bounds    x[2830]
 BV bounds    x[2831]
 BV bounds    x[2832]
 BV bounds    x[2833]
 BV bounds    x[2834]
 BV bounds    x[2835]
 BV bounds    x[2836]
 BV bounds    x[2837]
 BV bounds    x[2838]
 BV bounds    x[2839]
 BV bounds    x[2840]
 BV bounds    x[2841]
 BV bounds    x[2842]
 BV bounds    x[2843]
 BV bounds    x[2844]
 BV bounds    x[2845]
 BV bounds    x[2846]
 BV bounds    x[2847]
 BV bounds    x[2848]
 BV bounds    x[2849]
 BV bounds    x[2850]
 BV bounds    x[2851]
 BV bounds    x[2852]
 BV bounds    x[2853]
 BV bounds    x[2854]
 BV bounds    x[2855]
 BV bounds    x[2856]
 BV bounds    x[2857]
 BV bounds    x[2858]
 BV bounds    x[2859]
 BV bounds    x[2860]
 BV bounds    x[2861]
 BV bounds    x[2862]
 BV bounds    x[2863]
 BV bounds    x[2864]
 BV bounds    x[2865]
 BV bounds    x[2866]
 BV bounds    x[2867]
 BV bounds    x[2868]
 BV bounds    x[2869]
 BV bounds    x[2870]
 BV bounds    x[2871]
 BV bounds    x[2872]
 BV bounds    x[2873]
 BV bounds    x[2874]
 BV bounds    x[2875]
 BV bounds    x[2876]
 BV bounds    x[2877]
 BV bounds    x[2878]
 BV bounds    x[2879]
 BV bounds    x[2880]
 BV bounds    x[2881]
 FX bounds    x[2882]   0
 FX bounds    x[2883]   0
 FX bounds    x[2884]   0
 FX bounds    x[2885]   0
 FX bounds    x[2886]   0
 FX bounds    x[2887]   0
 FX bounds    x[2888]   0
 FX bounds    x[2889]   0
 FX bounds    x[2890]   0
 FX bounds    x[2891]   0
 FX bounds    x[2892]   0
 FX bounds    x[2893]   0
 FX bounds    x[2894]   0
 FX bounds    x[2895]   0
 FX bounds    x[2896]   0
 FX bounds    x[2897]   0
 FX bounds    x[2898]   0
 BV bounds    x[2899]
 BV bounds    x[2900]
 BV bounds    x[2901]
 BV bounds    x[2902]
 BV bounds    x[2903]
 BV bounds    x[2904]
 BV bounds    x[2905]
 BV bounds    x[2906]
 BV bounds    x[2907]
 BV bounds    x[2908]
 BV bounds    x[2909]
 BV bounds    x[2910]
 BV bounds    x[2911]
 BV bounds    x[2912]
 BV bounds    x[2913]
 BV bounds    x[2914]
 BV bounds    x[2915]
 BV bounds    x[2916]
 BV bounds    x[2917]
 BV bounds    x[2918]
 BV bounds    x[2919]
 BV bounds    x[2920]
 BV bounds    x[2921]
 BV bounds    x[2922]
 BV bounds    x[2923]
 BV bounds    x[2924]
 BV bounds    x[2925]
 BV bounds    x[2926]
 BV bounds    x[2927]
 BV bounds    x[2928]
 BV bounds    x[2929]
 BV bounds    x[2930]
 BV bounds    x[2931]
 BV bounds    x[2932]
 BV bounds    x[2933]
 BV bounds    x[2934]
 BV bounds    x[2935]
 BV bounds    x[2936]
 BV bounds    x[2937]
 BV bounds    x[2938]
 BV bounds    x[2939]
 BV bounds    x[2940]
 BV bounds    x[2941]
 BV bounds    x[2942]
 BV bounds    x[2943]
 BV bounds    x[2944]
 BV bounds    x[2945]
 BV bounds    x[2946]
 BV bounds    x[2947]
 BV bounds    x[2948]
 BV bounds    x[2949]
 BV bounds    x[2950]
 BV bounds    x[2951]
 BV bounds    x[2952]
 BV bounds    x[2953]
 BV bounds    x[2954]
 BV bounds    x[2955]
 BV bounds    x[2956]
 BV bounds    x[2957]
 BV bounds    x[2958]
 BV bounds    x[2959]
 BV bounds    x[2960]
 BV bounds    x[2961]
 BV bounds    x[2962]
 BV bounds    x[2963]
 BV bounds    x[2964]
 BV bounds    x[2965]
 BV bounds    x[2966]
 BV bounds    x[2967]
 BV bounds    x[2968]
 BV bounds    x[2969]
 BV bounds    x[2970]
 BV bounds    x[2971]
 FX bounds    x[2972]   0
 FX bounds    x[2973]   0
 FX bounds    x[2974]   0
 FX bounds    x[2975]   0
 FX bounds    x[2976]   0
 FX bounds    x[2977]   0
 FX bounds    x[2978]   0
 FX bounds    x[2979]   0
 FX bounds    x[2980]   0
 FX bounds    x[2981]   0
 FX bounds    x[2982]   0
 FX bounds    x[2983]   0
 FX bounds    x[2984]   0
 FX bounds    x[2985]   0
 FX bounds    x[2986]   0
 FX bounds    x[2987]   0
 FX bounds    x[2988]   0
 BV bounds    x[2989]
 BV bounds    x[2990]
 BV bounds    x[2991]
 BV bounds    x[2992]
 BV bounds    x[2993]
 BV bounds    x[2994]
 BV bounds    x[2995]
 BV bounds    x[2996]
 BV bounds    x[2997]
 BV bounds    x[2998]
 BV bounds    x[2999]
 BV bounds    x[3000]
 BV bounds    x[3001]
 BV bounds    x[3002]
 BV bounds    x[3003]
 BV bounds    x[3004]
 BV bounds    x[3005]
 BV bounds    x[3006]
 BV bounds    x[3007]
 BV bounds    x[3008]
 BV bounds    x[3009]
 BV bounds    x[3010]
 BV bounds    x[3011]
 BV bounds    x[3012]
 BV bounds    x[3013]
 BV bounds    x[3014]
 BV bounds    x[3015]
 BV bounds    x[3016]
 BV bounds    x[3017]
 BV bounds    x[3018]
 BV bounds    x[3019]
 BV bounds    x[3020]
 BV bounds    x[3021]
 BV bounds    x[3022]
 BV bounds    x[3023]
 BV bounds    x[3024]
 BV bounds    x[3025]
 BV bounds    x[3026]
 BV bounds    x[3027]
 BV bounds    x[3028]
 BV bounds    x[3029]
 BV bounds    x[3030]
 BV bounds    x[3031]
 BV bounds    x[3032]
 BV bounds    x[3033]
 BV bounds    x[3034]
 BV bounds    x[3035]
 BV bounds    x[3036]
 BV bounds    x[3037]
 BV bounds    x[3038]
 BV bounds    x[3039]
 BV bounds    x[3040]
 BV bounds    x[3041]
 BV bounds    x[3042]
 BV bounds    x[3043]
 BV bounds    x[3044]
 BV bounds    x[3045]
 BV bounds    x[3046]
 BV bounds    x[3047]
 BV bounds    x[3048]
 BV bounds    x[3049]
 BV bounds    x[3050]
 BV bounds    x[3051]
 BV bounds    x[3052]
 BV bounds    x[3053]
 BV bounds    x[3054]
 BV bounds    x[3055]
 BV bounds    x[3056]
 BV bounds    x[3057]
 BV bounds    x[3058]
 BV bounds    x[3059]
 BV bounds    x[3060]
 BV bounds    x[3061]
 FX bounds    x[3062]   0
 FX bounds    x[3063]   0
 FX bounds    x[3064]   0
 FX bounds    x[3065]   0
 FX bounds    x[3066]   0
 FX bounds    x[3067]   0
 FX bounds    x[3068]   0
 FX bounds    x[3069]   0
 FX bounds    x[3070]   0
 FX bounds    x[3071]   0
 FX bounds    x[3072]   0
 FX bounds    x[3073]   0
 FX bounds    x[3074]   0
 FX bounds    x[3075]   0
 FX bounds    x[3076]   0
 FX bounds    x[3077]   0
 FX bounds    x[3078]   0
 BV bounds    x[3079]
 BV bounds    x[3080]
 BV bounds    x[3081]
 BV bounds    x[3082]
 BV bounds    x[3083]
 BV bounds    x[3084]
 BV bounds    x[3085]
 BV bounds    x[3086]
 BV bounds    x[3087]
 BV bounds    x[3088]
 BV bounds    x[3089]
 BV bounds    x[3090]
 BV bounds    x[3091]
 BV bounds    x[3092]
 BV bounds    x[3093]
 BV bounds    x[3094]
 BV bounds    x[3095]
 BV bounds    x[3096]
 BV bounds    x[3097]
 BV bounds    x[3098]
 BV bounds    x[3099]
 BV bounds    x[3100]
 BV bounds    x[3101]
 BV bounds    x[3102]
 BV bounds    x[3103]
 BV bounds    x[3104]
 BV bounds    x[3105]
 BV bounds    x[3106]
 BV bounds    x[3107]
 BV bounds    x[3108]
 BV bounds    x[3109]
 BV bounds    x[3110]
 BV bounds    x[3111]
 BV bounds    x[3112]
 BV bounds    x[3113]
 BV bounds    x[3114]
 BV bounds    x[3115]
 BV bounds    x[3116]
 BV bounds    x[3117]
 BV bounds    x[3118]
 BV bounds    x[3119]
 BV bounds    x[3120]
 BV bounds    x[3121]
 BV bounds    x[3122]
 BV bounds    x[3123]
 BV bounds    x[3124]
 BV bounds    x[3125]
 BV bounds    x[3126]
 BV bounds    x[3127]
 BV bounds    x[3128]
 BV bounds    x[3129]
 BV bounds    x[3130]
 BV bounds    x[3131]
 BV bounds    x[3132]
 BV bounds    x[3133]
 BV bounds    x[3134]
 BV bounds    x[3135]
 BV bounds    x[3136]
 BV bounds    x[3137]
 BV bounds    x[3138]
 BV bounds    x[3139]
 BV bounds    x[3140]
 BV bounds    x[3141]
 BV bounds    x[3142]
 BV bounds    x[3143]
 BV bounds    x[3144]
 BV bounds    x[3145]
 BV bounds    x[3146]
 BV bounds    x[3147]
 BV bounds    x[3148]
 BV bounds    x[3149]
 BV bounds    x[3150]
 BV bounds    x[3151]
 FX bounds    x[3152]   0
 FX bounds    x[3153]   0
 FX bounds    x[3154]   0
 FX bounds    x[3155]   0
 FX bounds    x[3156]   0
 FX bounds    x[3157]   0
 FX bounds    x[3158]   0
 FX bounds    x[3159]   0
 FX bounds    x[3160]   0
 FX bounds    x[3161]   0
 FX bounds    x[3162]   0
 FX bounds    x[3163]   0
 FX bounds    x[3164]   0
 FX bounds    x[3165]   0
 FX bounds    x[3166]   0
 FX bounds    x[3167]   0
 FX bounds    x[3168]   0
 BV bounds    x[3169]
 BV bounds    x[3170]
 BV bounds    x[3171]
 BV bounds    x[3172]
 BV bounds    x[3173]
 BV bounds    x[3174]
 BV bounds    x[3175]
 BV bounds    x[3176]
 BV bounds    x[3177]
 BV bounds    x[3178]
 BV bounds    x[3179]
 BV bounds    x[3180]
 BV bounds    x[3181]
 BV bounds    x[3182]
 BV bounds    x[3183]
 BV bounds    x[3184]
 BV bounds    x[3185]
 BV bounds    x[3186]
 BV bounds    x[3187]
 BV bounds    x[3188]
 BV bounds    x[3189]
 BV bounds    x[3190]
 BV bounds    x[3191]
 BV bounds    x[3192]
 BV bounds    x[3193]
 BV bounds    x[3194]
 BV bounds    x[3195]
 BV bounds    x[3196]
 BV bounds    x[3197]
 BV bounds    x[3198]
 BV bounds    x[3199]
 BV bounds    x[3200]
 BV bounds    x[3201]
 BV bounds    x[3202]
 BV bounds    x[3203]
 BV bounds    x[3204]
 BV bounds    x[3205]
 BV bounds    x[3206]
 BV bounds    x[3207]
 BV bounds    x[3208]
 BV bounds    x[3209]
 BV bounds    x[3210]
 BV bounds    x[3211]
 BV bounds    x[3212]
 BV bounds    x[3213]
 BV bounds    x[3214]
 BV bounds    x[3215]
 BV bounds    x[3216]
 BV bounds    x[3217]
 BV bounds    x[3218]
 BV bounds    x[3219]
 BV bounds    x[3220]
 BV bounds    x[3221]
 BV bounds    x[3222]
 BV bounds    x[3223]
 BV bounds    x[3224]
 BV bounds    x[3225]
 BV bounds    x[3226]
 BV bounds    x[3227]
 BV bounds    x[3228]
 BV bounds    x[3229]
 BV bounds    x[3230]
 BV bounds    x[3231]
 BV bounds    x[3232]
 BV bounds    x[3233]
 BV bounds    x[3234]
 BV bounds    x[3235]
 BV bounds    x[3236]
 BV bounds    x[3237]
 BV bounds    x[3238]
 BV bounds    x[3239]
 BV bounds    x[3240]
 BV bounds    x[3241]
 FX bounds    x[3242]   0
 FX bounds    x[3243]   0
 FX bounds    x[3244]   0
 FX bounds    x[3245]   0
 FX bounds    x[3246]   0
 FX bounds    x[3247]   0
 FX bounds    x[3248]   0
 FX bounds    x[3249]   0
 FX bounds    x[3250]   0
 FX bounds    x[3251]   0
 FX bounds    x[3252]   0
 FX bounds    x[3253]   0
 FX bounds    x[3254]   0
 FX bounds    x[3255]   0
 FX bounds    x[3256]   0
 FX bounds    x[3257]   0
 FX bounds    x[3258]   0
 BV bounds    x[3259]
 BV bounds    x[3260]
 BV bounds    x[3261]
 BV bounds    x[3262]
 BV bounds    x[3263]
 BV bounds    x[3264]
 BV bounds    x[3265]
 BV bounds    x[3266]
 BV bounds    x[3267]
 BV bounds    x[3268]
 BV bounds    x[3269]
 BV bounds    x[3270]
 BV bounds    x[3271]
 BV bounds    x[3272]
 BV bounds    x[3273]
 BV bounds    x[3274]
 BV bounds    x[3275]
 BV bounds    x[3276]
 BV bounds    x[3277]
 BV bounds    x[3278]
 BV bounds    x[3279]
 BV bounds    x[3280]
 BV bounds    x[3281]
 BV bounds    x[3282]
 BV bounds    x[3283]
 BV bounds    x[3284]
 BV bounds    x[3285]
 BV bounds    x[3286]
 BV bounds    x[3287]
 BV bounds    x[3288]
 BV bounds    x[3289]
 BV bounds    x[3290]
 BV bounds    x[3291]
 BV bounds    x[3292]
 BV bounds    x[3293]
 BV bounds    x[3294]
 BV bounds    x[3295]
 BV bounds    x[3296]
 BV bounds    x[3297]
 BV bounds    x[3298]
 BV bounds    x[3299]
 BV bounds    x[3300]
 BV bounds    x[3301]
 BV bounds    x[3302]
 BV bounds    x[3303]
 BV bounds    x[3304]
 BV bounds    x[3305]
 BV bounds    x[3306]
 BV bounds    x[3307]
 BV bounds    x[3308]
 BV bounds    x[3309]
 BV bounds    x[3310]
 BV bounds    x[3311]
 BV bounds    x[3312]
 BV bounds    x[3313]
 BV bounds    x[3314]
 BV bounds    x[3315]
 BV bounds    x[3316]
 BV bounds    x[3317]
 BV bounds    x[3318]
 BV bounds    x[3319]
 BV bounds    x[3320]
 BV bounds    x[3321]
 BV bounds    x[3322]
 BV bounds    x[3323]
 BV bounds    x[3324]
 BV bounds    x[3325]
 BV bounds    x[3326]
 BV bounds    x[3327]
 BV bounds    x[3328]
 BV bounds    x[3329]
 BV bounds    x[3330]
 BV bounds    x[3331]
 FX bounds    x[3332]   0
 FX bounds    x[3333]   0
 FX bounds    x[3334]   0
 FX bounds    x[3335]   0
 FX bounds    x[3336]   0
 FX bounds    x[3337]   0
 FX bounds    x[3338]   0
 FX bounds    x[3339]   0
 FX bounds    x[3340]   0
 FX bounds    x[3341]   0
 FX bounds    x[3342]   0
 FX bounds    x[3343]   0
 FX bounds    x[3344]   0
 FX bounds    x[3345]   0
 FX bounds    x[3346]   0
 FX bounds    x[3347]   0
 FX bounds    x[3348]   0
 BV bounds    x[3349]
 BV bounds    x[3350]
 BV bounds    x[3351]
 BV bounds    x[3352]
 BV bounds    x[3353]
 BV bounds    x[3354]
 BV bounds    x[3355]
 BV bounds    x[3356]
 BV bounds    x[3357]
 BV bounds    x[3358]
 BV bounds    x[3359]
 BV bounds    x[3360]
 BV bounds    x[3361]
 BV bounds    x[3362]
 BV bounds    x[3363]
 BV bounds    x[3364]
 BV bounds    x[3365]
 BV bounds    x[3366]
 BV bounds    x[3367]
 BV bounds    x[3368]
 BV bounds    x[3369]
 BV bounds    x[3370]
 BV bounds    x[3371]
 BV bounds    x[3372]
 BV bounds    x[3373]
 BV bounds    x[3374]
 BV bounds    x[3375]
 BV bounds    x[3376]
 BV bounds    x[3377]
 BV bounds    x[3378]
 BV bounds    x[3379]
 BV bounds    x[3380]
 BV bounds    x[3381]
 BV bounds    x[3382]
 BV bounds    x[3383]
 BV bounds    x[3384]
 BV bounds    x[3385]
 BV bounds    x[3386]
 BV bounds    x[3387]
 BV bounds    x[3388]
 BV bounds    x[3389]
 BV bounds    x[3390]
 BV bounds    x[3391]
 BV bounds    x[3392]
 BV bounds    x[3393]
 BV bounds    x[3394]
 BV bounds    x[3395]
 BV bounds    x[3396]
 BV bounds    x[3397]
 BV bounds    x[3398]
 BV bounds    x[3399]
 BV bounds    x[3400]
 BV bounds    x[3401]
 BV bounds    x[3402]
 BV bounds    x[3403]
 BV bounds    x[3404]
 BV bounds    x[3405]
 BV bounds    x[3406]
 BV bounds    x[3407]
 BV bounds    x[3408]
 BV bounds    x[3409]
 BV bounds    x[3410]
 BV bounds    x[3411]
 BV bounds    x[3412]
 BV bounds    x[3413]
 BV bounds    x[3414]
 BV bounds    x[3415]
 BV bounds    x[3416]
 BV bounds    x[3417]
 BV bounds    x[3418]
 BV bounds    x[3419]
 BV bounds    x[3420]
 BV bounds    x[3421]
 FX bounds    x[3422]   0
 FX bounds    x[3423]   0
 FX bounds    x[3424]   0
 FX bounds    x[3425]   0
 FX bounds    x[3426]   0
 FX bounds    x[3427]   0
 FX bounds    x[3428]   0
 FX bounds    x[3429]   0
 FX bounds    x[3430]   0
 FX bounds    x[3431]   0
 FX bounds    x[3432]   0
 FX bounds    x[3433]   0
 FX bounds    x[3434]   0
 FX bounds    x[3435]   0
 FX bounds    x[3436]   0
 FX bounds    x[3437]   0
 FX bounds    x[3438]   0
 BV bounds    x[3439]
 BV bounds    x[3440]
 BV bounds    x[3441]
 BV bounds    x[3442]
 BV bounds    x[3443]
 BV bounds    x[3444]
 BV bounds    x[3445]
 BV bounds    x[3446]
 BV bounds    x[3447]
 BV bounds    x[3448]
 BV bounds    x[3449]
 BV bounds    x[3450]
 BV bounds    x[3451]
 BV bounds    x[3452]
 BV bounds    x[3453]
 BV bounds    x[3454]
 BV bounds    x[3455]
 BV bounds    x[3456]
 BV bounds    x[3457]
 BV bounds    x[3458]
 BV bounds    x[3459]
 BV bounds    x[3460]
 BV bounds    x[3461]
 BV bounds    x[3462]
 BV bounds    x[3463]
 BV bounds    x[3464]
 BV bounds    x[3465]
 BV bounds    x[3466]
 BV bounds    x[3467]
 BV bounds    x[3468]
 BV bounds    x[3469]
 BV bounds    x[3470]
 BV bounds    x[3471]
 BV bounds    x[3472]
 BV bounds    x[3473]
 BV bounds    x[3474]
 BV bounds    x[3475]
 BV bounds    x[3476]
 BV bounds    x[3477]
 BV bounds    x[3478]
 BV bounds    x[3479]
 BV bounds    x[3480]
 BV bounds    x[3481]
 BV bounds    x[3482]
 BV bounds    x[3483]
 BV bounds    x[3484]
 BV bounds    x[3485]
 BV bounds    x[3486]
 BV bounds    x[3487]
 BV bounds    x[3488]
 BV bounds    x[3489]
 BV bounds    x[3490]
 BV bounds    x[3491]
 BV bounds    x[3492]
 BV bounds    x[3493]
 BV bounds    x[3494]
 BV bounds    x[3495]
 BV bounds    x[3496]
 BV bounds    x[3497]
 BV bounds    x[3498]
 BV bounds    x[3499]
 BV bounds    x[3500]
 BV bounds    x[3501]
 BV bounds    x[3502]
 BV bounds    x[3503]
 BV bounds    x[3504]
 BV bounds    x[3505]
 BV bounds    x[3506]
 BV bounds    x[3507]
 BV bounds    x[3508]
 BV bounds    x[3509]
 BV bounds    x[3510]
 BV bounds    x[3511]
 FX bounds    x[3512]   0
 FX bounds    x[3513]   0
 FX bounds    x[3514]   0
 FX bounds    x[3515]   0
 FX bounds    x[3516]   0
 FX bounds    x[3517]   0
 FX bounds    x[3518]   0
 FX bounds    x[3519]   0
 FX bounds    x[3520]   0
 FX bounds    x[3521]   0
 FX bounds    x[3522]   0
 FX bounds    x[3523]   0
 FX bounds    x[3524]   0
 FX bounds    x[3525]   0
 FX bounds    x[3526]   0
 FX bounds    x[3527]   0
 FX bounds    x[3528]   0
 BV bounds    x[3529]
 BV bounds    x[3530]
 BV bounds    x[3531]
 BV bounds    x[3532]
 BV bounds    x[3533]
 BV bounds    x[3534]
 BV bounds    x[3535]
 BV bounds    x[3536]
 BV bounds    x[3537]
 BV bounds    x[3538]
 BV bounds    x[3539]
 BV bounds    x[3540]
 BV bounds    x[3541]
 BV bounds    x[3542]
 BV bounds    x[3543]
 BV bounds    x[3544]
 BV bounds    x[3545]
 BV bounds    x[3546]
 BV bounds    x[3547]
 BV bounds    x[3548]
 BV bounds    x[3549]
 BV bounds    x[3550]
 BV bounds    x[3551]
 BV bounds    x[3552]
 BV bounds    x[3553]
 BV bounds    x[3554]
 BV bounds    x[3555]
 BV bounds    x[3556]
 BV bounds    x[3557]
 BV bounds    x[3558]
 BV bounds    x[3559]
 BV bounds    x[3560]
 BV bounds    x[3561]
 BV bounds    x[3562]
 BV bounds    x[3563]
 BV bounds    x[3564]
 BV bounds    x[3565]
 BV bounds    x[3566]
 BV bounds    x[3567]
 BV bounds    x[3568]
 BV bounds    x[3569]
 BV bounds    x[3570]
 BV bounds    x[3571]
 BV bounds    x[3572]
 BV bounds    x[3573]
 BV bounds    x[3574]
 BV bounds    x[3575]
 BV bounds    x[3576]
 BV bounds    x[3577]
 BV bounds    x[3578]
 BV bounds    x[3579]
 BV bounds    x[3580]
 BV bounds    x[3581]
 BV bounds    x[3582]
 BV bounds    x[3583]
 BV bounds    x[3584]
 BV bounds    x[3585]
 BV bounds    x[3586]
 BV bounds    x[3587]
 BV bounds    x[3588]
 BV bounds    x[3589]
 BV bounds    x[3590]
 BV bounds    x[3591]
 BV bounds    x[3592]
 BV bounds    x[3593]
 BV bounds    x[3594]
 BV bounds    x[3595]
 BV bounds    x[3596]
 BV bounds    x[3597]
 BV bounds    x[3598]
 BV bounds    x[3599]
 BV bounds    x[3600]
 BV bounds    x[3601]
 FX bounds    x[3602]   0
 FX bounds    x[3603]   0
 FX bounds    x[3604]   0
 FX bounds    x[3605]   0
 FX bounds    x[3606]   0
 FX bounds    x[3607]   0
 FX bounds    x[3608]   0
 FX bounds    x[3609]   0
 FX bounds    x[3610]   0
 FX bounds    x[3611]   0
 FX bounds    x[3612]   0
 FX bounds    x[3613]   0
 FX bounds    x[3614]   0
 FX bounds    x[3615]   0
 FX bounds    x[3616]   0
 FX bounds    x[3617]   0
 FX bounds    x[3618]   0
 BV bounds    x[3619]
 BV bounds    x[3620]
 BV bounds    x[3621]
 BV bounds    x[3622]
 BV bounds    x[3623]
 BV bounds    x[3624]
 BV bounds    x[3625]
 BV bounds    x[3626]
 BV bounds    x[3627]
 BV bounds    x[3628]
 BV bounds    x[3629]
 BV bounds    x[3630]
 BV bounds    x[3631]
 BV bounds    x[3632]
 BV bounds    x[3633]
 BV bounds    x[3634]
 BV bounds    x[3635]
 BV bounds    x[3636]
 BV bounds    x[3637]
 BV bounds    x[3638]
 BV bounds    x[3639]
 BV bounds    x[3640]
 BV bounds    x[3641]
 BV bounds    x[3642]
 BV bounds    x[3643]
 BV bounds    x[3644]
 BV bounds    x[3645]
 BV bounds    x[3646]
 BV bounds    x[3647]
 BV bounds    x[3648]
 BV bounds    x[3649]
 BV bounds    x[3650]
 BV bounds    x[3651]
 BV bounds    x[3652]
 BV bounds    x[3653]
 BV bounds    x[3654]
 BV bounds    x[3655]
 BV bounds    x[3656]
 BV bounds    x[3657]
 BV bounds    x[3658]
 BV bounds    x[3659]
 BV bounds    x[3660]
 BV bounds    x[3661]
 BV bounds    x[3662]
 BV bounds    x[3663]
 BV bounds    x[3664]
 BV bounds    x[3665]
 BV bounds    x[3666]
 BV bounds    x[3667]
 BV bounds    x[3668]
 BV bounds    x[3669]
 BV bounds    x[3670]
 BV bounds    x[3671]
 BV bounds    x[3672]
 BV bounds    x[3673]
 BV bounds    x[3674]
 BV bounds    x[3675]
 BV bounds    x[3676]
 BV bounds    x[3677]
 BV bounds    x[3678]
 BV bounds    x[3679]
 BV bounds    x[3680]
 BV bounds    x[3681]
 BV bounds    x[3682]
 BV bounds    x[3683]
 BV bounds    x[3684]
 BV bounds    x[3685]
 BV bounds    x[3686]
 BV bounds    x[3687]
 BV bounds    x[3688]
 BV bounds    x[3689]
 BV bounds    x[3690]
 BV bounds    x[3691]
 FX bounds    x[3692]   0
 FX bounds    x[3693]   0
 FX bounds    x[3694]   0
 FX bounds    x[3695]   0
 FX bounds    x[3696]   0
 FX bounds    x[3697]   0
 FX bounds    x[3698]   0
 FX bounds    x[3699]   0
 FX bounds    x[3700]   0
 FX bounds    x[3701]   0
 FX bounds    x[3702]   0
 FX bounds    x[3703]   0
 FX bounds    x[3704]   0
 FX bounds    x[3705]   0
 FX bounds    x[3706]   0
 FX bounds    x[3707]   0
 FX bounds    x[3708]   0
 BV bounds    x[3709]
 BV bounds    x[3710]
 BV bounds    x[3711]
 BV bounds    x[3712]
 BV bounds    x[3713]
 BV bounds    x[3714]
 BV bounds    x[3715]
 BV bounds    x[3716]
 BV bounds    x[3717]
 BV bounds    x[3718]
 BV bounds    x[3719]
 BV bounds    x[3720]
 BV bounds    x[3721]
 BV bounds    x[3722]
 BV bounds    x[3723]
 BV bounds    x[3724]
 BV bounds    x[3725]
 BV bounds    x[3726]
 BV bounds    x[3727]
 BV bounds    x[3728]
 BV bounds    x[3729]
 BV bounds    x[3730]
 BV bounds    x[3731]
 BV bounds    x[3732]
 BV bounds    x[3733]
 BV bounds    x[3734]
 BV bounds    x[3735]
 BV bounds    x[3736]
 BV bounds    x[3737]
 BV bounds    x[3738]
 BV bounds    x[3739]
 BV bounds    x[3740]
 BV bounds    x[3741]
 BV bounds    x[3742]
 BV bounds    x[3743]
 BV bounds    x[3744]
 BV bounds    x[3745]
 BV bounds    x[3746]
 BV bounds    x[3747]
 BV bounds    x[3748]
 BV bounds    x[3749]
 BV bounds    x[3750]
 BV bounds    x[3751]
 BV bounds    x[3752]
 BV bounds    x[3753]
 BV bounds    x[3754]
 BV bounds    x[3755]
 BV bounds    x[3756]
 BV bounds    x[3757]
 BV bounds    x[3758]
 BV bounds    x[3759]
 BV bounds    x[3760]
 BV bounds    x[3761]
 BV bounds    x[3762]
 BV bounds    x[3763]
 BV bounds    x[3764]
 BV bounds    x[3765]
 BV bounds    x[3766]
 BV bounds    x[3767]
 BV bounds    x[3768]
 BV bounds    x[3769]
 BV bounds    x[3770]
 BV bounds    x[3771]
 BV bounds    x[3772]
 BV bounds    x[3773]
 BV bounds    x[3774]
 BV bounds    x[3775]
 BV bounds    x[3776]
 BV bounds    x[3777]
 BV bounds    x[3778]
 BV bounds    x[3779]
 BV bounds    x[3780]
 BV bounds    x[3781]
 FX bounds    x[3782]   0
 FX bounds    x[3783]   0
 FX bounds    x[3784]   0
 FX bounds    x[3785]   0
 FX bounds    x[3786]   0
 FX bounds    x[3787]   0
 FX bounds    x[3788]   0
 FX bounds    x[3789]   0
 FX bounds    x[3790]   0
 FX bounds    x[3791]   0
 FX bounds    x[3792]   0
 FX bounds    x[3793]   0
 FX bounds    x[3794]   0
 FX bounds    x[3795]   0
 FX bounds    x[3796]   0
 FX bounds    x[3797]   0
 FX bounds    x[3798]   0
 BV bounds    x[3799]
 BV bounds    x[3800]
 BV bounds    x[3801]
 BV bounds    x[3802]
 BV bounds    x[3803]
 BV bounds    x[3804]
 BV bounds    x[3805]
 BV bounds    x[3806]
 BV bounds    x[3807]
 BV bounds    x[3808]
 BV bounds    x[3809]
 BV bounds    x[3810]
 BV bounds    x[3811]
 BV bounds    x[3812]
 BV bounds    x[3813]
 BV bounds    x[3814]
 BV bounds    x[3815]
 BV bounds    x[3816]
 BV bounds    x[3817]
 BV bounds    x[3818]
 BV bounds    x[3819]
 BV bounds    x[3820]
 BV bounds    x[3821]
 BV bounds    x[3822]
 BV bounds    x[3823]
 BV bounds    x[3824]
 BV bounds    x[3825]
 BV bounds    x[3826]
 BV bounds    x[3827]
 BV bounds    x[3828]
 BV bounds    x[3829]
 BV bounds    x[3830]
 BV bounds    x[3831]
 BV bounds    x[3832]
 BV bounds    x[3833]
 BV bounds    x[3834]
 BV bounds    x[3835]
 BV bounds    x[3836]
 BV bounds    x[3837]
 BV bounds    x[3838]
 BV bounds    x[3839]
 BV bounds    x[3840]
 BV bounds    x[3841]
 BV bounds    x[3842]
 BV bounds    x[3843]
 BV bounds    x[3844]
 BV bounds    x[3845]
 BV bounds    x[3846]
 BV bounds    x[3847]
 BV bounds    x[3848]
 BV bounds    x[3849]
 BV bounds    x[3850]
 BV bounds    x[3851]
 BV bounds    x[3852]
 BV bounds    x[3853]
 BV bounds    x[3854]
 BV bounds    x[3855]
 BV bounds    x[3856]
 BV bounds    x[3857]
 BV bounds    x[3858]
 BV bounds    x[3859]
 BV bounds    x[3860]
 BV bounds    x[3861]
 BV bounds    x[3862]
 BV bounds    x[3863]
 BV bounds    x[3864]
 BV bounds    x[3865]
 BV bounds    x[3866]
 BV bounds    x[3867]
 BV bounds    x[3868]
 BV bounds    x[3869]
 BV bounds    x[3870]
 BV bounds    x[3871]
 FX bounds    x[3872]   0
 FX bounds    x[3873]   0
 FX bounds    x[3874]   0
 FX bounds    x[3875]   0
 FX bounds    x[3876]   0
 FX bounds    x[3877]   0
 FX bounds    x[3878]   0
 FX bounds    x[3879]   0
 FX bounds    x[3880]   0
 FX bounds    x[3881]   0
 FX bounds    x[3882]   0
 FX bounds    x[3883]   0
 FX bounds    x[3884]   0
 FX bounds    x[3885]   0
 FX bounds    x[3886]   0
 FX bounds    x[3887]   0
 FX bounds    x[3888]   0
 BV bounds    x[3889]
 BV bounds    x[3890]
 BV bounds    x[3891]
 BV bounds    x[3892]
 BV bounds    x[3893]
 BV bounds    x[3894]
 BV bounds    x[3895]
 BV bounds    x[3896]
 BV bounds    x[3897]
 BV bounds    x[3898]
 BV bounds    x[3899]
 BV bounds    x[3900]
 BV bounds    x[3901]
 BV bounds    x[3902]
 BV bounds    x[3903]
 BV bounds    x[3904]
 BV bounds    x[3905]
 BV bounds    x[3906]
 BV bounds    x[3907]
 BV bounds    x[3908]
 BV bounds    x[3909]
 BV bounds    x[3910]
 BV bounds    x[3911]
 BV bounds    x[3912]
 BV bounds    x[3913]
 BV bounds    x[3914]
 BV bounds    x[3915]
 BV bounds    x[3916]
 BV bounds    x[3917]
 BV bounds    x[3918]
 BV bounds    x[3919]
 BV bounds    x[3920]
 BV bounds    x[3921]
 BV bounds    x[3922]
 BV bounds    x[3923]
 BV bounds    x[3924]
 BV bounds    x[3925]
 BV bounds    x[3926]
 BV bounds    x[3927]
 BV bounds    x[3928]
 BV bounds    x[3929]
 BV bounds    x[3930]
 BV bounds    x[3931]
 BV bounds    x[3932]
 BV bounds    x[3933]
 BV bounds    x[3934]
 BV bounds    x[3935]
 BV bounds    x[3936]
 BV bounds    x[3937]
 BV bounds    x[3938]
 BV bounds    x[3939]
 BV bounds    x[3940]
 BV bounds    x[3941]
 BV bounds    x[3942]
 BV bounds    x[3943]
 BV bounds    x[3944]
 BV bounds    x[3945]
 BV bounds    x[3946]
 BV bounds    x[3947]
 BV bounds    x[3948]
 BV bounds    x[3949]
 BV bounds    x[3950]
 BV bounds    x[3951]
 BV bounds    x[3952]
 BV bounds    x[3953]
 BV bounds    x[3954]
 BV bounds    x[3955]
 BV bounds    x[3956]
 BV bounds    x[3957]
 BV bounds    x[3958]
 BV bounds    x[3959]
 BV bounds    x[3960]
 BV bounds    x[3961]
 FX bounds    x[3962]   0
 FX bounds    x[3963]   0
 FX bounds    x[3964]   0
 FX bounds    x[3965]   0
 FX bounds    x[3966]   0
 FX bounds    x[3967]   0
 FX bounds    x[3968]   0
 FX bounds    x[3969]   0
 FX bounds    x[3970]   0
 FX bounds    x[3971]   0
 FX bounds    x[3972]   0
 FX bounds    x[3973]   0
 FX bounds    x[3974]   0
 FX bounds    x[3975]   0
 FX bounds    x[3976]   0
 FX bounds    x[3977]   0
 FX bounds    x[3978]   0
 BV bounds    x[3979]
 BV bounds    x[3980]
 BV bounds    x[3981]
 BV bounds    x[3982]
 BV bounds    x[3983]
 BV bounds    x[3984]
 BV bounds    x[3985]
 BV bounds    x[3986]
 BV bounds    x[3987]
 BV bounds    x[3988]
 BV bounds    x[3989]
 BV bounds    x[3990]
 BV bounds    x[3991]
 BV bounds    x[3992]
 BV bounds    x[3993]
 BV bounds    x[3994]
 BV bounds    x[3995]
 BV bounds    x[3996]
 BV bounds    x[3997]
 BV bounds    x[3998]
 BV bounds    x[3999]
 BV bounds    x[4000]
 BV bounds    x[4001]
 BV bounds    x[4002]
 BV bounds    x[4003]
 BV bounds    x[4004]
 BV bounds    x[4005]
 BV bounds    x[4006]
 BV bounds    x[4007]
 BV bounds    x[4008]
 BV bounds    x[4009]
 BV bounds    x[4010]
 BV bounds    x[4011]
 BV bounds    x[4012]
 BV bounds    x[4013]
 BV bounds    x[4014]
 BV bounds    x[4015]
 BV bounds    x[4016]
 BV bounds    x[4017]
 BV bounds    x[4018]
 BV bounds    x[4019]
 BV bounds    x[4020]
 BV bounds    x[4021]
 BV bounds    x[4022]
 BV bounds    x[4023]
 BV bounds    x[4024]
 BV bounds    x[4025]
 BV bounds    x[4026]
 BV bounds    x[4027]
 BV bounds    x[4028]
 BV bounds    x[4029]
 BV bounds    x[4030]
 BV bounds    x[4031]
 BV bounds    x[4032]
 BV bounds    x[4033]
 BV bounds    x[4034]
 BV bounds    x[4035]
 BV bounds    x[4036]
 BV bounds    x[4037]
 BV bounds    x[4038]
 BV bounds    x[4039]
 BV bounds    x[4040]
 BV bounds    x[4041]
 BV bounds    x[4042]
 BV bounds    x[4043]
 BV bounds    x[4044]
 BV bounds    x[4045]
 BV bounds    x[4046]
 BV bounds    x[4047]
 BV bounds    x[4048]
 BV bounds    x[4049]
 BV bounds    x[4050]
 BV bounds    x[4051]
 BV bounds    x[4052]
 BV bounds    x[4053]
 BV bounds    x[4054]
 BV bounds    x[4055]
 BV bounds    x[4056]
 FX bounds    x[4057]   1
 LO bounds    x[4058]   0
 UP bounds    x[4058]   1920
 LO bounds    x[4059]   0
 UP bounds    x[4059]   1920
 LO bounds    x[4060]   0
 UP bounds    x[4060]   3538
 BV bounds    x[4061]
 BV bounds    x[4062]
 BV bounds    x[4063]
 BV bounds    x[4064]
 BV bounds    x[4065]
 FX bounds    x[4066]   1
 LO bounds    x[4067]   0
 UP bounds    x[4067]   1920
 LO bounds    x[4068]   0
 UP bounds    x[4068]   1920
 LO bounds    x[4069]   0
 UP bounds    x[4069]   2523
 BV bounds    x[4070]
 BV bounds    x[4071]
 BV bounds    x[4072]
 BV bounds    x[4073]
 BV bounds    x[4074]
 FX bounds    x[4075]   1
 LO bounds    x[4076]   0
 UP bounds    x[4076]   1920
 LO bounds    x[4077]   0
 UP bounds    x[4077]   1920
 LO bounds    x[4078]   0
 UP bounds    x[4078]   2215
 BV bounds    x[4079]
 BV bounds    x[4080]
 BV bounds    x[4081]
 BV bounds    x[4082]
 BV bounds    x[4083]
 FX bounds    x[4084]   1
 LO bounds    x[4085]   0
 UP bounds    x[4085]   1920
 LO bounds    x[4086]   0
 UP bounds    x[4086]   1920
 LO bounds    x[4087]   0
 UP bounds    x[4087]   2063
 BV bounds    x[4088]
 BV bounds    x[4089]
 BV bounds    x[4090]
 BV bounds    x[4091]
 BV bounds    x[4092]
 FX bounds    x[4093]   1
 LO bounds    x[4094]   0
 UP bounds    x[4094]   1920
 LO bounds    x[4095]   0
 UP bounds    x[4095]   1920
 LO bounds    x[4096]   0
 UP bounds    x[4096]   3181
 BV bounds    x[4097]
 BV bounds    x[4098]
 BV bounds    x[4099]
 BV bounds    x[4100]
 BV bounds    x[4101]
 FX bounds    x[4102]   1
 LO bounds    x[4103]   0
 UP bounds    x[4103]   1920
 LO bounds    x[4104]   0
 UP bounds    x[4104]   1920
 LO bounds    x[4105]   0
 UP bounds    x[4105]   2472
 BV bounds    x[4106]
 BV bounds    x[4107]
 BV bounds    x[4108]
 BV bounds    x[4109]
 BV bounds    x[4110]
 FX bounds    x[4111]   1
 LO bounds    x[4112]   0
 UP bounds    x[4112]   1920
 LO bounds    x[4113]   0
 UP bounds    x[4113]   1920
 LO bounds    x[4114]   0
 UP bounds    x[4114]   2937
 BV bounds    x[4115]
 BV bounds    x[4116]
 BV bounds    x[4117]
 BV bounds    x[4118]
 BV bounds    x[4119]
 FX bounds    x[4120]   1
 LO bounds    x[4121]   0
 UP bounds    x[4121]   1920
 LO bounds    x[4122]   0
 UP bounds    x[4122]   1920
 LO bounds    x[4123]   0
 UP bounds    x[4123]   3334
 BV bounds    x[4124]
 BV bounds    x[4125]
 BV bounds    x[4126]
 BV bounds    x[4127]
 BV bounds    x[4128]
 FX bounds    x[4129]   1
 LO bounds    x[4130]   0
 UP bounds    x[4130]   1920
 LO bounds    x[4131]   0
 UP bounds    x[4131]   1920
 LO bounds    x[4132]   0
 UP bounds    x[4132]   2879
 BV bounds    x[4133]
 BV bounds    x[4134]
 BV bounds    x[4135]
 BV bounds    x[4136]
 BV bounds    x[4137]
 FX bounds    x[4138]   1
 LO bounds    x[4139]   0
 UP bounds    x[4139]   1920
 LO bounds    x[4140]   0
 UP bounds    x[4140]   1920
 LO bounds    x[4141]   0
 UP bounds    x[4141]   2745
 BV bounds    x[4142]
 BV bounds    x[4143]
 BV bounds    x[4144]
 BV bounds    x[4145]
 BV bounds    x[4146]
 FX bounds    x[4147]   1
 LO bounds    x[4148]   0
 UP bounds    x[4148]   1920
 LO bounds    x[4149]   0
 UP bounds    x[4149]   1920
 LO bounds    x[4150]   0
 UP bounds    x[4150]   3393
 BV bounds    x[4151]
 BV bounds    x[4152]
 BV bounds    x[4153]
 BV bounds    x[4154]
 BV bounds    x[4155]
 FX bounds    x[4156]   1
 LO bounds    x[4157]   0
 UP bounds    x[4157]   1920
 LO bounds    x[4158]   0
 UP bounds    x[4158]   1920
 LO bounds    x[4159]   0
 UP bounds    x[4159]   4095
 BV bounds    x[4160]
 BV bounds    x[4161]
 BV bounds    x[4162]
 BV bounds    x[4163]
 BV bounds    x[4164]
 FX bounds    x[4165]   1
 LO bounds    x[4166]   0
 UP bounds    x[4166]   1920
 LO bounds    x[4167]   0
 UP bounds    x[4167]   1920
 LO bounds    x[4168]   0
 UP bounds    x[4168]   1975
 BV bounds    x[4169]
 BV bounds    x[4170]
 BV bounds    x[4171]
 BV bounds    x[4172]
 BV bounds    x[4173]
 FX bounds    x[4174]   1
 LO bounds    x[4175]   0
 UP bounds    x[4175]   1920
 LO bounds    x[4176]   0
 UP bounds    x[4176]   1920
 LO bounds    x[4177]   0
 UP bounds    x[4177]   3445
 BV bounds    x[4178]
 BV bounds    x[4179]
 BV bounds    x[4180]
 BV bounds    x[4181]
 BV bounds    x[4182]
 FX bounds    x[4183]   1
 LO bounds    x[4184]   0
 UP bounds    x[4184]   1920
 LO bounds    x[4185]   0
 UP bounds    x[4185]   1920
 LO bounds    x[4186]   0
 UP bounds    x[4186]   2543
 BV bounds    x[4187]
 BV bounds    x[4188]
 BV bounds    x[4189]
 BV bounds    x[4190]
 BV bounds    x[4191]
 FX bounds    x[4192]   1
 LO bounds    x[4193]   0
 UP bounds    x[4193]   1920
 LO bounds    x[4194]   0
 UP bounds    x[4194]   1920
 LO bounds    x[4195]   0
 UP bounds    x[4195]   2583
 BV bounds    x[4196]
 BV bounds    x[4197]
 BV bounds    x[4198]
 BV bounds    x[4199]
 BV bounds    x[4200]
 FX bounds    x[4201]   1
 LO bounds    x[4202]   0
 UP bounds    x[4202]   1920
 LO bounds    x[4203]   0
 UP bounds    x[4203]   1920
 LO bounds    x[4204]   0
 UP bounds    x[4204]   2690
 BV bounds    x[4205]
 BV bounds    x[4206]
 BV bounds    x[4207]
 BV bounds    x[4208]
 BV bounds    x[4209]
 FX bounds    x[4210]   1
 LO bounds    x[4211]   0
 UP bounds    x[4211]   1920
 LO bounds    x[4212]   0
 UP bounds    x[4212]   1920
 LO bounds    x[4213]   0
 UP bounds    x[4213]   2398
 BV bounds    x[4214]
 BV bounds    x[4215]
 BV bounds    x[4216]
 BV bounds    x[4217]
 BV bounds    x[4218]
 FX bounds    x[4219]   1
 LO bounds    x[4220]   0
 UP bounds    x[4220]   1920
 LO bounds    x[4221]   0
 UP bounds    x[4221]   1920
 LO bounds    x[4222]   0
 UP bounds    x[4222]   3188
 BV bounds    x[4223]
 BV bounds    x[4224]
 BV bounds    x[4225]
 BV bounds    x[4226]
 BV bounds    x[4227]
 FX bounds    x[4228]   1
 LO bounds    x[4229]   0
 UP bounds    x[4229]   1920
 LO bounds    x[4230]   0
 UP bounds    x[4230]   1920
 LO bounds    x[4231]   0
 UP bounds    x[4231]   2251
 BV bounds    x[4232]
 BV bounds    x[4233]
 BV bounds    x[4234]
 BV bounds    x[4235]
 BV bounds    x[4236]
 FX bounds    x[4237]   1
 LO bounds    x[4238]   0
 UP bounds    x[4238]   1920
 LO bounds    x[4239]   0
 UP bounds    x[4239]   1920
 LO bounds    x[4240]   0
 UP bounds    x[4240]   2798
 BV bounds    x[4241]
 BV bounds    x[4242]
 BV bounds    x[4243]
 BV bounds    x[4244]
 BV bounds    x[4245]
 FX bounds    x[4246]   1
 LO bounds    x[4247]   0
 UP bounds    x[4247]   1920
 LO bounds    x[4248]   0
 UP bounds    x[4248]   1920
 LO bounds    x[4249]   0
 UP bounds    x[4249]   2065
 BV bounds    x[4250]
 BV bounds    x[4251]
 BV bounds    x[4252]
 BV bounds    x[4253]
 BV bounds    x[4254]
 FX bounds    x[4255]   1
 LO bounds    x[4256]   0
 UP bounds    x[4256]   1920
 LO bounds    x[4257]   0
 UP bounds    x[4257]   1920
 LO bounds    x[4258]   0
 UP bounds    x[4258]   2580
 BV bounds    x[4259]
 BV bounds    x[4260]
 BV bounds    x[4261]
 BV bounds    x[4262]
 BV bounds    x[4263]
 FX bounds    x[4264]   1
 LO bounds    x[4265]   0
 UP bounds    x[4265]   1920
 LO bounds    x[4266]   0
 UP bounds    x[4266]   1920
 LO bounds    x[4267]   0
 UP bounds    x[4267]   2061
 BV bounds    x[4268]
 BV bounds    x[4269]
 BV bounds    x[4270]
 BV bounds    x[4271]
 BV bounds    x[4272]
 FX bounds    x[4273]   1
 LO bounds    x[4274]   0
 UP bounds    x[4274]   1920
 LO bounds    x[4275]   0
 UP bounds    x[4275]   1920
 LO bounds    x[4276]   0
 UP bounds    x[4276]   2856
 BV bounds    x[4277]
 BV bounds    x[4278]
 BV bounds    x[4279]
 BV bounds    x[4280]
 BV bounds    x[4281]
 FX bounds    x[4282]   1
 LO bounds    x[4283]   0
 UP bounds    x[4283]   1920
 LO bounds    x[4284]   0
 UP bounds    x[4284]   1920
 LO bounds    x[4285]   0
 UP bounds    x[4285]   3220
 BV bounds    x[4286]
 BV bounds    x[4287]
 BV bounds    x[4288]
 BV bounds    x[4289]
 BV bounds    x[4290]
 FX bounds    x[4291]   1
 LO bounds    x[4292]   0
 UP bounds    x[4292]   1920
 LO bounds    x[4293]   0
 UP bounds    x[4293]   1920
 LO bounds    x[4294]   0
 UP bounds    x[4294]   3139
 BV bounds    x[4295]
 BV bounds    x[4296]
 BV bounds    x[4297]
 BV bounds    x[4298]
 BV bounds    x[4299]
 FX bounds    x[4300]   1
 LO bounds    x[4301]   0
 UP bounds    x[4301]   1920
 LO bounds    x[4302]   0
 UP bounds    x[4302]   1920
 LO bounds    x[4303]   0
 UP bounds    x[4303]   3097
 BV bounds    x[4304]
 BV bounds    x[4305]
 BV bounds    x[4306]
 BV bounds    x[4307]
 BV bounds    x[4308]
 FX bounds    x[4309]   1
 LO bounds    x[4310]   0
 UP bounds    x[4310]   1920
 LO bounds    x[4311]   0
 UP bounds    x[4311]   1920
 LO bounds    x[4312]   0
 UP bounds    x[4312]   2896
 BV bounds    x[4313]
 BV bounds    x[4314]
 BV bounds    x[4315]
 BV bounds    x[4316]
 BV bounds    x[4317]
 FX bounds    x[4318]   1
 LO bounds    x[4319]   0
 UP bounds    x[4319]   1920
 LO bounds    x[4320]   0
 UP bounds    x[4320]   1920
 LO bounds    x[4321]   0
 UP bounds    x[4321]   3074
 BV bounds    x[4322]
 BV bounds    x[4323]
 BV bounds    x[4324]
 BV bounds    x[4325]
 BV bounds    x[4326]
 FX bounds    x[4327]   1
 LO bounds    x[4328]   0
 UP bounds    x[4328]   1920
 LO bounds    x[4329]   0
 UP bounds    x[4329]   1920
 LO bounds    x[4330]   0
 UP bounds    x[4330]   3719
 BV bounds    x[4331]
 BV bounds    x[4332]
 BV bounds    x[4333]
 BV bounds    x[4334]
 BV bounds    x[4335]
 FX bounds    x[4336]   1
 LO bounds    x[4337]   0
 UP bounds    x[4337]   1920
 LO bounds    x[4338]   0
 UP bounds    x[4338]   1920
 LO bounds    x[4339]   0
 UP bounds    x[4339]   2902
 BV bounds    x[4340]
 BV bounds    x[4341]
 BV bounds    x[4342]
 BV bounds    x[4343]
 BV bounds    x[4344]
 FX bounds    x[4345]   1
 LO bounds    x[4346]   0
 UP bounds    x[4346]   1920
 LO bounds    x[4347]   0
 UP bounds    x[4347]   1920
 LO bounds    x[4348]   0
 UP bounds    x[4348]   3454
 BV bounds    x[4349]
 BV bounds    x[4350]
 BV bounds    x[4351]
 BV bounds    x[4352]
 BV bounds    x[4353]
 FX bounds    x[4354]   1
 LO bounds    x[4355]   0
 UP bounds    x[4355]   1920
 LO bounds    x[4356]   0
 UP bounds    x[4356]   1920
 LO bounds    x[4357]   0
 UP bounds    x[4357]   3853
 BV bounds    x[4358]
 BV bounds    x[4359]
 BV bounds    x[4360]
 BV bounds    x[4361]
 BV bounds    x[4362]
 FX bounds    x[4363]   1
 LO bounds    x[4364]   0
 UP bounds    x[4364]   1920
 LO bounds    x[4365]   0
 UP bounds    x[4365]   1920
 LO bounds    x[4366]   0
 UP bounds    x[4366]   3388
 BV bounds    x[4367]
 BV bounds    x[4368]
 BV bounds    x[4369]
 BV bounds    x[4370]
 BV bounds    x[4371]
 FX bounds    x[4372]   1
 LO bounds    x[4373]   0
 UP bounds    x[4373]   1920
 LO bounds    x[4374]   0
 UP bounds    x[4374]   1920
 LO bounds    x[4375]   0
 UP bounds    x[4375]   2951
 BV bounds    x[4376]
 BV bounds    x[4377]
 BV bounds    x[4378]
 BV bounds    x[4379]
 BV bounds    x[4380]
 FX bounds    x[4381]   1
 LO bounds    x[4382]   0
 UP bounds    x[4382]   1920
 LO bounds    x[4383]   0
 UP bounds    x[4383]   1920
 LO bounds    x[4384]   0
 UP bounds    x[4384]   1591
 BV bounds    x[4385]
 BV bounds    x[4386]
 BV bounds    x[4387]
 BV bounds    x[4388]
 BV bounds    x[4389]
 FX bounds    x[4390]   1
 LO bounds    x[4391]   0
 UP bounds    x[4391]   1920
 LO bounds    x[4392]   0
 UP bounds    x[4392]   1920
 LO bounds    x[4393]   0
 UP bounds    x[4393]   2885
 BV bounds    x[4394]
 BV bounds    x[4395]
 BV bounds    x[4396]
 BV bounds    x[4397]
 BV bounds    x[4398]
 FX bounds    x[4399]   1
 LO bounds    x[4400]   0
 UP bounds    x[4400]   1920
 LO bounds    x[4401]   0
 UP bounds    x[4401]   1920
 LO bounds    x[4402]   0
 UP bounds    x[4402]   1742
 BV bounds    x[4403]
 BV bounds    x[4404]
 BV bounds    x[4405]
 BV bounds    x[4406]
 BV bounds    x[4407]
 FX bounds    x[4408]   1
 LO bounds    x[4409]   0
 UP bounds    x[4409]   1920
 LO bounds    x[4410]   0
 UP bounds    x[4410]   1920
 LO bounds    x[4411]   0
 UP bounds    x[4411]   2545
 BV bounds    x[4412]
 BV bounds    x[4413]
 BV bounds    x[4414]
 BV bounds    x[4415]
 BV bounds    x[4416]
 FX bounds    x[4417]   1
 LO bounds    x[4418]   0
 UP bounds    x[4418]   1920
 LO bounds    x[4419]   0
 UP bounds    x[4419]   1920
 LO bounds    x[4420]   0
 UP bounds    x[4420]   3625
 BV bounds    x[4421]
 BV bounds    x[4422]
 BV bounds    x[4423]
 BV bounds    x[4424]
 BV bounds    x[4425]
 FX bounds    x[4426]   1
 LO bounds    x[4427]   0
 UP bounds    x[4427]   1920
 LO bounds    x[4428]   0
 UP bounds    x[4428]   1920
 LO bounds    x[4429]   0
 UP bounds    x[4429]   2394
 BV bounds    x[4430]
 BV bounds    x[4431]
 BV bounds    x[4432]
 BV bounds    x[4433]
 BV bounds    x[4434]
 FX bounds    x[4435]   1
 LO bounds    x[4436]   0
 UP bounds    x[4436]   1920
 LO bounds    x[4437]   0
 UP bounds    x[4437]   1920
 LO bounds    x[4438]   0
 UP bounds    x[4438]   3027
 BV bounds    x[4439]
 BV bounds    x[4440]
 BV bounds    x[4441]
 BV bounds    x[4442]
 BV bounds    x[4443]
 FX bounds    x[4444]   1
 LO bounds    x[4445]   0
 UP bounds    x[4445]   1920
 LO bounds    x[4446]   0
 UP bounds    x[4446]   1920
 LO bounds    x[4447]   0
 UP bounds    x[4447]   994
 BV bounds    x[4448]
 BV bounds    x[4449]
 BV bounds    x[4450]
 BV bounds    x[4451]
 BV bounds    x[4452]
 FX bounds    x[4453]   1
 LO bounds    x[4454]   0
 UP bounds    x[4454]   1920
 LO bounds    x[4455]   0
 UP bounds    x[4455]   1920
 LO bounds    x[4456]   0
 UP bounds    x[4456]   3071
ENDATA
