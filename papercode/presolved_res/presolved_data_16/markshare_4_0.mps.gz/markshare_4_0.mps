NAME
ROWS
 N  OBJ
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
COLUMNS
    x[1]      c1        1
    x[1]      OBJ       1
    x[2]      c2        1
    x[2]      OBJ       1
    x[3]      c3        1
    x[3]      OBJ       1
    x[4]      c4        1
    x[4]      OBJ       1
    MARKER    'MARKER'                 'INTORG'
    x[5]      c1        17
    x[5]      c2        93
    x[5]      c3        46
    x[5]      c4        2
    x[6]      c1        75
    x[6]      c2        44
    x[6]      c3        63
    x[6]      c4        77
    x[7]      c1        9
    x[7]      c2        79
    x[7]      c3        13
    x[7]      c4        73
    x[8]      c1        87
    x[8]      c2        12
    x[8]      c3        97
    x[8]      c4        59
    x[9]      c1        58
    x[9]      c2        8
    x[9]      c3        14
    x[9]      c4        43
    x[10]     c1        79
    x[10]     c2        95
    x[10]     c3        45
    x[10]     c4        64
    x[11]     c1        69
    x[11]     c2        2
    x[11]     c3        32
    x[11]     c4        75
    x[12]     c1        37
    x[12]     c2        15
    x[12]     c3        96
    x[12]     c4        6
    x[13]     c1        88
    x[13]     c2        38
    x[13]     c3        36
    x[13]     c4        5
    x[14]     c1        75
    x[14]     c2        15
    x[14]     c3        40
    x[14]     c4        78
    x[15]     c1        45
    x[15]     c2        53
    x[15]     c3        10
    x[15]     c4        71
    x[16]     c1        35
    x[16]     c2        88
    x[16]     c3        96
    x[16]     c4        12
    x[17]     c1        73
    x[17]     c2        43
    x[17]     c3        99
    x[17]     c4        30
    x[18]     c1        26
    x[18]     c2        26
    x[18]     c3        58
    x[18]     c4        7
    x[19]     c1        39
    x[19]     c2        31
    x[19]     c3        87
    x[19]     c4        69
    x[20]     c1        78
    x[20]     c2        77
    x[20]     c3        15
    x[20]     c4        36
    x[21]     c1        85
    x[21]     c2        10
    x[21]     c3        91
    x[21]     c4        73
    x[22]     c1        58
    x[22]     c2        77
    x[22]     c3        65
    x[22]     c4        19
    x[23]     c1        72
    x[23]     c2        71
    x[23]     c3        6
    x[23]     c4        15
    x[24]     c1        8
    x[24]     c2        22
    x[24]     c3        96
    x[24]     c4        16
    x[25]     c1        46
    x[25]     c2        76
    x[25]     c3        97
    x[25]     c4        84
    x[26]     c1        11
    x[26]     c2        41
    x[26]     c3        79
    x[26]     c4        55
    x[27]     c1        55
    x[27]     c2        65
    x[27]     c3        81
    x[27]     c4        32
    x[28]     c1        39
    x[28]     c2        93
    x[28]     c3        57
    x[28]     c4        53
    x[29]     c1        57
    x[29]     c2        50
    x[29]     c3        28
    x[29]     c4        43
    x[30]     c1        96
    x[30]     c2        69
    x[30]     c3        97
    x[30]     c4        21
    x[31]     c1        87
    x[31]     c2        44
    x[31]     c3        58
    x[31]     c4        73
    x[32]     c1        16
    x[32]     c2        61
    x[32]     c3        44
    x[33]     c1        27
    x[33]     c2        58
    x[33]     c3        37
    x[33]     c4        59
    x[34]     c1        26
    x[34]     c2        63
    x[34]     c3        93
    x[34]     c4        48
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1        786
    rhs       c2        759
    rhs       c3        888
    rhs       c4        649
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
RANGES
BOUNDS
 LO bounds    x[1]      0
 UP bounds    x[1]      786
 LO bounds    x[2]      0
 UP bounds    x[2]      759
 LO bounds    x[3]      0
 UP bounds    x[3]      888
 LO bounds    x[4]      0
 UP bounds    x[4]      649
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
ENDATA
