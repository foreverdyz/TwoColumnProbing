NAME
ROWS
 N  OBJ
 L  c1_1
 L  c2_1
 L  c3_1
 L  c4_1
 L  c5_1
 L  c6_1
 L  c7_1
 L  c8_1
 L  c9_1
 L  c10_1
 L  c11_1
 L  c12_1
 L  c13_1
 L  c14_1
 L  c15_1
 L  c16_1
 L  c17_1
 L  c18_1
 L  c19_1
 L  c20_1
 L  c21_1
 L  c22_1
 L  c23_1
 L  c24_1
 L  c25_1
 L  c26_1
 L  c27_1
 L  c28_1
 L  c29_1
 L  c30_1
 L  c31_1
 L  c32_1
 L  c33_1
 L  c34_1
 L  c35_1
 L  c36_1
 L  c37_1
 L  c38_1
 L  c39_1
 L  c40_1
 L  c41_1
 L  c42_1
 L  c43_1
 L  c44_1
 L  c45_1
 L  c46_1
 L  c47_1
 L  c48_1
 L  c49_1
 L  c50_1
 L  c51_1
 L  c52_1
 L  c53_1
 L  c54_1
 L  c55_1
 L  c56_1
 L  c57_1
 L  c58_1
 L  c59_1
 L  c60_1
 L  c61_1
 L  c62_1
 L  c63_1
 L  c64_1
 L  c65_1
 L  c66_1
 L  c67_1
 L  c68_1
 L  c69_1
 L  c70_1
 L  c71_1
 L  c72_1
 L  c73_1
 L  c74_1
 L  c75_1
 L  c76_1
 L  c77_1
 L  c78_1
 L  c79_1
 L  c80_1
 L  c81_1
 L  c82_1
 L  c83_1
 L  c84_1
 L  c85_1
 L  c86_1
 L  c87_1
 L  c88_1
 L  c89_1
 L  c90_1
 L  c91_1
 L  c92_1
 L  c93_1
 L  c94_1
 L  c95_1
 L  c96_1
 L  c97_1
 L  c98_1
 L  c99_1
 L  c100_1
 L  c101_1
 L  c102_1
 L  c103_1
 L  c104_1
 L  c105_1
 L  c106_1
 L  c107_1
 L  c108_1
 L  c109_1
 L  c110_1
 L  c111_1
 L  c112_1
 L  c113_1
 L  c114_1
 L  c115_1
 L  c116_1
 L  c117_1
 L  c118_1
 L  c119_1
 L  c120_1
 L  c121_1
 L  c122_1
 L  c123_1
 L  c124_1
 L  c125_1
 L  c126_1
 L  c127_1
 L  c128_1
 L  c129_1
 L  c130_1
 L  c131_1
 L  c132_1
 L  c133_1
 L  c134_1
 L  c135_1
 L  c136_1
 L  c137_1
 L  c138_1
 L  c139_1
 L  c140_1
 L  c141_1
 L  c142_1
 L  c143_1
 L  c144_1
 L  c145_1
 L  c146_1
 L  c147_1
 L  c148_1
 L  c149_1
 L  c150_1
 L  c151_1
 L  c152_1
 L  c153_1
 L  c154_1
 L  c155_1
 L  c156_1
 L  c157_1
 L  c158_1
 L  c159_1
 L  c160_1
 L  c161_1
 L  c162_1
 L  c163_1
 L  c164_1
 L  c165_1
 L  c166_1
 L  c167_1
 L  c168_1
 L  c169_1
 L  c170_1
 L  c171_1
 L  c172_1
 L  c173_1
 L  c174_1
 L  c175_1
 L  c176_1
 L  c177_1
 L  c178_1
 L  c179_1
 L  c180_1
 L  c181_1
 L  c182_1
 L  c183_1
 L  c184_1
 L  c185_1
 L  c186_1
 L  c187_1
 L  c188_1
 L  c189_1
 L  c190_1
 L  c191_1
 L  c192_1
 L  c193_1
 L  c194_1
 L  c195_1
 L  c196_1
 L  c197_1
 L  c198_1
 L  c199_1
 L  c200_1
 L  c201_1
 L  c202_1
 L  c203_1
 L  c204_1
 L  c205_1
 L  c206_1
 L  c207_1
 L  c208_1
 L  c209_1
 L  c210_1
 L  c211_1
 L  c212_1
 L  c213_1
 L  c214_1
 L  c215_1
 L  c216_1
 L  c217_1
 L  c218_1
 L  c219_1
 L  c220_1
 L  c221_1
 L  c222_1
 L  c223_1
 L  c224_1
 L  c225_1
 L  c226_1
 L  c227_1
 L  c228_1
 L  c229_1
 L  c230_1
 L  c231_1
 L  c232_1
 L  c233_1
 L  c234_1
 L  c235_1
 L  c236_1
 L  c237_1
 L  c238_1
 L  c239_1
 L  c240_1
 L  c241_1
 L  c242_1
 L  c243_1
 L  c244_1
 L  c245_1
 L  c246_1
 L  c247_1
 L  c248_1
 L  c249_1
 L  c250_1
 L  c251_1
 L  c252_1
 L  c253_1
 L  c254_1
 L  c255_1
 L  c256_1
 L  c257_1
 L  c258_1
 L  c259_1
 L  c260_1
 L  c261_1
 L  c262_1
 L  c263_1
 L  c264_1
 L  c265_1
 L  c266_1
 L  c267_1
 L  c268_1
 L  c269_1
 L  c270_1
 L  c271_1
 L  c272_1
 L  c273_1
 L  c274_1
 L  c275_1
 L  c276_1
 L  c277_1
 L  c278_1
 L  c279_1
 L  c280_1
 L  c281_1
 L  c282_1
 L  c283_1
 L  c284_1
 L  c285_1
 L  c286_1
 L  c287_1
 L  c288_1
 L  c289_1
 L  c290_1
 L  c291_1
 L  c292_1
 L  c293_1
 L  c294_1
 L  c295_1
 L  c296_1
 L  c297_1
 L  c298_1
 L  c299_1
 L  c300_1
 L  c301_1
 L  c302_1
 L  c303_1
 L  c304_1
 L  c305_1
 L  c306_1
 L  c307_1
 L  c308_1
 L  c309_1
 L  c310_1
 L  c311_1
 L  c312_1
 L  c313_1
 L  c314_1
 L  c315_1
 L  c316_1
 L  c317_1
 L  c318_1
 L  c319_1
 L  c320_1
 L  c321_1
 L  c322_1
 L  c323_1
 L  c324_1
 L  c325_1
 L  c326_1
 L  c327_1
 L  c328_1
 L  c329_1
 L  c330_1
 L  c331_1
 L  c332_1
 L  c333_1
 L  c334_1
 L  c335_1
 L  c336_1
 L  c337_1
 L  c338_1
 L  c339_1
 L  c340_1
 L  c341_1
 L  c342_1
 L  c343_1
 L  c344_1
 L  c345_1
 L  c346_1
 L  c347_1
 L  c348_1
 L  c349_1
 L  c350_1
 L  c351_1
 L  c352_1
 L  c353_1
 L  c354_1
 L  c355_1
 L  c356_1
 L  c357_1
 L  c358_1
 L  c359_1
 L  c360_1
 L  c361_1
 L  c362_1
 L  c363_1
 L  c364_1
 L  c365_1
 L  c366_1
 L  c367_1
 L  c368_1
 L  c369_1
 L  c370_1
 L  c371_1
 L  c372_1
 L  c373_1
 L  c374_1
 L  c375_1
 L  c376_1
 L  c377_1
 L  c378_1
 L  c379_1
 L  c380_1
 L  c381_1
 L  c382_1
 L  c383_1
 L  c384_1
 L  c385_1
 L  c386_1
 L  c387_1
 L  c388_1
 L  c389_1
 L  c390_1
 L  c391_1
 L  c392_1
 L  c393_1
 L  c394_1
 L  c395_1
 L  c396_1
 L  c397_1
 L  c398_1
 L  c399_1
 L  c400_1
 L  c401_1
 L  c402_1
 L  c403_1
 L  c404_1
 L  c405_1
 L  c406_1
 L  c407_1
 L  c408_1
 L  c409_1
 L  c410_1
 L  c411_1
 L  c412_1
 L  c413_1
 L  c414_1
 L  c415_1
 L  c416_1
 L  c417_1
 L  c418_1
 L  c419_1
 L  c420_1
 L  c421_1
 L  c422_1
 L  c423_1
 L  c424_1
 L  c425_1
 L  c426_1
 L  c427_1
 L  c428_1
 L  c429_1
 L  c430_1
 L  c431_1
 L  c432_1
 L  c433_1
 L  c434_1
 L  c435_1
 L  c436_1
 L  c437_1
 L  c438_1
 L  c439_1
 L  c440_1
 L  c441_1
 L  c442_1
 L  c443_1
 L  c444_1
 L  c445_1
 L  c446_1
 L  c447_1
 L  c448_1
 L  c449_1
 L  c450_1
 L  c451_1
 L  c452_1
 L  c453_1
 L  c454_1
 L  c455_1
 L  c456_1
 L  c457_1
 L  c458_1
 L  c459_1
 L  c460_1
 L  c461_1
 L  c462_1
 L  c463_1
 L  c464_1
 L  c465_1
 L  c466_1
 L  c467_1
 L  c468_1
 L  c469_1
 L  c470_1
 L  c471_1
 L  c472_1
 L  c473_1
 L  c474_1
 L  c475_1
 L  c476_1
 L  c477_1
 L  c478_1
 L  c479_1
 L  c480_1
 L  c481_1
 L  c482_1
 L  c483_1
 L  c484_1
 L  c485_1
 L  c486_1
 L  c487_1
 L  c488_1
 L  c489_1
 L  c490_1
 L  c491_1
 L  c492_1
 L  c493_1
 L  c494_1
 L  c495_1
 L  c496_1
 L  c497_1
 L  c498_1
 L  c499_1
 L  c500_1
 L  c501_1
 L  c502_1
 L  c503_1
 L  c504_1
 L  c505_1
 L  c506_1
 L  c507_1
 L  c508_1
 L  c509_1
 L  c510_1
 L  c511_1
 L  c512_1
 L  c513_1
 L  c514_1
 L  c515_1
 L  c516_1
 L  c517_1
 L  c518_1
 L  c519_1
 L  c520_1
 L  c521_1
 L  c522_1
 L  c523_1
 L  c524_1
 L  c525_1
 L  c526_1
 L  c527_1
 L  c528_1
 L  c529_1
 L  c530_1
 L  c531_1
 L  c532_1
 L  c533_1
 L  c534_1
 L  c535_1
 L  c536_1
 L  c537_1
 L  c538_1
 L  c539_1
 L  c540_1
 L  c541_1
 L  c542_1
 L  c543_1
 L  c544_1
 L  c545_1
 L  c546_1
 L  c547_1
 L  c548_1
 L  c549_1
 L  c550_1
 L  c551_1
 L  c552_1
 L  c553_1
 L  c554_1
 L  c555_1
 L  c556_1
 L  c557_1
 L  c558_1
 L  c559_1
 L  c560_1
 L  c561_1
 L  c562_1
 L  c563_1
 L  c564_1
 L  c565_1
 L  c566_1
 L  c567_1
 L  c568_1
 L  c569_1
 L  c570_1
 L  c571_1
 L  c572_1
 L  c573_1
 L  c574_1
 L  c575_1
 L  c576_1
 L  c577_1
 L  c578_1
 L  c579_1
 L  c580_1
 L  c581_1
 L  c582_1
 L  c583_1
 L  c584_1
 L  c585_1
 L  c586_1
 L  c587_1
 L  c588_1
 L  c589_1
 L  c590_1
 L  c591_1
 L  c592_1
 L  c593_1
 L  c594_1
 L  c595_1
 L  c596_1
 L  c597_1
 L  c598_1
 L  c599_1
 L  c600_1
 L  c601_1
 L  c602_1
 L  c603_1
 L  c604_1
 L  c605_1
 L  c606_1
 L  c607_1
 L  c608_1
 L  c609_1
 L  c610_1
 L  c611_1
 L  c612_1
 L  c613_1
 L  c614_1
 L  c615_1
 L  c616_1
 L  c617_1
 L  c618_1
 L  c619_1
 L  c620_1
 L  c621_1
 L  c622_1
 L  c623_1
 L  c624_1
 L  c625_1
 L  c626_1
 L  c627_1
 L  c628_1
 L  c629_1
 L  c630_1
 L  c631_1
 L  c632_1
 L  c633_1
 L  c634_1
 L  c635_1
 L  c636_1
 L  c637_1
 L  c638_1
 L  c639_1
 L  c640_1
 L  c641_1
 L  c642_1
 L  c643_1
 L  c644_1
 L  c645_1
 L  c646_1
 L  c647_1
 L  c648_1
 L  c649_1
 L  c650_1
 L  c651_1
 L  c652_1
 L  c653_1
 L  c654_1
 L  c655_1
 L  c656_1
 L  c657_1
 L  c658_1
 L  c659_1
 L  c660_1
 L  c661_1
 L  c662_1
 L  c663_1
 L  c664_1
 L  c665_1
 L  c666_1
 L  c667_1
 L  c668_1
 L  c669_1
 L  c670_1
 L  c671_1
 L  c672_1
 L  c673_1
 L  c674_1
 L  c675_1
 L  c676_1
 L  c677_1
 L  c678_1
 L  c679_1
 L  c680_1
 L  c681_1
 L  c682_1
 L  c683_1
 L  c684_1
 L  c685_1
 L  c686_1
 L  c687_1
 L  c688_1
 L  c689_1
 L  c690_1
 L  c691_1
 L  c692_1
 L  c693_1
 L  c694_1
 L  c695_1
 L  c696_1
 L  c697_1
 L  c698_1
 L  c699_1
 L  c700_1
 L  c701_1
 L  c702_1
 L  c703_1
 L  c704_1
 L  c705_1
 L  c706_1
 L  c707_1
 L  c708_1
 L  c709_1
 L  c710_1
 L  c711_1
 L  c712_1
 L  c713_1
 L  c714_1
 L  c715_1
 L  c716_1
 L  c717_1
 L  c718_1
 L  c719_1
 L  c720_1
 L  c721_1
 L  c722_1
 L  c723_1
 L  c724_1
 L  c725_1
 L  c726_1
 L  c727_1
 L  c728_1
 L  c729_1
 L  c730_1
 L  c731_1
 L  c732_1
 L  c733_1
 L  c734_1
 L  c735_1
 L  c736_1
 L  c737_1
 L  c738_1
 L  c739_1
 L  c740_1
 L  c741_1
 L  c742_1
 L  c743_1
 L  c744_1
 L  c745_1
 L  c746_1
 L  c747_1
 L  c748_1
 L  c749_1
 L  c750_1
 L  c751_1
 L  c752_1
 L  c753_1
 L  c754_1
 L  c755_1
 L  c756_1
 L  c757_1
 L  c758_1
 L  c759_1
 L  c760_1
 L  c761_1
 L  c762_1
 L  c763_1
 L  c764_1
 L  c765_1
 L  c766_1
 L  c767_1
 L  c768_1
 L  c769_1
 L  c770_1
 L  c771_1
 L  c772_1
 L  c773_1
 L  c774_1
 L  c775_1
 L  c776_1
 L  c777_1
 L  c778_1
 L  c779_1
 L  c780_1
 L  c781_1
 L  c782_1
 L  c783_1
 L  c784_1
 L  c785_1
 L  c786_1
 L  c787_1
 L  c788_1
 L  c789_1
 L  c790_1
 L  c791_1
 L  c792_1
 L  c793_1
 L  c794_1
 L  c795_1
 L  c796_1
 L  c797_1
 L  c798_1
 L  c799_1
 L  c800_1
 L  c801_1
 L  c802_1
 L  c803_1
 L  c804_1
 L  c805_1
 L  c806_1
 L  c807_1
 L  c808_1
 L  c809_1
 L  c810_1
 L  c811_1
 L  c812_1
 L  c813_1
 L  c814_1
 L  c815_1
 L  c816_1
 L  c817_1
 L  c818_1
 L  c819_1
 L  c820_1
 L  c821_1
 L  c822_1
 L  c823_1
 L  c824_1
 L  c825_1
 L  c826_1
 L  c827_1
 L  c828_1
 L  c829_1
 L  c830_1
 L  c831_1
 L  c832_1
 L  c833_1
 L  c834_1
 L  c835_1
 L  c836_1
 L  c837_1
 L  c838_1
 L  c839_1
 L  c840_1
 L  c841_1
 L  c842_1
 L  c843_1
 L  c844_1
 L  c845_1
 L  c846_1
 L  c847_1
 L  c848_1
 L  c849_1
 L  c850_1
 L  c851_1
 L  c852_1
 L  c853_1
 L  c854_1
 L  c855_1
 L  c856_1
 L  c857_1
 L  c858_1
 L  c859_1
 L  c860_1
 L  c861_1
 L  c862_1
 L  c863_1
 L  c864_1
 L  c865_1
 L  c866_1
 L  c867_1
 L  c868_1
 L  c869_1
 L  c870_1
 L  c871_1
 L  c872_1
 L  c873_1
 L  c874_1
 L  c875_1
 L  c876_1
 L  c877_1
 L  c878_1
 L  c879_1
 L  c880_1
 L  c881_1
 L  c882_1
 L  c883_1
 L  c884_1
 L  c885_1
 L  c886_1
 L  c887_1
 L  c888_1
 L  c889_1
 L  c890_1
 L  c891_1
 L  c892_1
 L  c893_1
 L  c894_1
 L  c895_1
 L  c896_1
 L  c897_1
 L  c898_1
 L  c899_1
 L  c900_1
 L  c901_1
 L  c902_1
 L  c903_1
 L  c904_1
 L  c905_1
 L  c906_1
 L  c907_1
 L  c908_1
 L  c909_1
 L  c910_1
 L  c911_1
 L  c912_1
 L  c913_1
 L  c914_1
 L  c915_1
 L  c916_1
 L  c917_1
 L  c918_1
 L  c919_1
 L  c920_1
 L  c921_1
 L  c922_1
 L  c923_1
 L  c924_1
 L  c925_1
 L  c926_1
 L  c927_1
 L  c928_1
 L  c929_1
 L  c930_1
 L  c931_1
 L  c932_1
 L  c933_1
 L  c934_1
 L  c935_1
 L  c936_1
 L  c937_1
 L  c938_1
 L  c939_1
 L  c940_1
 L  c941_1
 L  c942_1
 L  c943_1
 L  c944_1
 L  c945_1
 L  c946_1
 L  c947_1
 L  c948_1
 L  c949_1
 L  c950_1
 L  c951_1
 L  c952_1
 L  c953_1
 L  c954_1
 L  c955_1
 L  c956_1
 L  c957_1
 L  c958_1
 L  c959_1
 L  c960_1
 L  c961_1
 L  c962_1
 L  c963_1
 L  c964_1
 L  c965_1
 L  c966_1
 L  c967_1
 L  c968_1
 L  c969_1
 L  c970_1
 L  c971_1
 L  c972_1
 L  c973_1
 L  c974_1
 L  c975_1
 L  c976_1
 L  c977_1
 L  c978_1
 L  c979_1
 L  c980_1
 L  c981_1
 L  c982_1
 L  c983_1
 L  c984_1
 L  c985_1
 L  c986_1
 L  c987_1
 L  c988_1
 L  c989_1
 L  c990_1
 L  c991_1
 L  c992_1
 L  c993_1
 L  c994_1
 L  c995_1
 L  c996_1
 L  c997_1
 L  c998_1
 L  c999_1
 L  c1000_1
 L  c1001_1
 L  c1002_1
 L  c1003_1
 L  c1004_1
 L  c1005_1
 L  c1006_1
 L  c1007_1
 L  c1008_1
 L  c1009_1
 L  c1010_1
 L  c1011_1
 L  c1012_1
 L  c1013_1
 L  c1014_1
 L  c1015_1
 L  c1016_1
 L  c1017_1
 L  c1018_1
 L  c1019_1
 L  c1020_1
 L  c1021_1
 L  c1022_1
 L  c1023_1
 L  c1024_1
 L  c1025_1
 L  c1026_1
 L  c1027_1
 L  c1028_1
 L  c1029_1
 L  c1030_1
 L  c1031_1
 L  c1032_1
 L  c1033_1
 L  c1034_1
 L  c1035_1
 L  c1036_1
 L  c1037_1
 L  c1038_1
 L  c1039_1
 L  c1040_1
 L  c1041_1
 L  c1042_1
 L  c1043_1
 L  c1044_1
 L  c1045_1
 L  c1046_1
 L  c1047_1
 L  c1048_1
 L  c1049_1
 L  c1050_1
 L  c1051_1
 L  c1052_1
 L  c1053_1
 L  c1054_1
 L  c1055_1
 L  c1056_1
 L  c1057_1
 L  c1058_1
 L  c1059_1
 L  c1060_1
 L  c1061_1
 L  c1062_1
 L  c1063_1
 L  c1064_1
 L  c1065_1
 L  c1066_1
 L  c1067_1
 L  c1068_1
 L  c1069_1
 L  c1070_1
 L  c1071_1
 L  c1072_1
 L  c1073_1
 L  c1074_1
 L  c1075_1
 L  c1076_1
 L  c1077_1
 L  c1078_1
 L  c1079_1
 L  c1080_1
 L  c1081_1
 L  c1082_1
 L  c1083_1
 L  c1084_1
 L  c1085_1
 L  c1086_1
 L  c1087_1
 L  c1088_1
 L  c1089_1
 L  c1090_1
 L  c1091_1
 L  c1092_1
 L  c1093_1
 L  c1094_1
 L  c1095_1
 L  c1096_1
 L  c1097_1
 L  c1098_1
 L  c1099_1
 L  c1100_1
 L  c1101_1
 L  c1102_1
 L  c1103_1
 L  c1104_1
 L  c1105_1
 L  c1106_1
 L  c1107_1
 L  c1108_1
 L  c1109_1
 L  c1110_1
 L  c1111_1
 L  c1112_1
 L  c1113_1
 L  c1114_1
 L  c1115_1
 L  c1116_1
 L  c1117_1
 L  c1118_1
 L  c1119_1
 L  c1120_1
 L  c1121_1
 L  c1122_1
 L  c1123_1
 L  c1124_1
 L  c1125_1
 L  c1126_1
 L  c1127_1
 L  c1128_1
 L  c1129_1
 L  c1130_1
 L  c1131_1
 L  c1132_1
 L  c1133_1
 L  c1134_1
 L  c1135_1
 L  c1136_1
 L  c1137_1
 L  c1138_1
 L  c1139_1
 L  c1140_1
 L  c1141_1
 L  c1142_1
 L  c1143_1
 L  c1144_1
 L  c1145_1
 L  c1146_1
 L  c1147_1
 L  c1148_1
 L  c1149_1
 L  c1150_1
 L  c1151_1
 L  c1152_1
 L  c1153_1
 L  c1154_1
 L  c1155_1
 L  c1156_1
 L  c1157_1
 L  c1158_1
 L  c1159_1
 L  c1160_1
 L  c1161_1
 L  c1162_1
 L  c1163_1
 L  c1164_1
 L  c1165_1
 L  c1166_1
 L  c1167_1
 L  c1168_1
 L  c1169_1
 L  c1170_1
 L  c1171_1
 L  c1172_1
 L  c1173_1
 L  c1174_1
 L  c1175_1
 L  c1176_1
 L  c1177_1
 L  c1178_1
 L  c1179_1
 L  c1180_1
 L  c1181_1
 L  c1182_1
 L  c1183_1
 L  c1184_1
 L  c1185_1
 L  c1186_1
 L  c1187_1
 L  c1188_1
 L  c1189_1
 L  c1190_1
 L  c1191_1
 L  c1192_1
 L  c1193_1
 L  c1194_1
 L  c1195_1
 L  c1196_1
 L  c1197_1
 L  c1198_1
 L  c1199_1
 L  c1200_1
 L  c1201_1
 L  c1202_1
 L  c1203_1
 L  c1204_1
 L  c1205_1
 L  c1206_1
 L  c1207_1
 L  c1208_1
 L  c1209_1
 L  c1210_1
 L  c1211_1
 L  c1212_1
 L  c1213_1
 L  c1214_1
 L  c1215_1
 L  c1216_1
 L  c1217_1
 L  c1218_1
 L  c1219_1
 L  c1220_1
 L  c1221_1
 L  c1222_1
 L  c1223_1
 L  c1224_1
 L  c1225_1
 L  c1226_1
 L  c1227_1
 L  c1228_1
 L  c1229_1
 L  c1230_1
 L  c1231_1
 L  c1232_1
 L  c1233_1
 L  c1234_1
 L  c1235_1
 L  c1236_1
 L  c1237_1
 L  c1238_1
 L  c1239_1
 L  c1240_1
 L  c1241_1
 L  c1242_1
 L  c1243_1
 L  c1244_1
 L  c1245_1
 L  c1246_1
 L  c1247_1
 L  c1248_1
 L  c1249_1
 L  c1250_1
 L  c1251_1
 L  c1252_1
 L  c1253_1
 L  c1254_1
 L  c1255_1
 L  c1256_1
 L  c1257_1
 L  c1258_1
 L  c1259_1
 L  c1260_1
 L  c1261_1
 L  c1262_1
 L  c1263_1
 L  c1264_1
 L  c1265_1
 L  c1266_1
 L  c1267_1
 L  c1268_1
 L  c1269_1
 L  c1270_1
 L  c1271_1
 L  c1272_1
 L  c1273_1
 L  c1274_1
 L  c1275_1
 L  c1276_1
 L  c1277_1
 L  c1278_1
 L  c1279_1
 L  c1280_1
 L  c1281_1
 L  c1282_1
 L  c1283_1
 L  c1284_1
 L  c1285_1
 L  c1286_1
 L  c1287_1
 L  c1288_1
 L  c1289_1
 L  c1290_1
 L  c1291_1
 L  c1292_1
 L  c1293_1
 L  c1294_1
 L  c1295_1
 L  c1296_1
 L  c1297_1
 L  c1298_1
 L  c1299_1
 L  c1300_1
 L  c1301_1
 L  c1302_1
 L  c1303_1
 L  c1304_1
 L  c1305_1
 L  c1306_1
 L  c1307_1
 L  c1308_1
 L  c1309_1
 L  c1310_1
 L  c1311_1
 L  c1312_1
 L  c1313_1
 L  c1314_1
 L  c1315_1
 L  c1316_1
 L  c1317_1
 L  c1318_1
 L  c1319
 L  c1320
 L  c1321
 L  c1322
 L  c1323
 L  c1324
 L  c1325
 L  c1326
 L  c1327
 L  c1328
 L  c1329
 L  c1330
 L  c1331
 L  c1332
 L  c1333
 L  c1334
 L  c1335
 L  c1336
 L  c1337
 L  c1338
 L  c1339
 L  c1340
 L  c1341
 L  c1342
 L  c1343
 L  c1344
 L  c1345
 L  c1346
 L  c1347
 L  c1348
 L  c1349
 L  c1350
 L  c1351
 L  c1352
 L  c1353
 L  c1354
 L  c1355
 L  c1356
 L  c1357
 L  c1358
 L  c1359
 L  c1360
 L  c1361
 L  c1362
 L  c1363
 L  c1364
 L  c1365
 L  c1366
 L  c1367
 L  c1368
 L  c1369
 L  c1370
 L  c1371
 L  c1372
 L  c1373
 L  c1374
 L  c1375
 L  c1376
 L  c1377
 L  c1378
 L  c1379
 L  c1380
 L  c1381
 L  c1382
 L  c1383
 L  c1384
 L  c1385
 L  c1386
 L  c1387
 L  c1388
 L  c1389
 L  c1390
 L  c1391
 L  c1392
 L  c1393
 L  c1394
 L  c1395
 L  c1396
 L  c1397
 L  c1398
 L  c1399
 L  c1400
 L  c1401
 L  c1402
 L  c1403
 L  c1404
 L  c1405
 L  c1406
 L  c1407
 L  c1408
 L  c1409
 L  c1410
 L  c1411
 L  c1412
 L  c1413
 L  c1414
 L  c1415
 L  c1416
 L  c1417
 L  c1418
 L  c1419
 L  c1420
 L  c1421
 L  c1422
 L  c1423
 L  c1424
 L  c1425
 L  c1426
 L  c1427
 L  c1428
 L  c1429
 L  c1430
 L  c1431
 L  c1432
 L  c1433
 L  c1434
 L  c1435
 L  c1436
 L  c1437
 L  c1438
 L  c1439
 L  c1440
 L  c1441
 L  c1442
 L  c1443
 L  c1444
 L  c1445
 L  c1446
 L  c1447
 L  c1448
 L  c1449
 L  c1450
 L  c1451
 L  c1452
 L  c1453
 L  c1454
 L  c1455
 L  c1456
 L  c1457
 L  c1458
 L  c1459
 L  c1460
 L  c1461
 L  c1462
 L  c1463
 L  c1464
 L  c1465
 L  c1466
 L  c1467
 L  c1468
 L  c1469
 L  c1470
 L  c1471
 L  c1472
 L  c1473
 L  c1474
 L  c1475
 L  c1476
 L  c1477
 L  c1478
 L  c1479
 L  c1480
 L  c1481
 L  c1482
 L  c1483
 L  c1484
 L  c1485
 L  c1486
 L  c1487
 L  c1488
 L  c1489
 L  c1490
 L  c1491
 L  c1492
 L  c1493
 L  c1494
 L  c1495
 L  c1496
 L  c1497
 L  c1498
 L  c1499
 L  c1500
 L  c1501
 L  c1502
 L  c1503
 L  c1504
 L  c1505
 L  c1506
 L  c1507
 L  c1508
 L  c1509
 L  c1510
 L  c1511
 L  c1512
 L  c1513
 L  c1514
 L  c1515
 L  c1516
 L  c1517
 L  c1518
 L  c1519
 L  c1520
 L  c1521
 L  c1522
 L  c1523
 L  c1524
 L  c1525
 L  c1526
 L  c1527
 L  c1528
 L  c1529
 L  c1530
 L  c1531
 L  c1532
 L  c1533
 L  c1534
 L  c1535
 L  c1536
 L  c1537
 L  c1538
 L  c1539
 L  c1540
 L  c1541
 L  c1542
 L  c1543
 L  c1544
 L  c1545
 L  c1546
 L  c1547
 L  c1548
 L  c1549
 L  c1550
 L  c1551
 L  c1552
 L  c1553
 L  c1554
 L  c1555
 L  c1556
 L  c1557
 L  c1558
 L  c1559
 L  c1560
 L  c1561
 L  c1562
 L  c1563
 L  c1564
 L  c1565
 L  c1566
 L  c1567
 L  c1568
 L  c1569
 L  c1570
 L  c1571
 L  c1572
 L  c1573
 L  c1574
 L  c1575
 L  c1576
 L  c1577
 L  c1578
 L  c1579
 L  c1580
 L  c1581
 L  c1582
 L  c1583
 L  c1584
 L  c1585
 L  c1586
 L  c1587
 L  c1588
 L  c1589
 L  c1590
 L  c1591
 L  c1592
 L  c1593
 L  c1594
 L  c1595
 L  c1596
 L  c1597
 L  c1598
 L  c1599
 L  c1600
 L  c1601
 L  c1602
 L  c1603
 L  c1604
 L  c1605
 L  c1606
 L  c1607
 L  c1608
 L  c1609
 L  c1610
 L  c1611
 L  c1612
 L  c1613
 L  c1614
 L  c1615
 L  c1616
 L  c1617
 L  c1618
 L  c1619
 L  c1620
 L  c1621
 L  c1622
 L  c1623
 L  c1624
 L  c1625
 L  c1626
 L  c1627
 L  c1628
 L  c1629
 L  c1630
 L  c1631
 L  c1632
 L  c1633
 L  c1634
 L  c1635
 L  c1636
 L  c1637
 L  c1638
 L  c1639
 L  c1640
 L  c1641
 L  c1642
 L  c1643
 L  c1644
 L  c1645
 L  c1646
 L  c1647
 L  c1648
 L  c1649
 L  c1650
 L  c1651
 L  c1652
 L  c1653
 L  c1654
 L  c1655
 L  c1656
 L  c1657
 L  c1658
 L  c1659
 L  c1660
 L  c1661
 L  c1662
 L  c1663
 L  c1664
 L  c1665
 L  c1666
 L  c1667
 L  c1668
 L  c1669
 L  c1670
 L  c1671
 L  c1672
 L  c1673
 L  c1674
 L  c1675
 L  c1676
 L  c1677
 L  c1678
 L  c1679
 L  c1680
 L  c1681
 L  c1682
 L  c1683
 L  c1684
 L  c1685
 L  c1686
 L  c1687
 L  c1688
 L  c1689
 L  c1690
 L  c1691
 L  c1692
 L  c1693
 L  c1694
 L  c1695
 L  c1696
 L  c1697
 L  c1698
 L  c1699
 L  c1700
 L  c1701
 L  c1702
 L  c1703
 L  c1704
 L  c1705
 L  c1706
 L  c1707
 L  c1708
 L  c1709
 L  c1710
 L  c1711
 L  c1712
 L  c1713
 L  c1714
 L  c1715
 L  c1716
 L  c1717
 L  c1718
 L  c1719
 L  c1720
 L  c1721
 L  c1722
 L  c1723
 L  c1724
 L  c1725
 L  c1726
 L  c1727
 L  c1728
 L  c1729
 L  c1730
 L  c1731
 L  c1732
 L  c1733
 L  c1734
 L  c1735
 L  c1736
 L  c1737
 L  c1738
 L  c1739
 L  c1740
 L  c1741
 L  c1742
 L  c1743
 L  c1744
 L  c1745
 L  c1746
 L  c1747
 L  c1748
 L  c1749
 L  c1750
 L  c1751
 L  c1752
 L  c1753
 L  c1754
 L  c1755
 L  c1756
 L  c1757
 L  c1758
 L  c1759
 L  c1760
 L  c1761
 L  c1762
 L  c1763
 L  c1764
 L  c1765
 L  c1766
 L  c1767
 L  c1768
 L  c1769
 L  c1770
 L  c1771
 L  c1772
 L  c1773
 L  c1774
 L  c1775
 L  c1776
 L  c1777
 L  c1778
 L  c1779
 L  c1780
 L  c1781
 L  c1782
 L  c1783
 L  c1784
 L  c1785
 L  c1786
 L  c1787
 L  c1788
 L  c1789
 L  c1790
 L  c1791
 L  c1792
 L  c1793
 L  c1794
 L  c1795
 L  c1796
 L  c1797
 L  c1798
 L  c1799
 L  c1800
 L  c1801
 L  c1802
 L  c1803
 L  c1804
 L  c1805
 L  c1806
 L  c1807
 L  c1808
 L  c1809
 L  c1810
 L  c1811
 L  c1812
 L  c1813
 L  c1814
 L  c1815
 L  c1816
 L  c1817
 L  c1818
 L  c1819
 L  c1820
 L  c1821
 L  c1822
 L  c1823
 L  c1824
 L  c1825
 L  c1826
 L  c1827
 L  c1828
 L  c1829
 L  c1830
 L  c1831
 L  c1832
 L  c1833
 L  c1834
 L  c1835
 L  c1836
 L  c1837
 L  c1838
 L  c1839
 L  c1840
 L  c1841
 L  c1842
 L  c1843
 L  c1844
 L  c1845
 L  c1846
 L  c1847
 L  c1848
 L  c1849
 L  c1850
 L  c1851
 L  c1852
 L  c1853
 L  c1854
 L  c1855
 L  c1856
 L  c1857
 L  c1858
 L  c1859
 L  c1860
 L  c1861
 L  c1862
 L  c1863
 L  c1864
 L  c1865
 L  c1866
 L  c1867
 L  c1868
 L  c1869
 L  c1870
 L  c1871
 L  c1872
 L  c1873
 L  c1874
 L  c1875
 L  c1876
 L  c1877
 L  c1878
 L  c1879
 L  c1880
 L  c1881
 L  c1882
 L  c1883
 L  c1884
 L  c1885
 L  c1886
 L  c1887
 L  c1888
 L  c1889
 L  c1890
 L  c1891
 L  c1892
 L  c1893
 L  c1894
 L  c1895
 L  c1896
 L  c1897
 L  c1898
 L  c1899
 L  c1900
 L  c1901
 L  c1902
 L  c1903
 L  c1904
 L  c1905
 L  c1906
 L  c1907
 L  c1908
 L  c1909
 L  c1910
 L  c1911
 L  c1912
 L  c1913
 L  c1914
 L  c1915
 L  c1916
 L  c1917
 L  c1918
 L  c1919
 L  c1920
 L  c1921
 L  c1922
 L  c1923
 L  c1924
 L  c1925
 L  c1926
 L  c1927
 L  c1928
 L  c1929
 L  c1930
 L  c1931
 L  c1932
 L  c1933
 L  c1934
 L  c1935
 L  c1936
 L  c1937
 L  c1938
 L  c1939
 L  c1940
 L  c1941
 L  c1942
 L  c1943
 L  c1944
 L  c1945
 L  c1946
 L  c1947
 L  c1948
 L  c1949
 L  c1950
 L  c1951
 L  c1952
 L  c1953
 L  c1954
 L  c1955
 L  c1956
 L  c1957
 L  c1958
 L  c1959
 L  c1960
 L  c1961
 L  c1962
 L  c1963
 L  c1964
 L  c1965
 L  c1966
 L  c1967
 L  c1968
 L  c1969
 L  c1970
 L  c1971
 L  c1972
 L  c1973
 L  c1974
 L  c1975
 L  c1976
 L  c1977
 L  c1978
 L  c1979
 L  c1980
 L  c1981
 L  c1982
 L  c1983
 L  c1984
 L  c1985
 L  c1986
 L  c1987
 L  c1988
 L  c1989
 L  c1990
 L  c1991
 L  c1992
 L  c1993
 L  c1994
 L  c1995
 L  c1996
 L  c1997
 L  c1998
 L  c1999
 L  c2000
 L  c2001
 L  c2002
 L  c2003
 L  c2004
 L  c2005
 L  c2006
 L  c2007
 L  c2008
 L  c2009
 L  c2010
 L  c2011
 L  c2012
 L  c2013
 L  c2014
 L  c2015
 L  c2016
 L  c2017
 L  c2018
 L  c2019
 L  c2020
 L  c2021
 L  c2022
 L  c2023
 L  c2024
 L  c2025
 L  c2026
 L  c2027
 L  c2028
 L  c2029
 L  c2030
 L  c2031
 L  c2032
 L  c2033
 L  c2034
 L  c2035
 L  c2036
 L  c2037
 L  c2038
 L  c2039
 L  c2040
 L  c2041
 L  c2042
 L  c2043
 L  c2044
 L  c2045
 L  c2046
 L  c2047
 L  c2048
 L  c2049
 L  c2050
 L  c2051
 L  c2052
 L  c2053
 L  c2054
 L  c2055
 L  c2056
 L  c2057
 L  c2058
 L  c2059
 L  c2060
 L  c2061
 L  c2062
 L  c2063
 L  c2064
 L  c2065
 L  c2066
 L  c2067
 L  c2068
 L  c2069
 L  c2070
 L  c2071
 L  c2072
 L  c2073
 L  c2074
 L  c2075
 L  c2076
 L  c2077
 L  c2078
 L  c2079
 L  c2080
 L  c2081
 L  c2082
 L  c2083
 L  c2084
 L  c2085
 L  c2086
 L  c2087
 L  c2088
 L  c2089
 L  c2090
 L  c2091
 L  c2092
 L  c2093
 L  c2094
 L  c2095
 L  c2096
 L  c2097
 L  c2098
 L  c2099
 L  c2100
 L  c2101
 L  c2102
 L  c2103
 L  c2104
 L  c2105
 L  c2106
 L  c2107
 L  c2108
 L  c2109
 L  c2110
 L  c2111
 L  c2112
 L  c2113
 L  c2114
 L  c2115
 L  c2116
 L  c2117
 L  c2118
 L  c2119
 L  c2120
 L  c2121
 L  c2122
 L  c2123
 L  c2124
 L  c2125
 L  c2126
 L  c2127
 L  c2128
 L  c2129
 L  c2130
 L  c2131
 L  c2132
 L  c2133
 L  c2134
 L  c2135
 L  c2136
 L  c2137
 L  c2138
 L  c2139
 L  c2140
 L  c2141
 L  c2142
 L  c2143
 L  c2144
 L  c2145
 L  c2146
 L  c2147
 L  c2148
 L  c2149
 L  c2150
 L  c2151
 L  c2152
 L  c2153
 L  c2154
 L  c2155
 L  c2156
 L  c2157
 L  c2158
 L  c2159
 L  c2160
 L  c2161
 L  c2162
 L  c2163
 L  c2164
 L  c2165
 L  c2166
 L  c2167
 L  c2168
 L  c2169
 L  c2170
 L  c2171
 L  c2172
 L  c2173
 L  c2174
 L  c2175
 L  c2176
 L  c2177
 L  c2178
 L  c2179
 L  c2180
 L  c2181
 L  c2182
 L  c2183
 L  c2184
 L  c2185
 L  c2186
 L  c2187
 L  c2188
 L  c2189
 L  c2190
 L  c2191
 L  c2192
 L  c2193
 L  c2194
 L  c2195
 L  c2196
 L  c2197
 L  c2198
 L  c2199
 L  c2200
 L  c2201
 L  c2202
 L  c2203
 L  c2204
 L  c2205
 L  c2206
 L  c2207
 L  c2208
 L  c2209
 L  c2210
 L  c2211
 L  c2212
 L  c2213
 L  c2214
 L  c2215
 L  c2216
 L  c2217
 L  c2218
 L  c2219
 L  c2220
 L  c2221
 L  c2222
 L  c2223
 L  c2224
 L  c2225
 L  c2226
 L  c2227
 L  c2228
 L  c2229
 L  c2230
 L  c2231
 L  c2232
 L  c2233
 L  c2234
 L  c2235
 L  c2236
 L  c2237
 L  c2238
 L  c2239
 L  c2240
 L  c2241
 L  c2242
 L  c2243
 L  c2244
 L  c2245
 L  c2246
 L  c2247
 L  c2248
 L  c2249
 L  c2250
 L  c2251
 L  c2252
 L  c2253
 L  c2254
 L  c2255
 L  c2256
 L  c2257
 L  c2258
 L  c2259
 L  c2260
 L  c2261
 L  c2262
 L  c2263
 L  c2264
 L  c2265
 L  c2266
 L  c2267
 L  c2268
 L  c2269
 L  c2270
 L  c2271
 L  c2272
 L  c2273
 L  c2274
 L  c2275
 L  c2276
 L  c2277
 L  c2278
 L  c2279
 L  c2280
 L  c2281
 L  c2282
 L  c2283
 L  c2284
 L  c2285
 L  c2286
 L  c2287
 L  c2288
 L  c2289
 L  c2290
 L  c2291
 L  c2292
 L  c2293
 L  c2294
 L  c2295
 L  c2296
 L  c2297
 L  c2298
 L  c2299
 L  c2300
 L  c2301
 L  c2302
 L  c2303
 L  c2304
 L  c2305
 L  c2306
 L  c2307
 L  c2308
 L  c2309
 L  c2310
 L  c2311
 L  c2312
 L  c2313
 L  c2314
 L  c2315
 L  c2316
 L  c2317
 L  c2318
 L  c2319
 L  c2320
 L  c2321
 L  c2322
 L  c2323
 L  c2324
 L  c2325
 L  c2326
 L  c2327
 L  c2328
 L  c2329
 L  c2330
 L  c2331
 L  c2332
 L  c2333
 L  c2334
 L  c2335
 L  c2336
 L  c2337
 L  c2338
 L  c2339
 L  c2340
 L  c2341
 L  c2342
 L  c2343
 L  c2344
 L  c2345
 L  c2346
 L  c2347
 L  c2348
 L  c2349
 L  c2350
 L  c2351
 L  c2352
 L  c2353
 L  c2354
 L  c2355
 L  c2356
 L  c2357
 L  c2358
 L  c2359
 L  c2360
 L  c2361
 L  c2362
 L  c2363
 L  c2364
 L  c2365
 L  c2366
 L  c2367
 L  c2368
 L  c2369
 L  c2370
 L  c2371
 L  c2372
 L  c2373
 L  c2374
 L  c2375
 L  c2376
 L  c2377
 L  c2378
 L  c2379
 L  c2380
 L  c2381
 L  c2382
 L  c2383
 L  c2384
 L  c2385
 L  c2386
 L  c2387
 L  c2388
 L  c2389
 L  c2390
 L  c2391
 L  c2392
 L  c2393
 L  c2394
 L  c2395
 L  c2396
 L  c2397
 L  c2398
 L  c2399
 L  c2400
 L  c2401
 L  c2402
 L  c2403
 L  c2404
 L  c2405
 L  c2406
 L  c2407
 L  c2408
 L  c2409
 L  c2410
 L  c2411
 L  c2412
 L  c2413
 L  c2414
 L  c2415
 L  c2416
 L  c2417
 L  c2418
 L  c2419
 L  c2420
 L  c2421
 L  c2422
 L  c2423
 L  c2424
 L  c2425
 L  c2426
 L  c2427
 L  c2428
 L  c2429
 L  c2430
 L  c2431
 L  c2432
 L  c2433
 L  c2434
 L  c2435
 L  c2436
 L  c2437
 L  c2438
 L  c2439
 L  c2440
 L  c2441
 L  c2442
 L  c2443
 L  c2444
 L  c2445
 L  c2446
 L  c2447
 L  c2448
 L  c2449
 L  c2450
 L  c2451
 L  c2452
 L  c2453
 L  c2454
 L  c2455
 L  c2456
 L  c2457
 L  c2458
 L  c2459
 L  c2460
 L  c2461
 L  c2462
 L  c2463
 L  c2464
 L  c2465
 L  c2466
 L  c2467
 L  c2468
 L  c2469
 L  c2470
 L  c2471
 L  c2472
 L  c2473
 L  c2474
 L  c2475
 L  c2476
 L  c2477
 L  c2478
 L  c2479
 L  c2480
 L  c2481
 L  c2482
 L  c2483
 L  c2484
 L  c2485
 L  c2486
 L  c2487
 L  c2488
 L  c2489
 L  c2490
 L  c2491
 L  c2492
 L  c2493
 L  c2494
 L  c2495
 L  c2496
 L  c2497
 L  c2498
 L  c2499
 L  c2500
 L  c2501
 L  c2502
 L  c2503
 L  c2504
 L  c2505
 L  c2506
 L  c2507
 L  c2508
 L  c2509
 L  c2510
 L  c2511
 L  c2512
 L  c2513
 L  c2514
 L  c2515
 L  c2516
 L  c2517
 L  c2518
 L  c2519
 L  c2520
 L  c2521
 L  c2522
 L  c2523
 L  c2524
 L  c2525
 L  c2526
 L  c2527
 L  c2528
 L  c2529
 L  c2530
 L  c2531
 L  c2532
 L  c2533
 L  c2534
 L  c2535
 L  c2536
 L  c2537
 L  c2538
 L  c2539
 L  c2540
 L  c2541
 L  c2542
 L  c2543
 L  c2544
 L  c2545
 L  c2546
 L  c2547
 L  c2548
 L  c2549
 L  c2550
 L  c2551
 L  c2552
 L  c2553
 L  c2554
 L  c2555
 L  c2556
 L  c2557
 L  c2558
 L  c2559
 L  c2560
 L  c2561
 L  c2562
 L  c2563
 L  c2564
 L  c2565
 L  c2566
 L  c2567
 L  c2568
 L  c2569
 L  c2570
 L  c2571
 L  c2572
 L  c2573
 L  c2574
 L  c2575
 L  c2576
 L  c2577
 L  c2578
 L  c2579
 L  c2580
 L  c2581
 L  c2582
 L  c2583
 L  c2584
 L  c2585
 L  c2586
 L  c2587
 L  c2588
 L  c2589
 L  c2590
 L  c2591
 L  c2592
 L  c2593
 L  c2594
 L  c2595
 L  c2596
 L  c2597
 L  c2598
 L  c2599
 L  c2600
 L  c2601
 L  c2602
 L  c2603
 L  c2604
 L  c2605
 L  c2606
 L  c2607
 L  c2608
 L  c2609
 L  c2610
 L  c2611
 L  c2612
 L  c2613
 L  c2614
 L  c2615
 L  c2616
 L  c2617
 L  c2618
 L  c2619
 L  c2620
 L  c2621
 L  c2622
 L  c2623
 L  c2624
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
 E  c70
 E  c71
 E  c72
 E  c73
 E  c74
 E  c75
 E  c76
 E  c77
 E  c78
 E  c79
 E  c80
 E  c81
 E  c82
 E  c83
 E  c84
 E  c85
 E  c86
 E  c87
 E  c88
 E  c89
 E  c90
 E  c91
 E  c92
 E  c93
 E  c94
 E  c95
 E  c96
 E  c97
 E  c98
 E  c99
 E  c100
 E  c101
 E  c102
 E  c103
 E  c104
 E  c105
 E  c106
 E  c107
 E  c108
 E  c109
 E  c110
 E  c111
 E  c112
 E  c113
 E  c114
 E  c115
 E  c116
 E  c117
 E  c118
 E  c119
 E  c120
 E  c121
 E  c122
 E  c123
 E  c124
 E  c125
 E  c126
 E  c127
 E  c128
 E  c129
 E  c130
 E  c131
 E  c132
 E  c133
 E  c134
 E  c135
 E  c136
 E  c137
 E  c138
 E  c139
 E  c140
 E  c141
 E  c142
 E  c143
 E  c144
 E  c145
 E  c146
 E  c147
 E  c148
 E  c149
 E  c150
 E  c151
 E  c152
 E  c153
 E  c154
 E  c155
 E  c156
 E  c157
 E  c158
 E  c159
 E  c160
 E  c161
 E  c162
 E  c163
 E  c164
 E  c165
 E  c166
 E  c167
 E  c168
 E  c169
 E  c170
 E  c171
 E  c172
 E  c173
 E  c174
 E  c175
 E  c176
 E  c177
 E  c178
 E  c179
 E  c180
 E  c181
 E  c182
 E  c183
 E  c184
 E  c185
 E  c186
 E  c187
 E  c188
 E  c189
 E  c190
 E  c191
 E  c192
 E  c193
 E  c194
 E  c195
 E  c196
 E  c197
 E  c198
 E  c199
 E  c200
 E  c201
 E  c202
 E  c203
 E  c204
 E  c205
 E  c206
 E  c207
 E  c208
 E  c209
 E  c210
 E  c211
 E  c212
 E  c213
 E  c214
 E  c215
 E  c216
 E  c217
 E  c218
 E  c219
 E  c220
 E  c221
 E  c222
 E  c223
 E  c224
 E  c225
 E  c226
 E  c227
 E  c228
 E  c229
 E  c230
 E  c231
 E  c232
 E  c233
 E  c234
 E  c235
 E  c236
 E  c237
 E  c238
 E  c239
 E  c240
 E  c241
 E  c242
 E  c243
 E  c244
 E  c245
 E  c246
 E  c247
 E  c248
 E  c249
 E  c250
 E  c251
 E  c252
 E  c253
 E  c254
 E  c255
 E  c256
 E  c257
 E  c258
 E  c259
 E  c260
 E  c261
 E  c262
 E  c263
 E  c264
 E  c265
 E  c266
 E  c267
 E  c268
 E  c269
 E  c270
 E  c271
 E  c272
 E  c273
 E  c274
 E  c275
 E  c276
 E  c277
 E  c278
 E  c279
 E  c280
 E  c281
 E  c282
 E  c283
 E  c284
 E  c285
 E  c286
 E  c287
 E  c288
 E  c289
 E  c290
 E  c291
 E  c292
 E  c293
 E  c294
 E  c295
 E  c296
 E  c297
 E  c298
 E  c299
 E  c300
 E  c301
 E  c302
 E  c303
 E  c304
 E  c305
 E  c306
 E  c307
 E  c308
 E  c309
 E  c310
 E  c311
 E  c312
 E  c313
 E  c314
 E  c315
 E  c316
 E  c317
 E  c318
 E  c319
 E  c320
 E  c321
 E  c322
 E  c323
 E  c324
 E  c325
 E  c326
 E  c327
 E  c328
 E  c329
 E  c330
 E  c331
 E  c332
 E  c333
 E  c334
 E  c335
 E  c336
 E  c337
 E  c338
 E  c339
 E  c340
 E  c341
 E  c342
 E  c343
 E  c344
 E  c345
 E  c346
 E  c347
 E  c348
 E  c349
 E  c350
 E  c351
 E  c352
 E  c353
 E  c354
 E  c355
 E  c356
 E  c357
 E  c358
 E  c359
 E  c360
 E  c361
 E  c362
 E  c363
 E  c364
 E  c365
 E  c366
 E  c367
 E  c368
 E  c369
 E  c370
 E  c371
 E  c372
 E  c373
 E  c374
 E  c375
 E  c376
 E  c377
 E  c378
 E  c379
 E  c380
 E  c381
 E  c382
 E  c383
 E  c384
 E  c385
 E  c386
 E  c387
 E  c388
 E  c389
 E  c390
 E  c391
 E  c392
 E  c393
 E  c394
 E  c395
 E  c396
 E  c397
 E  c398
 E  c399
 E  c400
 E  c401
 E  c402
 E  c403
 E  c404
 E  c405
 E  c406
 E  c407
 E  c408
 E  c409
 E  c410
 E  c411
 E  c412
 E  c413
 E  c414
 E  c415
 E  c416
 E  c417
 E  c418
 E  c419
 E  c420
 E  c421
 E  c422
 E  c423
 E  c424
 E  c425
 E  c426
 E  c427
 E  c428
 E  c429
 E  c430
 E  c431
 E  c432
 E  c433
 E  c434
 E  c435
 E  c436
 E  c437
 E  c438
 E  c439
 E  c440
 E  c441
 E  c442
 E  c443
 E  c444
 E  c445
 E  c446
 E  c447
 E  c448
 E  c449
 E  c450
 E  c451
 E  c452
 E  c453
 E  c454
 E  c455
 E  c456
 E  c457
 E  c458
 E  c459
 E  c460
 E  c461
 E  c462
 E  c463
 E  c464
 E  c465
 E  c466
 E  c467
 E  c468
 E  c469
 E  c470
 E  c471
 E  c472
 E  c473
 E  c474
 E  c475
 E  c476
 E  c477
 E  c478
 E  c479
 E  c480
 E  c481
 E  c482
 E  c483
 E  c484
 E  c485
 E  c486
 E  c487
 E  c488
 E  c489
 E  c490
 E  c491
 E  c492
 E  c493
 E  c494
 E  c495
 E  c496
 E  c497
 E  c498
 E  c499
 E  c500
 E  c501
 E  c502
 E  c503
 E  c504
 E  c505
 E  c506
 E  c507
 E  c508
 E  c509
 E  c510
 E  c511
 E  c512
 E  c513
 E  c514
 E  c515
 E  c516
 E  c517
 E  c518
 E  c519
 E  c520
 E  c521
 E  c522
 E  c523
 E  c524
 E  c525
 E  c526
 E  c527
 E  c528
 E  c529
 E  c530
 E  c531
 E  c532
 E  c533
 E  c534
 E  c535
 E  c536
 E  c537
 E  c538
 E  c539
 E  c540
 E  c541
 E  c542
 E  c543
 E  c544
 E  c545
 E  c546
 E  c547
 E  c548
 E  c549
 E  c550
 E  c551
 E  c552
 E  c553
 E  c554
 E  c555
 E  c556
 E  c557
 E  c558
 E  c559
 E  c560
 E  c561
 E  c562
 E  c563
 E  c564
 E  c565
 E  c566
 E  c567
 E  c568
 E  c569
 E  c570
 E  c571
 E  c572
 E  c573
 E  c574
 E  c575
 E  c576
 E  c577
 E  c578
 E  c579
 E  c580
 E  c581
 E  c582
 E  c583
 E  c584
 E  c585
 E  c586
 E  c587
 E  c588
 E  c589
 E  c590
 E  c591
 E  c592
 E  c593
 E  c594
 E  c595
 E  c596
 E  c597
 E  c598
 E  c599
 E  c600
 E  c601
 E  c602
 E  c603
 E  c604
 E  c605
 E  c606
 E  c607
 E  c608
 E  c609
 E  c610
 E  c611
 E  c612
 E  c613
 E  c614
 E  c615
 E  c616
 E  c617
 E  c618
 E  c619
 E  c620
 E  c621
 E  c622
 E  c623
 E  c624
 E  c625
 E  c626
 E  c627
 E  c628
 E  c629
 E  c630
 E  c631
 E  c632
 E  c633
 E  c634
 E  c635
 E  c636
 E  c637
 E  c638
 E  c639
 E  c640
 E  c641
 E  c642
 E  c643
 E  c644
 E  c645
 E  c646
 E  c647
 E  c648
 E  c649
 E  c650
 E  c651
 E  c652
 E  c653
 E  c654
 E  c655
 E  c656
 E  c657
 E  c658
 E  c659
 E  c660
 E  c661
 E  c662
 E  c663
 E  c664
 E  c665
 E  c666
 E  c667
 E  c668
 E  c669
 E  c670
 E  c671
 E  c672
 E  c673
 E  c674
 E  c675
 E  c676
 E  c677
 E  c678
 E  c679
 E  c680
 E  c681
 E  c682
 E  c683
 E  c684
 E  c685
 E  c686
 E  c687
 E  c688
 E  c689
 E  c690
 E  c691
 E  c692
 E  c693
 E  c694
 E  c695
 E  c696
 E  c697
 E  c698
 E  c699
 E  c700
 E  c701
 E  c702
 E  c703
 E  c704
 E  c705
 E  c706
 E  c707
 E  c708
 E  c709
 E  c710
 E  c711
 E  c712
 E  c713
 E  c714
 E  c715
 E  c716
 E  c717
 E  c718
 E  c719
 E  c720
 E  c721
 E  c722
 E  c723
 E  c724
 E  c725
 E  c726
 E  c727
 E  c728
 E  c729
 E  c730
 E  c731
 E  c732
 E  c733
 E  c734
 E  c735
 E  c736
 E  c737
 E  c738
 E  c739
 E  c740
 E  c741
 E  c742
 E  c743
 E  c744
 E  c745
 E  c746
 E  c747
 E  c748
 E  c749
 E  c750
 E  c751
 E  c752
 E  c753
 E  c754
 E  c755
 E  c756
 E  c757
 E  c758
 E  c759
 E  c760
 E  c761
 E  c762
 E  c763
 E  c764
 E  c765
 E  c766
 E  c767
 E  c768
 E  c769
 E  c770
 E  c771
 E  c772
 E  c773
 E  c774
 E  c775
 E  c776
 E  c777
 E  c778
 E  c779
 E  c780
 E  c781
 E  c782
 E  c783
 E  c784
 E  c785
 E  c786
 E  c787
 E  c788
 E  c789
 E  c790
 E  c791
 E  c792
 E  c793
 E  c794
 E  c795
 E  c796
 E  c797
 E  c798
 E  c799
 E  c800
 E  c801
 E  c802
 E  c803
 E  c804
 E  c805
 E  c806
 E  c807
 E  c808
 E  c809
 E  c810
 E  c811
 E  c812
 E  c813
 E  c814
 E  c815
 E  c816
 E  c817
 E  c818
 E  c819
 E  c820
 E  c821
 E  c822
 E  c823
 E  c824
 E  c825
 E  c826
 E  c827
 E  c828
 E  c829
 E  c830
 E  c831
 E  c832
 E  c833
 E  c834
 E  c835
 E  c836
 E  c837
 E  c838
 E  c839
 E  c840
 E  c841
 E  c842
 E  c843
 E  c844
 E  c845
 E  c846
 E  c847
 E  c848
 E  c849
 E  c850
 E  c851
 E  c852
 E  c853
 E  c854
 E  c855
 E  c856
 E  c857
 E  c858
 E  c859
 E  c860
 E  c861
 E  c862
 E  c863
 E  c864
 E  c865
 E  c866
 E  c867
 E  c868
 E  c869
 E  c870
 E  c871
 E  c872
 E  c873
 E  c874
 E  c875
 E  c876
 E  c877
 E  c878
 E  c879
 E  c880
 E  c881
 E  c882
 E  c883
 E  c884
 E  c885
 E  c886
 E  c887
 E  c888
 E  c889
 E  c890
 E  c891
 E  c892
 E  c893
 E  c894
 E  c895
 E  c896
 E  c897
 E  c898
 E  c899
 E  c900
 E  c901
 E  c902
 E  c903
 E  c904
 E  c905
 E  c906
 E  c907
 E  c908
 E  c909
 E  c910
 E  c911
 E  c912
 E  c913
 E  c914
 E  c915
 E  c916
 E  c917
 E  c918
 E  c919
 E  c920
 E  c921
 E  c922
 E  c923
 E  c924
 E  c925
 E  c926
 E  c927
 E  c928
 E  c929
 E  c930
 E  c931
 E  c932
 E  c933
 E  c934
 E  c935
 E  c936
 E  c937
 E  c938
 E  c939
 E  c940
 E  c941
 E  c942
 E  c943
 E  c944
 E  c945
 E  c946
 E  c947
 E  c948
 E  c949
 E  c950
 E  c951
 E  c952
 E  c953
 E  c954
 E  c955
 E  c956
 E  c957
 E  c958
 E  c959
 E  c960
 E  c961
 E  c962
 E  c963
 E  c964
 E  c965
 E  c966
 E  c967
 E  c968
 E  c969
 E  c970
 E  c971
 E  c972
 E  c973
 E  c974
 E  c975
 E  c976
 E  c977
 E  c978
 E  c979
 E  c980
 E  c981
 E  c982
 E  c983
 E  c984
 E  c985
 E  c986
 E  c987
 E  c988
 E  c989
 E  c990
 E  c991
 E  c992
 E  c993
 E  c994
 E  c995
 E  c996
 E  c997
 E  c998
 E  c999
 E  c1000
 E  c1001
 E  c1002
 E  c1003
 E  c1004
 E  c1005
 E  c1006
 E  c1007
 E  c1008
 E  c1009
 E  c1010
 E  c1011
 E  c1012
 E  c1013
 E  c1014
 E  c1015
 E  c1016
 E  c1017
 E  c1018
 E  c1019
 E  c1020
 E  c1021
 E  c1022
 E  c1023
 E  c1024
 E  c1025
 E  c1026
 E  c1027
 E  c1028
 E  c1029
 E  c1030
 E  c1031
 E  c1032
 E  c1033
 E  c1034
 E  c1035
 E  c1036
 E  c1037
 E  c1038
 E  c1039
 E  c1040
 E  c1041
 E  c1042
 E  c1043
 E  c1044
 E  c1045
 E  c1046
 E  c1047
 E  c1048
 E  c1049
 E  c1050
 E  c1051
 E  c1052
 E  c1053
 E  c1054
 E  c1055
 E  c1056
 E  c1057
 E  c1058
 E  c1059
 E  c1060
 E  c1061
 E  c1062
 E  c1063
 E  c1064
 E  c1065
 E  c1066
 E  c1067
 E  c1068
 E  c1069
 E  c1070
 E  c1071
 E  c1072
 E  c1073
 E  c1074
 E  c1075
 E  c1076
 E  c1077
 E  c1078
 E  c1079
 E  c1080
 E  c1081
 E  c1082
 E  c1083
 E  c1084
 E  c1085
 E  c1086
 E  c1087
 E  c1088
 E  c1089
 E  c1090
 E  c1091
 E  c1092
 E  c1093
 E  c1094
 E  c1095
 E  c1096
 E  c1097
 E  c1098
 E  c1099
 E  c1100
 E  c1101
 E  c1102
 E  c1103
 E  c1104
 E  c1105
 E  c1106
 E  c1107
 E  c1108
 E  c1109
 E  c1110
 E  c1111
 E  c1112
 E  c1113
 E  c1114
 E  c1115
 E  c1116
 E  c1117
 E  c1118
 E  c1119
 E  c1120
 E  c1121
 E  c1122
 E  c1123
 E  c1124
 E  c1125
 E  c1126
 E  c1127
 E  c1128
 E  c1129
 E  c1130
 E  c1131
 E  c1132
 E  c1133
 E  c1134
 E  c1135
 E  c1136
 E  c1137
 E  c1138
 E  c1139
 E  c1140
 E  c1141
 E  c1142
 E  c1143
 E  c1144
 E  c1145
 E  c1146
 E  c1147
 E  c1148
 E  c1149
 E  c1150
 E  c1151
 E  c1152
 E  c1153
 E  c1154
 E  c1155
 E  c1156
 E  c1157
 E  c1158
 E  c1159
 E  c1160
 E  c1161
 E  c1162
 E  c1163
 E  c1164
 E  c1165
 E  c1166
 E  c1167
 E  c1168
 E  c1169
 E  c1170
 E  c1171
 E  c1172
 E  c1173
 E  c1174
 E  c1175
 E  c1176
 E  c1177
 E  c1178
 E  c1179
 E  c1180
 E  c1181
 E  c1182
 E  c1183
 E  c1184
 E  c1185
 E  c1186
 E  c1187
 E  c1188
 E  c1189
 E  c1190
 E  c1191
 E  c1192
 E  c1193
 E  c1194
 E  c1195
 E  c1196
 E  c1197
 E  c1198
 E  c1199
 E  c1200
 E  c1201
 E  c1202
 E  c1203
 E  c1204
 E  c1205
 E  c1206
 E  c1207
 E  c1208
 E  c1209
 E  c1210
 E  c1211
 E  c1212
 E  c1213
 E  c1214
 E  c1215
 E  c1216
 E  c1217
 E  c1218
 E  c1219
 E  c1220
 E  c1221
 E  c1222
 E  c1223
 E  c1224
 E  c1225
 E  c1226
 E  c1227
 E  c1228
 E  c1229
 E  c1230
 E  c1231
 E  c1232
 E  c1233
 E  c1234
 E  c1235
 E  c1236
 E  c1237
 E  c1238
 E  c1239
 E  c1240
 E  c1241
 E  c1242
 E  c1243
 E  c1244
 E  c1245
 E  c1246
 E  c1247
 E  c1248
 E  c1249
 E  c1250
 E  c1251
 E  c1252
 E  c1253
 E  c1254
 E  c1255
 E  c1256
 E  c1257
 E  c1258
 E  c1259
 E  c1260
 E  c1261
 E  c1262
 E  c1263
 E  c1264
 E  c1265
 E  c1266
 E  c1267
 E  c1268
 E  c1269
 E  c1270
 E  c1271
 E  c1272
 E  c1273
 E  c1274
 E  c1275
 E  c1276
 E  c1277
 E  c1278
 E  c1279
 E  c1280
 E  c1281
 E  c1282
 E  c1283
 E  c1284
 E  c1285
 E  c1286
 E  c1287
 E  c1288
 E  c1289
 E  c1290
 E  c1291
 E  c1292
 E  c1293
 E  c1294
 E  c1295
 E  c1296
 E  c1297
 E  c1298
 E  c1299
 E  c1300
 E  c1301
 E  c1302
 E  c1303
 E  c1304
 E  c1305
 E  c1306
 E  c1307
 E  c1308
 E  c1309
 E  c1310
 E  c1311
 E  c1312
 E  c1313
 E  c1314
 E  c1315
 E  c1316
 E  c1317
 E  c1318
COLUMNS
    x[1]      c1025     -1
    x[1]      c1026     1
    x[1]      OBJ       6.35
    x[2]      c1041     -1
    x[2]      c1042     1
    x[2]      OBJ       4.35
    x[3]      c1057     -1
    x[3]      c1058     1
    x[3]      OBJ       6.22
    x[4]      c1073     -1
    x[4]      c1074     1
    x[4]      OBJ       4.22
    x[5]      c1089     -1
    x[5]      c1090     1
    x[5]      OBJ       6.45
    x[6]      c1105     -1
    x[6]      c1106     1
    x[6]      OBJ       4.45
    x[7]      c1121     -1
    x[7]      c1122     1
    x[7]      OBJ       6.27
    x[8]      c1137     -1
    x[8]      c1138     1
    x[8]      OBJ       4.27
    x[9]      c1153     -1
    x[9]      c1154     1
    x[9]      OBJ       6.4
    x[10]     c1169     -1
    x[10]     c1170     1
    x[10]     OBJ       4.4
    x[11]     c1185     -1
    x[11]     c1186     1
    x[11]     OBJ       6.32
    x[12]     c1201     -1
    x[12]     c1202     1
    x[12]     OBJ       4.32
    x[13]     c1217     -1
    x[13]     c1218     1
    x[13]     OBJ       6.5
    x[14]     c1233     -1
    x[14]     c1234     1
    x[14]     OBJ       4.5
    x[15]     c1249     -1
    x[15]     c1250     1
    x[15]     OBJ       6.37
    x[16]     c1265     -1
    x[16]     c1266     1
    x[16]     OBJ       4.37
    x[17]     c1        -1
    x[17]     c2        1
    x[17]     OBJ       5
    x[18]     c17       -1
    x[18]     c18       1
    x[18]     OBJ       1.25
    x[19]     c33       -1
    x[19]     c34       1
    x[19]     OBJ       3
    x[20]     c49       -1
    x[20]     c50       1
    x[20]     OBJ       1.25
    x[21]     c65       -1
    x[21]     c66       1
    x[21]     OBJ       5
    x[22]     c81       -1
    x[22]     c82       1
    x[22]     OBJ       1.12
    x[23]     c97       -1
    x[23]     c98       1
    x[23]     OBJ       3
    x[24]     c113      -1
    x[24]     c114      1
    x[24]     OBJ       1.12
    x[25]     c129      -1
    x[25]     c130      1
    x[25]     OBJ       5
    x[26]     c145      -1
    x[26]     c146      1
    x[26]     OBJ       1.35
    x[27]     c161      -1
    x[27]     c162      1
    x[27]     OBJ       3
    x[28]     c177      -1
    x[28]     c178      1
    x[28]     OBJ       1.35
    x[29]     c193      -1
    x[29]     c194      1
    x[29]     OBJ       5
    x[30]     c209      -1
    x[30]     c210      1
    x[30]     OBJ       1.17
    x[31]     c225      -1
    x[31]     c226      1
    x[31]     OBJ       3
    x[32]     c241      -1
    x[32]     c242      1
    x[32]     OBJ       1.17
    x[33]     c257      -1
    x[33]     c258      1
    x[33]     OBJ       5
    x[34]     c273      -1
    x[34]     c274      1
    x[34]     OBJ       1.3
    x[35]     c289      -1
    x[35]     c290      1
    x[35]     OBJ       3
    x[36]     c305      -1
    x[36]     c306      1
    x[36]     OBJ       1.3
    x[37]     c321      -1
    x[37]     c322      1
    x[37]     OBJ       5
    x[38]     c337      -1
    x[38]     c338      1
    x[38]     OBJ       1.22
    x[39]     c353      -1
    x[39]     c354      1
    x[39]     OBJ       3
    x[40]     c369      -1
    x[40]     c370      1
    x[40]     OBJ       1.22
    x[41]     c385      -1
    x[41]     c386      1
    x[41]     OBJ       5
    x[42]     c401      -1
    x[42]     c402      1
    x[42]     OBJ       1.4
    x[43]     c417      -1
    x[43]     c418      1
    x[43]     OBJ       3
    x[44]     c433      -1
    x[44]     c434      1
    x[44]     OBJ       1.4
    x[45]     c449      -1
    x[45]     c450      1
    x[45]     OBJ       5
    x[46]     c465      -1
    x[46]     c466      1
    x[46]     OBJ       1.27
    x[47]     c481      -1
    x[47]     c482      1
    x[47]     OBJ       3
    x[48]     c497      -1
    x[48]     c498      1
    x[48]     OBJ       1.27
    x[49]     c513      -1
    x[49]     c514      1
    x[49]     OBJ       0.1
    x[50]     c529      -1
    x[50]     c530      1
    x[50]     OBJ       0.15
    x[51]     c545      -1
    x[51]     c546      1
    x[51]     OBJ       0.1
    x[52]     c561      -1
    x[52]     c562      1
    x[52]     OBJ       0.15
    x[53]     c577      -1
    x[53]     c578      1
    x[53]     OBJ       0.02
    x[54]     c593      -1
    x[54]     c594      1
    x[54]     OBJ       0.1
    x[55]     c609      -1
    x[55]     c610      1
    x[55]     OBJ       0.02
    x[56]     c625      -1
    x[56]     c626      1
    x[56]     OBJ       0.1
    x[57]     c641      -1
    x[57]     c642      1
    x[57]     OBJ       0.05
    x[58]     c657      -1
    x[58]     c658      1
    x[58]     OBJ       0.3
    x[59]     c673      -1
    x[59]     c674      1
    x[59]     OBJ       0.05
    x[60]     c689      -1
    x[60]     c690      1
    x[60]     OBJ       0.3
    x[61]     c705      -1
    x[61]     c706      1
    x[61]     OBJ       0.02
    x[62]     c721      -1
    x[62]     c722      1
    x[62]     OBJ       0.15
    x[63]     c737      -1
    x[63]     c738      1
    x[63]     OBJ       0.02
    x[64]     c753      -1
    x[64]     c754      1
    x[64]     OBJ       0.15
    x[65]     c769      -1
    x[65]     c770      1
    x[65]     OBJ       0.05
    x[66]     c785      -1
    x[66]     c786      1
    x[66]     OBJ       0.25
    x[67]     c801      -1
    x[67]     c802      1
    x[67]     OBJ       0.05
    x[68]     c817      -1
    x[68]     c818      1
    x[68]     OBJ       0.25
    x[69]     c833      -1
    x[69]     c834      1
    x[69]     OBJ       0.02
    x[70]     c849      -1
    x[70]     c850      1
    x[70]     OBJ       0.2
    x[71]     c865      -1
    x[71]     c866      1
    x[71]     OBJ       0.02
    x[72]     c881      -1
    x[72]     c882      1
    x[72]     OBJ       0.2
    x[73]     c897      -1
    x[73]     c898      1
    x[73]     OBJ       0.05
    x[74]     c913      -1
    x[74]     c914      1
    x[74]     OBJ       0.35
    x[75]     c929      -1
    x[75]     c930      1
    x[75]     OBJ       0.05
    x[76]     c945      -1
    x[76]     c946      1
    x[76]     OBJ       0.35
    x[77]     c961      -1
    x[77]     c962      1
    x[77]     OBJ       0.02
    x[78]     c977      -1
    x[78]     c978      1
    x[78]     OBJ       0.25
    x[79]     c993      -1
    x[79]     c994      1
    x[79]     OBJ       0.02
    x[80]     c1009     -1
    x[80]     c1010     1
    x[80]     OBJ       0.25
    x[81]     c1026     -1
    x[81]     c1027     1
    x[81]     OBJ       6.35
    x[82]     c1042     -1
    x[82]     c1043     1
    x[82]     OBJ       4.35
    x[83]     c1058     -1
    x[83]     c1059     1
    x[83]     OBJ       6.22
    x[84]     c1074     -1
    x[84]     c1075     1
    x[84]     OBJ       4.22
    x[85]     c1090     -1
    x[85]     c1091     1
    x[85]     OBJ       6.45
    x[86]     c1106     -1
    x[86]     c1107     1
    x[86]     OBJ       4.45
    x[87]     c1122     -1
    x[87]     c1123     1
    x[87]     OBJ       6.27
    x[88]     c1138     -1
    x[88]     c1139     1
    x[88]     OBJ       4.27
    x[89]     c1154     -1
    x[89]     c1155     1
    x[89]     OBJ       6.4
    x[90]     c1170     -1
    x[90]     c1171     1
    x[90]     OBJ       4.4
    x[91]     c1186     -1
    x[91]     c1187     1
    x[91]     OBJ       6.32
    x[92]     c1202     -1
    x[92]     c1203     1
    x[92]     OBJ       4.32
    x[93]     c1218     -1
    x[93]     c1219     1
    x[93]     OBJ       6.5
    x[94]     c1234     -1
    x[94]     c1235     1
    x[94]     OBJ       4.5
    x[95]     c1250     -1
    x[95]     c1251     1
    x[95]     OBJ       6.37
    x[96]     c1266     -1
    x[96]     c1267     1
    x[96]     OBJ       4.37
    x[97]     c2        -1
    x[97]     c3        1
    x[97]     OBJ       5
    x[98]     c18       -1
    x[98]     c19       1
    x[98]     OBJ       1.25
    x[99]     c34       -1
    x[99]     c35       1
    x[99]     OBJ       3
    x[100]    c50       -1
    x[100]    c51       1
    x[100]    OBJ       1.25
    x[101]    c66       -1
    x[101]    c67       1
    x[101]    OBJ       5
    x[102]    c82       -1
    x[102]    c83       1
    x[102]    OBJ       1.12
    x[103]    c98       -1
    x[103]    c99       1
    x[103]    OBJ       3
    x[104]    c114      -1
    x[104]    c115      1
    x[104]    OBJ       1.12
    x[105]    c130      -1
    x[105]    c131      1
    x[105]    OBJ       5
    x[106]    c146      -1
    x[106]    c147      1
    x[106]    OBJ       1.35
    x[107]    c162      -1
    x[107]    c163      1
    x[107]    OBJ       3
    x[108]    c178      -1
    x[108]    c179      1
    x[108]    OBJ       1.35
    x[109]    c194      -1
    x[109]    c195      1
    x[109]    OBJ       5
    x[110]    c210      -1
    x[110]    c211      1
    x[110]    OBJ       1.17
    x[111]    c226      -1
    x[111]    c227      1
    x[111]    OBJ       3
    x[112]    c242      -1
    x[112]    c243      1
    x[112]    OBJ       1.17
    x[113]    c258      -1
    x[113]    c259      1
    x[113]    OBJ       5
    x[114]    c274      -1
    x[114]    c275      1
    x[114]    OBJ       1.3
    x[115]    c290      -1
    x[115]    c291      1
    x[115]    OBJ       3
    x[116]    c306      -1
    x[116]    c307      1
    x[116]    OBJ       1.3
    x[117]    c322      -1
    x[117]    c323      1
    x[117]    OBJ       5
    x[118]    c338      -1
    x[118]    c339      1
    x[118]    OBJ       1.22
    x[119]    c354      -1
    x[119]    c355      1
    x[119]    OBJ       3
    x[120]    c370      -1
    x[120]    c371      1
    x[120]    OBJ       1.22
    x[121]    c386      -1
    x[121]    c387      1
    x[121]    OBJ       5
    x[122]    c402      -1
    x[122]    c403      1
    x[122]    OBJ       1.4
    x[123]    c418      -1
    x[123]    c419      1
    x[123]    OBJ       3
    x[124]    c434      -1
    x[124]    c435      1
    x[124]    OBJ       1.4
    x[125]    c450      -1
    x[125]    c451      1
    x[125]    OBJ       5
    x[126]    c466      -1
    x[126]    c467      1
    x[126]    OBJ       1.27
    x[127]    c482      -1
    x[127]    c483      1
    x[127]    OBJ       3
    x[128]    c498      -1
    x[128]    c499      1
    x[128]    OBJ       1.27
    x[129]    c514      -1
    x[129]    c515      1
    x[129]    OBJ       0.1
    x[130]    c530      -1
    x[130]    c531      1
    x[130]    OBJ       0.15
    x[131]    c546      -1
    x[131]    c547      1
    x[131]    OBJ       0.1
    x[132]    c562      -1
    x[132]    c563      1
    x[132]    OBJ       0.15
    x[133]    c578      -1
    x[133]    c579      1
    x[133]    OBJ       0.02
    x[134]    c594      -1
    x[134]    c595      1
    x[134]    OBJ       0.1
    x[135]    c610      -1
    x[135]    c611      1
    x[135]    OBJ       0.02
    x[136]    c626      -1
    x[136]    c627      1
    x[136]    OBJ       0.1
    x[137]    c642      -1
    x[137]    c643      1
    x[137]    OBJ       0.05
    x[138]    c658      -1
    x[138]    c659      1
    x[138]    OBJ       0.3
    x[139]    c674      -1
    x[139]    c675      1
    x[139]    OBJ       0.05
    x[140]    c690      -1
    x[140]    c691      1
    x[140]    OBJ       0.3
    x[141]    c706      -1
    x[141]    c707      1
    x[141]    OBJ       0.02
    x[142]    c722      -1
    x[142]    c723      1
    x[142]    OBJ       0.15
    x[143]    c738      -1
    x[143]    c739      1
    x[143]    OBJ       0.02
    x[144]    c754      -1
    x[144]    c755      1
    x[144]    OBJ       0.15
    x[145]    c770      -1
    x[145]    c771      1
    x[145]    OBJ       0.05
    x[146]    c786      -1
    x[146]    c787      1
    x[146]    OBJ       0.25
    x[147]    c802      -1
    x[147]    c803      1
    x[147]    OBJ       0.05
    x[148]    c818      -1
    x[148]    c819      1
    x[148]    OBJ       0.25
    x[149]    c834      -1
    x[149]    c835      1
    x[149]    OBJ       0.02
    x[150]    c850      -1
    x[150]    c851      1
    x[150]    OBJ       0.2
    x[151]    c866      -1
    x[151]    c867      1
    x[151]    OBJ       0.02
    x[152]    c882      -1
    x[152]    c883      1
    x[152]    OBJ       0.2
    x[153]    c898      -1
    x[153]    c899      1
    x[153]    OBJ       0.05
    x[154]    c914      -1
    x[154]    c915      1
    x[154]    OBJ       0.35
    x[155]    c930      -1
    x[155]    c931      1
    x[155]    OBJ       0.05
    x[156]    c946      -1
    x[156]    c947      1
    x[156]    OBJ       0.35
    x[157]    c962      -1
    x[157]    c963      1
    x[157]    OBJ       0.02
    x[158]    c978      -1
    x[158]    c979      1
    x[158]    OBJ       0.25
    x[159]    c994      -1
    x[159]    c995      1
    x[159]    OBJ       0.02
    x[160]    c1010     -1
    x[160]    c1011     1
    x[160]    OBJ       0.25
    x[161]    c1027     -1
    x[161]    c1028     1
    x[161]    OBJ       6.35
    x[162]    c1043     -1
    x[162]    c1044     1
    x[162]    OBJ       4.35
    x[163]    c1059     -1
    x[163]    c1060     1
    x[163]    OBJ       6.22
    x[164]    c1075     -1
    x[164]    c1076     1
    x[164]    OBJ       4.22
    x[165]    c1091     -1
    x[165]    c1092     1
    x[165]    OBJ       6.45
    x[166]    c1107     -1
    x[166]    c1108     1
    x[166]    OBJ       4.45
    x[167]    c1123     -1
    x[167]    c1124     1
    x[167]    OBJ       6.27
    x[168]    c1139     -1
    x[168]    c1140     1
    x[168]    OBJ       4.27
    x[169]    c1155     -1
    x[169]    c1156     1
    x[169]    OBJ       6.4
    x[170]    c1171     -1
    x[170]    c1172     1
    x[170]    OBJ       4.4
    x[171]    c1187     -1
    x[171]    c1188     1
    x[171]    OBJ       6.32
    x[172]    c1203     -1
    x[172]    c1204     1
    x[172]    OBJ       4.32
    x[173]    c1219     -1
    x[173]    c1220     1
    x[173]    OBJ       6.5
    x[174]    c1235     -1
    x[174]    c1236     1
    x[174]    OBJ       4.5
    x[175]    c1251     -1
    x[175]    c1252     1
    x[175]    OBJ       6.37
    x[176]    c1267     -1
    x[176]    c1268     1
    x[176]    OBJ       4.37
    x[177]    c3        -1
    x[177]    c4        1
    x[177]    OBJ       5
    x[178]    c19       -1
    x[178]    c20       1
    x[178]    OBJ       1.25
    x[179]    c35       -1
    x[179]    c36       1
    x[179]    OBJ       3
    x[180]    c51       -1
    x[180]    c52       1
    x[180]    OBJ       1.25
    x[181]    c67       -1
    x[181]    c68       1
    x[181]    OBJ       5
    x[182]    c83       -1
    x[182]    c84       1
    x[182]    OBJ       1.12
    x[183]    c99       -1
    x[183]    c100      1
    x[183]    OBJ       3
    x[184]    c115      -1
    x[184]    c116      1
    x[184]    OBJ       1.12
    x[185]    c131      -1
    x[185]    c132      1
    x[185]    OBJ       5
    x[186]    c147      -1
    x[186]    c148      1
    x[186]    OBJ       1.35
    x[187]    c163      -1
    x[187]    c164      1
    x[187]    OBJ       3
    x[188]    c179      -1
    x[188]    c180      1
    x[188]    OBJ       1.35
    x[189]    c195      -1
    x[189]    c196      1
    x[189]    OBJ       5
    x[190]    c211      -1
    x[190]    c212      1
    x[190]    OBJ       1.17
    x[191]    c227      -1
    x[191]    c228      1
    x[191]    OBJ       3
    x[192]    c243      -1
    x[192]    c244      1
    x[192]    OBJ       1.17
    x[193]    c259      -1
    x[193]    c260      1
    x[193]    OBJ       5
    x[194]    c275      -1
    x[194]    c276      1
    x[194]    OBJ       1.3
    x[195]    c291      -1
    x[195]    c292      1
    x[195]    OBJ       3
    x[196]    c307      -1
    x[196]    c308      1
    x[196]    OBJ       1.3
    x[197]    c323      -1
    x[197]    c324      1
    x[197]    OBJ       5
    x[198]    c339      -1
    x[198]    c340      1
    x[198]    OBJ       1.22
    x[199]    c355      -1
    x[199]    c356      1
    x[199]    OBJ       3
    x[200]    c371      -1
    x[200]    c372      1
    x[200]    OBJ       1.22
    x[201]    c387      -1
    x[201]    c388      1
    x[201]    OBJ       5
    x[202]    c403      -1
    x[202]    c404      1
    x[202]    OBJ       1.4
    x[203]    c419      -1
    x[203]    c420      1
    x[203]    OBJ       3
    x[204]    c435      -1
    x[204]    c436      1
    x[204]    OBJ       1.4
    x[205]    c451      -1
    x[205]    c452      1
    x[205]    OBJ       5
    x[206]    c467      -1
    x[206]    c468      1
    x[206]    OBJ       1.27
    x[207]    c483      -1
    x[207]    c484      1
    x[207]    OBJ       3
    x[208]    c499      -1
    x[208]    c500      1
    x[208]    OBJ       1.27
    x[209]    c515      -1
    x[209]    c516      1
    x[209]    OBJ       0.1
    x[210]    c531      -1
    x[210]    c532      1
    x[210]    OBJ       0.15
    x[211]    c547      -1
    x[211]    c548      1
    x[211]    OBJ       0.1
    x[212]    c563      -1
    x[212]    c564      1
    x[212]    OBJ       0.15
    x[213]    c579      -1
    x[213]    c580      1
    x[213]    OBJ       0.02
    x[214]    c595      -1
    x[214]    c596      1
    x[214]    OBJ       0.1
    x[215]    c611      -1
    x[215]    c612      1
    x[215]    OBJ       0.02
    x[216]    c627      -1
    x[216]    c628      1
    x[216]    OBJ       0.1
    x[217]    c643      -1
    x[217]    c644      1
    x[217]    OBJ       0.05
    x[218]    c659      -1
    x[218]    c660      1
    x[218]    OBJ       0.3
    x[219]    c675      -1
    x[219]    c676      1
    x[219]    OBJ       0.05
    x[220]    c691      -1
    x[220]    c692      1
    x[220]    OBJ       0.3
    x[221]    c707      -1
    x[221]    c708      1
    x[221]    OBJ       0.02
    x[222]    c723      -1
    x[222]    c724      1
    x[222]    OBJ       0.15
    x[223]    c739      -1
    x[223]    c740      1
    x[223]    OBJ       0.02
    x[224]    c755      -1
    x[224]    c756      1
    x[224]    OBJ       0.15
    x[225]    c771      -1
    x[225]    c772      1
    x[225]    OBJ       0.05
    x[226]    c787      -1
    x[226]    c788      1
    x[226]    OBJ       0.25
    x[227]    c803      -1
    x[227]    c804      1
    x[227]    OBJ       0.05
    x[228]    c819      -1
    x[228]    c820      1
    x[228]    OBJ       0.25
    x[229]    c835      -1
    x[229]    c836      1
    x[229]    OBJ       0.02
    x[230]    c851      -1
    x[230]    c852      1
    x[230]    OBJ       0.2
    x[231]    c867      -1
    x[231]    c868      1
    x[231]    OBJ       0.02
    x[232]    c883      -1
    x[232]    c884      1
    x[232]    OBJ       0.2
    x[233]    c899      -1
    x[233]    c900      1
    x[233]    OBJ       0.05
    x[234]    c915      -1
    x[234]    c916      1
    x[234]    OBJ       0.35
    x[235]    c931      -1
    x[235]    c932      1
    x[235]    OBJ       0.05
    x[236]    c947      -1
    x[236]    c948      1
    x[236]    OBJ       0.35
    x[237]    c963      -1
    x[237]    c964      1
    x[237]    OBJ       0.02
    x[238]    c979      -1
    x[238]    c980      1
    x[238]    OBJ       0.25
    x[239]    c995      -1
    x[239]    c996      1
    x[239]    OBJ       0.02
    x[240]    c1011     -1
    x[240]    c1012     1
    x[240]    OBJ       0.25
    x[241]    c1028     -1
    x[241]    c1029     1
    x[241]    OBJ       6.35
    x[242]    c1044     -1
    x[242]    c1045     1
    x[242]    OBJ       4.35
    x[243]    c1060     -1
    x[243]    c1061     1
    x[243]    OBJ       6.22
    x[244]    c1076     -1
    x[244]    c1077     1
    x[244]    OBJ       4.22
    x[245]    c1092     -1
    x[245]    c1093     1
    x[245]    OBJ       6.45
    x[246]    c1108     -1
    x[246]    c1109     1
    x[246]    OBJ       4.45
    x[247]    c1124     -1
    x[247]    c1125     1
    x[247]    OBJ       6.27
    x[248]    c1140     -1
    x[248]    c1141     1
    x[248]    OBJ       4.27
    x[249]    c1156     -1
    x[249]    c1157     1
    x[249]    OBJ       6.4
    x[250]    c1172     -1
    x[250]    c1173     1
    x[250]    OBJ       4.4
    x[251]    c1188     -1
    x[251]    c1189     1
    x[251]    OBJ       6.32
    x[252]    c1204     -1
    x[252]    c1205     1
    x[252]    OBJ       4.32
    x[253]    c1220     -1
    x[253]    c1221     1
    x[253]    OBJ       6.5
    x[254]    c1236     -1
    x[254]    c1237     1
    x[254]    OBJ       4.5
    x[255]    c1252     -1
    x[255]    c1253     1
    x[255]    OBJ       6.37
    x[256]    c1268     -1
    x[256]    c1269     1
    x[256]    OBJ       4.37
    x[257]    c4        -1
    x[257]    c5        1
    x[257]    OBJ       5
    x[258]    c20       -1
    x[258]    c21       1
    x[258]    OBJ       1.25
    x[259]    c36       -1
    x[259]    c37       1
    x[259]    OBJ       3
    x[260]    c52       -1
    x[260]    c53       1
    x[260]    OBJ       1.25
    x[261]    c68       -1
    x[261]    c69       1
    x[261]    OBJ       5
    x[262]    c84       -1
    x[262]    c85       1
    x[262]    OBJ       1.12
    x[263]    c100      -1
    x[263]    c101      1
    x[263]    OBJ       3
    x[264]    c116      -1
    x[264]    c117      1
    x[264]    OBJ       1.12
    x[265]    c132      -1
    x[265]    c133      1
    x[265]    OBJ       5
    x[266]    c148      -1
    x[266]    c149      1
    x[266]    OBJ       1.35
    x[267]    c164      -1
    x[267]    c165      1
    x[267]    OBJ       3
    x[268]    c180      -1
    x[268]    c181      1
    x[268]    OBJ       1.35
    x[269]    c196      -1
    x[269]    c197      1
    x[269]    OBJ       5
    x[270]    c212      -1
    x[270]    c213      1
    x[270]    OBJ       1.17
    x[271]    c228      -1
    x[271]    c229      1
    x[271]    OBJ       3
    x[272]    c244      -1
    x[272]    c245      1
    x[272]    OBJ       1.17
    x[273]    c260      -1
    x[273]    c261      1
    x[273]    OBJ       5
    x[274]    c276      -1
    x[274]    c277      1
    x[274]    OBJ       1.3
    x[275]    c292      -1
    x[275]    c293      1
    x[275]    OBJ       3
    x[276]    c308      -1
    x[276]    c309      1
    x[276]    OBJ       1.3
    x[277]    c324      -1
    x[277]    c325      1
    x[277]    OBJ       5
    x[278]    c340      -1
    x[278]    c341      1
    x[278]    OBJ       1.22
    x[279]    c356      -1
    x[279]    c357      1
    x[279]    OBJ       3
    x[280]    c372      -1
    x[280]    c373      1
    x[280]    OBJ       1.22
    x[281]    c388      -1
    x[281]    c389      1
    x[281]    OBJ       5
    x[282]    c404      -1
    x[282]    c405      1
    x[282]    OBJ       1.4
    x[283]    c420      -1
    x[283]    c421      1
    x[283]    OBJ       3
    x[284]    c436      -1
    x[284]    c437      1
    x[284]    OBJ       1.4
    x[285]    c452      -1
    x[285]    c453      1
    x[285]    OBJ       5
    x[286]    c468      -1
    x[286]    c469      1
    x[286]    OBJ       1.27
    x[287]    c484      -1
    x[287]    c485      1
    x[287]    OBJ       3
    x[288]    c500      -1
    x[288]    c501      1
    x[288]    OBJ       1.27
    x[289]    c516      -1
    x[289]    c517      1
    x[289]    OBJ       0.1
    x[290]    c532      -1
    x[290]    c533      1
    x[290]    OBJ       0.15
    x[291]    c548      -1
    x[291]    c549      1
    x[291]    OBJ       0.1
    x[292]    c564      -1
    x[292]    c565      1
    x[292]    OBJ       0.15
    x[293]    c580      -1
    x[293]    c581      1
    x[293]    OBJ       0.02
    x[294]    c596      -1
    x[294]    c597      1
    x[294]    OBJ       0.1
    x[295]    c612      -1
    x[295]    c613      1
    x[295]    OBJ       0.02
    x[296]    c628      -1
    x[296]    c629      1
    x[296]    OBJ       0.1
    x[297]    c644      -1
    x[297]    c645      1
    x[297]    OBJ       0.05
    x[298]    c660      -1
    x[298]    c661      1
    x[298]    OBJ       0.3
    x[299]    c676      -1
    x[299]    c677      1
    x[299]    OBJ       0.05
    x[300]    c692      -1
    x[300]    c693      1
    x[300]    OBJ       0.3
    x[301]    c708      -1
    x[301]    c709      1
    x[301]    OBJ       0.02
    x[302]    c724      -1
    x[302]    c725      1
    x[302]    OBJ       0.15
    x[303]    c740      -1
    x[303]    c741      1
    x[303]    OBJ       0.02
    x[304]    c756      -1
    x[304]    c757      1
    x[304]    OBJ       0.15
    x[305]    c772      -1
    x[305]    c773      1
    x[305]    OBJ       0.05
    x[306]    c788      -1
    x[306]    c789      1
    x[306]    OBJ       0.25
    x[307]    c804      -1
    x[307]    c805      1
    x[307]    OBJ       0.05
    x[308]    c820      -1
    x[308]    c821      1
    x[308]    OBJ       0.25
    x[309]    c836      -1
    x[309]    c837      1
    x[309]    OBJ       0.02
    x[310]    c852      -1
    x[310]    c853      1
    x[310]    OBJ       0.2
    x[311]    c868      -1
    x[311]    c869      1
    x[311]    OBJ       0.02
    x[312]    c884      -1
    x[312]    c885      1
    x[312]    OBJ       0.2
    x[313]    c900      -1
    x[313]    c901      1
    x[313]    OBJ       0.05
    x[314]    c916      -1
    x[314]    c917      1
    x[314]    OBJ       0.35
    x[315]    c932      -1
    x[315]    c933      1
    x[315]    OBJ       0.05
    x[316]    c948      -1
    x[316]    c949      1
    x[316]    OBJ       0.35
    x[317]    c964      -1
    x[317]    c965      1
    x[317]    OBJ       0.02
    x[318]    c980      -1
    x[318]    c981      1
    x[318]    OBJ       0.25
    x[319]    c996      -1
    x[319]    c997      1
    x[319]    OBJ       0.02
    x[320]    c1012     -1
    x[320]    c1013     1
    x[320]    OBJ       0.25
    x[321]    c1029     -1
    x[321]    c1030     1
    x[321]    OBJ       6.35
    x[322]    c1045     -1
    x[322]    c1046     1
    x[322]    OBJ       4.35
    x[323]    c1061     -1
    x[323]    c1062     1
    x[323]    OBJ       6.22
    x[324]    c1077     -1
    x[324]    c1078     1
    x[324]    OBJ       4.22
    x[325]    c1093     -1
    x[325]    c1094     1
    x[325]    OBJ       6.45
    x[326]    c1109     -1
    x[326]    c1110     1
    x[326]    OBJ       4.45
    x[327]    c1125     -1
    x[327]    c1126     1
    x[327]    OBJ       6.27
    x[328]    c1141     -1
    x[328]    c1142     1
    x[328]    OBJ       4.27
    x[329]    c1157     -1
    x[329]    c1158     1
    x[329]    OBJ       6.4
    x[330]    c1173     -1
    x[330]    c1174     1
    x[330]    OBJ       4.4
    x[331]    c1189     -1
    x[331]    c1190     1
    x[331]    OBJ       6.32
    x[332]    c1205     -1
    x[332]    c1206     1
    x[332]    OBJ       4.32
    x[333]    c1221     -1
    x[333]    c1222     1
    x[333]    OBJ       6.5
    x[334]    c1237     -1
    x[334]    c1238     1
    x[334]    OBJ       4.5
    x[335]    c1253     -1
    x[335]    c1254     1
    x[335]    OBJ       6.37
    x[336]    c1269     -1
    x[336]    c1270     1
    x[336]    OBJ       4.37
    x[337]    c5        -1
    x[337]    c6        1
    x[337]    OBJ       5
    x[338]    c21       -1
    x[338]    c22       1
    x[338]    OBJ       1.25
    x[339]    c37       -1
    x[339]    c38       1
    x[339]    OBJ       3
    x[340]    c53       -1
    x[340]    c54       1
    x[340]    OBJ       1.25
    x[341]    c69       -1
    x[341]    c70       1
    x[341]    OBJ       5
    x[342]    c85       -1
    x[342]    c86       1
    x[342]    OBJ       1.12
    x[343]    c101      -1
    x[343]    c102      1
    x[343]    OBJ       3
    x[344]    c117      -1
    x[344]    c118      1
    x[344]    OBJ       1.12
    x[345]    c133      -1
    x[345]    c134      1
    x[345]    OBJ       5
    x[346]    c149      -1
    x[346]    c150      1
    x[346]    OBJ       1.35
    x[347]    c165      -1
    x[347]    c166      1
    x[347]    OBJ       3
    x[348]    c181      -1
    x[348]    c182      1
    x[348]    OBJ       1.35
    x[349]    c197      -1
    x[349]    c198      1
    x[349]    OBJ       5
    x[350]    c213      -1
    x[350]    c214      1
    x[350]    OBJ       1.17
    x[351]    c229      -1
    x[351]    c230      1
    x[351]    OBJ       3
    x[352]    c245      -1
    x[352]    c246      1
    x[352]    OBJ       1.17
    x[353]    c261      -1
    x[353]    c262      1
    x[353]    OBJ       5
    x[354]    c277      -1
    x[354]    c278      1
    x[354]    OBJ       1.3
    x[355]    c293      -1
    x[355]    c294      1
    x[355]    OBJ       3
    x[356]    c309      -1
    x[356]    c310      1
    x[356]    OBJ       1.3
    x[357]    c325      -1
    x[357]    c326      1
    x[357]    OBJ       5
    x[358]    c341      -1
    x[358]    c342      1
    x[358]    OBJ       1.22
    x[359]    c357      -1
    x[359]    c358      1
    x[359]    OBJ       3
    x[360]    c373      -1
    x[360]    c374      1
    x[360]    OBJ       1.22
    x[361]    c389      -1
    x[361]    c390      1
    x[361]    OBJ       5
    x[362]    c405      -1
    x[362]    c406      1
    x[362]    OBJ       1.4
    x[363]    c421      -1
    x[363]    c422      1
    x[363]    OBJ       3
    x[364]    c437      -1
    x[364]    c438      1
    x[364]    OBJ       1.4
    x[365]    c453      -1
    x[365]    c454      1
    x[365]    OBJ       5
    x[366]    c469      -1
    x[366]    c470      1
    x[366]    OBJ       1.27
    x[367]    c485      -1
    x[367]    c486      1
    x[367]    OBJ       3
    x[368]    c501      -1
    x[368]    c502      1
    x[368]    OBJ       1.27
    x[369]    c517      -1
    x[369]    c518      1
    x[369]    OBJ       0.1
    x[370]    c533      -1
    x[370]    c534      1
    x[370]    OBJ       0.15
    x[371]    c549      -1
    x[371]    c550      1
    x[371]    OBJ       0.1
    x[372]    c565      -1
    x[372]    c566      1
    x[372]    OBJ       0.15
    x[373]    c581      -1
    x[373]    c582      1
    x[373]    OBJ       0.02
    x[374]    c597      -1
    x[374]    c598      1
    x[374]    OBJ       0.1
    x[375]    c613      -1
    x[375]    c614      1
    x[375]    OBJ       0.02
    x[376]    c629      -1
    x[376]    c630      1
    x[376]    OBJ       0.1
    x[377]    c645      -1
    x[377]    c646      1
    x[377]    OBJ       0.05
    x[378]    c661      -1
    x[378]    c662      1
    x[378]    OBJ       0.3
    x[379]    c677      -1
    x[379]    c678      1
    x[379]    OBJ       0.05
    x[380]    c693      -1
    x[380]    c694      1
    x[380]    OBJ       0.3
    x[381]    c709      -1
    x[381]    c710      1
    x[381]    OBJ       0.02
    x[382]    c725      -1
    x[382]    c726      1
    x[382]    OBJ       0.15
    x[383]    c741      -1
    x[383]    c742      1
    x[383]    OBJ       0.02
    x[384]    c757      -1
    x[384]    c758      1
    x[384]    OBJ       0.15
    x[385]    c773      -1
    x[385]    c774      1
    x[385]    OBJ       0.05
    x[386]    c789      -1
    x[386]    c790      1
    x[386]    OBJ       0.25
    x[387]    c805      -1
    x[387]    c806      1
    x[387]    OBJ       0.05
    x[388]    c821      -1
    x[388]    c822      1
    x[388]    OBJ       0.25
    x[389]    c837      -1
    x[389]    c838      1
    x[389]    OBJ       0.02
    x[390]    c853      -1
    x[390]    c854      1
    x[390]    OBJ       0.2
    x[391]    c869      -1
    x[391]    c870      1
    x[391]    OBJ       0.02
    x[392]    c885      -1
    x[392]    c886      1
    x[392]    OBJ       0.2
    x[393]    c901      -1
    x[393]    c902      1
    x[393]    OBJ       0.05
    x[394]    c917      -1
    x[394]    c918      1
    x[394]    OBJ       0.35
    x[395]    c933      -1
    x[395]    c934      1
    x[395]    OBJ       0.05
    x[396]    c949      -1
    x[396]    c950      1
    x[396]    OBJ       0.35
    x[397]    c965      -1
    x[397]    c966      1
    x[397]    OBJ       0.02
    x[398]    c981      -1
    x[398]    c982      1
    x[398]    OBJ       0.25
    x[399]    c997      -1
    x[399]    c998      1
    x[399]    OBJ       0.02
    x[400]    c1013     -1
    x[400]    c1014     1
    x[400]    OBJ       0.25
    x[401]    c1030     -1
    x[401]    c1031     1
    x[401]    OBJ       6.35
    x[402]    c1046     -1
    x[402]    c1047     1
    x[402]    OBJ       4.35
    x[403]    c1062     -1
    x[403]    c1063     1
    x[403]    OBJ       6.22
    x[404]    c1078     -1
    x[404]    c1079     1
    x[404]    OBJ       4.22
    x[405]    c1094     -1
    x[405]    c1095     1
    x[405]    OBJ       6.45
    x[406]    c1110     -1
    x[406]    c1111     1
    x[406]    OBJ       4.45
    x[407]    c1126     -1
    x[407]    c1127     1
    x[407]    OBJ       6.27
    x[408]    c1142     -1
    x[408]    c1143     1
    x[408]    OBJ       4.27
    x[409]    c1158     -1
    x[409]    c1159     1
    x[409]    OBJ       6.4
    x[410]    c1174     -1
    x[410]    c1175     1
    x[410]    OBJ       4.4
    x[411]    c1190     -1
    x[411]    c1191     1
    x[411]    OBJ       6.32
    x[412]    c1206     -1
    x[412]    c1207     1
    x[412]    OBJ       4.32
    x[413]    c1222     -1
    x[413]    c1223     1
    x[413]    OBJ       6.5
    x[414]    c1238     -1
    x[414]    c1239     1
    x[414]    OBJ       4.5
    x[415]    c1254     -1
    x[415]    c1255     1
    x[415]    OBJ       6.37
    x[416]    c1270     -1
    x[416]    c1271     1
    x[416]    OBJ       4.37
    x[417]    c6        -1
    x[417]    c7        1
    x[417]    OBJ       5
    x[418]    c22       -1
    x[418]    c23       1
    x[418]    OBJ       1.25
    x[419]    c38       -1
    x[419]    c39       1
    x[419]    OBJ       3
    x[420]    c54       -1
    x[420]    c55       1
    x[420]    OBJ       1.25
    x[421]    c70       -1
    x[421]    c71       1
    x[421]    OBJ       5
    x[422]    c86       -1
    x[422]    c87       1
    x[422]    OBJ       1.12
    x[423]    c102      -1
    x[423]    c103      1
    x[423]    OBJ       3
    x[424]    c118      -1
    x[424]    c119      1
    x[424]    OBJ       1.12
    x[425]    c134      -1
    x[425]    c135      1
    x[425]    OBJ       5
    x[426]    c150      -1
    x[426]    c151      1
    x[426]    OBJ       1.35
    x[427]    c166      -1
    x[427]    c167      1
    x[427]    OBJ       3
    x[428]    c182      -1
    x[428]    c183      1
    x[428]    OBJ       1.35
    x[429]    c198      -1
    x[429]    c199      1
    x[429]    OBJ       5
    x[430]    c214      -1
    x[430]    c215      1
    x[430]    OBJ       1.17
    x[431]    c230      -1
    x[431]    c231      1
    x[431]    OBJ       3
    x[432]    c246      -1
    x[432]    c247      1
    x[432]    OBJ       1.17
    x[433]    c262      -1
    x[433]    c263      1
    x[433]    OBJ       5
    x[434]    c278      -1
    x[434]    c279      1
    x[434]    OBJ       1.3
    x[435]    c294      -1
    x[435]    c295      1
    x[435]    OBJ       3
    x[436]    c310      -1
    x[436]    c311      1
    x[436]    OBJ       1.3
    x[437]    c326      -1
    x[437]    c327      1
    x[437]    OBJ       5
    x[438]    c342      -1
    x[438]    c343      1
    x[438]    OBJ       1.22
    x[439]    c358      -1
    x[439]    c359      1
    x[439]    OBJ       3
    x[440]    c374      -1
    x[440]    c375      1
    x[440]    OBJ       1.22
    x[441]    c390      -1
    x[441]    c391      1
    x[441]    OBJ       5
    x[442]    c406      -1
    x[442]    c407      1
    x[442]    OBJ       1.4
    x[443]    c422      -1
    x[443]    c423      1
    x[443]    OBJ       3
    x[444]    c438      -1
    x[444]    c439      1
    x[444]    OBJ       1.4
    x[445]    c454      -1
    x[445]    c455      1
    x[445]    OBJ       5
    x[446]    c470      -1
    x[446]    c471      1
    x[446]    OBJ       1.27
    x[447]    c486      -1
    x[447]    c487      1
    x[447]    OBJ       3
    x[448]    c502      -1
    x[448]    c503      1
    x[448]    OBJ       1.27
    x[449]    c518      -1
    x[449]    c519      1
    x[449]    OBJ       0.1
    x[450]    c534      -1
    x[450]    c535      1
    x[450]    OBJ       0.15
    x[451]    c550      -1
    x[451]    c551      1
    x[451]    OBJ       0.1
    x[452]    c566      -1
    x[452]    c567      1
    x[452]    OBJ       0.15
    x[453]    c582      -1
    x[453]    c583      1
    x[453]    OBJ       0.02
    x[454]    c598      -1
    x[454]    c599      1
    x[454]    OBJ       0.1
    x[455]    c614      -1
    x[455]    c615      1
    x[455]    OBJ       0.02
    x[456]    c630      -1
    x[456]    c631      1
    x[456]    OBJ       0.1
    x[457]    c646      -1
    x[457]    c647      1
    x[457]    OBJ       0.05
    x[458]    c662      -1
    x[458]    c663      1
    x[458]    OBJ       0.3
    x[459]    c678      -1
    x[459]    c679      1
    x[459]    OBJ       0.05
    x[460]    c694      -1
    x[460]    c695      1
    x[460]    OBJ       0.3
    x[461]    c710      -1
    x[461]    c711      1
    x[461]    OBJ       0.02
    x[462]    c726      -1
    x[462]    c727      1
    x[462]    OBJ       0.15
    x[463]    c742      -1
    x[463]    c743      1
    x[463]    OBJ       0.02
    x[464]    c758      -1
    x[464]    c759      1
    x[464]    OBJ       0.15
    x[465]    c774      -1
    x[465]    c775      1
    x[465]    OBJ       0.05
    x[466]    c790      -1
    x[466]    c791      1
    x[466]    OBJ       0.25
    x[467]    c806      -1
    x[467]    c807      1
    x[467]    OBJ       0.05
    x[468]    c822      -1
    x[468]    c823      1
    x[468]    OBJ       0.25
    x[469]    c838      -1
    x[469]    c839      1
    x[469]    OBJ       0.02
    x[470]    c854      -1
    x[470]    c855      1
    x[470]    OBJ       0.2
    x[471]    c870      -1
    x[471]    c871      1
    x[471]    OBJ       0.02
    x[472]    c886      -1
    x[472]    c887      1
    x[472]    OBJ       0.2
    x[473]    c902      -1
    x[473]    c903      1
    x[473]    OBJ       0.05
    x[474]    c918      -1
    x[474]    c919      1
    x[474]    OBJ       0.35
    x[475]    c934      -1
    x[475]    c935      1
    x[475]    OBJ       0.05
    x[476]    c950      -1
    x[476]    c951      1
    x[476]    OBJ       0.35
    x[477]    c966      -1
    x[477]    c967      1
    x[477]    OBJ       0.02
    x[478]    c982      -1
    x[478]    c983      1
    x[478]    OBJ       0.25
    x[479]    c998      -1
    x[479]    c999      1
    x[479]    OBJ       0.02
    x[480]    c1014     -1
    x[480]    c1015     1
    x[480]    OBJ       0.25
    x[481]    c1031     -1
    x[481]    c1032     1
    x[481]    OBJ       6.35
    x[482]    c1047     -1
    x[482]    c1048     1
    x[482]    OBJ       4.35
    x[483]    c1063     -1
    x[483]    c1064     1
    x[483]    OBJ       6.22
    x[484]    c1079     -1
    x[484]    c1080     1
    x[484]    OBJ       4.22
    x[485]    c1095     -1
    x[485]    c1096     1
    x[485]    OBJ       6.45
    x[486]    c1111     -1
    x[486]    c1112     1
    x[486]    OBJ       4.45
    x[487]    c1127     -1
    x[487]    c1128     1
    x[487]    OBJ       6.27
    x[488]    c1143     -1
    x[488]    c1144     1
    x[488]    OBJ       4.27
    x[489]    c1159     -1
    x[489]    c1160     1
    x[489]    OBJ       6.4
    x[490]    c1175     -1
    x[490]    c1176     1
    x[490]    OBJ       4.4
    x[491]    c1191     -1
    x[491]    c1192     1
    x[491]    OBJ       6.32
    x[492]    c1207     -1
    x[492]    c1208     1
    x[492]    OBJ       4.32
    x[493]    c1223     -1
    x[493]    c1224     1
    x[493]    OBJ       6.5
    x[494]    c1239     -1
    x[494]    c1240     1
    x[494]    OBJ       4.5
    x[495]    c1255     -1
    x[495]    c1256     1
    x[495]    OBJ       6.37
    x[496]    c1271     -1
    x[496]    c1272     1
    x[496]    OBJ       4.37
    x[497]    c7        -1
    x[497]    c8        1
    x[497]    OBJ       5
    x[498]    c23       -1
    x[498]    c24       1
    x[498]    OBJ       1.25
    x[499]    c39       -1
    x[499]    c40       1
    x[499]    OBJ       3
    x[500]    c55       -1
    x[500]    c56       1
    x[500]    OBJ       1.25
    x[501]    c71       -1
    x[501]    c72       1
    x[501]    OBJ       5
    x[502]    c87       -1
    x[502]    c88       1
    x[502]    OBJ       1.12
    x[503]    c103      -1
    x[503]    c104      1
    x[503]    OBJ       3
    x[504]    c119      -1
    x[504]    c120      1
    x[504]    OBJ       1.12
    x[505]    c135      -1
    x[505]    c136      1
    x[505]    OBJ       5
    x[506]    c151      -1
    x[506]    c152      1
    x[506]    OBJ       1.35
    x[507]    c167      -1
    x[507]    c168      1
    x[507]    OBJ       3
    x[508]    c183      -1
    x[508]    c184      1
    x[508]    OBJ       1.35
    x[509]    c199      -1
    x[509]    c200      1
    x[509]    OBJ       5
    x[510]    c215      -1
    x[510]    c216      1
    x[510]    OBJ       1.17
    x[511]    c231      -1
    x[511]    c232      1
    x[511]    OBJ       3
    x[512]    c247      -1
    x[512]    c248      1
    x[512]    OBJ       1.17
    x[513]    c263      -1
    x[513]    c264      1
    x[513]    OBJ       5
    x[514]    c279      -1
    x[514]    c280      1
    x[514]    OBJ       1.3
    x[515]    c295      -1
    x[515]    c296      1
    x[515]    OBJ       3
    x[516]    c311      -1
    x[516]    c312      1
    x[516]    OBJ       1.3
    x[517]    c327      -1
    x[517]    c328      1
    x[517]    OBJ       5
    x[518]    c343      -1
    x[518]    c344      1
    x[518]    OBJ       1.22
    x[519]    c359      -1
    x[519]    c360      1
    x[519]    OBJ       3
    x[520]    c375      -1
    x[520]    c376      1
    x[520]    OBJ       1.22
    x[521]    c391      -1
    x[521]    c392      1
    x[521]    OBJ       5
    x[522]    c407      -1
    x[522]    c408      1
    x[522]    OBJ       1.4
    x[523]    c423      -1
    x[523]    c424      1
    x[523]    OBJ       3
    x[524]    c439      -1
    x[524]    c440      1
    x[524]    OBJ       1.4
    x[525]    c455      -1
    x[525]    c456      1
    x[525]    OBJ       5
    x[526]    c471      -1
    x[526]    c472      1
    x[526]    OBJ       1.27
    x[527]    c487      -1
    x[527]    c488      1
    x[527]    OBJ       3
    x[528]    c503      -1
    x[528]    c504      1
    x[528]    OBJ       1.27
    x[529]    c519      -1
    x[529]    c520      1
    x[529]    OBJ       0.1
    x[530]    c535      -1
    x[530]    c536      1
    x[530]    OBJ       0.15
    x[531]    c551      -1
    x[531]    c552      1
    x[531]    OBJ       0.1
    x[532]    c567      -1
    x[532]    c568      1
    x[532]    OBJ       0.15
    x[533]    c583      -1
    x[533]    c584      1
    x[533]    OBJ       0.02
    x[534]    c599      -1
    x[534]    c600      1
    x[534]    OBJ       0.1
    x[535]    c615      -1
    x[535]    c616      1
    x[535]    OBJ       0.02
    x[536]    c631      -1
    x[536]    c632      1
    x[536]    OBJ       0.1
    x[537]    c647      -1
    x[537]    c648      1
    x[537]    OBJ       0.05
    x[538]    c663      -1
    x[538]    c664      1
    x[538]    OBJ       0.3
    x[539]    c679      -1
    x[539]    c680      1
    x[539]    OBJ       0.05
    x[540]    c695      -1
    x[540]    c696      1
    x[540]    OBJ       0.3
    x[541]    c711      -1
    x[541]    c712      1
    x[541]    OBJ       0.02
    x[542]    c727      -1
    x[542]    c728      1
    x[542]    OBJ       0.15
    x[543]    c743      -1
    x[543]    c744      1
    x[543]    OBJ       0.02
    x[544]    c759      -1
    x[544]    c760      1
    x[544]    OBJ       0.15
    x[545]    c775      -1
    x[545]    c776      1
    x[545]    OBJ       0.05
    x[546]    c791      -1
    x[546]    c792      1
    x[546]    OBJ       0.25
    x[547]    c807      -1
    x[547]    c808      1
    x[547]    OBJ       0.05
    x[548]    c823      -1
    x[548]    c824      1
    x[548]    OBJ       0.25
    x[549]    c839      -1
    x[549]    c840      1
    x[549]    OBJ       0.02
    x[550]    c855      -1
    x[550]    c856      1
    x[550]    OBJ       0.2
    x[551]    c871      -1
    x[551]    c872      1
    x[551]    OBJ       0.02
    x[552]    c887      -1
    x[552]    c888      1
    x[552]    OBJ       0.2
    x[553]    c903      -1
    x[553]    c904      1
    x[553]    OBJ       0.05
    x[554]    c919      -1
    x[554]    c920      1
    x[554]    OBJ       0.35
    x[555]    c935      -1
    x[555]    c936      1
    x[555]    OBJ       0.05
    x[556]    c951      -1
    x[556]    c952      1
    x[556]    OBJ       0.35
    x[557]    c967      -1
    x[557]    c968      1
    x[557]    OBJ       0.02
    x[558]    c983      -1
    x[558]    c984      1
    x[558]    OBJ       0.25
    x[559]    c999      -1
    x[559]    c1000     1
    x[559]    OBJ       0.02
    x[560]    c1015     -1
    x[560]    c1016     1
    x[560]    OBJ       0.25
    x[561]    c1032     -1
    x[561]    c1033     1
    x[561]    OBJ       6.35
    x[562]    c1048     -1
    x[562]    c1049     1
    x[562]    OBJ       4.35
    x[563]    c1064     -1
    x[563]    c1065     1
    x[563]    OBJ       6.22
    x[564]    c1080     -1
    x[564]    c1081     1
    x[564]    OBJ       4.22
    x[565]    c1096     -1
    x[565]    c1097     1
    x[565]    OBJ       6.45
    x[566]    c1112     -1
    x[566]    c1113     1
    x[566]    OBJ       4.45
    x[567]    c1128     -1
    x[567]    c1129     1
    x[567]    OBJ       6.27
    x[568]    c1144     -1
    x[568]    c1145     1
    x[568]    OBJ       4.27
    x[569]    c1160     -1
    x[569]    c1161     1
    x[569]    OBJ       6.4
    x[570]    c1176     -1
    x[570]    c1177     1
    x[570]    OBJ       4.4
    x[571]    c1192     -1
    x[571]    c1193     1
    x[571]    OBJ       6.32
    x[572]    c1208     -1
    x[572]    c1209     1
    x[572]    OBJ       4.32
    x[573]    c1224     -1
    x[573]    c1225     1
    x[573]    OBJ       6.5
    x[574]    c1240     -1
    x[574]    c1241     1
    x[574]    OBJ       4.5
    x[575]    c1256     -1
    x[575]    c1257     1
    x[575]    OBJ       6.37
    x[576]    c1272     -1
    x[576]    c1273     1
    x[576]    OBJ       4.37
    x[577]    c8        -1
    x[577]    c9        1
    x[577]    OBJ       5
    x[578]    c24       -1
    x[578]    c25       1
    x[578]    OBJ       1.25
    x[579]    c40       -1
    x[579]    c41       1
    x[579]    OBJ       3
    x[580]    c56       -1
    x[580]    c57       1
    x[580]    OBJ       1.25
    x[581]    c72       -1
    x[581]    c73       1
    x[581]    OBJ       5
    x[582]    c88       -1
    x[582]    c89       1
    x[582]    OBJ       1.12
    x[583]    c104      -1
    x[583]    c105      1
    x[583]    OBJ       3
    x[584]    c120      -1
    x[584]    c121      1
    x[584]    OBJ       1.12
    x[585]    c136      -1
    x[585]    c137      1
    x[585]    OBJ       5
    x[586]    c152      -1
    x[586]    c153      1
    x[586]    OBJ       1.35
    x[587]    c168      -1
    x[587]    c169      1
    x[587]    OBJ       3
    x[588]    c184      -1
    x[588]    c185      1
    x[588]    OBJ       1.35
    x[589]    c200      -1
    x[589]    c201      1
    x[589]    OBJ       5
    x[590]    c216      -1
    x[590]    c217      1
    x[590]    OBJ       1.17
    x[591]    c232      -1
    x[591]    c233      1
    x[591]    OBJ       3
    x[592]    c248      -1
    x[592]    c249      1
    x[592]    OBJ       1.17
    x[593]    c264      -1
    x[593]    c265      1
    x[593]    OBJ       5
    x[594]    c280      -1
    x[594]    c281      1
    x[594]    OBJ       1.3
    x[595]    c296      -1
    x[595]    c297      1
    x[595]    OBJ       3
    x[596]    c312      -1
    x[596]    c313      1
    x[596]    OBJ       1.3
    x[597]    c328      -1
    x[597]    c329      1
    x[597]    OBJ       5
    x[598]    c344      -1
    x[598]    c345      1
    x[598]    OBJ       1.22
    x[599]    c360      -1
    x[599]    c361      1
    x[599]    OBJ       3
    x[600]    c376      -1
    x[600]    c377      1
    x[600]    OBJ       1.22
    x[601]    c392      -1
    x[601]    c393      1
    x[601]    OBJ       5
    x[602]    c408      -1
    x[602]    c409      1
    x[602]    OBJ       1.4
    x[603]    c424      -1
    x[603]    c425      1
    x[603]    OBJ       3
    x[604]    c440      -1
    x[604]    c441      1
    x[604]    OBJ       1.4
    x[605]    c456      -1
    x[605]    c457      1
    x[605]    OBJ       5
    x[606]    c472      -1
    x[606]    c473      1
    x[606]    OBJ       1.27
    x[607]    c488      -1
    x[607]    c489      1
    x[607]    OBJ       3
    x[608]    c504      -1
    x[608]    c505      1
    x[608]    OBJ       1.27
    x[609]    c520      -1
    x[609]    c521      1
    x[609]    OBJ       0.1
    x[610]    c536      -1
    x[610]    c537      1
    x[610]    OBJ       0.15
    x[611]    c552      -1
    x[611]    c553      1
    x[611]    OBJ       0.1
    x[612]    c568      -1
    x[612]    c569      1
    x[612]    OBJ       0.15
    x[613]    c584      -1
    x[613]    c585      1
    x[613]    OBJ       0.02
    x[614]    c600      -1
    x[614]    c601      1
    x[614]    OBJ       0.1
    x[615]    c616      -1
    x[615]    c617      1
    x[615]    OBJ       0.02
    x[616]    c632      -1
    x[616]    c633      1
    x[616]    OBJ       0.1
    x[617]    c648      -1
    x[617]    c649      1
    x[617]    OBJ       0.05
    x[618]    c664      -1
    x[618]    c665      1
    x[618]    OBJ       0.3
    x[619]    c680      -1
    x[619]    c681      1
    x[619]    OBJ       0.05
    x[620]    c696      -1
    x[620]    c697      1
    x[620]    OBJ       0.3
    x[621]    c712      -1
    x[621]    c713      1
    x[621]    OBJ       0.02
    x[622]    c728      -1
    x[622]    c729      1
    x[622]    OBJ       0.15
    x[623]    c744      -1
    x[623]    c745      1
    x[623]    OBJ       0.02
    x[624]    c760      -1
    x[624]    c761      1
    x[624]    OBJ       0.15
    x[625]    c776      -1
    x[625]    c777      1
    x[625]    OBJ       0.05
    x[626]    c792      -1
    x[626]    c793      1
    x[626]    OBJ       0.25
    x[627]    c808      -1
    x[627]    c809      1
    x[627]    OBJ       0.05
    x[628]    c824      -1
    x[628]    c825      1
    x[628]    OBJ       0.25
    x[629]    c840      -1
    x[629]    c841      1
    x[629]    OBJ       0.02
    x[630]    c856      -1
    x[630]    c857      1
    x[630]    OBJ       0.2
    x[631]    c872      -1
    x[631]    c873      1
    x[631]    OBJ       0.02
    x[632]    c888      -1
    x[632]    c889      1
    x[632]    OBJ       0.2
    x[633]    c904      -1
    x[633]    c905      1
    x[633]    OBJ       0.05
    x[634]    c920      -1
    x[634]    c921      1
    x[634]    OBJ       0.35
    x[635]    c936      -1
    x[635]    c937      1
    x[635]    OBJ       0.05
    x[636]    c952      -1
    x[636]    c953      1
    x[636]    OBJ       0.35
    x[637]    c968      -1
    x[637]    c969      1
    x[637]    OBJ       0.02
    x[638]    c984      -1
    x[638]    c985      1
    x[638]    OBJ       0.25
    x[639]    c1000     -1
    x[639]    c1001     1
    x[639]    OBJ       0.02
    x[640]    c1016     -1
    x[640]    c1017     1
    x[640]    OBJ       0.25
    x[641]    c1033     -1
    x[641]    c1034     1
    x[641]    OBJ       6.35
    x[642]    c1049     -1
    x[642]    c1050     1
    x[642]    OBJ       4.35
    x[643]    c1065     -1
    x[643]    c1066     1
    x[643]    OBJ       6.22
    x[644]    c1081     -1
    x[644]    c1082     1
    x[644]    OBJ       4.22
    x[645]    c1097     -1
    x[645]    c1098     1
    x[645]    OBJ       6.45
    x[646]    c1113     -1
    x[646]    c1114     1
    x[646]    OBJ       4.45
    x[647]    c1129     -1
    x[647]    c1130     1
    x[647]    OBJ       6.27
    x[648]    c1145     -1
    x[648]    c1146     1
    x[648]    OBJ       4.27
    x[649]    c1161     -1
    x[649]    c1162     1
    x[649]    OBJ       6.4
    x[650]    c1177     -1
    x[650]    c1178     1
    x[650]    OBJ       4.4
    x[651]    c1193     -1
    x[651]    c1194     1
    x[651]    OBJ       6.32
    x[652]    c1209     -1
    x[652]    c1210     1
    x[652]    OBJ       4.32
    x[653]    c1225     -1
    x[653]    c1226     1
    x[653]    OBJ       6.5
    x[654]    c1241     -1
    x[654]    c1242     1
    x[654]    OBJ       4.5
    x[655]    c1257     -1
    x[655]    c1258     1
    x[655]    OBJ       6.37
    x[656]    c1273     -1
    x[656]    c1274     1
    x[656]    OBJ       4.37
    x[657]    c9        -1
    x[657]    c10       1
    x[657]    OBJ       5
    x[658]    c25       -1
    x[658]    c26       1
    x[658]    OBJ       1.25
    x[659]    c41       -1
    x[659]    c42       1
    x[659]    OBJ       3
    x[660]    c57       -1
    x[660]    c58       1
    x[660]    OBJ       1.25
    x[661]    c73       -1
    x[661]    c74       1
    x[661]    OBJ       5
    x[662]    c89       -1
    x[662]    c90       1
    x[662]    OBJ       1.12
    x[663]    c105      -1
    x[663]    c106      1
    x[663]    OBJ       3
    x[664]    c121      -1
    x[664]    c122      1
    x[664]    OBJ       1.12
    x[665]    c137      -1
    x[665]    c138      1
    x[665]    OBJ       5
    x[666]    c153      -1
    x[666]    c154      1
    x[666]    OBJ       1.35
    x[667]    c169      -1
    x[667]    c170      1
    x[667]    OBJ       3
    x[668]    c185      -1
    x[668]    c186      1
    x[668]    OBJ       1.35
    x[669]    c201      -1
    x[669]    c202      1
    x[669]    OBJ       5
    x[670]    c217      -1
    x[670]    c218      1
    x[670]    OBJ       1.17
    x[671]    c233      -1
    x[671]    c234      1
    x[671]    OBJ       3
    x[672]    c249      -1
    x[672]    c250      1
    x[672]    OBJ       1.17
    x[673]    c265      -1
    x[673]    c266      1
    x[673]    OBJ       5
    x[674]    c281      -1
    x[674]    c282      1
    x[674]    OBJ       1.3
    x[675]    c297      -1
    x[675]    c298      1
    x[675]    OBJ       3
    x[676]    c313      -1
    x[676]    c314      1
    x[676]    OBJ       1.3
    x[677]    c329      -1
    x[677]    c330      1
    x[677]    OBJ       5
    x[678]    c345      -1
    x[678]    c346      1
    x[678]    OBJ       1.22
    x[679]    c361      -1
    x[679]    c362      1
    x[679]    OBJ       3
    x[680]    c377      -1
    x[680]    c378      1
    x[680]    OBJ       1.22
    x[681]    c393      -1
    x[681]    c394      1
    x[681]    OBJ       5
    x[682]    c409      -1
    x[682]    c410      1
    x[682]    OBJ       1.4
    x[683]    c425      -1
    x[683]    c426      1
    x[683]    OBJ       3
    x[684]    c441      -1
    x[684]    c442      1
    x[684]    OBJ       1.4
    x[685]    c457      -1
    x[685]    c458      1
    x[685]    OBJ       5
    x[686]    c473      -1
    x[686]    c474      1
    x[686]    OBJ       1.27
    x[687]    c489      -1
    x[687]    c490      1
    x[687]    OBJ       3
    x[688]    c505      -1
    x[688]    c506      1
    x[688]    OBJ       1.27
    x[689]    c521      -1
    x[689]    c522      1
    x[689]    OBJ       0.1
    x[690]    c537      -1
    x[690]    c538      1
    x[690]    OBJ       0.15
    x[691]    c553      -1
    x[691]    c554      1
    x[691]    OBJ       0.1
    x[692]    c569      -1
    x[692]    c570      1
    x[692]    OBJ       0.15
    x[693]    c585      -1
    x[693]    c586      1
    x[693]    OBJ       0.02
    x[694]    c601      -1
    x[694]    c602      1
    x[694]    OBJ       0.1
    x[695]    c617      -1
    x[695]    c618      1
    x[695]    OBJ       0.02
    x[696]    c633      -1
    x[696]    c634      1
    x[696]    OBJ       0.1
    x[697]    c649      -1
    x[697]    c650      1
    x[697]    OBJ       0.05
    x[698]    c665      -1
    x[698]    c666      1
    x[698]    OBJ       0.3
    x[699]    c681      -1
    x[699]    c682      1
    x[699]    OBJ       0.05
    x[700]    c697      -1
    x[700]    c698      1
    x[700]    OBJ       0.3
    x[701]    c713      -1
    x[701]    c714      1
    x[701]    OBJ       0.02
    x[702]    c729      -1
    x[702]    c730      1
    x[702]    OBJ       0.15
    x[703]    c745      -1
    x[703]    c746      1
    x[703]    OBJ       0.02
    x[704]    c761      -1
    x[704]    c762      1
    x[704]    OBJ       0.15
    x[705]    c777      -1
    x[705]    c778      1
    x[705]    OBJ       0.05
    x[706]    c793      -1
    x[706]    c794      1
    x[706]    OBJ       0.25
    x[707]    c809      -1
    x[707]    c810      1
    x[707]    OBJ       0.05
    x[708]    c825      -1
    x[708]    c826      1
    x[708]    OBJ       0.25
    x[709]    c841      -1
    x[709]    c842      1
    x[709]    OBJ       0.02
    x[710]    c857      -1
    x[710]    c858      1
    x[710]    OBJ       0.2
    x[711]    c873      -1
    x[711]    c874      1
    x[711]    OBJ       0.02
    x[712]    c889      -1
    x[712]    c890      1
    x[712]    OBJ       0.2
    x[713]    c905      -1
    x[713]    c906      1
    x[713]    OBJ       0.05
    x[714]    c921      -1
    x[714]    c922      1
    x[714]    OBJ       0.35
    x[715]    c937      -1
    x[715]    c938      1
    x[715]    OBJ       0.05
    x[716]    c953      -1
    x[716]    c954      1
    x[716]    OBJ       0.35
    x[717]    c969      -1
    x[717]    c970      1
    x[717]    OBJ       0.02
    x[718]    c985      -1
    x[718]    c986      1
    x[718]    OBJ       0.25
    x[719]    c1001     -1
    x[719]    c1002     1
    x[719]    OBJ       0.02
    x[720]    c1017     -1
    x[720]    c1018     1
    x[720]    OBJ       0.25
    x[721]    c1034     -1
    x[721]    c1035     1
    x[721]    OBJ       6.35
    x[722]    c1050     -1
    x[722]    c1051     1
    x[722]    OBJ       4.35
    x[723]    c1066     -1
    x[723]    c1067     1
    x[723]    OBJ       6.22
    x[724]    c1082     -1
    x[724]    c1083     1
    x[724]    OBJ       4.22
    x[725]    c1098     -1
    x[725]    c1099     1
    x[725]    OBJ       6.45
    x[726]    c1114     -1
    x[726]    c1115     1
    x[726]    OBJ       4.45
    x[727]    c1130     -1
    x[727]    c1131     1
    x[727]    OBJ       6.27
    x[728]    c1146     -1
    x[728]    c1147     1
    x[728]    OBJ       4.27
    x[729]    c1162     -1
    x[729]    c1163     1
    x[729]    OBJ       6.4
    x[730]    c1178     -1
    x[730]    c1179     1
    x[730]    OBJ       4.4
    x[731]    c1194     -1
    x[731]    c1195     1
    x[731]    OBJ       6.32
    x[732]    c1210     -1
    x[732]    c1211     1
    x[732]    OBJ       4.32
    x[733]    c1226     -1
    x[733]    c1227     1
    x[733]    OBJ       6.5
    x[734]    c1242     -1
    x[734]    c1243     1
    x[734]    OBJ       4.5
    x[735]    c1258     -1
    x[735]    c1259     1
    x[735]    OBJ       6.37
    x[736]    c1274     -1
    x[736]    c1275     1
    x[736]    OBJ       4.37
    x[737]    c10       -1
    x[737]    c11       1
    x[737]    OBJ       5
    x[738]    c26       -1
    x[738]    c27       1
    x[738]    OBJ       1.25
    x[739]    c42       -1
    x[739]    c43       1
    x[739]    OBJ       3
    x[740]    c58       -1
    x[740]    c59       1
    x[740]    OBJ       1.25
    x[741]    c74       -1
    x[741]    c75       1
    x[741]    OBJ       5
    x[742]    c90       -1
    x[742]    c91       1
    x[742]    OBJ       1.12
    x[743]    c106      -1
    x[743]    c107      1
    x[743]    OBJ       3
    x[744]    c122      -1
    x[744]    c123      1
    x[744]    OBJ       1.12
    x[745]    c138      -1
    x[745]    c139      1
    x[745]    OBJ       5
    x[746]    c154      -1
    x[746]    c155      1
    x[746]    OBJ       1.35
    x[747]    c170      -1
    x[747]    c171      1
    x[747]    OBJ       3
    x[748]    c186      -1
    x[748]    c187      1
    x[748]    OBJ       1.35
    x[749]    c202      -1
    x[749]    c203      1
    x[749]    OBJ       5
    x[750]    c218      -1
    x[750]    c219      1
    x[750]    OBJ       1.17
    x[751]    c234      -1
    x[751]    c235      1
    x[751]    OBJ       3
    x[752]    c250      -1
    x[752]    c251      1
    x[752]    OBJ       1.17
    x[753]    c266      -1
    x[753]    c267      1
    x[753]    OBJ       5
    x[754]    c282      -1
    x[754]    c283      1
    x[754]    OBJ       1.3
    x[755]    c298      -1
    x[755]    c299      1
    x[755]    OBJ       3
    x[756]    c314      -1
    x[756]    c315      1
    x[756]    OBJ       1.3
    x[757]    c330      -1
    x[757]    c331      1
    x[757]    OBJ       5
    x[758]    c346      -1
    x[758]    c347      1
    x[758]    OBJ       1.22
    x[759]    c362      -1
    x[759]    c363      1
    x[759]    OBJ       3
    x[760]    c378      -1
    x[760]    c379      1
    x[760]    OBJ       1.22
    x[761]    c394      -1
    x[761]    c395      1
    x[761]    OBJ       5
    x[762]    c410      -1
    x[762]    c411      1
    x[762]    OBJ       1.4
    x[763]    c426      -1
    x[763]    c427      1
    x[763]    OBJ       3
    x[764]    c442      -1
    x[764]    c443      1
    x[764]    OBJ       1.4
    x[765]    c458      -1
    x[765]    c459      1
    x[765]    OBJ       5
    x[766]    c474      -1
    x[766]    c475      1
    x[766]    OBJ       1.27
    x[767]    c490      -1
    x[767]    c491      1
    x[767]    OBJ       3
    x[768]    c506      -1
    x[768]    c507      1
    x[768]    OBJ       1.27
    x[769]    c522      -1
    x[769]    c523      1
    x[769]    OBJ       0.1
    x[770]    c538      -1
    x[770]    c539      1
    x[770]    OBJ       0.15
    x[771]    c554      -1
    x[771]    c555      1
    x[771]    OBJ       0.1
    x[772]    c570      -1
    x[772]    c571      1
    x[772]    OBJ       0.15
    x[773]    c586      -1
    x[773]    c587      1
    x[773]    OBJ       0.02
    x[774]    c602      -1
    x[774]    c603      1
    x[774]    OBJ       0.1
    x[775]    c618      -1
    x[775]    c619      1
    x[775]    OBJ       0.02
    x[776]    c634      -1
    x[776]    c635      1
    x[776]    OBJ       0.1
    x[777]    c650      -1
    x[777]    c651      1
    x[777]    OBJ       0.05
    x[778]    c666      -1
    x[778]    c667      1
    x[778]    OBJ       0.3
    x[779]    c682      -1
    x[779]    c683      1
    x[779]    OBJ       0.05
    x[780]    c698      -1
    x[780]    c699      1
    x[780]    OBJ       0.3
    x[781]    c714      -1
    x[781]    c715      1
    x[781]    OBJ       0.02
    x[782]    c730      -1
    x[782]    c731      1
    x[782]    OBJ       0.15
    x[783]    c746      -1
    x[783]    c747      1
    x[783]    OBJ       0.02
    x[784]    c762      -1
    x[784]    c763      1
    x[784]    OBJ       0.15
    x[785]    c778      -1
    x[785]    c779      1
    x[785]    OBJ       0.05
    x[786]    c794      -1
    x[786]    c795      1
    x[786]    OBJ       0.25
    x[787]    c810      -1
    x[787]    c811      1
    x[787]    OBJ       0.05
    x[788]    c826      -1
    x[788]    c827      1
    x[788]    OBJ       0.25
    x[789]    c842      -1
    x[789]    c843      1
    x[789]    OBJ       0.02
    x[790]    c858      -1
    x[790]    c859      1
    x[790]    OBJ       0.2
    x[791]    c874      -1
    x[791]    c875      1
    x[791]    OBJ       0.02
    x[792]    c890      -1
    x[792]    c891      1
    x[792]    OBJ       0.2
    x[793]    c906      -1
    x[793]    c907      1
    x[793]    OBJ       0.05
    x[794]    c922      -1
    x[794]    c923      1
    x[794]    OBJ       0.35
    x[795]    c938      -1
    x[795]    c939      1
    x[795]    OBJ       0.05
    x[796]    c954      -1
    x[796]    c955      1
    x[796]    OBJ       0.35
    x[797]    c970      -1
    x[797]    c971      1
    x[797]    OBJ       0.02
    x[798]    c986      -1
    x[798]    c987      1
    x[798]    OBJ       0.25
    x[799]    c1002     -1
    x[799]    c1003     1
    x[799]    OBJ       0.02
    x[800]    c1018     -1
    x[800]    c1019     1
    x[800]    OBJ       0.25
    x[801]    c1035     -1
    x[801]    c1036     1
    x[801]    OBJ       6.35
    x[802]    c1051     -1
    x[802]    c1052     1
    x[802]    OBJ       4.35
    x[803]    c1067     -1
    x[803]    c1068     1
    x[803]    OBJ       6.22
    x[804]    c1083     -1
    x[804]    c1084     1
    x[804]    OBJ       4.22
    x[805]    c1099     -1
    x[805]    c1100     1
    x[805]    OBJ       6.45
    x[806]    c1115     -1
    x[806]    c1116     1
    x[806]    OBJ       4.45
    x[807]    c1131     -1
    x[807]    c1132     1
    x[807]    OBJ       6.27
    x[808]    c1147     -1
    x[808]    c1148     1
    x[808]    OBJ       4.27
    x[809]    c1163     -1
    x[809]    c1164     1
    x[809]    OBJ       6.4
    x[810]    c1179     -1
    x[810]    c1180     1
    x[810]    OBJ       4.4
    x[811]    c1195     -1
    x[811]    c1196     1
    x[811]    OBJ       6.32
    x[812]    c1211     -1
    x[812]    c1212     1
    x[812]    OBJ       4.32
    x[813]    c1227     -1
    x[813]    c1228     1
    x[813]    OBJ       6.5
    x[814]    c1243     -1
    x[814]    c1244     1
    x[814]    OBJ       4.5
    x[815]    c1259     -1
    x[815]    c1260     1
    x[815]    OBJ       6.37
    x[816]    c1275     -1
    x[816]    c1276     1
    x[816]    OBJ       4.37
    x[817]    c11       -1
    x[817]    c12       1
    x[817]    OBJ       5
    x[818]    c27       -1
    x[818]    c28       1
    x[818]    OBJ       1.25
    x[819]    c43       -1
    x[819]    c44       1
    x[819]    OBJ       3
    x[820]    c59       -1
    x[820]    c60       1
    x[820]    OBJ       1.25
    x[821]    c75       -1
    x[821]    c76       1
    x[821]    OBJ       5
    x[822]    c91       -1
    x[822]    c92       1
    x[822]    OBJ       1.12
    x[823]    c107      -1
    x[823]    c108      1
    x[823]    OBJ       3
    x[824]    c123      -1
    x[824]    c124      1
    x[824]    OBJ       1.12
    x[825]    c139      -1
    x[825]    c140      1
    x[825]    OBJ       5
    x[826]    c155      -1
    x[826]    c156      1
    x[826]    OBJ       1.35
    x[827]    c171      -1
    x[827]    c172      1
    x[827]    OBJ       3
    x[828]    c187      -1
    x[828]    c188      1
    x[828]    OBJ       1.35
    x[829]    c203      -1
    x[829]    c204      1
    x[829]    OBJ       5
    x[830]    c219      -1
    x[830]    c220      1
    x[830]    OBJ       1.17
    x[831]    c235      -1
    x[831]    c236      1
    x[831]    OBJ       3
    x[832]    c251      -1
    x[832]    c252      1
    x[832]    OBJ       1.17
    x[833]    c267      -1
    x[833]    c268      1
    x[833]    OBJ       5
    x[834]    c283      -1
    x[834]    c284      1
    x[834]    OBJ       1.3
    x[835]    c299      -1
    x[835]    c300      1
    x[835]    OBJ       3
    x[836]    c315      -1
    x[836]    c316      1
    x[836]    OBJ       1.3
    x[837]    c331      -1
    x[837]    c332      1
    x[837]    OBJ       5
    x[838]    c347      -1
    x[838]    c348      1
    x[838]    OBJ       1.22
    x[839]    c363      -1
    x[839]    c364      1
    x[839]    OBJ       3
    x[840]    c379      -1
    x[840]    c380      1
    x[840]    OBJ       1.22
    x[841]    c395      -1
    x[841]    c396      1
    x[841]    OBJ       5
    x[842]    c411      -1
    x[842]    c412      1
    x[842]    OBJ       1.4
    x[843]    c427      -1
    x[843]    c428      1
    x[843]    OBJ       3
    x[844]    c443      -1
    x[844]    c444      1
    x[844]    OBJ       1.4
    x[845]    c459      -1
    x[845]    c460      1
    x[845]    OBJ       5
    x[846]    c475      -1
    x[846]    c476      1
    x[846]    OBJ       1.27
    x[847]    c491      -1
    x[847]    c492      1
    x[847]    OBJ       3
    x[848]    c507      -1
    x[848]    c508      1
    x[848]    OBJ       1.27
    x[849]    c523      -1
    x[849]    c524      1
    x[849]    OBJ       0.1
    x[850]    c539      -1
    x[850]    c540      1
    x[850]    OBJ       0.15
    x[851]    c555      -1
    x[851]    c556      1
    x[851]    OBJ       0.1
    x[852]    c571      -1
    x[852]    c572      1
    x[852]    OBJ       0.15
    x[853]    c587      -1
    x[853]    c588      1
    x[853]    OBJ       0.02
    x[854]    c603      -1
    x[854]    c604      1
    x[854]    OBJ       0.1
    x[855]    c619      -1
    x[855]    c620      1
    x[855]    OBJ       0.02
    x[856]    c635      -1
    x[856]    c636      1
    x[856]    OBJ       0.1
    x[857]    c651      -1
    x[857]    c652      1
    x[857]    OBJ       0.05
    x[858]    c667      -1
    x[858]    c668      1
    x[858]    OBJ       0.3
    x[859]    c683      -1
    x[859]    c684      1
    x[859]    OBJ       0.05
    x[860]    c699      -1
    x[860]    c700      1
    x[860]    OBJ       0.3
    x[861]    c715      -1
    x[861]    c716      1
    x[861]    OBJ       0.02
    x[862]    c731      -1
    x[862]    c732      1
    x[862]    OBJ       0.15
    x[863]    c747      -1
    x[863]    c748      1
    x[863]    OBJ       0.02
    x[864]    c763      -1
    x[864]    c764      1
    x[864]    OBJ       0.15
    x[865]    c779      -1
    x[865]    c780      1
    x[865]    OBJ       0.05
    x[866]    c795      -1
    x[866]    c796      1
    x[866]    OBJ       0.25
    x[867]    c811      -1
    x[867]    c812      1
    x[867]    OBJ       0.05
    x[868]    c827      -1
    x[868]    c828      1
    x[868]    OBJ       0.25
    x[869]    c843      -1
    x[869]    c844      1
    x[869]    OBJ       0.02
    x[870]    c859      -1
    x[870]    c860      1
    x[870]    OBJ       0.2
    x[871]    c875      -1
    x[871]    c876      1
    x[871]    OBJ       0.02
    x[872]    c891      -1
    x[872]    c892      1
    x[872]    OBJ       0.2
    x[873]    c907      -1
    x[873]    c908      1
    x[873]    OBJ       0.05
    x[874]    c923      -1
    x[874]    c924      1
    x[874]    OBJ       0.35
    x[875]    c939      -1
    x[875]    c940      1
    x[875]    OBJ       0.05
    x[876]    c955      -1
    x[876]    c956      1
    x[876]    OBJ       0.35
    x[877]    c971      -1
    x[877]    c972      1
    x[877]    OBJ       0.02
    x[878]    c987      -1
    x[878]    c988      1
    x[878]    OBJ       0.25
    x[879]    c1003     -1
    x[879]    c1004     1
    x[879]    OBJ       0.02
    x[880]    c1019     -1
    x[880]    c1020     1
    x[880]    OBJ       0.25
    x[881]    c1036     -1
    x[881]    c1037     1
    x[881]    OBJ       6.35
    x[882]    c1052     -1
    x[882]    c1053     1
    x[882]    OBJ       4.35
    x[883]    c1068     -1
    x[883]    c1069     1
    x[883]    OBJ       6.22
    x[884]    c1084     -1
    x[884]    c1085     1
    x[884]    OBJ       4.22
    x[885]    c1100     -1
    x[885]    c1101     1
    x[885]    OBJ       6.45
    x[886]    c1116     -1
    x[886]    c1117     1
    x[886]    OBJ       4.45
    x[887]    c1132     -1
    x[887]    c1133     1
    x[887]    OBJ       6.27
    x[888]    c1148     -1
    x[888]    c1149     1
    x[888]    OBJ       4.27
    x[889]    c1164     -1
    x[889]    c1165     1
    x[889]    OBJ       6.4
    x[890]    c1180     -1
    x[890]    c1181     1
    x[890]    OBJ       4.4
    x[891]    c1196     -1
    x[891]    c1197     1
    x[891]    OBJ       6.32
    x[892]    c1212     -1
    x[892]    c1213     1
    x[892]    OBJ       4.32
    x[893]    c1228     -1
    x[893]    c1229     1
    x[893]    OBJ       6.5
    x[894]    c1244     -1
    x[894]    c1245     1
    x[894]    OBJ       4.5
    x[895]    c1260     -1
    x[895]    c1261     1
    x[895]    OBJ       6.37
    x[896]    c1276     -1
    x[896]    c1277     1
    x[896]    OBJ       4.37
    x[897]    c12       -1
    x[897]    c13       1
    x[897]    OBJ       5
    x[898]    c28       -1
    x[898]    c29       1
    x[898]    OBJ       1.25
    x[899]    c44       -1
    x[899]    c45       1
    x[899]    OBJ       3
    x[900]    c60       -1
    x[900]    c61       1
    x[900]    OBJ       1.25
    x[901]    c76       -1
    x[901]    c77       1
    x[901]    OBJ       5
    x[902]    c92       -1
    x[902]    c93       1
    x[902]    OBJ       1.12
    x[903]    c108      -1
    x[903]    c109      1
    x[903]    OBJ       3
    x[904]    c124      -1
    x[904]    c125      1
    x[904]    OBJ       1.12
    x[905]    c140      -1
    x[905]    c141      1
    x[905]    OBJ       5
    x[906]    c156      -1
    x[906]    c157      1
    x[906]    OBJ       1.35
    x[907]    c172      -1
    x[907]    c173      1
    x[907]    OBJ       3
    x[908]    c188      -1
    x[908]    c189      1
    x[908]    OBJ       1.35
    x[909]    c204      -1
    x[909]    c205      1
    x[909]    OBJ       5
    x[910]    c220      -1
    x[910]    c221      1
    x[910]    OBJ       1.17
    x[911]    c236      -1
    x[911]    c237      1
    x[911]    OBJ       3
    x[912]    c252      -1
    x[912]    c253      1
    x[912]    OBJ       1.17
    x[913]    c268      -1
    x[913]    c269      1
    x[913]    OBJ       5
    x[914]    c284      -1
    x[914]    c285      1
    x[914]    OBJ       1.3
    x[915]    c300      -1
    x[915]    c301      1
    x[915]    OBJ       3
    x[916]    c316      -1
    x[916]    c317      1
    x[916]    OBJ       1.3
    x[917]    c332      -1
    x[917]    c333      1
    x[917]    OBJ       5
    x[918]    c348      -1
    x[918]    c349      1
    x[918]    OBJ       1.22
    x[919]    c364      -1
    x[919]    c365      1
    x[919]    OBJ       3
    x[920]    c380      -1
    x[920]    c381      1
    x[920]    OBJ       1.22
    x[921]    c396      -1
    x[921]    c397      1
    x[921]    OBJ       5
    x[922]    c412      -1
    x[922]    c413      1
    x[922]    OBJ       1.4
    x[923]    c428      -1
    x[923]    c429      1
    x[923]    OBJ       3
    x[924]    c444      -1
    x[924]    c445      1
    x[924]    OBJ       1.4
    x[925]    c460      -1
    x[925]    c461      1
    x[925]    OBJ       5
    x[926]    c476      -1
    x[926]    c477      1
    x[926]    OBJ       1.27
    x[927]    c492      -1
    x[927]    c493      1
    x[927]    OBJ       3
    x[928]    c508      -1
    x[928]    c509      1
    x[928]    OBJ       1.27
    x[929]    c524      -1
    x[929]    c525      1
    x[929]    OBJ       0.1
    x[930]    c540      -1
    x[930]    c541      1
    x[930]    OBJ       0.15
    x[931]    c556      -1
    x[931]    c557      1
    x[931]    OBJ       0.1
    x[932]    c572      -1
    x[932]    c573      1
    x[932]    OBJ       0.15
    x[933]    c588      -1
    x[933]    c589      1
    x[933]    OBJ       0.02
    x[934]    c604      -1
    x[934]    c605      1
    x[934]    OBJ       0.1
    x[935]    c620      -1
    x[935]    c621      1
    x[935]    OBJ       0.02
    x[936]    c636      -1
    x[936]    c637      1
    x[936]    OBJ       0.1
    x[937]    c652      -1
    x[937]    c653      1
    x[937]    OBJ       0.05
    x[938]    c668      -1
    x[938]    c669      1
    x[938]    OBJ       0.3
    x[939]    c684      -1
    x[939]    c685      1
    x[939]    OBJ       0.05
    x[940]    c700      -1
    x[940]    c701      1
    x[940]    OBJ       0.3
    x[941]    c716      -1
    x[941]    c717      1
    x[941]    OBJ       0.02
    x[942]    c732      -1
    x[942]    c733      1
    x[942]    OBJ       0.15
    x[943]    c748      -1
    x[943]    c749      1
    x[943]    OBJ       0.02
    x[944]    c764      -1
    x[944]    c765      1
    x[944]    OBJ       0.15
    x[945]    c780      -1
    x[945]    c781      1
    x[945]    OBJ       0.05
    x[946]    c796      -1
    x[946]    c797      1
    x[946]    OBJ       0.25
    x[947]    c812      -1
    x[947]    c813      1
    x[947]    OBJ       0.05
    x[948]    c828      -1
    x[948]    c829      1
    x[948]    OBJ       0.25
    x[949]    c844      -1
    x[949]    c845      1
    x[949]    OBJ       0.02
    x[950]    c860      -1
    x[950]    c861      1
    x[950]    OBJ       0.2
    x[951]    c876      -1
    x[951]    c877      1
    x[951]    OBJ       0.02
    x[952]    c892      -1
    x[952]    c893      1
    x[952]    OBJ       0.2
    x[953]    c908      -1
    x[953]    c909      1
    x[953]    OBJ       0.05
    x[954]    c924      -1
    x[954]    c925      1
    x[954]    OBJ       0.35
    x[955]    c940      -1
    x[955]    c941      1
    x[955]    OBJ       0.05
    x[956]    c956      -1
    x[956]    c957      1
    x[956]    OBJ       0.35
    x[957]    c972      -1
    x[957]    c973      1
    x[957]    OBJ       0.02
    x[958]    c988      -1
    x[958]    c989      1
    x[958]    OBJ       0.25
    x[959]    c1004     -1
    x[959]    c1005     1
    x[959]    OBJ       0.02
    x[960]    c1020     -1
    x[960]    c1021     1
    x[960]    OBJ       0.25
    x[961]    c1037     -1
    x[961]    c1038     1
    x[961]    OBJ       6.35
    x[962]    c1053     -1
    x[962]    c1054     1
    x[962]    OBJ       4.35
    x[963]    c1069     -1
    x[963]    c1070     1
    x[963]    OBJ       6.22
    x[964]    c1085     -1
    x[964]    c1086     1
    x[964]    OBJ       4.22
    x[965]    c1101     -1
    x[965]    c1102     1
    x[965]    OBJ       6.45
    x[966]    c1117     -1
    x[966]    c1118     1
    x[966]    OBJ       4.45
    x[967]    c1133     -1
    x[967]    c1134     1
    x[967]    OBJ       6.27
    x[968]    c1149     -1
    x[968]    c1150     1
    x[968]    OBJ       4.27
    x[969]    c1165     -1
    x[969]    c1166     1
    x[969]    OBJ       6.4
    x[970]    c1181     -1
    x[970]    c1182     1
    x[970]    OBJ       4.4
    x[971]    c1197     -1
    x[971]    c1198     1
    x[971]    OBJ       6.32
    x[972]    c1213     -1
    x[972]    c1214     1
    x[972]    OBJ       4.32
    x[973]    c1229     -1
    x[973]    c1230     1
    x[973]    OBJ       6.5
    x[974]    c1245     -1
    x[974]    c1246     1
    x[974]    OBJ       4.5
    x[975]    c1261     -1
    x[975]    c1262     1
    x[975]    OBJ       6.37
    x[976]    c1277     -1
    x[976]    c1278     1
    x[976]    OBJ       4.37
    x[977]    c13       -1
    x[977]    c14       1
    x[977]    OBJ       5
    x[978]    c29       -1
    x[978]    c30       1
    x[978]    OBJ       1.25
    x[979]    c45       -1
    x[979]    c46       1
    x[979]    OBJ       3
    x[980]    c61       -1
    x[980]    c62       1
    x[980]    OBJ       1.25
    x[981]    c77       -1
    x[981]    c78       1
    x[981]    OBJ       5
    x[982]    c93       -1
    x[982]    c94       1
    x[982]    OBJ       1.12
    x[983]    c109      -1
    x[983]    c110      1
    x[983]    OBJ       3
    x[984]    c125      -1
    x[984]    c126      1
    x[984]    OBJ       1.12
    x[985]    c141      -1
    x[985]    c142      1
    x[985]    OBJ       5
    x[986]    c157      -1
    x[986]    c158      1
    x[986]    OBJ       1.35
    x[987]    c173      -1
    x[987]    c174      1
    x[987]    OBJ       3
    x[988]    c189      -1
    x[988]    c190      1
    x[988]    OBJ       1.35
    x[989]    c205      -1
    x[989]    c206      1
    x[989]    OBJ       5
    x[990]    c221      -1
    x[990]    c222      1
    x[990]    OBJ       1.17
    x[991]    c237      -1
    x[991]    c238      1
    x[991]    OBJ       3
    x[992]    c253      -1
    x[992]    c254      1
    x[992]    OBJ       1.17
    x[993]    c269      -1
    x[993]    c270      1
    x[993]    OBJ       5
    x[994]    c285      -1
    x[994]    c286      1
    x[994]    OBJ       1.3
    x[995]    c301      -1
    x[995]    c302      1
    x[995]    OBJ       3
    x[996]    c317      -1
    x[996]    c318      1
    x[996]    OBJ       1.3
    x[997]    c333      -1
    x[997]    c334      1
    x[997]    OBJ       5
    x[998]    c349      -1
    x[998]    c350      1
    x[998]    OBJ       1.22
    x[999]    c365      -1
    x[999]    c366      1
    x[999]    OBJ       3
    x[1000]   c381      -1
    x[1000]   c382      1
    x[1000]   OBJ       1.22
    x[1001]   c397      -1
    x[1001]   c398      1
    x[1001]   OBJ       5
    x[1002]   c413      -1
    x[1002]   c414      1
    x[1002]   OBJ       1.4
    x[1003]   c429      -1
    x[1003]   c430      1
    x[1003]   OBJ       3
    x[1004]   c445      -1
    x[1004]   c446      1
    x[1004]   OBJ       1.4
    x[1005]   c461      -1
    x[1005]   c462      1
    x[1005]   OBJ       5
    x[1006]   c477      -1
    x[1006]   c478      1
    x[1006]   OBJ       1.27
    x[1007]   c493      -1
    x[1007]   c494      1
    x[1007]   OBJ       3
    x[1008]   c509      -1
    x[1008]   c510      1
    x[1008]   OBJ       1.27
    x[1009]   c525      -1
    x[1009]   c526      1
    x[1009]   OBJ       0.1
    x[1010]   c541      -1
    x[1010]   c542      1
    x[1010]   OBJ       0.15
    x[1011]   c557      -1
    x[1011]   c558      1
    x[1011]   OBJ       0.1
    x[1012]   c573      -1
    x[1012]   c574      1
    x[1012]   OBJ       0.15
    x[1013]   c589      -1
    x[1013]   c590      1
    x[1013]   OBJ       0.02
    x[1014]   c605      -1
    x[1014]   c606      1
    x[1014]   OBJ       0.1
    x[1015]   c621      -1
    x[1015]   c622      1
    x[1015]   OBJ       0.02
    x[1016]   c637      -1
    x[1016]   c638      1
    x[1016]   OBJ       0.1
    x[1017]   c653      -1
    x[1017]   c654      1
    x[1017]   OBJ       0.05
    x[1018]   c669      -1
    x[1018]   c670      1
    x[1018]   OBJ       0.3
    x[1019]   c685      -1
    x[1019]   c686      1
    x[1019]   OBJ       0.05
    x[1020]   c701      -1
    x[1020]   c702      1
    x[1020]   OBJ       0.3
    x[1021]   c717      -1
    x[1021]   c718      1
    x[1021]   OBJ       0.02
    x[1022]   c733      -1
    x[1022]   c734      1
    x[1022]   OBJ       0.15
    x[1023]   c749      -1
    x[1023]   c750      1
    x[1023]   OBJ       0.02
    x[1024]   c765      -1
    x[1024]   c766      1
    x[1024]   OBJ       0.15
    x[1025]   c781      -1
    x[1025]   c782      1
    x[1025]   OBJ       0.05
    x[1026]   c797      -1
    x[1026]   c798      1
    x[1026]   OBJ       0.25
    x[1027]   c813      -1
    x[1027]   c814      1
    x[1027]   OBJ       0.05
    x[1028]   c829      -1
    x[1028]   c830      1
    x[1028]   OBJ       0.25
    x[1029]   c845      -1
    x[1029]   c846      1
    x[1029]   OBJ       0.02
    x[1030]   c861      -1
    x[1030]   c862      1
    x[1030]   OBJ       0.2
    x[1031]   c877      -1
    x[1031]   c878      1
    x[1031]   OBJ       0.02
    x[1032]   c893      -1
    x[1032]   c894      1
    x[1032]   OBJ       0.2
    x[1033]   c909      -1
    x[1033]   c910      1
    x[1033]   OBJ       0.05
    x[1034]   c925      -1
    x[1034]   c926      1
    x[1034]   OBJ       0.35
    x[1035]   c941      -1
    x[1035]   c942      1
    x[1035]   OBJ       0.05
    x[1036]   c957      -1
    x[1036]   c958      1
    x[1036]   OBJ       0.35
    x[1037]   c973      -1
    x[1037]   c974      1
    x[1037]   OBJ       0.02
    x[1038]   c989      -1
    x[1038]   c990      1
    x[1038]   OBJ       0.25
    x[1039]   c1005     -1
    x[1039]   c1006     1
    x[1039]   OBJ       0.02
    x[1040]   c1021     -1
    x[1040]   c1022     1
    x[1040]   OBJ       0.25
    x[1041]   c1038     -1
    x[1041]   c1039     1
    x[1041]   OBJ       6.35
    x[1042]   c1054     -1
    x[1042]   c1055     1
    x[1042]   OBJ       4.35
    x[1043]   c1070     -1
    x[1043]   c1071     1
    x[1043]   OBJ       6.22
    x[1044]   c1086     -1
    x[1044]   c1087     1
    x[1044]   OBJ       4.22
    x[1045]   c1102     -1
    x[1045]   c1103     1
    x[1045]   OBJ       6.45
    x[1046]   c1118     -1
    x[1046]   c1119     1
    x[1046]   OBJ       4.45
    x[1047]   c1134     -1
    x[1047]   c1135     1
    x[1047]   OBJ       6.27
    x[1048]   c1150     -1
    x[1048]   c1151     1
    x[1048]   OBJ       4.27
    x[1049]   c1166     -1
    x[1049]   c1167     1
    x[1049]   OBJ       6.4
    x[1050]   c1182     -1
    x[1050]   c1183     1
    x[1050]   OBJ       4.4
    x[1051]   c1198     -1
    x[1051]   c1199     1
    x[1051]   OBJ       6.32
    x[1052]   c1214     -1
    x[1052]   c1215     1
    x[1052]   OBJ       4.32
    x[1053]   c1230     -1
    x[1053]   c1231     1
    x[1053]   OBJ       6.5
    x[1054]   c1246     -1
    x[1054]   c1247     1
    x[1054]   OBJ       4.5
    x[1055]   c1262     -1
    x[1055]   c1263     1
    x[1055]   OBJ       6.37
    x[1056]   c1278     -1
    x[1056]   c1279     1
    x[1056]   OBJ       4.37
    x[1057]   c14       -1
    x[1057]   c15       1
    x[1057]   OBJ       5
    x[1058]   c30       -1
    x[1058]   c31       1
    x[1058]   OBJ       1.25
    x[1059]   c46       -1
    x[1059]   c47       1
    x[1059]   OBJ       3
    x[1060]   c62       -1
    x[1060]   c63       1
    x[1060]   OBJ       1.25
    x[1061]   c78       -1
    x[1061]   c79       1
    x[1061]   OBJ       5
    x[1062]   c94       -1
    x[1062]   c95       1
    x[1062]   OBJ       1.12
    x[1063]   c110      -1
    x[1063]   c111      1
    x[1063]   OBJ       3
    x[1064]   c126      -1
    x[1064]   c127      1
    x[1064]   OBJ       1.12
    x[1065]   c142      -1
    x[1065]   c143      1
    x[1065]   OBJ       5
    x[1066]   c158      -1
    x[1066]   c159      1
    x[1066]   OBJ       1.35
    x[1067]   c174      -1
    x[1067]   c175      1
    x[1067]   OBJ       3
    x[1068]   c190      -1
    x[1068]   c191      1
    x[1068]   OBJ       1.35
    x[1069]   c206      -1
    x[1069]   c207      1
    x[1069]   OBJ       5
    x[1070]   c222      -1
    x[1070]   c223      1
    x[1070]   OBJ       1.17
    x[1071]   c238      -1
    x[1071]   c239      1
    x[1071]   OBJ       3
    x[1072]   c254      -1
    x[1072]   c255      1
    x[1072]   OBJ       1.17
    x[1073]   c270      -1
    x[1073]   c271      1
    x[1073]   OBJ       5
    x[1074]   c286      -1
    x[1074]   c287      1
    x[1074]   OBJ       1.3
    x[1075]   c302      -1
    x[1075]   c303      1
    x[1075]   OBJ       3
    x[1076]   c318      -1
    x[1076]   c319      1
    x[1076]   OBJ       1.3
    x[1077]   c334      -1
    x[1077]   c335      1
    x[1077]   OBJ       5
    x[1078]   c350      -1
    x[1078]   c351      1
    x[1078]   OBJ       1.22
    x[1079]   c366      -1
    x[1079]   c367      1
    x[1079]   OBJ       3
    x[1080]   c382      -1
    x[1080]   c383      1
    x[1080]   OBJ       1.22
    x[1081]   c398      -1
    x[1081]   c399      1
    x[1081]   OBJ       5
    x[1082]   c414      -1
    x[1082]   c415      1
    x[1082]   OBJ       1.4
    x[1083]   c430      -1
    x[1083]   c431      1
    x[1083]   OBJ       3
    x[1084]   c446      -1
    x[1084]   c447      1
    x[1084]   OBJ       1.4
    x[1085]   c462      -1
    x[1085]   c463      1
    x[1085]   OBJ       5
    x[1086]   c478      -1
    x[1086]   c479      1
    x[1086]   OBJ       1.27
    x[1087]   c494      -1
    x[1087]   c495      1
    x[1087]   OBJ       3
    x[1088]   c510      -1
    x[1088]   c511      1
    x[1088]   OBJ       1.27
    x[1089]   c526      -1
    x[1089]   c527      1
    x[1089]   OBJ       0.1
    x[1090]   c542      -1
    x[1090]   c543      1
    x[1090]   OBJ       0.15
    x[1091]   c558      -1
    x[1091]   c559      1
    x[1091]   OBJ       0.1
    x[1092]   c574      -1
    x[1092]   c575      1
    x[1092]   OBJ       0.15
    x[1093]   c590      -1
    x[1093]   c591      1
    x[1093]   OBJ       0.02
    x[1094]   c606      -1
    x[1094]   c607      1
    x[1094]   OBJ       0.1
    x[1095]   c622      -1
    x[1095]   c623      1
    x[1095]   OBJ       0.02
    x[1096]   c638      -1
    x[1096]   c639      1
    x[1096]   OBJ       0.1
    x[1097]   c654      -1
    x[1097]   c655      1
    x[1097]   OBJ       0.05
    x[1098]   c670      -1
    x[1098]   c671      1
    x[1098]   OBJ       0.3
    x[1099]   c686      -1
    x[1099]   c687      1
    x[1099]   OBJ       0.05
    x[1100]   c702      -1
    x[1100]   c703      1
    x[1100]   OBJ       0.3
    x[1101]   c718      -1
    x[1101]   c719      1
    x[1101]   OBJ       0.02
    x[1102]   c734      -1
    x[1102]   c735      1
    x[1102]   OBJ       0.15
    x[1103]   c750      -1
    x[1103]   c751      1
    x[1103]   OBJ       0.02
    x[1104]   c766      -1
    x[1104]   c767      1
    x[1104]   OBJ       0.15
    x[1105]   c782      -1
    x[1105]   c783      1
    x[1105]   OBJ       0.05
    x[1106]   c798      -1
    x[1106]   c799      1
    x[1106]   OBJ       0.25
    x[1107]   c814      -1
    x[1107]   c815      1
    x[1107]   OBJ       0.05
    x[1108]   c830      -1
    x[1108]   c831      1
    x[1108]   OBJ       0.25
    x[1109]   c846      -1
    x[1109]   c847      1
    x[1109]   OBJ       0.02
    x[1110]   c862      -1
    x[1110]   c863      1
    x[1110]   OBJ       0.2
    x[1111]   c878      -1
    x[1111]   c879      1
    x[1111]   OBJ       0.02
    x[1112]   c894      -1
    x[1112]   c895      1
    x[1112]   OBJ       0.2
    x[1113]   c910      -1
    x[1113]   c911      1
    x[1113]   OBJ       0.05
    x[1114]   c926      -1
    x[1114]   c927      1
    x[1114]   OBJ       0.35
    x[1115]   c942      -1
    x[1115]   c943      1
    x[1115]   OBJ       0.05
    x[1116]   c958      -1
    x[1116]   c959      1
    x[1116]   OBJ       0.35
    x[1117]   c974      -1
    x[1117]   c975      1
    x[1117]   OBJ       0.02
    x[1118]   c990      -1
    x[1118]   c991      1
    x[1118]   OBJ       0.25
    x[1119]   c1006     -1
    x[1119]   c1007     1
    x[1119]   OBJ       0.02
    x[1120]   c1022     -1
    x[1120]   c1023     1
    x[1120]   OBJ       0.25
    x[1121]   c1039     -1
    x[1121]   c1040     1
    x[1121]   OBJ       6.35
    x[1122]   c1055     -1
    x[1122]   c1056     1
    x[1122]   OBJ       4.35
    x[1123]   c1071     -1
    x[1123]   c1072     1
    x[1123]   OBJ       6.22
    x[1124]   c1087     -1
    x[1124]   c1088     1
    x[1124]   OBJ       4.22
    x[1125]   c1103     -1
    x[1125]   c1104     1
    x[1125]   OBJ       6.45
    x[1126]   c1119     -1
    x[1126]   c1120     1
    x[1126]   OBJ       4.45
    x[1127]   c1135     -1
    x[1127]   c1136     1
    x[1127]   OBJ       6.27
    x[1128]   c1151     -1
    x[1128]   c1152     1
    x[1128]   OBJ       4.27
    x[1129]   c1167     -1
    x[1129]   c1168     1
    x[1129]   OBJ       6.4
    x[1130]   c1183     -1
    x[1130]   c1184     1
    x[1130]   OBJ       4.4
    x[1131]   c1199     -1
    x[1131]   c1200     1
    x[1131]   OBJ       6.32
    x[1132]   c1215     -1
    x[1132]   c1216     1
    x[1132]   OBJ       4.32
    x[1133]   c1231     -1
    x[1133]   c1232     1
    x[1133]   OBJ       6.5
    x[1134]   c1247     -1
    x[1134]   c1248     1
    x[1134]   OBJ       4.5
    x[1135]   c1263     -1
    x[1135]   c1264     1
    x[1135]   OBJ       6.37
    x[1136]   c1279     -1
    x[1136]   c1280     1
    x[1136]   OBJ       4.37
    x[1137]   c15       -1
    x[1137]   c16       1
    x[1137]   OBJ       5
    x[1138]   c31       -1
    x[1138]   c32       1
    x[1138]   OBJ       1.25
    x[1139]   c47       -1
    x[1139]   c48       1
    x[1139]   OBJ       3
    x[1140]   c63       -1
    x[1140]   c64       1
    x[1140]   OBJ       1.25
    x[1141]   c79       -1
    x[1141]   c80       1
    x[1141]   OBJ       5
    x[1142]   c95       -1
    x[1142]   c96       1
    x[1142]   OBJ       1.12
    x[1143]   c111      -1
    x[1143]   c112      1
    x[1143]   OBJ       3
    x[1144]   c127      -1
    x[1144]   c128      1
    x[1144]   OBJ       1.12
    x[1145]   c143      -1
    x[1145]   c144      1
    x[1145]   OBJ       5
    x[1146]   c159      -1
    x[1146]   c160      1
    x[1146]   OBJ       1.35
    x[1147]   c175      -1
    x[1147]   c176      1
    x[1147]   OBJ       3
    x[1148]   c191      -1
    x[1148]   c192      1
    x[1148]   OBJ       1.35
    x[1149]   c207      -1
    x[1149]   c208      1
    x[1149]   OBJ       5
    x[1150]   c223      -1
    x[1150]   c224      1
    x[1150]   OBJ       1.17
    x[1151]   c239      -1
    x[1151]   c240      1
    x[1151]   OBJ       3
    x[1152]   c255      -1
    x[1152]   c256      1
    x[1152]   OBJ       1.17
    x[1153]   c271      -1
    x[1153]   c272      1
    x[1153]   OBJ       5
    x[1154]   c287      -1
    x[1154]   c288      1
    x[1154]   OBJ       1.3
    x[1155]   c303      -1
    x[1155]   c304      1
    x[1155]   OBJ       3
    x[1156]   c319      -1
    x[1156]   c320      1
    x[1156]   OBJ       1.3
    x[1157]   c335      -1
    x[1157]   c336      1
    x[1157]   OBJ       5
    x[1158]   c351      -1
    x[1158]   c352      1
    x[1158]   OBJ       1.22
    x[1159]   c367      -1
    x[1159]   c368      1
    x[1159]   OBJ       3
    x[1160]   c383      -1
    x[1160]   c384      1
    x[1160]   OBJ       1.22
    x[1161]   c399      -1
    x[1161]   c400      1
    x[1161]   OBJ       5
    x[1162]   c415      -1
    x[1162]   c416      1
    x[1162]   OBJ       1.4
    x[1163]   c431      -1
    x[1163]   c432      1
    x[1163]   OBJ       3
    x[1164]   c447      -1
    x[1164]   c448      1
    x[1164]   OBJ       1.4
    x[1165]   c463      -1
    x[1165]   c464      1
    x[1165]   OBJ       5
    x[1166]   c479      -1
    x[1166]   c480      1
    x[1166]   OBJ       1.27
    x[1167]   c495      -1
    x[1167]   c496      1
    x[1167]   OBJ       3
    x[1168]   c511      -1
    x[1168]   c512      1
    x[1168]   OBJ       1.27
    x[1169]   c527      -1
    x[1169]   c528      1
    x[1169]   OBJ       0.1
    x[1170]   c543      -1
    x[1170]   c544      1
    x[1170]   OBJ       0.15
    x[1171]   c559      -1
    x[1171]   c560      1
    x[1171]   OBJ       0.1
    x[1172]   c575      -1
    x[1172]   c576      1
    x[1172]   OBJ       0.15
    x[1173]   c591      -1
    x[1173]   c592      1
    x[1173]   OBJ       0.02
    x[1174]   c607      -1
    x[1174]   c608      1
    x[1174]   OBJ       0.1
    x[1175]   c623      -1
    x[1175]   c624      1
    x[1175]   OBJ       0.02
    x[1176]   c639      -1
    x[1176]   c640      1
    x[1176]   OBJ       0.1
    x[1177]   c655      -1
    x[1177]   c656      1
    x[1177]   OBJ       0.05
    x[1178]   c671      -1
    x[1178]   c672      1
    x[1178]   OBJ       0.3
    x[1179]   c687      -1
    x[1179]   c688      1
    x[1179]   OBJ       0.05
    x[1180]   c703      -1
    x[1180]   c704      1
    x[1180]   OBJ       0.3
    x[1181]   c719      -1
    x[1181]   c720      1
    x[1181]   OBJ       0.02
    x[1182]   c735      -1
    x[1182]   c736      1
    x[1182]   OBJ       0.15
    x[1183]   c751      -1
    x[1183]   c752      1
    x[1183]   OBJ       0.02
    x[1184]   c767      -1
    x[1184]   c768      1
    x[1184]   OBJ       0.15
    x[1185]   c783      -1
    x[1185]   c784      1
    x[1185]   OBJ       0.05
    x[1186]   c799      -1
    x[1186]   c800      1
    x[1186]   OBJ       0.25
    x[1187]   c815      -1
    x[1187]   c816      1
    x[1187]   OBJ       0.05
    x[1188]   c831      -1
    x[1188]   c832      1
    x[1188]   OBJ       0.25
    x[1189]   c847      -1
    x[1189]   c848      1
    x[1189]   OBJ       0.02
    x[1190]   c863      -1
    x[1190]   c864      1
    x[1190]   OBJ       0.2
    x[1191]   c879      -1
    x[1191]   c880      1
    x[1191]   OBJ       0.02
    x[1192]   c895      -1
    x[1192]   c896      1
    x[1192]   OBJ       0.2
    x[1193]   c911      -1
    x[1193]   c912      1
    x[1193]   OBJ       0.05
    x[1194]   c927      -1
    x[1194]   c928      1
    x[1194]   OBJ       0.35
    x[1195]   c943      -1
    x[1195]   c944      1
    x[1195]   OBJ       0.05
    x[1196]   c959      -1
    x[1196]   c960      1
    x[1196]   OBJ       0.35
    x[1197]   c975      -1
    x[1197]   c976      1
    x[1197]   OBJ       0.02
    x[1198]   c991      -1
    x[1198]   c992      1
    x[1198]   OBJ       0.25
    x[1199]   c1007     -1
    x[1199]   c1008     1
    x[1199]   OBJ       0.02
    x[1200]   c1023     -1
    x[1200]   c1024     1
    x[1200]   OBJ       0.25
    x[1201]   c1040     -1
    x[1201]   OBJ       6.35
    x[1202]   c1056     -1
    x[1202]   OBJ       4.35
    x[1203]   c1072     -1
    x[1203]   OBJ       6.22
    x[1204]   c1088     -1
    x[1204]   OBJ       4.22
    x[1205]   c1104     -1
    x[1205]   OBJ       6.45
    x[1206]   c1120     -1
    x[1206]   OBJ       4.45
    x[1207]   c1136     -1
    x[1207]   OBJ       6.27
    x[1208]   c1152     -1
    x[1208]   OBJ       4.27
    x[1209]   c1168     -1
    x[1209]   OBJ       6.4
    x[1210]   c1184     -1
    x[1210]   OBJ       4.4
    x[1211]   c1200     -1
    x[1211]   OBJ       6.32
    x[1212]   c1216     -1
    x[1212]   OBJ       4.32
    x[1213]   c1232     -1
    x[1213]   OBJ       6.5
    x[1214]   c1248     -1
    x[1214]   OBJ       4.5
    x[1215]   c1264     -1
    x[1215]   OBJ       6.37
    x[1216]   c1280     -1
    x[1216]   OBJ       4.37
    x[1217]   c16       -1
    x[1217]   OBJ       5
    x[1218]   c32       -1
    x[1218]   OBJ       1.25
    x[1219]   c48       -1
    x[1219]   OBJ       3
    x[1220]   c64       -1
    x[1220]   OBJ       1.25
    x[1221]   c80       -1
    x[1221]   OBJ       5
    x[1222]   c96       -1
    x[1222]   OBJ       1.12
    x[1223]   c112      -1
    x[1223]   OBJ       3
    x[1224]   c128      -1
    x[1224]   OBJ       1.12
    x[1225]   c144      -1
    x[1225]   OBJ       5
    x[1226]   c160      -1
    x[1226]   OBJ       1.35
    x[1227]   c176      -1
    x[1227]   OBJ       3
    x[1228]   c192      -1
    x[1228]   OBJ       1.35
    x[1229]   c208      -1
    x[1229]   OBJ       5
    x[1230]   c224      -1
    x[1230]   OBJ       1.17
    x[1231]   c240      -1
    x[1231]   OBJ       3
    x[1232]   c256      -1
    x[1232]   OBJ       1.17
    x[1233]   c272      -1
    x[1233]   OBJ       5
    x[1234]   c288      -1
    x[1234]   OBJ       1.3
    x[1235]   c304      -1
    x[1235]   OBJ       3
    x[1236]   c320      -1
    x[1236]   OBJ       1.3
    x[1237]   c336      -1
    x[1237]   OBJ       5
    x[1238]   c352      -1
    x[1238]   OBJ       1.22
    x[1239]   c368      -1
    x[1239]   OBJ       3
    x[1240]   c384      -1
    x[1240]   OBJ       1.22
    x[1241]   c400      -1
    x[1241]   OBJ       5
    x[1242]   c416      -1
    x[1242]   OBJ       1.4
    x[1243]   c432      -1
    x[1243]   OBJ       3
    x[1244]   c448      -1
    x[1244]   OBJ       1.4
    x[1245]   c464      -1
    x[1245]   OBJ       5
    x[1246]   c480      -1
    x[1246]   OBJ       1.27
    x[1247]   c496      -1
    x[1247]   OBJ       3
    x[1248]   c512      -1
    x[1248]   OBJ       1.27
    x[1249]   c528      -1
    x[1249]   OBJ       0.1
    x[1250]   c544      -1
    x[1250]   OBJ       0.15
    x[1251]   c560      -1
    x[1251]   OBJ       0.1
    x[1252]   c576      -1
    x[1252]   OBJ       0.15
    x[1253]   c592      -1
    x[1253]   OBJ       0.02
    x[1254]   c608      -1
    x[1254]   OBJ       0.1
    x[1255]   c624      -1
    x[1255]   OBJ       0.02
    x[1256]   c640      -1
    x[1256]   OBJ       0.1
    x[1257]   c656      -1
    x[1257]   OBJ       0.05
    x[1258]   c672      -1
    x[1258]   OBJ       0.3
    x[1259]   c688      -1
    x[1259]   OBJ       0.05
    x[1260]   c704      -1
    x[1260]   OBJ       0.3
    x[1261]   c720      -1
    x[1261]   OBJ       0.02
    x[1262]   c736      -1
    x[1262]   OBJ       0.15
    x[1263]   c752      -1
    x[1263]   OBJ       0.02
    x[1264]   c768      -1
    x[1264]   OBJ       0.15
    x[1265]   c784      -1
    x[1265]   OBJ       0.05
    x[1266]   c800      -1
    x[1266]   OBJ       0.25
    x[1267]   c816      -1
    x[1267]   OBJ       0.05
    x[1268]   c832      -1
    x[1268]   OBJ       0.25
    x[1269]   c848      -1
    x[1269]   OBJ       0.02
    x[1270]   c864      -1
    x[1270]   OBJ       0.2
    x[1271]   c880      -1
    x[1271]   OBJ       0.02
    x[1272]   c896      -1
    x[1272]   OBJ       0.2
    x[1273]   c912      -1
    x[1273]   OBJ       0.05
    x[1274]   c928      -1
    x[1274]   OBJ       0.35
    x[1275]   c944      -1
    x[1275]   OBJ       0.05
    x[1276]   c960      -1
    x[1276]   OBJ       0.35
    x[1277]   c976      -1
    x[1277]   OBJ       0.02
    x[1278]   c992      -1
    x[1278]   OBJ       0.25
    x[1279]   c1008     -1
    x[1279]   OBJ       0.02
    x[1280]   c1024     -1
    x[1280]   OBJ       0.25
    MARKER    'MARKER'                 'INTORG'
    x[1281]   c2049     -1
    x[1281]   c2081     -1
    x[1281]   c2113     -1
    x[1281]   c2129     -1
    x[1281]   c2145     -1
    x[1281]   c2161     -1
    x[1281]   c2177     -1
    x[1281]   c2209     -1
    x[1281]   c2241     -1
    x[1281]   c2257     -1
    x[1281]   c2273     -1
    x[1281]   c2289     -1
    x[1281]   c2305     -1
    x[1281]   c2337     -1
    x[1281]   c2369     -1
    x[1281]   c2385     -1
    x[1281]   c2401     -1
    x[1281]   c2417     -1
    x[1281]   c2433     -1
    x[1281]   c2465     -1
    x[1281]   c2497     -1
    x[1281]   c2513     -1
    x[1281]   c2529     -1
    x[1281]   c2545     -1
    x[1281]   OBJ       500
    x[1282]   c2065     -1
    x[1282]   c2097     -1
    x[1282]   c2193     -1
    x[1282]   c2225     -1
    x[1282]   c2321     -1
    x[1282]   c2353     -1
    x[1282]   c2449     -1
    x[1282]   c2481     -1
    x[1282]   OBJ       100
    x[1283]   c1281_1   -1
    x[1283]   c1329     -1
    x[1283]   c1377     -1
    x[1283]   c1425     -1
    x[1283]   c1473     -1
    x[1283]   c1521     -1
    x[1283]   c1569     -1
    x[1283]   c1617     -1
    x[1283]   c2577     40
    x[1283]   OBJ       1200
    x[1284]   c1297_1   -1
    x[1284]   c1345     -1
    x[1284]   c1489     -1
    x[1284]   c1537     -1
    x[1284]   c2577     20
    x[1284]   OBJ       500
    x[1285]   c1313_1   -1
    x[1285]   c1361     -1
    x[1285]   c2577     2
    x[1285]   OBJ       50
    x[1286]   c1505     -1
    x[1286]   c1553     -1
    x[1286]   c2577     2
    x[1286]   OBJ       50
    x[1287]   c1393     -1
    x[1287]   c1441     -1
    x[1287]   c1585     -1
    x[1287]   c1633     -1
    x[1287]   c2577     10
    x[1287]   OBJ       125
    x[1288]   c1409     -1
    x[1288]   c1457     -1
    x[1288]   c2577     2
    x[1288]   OBJ       50
    x[1289]   c1601     -1
    x[1289]   c1649     -1
    x[1289]   c2577     2
    x[1289]   OBJ       50
    x[1290]   c1665     -1
    x[1290]   c1713     -1
    x[1290]   c1761     -1
    x[1290]   c1809     -1
    x[1290]   c1857     -1
    x[1290]   c1905     -1
    x[1290]   c1953     -1
    x[1290]   c2001     -1
    x[1290]   c2577     40
    x[1290]   OBJ       1200
    x[1291]   c1681     -1
    x[1291]   c1729     -1
    x[1291]   c1873     -1
    x[1291]   c1921     -1
    x[1291]   c2577     20
    x[1291]   OBJ       500
    x[1292]   c1697     -1
    x[1292]   c1745     -1
    x[1292]   c2577     2
    x[1292]   OBJ       50
    x[1293]   c1889     -1
    x[1293]   c1937     -1
    x[1293]   c2577     2
    x[1293]   OBJ       50
    x[1294]   c1777     -1
    x[1294]   c1825     -1
    x[1294]   c1969     -1
    x[1294]   c2017     -1
    x[1294]   c2577     10
    x[1294]   OBJ       125
    x[1295]   c1793     -1
    x[1295]   c1841     -1
    x[1295]   c2577     2
    x[1295]   OBJ       50
    x[1296]   c1985     -1
    x[1296]   c2033     -1
    x[1296]   c2577     2
    x[1296]   OBJ       50
    x[1297]   c1025_1   -1
    x[1297]   c1057_1   -1
    x[1297]   c1089_1   -1
    x[1297]   c1121_1   -1
    x[1297]   c1153_1   -1
    x[1297]   c1185_1   -1
    x[1297]   c1217_1   -1
    x[1297]   c1249_1   -1
    x[1297]   OBJ       10
    x[1298]   c1041_1   -1
    x[1298]   c1073_1   -1
    x[1298]   c1105_1   -1
    x[1298]   c1137_1   -1
    x[1298]   c1169_1   -1
    x[1298]   c1201_1   -1
    x[1298]   c1233_1   -1
    x[1298]   c1265_1   -1
    x[1298]   OBJ       10
    x[1299]   c2050     -1
    x[1299]   c2082     -1
    x[1299]   c2114     -1
    x[1299]   c2130     -1
    x[1299]   c2146     -1
    x[1299]   c2162     -1
    x[1299]   c2178     -1
    x[1299]   c2210     -1
    x[1299]   c2242     -1
    x[1299]   c2258     -1
    x[1299]   c2274     -1
    x[1299]   c2290     -1
    x[1299]   c2306     -1
    x[1299]   c2338     -1
    x[1299]   c2370     -1
    x[1299]   c2386     -1
    x[1299]   c2402     -1
    x[1299]   c2418     -1
    x[1299]   c2434     -1
    x[1299]   c2466     -1
    x[1299]   c2498     -1
    x[1299]   c2514     -1
    x[1299]   c2530     -1
    x[1299]   c2546     -1
    x[1299]   OBJ       500
    x[1300]   c2066     -1
    x[1300]   c2098     -1
    x[1300]   c2194     -1
    x[1300]   c2226     -1
    x[1300]   c2322     -1
    x[1300]   c2354     -1
    x[1300]   c2450     -1
    x[1300]   c2482     -1
    x[1300]   OBJ       100
    x[1301]   c1282_1   -1
    x[1301]   c1330     -1
    x[1301]   c1378     -1
    x[1301]   c1426     -1
    x[1301]   c1474     -1
    x[1301]   c1522     -1
    x[1301]   c1570     -1
    x[1301]   c1618     -1
    x[1301]   c2578     40
    x[1301]   OBJ       1200
    x[1302]   c1298_1   -1
    x[1302]   c1346     -1
    x[1302]   c1490     -1
    x[1302]   c1538     -1
    x[1302]   c2578     20
    x[1302]   OBJ       500
    x[1303]   c1314_1   -1
    x[1303]   c1362     -1
    x[1303]   c2578     2
    x[1303]   OBJ       50
    x[1304]   c1506     -1
    x[1304]   c1554     -1
    x[1304]   c2578     2
    x[1304]   OBJ       50
    x[1305]   c1394     -1
    x[1305]   c1442     -1
    x[1305]   c1586     -1
    x[1305]   c1634     -1
    x[1305]   c2578     10
    x[1305]   OBJ       125
    x[1306]   c1410     -1
    x[1306]   c1458     -1
    x[1306]   c2578     2
    x[1306]   OBJ       50
    x[1307]   c1602     -1
    x[1307]   c1650     -1
    x[1307]   c2578     2
    x[1307]   OBJ       50
    x[1308]   c1666     -1
    x[1308]   c1714     -1
    x[1308]   c1762     -1
    x[1308]   c1810     -1
    x[1308]   c1858     -1
    x[1308]   c1906     -1
    x[1308]   c1954     -1
    x[1308]   c2002     -1
    x[1308]   c2578     40
    x[1308]   OBJ       1200
    x[1309]   c1682     -1
    x[1309]   c1730     -1
    x[1309]   c1874     -1
    x[1309]   c1922     -1
    x[1309]   c2578     20
    x[1309]   OBJ       500
    x[1310]   c1698     -1
    x[1310]   c1746     -1
    x[1310]   c2578     2
    x[1310]   OBJ       50
    x[1311]   c1890     -1
    x[1311]   c1938     -1
    x[1311]   c2578     2
    x[1311]   OBJ       50
    x[1312]   c1778     -1
    x[1312]   c1826     -1
    x[1312]   c1970     -1
    x[1312]   c2018     -1
    x[1312]   c2578     10
    x[1312]   OBJ       125
    x[1313]   c1794     -1
    x[1313]   c1842     -1
    x[1313]   c2578     2
    x[1313]   OBJ       50
    x[1314]   c1986     -1
    x[1314]   c2034     -1
    x[1314]   c2578     2
    x[1314]   OBJ       50
    x[1315]   c1026_1   -1
    x[1315]   c1058_1   -1
    x[1315]   c1090_1   -1
    x[1315]   c1122_1   -1
    x[1315]   c1154_1   -1
    x[1315]   c1186_1   -1
    x[1315]   c1218_1   -1
    x[1315]   c1250_1   -1
    x[1315]   OBJ       10
    x[1316]   c1042_1   -1
    x[1316]   c1074_1   -1
    x[1316]   c1106_1   -1
    x[1316]   c1138_1   -1
    x[1316]   c1170_1   -1
    x[1316]   c1202_1   -1
    x[1316]   c1234_1   -1
    x[1316]   c1266_1   -1
    x[1316]   OBJ       10
    x[1317]   c2051     -1
    x[1317]   c2083     -1
    x[1317]   c2115     -1
    x[1317]   c2131     -1
    x[1317]   c2147     -1
    x[1317]   c2163     -1
    x[1317]   c2179     -1
    x[1317]   c2211     -1
    x[1317]   c2243     -1
    x[1317]   c2259     -1
    x[1317]   c2275     -1
    x[1317]   c2291     -1
    x[1317]   c2307     -1
    x[1317]   c2339     -1
    x[1317]   c2371     -1
    x[1317]   c2387     -1
    x[1317]   c2403     -1
    x[1317]   c2419     -1
    x[1317]   c2435     -1
    x[1317]   c2467     -1
    x[1317]   c2499     -1
    x[1317]   c2515     -1
    x[1317]   c2531     -1
    x[1317]   c2547     -1
    x[1317]   OBJ       500
    x[1318]   c2067     -1
    x[1318]   c2099     -1
    x[1318]   c2195     -1
    x[1318]   c2227     -1
    x[1318]   c2323     -1
    x[1318]   c2355     -1
    x[1318]   c2451     -1
    x[1318]   c2483     -1
    x[1318]   OBJ       100
    x[1319]   c1283_1   -1
    x[1319]   c1331     -1
    x[1319]   c1379     -1
    x[1319]   c1427     -1
    x[1319]   c1475     -1
    x[1319]   c1523     -1
    x[1319]   c1571     -1
    x[1319]   c1619     -1
    x[1319]   c2579     40
    x[1319]   OBJ       1200
    x[1320]   c1299_1   -1
    x[1320]   c1347     -1
    x[1320]   c1491     -1
    x[1320]   c1539     -1
    x[1320]   c2579     20
    x[1320]   OBJ       500
    x[1321]   c1315_1   -1
    x[1321]   c1363     -1
    x[1321]   c2579     2
    x[1321]   OBJ       50
    x[1322]   c1507     -1
    x[1322]   c1555     -1
    x[1322]   c2579     2
    x[1322]   OBJ       50
    x[1323]   c1395     -1
    x[1323]   c1443     -1
    x[1323]   c1587     -1
    x[1323]   c1635     -1
    x[1323]   c2579     10
    x[1323]   OBJ       125
    x[1324]   c1411     -1
    x[1324]   c1459     -1
    x[1324]   c2579     2
    x[1324]   OBJ       50
    x[1325]   c1603     -1
    x[1325]   c1651     -1
    x[1325]   c2579     2
    x[1325]   OBJ       50
    x[1326]   c1667     -1
    x[1326]   c1715     -1
    x[1326]   c1763     -1
    x[1326]   c1811     -1
    x[1326]   c1859     -1
    x[1326]   c1907     -1
    x[1326]   c1955     -1
    x[1326]   c2003     -1
    x[1326]   c2579     40
    x[1326]   OBJ       1200
    x[1327]   c1683     -1
    x[1327]   c1731     -1
    x[1327]   c1875     -1
    x[1327]   c1923     -1
    x[1327]   c2579     20
    x[1327]   OBJ       500
    x[1328]   c1699     -1
    x[1328]   c1747     -1
    x[1328]   c2579     2
    x[1328]   OBJ       50
    x[1329]   c1891     -1
    x[1329]   c1939     -1
    x[1329]   c2579     2
    x[1329]   OBJ       50
    x[1330]   c1779     -1
    x[1330]   c1827     -1
    x[1330]   c1971     -1
    x[1330]   c2019     -1
    x[1330]   c2579     10
    x[1330]   OBJ       125
    x[1331]   c1795     -1
    x[1331]   c1843     -1
    x[1331]   c2579     2
    x[1331]   OBJ       50
    x[1332]   c1987     -1
    x[1332]   c2035     -1
    x[1332]   c2579     2
    x[1332]   OBJ       50
    x[1333]   c1027_1   -1
    x[1333]   c1059_1   -1
    x[1333]   c1091_1   -1
    x[1333]   c1123_1   -1
    x[1333]   c1155_1   -1
    x[1333]   c1187_1   -1
    x[1333]   c1219_1   -1
    x[1333]   c1251_1   -1
    x[1333]   OBJ       10
    x[1334]   c1043_1   -1
    x[1334]   c1075_1   -1
    x[1334]   c1107_1   -1
    x[1334]   c1139_1   -1
    x[1334]   c1171_1   -1
    x[1334]   c1203_1   -1
    x[1334]   c1235_1   -1
    x[1334]   c1267_1   -1
    x[1334]   OBJ       10
    x[1335]   c2052     -1
    x[1335]   c2084     -1
    x[1335]   c2116     -1
    x[1335]   c2132     -1
    x[1335]   c2148     -1
    x[1335]   c2164     -1
    x[1335]   c2180     -1
    x[1335]   c2212     -1
    x[1335]   c2244     -1
    x[1335]   c2260     -1
    x[1335]   c2276     -1
    x[1335]   c2292     -1
    x[1335]   c2308     -1
    x[1335]   c2340     -1
    x[1335]   c2372     -1
    x[1335]   c2388     -1
    x[1335]   c2404     -1
    x[1335]   c2420     -1
    x[1335]   c2436     -1
    x[1335]   c2468     -1
    x[1335]   c2500     -1
    x[1335]   c2516     -1
    x[1335]   c2532     -1
    x[1335]   c2548     -1
    x[1335]   OBJ       500
    x[1336]   c2068     -1
    x[1336]   c2100     -1
    x[1336]   c2196     -1
    x[1336]   c2228     -1
    x[1336]   c2324     -1
    x[1336]   c2356     -1
    x[1336]   c2452     -1
    x[1336]   c2484     -1
    x[1336]   OBJ       100
    x[1337]   c1284_1   -1
    x[1337]   c1332     -1
    x[1337]   c1380     -1
    x[1337]   c1428     -1
    x[1337]   c1476     -1
    x[1337]   c1524     -1
    x[1337]   c1572     -1
    x[1337]   c1620     -1
    x[1337]   c2580     40
    x[1337]   OBJ       1200
    x[1338]   c1300_1   -1
    x[1338]   c1348     -1
    x[1338]   c1492     -1
    x[1338]   c1540     -1
    x[1338]   c2580     20
    x[1338]   OBJ       500
    x[1339]   c1316_1   -1
    x[1339]   c1364     -1
    x[1339]   c2580     2
    x[1339]   OBJ       50
    x[1340]   c1508     -1
    x[1340]   c1556     -1
    x[1340]   c2580     2
    x[1340]   OBJ       50
    x[1341]   c1396     -1
    x[1341]   c1444     -1
    x[1341]   c1588     -1
    x[1341]   c1636     -1
    x[1341]   c2580     10
    x[1341]   OBJ       125
    x[1342]   c1412     -1
    x[1342]   c1460     -1
    x[1342]   c2580     2
    x[1342]   OBJ       50
    x[1343]   c1604     -1
    x[1343]   c1652     -1
    x[1343]   c2580     2
    x[1343]   OBJ       50
    x[1344]   c1668     -1
    x[1344]   c1716     -1
    x[1344]   c1764     -1
    x[1344]   c1812     -1
    x[1344]   c1860     -1
    x[1344]   c1908     -1
    x[1344]   c1956     -1
    x[1344]   c2004     -1
    x[1344]   c2580     40
    x[1344]   OBJ       1200
    x[1345]   c1684     -1
    x[1345]   c1732     -1
    x[1345]   c1876     -1
    x[1345]   c1924     -1
    x[1345]   c2580     20
    x[1345]   OBJ       500
    x[1346]   c1700     -1
    x[1346]   c1748     -1
    x[1346]   c2580     2
    x[1346]   OBJ       50
    x[1347]   c1892     -1
    x[1347]   c1940     -1
    x[1347]   c2580     2
    x[1347]   OBJ       50
    x[1348]   c1780     -1
    x[1348]   c1828     -1
    x[1348]   c1972     -1
    x[1348]   c2020     -1
    x[1348]   c2580     10
    x[1348]   OBJ       125
    x[1349]   c1796     -1
    x[1349]   c1844     -1
    x[1349]   c2580     2
    x[1349]   OBJ       50
    x[1350]   c1988     -1
    x[1350]   c2036     -1
    x[1350]   c2580     2
    x[1350]   OBJ       50
    x[1351]   c1028_1   -1
    x[1351]   c1060_1   -1
    x[1351]   c1092_1   -1
    x[1351]   c1124_1   -1
    x[1351]   c1156_1   -1
    x[1351]   c1188_1   -1
    x[1351]   c1220_1   -1
    x[1351]   c1252_1   -1
    x[1351]   OBJ       10
    x[1352]   c1044_1   -1
    x[1352]   c1076_1   -1
    x[1352]   c1108_1   -1
    x[1352]   c1140_1   -1
    x[1352]   c1172_1   -1
    x[1352]   c1204_1   -1
    x[1352]   c1236_1   -1
    x[1352]   c1268_1   -1
    x[1352]   OBJ       10
    x[1353]   c2053     -1
    x[1353]   c2085     -1
    x[1353]   c2117     -1
    x[1353]   c2133     -1
    x[1353]   c2149     -1
    x[1353]   c2165     -1
    x[1353]   c2181     -1
    x[1353]   c2213     -1
    x[1353]   c2245     -1
    x[1353]   c2261     -1
    x[1353]   c2277     -1
    x[1353]   c2293     -1
    x[1353]   c2309     -1
    x[1353]   c2341     -1
    x[1353]   c2373     -1
    x[1353]   c2389     -1
    x[1353]   c2405     -1
    x[1353]   c2421     -1
    x[1353]   c2437     -1
    x[1353]   c2469     -1
    x[1353]   c2501     -1
    x[1353]   c2517     -1
    x[1353]   c2533     -1
    x[1353]   c2549     -1
    x[1353]   OBJ       500
    x[1354]   c2069     -1
    x[1354]   c2101     -1
    x[1354]   c2197     -1
    x[1354]   c2229     -1
    x[1354]   c2325     -1
    x[1354]   c2357     -1
    x[1354]   c2453     -1
    x[1354]   c2485     -1
    x[1354]   OBJ       100
    x[1355]   c1285_1   -1
    x[1355]   c1333     -1
    x[1355]   c1381     -1
    x[1355]   c1429     -1
    x[1355]   c1477     -1
    x[1355]   c1525     -1
    x[1355]   c1573     -1
    x[1355]   c1621     -1
    x[1355]   c2581     40
    x[1355]   OBJ       1200
    x[1356]   c1301_1   -1
    x[1356]   c1349     -1
    x[1356]   c1493     -1
    x[1356]   c1541     -1
    x[1356]   c2581     20
    x[1356]   OBJ       500
    x[1357]   c1317_1   -1
    x[1357]   c1365     -1
    x[1357]   c2581     2
    x[1357]   OBJ       50
    x[1358]   c1509     -1
    x[1358]   c1557     -1
    x[1358]   c2581     2
    x[1358]   OBJ       50
    x[1359]   c1397     -1
    x[1359]   c1445     -1
    x[1359]   c1589     -1
    x[1359]   c1637     -1
    x[1359]   c2581     10
    x[1359]   OBJ       125
    x[1360]   c1413     -1
    x[1360]   c1461     -1
    x[1360]   c2581     2
    x[1360]   OBJ       50
    x[1361]   c1605     -1
    x[1361]   c1653     -1
    x[1361]   c2581     2
    x[1361]   OBJ       50
    x[1362]   c1669     -1
    x[1362]   c1717     -1
    x[1362]   c1765     -1
    x[1362]   c1813     -1
    x[1362]   c1861     -1
    x[1362]   c1909     -1
    x[1362]   c1957     -1
    x[1362]   c2005     -1
    x[1362]   c2581     40
    x[1362]   OBJ       1200
    x[1363]   c1685     -1
    x[1363]   c1733     -1
    x[1363]   c1877     -1
    x[1363]   c1925     -1
    x[1363]   c2581     20
    x[1363]   OBJ       500
    x[1364]   c1701     -1
    x[1364]   c1749     -1
    x[1364]   c2581     2
    x[1364]   OBJ       50
    x[1365]   c1893     -1
    x[1365]   c1941     -1
    x[1365]   c2581     2
    x[1365]   OBJ       50
    x[1366]   c1781     -1
    x[1366]   c1829     -1
    x[1366]   c1973     -1
    x[1366]   c2021     -1
    x[1366]   c2581     10
    x[1366]   OBJ       125
    x[1367]   c1797     -1
    x[1367]   c1845     -1
    x[1367]   c2581     2
    x[1367]   OBJ       50
    x[1368]   c1989     -1
    x[1368]   c2037     -1
    x[1368]   c2581     2
    x[1368]   OBJ       50
    x[1369]   c1029_1   -1
    x[1369]   c1061_1   -1
    x[1369]   c1093_1   -1
    x[1369]   c1125_1   -1
    x[1369]   c1157_1   -1
    x[1369]   c1189_1   -1
    x[1369]   c1221_1   -1
    x[1369]   c1253_1   -1
    x[1369]   OBJ       10
    x[1370]   c1045_1   -1
    x[1370]   c1077_1   -1
    x[1370]   c1109_1   -1
    x[1370]   c1141_1   -1
    x[1370]   c1173_1   -1
    x[1370]   c1205_1   -1
    x[1370]   c1237_1   -1
    x[1370]   c1269_1   -1
    x[1370]   OBJ       10
    x[1371]   c2054     -1
    x[1371]   c2086     -1
    x[1371]   c2118     -1
    x[1371]   c2134     -1
    x[1371]   c2150     -1
    x[1371]   c2166     -1
    x[1371]   c2182     -1
    x[1371]   c2214     -1
    x[1371]   c2246     -1
    x[1371]   c2262     -1
    x[1371]   c2278     -1
    x[1371]   c2294     -1
    x[1371]   c2310     -1
    x[1371]   c2342     -1
    x[1371]   c2374     -1
    x[1371]   c2390     -1
    x[1371]   c2406     -1
    x[1371]   c2422     -1
    x[1371]   c2438     -1
    x[1371]   c2470     -1
    x[1371]   c2502     -1
    x[1371]   c2518     -1
    x[1371]   c2534     -1
    x[1371]   c2550     -1
    x[1371]   OBJ       500
    x[1372]   c2070     -1
    x[1372]   c2102     -1
    x[1372]   c2198     -1
    x[1372]   c2230     -1
    x[1372]   c2326     -1
    x[1372]   c2358     -1
    x[1372]   c2454     -1
    x[1372]   c2486     -1
    x[1372]   OBJ       100
    x[1373]   c1286_1   -1
    x[1373]   c1334     -1
    x[1373]   c1382     -1
    x[1373]   c1430     -1
    x[1373]   c1478     -1
    x[1373]   c1526     -1
    x[1373]   c1574     -1
    x[1373]   c1622     -1
    x[1373]   c2582     40
    x[1373]   OBJ       1200
    x[1374]   c1302_1   -1
    x[1374]   c1350     -1
    x[1374]   c1494     -1
    x[1374]   c1542     -1
    x[1374]   c2582     20
    x[1374]   OBJ       500
    x[1375]   c1318_1   -1
    x[1375]   c1366     -1
    x[1375]   c2582     2
    x[1375]   OBJ       50
    x[1376]   c1510     -1
    x[1376]   c1558     -1
    x[1376]   c2582     2
    x[1376]   OBJ       50
    x[1377]   c1398     -1
    x[1377]   c1446     -1
    x[1377]   c1590     -1
    x[1377]   c1638     -1
    x[1377]   c2582     10
    x[1377]   OBJ       125
    x[1378]   c1414     -1
    x[1378]   c1462     -1
    x[1378]   c2582     2
    x[1378]   OBJ       50
    x[1379]   c1606     -1
    x[1379]   c1654     -1
    x[1379]   c2582     2
    x[1379]   OBJ       50
    x[1380]   c1670     -1
    x[1380]   c1718     -1
    x[1380]   c1766     -1
    x[1380]   c1814     -1
    x[1380]   c1862     -1
    x[1380]   c1910     -1
    x[1380]   c1958     -1
    x[1380]   c2006     -1
    x[1380]   c2582     40
    x[1380]   OBJ       1200
    x[1381]   c1686     -1
    x[1381]   c1734     -1
    x[1381]   c1878     -1
    x[1381]   c1926     -1
    x[1381]   c2582     20
    x[1381]   OBJ       500
    x[1382]   c1702     -1
    x[1382]   c1750     -1
    x[1382]   c2582     2
    x[1382]   OBJ       50
    x[1383]   c1894     -1
    x[1383]   c1942     -1
    x[1383]   c2582     2
    x[1383]   OBJ       50
    x[1384]   c1782     -1
    x[1384]   c1830     -1
    x[1384]   c1974     -1
    x[1384]   c2022     -1
    x[1384]   c2582     10
    x[1384]   OBJ       125
    x[1385]   c1798     -1
    x[1385]   c1846     -1
    x[1385]   c2582     2
    x[1385]   OBJ       50
    x[1386]   c1990     -1
    x[1386]   c2038     -1
    x[1386]   c2582     2
    x[1386]   OBJ       50
    x[1387]   c1030_1   -1
    x[1387]   c1062_1   -1
    x[1387]   c1094_1   -1
    x[1387]   c1126_1   -1
    x[1387]   c1158_1   -1
    x[1387]   c1190_1   -1
    x[1387]   c1222_1   -1
    x[1387]   c1254_1   -1
    x[1387]   OBJ       10
    x[1388]   c1046_1   -1
    x[1388]   c1078_1   -1
    x[1388]   c1110_1   -1
    x[1388]   c1142_1   -1
    x[1388]   c1174_1   -1
    x[1388]   c1206_1   -1
    x[1388]   c1238_1   -1
    x[1388]   c1270_1   -1
    x[1388]   OBJ       10
    x[1389]   c2055     -1
    x[1389]   c2087     -1
    x[1389]   c2119     -1
    x[1389]   c2135     -1
    x[1389]   c2151     -1
    x[1389]   c2167     -1
    x[1389]   c2183     -1
    x[1389]   c2215     -1
    x[1389]   c2247     -1
    x[1389]   c2263     -1
    x[1389]   c2279     -1
    x[1389]   c2295     -1
    x[1389]   c2311     -1
    x[1389]   c2343     -1
    x[1389]   c2375     -1
    x[1389]   c2391     -1
    x[1389]   c2407     -1
    x[1389]   c2423     -1
    x[1389]   c2439     -1
    x[1389]   c2471     -1
    x[1389]   c2503     -1
    x[1389]   c2519     -1
    x[1389]   c2535     -1
    x[1389]   c2551     -1
    x[1389]   OBJ       500
    x[1390]   c2071     -1
    x[1390]   c2103     -1
    x[1390]   c2199     -1
    x[1390]   c2231     -1
    x[1390]   c2327     -1
    x[1390]   c2359     -1
    x[1390]   c2455     -1
    x[1390]   c2487     -1
    x[1390]   OBJ       100
    x[1391]   c1287_1   -1
    x[1391]   c1335     -1
    x[1391]   c1383     -1
    x[1391]   c1431     -1
    x[1391]   c1479     -1
    x[1391]   c1527     -1
    x[1391]   c1575     -1
    x[1391]   c1623     -1
    x[1391]   c2583     40
    x[1391]   OBJ       1200
    x[1392]   c1303_1   -1
    x[1392]   c1351     -1
    x[1392]   c1495     -1
    x[1392]   c1543     -1
    x[1392]   c2583     20
    x[1392]   OBJ       500
    x[1393]   c1319     -1
    x[1393]   c1367     -1
    x[1393]   c2583     2
    x[1393]   OBJ       50
    x[1394]   c1511     -1
    x[1394]   c1559     -1
    x[1394]   c2583     2
    x[1394]   OBJ       50
    x[1395]   c1399     -1
    x[1395]   c1447     -1
    x[1395]   c1591     -1
    x[1395]   c1639     -1
    x[1395]   c2583     10
    x[1395]   OBJ       125
    x[1396]   c1415     -1
    x[1396]   c1463     -1
    x[1396]   c2583     2
    x[1396]   OBJ       50
    x[1397]   c1607     -1
    x[1397]   c1655     -1
    x[1397]   c2583     2
    x[1397]   OBJ       50
    x[1398]   c1671     -1
    x[1398]   c1719     -1
    x[1398]   c1767     -1
    x[1398]   c1815     -1
    x[1398]   c1863     -1
    x[1398]   c1911     -1
    x[1398]   c1959     -1
    x[1398]   c2007     -1
    x[1398]   c2583     40
    x[1398]   OBJ       1200
    x[1399]   c1687     -1
    x[1399]   c1735     -1
    x[1399]   c1879     -1
    x[1399]   c1927     -1
    x[1399]   c2583     20
    x[1399]   OBJ       500
    x[1400]   c1703     -1
    x[1400]   c1751     -1
    x[1400]   c2583     2
    x[1400]   OBJ       50
    x[1401]   c1895     -1
    x[1401]   c1943     -1
    x[1401]   c2583     2
    x[1401]   OBJ       50
    x[1402]   c1783     -1
    x[1402]   c1831     -1
    x[1402]   c1975     -1
    x[1402]   c2023     -1
    x[1402]   c2583     10
    x[1402]   OBJ       125
    x[1403]   c1799     -1
    x[1403]   c1847     -1
    x[1403]   c2583     2
    x[1403]   OBJ       50
    x[1404]   c1991     -1
    x[1404]   c2039     -1
    x[1404]   c2583     2
    x[1404]   OBJ       50
    x[1405]   c1031_1   -1
    x[1405]   c1063_1   -1
    x[1405]   c1095_1   -1
    x[1405]   c1127_1   -1
    x[1405]   c1159_1   -1
    x[1405]   c1191_1   -1
    x[1405]   c1223_1   -1
    x[1405]   c1255_1   -1
    x[1405]   OBJ       10
    x[1406]   c1047_1   -1
    x[1406]   c1079_1   -1
    x[1406]   c1111_1   -1
    x[1406]   c1143_1   -1
    x[1406]   c1175_1   -1
    x[1406]   c1207_1   -1
    x[1406]   c1239_1   -1
    x[1406]   c1271_1   -1
    x[1406]   OBJ       10
    x[1407]   c2056     -1
    x[1407]   c2088     -1
    x[1407]   c2120     -1
    x[1407]   c2136     -1
    x[1407]   c2152     -1
    x[1407]   c2168     -1
    x[1407]   c2184     -1
    x[1407]   c2216     -1
    x[1407]   c2248     -1
    x[1407]   c2264     -1
    x[1407]   c2280     -1
    x[1407]   c2296     -1
    x[1407]   c2312     -1
    x[1407]   c2344     -1
    x[1407]   c2376     -1
    x[1407]   c2392     -1
    x[1407]   c2408     -1
    x[1407]   c2424     -1
    x[1407]   c2440     -1
    x[1407]   c2472     -1
    x[1407]   c2504     -1
    x[1407]   c2520     -1
    x[1407]   c2536     -1
    x[1407]   c2552     -1
    x[1407]   OBJ       500
    x[1408]   c2072     -1
    x[1408]   c2104     -1
    x[1408]   c2200     -1
    x[1408]   c2232     -1
    x[1408]   c2328     -1
    x[1408]   c2360     -1
    x[1408]   c2456     -1
    x[1408]   c2488     -1
    x[1408]   OBJ       100
    x[1409]   c1288_1   -1
    x[1409]   c1336     -1
    x[1409]   c1384     -1
    x[1409]   c1432     -1
    x[1409]   c1480     -1
    x[1409]   c1528     -1
    x[1409]   c1576     -1
    x[1409]   c1624     -1
    x[1409]   c2584     40
    x[1409]   OBJ       1200
    x[1410]   c1304_1   -1
    x[1410]   c1352     -1
    x[1410]   c1496     -1
    x[1410]   c1544     -1
    x[1410]   c2584     20
    x[1410]   OBJ       500
    x[1411]   c1320     -1
    x[1411]   c1368     -1
    x[1411]   c2584     2
    x[1411]   OBJ       50
    x[1412]   c1512     -1
    x[1412]   c1560     -1
    x[1412]   c2584     2
    x[1412]   OBJ       50
    x[1413]   c1400     -1
    x[1413]   c1448     -1
    x[1413]   c1592     -1
    x[1413]   c1640     -1
    x[1413]   c2584     10
    x[1413]   OBJ       125
    x[1414]   c1416     -1
    x[1414]   c1464     -1
    x[1414]   c2584     2
    x[1414]   OBJ       50
    x[1415]   c1608     -1
    x[1415]   c1656     -1
    x[1415]   c2584     2
    x[1415]   OBJ       50
    x[1416]   c1672     -1
    x[1416]   c1720     -1
    x[1416]   c1768     -1
    x[1416]   c1816     -1
    x[1416]   c1864     -1
    x[1416]   c1912     -1
    x[1416]   c1960     -1
    x[1416]   c2008     -1
    x[1416]   c2584     40
    x[1416]   OBJ       1200
    x[1417]   c1688     -1
    x[1417]   c1736     -1
    x[1417]   c1880     -1
    x[1417]   c1928     -1
    x[1417]   c2584     20
    x[1417]   OBJ       500
    x[1418]   c1704     -1
    x[1418]   c1752     -1
    x[1418]   c2584     2
    x[1418]   OBJ       50
    x[1419]   c1896     -1
    x[1419]   c1944     -1
    x[1419]   c2584     2
    x[1419]   OBJ       50
    x[1420]   c1784     -1
    x[1420]   c1832     -1
    x[1420]   c1976     -1
    x[1420]   c2024     -1
    x[1420]   c2584     10
    x[1420]   OBJ       125
    x[1421]   c1800     -1
    x[1421]   c1848     -1
    x[1421]   c2584     2
    x[1421]   OBJ       50
    x[1422]   c1992     -1
    x[1422]   c2040     -1
    x[1422]   c2584     2
    x[1422]   OBJ       50
    x[1423]   c1032_1   -1
    x[1423]   c1064_1   -1
    x[1423]   c1096_1   -1
    x[1423]   c1128_1   -1
    x[1423]   c1160_1   -1
    x[1423]   c1192_1   -1
    x[1423]   c1224_1   -1
    x[1423]   c1256_1   -1
    x[1423]   OBJ       10
    x[1424]   c1048_1   -1
    x[1424]   c1080_1   -1
    x[1424]   c1112_1   -1
    x[1424]   c1144_1   -1
    x[1424]   c1176_1   -1
    x[1424]   c1208_1   -1
    x[1424]   c1240_1   -1
    x[1424]   c1272_1   -1
    x[1424]   OBJ       10
    x[1425]   c2057     -1
    x[1425]   c2089     -1
    x[1425]   c2121     -1
    x[1425]   c2137     -1
    x[1425]   c2153     -1
    x[1425]   c2169     -1
    x[1425]   c2185     -1
    x[1425]   c2217     -1
    x[1425]   c2249     -1
    x[1425]   c2265     -1
    x[1425]   c2281     -1
    x[1425]   c2297     -1
    x[1425]   c2313     -1
    x[1425]   c2345     -1
    x[1425]   c2377     -1
    x[1425]   c2393     -1
    x[1425]   c2409     -1
    x[1425]   c2425     -1
    x[1425]   c2441     -1
    x[1425]   c2473     -1
    x[1425]   c2505     -1
    x[1425]   c2521     -1
    x[1425]   c2537     -1
    x[1425]   c2553     -1
    x[1425]   OBJ       500
    x[1426]   c2073     -1
    x[1426]   c2105     -1
    x[1426]   c2201     -1
    x[1426]   c2233     -1
    x[1426]   c2329     -1
    x[1426]   c2361     -1
    x[1426]   c2457     -1
    x[1426]   c2489     -1
    x[1426]   OBJ       100
    x[1427]   c1289_1   -1
    x[1427]   c1337     -1
    x[1427]   c1385     -1
    x[1427]   c1433     -1
    x[1427]   c1481     -1
    x[1427]   c1529     -1
    x[1427]   c1577     -1
    x[1427]   c1625     -1
    x[1427]   c2585     40
    x[1427]   OBJ       1200
    x[1428]   c1305_1   -1
    x[1428]   c1353     -1
    x[1428]   c1497     -1
    x[1428]   c1545     -1
    x[1428]   c2585     20
    x[1428]   OBJ       500
    x[1429]   c1321     -1
    x[1429]   c1369     -1
    x[1429]   c2585     2
    x[1429]   OBJ       50
    x[1430]   c1513     -1
    x[1430]   c1561     -1
    x[1430]   c2585     2
    x[1430]   OBJ       50
    x[1431]   c1401     -1
    x[1431]   c1449     -1
    x[1431]   c1593     -1
    x[1431]   c1641     -1
    x[1431]   c2585     10
    x[1431]   OBJ       125
    x[1432]   c1417     -1
    x[1432]   c1465     -1
    x[1432]   c2585     2
    x[1432]   OBJ       50
    x[1433]   c1609     -1
    x[1433]   c1657     -1
    x[1433]   c2585     2
    x[1433]   OBJ       50
    x[1434]   c1673     -1
    x[1434]   c1721     -1
    x[1434]   c1769     -1
    x[1434]   c1817     -1
    x[1434]   c1865     -1
    x[1434]   c1913     -1
    x[1434]   c1961     -1
    x[1434]   c2009     -1
    x[1434]   c2585     40
    x[1434]   OBJ       1200
    x[1435]   c1689     -1
    x[1435]   c1737     -1
    x[1435]   c1881     -1
    x[1435]   c1929     -1
    x[1435]   c2585     20
    x[1435]   OBJ       500
    x[1436]   c1705     -1
    x[1436]   c1753     -1
    x[1436]   c2585     2
    x[1436]   OBJ       50
    x[1437]   c1897     -1
    x[1437]   c1945     -1
    x[1437]   c2585     2
    x[1437]   OBJ       50
    x[1438]   c1785     -1
    x[1438]   c1833     -1
    x[1438]   c1977     -1
    x[1438]   c2025     -1
    x[1438]   c2585     10
    x[1438]   OBJ       125
    x[1439]   c1801     -1
    x[1439]   c1849     -1
    x[1439]   c2585     2
    x[1439]   OBJ       50
    x[1440]   c1993     -1
    x[1440]   c2041     -1
    x[1440]   c2585     2
    x[1440]   OBJ       50
    x[1441]   c1033_1   -1
    x[1441]   c1065_1   -1
    x[1441]   c1097_1   -1
    x[1441]   c1129_1   -1
    x[1441]   c1161_1   -1
    x[1441]   c1193_1   -1
    x[1441]   c1225_1   -1
    x[1441]   c1257_1   -1
    x[1441]   OBJ       10
    x[1442]   c1049_1   -1
    x[1442]   c1081_1   -1
    x[1442]   c1113_1   -1
    x[1442]   c1145_1   -1
    x[1442]   c1177_1   -1
    x[1442]   c1209_1   -1
    x[1442]   c1241_1   -1
    x[1442]   c1273_1   -1
    x[1442]   OBJ       10
    x[1443]   c2058     -1
    x[1443]   c2090     -1
    x[1443]   c2122     -1
    x[1443]   c2138     -1
    x[1443]   c2154     -1
    x[1443]   c2170     -1
    x[1443]   c2186     -1
    x[1443]   c2218     -1
    x[1443]   c2250     -1
    x[1443]   c2266     -1
    x[1443]   c2282     -1
    x[1443]   c2298     -1
    x[1443]   c2314     -1
    x[1443]   c2346     -1
    x[1443]   c2378     -1
    x[1443]   c2394     -1
    x[1443]   c2410     -1
    x[1443]   c2426     -1
    x[1443]   c2442     -1
    x[1443]   c2474     -1
    x[1443]   c2506     -1
    x[1443]   c2522     -1
    x[1443]   c2538     -1
    x[1443]   c2554     -1
    x[1443]   OBJ       500
    x[1444]   c2074     -1
    x[1444]   c2106     -1
    x[1444]   c2202     -1
    x[1444]   c2234     -1
    x[1444]   c2330     -1
    x[1444]   c2362     -1
    x[1444]   c2458     -1
    x[1444]   c2490     -1
    x[1444]   OBJ       100
    x[1445]   c1290_1   -1
    x[1445]   c1338     -1
    x[1445]   c1386     -1
    x[1445]   c1434     -1
    x[1445]   c1482     -1
    x[1445]   c1530     -1
    x[1445]   c1578     -1
    x[1445]   c1626     -1
    x[1445]   c2586     40
    x[1445]   OBJ       1200
    x[1446]   c1306_1   -1
    x[1446]   c1354     -1
    x[1446]   c1498     -1
    x[1446]   c1546     -1
    x[1446]   c2586     20
    x[1446]   OBJ       500
    x[1447]   c1322     -1
    x[1447]   c1370     -1
    x[1447]   c2586     2
    x[1447]   OBJ       50
    x[1448]   c1514     -1
    x[1448]   c1562     -1
    x[1448]   c2586     2
    x[1448]   OBJ       50
    x[1449]   c1402     -1
    x[1449]   c1450     -1
    x[1449]   c1594     -1
    x[1449]   c1642     -1
    x[1449]   c2586     10
    x[1449]   OBJ       125
    x[1450]   c1418     -1
    x[1450]   c1466     -1
    x[1450]   c2586     2
    x[1450]   OBJ       50
    x[1451]   c1610     -1
    x[1451]   c1658     -1
    x[1451]   c2586     2
    x[1451]   OBJ       50
    x[1452]   c1674     -1
    x[1452]   c1722     -1
    x[1452]   c1770     -1
    x[1452]   c1818     -1
    x[1452]   c1866     -1
    x[1452]   c1914     -1
    x[1452]   c1962     -1
    x[1452]   c2010     -1
    x[1452]   c2586     40
    x[1452]   OBJ       1200
    x[1453]   c1690     -1
    x[1453]   c1738     -1
    x[1453]   c1882     -1
    x[1453]   c1930     -1
    x[1453]   c2586     20
    x[1453]   OBJ       500
    x[1454]   c1706     -1
    x[1454]   c1754     -1
    x[1454]   c2586     2
    x[1454]   OBJ       50
    x[1455]   c1898     -1
    x[1455]   c1946     -1
    x[1455]   c2586     2
    x[1455]   OBJ       50
    x[1456]   c1786     -1
    x[1456]   c1834     -1
    x[1456]   c1978     -1
    x[1456]   c2026     -1
    x[1456]   c2586     10
    x[1456]   OBJ       125
    x[1457]   c1802     -1
    x[1457]   c1850     -1
    x[1457]   c2586     2
    x[1457]   OBJ       50
    x[1458]   c1994     -1
    x[1458]   c2042     -1
    x[1458]   c2586     2
    x[1458]   OBJ       50
    x[1459]   c1034_1   -1
    x[1459]   c1066_1   -1
    x[1459]   c1098_1   -1
    x[1459]   c1130_1   -1
    x[1459]   c1162_1   -1
    x[1459]   c1194_1   -1
    x[1459]   c1226_1   -1
    x[1459]   c1258_1   -1
    x[1459]   OBJ       10
    x[1460]   c1050_1   -1
    x[1460]   c1082_1   -1
    x[1460]   c1114_1   -1
    x[1460]   c1146_1   -1
    x[1460]   c1178_1   -1
    x[1460]   c1210_1   -1
    x[1460]   c1242_1   -1
    x[1460]   c1274_1   -1
    x[1460]   OBJ       10
    x[1461]   c2059     -1
    x[1461]   c2091     -1
    x[1461]   c2123     -1
    x[1461]   c2139     -1
    x[1461]   c2155     -1
    x[1461]   c2171     -1
    x[1461]   c2187     -1
    x[1461]   c2219     -1
    x[1461]   c2251     -1
    x[1461]   c2267     -1
    x[1461]   c2283     -1
    x[1461]   c2299     -1
    x[1461]   c2315     -1
    x[1461]   c2347     -1
    x[1461]   c2379     -1
    x[1461]   c2395     -1
    x[1461]   c2411     -1
    x[1461]   c2427     -1
    x[1461]   c2443     -1
    x[1461]   c2475     -1
    x[1461]   c2507     -1
    x[1461]   c2523     -1
    x[1461]   c2539     -1
    x[1461]   c2555     -1
    x[1461]   OBJ       500
    x[1462]   c2075     -1
    x[1462]   c2107     -1
    x[1462]   c2203     -1
    x[1462]   c2235     -1
    x[1462]   c2331     -1
    x[1462]   c2363     -1
    x[1462]   c2459     -1
    x[1462]   c2491     -1
    x[1462]   OBJ       100
    x[1463]   c1291_1   -1
    x[1463]   c1339     -1
    x[1463]   c1387     -1
    x[1463]   c1435     -1
    x[1463]   c1483     -1
    x[1463]   c1531     -1
    x[1463]   c1579     -1
    x[1463]   c1627     -1
    x[1463]   c2587     40
    x[1463]   OBJ       1200
    x[1464]   c1307_1   -1
    x[1464]   c1355     -1
    x[1464]   c1499     -1
    x[1464]   c1547     -1
    x[1464]   c2587     20
    x[1464]   OBJ       500
    x[1465]   c1323     -1
    x[1465]   c1371     -1
    x[1465]   c2587     2
    x[1465]   OBJ       50
    x[1466]   c1515     -1
    x[1466]   c1563     -1
    x[1466]   c2587     2
    x[1466]   OBJ       50
    x[1467]   c1403     -1
    x[1467]   c1451     -1
    x[1467]   c1595     -1
    x[1467]   c1643     -1
    x[1467]   c2587     10
    x[1467]   OBJ       125
    x[1468]   c1419     -1
    x[1468]   c1467     -1
    x[1468]   c2587     2
    x[1468]   OBJ       50
    x[1469]   c1611     -1
    x[1469]   c1659     -1
    x[1469]   c2587     2
    x[1469]   OBJ       50
    x[1470]   c1675     -1
    x[1470]   c1723     -1
    x[1470]   c1771     -1
    x[1470]   c1819     -1
    x[1470]   c1867     -1
    x[1470]   c1915     -1
    x[1470]   c1963     -1
    x[1470]   c2011     -1
    x[1470]   c2587     40
    x[1470]   OBJ       1200
    x[1471]   c1691     -1
    x[1471]   c1739     -1
    x[1471]   c1883     -1
    x[1471]   c1931     -1
    x[1471]   c2587     20
    x[1471]   OBJ       500
    x[1472]   c1707     -1
    x[1472]   c1755     -1
    x[1472]   c2587     2
    x[1472]   OBJ       50
    x[1473]   c1899     -1
    x[1473]   c1947     -1
    x[1473]   c2587     2
    x[1473]   OBJ       50
    x[1474]   c1787     -1
    x[1474]   c1835     -1
    x[1474]   c1979     -1
    x[1474]   c2027     -1
    x[1474]   c2587     10
    x[1474]   OBJ       125
    x[1475]   c1803     -1
    x[1475]   c1851     -1
    x[1475]   c2587     2
    x[1475]   OBJ       50
    x[1476]   c1995     -1
    x[1476]   c2043     -1
    x[1476]   c2587     2
    x[1476]   OBJ       50
    x[1477]   c1035_1   -1
    x[1477]   c1067_1   -1
    x[1477]   c1099_1   -1
    x[1477]   c1131_1   -1
    x[1477]   c1163_1   -1
    x[1477]   c1195_1   -1
    x[1477]   c1227_1   -1
    x[1477]   c1259_1   -1
    x[1477]   OBJ       10
    x[1478]   c1051_1   -1
    x[1478]   c1083_1   -1
    x[1478]   c1115_1   -1
    x[1478]   c1147_1   -1
    x[1478]   c1179_1   -1
    x[1478]   c1211_1   -1
    x[1478]   c1243_1   -1
    x[1478]   c1275_1   -1
    x[1478]   OBJ       10
    x[1479]   c2060     -1
    x[1479]   c2092     -1
    x[1479]   c2124     -1
    x[1479]   c2140     -1
    x[1479]   c2156     -1
    x[1479]   c2172     -1
    x[1479]   c2188     -1
    x[1479]   c2220     -1
    x[1479]   c2252     -1
    x[1479]   c2268     -1
    x[1479]   c2284     -1
    x[1479]   c2300     -1
    x[1479]   c2316     -1
    x[1479]   c2348     -1
    x[1479]   c2380     -1
    x[1479]   c2396     -1
    x[1479]   c2412     -1
    x[1479]   c2428     -1
    x[1479]   c2444     -1
    x[1479]   c2476     -1
    x[1479]   c2508     -1
    x[1479]   c2524     -1
    x[1479]   c2540     -1
    x[1479]   c2556     -1
    x[1479]   OBJ       500
    x[1480]   c2076     -1
    x[1480]   c2108     -1
    x[1480]   c2204     -1
    x[1480]   c2236     -1
    x[1480]   c2332     -1
    x[1480]   c2364     -1
    x[1480]   c2460     -1
    x[1480]   c2492     -1
    x[1480]   OBJ       100
    x[1481]   c1292_1   -1
    x[1481]   c1340     -1
    x[1481]   c1388     -1
    x[1481]   c1436     -1
    x[1481]   c1484     -1
    x[1481]   c1532     -1
    x[1481]   c1580     -1
    x[1481]   c1628     -1
    x[1481]   c2588     40
    x[1481]   OBJ       1200
    x[1482]   c1308_1   -1
    x[1482]   c1356     -1
    x[1482]   c1500     -1
    x[1482]   c1548     -1
    x[1482]   c2588     20
    x[1482]   OBJ       500
    x[1483]   c1324     -1
    x[1483]   c1372     -1
    x[1483]   c2588     2
    x[1483]   OBJ       50
    x[1484]   c1516     -1
    x[1484]   c1564     -1
    x[1484]   c2588     2
    x[1484]   OBJ       50
    x[1485]   c1404     -1
    x[1485]   c1452     -1
    x[1485]   c1596     -1
    x[1485]   c1644     -1
    x[1485]   c2588     10
    x[1485]   OBJ       125
    x[1486]   c1420     -1
    x[1486]   c1468     -1
    x[1486]   c2588     2
    x[1486]   OBJ       50
    x[1487]   c1612     -1
    x[1487]   c1660     -1
    x[1487]   c2588     2
    x[1487]   OBJ       50
    x[1488]   c1676     -1
    x[1488]   c1724     -1
    x[1488]   c1772     -1
    x[1488]   c1820     -1
    x[1488]   c1868     -1
    x[1488]   c1916     -1
    x[1488]   c1964     -1
    x[1488]   c2012     -1
    x[1488]   c2588     40
    x[1488]   OBJ       1200
    x[1489]   c1692     -1
    x[1489]   c1740     -1
    x[1489]   c1884     -1
    x[1489]   c1932     -1
    x[1489]   c2588     20
    x[1489]   OBJ       500
    x[1490]   c1708     -1
    x[1490]   c1756     -1
    x[1490]   c2588     2
    x[1490]   OBJ       50
    x[1491]   c1900     -1
    x[1491]   c1948     -1
    x[1491]   c2588     2
    x[1491]   OBJ       50
    x[1492]   c1788     -1
    x[1492]   c1836     -1
    x[1492]   c1980     -1
    x[1492]   c2028     -1
    x[1492]   c2588     10
    x[1492]   OBJ       125
    x[1493]   c1804     -1
    x[1493]   c1852     -1
    x[1493]   c2588     2
    x[1493]   OBJ       50
    x[1494]   c1996     -1
    x[1494]   c2044     -1
    x[1494]   c2588     2
    x[1494]   OBJ       50
    x[1495]   c1036_1   -1
    x[1495]   c1068_1   -1
    x[1495]   c1100_1   -1
    x[1495]   c1132_1   -1
    x[1495]   c1164_1   -1
    x[1495]   c1196_1   -1
    x[1495]   c1228_1   -1
    x[1495]   c1260_1   -1
    x[1495]   OBJ       10
    x[1496]   c1052_1   -1
    x[1496]   c1084_1   -1
    x[1496]   c1116_1   -1
    x[1496]   c1148_1   -1
    x[1496]   c1180_1   -1
    x[1496]   c1212_1   -1
    x[1496]   c1244_1   -1
    x[1496]   c1276_1   -1
    x[1496]   OBJ       10
    x[1497]   c2061     -1
    x[1497]   c2093     -1
    x[1497]   c2125     -1
    x[1497]   c2141     -1
    x[1497]   c2157     -1
    x[1497]   c2173     -1
    x[1497]   c2189     -1
    x[1497]   c2221     -1
    x[1497]   c2253     -1
    x[1497]   c2269     -1
    x[1497]   c2285     -1
    x[1497]   c2301     -1
    x[1497]   c2317     -1
    x[1497]   c2349     -1
    x[1497]   c2381     -1
    x[1497]   c2397     -1
    x[1497]   c2413     -1
    x[1497]   c2429     -1
    x[1497]   c2445     -1
    x[1497]   c2477     -1
    x[1497]   c2509     -1
    x[1497]   c2525     -1
    x[1497]   c2541     -1
    x[1497]   c2557     -1
    x[1497]   OBJ       500
    x[1498]   c2077     -1
    x[1498]   c2109     -1
    x[1498]   c2205     -1
    x[1498]   c2237     -1
    x[1498]   c2333     -1
    x[1498]   c2365     -1
    x[1498]   c2461     -1
    x[1498]   c2493     -1
    x[1498]   OBJ       100
    x[1499]   c1293_1   -1
    x[1499]   c1341     -1
    x[1499]   c1389     -1
    x[1499]   c1437     -1
    x[1499]   c1485     -1
    x[1499]   c1533     -1
    x[1499]   c1581     -1
    x[1499]   c1629     -1
    x[1499]   c2589     40
    x[1499]   OBJ       1200
    x[1500]   c1309_1   -1
    x[1500]   c1357     -1
    x[1500]   c1501     -1
    x[1500]   c1549     -1
    x[1500]   c2589     20
    x[1500]   OBJ       500
    x[1501]   c1325     -1
    x[1501]   c1373     -1
    x[1501]   c2589     2
    x[1501]   OBJ       50
    x[1502]   c1517     -1
    x[1502]   c1565     -1
    x[1502]   c2589     2
    x[1502]   OBJ       50
    x[1503]   c1405     -1
    x[1503]   c1453     -1
    x[1503]   c1597     -1
    x[1503]   c1645     -1
    x[1503]   c2589     10
    x[1503]   OBJ       125
    x[1504]   c1421     -1
    x[1504]   c1469     -1
    x[1504]   c2589     2
    x[1504]   OBJ       50
    x[1505]   c1613     -1
    x[1505]   c1661     -1
    x[1505]   c2589     2
    x[1505]   OBJ       50
    x[1506]   c1677     -1
    x[1506]   c1725     -1
    x[1506]   c1773     -1
    x[1506]   c1821     -1
    x[1506]   c1869     -1
    x[1506]   c1917     -1
    x[1506]   c1965     -1
    x[1506]   c2013     -1
    x[1506]   c2589     40
    x[1506]   OBJ       1200
    x[1507]   c1693     -1
    x[1507]   c1741     -1
    x[1507]   c1885     -1
    x[1507]   c1933     -1
    x[1507]   c2589     20
    x[1507]   OBJ       500
    x[1508]   c1709     -1
    x[1508]   c1757     -1
    x[1508]   c2589     2
    x[1508]   OBJ       50
    x[1509]   c1901     -1
    x[1509]   c1949     -1
    x[1509]   c2589     2
    x[1509]   OBJ       50
    x[1510]   c1789     -1
    x[1510]   c1837     -1
    x[1510]   c1981     -1
    x[1510]   c2029     -1
    x[1510]   c2589     10
    x[1510]   OBJ       125
    x[1511]   c1805     -1
    x[1511]   c1853     -1
    x[1511]   c2589     2
    x[1511]   OBJ       50
    x[1512]   c1997     -1
    x[1512]   c2045     -1
    x[1512]   c2589     2
    x[1512]   OBJ       50
    x[1513]   c1037_1   -1
    x[1513]   c1069_1   -1
    x[1513]   c1101_1   -1
    x[1513]   c1133_1   -1
    x[1513]   c1165_1   -1
    x[1513]   c1197_1   -1
    x[1513]   c1229_1   -1
    x[1513]   c1261_1   -1
    x[1513]   OBJ       10
    x[1514]   c1053_1   -1
    x[1514]   c1085_1   -1
    x[1514]   c1117_1   -1
    x[1514]   c1149_1   -1
    x[1514]   c1181_1   -1
    x[1514]   c1213_1   -1
    x[1514]   c1245_1   -1
    x[1514]   c1277_1   -1
    x[1514]   OBJ       10
    x[1515]   c2062     -1
    x[1515]   c2094     -1
    x[1515]   c2126     -1
    x[1515]   c2142     -1
    x[1515]   c2158     -1
    x[1515]   c2174     -1
    x[1515]   c2190     -1
    x[1515]   c2222     -1
    x[1515]   c2254     -1
    x[1515]   c2270     -1
    x[1515]   c2286     -1
    x[1515]   c2302     -1
    x[1515]   c2318     -1
    x[1515]   c2350     -1
    x[1515]   c2382     -1
    x[1515]   c2398     -1
    x[1515]   c2414     -1
    x[1515]   c2430     -1
    x[1515]   c2446     -1
    x[1515]   c2478     -1
    x[1515]   c2510     -1
    x[1515]   c2526     -1
    x[1515]   c2542     -1
    x[1515]   c2558     -1
    x[1515]   OBJ       500
    x[1516]   c2078     -1
    x[1516]   c2110     -1
    x[1516]   c2206     -1
    x[1516]   c2238     -1
    x[1516]   c2334     -1
    x[1516]   c2366     -1
    x[1516]   c2462     -1
    x[1516]   c2494     -1
    x[1516]   OBJ       100
    x[1517]   c1294_1   -1
    x[1517]   c1342     -1
    x[1517]   c1390     -1
    x[1517]   c1438     -1
    x[1517]   c1486     -1
    x[1517]   c1534     -1
    x[1517]   c1582     -1
    x[1517]   c1630     -1
    x[1517]   c2590     40
    x[1517]   OBJ       1200
    x[1518]   c1310_1   -1
    x[1518]   c1358     -1
    x[1518]   c1502     -1
    x[1518]   c1550     -1
    x[1518]   c2590     20
    x[1518]   OBJ       500
    x[1519]   c1326     -1
    x[1519]   c1374     -1
    x[1519]   c2590     2
    x[1519]   OBJ       50
    x[1520]   c1518     -1
    x[1520]   c1566     -1
    x[1520]   c2590     2
    x[1520]   OBJ       50
    x[1521]   c1406     -1
    x[1521]   c1454     -1
    x[1521]   c1598     -1
    x[1521]   c1646     -1
    x[1521]   c2590     10
    x[1521]   OBJ       125
    x[1522]   c1422     -1
    x[1522]   c1470     -1
    x[1522]   c2590     2
    x[1522]   OBJ       50
    x[1523]   c1614     -1
    x[1523]   c1662     -1
    x[1523]   c2590     2
    x[1523]   OBJ       50
    x[1524]   c1678     -1
    x[1524]   c1726     -1
    x[1524]   c1774     -1
    x[1524]   c1822     -1
    x[1524]   c1870     -1
    x[1524]   c1918     -1
    x[1524]   c1966     -1
    x[1524]   c2014     -1
    x[1524]   c2590     40
    x[1524]   OBJ       1200
    x[1525]   c1694     -1
    x[1525]   c1742     -1
    x[1525]   c1886     -1
    x[1525]   c1934     -1
    x[1525]   c2590     20
    x[1525]   OBJ       500
    x[1526]   c1710     -1
    x[1526]   c1758     -1
    x[1526]   c2590     2
    x[1526]   OBJ       50
    x[1527]   c1902     -1
    x[1527]   c1950     -1
    x[1527]   c2590     2
    x[1527]   OBJ       50
    x[1528]   c1790     -1
    x[1528]   c1838     -1
    x[1528]   c1982     -1
    x[1528]   c2030     -1
    x[1528]   c2590     10
    x[1528]   OBJ       125
    x[1529]   c1806     -1
    x[1529]   c1854     -1
    x[1529]   c2590     2
    x[1529]   OBJ       50
    x[1530]   c1998     -1
    x[1530]   c2046     -1
    x[1530]   c2590     2
    x[1530]   OBJ       50
    x[1531]   c1038_1   -1
    x[1531]   c1070_1   -1
    x[1531]   c1102_1   -1
    x[1531]   c1134_1   -1
    x[1531]   c1166_1   -1
    x[1531]   c1198_1   -1
    x[1531]   c1230_1   -1
    x[1531]   c1262_1   -1
    x[1531]   OBJ       10
    x[1532]   c1054_1   -1
    x[1532]   c1086_1   -1
    x[1532]   c1118_1   -1
    x[1532]   c1150_1   -1
    x[1532]   c1182_1   -1
    x[1532]   c1214_1   -1
    x[1532]   c1246_1   -1
    x[1532]   c1278_1   -1
    x[1532]   OBJ       10
    x[1533]   c2063     -1
    x[1533]   c2095     -1
    x[1533]   c2127     -1
    x[1533]   c2143     -1
    x[1533]   c2159     -1
    x[1533]   c2175     -1
    x[1533]   c2191     -1
    x[1533]   c2223     -1
    x[1533]   c2255     -1
    x[1533]   c2271     -1
    x[1533]   c2287     -1
    x[1533]   c2303     -1
    x[1533]   c2319     -1
    x[1533]   c2351     -1
    x[1533]   c2383     -1
    x[1533]   c2399     -1
    x[1533]   c2415     -1
    x[1533]   c2431     -1
    x[1533]   c2447     -1
    x[1533]   c2479     -1
    x[1533]   c2511     -1
    x[1533]   c2527     -1
    x[1533]   c2543     -1
    x[1533]   c2559     -1
    x[1533]   OBJ       500
    x[1534]   c2079     -1
    x[1534]   c2111     -1
    x[1534]   c2207     -1
    x[1534]   c2239     -1
    x[1534]   c2335     -1
    x[1534]   c2367     -1
    x[1534]   c2463     -1
    x[1534]   c2495     -1
    x[1534]   OBJ       100
    x[1535]   c1295_1   -1
    x[1535]   c1343     -1
    x[1535]   c1391     -1
    x[1535]   c1439     -1
    x[1535]   c1487     -1
    x[1535]   c1535     -1
    x[1535]   c1583     -1
    x[1535]   c1631     -1
    x[1535]   c2591     40
    x[1535]   OBJ       1200
    x[1536]   c1311_1   -1
    x[1536]   c1359     -1
    x[1536]   c1503     -1
    x[1536]   c1551     -1
    x[1536]   c2591     20
    x[1536]   OBJ       500
    x[1537]   c1327     -1
    x[1537]   c1375     -1
    x[1537]   c2591     2
    x[1537]   OBJ       50
    x[1538]   c1519     -1
    x[1538]   c1567     -1
    x[1538]   c2591     2
    x[1538]   OBJ       50
    x[1539]   c1407     -1
    x[1539]   c1455     -1
    x[1539]   c1599     -1
    x[1539]   c1647     -1
    x[1539]   c2591     10
    x[1539]   OBJ       125
    x[1540]   c1423     -1
    x[1540]   c1471     -1
    x[1540]   c2591     2
    x[1540]   OBJ       50
    x[1541]   c1615     -1
    x[1541]   c1663     -1
    x[1541]   c2591     2
    x[1541]   OBJ       50
    x[1542]   c1679     -1
    x[1542]   c1727     -1
    x[1542]   c1775     -1
    x[1542]   c1823     -1
    x[1542]   c1871     -1
    x[1542]   c1919     -1
    x[1542]   c1967     -1
    x[1542]   c2015     -1
    x[1542]   c2591     40
    x[1542]   OBJ       1200
    x[1543]   c1695     -1
    x[1543]   c1743     -1
    x[1543]   c1887     -1
    x[1543]   c1935     -1
    x[1543]   c2591     20
    x[1543]   OBJ       500
    x[1544]   c1711     -1
    x[1544]   c1759     -1
    x[1544]   c2591     2
    x[1544]   OBJ       50
    x[1545]   c1903     -1
    x[1545]   c1951     -1
    x[1545]   c2591     2
    x[1545]   OBJ       50
    x[1546]   c1791     -1
    x[1546]   c1839     -1
    x[1546]   c1983     -1
    x[1546]   c2031     -1
    x[1546]   c2591     10
    x[1546]   OBJ       125
    x[1547]   c1807     -1
    x[1547]   c1855     -1
    x[1547]   c2591     2
    x[1547]   OBJ       50
    x[1548]   c1999     -1
    x[1548]   c2047     -1
    x[1548]   c2591     2
    x[1548]   OBJ       50
    x[1549]   c1039_1   -1
    x[1549]   c1071_1   -1
    x[1549]   c1103_1   -1
    x[1549]   c1135_1   -1
    x[1549]   c1167_1   -1
    x[1549]   c1199_1   -1
    x[1549]   c1231_1   -1
    x[1549]   c1263_1   -1
    x[1549]   OBJ       10
    x[1550]   c1055_1   -1
    x[1550]   c1087_1   -1
    x[1550]   c1119_1   -1
    x[1550]   c1151_1   -1
    x[1550]   c1183_1   -1
    x[1550]   c1215_1   -1
    x[1550]   c1247_1   -1
    x[1550]   c1279_1   -1
    x[1550]   OBJ       10
    x[1551]   c2064     -1
    x[1551]   c2096     -1
    x[1551]   c2128     -1
    x[1551]   c2144     -1
    x[1551]   c2160     -1
    x[1551]   c2176     -1
    x[1551]   c2192     -1
    x[1551]   c2224     -1
    x[1551]   c2256     -1
    x[1551]   c2272     -1
    x[1551]   c2288     -1
    x[1551]   c2304     -1
    x[1551]   c2320     -1
    x[1551]   c2352     -1
    x[1551]   c2384     -1
    x[1551]   c2400     -1
    x[1551]   c2416     -1
    x[1551]   c2432     -1
    x[1551]   c2448     -1
    x[1551]   c2480     -1
    x[1551]   c2512     -1
    x[1551]   c2528     -1
    x[1551]   c2544     -1
    x[1551]   c2560     -1
    x[1551]   OBJ       500
    x[1552]   c2080     -1
    x[1552]   c2112     -1
    x[1552]   c2208     -1
    x[1552]   c2240     -1
    x[1552]   c2336     -1
    x[1552]   c2368     -1
    x[1552]   c2464     -1
    x[1552]   c2496     -1
    x[1552]   OBJ       100
    x[1553]   c1296_1   -1
    x[1553]   c1344     -1
    x[1553]   c1392     -1
    x[1553]   c1440     -1
    x[1553]   c1488     -1
    x[1553]   c1536     -1
    x[1553]   c1584     -1
    x[1553]   c1632     -1
    x[1553]   c2592     40
    x[1553]   OBJ       1200
    x[1554]   c1312_1   -1
    x[1554]   c1360     -1
    x[1554]   c1504     -1
    x[1554]   c1552     -1
    x[1554]   c2592     20
    x[1554]   OBJ       500
    x[1555]   c1328     -1
    x[1555]   c1376     -1
    x[1555]   c2592     2
    x[1555]   OBJ       50
    x[1556]   c1520     -1
    x[1556]   c1568     -1
    x[1556]   c2592     2
    x[1556]   OBJ       50
    x[1557]   c1408     -1
    x[1557]   c1456     -1
    x[1557]   c1600     -1
    x[1557]   c1648     -1
    x[1557]   c2592     10
    x[1557]   OBJ       125
    x[1558]   c1424     -1
    x[1558]   c1472     -1
    x[1558]   c2592     2
    x[1558]   OBJ       50
    x[1559]   c1616     -1
    x[1559]   c1664     -1
    x[1559]   c2592     2
    x[1559]   OBJ       50
    x[1560]   c1680     -1
    x[1560]   c1728     -1
    x[1560]   c1776     -1
    x[1560]   c1824     -1
    x[1560]   c1872     -1
    x[1560]   c1920     -1
    x[1560]   c1968     -1
    x[1560]   c2016     -1
    x[1560]   c2592     40
    x[1560]   OBJ       1200
    x[1561]   c1696     -1
    x[1561]   c1744     -1
    x[1561]   c1888     -1
    x[1561]   c1936     -1
    x[1561]   c2592     20
    x[1561]   OBJ       500
    x[1562]   c1712     -1
    x[1562]   c1760     -1
    x[1562]   c2592     2
    x[1562]   OBJ       50
    x[1563]   c1904     -1
    x[1563]   c1952     -1
    x[1563]   c2592     2
    x[1563]   OBJ       50
    x[1564]   c1792     -1
    x[1564]   c1840     -1
    x[1564]   c1984     -1
    x[1564]   c2032     -1
    x[1564]   c2592     10
    x[1564]   OBJ       125
    x[1565]   c1808     -1
    x[1565]   c1856     -1
    x[1565]   c2592     2
    x[1565]   OBJ       50
    x[1566]   c2000     -1
    x[1566]   c2048     -1
    x[1566]   c2592     2
    x[1566]   OBJ       50
    x[1567]   c1040_1   -1
    x[1567]   c1072_1   -1
    x[1567]   c1104_1   -1
    x[1567]   c1136_1   -1
    x[1567]   c1168_1   -1
    x[1567]   c1200_1   -1
    x[1567]   c1232_1   -1
    x[1567]   c1264_1   -1
    x[1567]   OBJ       10
    x[1568]   c1056_1   -1
    x[1568]   c1088_1   -1
    x[1568]   c1120_1   -1
    x[1568]   c1152_1   -1
    x[1568]   c1184_1   -1
    x[1568]   c1216_1   -1
    x[1568]   c1248_1   -1
    x[1568]   c1280_1   -1
    x[1568]   OBJ       10
    MARKER    'MARKER'                 'INTEND'
    x[1569]   c1_1      1
    x[1569]   c2593     1
    x[1569]   c1        -1
    x[1569]   c17       -1
    x[1569]   c1025     1
    x[1570]   c2561     50
    x[1570]   c1        1
    x[1571]   c2_1      1
    x[1571]   c2594     1
    x[1571]   c2        -1
    x[1571]   c18       -1
    x[1571]   c1026     1
    x[1572]   c2562     50
    x[1572]   c2        1
    x[1573]   c3_1      1
    x[1573]   c2595     1
    x[1573]   c3        -1
    x[1573]   c19       -1
    x[1573]   c1027     1
    x[1574]   c2563     50
    x[1574]   c3        1
    x[1575]   c4_1      1
    x[1575]   c2596     1
    x[1575]   c4        -1
    x[1575]   c20       -1
    x[1575]   c1028     1
    x[1576]   c2564     50
    x[1576]   c4        1
    x[1577]   c5_1      1
    x[1577]   c2597     1
    x[1577]   c5        -1
    x[1577]   c21       -1
    x[1577]   c1029     1
    x[1578]   c2565     50
    x[1578]   c5        1
    x[1579]   c6_1      1
    x[1579]   c2598     1
    x[1579]   c6        -1
    x[1579]   c22       -1
    x[1579]   c1030     1
    x[1580]   c2566     50
    x[1580]   c6        1
    x[1581]   c7_1      1
    x[1581]   c2599     1
    x[1581]   c7        -1
    x[1581]   c23       -1
    x[1581]   c1031     1
    x[1582]   c2567     50
    x[1582]   c7        1
    x[1583]   c8_1      1
    x[1583]   c2600     1
    x[1583]   c8        -1
    x[1583]   c24       -1
    x[1583]   c1032     1
    x[1584]   c2568     50
    x[1584]   c8        1
    x[1585]   c9_1      1
    x[1585]   c2601     1
    x[1585]   c9        -1
    x[1585]   c25       -1
    x[1585]   c1033     1
    x[1586]   c2569     50
    x[1586]   c9        1
    x[1587]   c10_1     1
    x[1587]   c2602     1
    x[1587]   c10       -1
    x[1587]   c26       -1
    x[1587]   c1034     1
    x[1588]   c2570     50
    x[1588]   c10       1
    x[1589]   c11_1     1
    x[1589]   c2603     1
    x[1589]   c11       -1
    x[1589]   c27       -1
    x[1589]   c1035     1
    x[1590]   c2571     50
    x[1590]   c11       1
    x[1591]   c12_1     1
    x[1591]   c2604     1
    x[1591]   c12       -1
    x[1591]   c28       -1
    x[1591]   c1036     1
    x[1592]   c2572     50
    x[1592]   c12       1
    x[1593]   c13_1     1
    x[1593]   c2605     1
    x[1593]   c13       -1
    x[1593]   c29       -1
    x[1593]   c1037     1
    x[1594]   c2573     50
    x[1594]   c13       1
    x[1595]   c14_1     1
    x[1595]   c2606     1
    x[1595]   c14       -1
    x[1595]   c30       -1
    x[1595]   c1038     1
    x[1596]   c2574     50
    x[1596]   c14       1
    x[1597]   c15_1     1
    x[1597]   c2607     1
    x[1597]   c15       -1
    x[1597]   c31       -1
    x[1597]   c1039     1
    x[1598]   c2575     50
    x[1598]   c15       1
    x[1599]   c16_1     1
    x[1599]   c2608     1
    x[1599]   c16       -1
    x[1599]   c32       -1
    x[1599]   c1040     1
    x[1600]   c2576     50
    x[1600]   c16       1
    x[1601]   c257_1    1
    x[1601]   c2577     1
    x[1601]   c17       1
    x[1601]   c513      -1
    x[1601]   c529      -1
    x[1602]   c258_1    1
    x[1602]   c2578     1
    x[1602]   c18       1
    x[1602]   c514      -1
    x[1602]   c530      -1
    x[1603]   c259_1    1
    x[1603]   c2579     1
    x[1603]   c19       1
    x[1603]   c515      -1
    x[1603]   c531      -1
    x[1604]   c260_1    1
    x[1604]   c2580     1
    x[1604]   c20       1
    x[1604]   c516      -1
    x[1604]   c532      -1
    x[1605]   c261_1    1
    x[1605]   c2581     1
    x[1605]   c21       1
    x[1605]   c517      -1
    x[1605]   c533      -1
    x[1606]   c262_1    1
    x[1606]   c2582     1
    x[1606]   c22       1
    x[1606]   c518      -1
    x[1606]   c534      -1
    x[1607]   c263_1    1
    x[1607]   c2583     1
    x[1607]   c23       1
    x[1607]   c519      -1
    x[1607]   c535      -1
    x[1608]   c264_1    1
    x[1608]   c2584     1
    x[1608]   c24       1
    x[1608]   c520      -1
    x[1608]   c536      -1
    x[1609]   c265_1    1
    x[1609]   c2585     1
    x[1609]   c25       1
    x[1609]   c521      -1
    x[1609]   c537      -1
    x[1610]   c266_1    1
    x[1610]   c2586     1
    x[1610]   c26       1
    x[1610]   c522      -1
    x[1610]   c538      -1
    x[1611]   c267_1    1
    x[1611]   c2587     1
    x[1611]   c27       1
    x[1611]   c523      -1
    x[1611]   c539      -1
    x[1612]   c268_1    1
    x[1612]   c2588     1
    x[1612]   c28       1
    x[1612]   c524      -1
    x[1612]   c540      -1
    x[1613]   c269_1    1
    x[1613]   c2589     1
    x[1613]   c29       1
    x[1613]   c525      -1
    x[1613]   c541      -1
    x[1614]   c270_1    1
    x[1614]   c2590     1
    x[1614]   c30       1
    x[1614]   c526      -1
    x[1614]   c542      -1
    x[1615]   c271_1    1
    x[1615]   c2591     1
    x[1615]   c31       1
    x[1615]   c527      -1
    x[1615]   c543      -1
    x[1616]   c272_1    1
    x[1616]   c2592     1
    x[1616]   c32       1
    x[1616]   c528      -1
    x[1616]   c544      -1
    x[1617]   c17_1     1
    x[1617]   c2609     1
    x[1617]   c33       -1
    x[1617]   c49       -1
    x[1617]   c1041     1
    x[1618]   c2561     10
    x[1618]   c33       1
    x[1619]   c18_1     1
    x[1619]   c2610     1
    x[1619]   c34       -1
    x[1619]   c50       -1
    x[1619]   c1042     1
    x[1620]   c2562     10
    x[1620]   c34       1
    x[1621]   c19_1     1
    x[1621]   c2611     1
    x[1621]   c35       -1
    x[1621]   c51       -1
    x[1621]   c1043     1
    x[1622]   c2563     10
    x[1622]   c35       1
    x[1623]   c20_1     1
    x[1623]   c2612     1
    x[1623]   c36       -1
    x[1623]   c52       -1
    x[1623]   c1044     1
    x[1624]   c2564     10
    x[1624]   c36       1
    x[1625]   c21_1     1
    x[1625]   c2613     1
    x[1625]   c37       -1
    x[1625]   c53       -1
    x[1625]   c1045     1
    x[1626]   c2565     10
    x[1626]   c37       1
    x[1627]   c22_1     1
    x[1627]   c2614     1
    x[1627]   c38       -1
    x[1627]   c54       -1
    x[1627]   c1046     1
    x[1628]   c2566     10
    x[1628]   c38       1
    x[1629]   c23_1     1
    x[1629]   c2615     1
    x[1629]   c39       -1
    x[1629]   c55       -1
    x[1629]   c1047     1
    x[1630]   c2567     10
    x[1630]   c39       1
    x[1631]   c24_1     1
    x[1631]   c2616     1
    x[1631]   c40       -1
    x[1631]   c56       -1
    x[1631]   c1048     1
    x[1632]   c2568     10
    x[1632]   c40       1
    x[1633]   c25_1     1
    x[1633]   c2617     1
    x[1633]   c41       -1
    x[1633]   c57       -1
    x[1633]   c1049     1
    x[1634]   c2569     10
    x[1634]   c41       1
    x[1635]   c26_1     1
    x[1635]   c2618     1
    x[1635]   c42       -1
    x[1635]   c58       -1
    x[1635]   c1050     1
    x[1636]   c2570     10
    x[1636]   c42       1
    x[1637]   c27_1     1
    x[1637]   c2619     1
    x[1637]   c43       -1
    x[1637]   c59       -1
    x[1637]   c1051     1
    x[1638]   c2571     10
    x[1638]   c43       1
    x[1639]   c28_1     1
    x[1639]   c2620     1
    x[1639]   c44       -1
    x[1639]   c60       -1
    x[1639]   c1052     1
    x[1640]   c2572     10
    x[1640]   c44       1
    x[1641]   c29_1     1
    x[1641]   c2621     1
    x[1641]   c45       -1
    x[1641]   c61       -1
    x[1641]   c1053     1
    x[1642]   c2573     10
    x[1642]   c45       1
    x[1643]   c30_1     1
    x[1643]   c2622     1
    x[1643]   c46       -1
    x[1643]   c62       -1
    x[1643]   c1054     1
    x[1644]   c2574     10
    x[1644]   c46       1
    x[1645]   c31_1     1
    x[1645]   c2623     1
    x[1645]   c47       -1
    x[1645]   c63       -1
    x[1645]   c1055     1
    x[1646]   c2575     10
    x[1646]   c47       1
    x[1647]   c32_1     1
    x[1647]   c2624     1
    x[1647]   c48       -1
    x[1647]   c64       -1
    x[1647]   c1056     1
    x[1648]   c2576     10
    x[1648]   c48       1
    x[1649]   c273_1    1
    x[1649]   c2577     1
    x[1649]   c49       1
    x[1649]   c545      -1
    x[1649]   c561      -1
    x[1650]   c274_1    1
    x[1650]   c2578     1
    x[1650]   c50       1
    x[1650]   c546      -1
    x[1650]   c562      -1
    x[1651]   c275_1    1
    x[1651]   c2579     1
    x[1651]   c51       1
    x[1651]   c547      -1
    x[1651]   c563      -1
    x[1652]   c276_1    1
    x[1652]   c2580     1
    x[1652]   c52       1
    x[1652]   c548      -1
    x[1652]   c564      -1
    x[1653]   c277_1    1
    x[1653]   c2581     1
    x[1653]   c53       1
    x[1653]   c549      -1
    x[1653]   c565      -1
    x[1654]   c278_1    1
    x[1654]   c2582     1
    x[1654]   c54       1
    x[1654]   c550      -1
    x[1654]   c566      -1
    x[1655]   c279_1    1
    x[1655]   c2583     1
    x[1655]   c55       1
    x[1655]   c551      -1
    x[1655]   c567      -1
    x[1656]   c280_1    1
    x[1656]   c2584     1
    x[1656]   c56       1
    x[1656]   c552      -1
    x[1656]   c568      -1
    x[1657]   c281_1    1
    x[1657]   c2585     1
    x[1657]   c57       1
    x[1657]   c553      -1
    x[1657]   c569      -1
    x[1658]   c282_1    1
    x[1658]   c2586     1
    x[1658]   c58       1
    x[1658]   c554      -1
    x[1658]   c570      -1
    x[1659]   c283_1    1
    x[1659]   c2587     1
    x[1659]   c59       1
    x[1659]   c555      -1
    x[1659]   c571      -1
    x[1660]   c284_1    1
    x[1660]   c2588     1
    x[1660]   c60       1
    x[1660]   c556      -1
    x[1660]   c572      -1
    x[1661]   c285_1    1
    x[1661]   c2589     1
    x[1661]   c61       1
    x[1661]   c557      -1
    x[1661]   c573      -1
    x[1662]   c286_1    1
    x[1662]   c2590     1
    x[1662]   c62       1
    x[1662]   c558      -1
    x[1662]   c574      -1
    x[1663]   c287_1    1
    x[1663]   c2591     1
    x[1663]   c63       1
    x[1663]   c559      -1
    x[1663]   c575      -1
    x[1664]   c288_1    1
    x[1664]   c2592     1
    x[1664]   c64       1
    x[1664]   c560      -1
    x[1664]   c576      -1
    x[1665]   c33_1     1
    x[1665]   c2593     1
    x[1665]   c65       -1
    x[1665]   c81       -1
    x[1665]   c1057     1
    x[1666]   c2561     50
    x[1666]   c65       1
    x[1667]   c34_1     1
    x[1667]   c2594     1
    x[1667]   c66       -1
    x[1667]   c82       -1
    x[1667]   c1058     1
    x[1668]   c2562     50
    x[1668]   c66       1
    x[1669]   c35_1     1
    x[1669]   c2595     1
    x[1669]   c67       -1
    x[1669]   c83       -1
    x[1669]   c1059     1
    x[1670]   c2563     50
    x[1670]   c67       1
    x[1671]   c36_1     1
    x[1671]   c2596     1
    x[1671]   c68       -1
    x[1671]   c84       -1
    x[1671]   c1060     1
    x[1672]   c2564     50
    x[1672]   c68       1
    x[1673]   c37_1     1
    x[1673]   c2597     1
    x[1673]   c69       -1
    x[1673]   c85       -1
    x[1673]   c1061     1
    x[1674]   c2565     50
    x[1674]   c69       1
    x[1675]   c38_1     1
    x[1675]   c2598     1
    x[1675]   c70       -1
    x[1675]   c86       -1
    x[1675]   c1062     1
    x[1676]   c2566     50
    x[1676]   c70       1
    x[1677]   c39_1     1
    x[1677]   c2599     1
    x[1677]   c71       -1
    x[1677]   c87       -1
    x[1677]   c1063     1
    x[1678]   c2567     50
    x[1678]   c71       1
    x[1679]   c40_1     1
    x[1679]   c2600     1
    x[1679]   c72       -1
    x[1679]   c88       -1
    x[1679]   c1064     1
    x[1680]   c2568     50
    x[1680]   c72       1
    x[1681]   c41_1     1
    x[1681]   c2601     1
    x[1681]   c73       -1
    x[1681]   c89       -1
    x[1681]   c1065     1
    x[1682]   c2569     50
    x[1682]   c73       1
    x[1683]   c42_1     1
    x[1683]   c2602     1
    x[1683]   c74       -1
    x[1683]   c90       -1
    x[1683]   c1066     1
    x[1684]   c2570     50
    x[1684]   c74       1
    x[1685]   c43_1     1
    x[1685]   c2603     1
    x[1685]   c75       -1
    x[1685]   c91       -1
    x[1685]   c1067     1
    x[1686]   c2571     50
    x[1686]   c75       1
    x[1687]   c44_1     1
    x[1687]   c2604     1
    x[1687]   c76       -1
    x[1687]   c92       -1
    x[1687]   c1068     1
    x[1688]   c2572     50
    x[1688]   c76       1
    x[1689]   c45_1     1
    x[1689]   c2605     1
    x[1689]   c77       -1
    x[1689]   c93       -1
    x[1689]   c1069     1
    x[1690]   c2573     50
    x[1690]   c77       1
    x[1691]   c46_1     1
    x[1691]   c2606     1
    x[1691]   c78       -1
    x[1691]   c94       -1
    x[1691]   c1070     1
    x[1692]   c2574     50
    x[1692]   c78       1
    x[1693]   c47_1     1
    x[1693]   c2607     1
    x[1693]   c79       -1
    x[1693]   c95       -1
    x[1693]   c1071     1
    x[1694]   c2575     50
    x[1694]   c79       1
    x[1695]   c48_1     1
    x[1695]   c2608     1
    x[1695]   c80       -1
    x[1695]   c96       -1
    x[1695]   c1072     1
    x[1696]   c2576     50
    x[1696]   c80       1
    x[1697]   c289_1    1
    x[1697]   c2577     1
    x[1697]   c81       1
    x[1697]   c577      -1
    x[1697]   c593      -1
    x[1698]   c290_1    1
    x[1698]   c2578     1
    x[1698]   c82       1
    x[1698]   c578      -1
    x[1698]   c594      -1
    x[1699]   c291_1    1
    x[1699]   c2579     1
    x[1699]   c83       1
    x[1699]   c579      -1
    x[1699]   c595      -1
    x[1700]   c292_1    1
    x[1700]   c2580     1
    x[1700]   c84       1
    x[1700]   c580      -1
    x[1700]   c596      -1
    x[1701]   c293_1    1
    x[1701]   c2581     1
    x[1701]   c85       1
    x[1701]   c581      -1
    x[1701]   c597      -1
    x[1702]   c294_1    1
    x[1702]   c2582     1
    x[1702]   c86       1
    x[1702]   c582      -1
    x[1702]   c598      -1
    x[1703]   c295_1    1
    x[1703]   c2583     1
    x[1703]   c87       1
    x[1703]   c583      -1
    x[1703]   c599      -1
    x[1704]   c296_1    1
    x[1704]   c2584     1
    x[1704]   c88       1
    x[1704]   c584      -1
    x[1704]   c600      -1
    x[1705]   c297_1    1
    x[1705]   c2585     1
    x[1705]   c89       1
    x[1705]   c585      -1
    x[1705]   c601      -1
    x[1706]   c298_1    1
    x[1706]   c2586     1
    x[1706]   c90       1
    x[1706]   c586      -1
    x[1706]   c602      -1
    x[1707]   c299_1    1
    x[1707]   c2587     1
    x[1707]   c91       1
    x[1707]   c587      -1
    x[1707]   c603      -1
    x[1708]   c300_1    1
    x[1708]   c2588     1
    x[1708]   c92       1
    x[1708]   c588      -1
    x[1708]   c604      -1
    x[1709]   c301_1    1
    x[1709]   c2589     1
    x[1709]   c93       1
    x[1709]   c589      -1
    x[1709]   c605      -1
    x[1710]   c302_1    1
    x[1710]   c2590     1
    x[1710]   c94       1
    x[1710]   c590      -1
    x[1710]   c606      -1
    x[1711]   c303_1    1
    x[1711]   c2591     1
    x[1711]   c95       1
    x[1711]   c591      -1
    x[1711]   c607      -1
    x[1712]   c304_1    1
    x[1712]   c2592     1
    x[1712]   c96       1
    x[1712]   c592      -1
    x[1712]   c608      -1
    x[1713]   c49_1     1
    x[1713]   c2609     1
    x[1713]   c97       -1
    x[1713]   c113      -1
    x[1713]   c1073     1
    x[1714]   c2561     30
    x[1714]   c97       1
    x[1715]   c50_1     1
    x[1715]   c2610     1
    x[1715]   c98       -1
    x[1715]   c114      -1
    x[1715]   c1074     1
    x[1716]   c2562     30
    x[1716]   c98       1
    x[1717]   c51_1     1
    x[1717]   c2611     1
    x[1717]   c99       -1
    x[1717]   c115      -1
    x[1717]   c1075     1
    x[1718]   c2563     30
    x[1718]   c99       1
    x[1719]   c52_1     1
    x[1719]   c2612     1
    x[1719]   c100      -1
    x[1719]   c116      -1
    x[1719]   c1076     1
    x[1720]   c2564     30
    x[1720]   c100      1
    x[1721]   c53_1     1
    x[1721]   c2613     1
    x[1721]   c101      -1
    x[1721]   c117      -1
    x[1721]   c1077     1
    x[1722]   c2565     30
    x[1722]   c101      1
    x[1723]   c54_1     1
    x[1723]   c2614     1
    x[1723]   c102      -1
    x[1723]   c118      -1
    x[1723]   c1078     1
    x[1724]   c2566     30
    x[1724]   c102      1
    x[1725]   c55_1     1
    x[1725]   c2615     1
    x[1725]   c103      -1
    x[1725]   c119      -1
    x[1725]   c1079     1
    x[1726]   c2567     30
    x[1726]   c103      1
    x[1727]   c56_1     1
    x[1727]   c2616     1
    x[1727]   c104      -1
    x[1727]   c120      -1
    x[1727]   c1080     1
    x[1728]   c2568     30
    x[1728]   c104      1
    x[1729]   c57_1     1
    x[1729]   c2617     1
    x[1729]   c105      -1
    x[1729]   c121      -1
    x[1729]   c1081     1
    x[1730]   c2569     30
    x[1730]   c105      1
    x[1731]   c58_1     1
    x[1731]   c2618     1
    x[1731]   c106      -1
    x[1731]   c122      -1
    x[1731]   c1082     1
    x[1732]   c2570     30
    x[1732]   c106      1
    x[1733]   c59_1     1
    x[1733]   c2619     1
    x[1733]   c107      -1
    x[1733]   c123      -1
    x[1733]   c1083     1
    x[1734]   c2571     30
    x[1734]   c107      1
    x[1735]   c60_1     1
    x[1735]   c2620     1
    x[1735]   c108      -1
    x[1735]   c124      -1
    x[1735]   c1084     1
    x[1736]   c2572     30
    x[1736]   c108      1
    x[1737]   c61_1     1
    x[1737]   c2621     1
    x[1737]   c109      -1
    x[1737]   c125      -1
    x[1737]   c1085     1
    x[1738]   c2573     30
    x[1738]   c109      1
    x[1739]   c62_1     1
    x[1739]   c2622     1
    x[1739]   c110      -1
    x[1739]   c126      -1
    x[1739]   c1086     1
    x[1740]   c2574     30
    x[1740]   c110      1
    x[1741]   c63_1     1
    x[1741]   c2623     1
    x[1741]   c111      -1
    x[1741]   c127      -1
    x[1741]   c1087     1
    x[1742]   c2575     30
    x[1742]   c111      1
    x[1743]   c64_1     1
    x[1743]   c2624     1
    x[1743]   c112      -1
    x[1743]   c128      -1
    x[1743]   c1088     1
    x[1744]   c2576     30
    x[1744]   c112      1
    x[1745]   c305_1    1
    x[1745]   c2577     1
    x[1745]   c113      1
    x[1745]   c609      -1
    x[1745]   c625      -1
    x[1746]   c306_1    1
    x[1746]   c2578     1
    x[1746]   c114      1
    x[1746]   c610      -1
    x[1746]   c626      -1
    x[1747]   c307_1    1
    x[1747]   c2579     1
    x[1747]   c115      1
    x[1747]   c611      -1
    x[1747]   c627      -1
    x[1748]   c308_1    1
    x[1748]   c2580     1
    x[1748]   c116      1
    x[1748]   c612      -1
    x[1748]   c628      -1
    x[1749]   c309_1    1
    x[1749]   c2581     1
    x[1749]   c117      1
    x[1749]   c613      -1
    x[1749]   c629      -1
    x[1750]   c310_1    1
    x[1750]   c2582     1
    x[1750]   c118      1
    x[1750]   c614      -1
    x[1750]   c630      -1
    x[1751]   c311_1    1
    x[1751]   c2583     1
    x[1751]   c119      1
    x[1751]   c615      -1
    x[1751]   c631      -1
    x[1752]   c312_1    1
    x[1752]   c2584     1
    x[1752]   c120      1
    x[1752]   c616      -1
    x[1752]   c632      -1
    x[1753]   c313_1    1
    x[1753]   c2585     1
    x[1753]   c121      1
    x[1753]   c617      -1
    x[1753]   c633      -1
    x[1754]   c314_1    1
    x[1754]   c2586     1
    x[1754]   c122      1
    x[1754]   c618      -1
    x[1754]   c634      -1
    x[1755]   c315_1    1
    x[1755]   c2587     1
    x[1755]   c123      1
    x[1755]   c619      -1
    x[1755]   c635      -1
    x[1756]   c316_1    1
    x[1756]   c2588     1
    x[1756]   c124      1
    x[1756]   c620      -1
    x[1756]   c636      -1
    x[1757]   c317_1    1
    x[1757]   c2589     1
    x[1757]   c125      1
    x[1757]   c621      -1
    x[1757]   c637      -1
    x[1758]   c318_1    1
    x[1758]   c2590     1
    x[1758]   c126      1
    x[1758]   c622      -1
    x[1758]   c638      -1
    x[1759]   c319_1    1
    x[1759]   c2591     1
    x[1759]   c127      1
    x[1759]   c623      -1
    x[1759]   c639      -1
    x[1760]   c320_1    1
    x[1760]   c2592     1
    x[1760]   c128      1
    x[1760]   c624      -1
    x[1760]   c640      -1
    x[1761]   c65_1     1
    x[1761]   c2593     1
    x[1761]   c129      -1
    x[1761]   c145      -1
    x[1761]   c1089     1
    x[1762]   c2561     50
    x[1762]   c129      1
    x[1763]   c66_1     1
    x[1763]   c2594     1
    x[1763]   c130      -1
    x[1763]   c146      -1
    x[1763]   c1090     1
    x[1764]   c2562     50
    x[1764]   c130      1
    x[1765]   c67_1     1
    x[1765]   c2595     1
    x[1765]   c131      -1
    x[1765]   c147      -1
    x[1765]   c1091     1
    x[1766]   c2563     50
    x[1766]   c131      1
    x[1767]   c68_1     1
    x[1767]   c2596     1
    x[1767]   c132      -1
    x[1767]   c148      -1
    x[1767]   c1092     1
    x[1768]   c2564     50
    x[1768]   c132      1
    x[1769]   c69_1     1
    x[1769]   c2597     1
    x[1769]   c133      -1
    x[1769]   c149      -1
    x[1769]   c1093     1
    x[1770]   c2565     50
    x[1770]   c133      1
    x[1771]   c70_1     1
    x[1771]   c2598     1
    x[1771]   c134      -1
    x[1771]   c150      -1
    x[1771]   c1094     1
    x[1772]   c2566     50
    x[1772]   c134      1
    x[1773]   c71_1     1
    x[1773]   c2599     1
    x[1773]   c135      -1
    x[1773]   c151      -1
    x[1773]   c1095     1
    x[1774]   c2567     50
    x[1774]   c135      1
    x[1775]   c72_1     1
    x[1775]   c2600     1
    x[1775]   c136      -1
    x[1775]   c152      -1
    x[1775]   c1096     1
    x[1776]   c2568     50
    x[1776]   c136      1
    x[1777]   c73_1     1
    x[1777]   c2601     1
    x[1777]   c137      -1
    x[1777]   c153      -1
    x[1777]   c1097     1
    x[1778]   c2569     50
    x[1778]   c137      1
    x[1779]   c74_1     1
    x[1779]   c2602     1
    x[1779]   c138      -1
    x[1779]   c154      -1
    x[1779]   c1098     1
    x[1780]   c2570     50
    x[1780]   c138      1
    x[1781]   c75_1     1
    x[1781]   c2603     1
    x[1781]   c139      -1
    x[1781]   c155      -1
    x[1781]   c1099     1
    x[1782]   c2571     50
    x[1782]   c139      1
    x[1783]   c76_1     1
    x[1783]   c2604     1
    x[1783]   c140      -1
    x[1783]   c156      -1
    x[1783]   c1100     1
    x[1784]   c2572     50
    x[1784]   c140      1
    x[1785]   c77_1     1
    x[1785]   c2605     1
    x[1785]   c141      -1
    x[1785]   c157      -1
    x[1785]   c1101     1
    x[1786]   c2573     50
    x[1786]   c141      1
    x[1787]   c78_1     1
    x[1787]   c2606     1
    x[1787]   c142      -1
    x[1787]   c158      -1
    x[1787]   c1102     1
    x[1788]   c2574     50
    x[1788]   c142      1
    x[1789]   c79_1     1
    x[1789]   c2607     1
    x[1789]   c143      -1
    x[1789]   c159      -1
    x[1789]   c1103     1
    x[1790]   c2575     50
    x[1790]   c143      1
    x[1791]   c80_1     1
    x[1791]   c2608     1
    x[1791]   c144      -1
    x[1791]   c160      -1
    x[1791]   c1104     1
    x[1792]   c2576     50
    x[1792]   c144      1
    x[1793]   c321_1    1
    x[1793]   c2577     1
    x[1793]   c145      1
    x[1793]   c641      -1
    x[1793]   c657      -1
    x[1794]   c322_1    1
    x[1794]   c2578     1
    x[1794]   c146      1
    x[1794]   c642      -1
    x[1794]   c658      -1
    x[1795]   c323_1    1
    x[1795]   c2579     1
    x[1795]   c147      1
    x[1795]   c643      -1
    x[1795]   c659      -1
    x[1796]   c324_1    1
    x[1796]   c2580     1
    x[1796]   c148      1
    x[1796]   c644      -1
    x[1796]   c660      -1
    x[1797]   c325_1    1
    x[1797]   c2581     1
    x[1797]   c149      1
    x[1797]   c645      -1
    x[1797]   c661      -1
    x[1798]   c326_1    1
    x[1798]   c2582     1
    x[1798]   c150      1
    x[1798]   c646      -1
    x[1798]   c662      -1
    x[1799]   c327_1    1
    x[1799]   c2583     1
    x[1799]   c151      1
    x[1799]   c647      -1
    x[1799]   c663      -1
    x[1800]   c328_1    1
    x[1800]   c2584     1
    x[1800]   c152      1
    x[1800]   c648      -1
    x[1800]   c664      -1
    x[1801]   c329_1    1
    x[1801]   c2585     1
    x[1801]   c153      1
    x[1801]   c649      -1
    x[1801]   c665      -1
    x[1802]   c330_1    1
    x[1802]   c2586     1
    x[1802]   c154      1
    x[1802]   c650      -1
    x[1802]   c666      -1
    x[1803]   c331_1    1
    x[1803]   c2587     1
    x[1803]   c155      1
    x[1803]   c651      -1
    x[1803]   c667      -1
    x[1804]   c332_1    1
    x[1804]   c2588     1
    x[1804]   c156      1
    x[1804]   c652      -1
    x[1804]   c668      -1
    x[1805]   c333_1    1
    x[1805]   c2589     1
    x[1805]   c157      1
    x[1805]   c653      -1
    x[1805]   c669      -1
    x[1806]   c334_1    1
    x[1806]   c2590     1
    x[1806]   c158      1
    x[1806]   c654      -1
    x[1806]   c670      -1
    x[1807]   c335_1    1
    x[1807]   c2591     1
    x[1807]   c159      1
    x[1807]   c655      -1
    x[1807]   c671      -1
    x[1808]   c336_1    1
    x[1808]   c2592     1
    x[1808]   c160      1
    x[1808]   c656      -1
    x[1808]   c672      -1
    x[1809]   c81_1     1
    x[1809]   c2609     1
    x[1809]   c161      -1
    x[1809]   c177      -1
    x[1809]   c1105     1
    x[1810]   c2561     10
    x[1810]   c161      1
    x[1811]   c82_1     1
    x[1811]   c2610     1
    x[1811]   c162      -1
    x[1811]   c178      -1
    x[1811]   c1106     1
    x[1812]   c2562     10
    x[1812]   c162      1
    x[1813]   c83_1     1
    x[1813]   c2611     1
    x[1813]   c163      -1
    x[1813]   c179      -1
    x[1813]   c1107     1
    x[1814]   c2563     10
    x[1814]   c163      1
    x[1815]   c84_1     1
    x[1815]   c2612     1
    x[1815]   c164      -1
    x[1815]   c180      -1
    x[1815]   c1108     1
    x[1816]   c2564     10
    x[1816]   c164      1
    x[1817]   c85_1     1
    x[1817]   c2613     1
    x[1817]   c165      -1
    x[1817]   c181      -1
    x[1817]   c1109     1
    x[1818]   c2565     10
    x[1818]   c165      1
    x[1819]   c86_1     1
    x[1819]   c2614     1
    x[1819]   c166      -1
    x[1819]   c182      -1
    x[1819]   c1110     1
    x[1820]   c2566     10
    x[1820]   c166      1
    x[1821]   c87_1     1
    x[1821]   c2615     1
    x[1821]   c167      -1
    x[1821]   c183      -1
    x[1821]   c1111     1
    x[1822]   c2567     10
    x[1822]   c167      1
    x[1823]   c88_1     1
    x[1823]   c2616     1
    x[1823]   c168      -1
    x[1823]   c184      -1
    x[1823]   c1112     1
    x[1824]   c2568     10
    x[1824]   c168      1
    x[1825]   c89_1     1
    x[1825]   c2617     1
    x[1825]   c169      -1
    x[1825]   c185      -1
    x[1825]   c1113     1
    x[1826]   c2569     10
    x[1826]   c169      1
    x[1827]   c90_1     1
    x[1827]   c2618     1
    x[1827]   c170      -1
    x[1827]   c186      -1
    x[1827]   c1114     1
    x[1828]   c2570     10
    x[1828]   c170      1
    x[1829]   c91_1     1
    x[1829]   c2619     1
    x[1829]   c171      -1
    x[1829]   c187      -1
    x[1829]   c1115     1
    x[1830]   c2571     10
    x[1830]   c171      1
    x[1831]   c92_1     1
    x[1831]   c2620     1
    x[1831]   c172      -1
    x[1831]   c188      -1
    x[1831]   c1116     1
    x[1832]   c2572     10
    x[1832]   c172      1
    x[1833]   c93_1     1
    x[1833]   c2621     1
    x[1833]   c173      -1
    x[1833]   c189      -1
    x[1833]   c1117     1
    x[1834]   c2573     10
    x[1834]   c173      1
    x[1835]   c94_1     1
    x[1835]   c2622     1
    x[1835]   c174      -1
    x[1835]   c190      -1
    x[1835]   c1118     1
    x[1836]   c2574     10
    x[1836]   c174      1
    x[1837]   c95_1     1
    x[1837]   c2623     1
    x[1837]   c175      -1
    x[1837]   c191      -1
    x[1837]   c1119     1
    x[1838]   c2575     10
    x[1838]   c175      1
    x[1839]   c96_1     1
    x[1839]   c2624     1
    x[1839]   c176      -1
    x[1839]   c192      -1
    x[1839]   c1120     1
    x[1840]   c2576     10
    x[1840]   c176      1
    x[1841]   c337_1    1
    x[1841]   c2577     1
    x[1841]   c177      1
    x[1841]   c673      -1
    x[1841]   c689      -1
    x[1842]   c338_1    1
    x[1842]   c2578     1
    x[1842]   c178      1
    x[1842]   c674      -1
    x[1842]   c690      -1
    x[1843]   c339_1    1
    x[1843]   c2579     1
    x[1843]   c179      1
    x[1843]   c675      -1
    x[1843]   c691      -1
    x[1844]   c340_1    1
    x[1844]   c2580     1
    x[1844]   c180      1
    x[1844]   c676      -1
    x[1844]   c692      -1
    x[1845]   c341_1    1
    x[1845]   c2581     1
    x[1845]   c181      1
    x[1845]   c677      -1
    x[1845]   c693      -1
    x[1846]   c342_1    1
    x[1846]   c2582     1
    x[1846]   c182      1
    x[1846]   c678      -1
    x[1846]   c694      -1
    x[1847]   c343_1    1
    x[1847]   c2583     1
    x[1847]   c183      1
    x[1847]   c679      -1
    x[1847]   c695      -1
    x[1848]   c344_1    1
    x[1848]   c2584     1
    x[1848]   c184      1
    x[1848]   c680      -1
    x[1848]   c696      -1
    x[1849]   c345_1    1
    x[1849]   c2585     1
    x[1849]   c185      1
    x[1849]   c681      -1
    x[1849]   c697      -1
    x[1850]   c346_1    1
    x[1850]   c2586     1
    x[1850]   c186      1
    x[1850]   c682      -1
    x[1850]   c698      -1
    x[1851]   c347_1    1
    x[1851]   c2587     1
    x[1851]   c187      1
    x[1851]   c683      -1
    x[1851]   c699      -1
    x[1852]   c348_1    1
    x[1852]   c2588     1
    x[1852]   c188      1
    x[1852]   c684      -1
    x[1852]   c700      -1
    x[1853]   c349_1    1
    x[1853]   c2589     1
    x[1853]   c189      1
    x[1853]   c685      -1
    x[1853]   c701      -1
    x[1854]   c350_1    1
    x[1854]   c2590     1
    x[1854]   c190      1
    x[1854]   c686      -1
    x[1854]   c702      -1
    x[1855]   c351_1    1
    x[1855]   c2591     1
    x[1855]   c191      1
    x[1855]   c687      -1
    x[1855]   c703      -1
    x[1856]   c352_1    1
    x[1856]   c2592     1
    x[1856]   c192      1
    x[1856]   c688      -1
    x[1856]   c704      -1
    x[1857]   c97_1     1
    x[1857]   c2593     1
    x[1857]   c193      -1
    x[1857]   c209      -1
    x[1857]   c1121     1
    x[1858]   c2561     50
    x[1858]   c193      1
    x[1859]   c98_1     1
    x[1859]   c2594     1
    x[1859]   c194      -1
    x[1859]   c210      -1
    x[1859]   c1122     1
    x[1860]   c2562     50
    x[1860]   c194      1
    x[1861]   c99_1     1
    x[1861]   c2595     1
    x[1861]   c195      -1
    x[1861]   c211      -1
    x[1861]   c1123     1
    x[1862]   c2563     50
    x[1862]   c195      1
    x[1863]   c100_1    1
    x[1863]   c2596     1
    x[1863]   c196      -1
    x[1863]   c212      -1
    x[1863]   c1124     1
    x[1864]   c2564     50
    x[1864]   c196      1
    x[1865]   c101_1    1
    x[1865]   c2597     1
    x[1865]   c197      -1
    x[1865]   c213      -1
    x[1865]   c1125     1
    x[1866]   c2565     50
    x[1866]   c197      1
    x[1867]   c102_1    1
    x[1867]   c2598     1
    x[1867]   c198      -1
    x[1867]   c214      -1
    x[1867]   c1126     1
    x[1868]   c2566     50
    x[1868]   c198      1
    x[1869]   c103_1    1
    x[1869]   c2599     1
    x[1869]   c199      -1
    x[1869]   c215      -1
    x[1869]   c1127     1
    x[1870]   c2567     50
    x[1870]   c199      1
    x[1871]   c104_1    1
    x[1871]   c2600     1
    x[1871]   c200      -1
    x[1871]   c216      -1
    x[1871]   c1128     1
    x[1872]   c2568     50
    x[1872]   c200      1
    x[1873]   c105_1    1
    x[1873]   c2601     1
    x[1873]   c201      -1
    x[1873]   c217      -1
    x[1873]   c1129     1
    x[1874]   c2569     50
    x[1874]   c201      1
    x[1875]   c106_1    1
    x[1875]   c2602     1
    x[1875]   c202      -1
    x[1875]   c218      -1
    x[1875]   c1130     1
    x[1876]   c2570     50
    x[1876]   c202      1
    x[1877]   c107_1    1
    x[1877]   c2603     1
    x[1877]   c203      -1
    x[1877]   c219      -1
    x[1877]   c1131     1
    x[1878]   c2571     50
    x[1878]   c203      1
    x[1879]   c108_1    1
    x[1879]   c2604     1
    x[1879]   c204      -1
    x[1879]   c220      -1
    x[1879]   c1132     1
    x[1880]   c2572     50
    x[1880]   c204      1
    x[1881]   c109_1    1
    x[1881]   c2605     1
    x[1881]   c205      -1
    x[1881]   c221      -1
    x[1881]   c1133     1
    x[1882]   c2573     50
    x[1882]   c205      1
    x[1883]   c110_1    1
    x[1883]   c2606     1
    x[1883]   c206      -1
    x[1883]   c222      -1
    x[1883]   c1134     1
    x[1884]   c2574     50
    x[1884]   c206      1
    x[1885]   c111_1    1
    x[1885]   c2607     1
    x[1885]   c207      -1
    x[1885]   c223      -1
    x[1885]   c1135     1
    x[1886]   c2575     50
    x[1886]   c207      1
    x[1887]   c112_1    1
    x[1887]   c2608     1
    x[1887]   c208      -1
    x[1887]   c224      -1
    x[1887]   c1136     1
    x[1888]   c2576     50
    x[1888]   c208      1
    x[1889]   c353_1    1
    x[1889]   c2577     1
    x[1889]   c209      1
    x[1889]   c705      -1
    x[1889]   c721      -1
    x[1890]   c354_1    1
    x[1890]   c2578     1
    x[1890]   c210      1
    x[1890]   c706      -1
    x[1890]   c722      -1
    x[1891]   c355_1    1
    x[1891]   c2579     1
    x[1891]   c211      1
    x[1891]   c707      -1
    x[1891]   c723      -1
    x[1892]   c356_1    1
    x[1892]   c2580     1
    x[1892]   c212      1
    x[1892]   c708      -1
    x[1892]   c724      -1
    x[1893]   c357_1    1
    x[1893]   c2581     1
    x[1893]   c213      1
    x[1893]   c709      -1
    x[1893]   c725      -1
    x[1894]   c358_1    1
    x[1894]   c2582     1
    x[1894]   c214      1
    x[1894]   c710      -1
    x[1894]   c726      -1
    x[1895]   c359_1    1
    x[1895]   c2583     1
    x[1895]   c215      1
    x[1895]   c711      -1
    x[1895]   c727      -1
    x[1896]   c360_1    1
    x[1896]   c2584     1
    x[1896]   c216      1
    x[1896]   c712      -1
    x[1896]   c728      -1
    x[1897]   c361_1    1
    x[1897]   c2585     1
    x[1897]   c217      1
    x[1897]   c713      -1
    x[1897]   c729      -1
    x[1898]   c362_1    1
    x[1898]   c2586     1
    x[1898]   c218      1
    x[1898]   c714      -1
    x[1898]   c730      -1
    x[1899]   c363_1    1
    x[1899]   c2587     1
    x[1899]   c219      1
    x[1899]   c715      -1
    x[1899]   c731      -1
    x[1900]   c364_1    1
    x[1900]   c2588     1
    x[1900]   c220      1
    x[1900]   c716      -1
    x[1900]   c732      -1
    x[1901]   c365_1    1
    x[1901]   c2589     1
    x[1901]   c221      1
    x[1901]   c717      -1
    x[1901]   c733      -1
    x[1902]   c366_1    1
    x[1902]   c2590     1
    x[1902]   c222      1
    x[1902]   c718      -1
    x[1902]   c734      -1
    x[1903]   c367_1    1
    x[1903]   c2591     1
    x[1903]   c223      1
    x[1903]   c719      -1
    x[1903]   c735      -1
    x[1904]   c368_1    1
    x[1904]   c2592     1
    x[1904]   c224      1
    x[1904]   c720      -1
    x[1904]   c736      -1
    x[1905]   c113_1    1
    x[1905]   c2609     1
    x[1905]   c225      -1
    x[1905]   c241      -1
    x[1905]   c1137     1
    x[1906]   c2561     30
    x[1906]   c225      1
    x[1907]   c114_1    1
    x[1907]   c2610     1
    x[1907]   c226      -1
    x[1907]   c242      -1
    x[1907]   c1138     1
    x[1908]   c2562     30
    x[1908]   c226      1
    x[1909]   c115_1    1
    x[1909]   c2611     1
    x[1909]   c227      -1
    x[1909]   c243      -1
    x[1909]   c1139     1
    x[1910]   c2563     30
    x[1910]   c227      1
    x[1911]   c116_1    1
    x[1911]   c2612     1
    x[1911]   c228      -1
    x[1911]   c244      -1
    x[1911]   c1140     1
    x[1912]   c2564     30
    x[1912]   c228      1
    x[1913]   c117_1    1
    x[1913]   c2613     1
    x[1913]   c229      -1
    x[1913]   c245      -1
    x[1913]   c1141     1
    x[1914]   c2565     30
    x[1914]   c229      1
    x[1915]   c118_1    1
    x[1915]   c2614     1
    x[1915]   c230      -1
    x[1915]   c246      -1
    x[1915]   c1142     1
    x[1916]   c2566     30
    x[1916]   c230      1
    x[1917]   c119_1    1
    x[1917]   c2615     1
    x[1917]   c231      -1
    x[1917]   c247      -1
    x[1917]   c1143     1
    x[1918]   c2567     30
    x[1918]   c231      1
    x[1919]   c120_1    1
    x[1919]   c2616     1
    x[1919]   c232      -1
    x[1919]   c248      -1
    x[1919]   c1144     1
    x[1920]   c2568     30
    x[1920]   c232      1
    x[1921]   c121_1    1
    x[1921]   c2617     1
    x[1921]   c233      -1
    x[1921]   c249      -1
    x[1921]   c1145     1
    x[1922]   c2569     30
    x[1922]   c233      1
    x[1923]   c122_1    1
    x[1923]   c2618     1
    x[1923]   c234      -1
    x[1923]   c250      -1
    x[1923]   c1146     1
    x[1924]   c2570     30
    x[1924]   c234      1
    x[1925]   c123_1    1
    x[1925]   c2619     1
    x[1925]   c235      -1
    x[1925]   c251      -1
    x[1925]   c1147     1
    x[1926]   c2571     30
    x[1926]   c235      1
    x[1927]   c124_1    1
    x[1927]   c2620     1
    x[1927]   c236      -1
    x[1927]   c252      -1
    x[1927]   c1148     1
    x[1928]   c2572     30
    x[1928]   c236      1
    x[1929]   c125_1    1
    x[1929]   c2621     1
    x[1929]   c237      -1
    x[1929]   c253      -1
    x[1929]   c1149     1
    x[1930]   c2573     30
    x[1930]   c237      1
    x[1931]   c126_1    1
    x[1931]   c2622     1
    x[1931]   c238      -1
    x[1931]   c254      -1
    x[1931]   c1150     1
    x[1932]   c2574     30
    x[1932]   c238      1
    x[1933]   c127_1    1
    x[1933]   c2623     1
    x[1933]   c239      -1
    x[1933]   c255      -1
    x[1933]   c1151     1
    x[1934]   c2575     30
    x[1934]   c239      1
    x[1935]   c128_1    1
    x[1935]   c2624     1
    x[1935]   c240      -1
    x[1935]   c256      -1
    x[1935]   c1152     1
    x[1936]   c2576     30
    x[1936]   c240      1
    x[1937]   c369_1    1
    x[1937]   c2577     1
    x[1937]   c241      1
    x[1937]   c737      -1
    x[1937]   c753      -1
    x[1938]   c370_1    1
    x[1938]   c2578     1
    x[1938]   c242      1
    x[1938]   c738      -1
    x[1938]   c754      -1
    x[1939]   c371_1    1
    x[1939]   c2579     1
    x[1939]   c243      1
    x[1939]   c739      -1
    x[1939]   c755      -1
    x[1940]   c372_1    1
    x[1940]   c2580     1
    x[1940]   c244      1
    x[1940]   c740      -1
    x[1940]   c756      -1
    x[1941]   c373_1    1
    x[1941]   c2581     1
    x[1941]   c245      1
    x[1941]   c741      -1
    x[1941]   c757      -1
    x[1942]   c374_1    1
    x[1942]   c2582     1
    x[1942]   c246      1
    x[1942]   c742      -1
    x[1942]   c758      -1
    x[1943]   c375_1    1
    x[1943]   c2583     1
    x[1943]   c247      1
    x[1943]   c743      -1
    x[1943]   c759      -1
    x[1944]   c376_1    1
    x[1944]   c2584     1
    x[1944]   c248      1
    x[1944]   c744      -1
    x[1944]   c760      -1
    x[1945]   c377_1    1
    x[1945]   c2585     1
    x[1945]   c249      1
    x[1945]   c745      -1
    x[1945]   c761      -1
    x[1946]   c378_1    1
    x[1946]   c2586     1
    x[1946]   c250      1
    x[1946]   c746      -1
    x[1946]   c762      -1
    x[1947]   c379_1    1
    x[1947]   c2587     1
    x[1947]   c251      1
    x[1947]   c747      -1
    x[1947]   c763      -1
    x[1948]   c380_1    1
    x[1948]   c2588     1
    x[1948]   c252      1
    x[1948]   c748      -1
    x[1948]   c764      -1
    x[1949]   c381_1    1
    x[1949]   c2589     1
    x[1949]   c253      1
    x[1949]   c749      -1
    x[1949]   c765      -1
    x[1950]   c382_1    1
    x[1950]   c2590     1
    x[1950]   c254      1
    x[1950]   c750      -1
    x[1950]   c766      -1
    x[1951]   c383_1    1
    x[1951]   c2591     1
    x[1951]   c255      1
    x[1951]   c751      -1
    x[1951]   c767      -1
    x[1952]   c384_1    1
    x[1952]   c2592     1
    x[1952]   c256      1
    x[1952]   c752      -1
    x[1952]   c768      -1
    x[1953]   c129_1    1
    x[1953]   c2593     1
    x[1953]   c257      -1
    x[1953]   c273      -1
    x[1953]   c1153     1
    x[1954]   c2561     50
    x[1954]   c257      1
    x[1955]   c130_1    1
    x[1955]   c2594     1
    x[1955]   c258      -1
    x[1955]   c274      -1
    x[1955]   c1154     1
    x[1956]   c2562     50
    x[1956]   c258      1
    x[1957]   c131_1    1
    x[1957]   c2595     1
    x[1957]   c259      -1
    x[1957]   c275      -1
    x[1957]   c1155     1
    x[1958]   c2563     50
    x[1958]   c259      1
    x[1959]   c132_1    1
    x[1959]   c2596     1
    x[1959]   c260      -1
    x[1959]   c276      -1
    x[1959]   c1156     1
    x[1960]   c2564     50
    x[1960]   c260      1
    x[1961]   c133_1    1
    x[1961]   c2597     1
    x[1961]   c261      -1
    x[1961]   c277      -1
    x[1961]   c1157     1
    x[1962]   c2565     50
    x[1962]   c261      1
    x[1963]   c134_1    1
    x[1963]   c2598     1
    x[1963]   c262      -1
    x[1963]   c278      -1
    x[1963]   c1158     1
    x[1964]   c2566     50
    x[1964]   c262      1
    x[1965]   c135_1    1
    x[1965]   c2599     1
    x[1965]   c263      -1
    x[1965]   c279      -1
    x[1965]   c1159     1
    x[1966]   c2567     50
    x[1966]   c263      1
    x[1967]   c136_1    1
    x[1967]   c2600     1
    x[1967]   c264      -1
    x[1967]   c280      -1
    x[1967]   c1160     1
    x[1968]   c2568     50
    x[1968]   c264      1
    x[1969]   c137_1    1
    x[1969]   c2601     1
    x[1969]   c265      -1
    x[1969]   c281      -1
    x[1969]   c1161     1
    x[1970]   c2569     50
    x[1970]   c265      1
    x[1971]   c138_1    1
    x[1971]   c2602     1
    x[1971]   c266      -1
    x[1971]   c282      -1
    x[1971]   c1162     1
    x[1972]   c2570     50
    x[1972]   c266      1
    x[1973]   c139_1    1
    x[1973]   c2603     1
    x[1973]   c267      -1
    x[1973]   c283      -1
    x[1973]   c1163     1
    x[1974]   c2571     50
    x[1974]   c267      1
    x[1975]   c140_1    1
    x[1975]   c2604     1
    x[1975]   c268      -1
    x[1975]   c284      -1
    x[1975]   c1164     1
    x[1976]   c2572     50
    x[1976]   c268      1
    x[1977]   c141_1    1
    x[1977]   c2605     1
    x[1977]   c269      -1
    x[1977]   c285      -1
    x[1977]   c1165     1
    x[1978]   c2573     50
    x[1978]   c269      1
    x[1979]   c142_1    1
    x[1979]   c2606     1
    x[1979]   c270      -1
    x[1979]   c286      -1
    x[1979]   c1166     1
    x[1980]   c2574     50
    x[1980]   c270      1
    x[1981]   c143_1    1
    x[1981]   c2607     1
    x[1981]   c271      -1
    x[1981]   c287      -1
    x[1981]   c1167     1
    x[1982]   c2575     50
    x[1982]   c271      1
    x[1983]   c144_1    1
    x[1983]   c2608     1
    x[1983]   c272      -1
    x[1983]   c288      -1
    x[1983]   c1168     1
    x[1984]   c2576     50
    x[1984]   c272      1
    x[1985]   c385_1    1
    x[1985]   c2577     1
    x[1985]   c273      1
    x[1985]   c769      -1
    x[1985]   c785      -1
    x[1986]   c386_1    1
    x[1986]   c2578     1
    x[1986]   c274      1
    x[1986]   c770      -1
    x[1986]   c786      -1
    x[1987]   c387_1    1
    x[1987]   c2579     1
    x[1987]   c275      1
    x[1987]   c771      -1
    x[1987]   c787      -1
    x[1988]   c388_1    1
    x[1988]   c2580     1
    x[1988]   c276      1
    x[1988]   c772      -1
    x[1988]   c788      -1
    x[1989]   c389_1    1
    x[1989]   c2581     1
    x[1989]   c277      1
    x[1989]   c773      -1
    x[1989]   c789      -1
    x[1990]   c390_1    1
    x[1990]   c2582     1
    x[1990]   c278      1
    x[1990]   c774      -1
    x[1990]   c790      -1
    x[1991]   c391_1    1
    x[1991]   c2583     1
    x[1991]   c279      1
    x[1991]   c775      -1
    x[1991]   c791      -1
    x[1992]   c392_1    1
    x[1992]   c2584     1
    x[1992]   c280      1
    x[1992]   c776      -1
    x[1992]   c792      -1
    x[1993]   c393_1    1
    x[1993]   c2585     1
    x[1993]   c281      1
    x[1993]   c777      -1
    x[1993]   c793      -1
    x[1994]   c394_1    1
    x[1994]   c2586     1
    x[1994]   c282      1
    x[1994]   c778      -1
    x[1994]   c794      -1
    x[1995]   c395_1    1
    x[1995]   c2587     1
    x[1995]   c283      1
    x[1995]   c779      -1
    x[1995]   c795      -1
    x[1996]   c396_1    1
    x[1996]   c2588     1
    x[1996]   c284      1
    x[1996]   c780      -1
    x[1996]   c796      -1
    x[1997]   c397_1    1
    x[1997]   c2589     1
    x[1997]   c285      1
    x[1997]   c781      -1
    x[1997]   c797      -1
    x[1998]   c398_1    1
    x[1998]   c2590     1
    x[1998]   c286      1
    x[1998]   c782      -1
    x[1998]   c798      -1
    x[1999]   c399_1    1
    x[1999]   c2591     1
    x[1999]   c287      1
    x[1999]   c783      -1
    x[1999]   c799      -1
    x[2000]   c400_1    1
    x[2000]   c2592     1
    x[2000]   c288      1
    x[2000]   c784      -1
    x[2000]   c800      -1
    x[2001]   c145_1    1
    x[2001]   c2609     1
    x[2001]   c289      -1
    x[2001]   c305      -1
    x[2001]   c1169     1
    x[2002]   c2561     10
    x[2002]   c289      1
    x[2003]   c146_1    1
    x[2003]   c2610     1
    x[2003]   c290      -1
    x[2003]   c306      -1
    x[2003]   c1170     1
    x[2004]   c2562     10
    x[2004]   c290      1
    x[2005]   c147_1    1
    x[2005]   c2611     1
    x[2005]   c291      -1
    x[2005]   c307      -1
    x[2005]   c1171     1
    x[2006]   c2563     10
    x[2006]   c291      1
    x[2007]   c148_1    1
    x[2007]   c2612     1
    x[2007]   c292      -1
    x[2007]   c308      -1
    x[2007]   c1172     1
    x[2008]   c2564     10
    x[2008]   c292      1
    x[2009]   c149_1    1
    x[2009]   c2613     1
    x[2009]   c293      -1
    x[2009]   c309      -1
    x[2009]   c1173     1
    x[2010]   c2565     10
    x[2010]   c293      1
    x[2011]   c150_1    1
    x[2011]   c2614     1
    x[2011]   c294      -1
    x[2011]   c310      -1
    x[2011]   c1174     1
    x[2012]   c2566     10
    x[2012]   c294      1
    x[2013]   c151_1    1
    x[2013]   c2615     1
    x[2013]   c295      -1
    x[2013]   c311      -1
    x[2013]   c1175     1
    x[2014]   c2567     10
    x[2014]   c295      1
    x[2015]   c152_1    1
    x[2015]   c2616     1
    x[2015]   c296      -1
    x[2015]   c312      -1
    x[2015]   c1176     1
    x[2016]   c2568     10
    x[2016]   c296      1
    x[2017]   c153_1    1
    x[2017]   c2617     1
    x[2017]   c297      -1
    x[2017]   c313      -1
    x[2017]   c1177     1
    x[2018]   c2569     10
    x[2018]   c297      1
    x[2019]   c154_1    1
    x[2019]   c2618     1
    x[2019]   c298      -1
    x[2019]   c314      -1
    x[2019]   c1178     1
    x[2020]   c2570     10
    x[2020]   c298      1
    x[2021]   c155_1    1
    x[2021]   c2619     1
    x[2021]   c299      -1
    x[2021]   c315      -1
    x[2021]   c1179     1
    x[2022]   c2571     10
    x[2022]   c299      1
    x[2023]   c156_1    1
    x[2023]   c2620     1
    x[2023]   c300      -1
    x[2023]   c316      -1
    x[2023]   c1180     1
    x[2024]   c2572     10
    x[2024]   c300      1
    x[2025]   c157_1    1
    x[2025]   c2621     1
    x[2025]   c301      -1
    x[2025]   c317      -1
    x[2025]   c1181     1
    x[2026]   c2573     10
    x[2026]   c301      1
    x[2027]   c158_1    1
    x[2027]   c2622     1
    x[2027]   c302      -1
    x[2027]   c318      -1
    x[2027]   c1182     1
    x[2028]   c2574     10
    x[2028]   c302      1
    x[2029]   c159_1    1
    x[2029]   c2623     1
    x[2029]   c303      -1
    x[2029]   c319      -1
    x[2029]   c1183     1
    x[2030]   c2575     10
    x[2030]   c303      1
    x[2031]   c160_1    1
    x[2031]   c2624     1
    x[2031]   c304      -1
    x[2031]   c320      -1
    x[2031]   c1184     1
    x[2032]   c2576     10
    x[2032]   c304      1
    x[2033]   c401_1    1
    x[2033]   c2577     1
    x[2033]   c305      1
    x[2033]   c801      -1
    x[2033]   c817      -1
    x[2034]   c402_1    1
    x[2034]   c2578     1
    x[2034]   c306      1
    x[2034]   c802      -1
    x[2034]   c818      -1
    x[2035]   c403_1    1
    x[2035]   c2579     1
    x[2035]   c307      1
    x[2035]   c803      -1
    x[2035]   c819      -1
    x[2036]   c404_1    1
    x[2036]   c2580     1
    x[2036]   c308      1
    x[2036]   c804      -1
    x[2036]   c820      -1
    x[2037]   c405_1    1
    x[2037]   c2581     1
    x[2037]   c309      1
    x[2037]   c805      -1
    x[2037]   c821      -1
    x[2038]   c406_1    1
    x[2038]   c2582     1
    x[2038]   c310      1
    x[2038]   c806      -1
    x[2038]   c822      -1
    x[2039]   c407_1    1
    x[2039]   c2583     1
    x[2039]   c311      1
    x[2039]   c807      -1
    x[2039]   c823      -1
    x[2040]   c408_1    1
    x[2040]   c2584     1
    x[2040]   c312      1
    x[2040]   c808      -1
    x[2040]   c824      -1
    x[2041]   c409_1    1
    x[2041]   c2585     1
    x[2041]   c313      1
    x[2041]   c809      -1
    x[2041]   c825      -1
    x[2042]   c410_1    1
    x[2042]   c2586     1
    x[2042]   c314      1
    x[2042]   c810      -1
    x[2042]   c826      -1
    x[2043]   c411_1    1
    x[2043]   c2587     1
    x[2043]   c315      1
    x[2043]   c811      -1
    x[2043]   c827      -1
    x[2044]   c412_1    1
    x[2044]   c2588     1
    x[2044]   c316      1
    x[2044]   c812      -1
    x[2044]   c828      -1
    x[2045]   c413_1    1
    x[2045]   c2589     1
    x[2045]   c317      1
    x[2045]   c813      -1
    x[2045]   c829      -1
    x[2046]   c414_1    1
    x[2046]   c2590     1
    x[2046]   c318      1
    x[2046]   c814      -1
    x[2046]   c830      -1
    x[2047]   c415_1    1
    x[2047]   c2591     1
    x[2047]   c319      1
    x[2047]   c815      -1
    x[2047]   c831      -1
    x[2048]   c416_1    1
    x[2048]   c2592     1
    x[2048]   c320      1
    x[2048]   c816      -1
    x[2048]   c832      -1
    x[2049]   c161_1    1
    x[2049]   c2593     1
    x[2049]   c321      -1
    x[2049]   c337      -1
    x[2049]   c1185     1
    x[2050]   c2561     50
    x[2050]   c321      1
    x[2051]   c162_1    1
    x[2051]   c2594     1
    x[2051]   c322      -1
    x[2051]   c338      -1
    x[2051]   c1186     1
    x[2052]   c2562     50
    x[2052]   c322      1
    x[2053]   c163_1    1
    x[2053]   c2595     1
    x[2053]   c323      -1
    x[2053]   c339      -1
    x[2053]   c1187     1
    x[2054]   c2563     50
    x[2054]   c323      1
    x[2055]   c164_1    1
    x[2055]   c2596     1
    x[2055]   c324      -1
    x[2055]   c340      -1
    x[2055]   c1188     1
    x[2056]   c2564     50
    x[2056]   c324      1
    x[2057]   c165_1    1
    x[2057]   c2597     1
    x[2057]   c325      -1
    x[2057]   c341      -1
    x[2057]   c1189     1
    x[2058]   c2565     50
    x[2058]   c325      1
    x[2059]   c166_1    1
    x[2059]   c2598     1
    x[2059]   c326      -1
    x[2059]   c342      -1
    x[2059]   c1190     1
    x[2060]   c2566     50
    x[2060]   c326      1
    x[2061]   c167_1    1
    x[2061]   c2599     1
    x[2061]   c327      -1
    x[2061]   c343      -1
    x[2061]   c1191     1
    x[2062]   c2567     50
    x[2062]   c327      1
    x[2063]   c168_1    1
    x[2063]   c2600     1
    x[2063]   c328      -1
    x[2063]   c344      -1
    x[2063]   c1192     1
    x[2064]   c2568     50
    x[2064]   c328      1
    x[2065]   c169_1    1
    x[2065]   c2601     1
    x[2065]   c329      -1
    x[2065]   c345      -1
    x[2065]   c1193     1
    x[2066]   c2569     50
    x[2066]   c329      1
    x[2067]   c170_1    1
    x[2067]   c2602     1
    x[2067]   c330      -1
    x[2067]   c346      -1
    x[2067]   c1194     1
    x[2068]   c2570     50
    x[2068]   c330      1
    x[2069]   c171_1    1
    x[2069]   c2603     1
    x[2069]   c331      -1
    x[2069]   c347      -1
    x[2069]   c1195     1
    x[2070]   c2571     50
    x[2070]   c331      1
    x[2071]   c172_1    1
    x[2071]   c2604     1
    x[2071]   c332      -1
    x[2071]   c348      -1
    x[2071]   c1196     1
    x[2072]   c2572     50
    x[2072]   c332      1
    x[2073]   c173_1    1
    x[2073]   c2605     1
    x[2073]   c333      -1
    x[2073]   c349      -1
    x[2073]   c1197     1
    x[2074]   c2573     50
    x[2074]   c333      1
    x[2075]   c174_1    1
    x[2075]   c2606     1
    x[2075]   c334      -1
    x[2075]   c350      -1
    x[2075]   c1198     1
    x[2076]   c2574     50
    x[2076]   c334      1
    x[2077]   c175_1    1
    x[2077]   c2607     1
    x[2077]   c335      -1
    x[2077]   c351      -1
    x[2077]   c1199     1
    x[2078]   c2575     50
    x[2078]   c335      1
    x[2079]   c176_1    1
    x[2079]   c2608     1
    x[2079]   c336      -1
    x[2079]   c352      -1
    x[2079]   c1200     1
    x[2080]   c2576     50
    x[2080]   c336      1
    x[2081]   c417_1    1
    x[2081]   c2577     1
    x[2081]   c337      1
    x[2081]   c833      -1
    x[2081]   c849      -1
    x[2082]   c418_1    1
    x[2082]   c2578     1
    x[2082]   c338      1
    x[2082]   c834      -1
    x[2082]   c850      -1
    x[2083]   c419_1    1
    x[2083]   c2579     1
    x[2083]   c339      1
    x[2083]   c835      -1
    x[2083]   c851      -1
    x[2084]   c420_1    1
    x[2084]   c2580     1
    x[2084]   c340      1
    x[2084]   c836      -1
    x[2084]   c852      -1
    x[2085]   c421_1    1
    x[2085]   c2581     1
    x[2085]   c341      1
    x[2085]   c837      -1
    x[2085]   c853      -1
    x[2086]   c422_1    1
    x[2086]   c2582     1
    x[2086]   c342      1
    x[2086]   c838      -1
    x[2086]   c854      -1
    x[2087]   c423_1    1
    x[2087]   c2583     1
    x[2087]   c343      1
    x[2087]   c839      -1
    x[2087]   c855      -1
    x[2088]   c424_1    1
    x[2088]   c2584     1
    x[2088]   c344      1
    x[2088]   c840      -1
    x[2088]   c856      -1
    x[2089]   c425_1    1
    x[2089]   c2585     1
    x[2089]   c345      1
    x[2089]   c841      -1
    x[2089]   c857      -1
    x[2090]   c426_1    1
    x[2090]   c2586     1
    x[2090]   c346      1
    x[2090]   c842      -1
    x[2090]   c858      -1
    x[2091]   c427_1    1
    x[2091]   c2587     1
    x[2091]   c347      1
    x[2091]   c843      -1
    x[2091]   c859      -1
    x[2092]   c428_1    1
    x[2092]   c2588     1
    x[2092]   c348      1
    x[2092]   c844      -1
    x[2092]   c860      -1
    x[2093]   c429_1    1
    x[2093]   c2589     1
    x[2093]   c349      1
    x[2093]   c845      -1
    x[2093]   c861      -1
    x[2094]   c430_1    1
    x[2094]   c2590     1
    x[2094]   c350      1
    x[2094]   c846      -1
    x[2094]   c862      -1
    x[2095]   c431_1    1
    x[2095]   c2591     1
    x[2095]   c351      1
    x[2095]   c847      -1
    x[2095]   c863      -1
    x[2096]   c432_1    1
    x[2096]   c2592     1
    x[2096]   c352      1
    x[2096]   c848      -1
    x[2096]   c864      -1
    x[2097]   c177_1    1
    x[2097]   c2609     1
    x[2097]   c353      -1
    x[2097]   c369      -1
    x[2097]   c1201     1
    x[2098]   c2561     30
    x[2098]   c353      1
    x[2099]   c178_1    1
    x[2099]   c2610     1
    x[2099]   c354      -1
    x[2099]   c370      -1
    x[2099]   c1202     1
    x[2100]   c2562     30
    x[2100]   c354      1
    x[2101]   c179_1    1
    x[2101]   c2611     1
    x[2101]   c355      -1
    x[2101]   c371      -1
    x[2101]   c1203     1
    x[2102]   c2563     30
    x[2102]   c355      1
    x[2103]   c180_1    1
    x[2103]   c2612     1
    x[2103]   c356      -1
    x[2103]   c372      -1
    x[2103]   c1204     1
    x[2104]   c2564     30
    x[2104]   c356      1
    x[2105]   c181_1    1
    x[2105]   c2613     1
    x[2105]   c357      -1
    x[2105]   c373      -1
    x[2105]   c1205     1
    x[2106]   c2565     30
    x[2106]   c357      1
    x[2107]   c182_1    1
    x[2107]   c2614     1
    x[2107]   c358      -1
    x[2107]   c374      -1
    x[2107]   c1206     1
    x[2108]   c2566     30
    x[2108]   c358      1
    x[2109]   c183_1    1
    x[2109]   c2615     1
    x[2109]   c359      -1
    x[2109]   c375      -1
    x[2109]   c1207     1
    x[2110]   c2567     30
    x[2110]   c359      1
    x[2111]   c184_1    1
    x[2111]   c2616     1
    x[2111]   c360      -1
    x[2111]   c376      -1
    x[2111]   c1208     1
    x[2112]   c2568     30
    x[2112]   c360      1
    x[2113]   c185_1    1
    x[2113]   c2617     1
    x[2113]   c361      -1
    x[2113]   c377      -1
    x[2113]   c1209     1
    x[2114]   c2569     30
    x[2114]   c361      1
    x[2115]   c186_1    1
    x[2115]   c2618     1
    x[2115]   c362      -1
    x[2115]   c378      -1
    x[2115]   c1210     1
    x[2116]   c2570     30
    x[2116]   c362      1
    x[2117]   c187_1    1
    x[2117]   c2619     1
    x[2117]   c363      -1
    x[2117]   c379      -1
    x[2117]   c1211     1
    x[2118]   c2571     30
    x[2118]   c363      1
    x[2119]   c188_1    1
    x[2119]   c2620     1
    x[2119]   c364      -1
    x[2119]   c380      -1
    x[2119]   c1212     1
    x[2120]   c2572     30
    x[2120]   c364      1
    x[2121]   c189_1    1
    x[2121]   c2621     1
    x[2121]   c365      -1
    x[2121]   c381      -1
    x[2121]   c1213     1
    x[2122]   c2573     30
    x[2122]   c365      1
    x[2123]   c190_1    1
    x[2123]   c2622     1
    x[2123]   c366      -1
    x[2123]   c382      -1
    x[2123]   c1214     1
    x[2124]   c2574     30
    x[2124]   c366      1
    x[2125]   c191_1    1
    x[2125]   c2623     1
    x[2125]   c367      -1
    x[2125]   c383      -1
    x[2125]   c1215     1
    x[2126]   c2575     30
    x[2126]   c367      1
    x[2127]   c192_1    1
    x[2127]   c2624     1
    x[2127]   c368      -1
    x[2127]   c384      -1
    x[2127]   c1216     1
    x[2128]   c2576     30
    x[2128]   c368      1
    x[2129]   c433_1    1
    x[2129]   c2577     1
    x[2129]   c369      1
    x[2129]   c865      -1
    x[2129]   c881      -1
    x[2130]   c434_1    1
    x[2130]   c2578     1
    x[2130]   c370      1
    x[2130]   c866      -1
    x[2130]   c882      -1
    x[2131]   c435_1    1
    x[2131]   c2579     1
    x[2131]   c371      1
    x[2131]   c867      -1
    x[2131]   c883      -1
    x[2132]   c436_1    1
    x[2132]   c2580     1
    x[2132]   c372      1
    x[2132]   c868      -1
    x[2132]   c884      -1
    x[2133]   c437_1    1
    x[2133]   c2581     1
    x[2133]   c373      1
    x[2133]   c869      -1
    x[2133]   c885      -1
    x[2134]   c438_1    1
    x[2134]   c2582     1
    x[2134]   c374      1
    x[2134]   c870      -1
    x[2134]   c886      -1
    x[2135]   c439_1    1
    x[2135]   c2583     1
    x[2135]   c375      1
    x[2135]   c871      -1
    x[2135]   c887      -1
    x[2136]   c440_1    1
    x[2136]   c2584     1
    x[2136]   c376      1
    x[2136]   c872      -1
    x[2136]   c888      -1
    x[2137]   c441_1    1
    x[2137]   c2585     1
    x[2137]   c377      1
    x[2137]   c873      -1
    x[2137]   c889      -1
    x[2138]   c442_1    1
    x[2138]   c2586     1
    x[2138]   c378      1
    x[2138]   c874      -1
    x[2138]   c890      -1
    x[2139]   c443_1    1
    x[2139]   c2587     1
    x[2139]   c379      1
    x[2139]   c875      -1
    x[2139]   c891      -1
    x[2140]   c444_1    1
    x[2140]   c2588     1
    x[2140]   c380      1
    x[2140]   c876      -1
    x[2140]   c892      -1
    x[2141]   c445_1    1
    x[2141]   c2589     1
    x[2141]   c381      1
    x[2141]   c877      -1
    x[2141]   c893      -1
    x[2142]   c446_1    1
    x[2142]   c2590     1
    x[2142]   c382      1
    x[2142]   c878      -1
    x[2142]   c894      -1
    x[2143]   c447_1    1
    x[2143]   c2591     1
    x[2143]   c383      1
    x[2143]   c879      -1
    x[2143]   c895      -1
    x[2144]   c448_1    1
    x[2144]   c2592     1
    x[2144]   c384      1
    x[2144]   c880      -1
    x[2144]   c896      -1
    x[2145]   c193_1    1
    x[2145]   c2593     1
    x[2145]   c385      -1
    x[2145]   c401      -1
    x[2145]   c1217     1
    x[2146]   c2561     50
    x[2146]   c385      1
    x[2147]   c194_1    1
    x[2147]   c2594     1
    x[2147]   c386      -1
    x[2147]   c402      -1
    x[2147]   c1218     1
    x[2148]   c2562     50
    x[2148]   c386      1
    x[2149]   c195_1    1
    x[2149]   c2595     1
    x[2149]   c387      -1
    x[2149]   c403      -1
    x[2149]   c1219     1
    x[2150]   c2563     50
    x[2150]   c387      1
    x[2151]   c196_1    1
    x[2151]   c2596     1
    x[2151]   c388      -1
    x[2151]   c404      -1
    x[2151]   c1220     1
    x[2152]   c2564     50
    x[2152]   c388      1
    x[2153]   c197_1    1
    x[2153]   c2597     1
    x[2153]   c389      -1
    x[2153]   c405      -1
    x[2153]   c1221     1
    x[2154]   c2565     50
    x[2154]   c389      1
    x[2155]   c198_1    1
    x[2155]   c2598     1
    x[2155]   c390      -1
    x[2155]   c406      -1
    x[2155]   c1222     1
    x[2156]   c2566     50
    x[2156]   c390      1
    x[2157]   c199_1    1
    x[2157]   c2599     1
    x[2157]   c391      -1
    x[2157]   c407      -1
    x[2157]   c1223     1
    x[2158]   c2567     50
    x[2158]   c391      1
    x[2159]   c200_1    1
    x[2159]   c2600     1
    x[2159]   c392      -1
    x[2159]   c408      -1
    x[2159]   c1224     1
    x[2160]   c2568     50
    x[2160]   c392      1
    x[2161]   c201_1    1
    x[2161]   c2601     1
    x[2161]   c393      -1
    x[2161]   c409      -1
    x[2161]   c1225     1
    x[2162]   c2569     50
    x[2162]   c393      1
    x[2163]   c202_1    1
    x[2163]   c2602     1
    x[2163]   c394      -1
    x[2163]   c410      -1
    x[2163]   c1226     1
    x[2164]   c2570     50
    x[2164]   c394      1
    x[2165]   c203_1    1
    x[2165]   c2603     1
    x[2165]   c395      -1
    x[2165]   c411      -1
    x[2165]   c1227     1
    x[2166]   c2571     50
    x[2166]   c395      1
    x[2167]   c204_1    1
    x[2167]   c2604     1
    x[2167]   c396      -1
    x[2167]   c412      -1
    x[2167]   c1228     1
    x[2168]   c2572     50
    x[2168]   c396      1
    x[2169]   c205_1    1
    x[2169]   c2605     1
    x[2169]   c397      -1
    x[2169]   c413      -1
    x[2169]   c1229     1
    x[2170]   c2573     50
    x[2170]   c397      1
    x[2171]   c206_1    1
    x[2171]   c2606     1
    x[2171]   c398      -1
    x[2171]   c414      -1
    x[2171]   c1230     1
    x[2172]   c2574     50
    x[2172]   c398      1
    x[2173]   c207_1    1
    x[2173]   c2607     1
    x[2173]   c399      -1
    x[2173]   c415      -1
    x[2173]   c1231     1
    x[2174]   c2575     50
    x[2174]   c399      1
    x[2175]   c208_1    1
    x[2175]   c2608     1
    x[2175]   c400      -1
    x[2175]   c416      -1
    x[2175]   c1232     1
    x[2176]   c2576     50
    x[2176]   c400      1
    x[2177]   c449_1    1
    x[2177]   c2577     1
    x[2177]   c401      1
    x[2177]   c897      -1
    x[2177]   c913      -1
    x[2178]   c450_1    1
    x[2178]   c2578     1
    x[2178]   c402      1
    x[2178]   c898      -1
    x[2178]   c914      -1
    x[2179]   c451_1    1
    x[2179]   c2579     1
    x[2179]   c403      1
    x[2179]   c899      -1
    x[2179]   c915      -1
    x[2180]   c452_1    1
    x[2180]   c2580     1
    x[2180]   c404      1
    x[2180]   c900      -1
    x[2180]   c916      -1
    x[2181]   c453_1    1
    x[2181]   c2581     1
    x[2181]   c405      1
    x[2181]   c901      -1
    x[2181]   c917      -1
    x[2182]   c454_1    1
    x[2182]   c2582     1
    x[2182]   c406      1
    x[2182]   c902      -1
    x[2182]   c918      -1
    x[2183]   c455_1    1
    x[2183]   c2583     1
    x[2183]   c407      1
    x[2183]   c903      -1
    x[2183]   c919      -1
    x[2184]   c456_1    1
    x[2184]   c2584     1
    x[2184]   c408      1
    x[2184]   c904      -1
    x[2184]   c920      -1
    x[2185]   c457_1    1
    x[2185]   c2585     1
    x[2185]   c409      1
    x[2185]   c905      -1
    x[2185]   c921      -1
    x[2186]   c458_1    1
    x[2186]   c2586     1
    x[2186]   c410      1
    x[2186]   c906      -1
    x[2186]   c922      -1
    x[2187]   c459_1    1
    x[2187]   c2587     1
    x[2187]   c411      1
    x[2187]   c907      -1
    x[2187]   c923      -1
    x[2188]   c460_1    1
    x[2188]   c2588     1
    x[2188]   c412      1
    x[2188]   c908      -1
    x[2188]   c924      -1
    x[2189]   c461_1    1
    x[2189]   c2589     1
    x[2189]   c413      1
    x[2189]   c909      -1
    x[2189]   c925      -1
    x[2190]   c462_1    1
    x[2190]   c2590     1
    x[2190]   c414      1
    x[2190]   c910      -1
    x[2190]   c926      -1
    x[2191]   c463_1    1
    x[2191]   c2591     1
    x[2191]   c415      1
    x[2191]   c911      -1
    x[2191]   c927      -1
    x[2192]   c464_1    1
    x[2192]   c2592     1
    x[2192]   c416      1
    x[2192]   c912      -1
    x[2192]   c928      -1
    x[2193]   c209_1    1
    x[2193]   c2609     1
    x[2193]   c417      -1
    x[2193]   c433      -1
    x[2193]   c1233     1
    x[2194]   c2561     10
    x[2194]   c417      1
    x[2195]   c210_1    1
    x[2195]   c2610     1
    x[2195]   c418      -1
    x[2195]   c434      -1
    x[2195]   c1234     1
    x[2196]   c2562     10
    x[2196]   c418      1
    x[2197]   c211_1    1
    x[2197]   c2611     1
    x[2197]   c419      -1
    x[2197]   c435      -1
    x[2197]   c1235     1
    x[2198]   c2563     10
    x[2198]   c419      1
    x[2199]   c212_1    1
    x[2199]   c2612     1
    x[2199]   c420      -1
    x[2199]   c436      -1
    x[2199]   c1236     1
    x[2200]   c2564     10
    x[2200]   c420      1
    x[2201]   c213_1    1
    x[2201]   c2613     1
    x[2201]   c421      -1
    x[2201]   c437      -1
    x[2201]   c1237     1
    x[2202]   c2565     10
    x[2202]   c421      1
    x[2203]   c214_1    1
    x[2203]   c2614     1
    x[2203]   c422      -1
    x[2203]   c438      -1
    x[2203]   c1238     1
    x[2204]   c2566     10
    x[2204]   c422      1
    x[2205]   c215_1    1
    x[2205]   c2615     1
    x[2205]   c423      -1
    x[2205]   c439      -1
    x[2205]   c1239     1
    x[2206]   c2567     10
    x[2206]   c423      1
    x[2207]   c216_1    1
    x[2207]   c2616     1
    x[2207]   c424      -1
    x[2207]   c440      -1
    x[2207]   c1240     1
    x[2208]   c2568     10
    x[2208]   c424      1
    x[2209]   c217_1    1
    x[2209]   c2617     1
    x[2209]   c425      -1
    x[2209]   c441      -1
    x[2209]   c1241     1
    x[2210]   c2569     10
    x[2210]   c425      1
    x[2211]   c218_1    1
    x[2211]   c2618     1
    x[2211]   c426      -1
    x[2211]   c442      -1
    x[2211]   c1242     1
    x[2212]   c2570     10
    x[2212]   c426      1
    x[2213]   c219_1    1
    x[2213]   c2619     1
    x[2213]   c427      -1
    x[2213]   c443      -1
    x[2213]   c1243     1
    x[2214]   c2571     10
    x[2214]   c427      1
    x[2215]   c220_1    1
    x[2215]   c2620     1
    x[2215]   c428      -1
    x[2215]   c444      -1
    x[2215]   c1244     1
    x[2216]   c2572     10
    x[2216]   c428      1
    x[2217]   c221_1    1
    x[2217]   c2621     1
    x[2217]   c429      -1
    x[2217]   c445      -1
    x[2217]   c1245     1
    x[2218]   c2573     10
    x[2218]   c429      1
    x[2219]   c222_1    1
    x[2219]   c2622     1
    x[2219]   c430      -1
    x[2219]   c446      -1
    x[2219]   c1246     1
    x[2220]   c2574     10
    x[2220]   c430      1
    x[2221]   c223_1    1
    x[2221]   c2623     1
    x[2221]   c431      -1
    x[2221]   c447      -1
    x[2221]   c1247     1
    x[2222]   c2575     10
    x[2222]   c431      1
    x[2223]   c224_1    1
    x[2223]   c2624     1
    x[2223]   c432      -1
    x[2223]   c448      -1
    x[2223]   c1248     1
    x[2224]   c2576     10
    x[2224]   c432      1
    x[2225]   c465_1    1
    x[2225]   c2577     1
    x[2225]   c433      1
    x[2225]   c929      -1
    x[2225]   c945      -1
    x[2226]   c466_1    1
    x[2226]   c2578     1
    x[2226]   c434      1
    x[2226]   c930      -1
    x[2226]   c946      -1
    x[2227]   c467_1    1
    x[2227]   c2579     1
    x[2227]   c435      1
    x[2227]   c931      -1
    x[2227]   c947      -1
    x[2228]   c468_1    1
    x[2228]   c2580     1
    x[2228]   c436      1
    x[2228]   c932      -1
    x[2228]   c948      -1
    x[2229]   c469_1    1
    x[2229]   c2581     1
    x[2229]   c437      1
    x[2229]   c933      -1
    x[2229]   c949      -1
    x[2230]   c470_1    1
    x[2230]   c2582     1
    x[2230]   c438      1
    x[2230]   c934      -1
    x[2230]   c950      -1
    x[2231]   c471_1    1
    x[2231]   c2583     1
    x[2231]   c439      1
    x[2231]   c935      -1
    x[2231]   c951      -1
    x[2232]   c472_1    1
    x[2232]   c2584     1
    x[2232]   c440      1
    x[2232]   c936      -1
    x[2232]   c952      -1
    x[2233]   c473_1    1
    x[2233]   c2585     1
    x[2233]   c441      1
    x[2233]   c937      -1
    x[2233]   c953      -1
    x[2234]   c474_1    1
    x[2234]   c2586     1
    x[2234]   c442      1
    x[2234]   c938      -1
    x[2234]   c954      -1
    x[2235]   c475_1    1
    x[2235]   c2587     1
    x[2235]   c443      1
    x[2235]   c939      -1
    x[2235]   c955      -1
    x[2236]   c476_1    1
    x[2236]   c2588     1
    x[2236]   c444      1
    x[2236]   c940      -1
    x[2236]   c956      -1
    x[2237]   c477_1    1
    x[2237]   c2589     1
    x[2237]   c445      1
    x[2237]   c941      -1
    x[2237]   c957      -1
    x[2238]   c478_1    1
    x[2238]   c2590     1
    x[2238]   c446      1
    x[2238]   c942      -1
    x[2238]   c958      -1
    x[2239]   c479_1    1
    x[2239]   c2591     1
    x[2239]   c447      1
    x[2239]   c943      -1
    x[2239]   c959      -1
    x[2240]   c480_1    1
    x[2240]   c2592     1
    x[2240]   c448      1
    x[2240]   c944      -1
    x[2240]   c960      -1
    x[2241]   c225_1    1
    x[2241]   c2593     1
    x[2241]   c449      -1
    x[2241]   c465      -1
    x[2241]   c1249     1
    x[2242]   c2561     50
    x[2242]   c449      1
    x[2243]   c226_1    1
    x[2243]   c2594     1
    x[2243]   c450      -1
    x[2243]   c466      -1
    x[2243]   c1250     1
    x[2244]   c2562     50
    x[2244]   c450      1
    x[2245]   c227_1    1
    x[2245]   c2595     1
    x[2245]   c451      -1
    x[2245]   c467      -1
    x[2245]   c1251     1
    x[2246]   c2563     50
    x[2246]   c451      1
    x[2247]   c228_1    1
    x[2247]   c2596     1
    x[2247]   c452      -1
    x[2247]   c468      -1
    x[2247]   c1252     1
    x[2248]   c2564     50
    x[2248]   c452      1
    x[2249]   c229_1    1
    x[2249]   c2597     1
    x[2249]   c453      -1
    x[2249]   c469      -1
    x[2249]   c1253     1
    x[2250]   c2565     50
    x[2250]   c453      1
    x[2251]   c230_1    1
    x[2251]   c2598     1
    x[2251]   c454      -1
    x[2251]   c470      -1
    x[2251]   c1254     1
    x[2252]   c2566     50
    x[2252]   c454      1
    x[2253]   c231_1    1
    x[2253]   c2599     1
    x[2253]   c455      -1
    x[2253]   c471      -1
    x[2253]   c1255     1
    x[2254]   c2567     50
    x[2254]   c455      1
    x[2255]   c232_1    1
    x[2255]   c2600     1
    x[2255]   c456      -1
    x[2255]   c472      -1
    x[2255]   c1256     1
    x[2256]   c2568     50
    x[2256]   c456      1
    x[2257]   c233_1    1
    x[2257]   c2601     1
    x[2257]   c457      -1
    x[2257]   c473      -1
    x[2257]   c1257     1
    x[2258]   c2569     50
    x[2258]   c457      1
    x[2259]   c234_1    1
    x[2259]   c2602     1
    x[2259]   c458      -1
    x[2259]   c474      -1
    x[2259]   c1258     1
    x[2260]   c2570     50
    x[2260]   c458      1
    x[2261]   c235_1    1
    x[2261]   c2603     1
    x[2261]   c459      -1
    x[2261]   c475      -1
    x[2261]   c1259     1
    x[2262]   c2571     50
    x[2262]   c459      1
    x[2263]   c236_1    1
    x[2263]   c2604     1
    x[2263]   c460      -1
    x[2263]   c476      -1
    x[2263]   c1260     1
    x[2264]   c2572     50
    x[2264]   c460      1
    x[2265]   c237_1    1
    x[2265]   c2605     1
    x[2265]   c461      -1
    x[2265]   c477      -1
    x[2265]   c1261     1
    x[2266]   c2573     50
    x[2266]   c461      1
    x[2267]   c238_1    1
    x[2267]   c2606     1
    x[2267]   c462      -1
    x[2267]   c478      -1
    x[2267]   c1262     1
    x[2268]   c2574     50
    x[2268]   c462      1
    x[2269]   c239_1    1
    x[2269]   c2607     1
    x[2269]   c463      -1
    x[2269]   c479      -1
    x[2269]   c1263     1
    x[2270]   c2575     50
    x[2270]   c463      1
    x[2271]   c240_1    1
    x[2271]   c2608     1
    x[2271]   c464      -1
    x[2271]   c480      -1
    x[2271]   c1264     1
    x[2272]   c2576     50
    x[2272]   c464      1
    x[2273]   c481_1    1
    x[2273]   c2577     1
    x[2273]   c465      1
    x[2273]   c961      -1
    x[2273]   c977      -1
    x[2274]   c482_1    1
    x[2274]   c2578     1
    x[2274]   c466      1
    x[2274]   c962      -1
    x[2274]   c978      -1
    x[2275]   c483_1    1
    x[2275]   c2579     1
    x[2275]   c467      1
    x[2275]   c963      -1
    x[2275]   c979      -1
    x[2276]   c484_1    1
    x[2276]   c2580     1
    x[2276]   c468      1
    x[2276]   c964      -1
    x[2276]   c980      -1
    x[2277]   c485_1    1
    x[2277]   c2581     1
    x[2277]   c469      1
    x[2277]   c965      -1
    x[2277]   c981      -1
    x[2278]   c486_1    1
    x[2278]   c2582     1
    x[2278]   c470      1
    x[2278]   c966      -1
    x[2278]   c982      -1
    x[2279]   c487_1    1
    x[2279]   c2583     1
    x[2279]   c471      1
    x[2279]   c967      -1
    x[2279]   c983      -1
    x[2280]   c488_1    1
    x[2280]   c2584     1
    x[2280]   c472      1
    x[2280]   c968      -1
    x[2280]   c984      -1
    x[2281]   c489_1    1
    x[2281]   c2585     1
    x[2281]   c473      1
    x[2281]   c969      -1
    x[2281]   c985      -1
    x[2282]   c490_1    1
    x[2282]   c2586     1
    x[2282]   c474      1
    x[2282]   c970      -1
    x[2282]   c986      -1
    x[2283]   c491_1    1
    x[2283]   c2587     1
    x[2283]   c475      1
    x[2283]   c971      -1
    x[2283]   c987      -1
    x[2284]   c492_1    1
    x[2284]   c2588     1
    x[2284]   c476      1
    x[2284]   c972      -1
    x[2284]   c988      -1
    x[2285]   c493_1    1
    x[2285]   c2589     1
    x[2285]   c477      1
    x[2285]   c973      -1
    x[2285]   c989      -1
    x[2286]   c494_1    1
    x[2286]   c2590     1
    x[2286]   c478      1
    x[2286]   c974      -1
    x[2286]   c990      -1
    x[2287]   c495_1    1
    x[2287]   c2591     1
    x[2287]   c479      1
    x[2287]   c975      -1
    x[2287]   c991      -1
    x[2288]   c496_1    1
    x[2288]   c2592     1
    x[2288]   c480      1
    x[2288]   c976      -1
    x[2288]   c992      -1
    x[2289]   c241_1    1
    x[2289]   c2609     1
    x[2289]   c481      -1
    x[2289]   c497      -1
    x[2289]   c1265     1
    x[2290]   c2561     30
    x[2290]   c481      1
    x[2291]   c242_1    1
    x[2291]   c2610     1
    x[2291]   c482      -1
    x[2291]   c498      -1
    x[2291]   c1266     1
    x[2292]   c2562     30
    x[2292]   c482      1
    x[2293]   c243_1    1
    x[2293]   c2611     1
    x[2293]   c483      -1
    x[2293]   c499      -1
    x[2293]   c1267     1
    x[2294]   c2563     30
    x[2294]   c483      1
    x[2295]   c244_1    1
    x[2295]   c2612     1
    x[2295]   c484      -1
    x[2295]   c500      -1
    x[2295]   c1268     1
    x[2296]   c2564     30
    x[2296]   c484      1
    x[2297]   c245_1    1
    x[2297]   c2613     1
    x[2297]   c485      -1
    x[2297]   c501      -1
    x[2297]   c1269     1
    x[2298]   c2565     30
    x[2298]   c485      1
    x[2299]   c246_1    1
    x[2299]   c2614     1
    x[2299]   c486      -1
    x[2299]   c502      -1
    x[2299]   c1270     1
    x[2300]   c2566     30
    x[2300]   c486      1
    x[2301]   c247_1    1
    x[2301]   c2615     1
    x[2301]   c487      -1
    x[2301]   c503      -1
    x[2301]   c1271     1
    x[2302]   c2567     30
    x[2302]   c487      1
    x[2303]   c248_1    1
    x[2303]   c2616     1
    x[2303]   c488      -1
    x[2303]   c504      -1
    x[2303]   c1272     1
    x[2304]   c2568     30
    x[2304]   c488      1
    x[2305]   c249_1    1
    x[2305]   c2617     1
    x[2305]   c489      -1
    x[2305]   c505      -1
    x[2305]   c1273     1
    x[2306]   c2569     30
    x[2306]   c489      1
    x[2307]   c250_1    1
    x[2307]   c2618     1
    x[2307]   c490      -1
    x[2307]   c506      -1
    x[2307]   c1274     1
    x[2308]   c2570     30
    x[2308]   c490      1
    x[2309]   c251_1    1
    x[2309]   c2619     1
    x[2309]   c491      -1
    x[2309]   c507      -1
    x[2309]   c1275     1
    x[2310]   c2571     30
    x[2310]   c491      1
    x[2311]   c252_1    1
    x[2311]   c2620     1
    x[2311]   c492      -1
    x[2311]   c508      -1
    x[2311]   c1276     1
    x[2312]   c2572     30
    x[2312]   c492      1
    x[2313]   c253_1    1
    x[2313]   c2621     1
    x[2313]   c493      -1
    x[2313]   c509      -1
    x[2313]   c1277     1
    x[2314]   c2573     30
    x[2314]   c493      1
    x[2315]   c254_1    1
    x[2315]   c2622     1
    x[2315]   c494      -1
    x[2315]   c510      -1
    x[2315]   c1278     1
    x[2316]   c2574     30
    x[2316]   c494      1
    x[2317]   c255_1    1
    x[2317]   c2623     1
    x[2317]   c495      -1
    x[2317]   c511      -1
    x[2317]   c1279     1
    x[2318]   c2575     30
    x[2318]   c495      1
    x[2319]   c256_1    1
    x[2319]   c2624     1
    x[2319]   c496      -1
    x[2319]   c512      -1
    x[2319]   c1280     1
    x[2320]   c2576     30
    x[2320]   c496      1
    x[2321]   c497_1    1
    x[2321]   c2577     1
    x[2321]   c497      1
    x[2321]   c993      -1
    x[2321]   c1009     -1
    x[2322]   c498_1    1
    x[2322]   c2578     1
    x[2322]   c498      1
    x[2322]   c994      -1
    x[2322]   c1010     -1
    x[2323]   c499_1    1
    x[2323]   c2579     1
    x[2323]   c499      1
    x[2323]   c995      -1
    x[2323]   c1011     -1
    x[2324]   c500_1    1
    x[2324]   c2580     1
    x[2324]   c500      1
    x[2324]   c996      -1
    x[2324]   c1012     -1
    x[2325]   c501_1    1
    x[2325]   c2581     1
    x[2325]   c501      1
    x[2325]   c997      -1
    x[2325]   c1013     -1
    x[2326]   c502_1    1
    x[2326]   c2582     1
    x[2326]   c502      1
    x[2326]   c998      -1
    x[2326]   c1014     -1
    x[2327]   c503_1    1
    x[2327]   c2583     1
    x[2327]   c503      1
    x[2327]   c999      -1
    x[2327]   c1015     -1
    x[2328]   c504_1    1
    x[2328]   c2584     1
    x[2328]   c504      1
    x[2328]   c1000     -1
    x[2328]   c1016     -1
    x[2329]   c505_1    1
    x[2329]   c2585     1
    x[2329]   c505      1
    x[2329]   c1001     -1
    x[2329]   c1017     -1
    x[2330]   c506_1    1
    x[2330]   c2586     1
    x[2330]   c506      1
    x[2330]   c1002     -1
    x[2330]   c1018     -1
    x[2331]   c507_1    1
    x[2331]   c2587     1
    x[2331]   c507      1
    x[2331]   c1003     -1
    x[2331]   c1019     -1
    x[2332]   c508_1    1
    x[2332]   c2588     1
    x[2332]   c508      1
    x[2332]   c1004     -1
    x[2332]   c1020     -1
    x[2333]   c509_1    1
    x[2333]   c2589     1
    x[2333]   c509      1
    x[2333]   c1005     -1
    x[2333]   c1021     -1
    x[2334]   c510_1    1
    x[2334]   c2590     1
    x[2334]   c510      1
    x[2334]   c1006     -1
    x[2334]   c1022     -1
    x[2335]   c511_1    1
    x[2335]   c2591     1
    x[2335]   c511      1
    x[2335]   c1007     -1
    x[2335]   c1023     -1
    x[2336]   c512_1    1
    x[2336]   c2592     1
    x[2336]   c512      1
    x[2336]   c1008     -1
    x[2336]   c1024     -1
    x[2337]   c513_1    1
    x[2337]   c2561     1
    x[2337]   c513      1
    x[2338]   c514_1    1
    x[2338]   c2562     1
    x[2338]   c514      1
    x[2339]   c515_1    1
    x[2339]   c2563     1
    x[2339]   c515      1
    x[2340]   c516_1    1
    x[2340]   c2564     1
    x[2340]   c516      1
    x[2341]   c517_1    1
    x[2341]   c2565     1
    x[2341]   c517      1
    x[2342]   c518_1    1
    x[2342]   c2566     1
    x[2342]   c518      1
    x[2343]   c519_1    1
    x[2343]   c2567     1
    x[2343]   c519      1
    x[2344]   c520_1    1
    x[2344]   c2568     1
    x[2344]   c520      1
    x[2345]   c521_1    1
    x[2345]   c2569     1
    x[2345]   c521      1
    x[2346]   c522_1    1
    x[2346]   c2570     1
    x[2346]   c522      1
    x[2347]   c523_1    1
    x[2347]   c2571     1
    x[2347]   c523      1
    x[2348]   c524_1    1
    x[2348]   c2572     1
    x[2348]   c524      1
    x[2349]   c525_1    1
    x[2349]   c2573     1
    x[2349]   c525      1
    x[2350]   c526_1    1
    x[2350]   c2574     1
    x[2350]   c526      1
    x[2351]   c527_1    1
    x[2351]   c2575     1
    x[2351]   c527      1
    x[2352]   c528_1    1
    x[2352]   c2576     1
    x[2352]   c528      1
    x[2353]   c529_1    1
    x[2353]   c2561     1.5
    x[2353]   c529      1
    x[2354]   c530_1    1
    x[2354]   c2562     1.5
    x[2354]   c530      1
    x[2355]   c531_1    1
    x[2355]   c2563     1.5
    x[2355]   c531      1
    x[2356]   c532_1    1
    x[2356]   c2564     1.5
    x[2356]   c532      1
    x[2357]   c533_1    1
    x[2357]   c2565     1.5
    x[2357]   c533      1
    x[2358]   c534_1    1
    x[2358]   c2566     1.5
    x[2358]   c534      1
    x[2359]   c535_1    1
    x[2359]   c2567     1.5
    x[2359]   c535      1
    x[2360]   c536_1    1
    x[2360]   c2568     1.5
    x[2360]   c536      1
    x[2361]   c537_1    1
    x[2361]   c2569     1.5
    x[2361]   c537      1
    x[2362]   c538_1    1
    x[2362]   c2570     1.5
    x[2362]   c538      1
    x[2363]   c539_1    1
    x[2363]   c2571     1.5
    x[2363]   c539      1
    x[2364]   c540_1    1
    x[2364]   c2572     1.5
    x[2364]   c540      1
    x[2365]   c541_1    1
    x[2365]   c2573     1.5
    x[2365]   c541      1
    x[2366]   c542_1    1
    x[2366]   c2574     1.5
    x[2366]   c542      1
    x[2367]   c543_1    1
    x[2367]   c2575     1.5
    x[2367]   c543      1
    x[2368]   c544_1    1
    x[2368]   c2576     1.5
    x[2368]   c544      1
    x[2369]   c545_1    1
    x[2369]   c2561     1
    x[2369]   c545      1
    x[2370]   c546_1    1
    x[2370]   c2562     1
    x[2370]   c546      1
    x[2371]   c547_1    1
    x[2371]   c2563     1
    x[2371]   c547      1
    x[2372]   c548_1    1
    x[2372]   c2564     1
    x[2372]   c548      1
    x[2373]   c549_1    1
    x[2373]   c2565     1
    x[2373]   c549      1
    x[2374]   c550_1    1
    x[2374]   c2566     1
    x[2374]   c550      1
    x[2375]   c551_1    1
    x[2375]   c2567     1
    x[2375]   c551      1
    x[2376]   c552_1    1
    x[2376]   c2568     1
    x[2376]   c552      1
    x[2377]   c553_1    1
    x[2377]   c2569     1
    x[2377]   c553      1
    x[2378]   c554_1    1
    x[2378]   c2570     1
    x[2378]   c554      1
    x[2379]   c555_1    1
    x[2379]   c2571     1
    x[2379]   c555      1
    x[2380]   c556_1    1
    x[2380]   c2572     1
    x[2380]   c556      1
    x[2381]   c557_1    1
    x[2381]   c2573     1
    x[2381]   c557      1
    x[2382]   c558_1    1
    x[2382]   c2574     1
    x[2382]   c558      1
    x[2383]   c559_1    1
    x[2383]   c2575     1
    x[2383]   c559      1
    x[2384]   c560_1    1
    x[2384]   c2576     1
    x[2384]   c560      1
    x[2385]   c561_1    1
    x[2385]   c2561     1.5
    x[2385]   c561      1
    x[2386]   c562_1    1
    x[2386]   c2562     1.5
    x[2386]   c562      1
    x[2387]   c563_1    1
    x[2387]   c2563     1.5
    x[2387]   c563      1
    x[2388]   c564_1    1
    x[2388]   c2564     1.5
    x[2388]   c564      1
    x[2389]   c565_1    1
    x[2389]   c2565     1.5
    x[2389]   c565      1
    x[2390]   c566_1    1
    x[2390]   c2566     1.5
    x[2390]   c566      1
    x[2391]   c567_1    1
    x[2391]   c2567     1.5
    x[2391]   c567      1
    x[2392]   c568_1    1
    x[2392]   c2568     1.5
    x[2392]   c568      1
    x[2393]   c569_1    1
    x[2393]   c2569     1.5
    x[2393]   c569      1
    x[2394]   c570_1    1
    x[2394]   c2570     1.5
    x[2394]   c570      1
    x[2395]   c571_1    1
    x[2395]   c2571     1.5
    x[2395]   c571      1
    x[2396]   c572_1    1
    x[2396]   c2572     1.5
    x[2396]   c572      1
    x[2397]   c573_1    1
    x[2397]   c2573     1.5
    x[2397]   c573      1
    x[2398]   c574_1    1
    x[2398]   c2574     1.5
    x[2398]   c574      1
    x[2399]   c575_1    1
    x[2399]   c2575     1.5
    x[2399]   c575      1
    x[2400]   c576_1    1
    x[2400]   c2576     1.5
    x[2400]   c576      1
    x[2401]   c577_1    1
    x[2401]   c2561     0.2
    x[2401]   c577      1
    x[2402]   c578_1    1
    x[2402]   c2562     0.2
    x[2402]   c578      1
    x[2403]   c579_1    1
    x[2403]   c2563     0.2
    x[2403]   c579      1
    x[2404]   c580_1    1
    x[2404]   c2564     0.2
    x[2404]   c580      1
    x[2405]   c581_1    1
    x[2405]   c2565     0.2
    x[2405]   c581      1
    x[2406]   c582_1    1
    x[2406]   c2566     0.2
    x[2406]   c582      1
    x[2407]   c583_1    1
    x[2407]   c2567     0.2
    x[2407]   c583      1
    x[2408]   c584_1    1
    x[2408]   c2568     0.2
    x[2408]   c584      1
    x[2409]   c585_1    1
    x[2409]   c2569     0.2
    x[2409]   c585      1
    x[2410]   c586_1    1
    x[2410]   c2570     0.2
    x[2410]   c586      1
    x[2411]   c587_1    1
    x[2411]   c2571     0.2
    x[2411]   c587      1
    x[2412]   c588_1    1
    x[2412]   c2572     0.2
    x[2412]   c588      1
    x[2413]   c589_1    1
    x[2413]   c2573     0.2
    x[2413]   c589      1
    x[2414]   c590_1    1
    x[2414]   c2574     0.2
    x[2414]   c590      1
    x[2415]   c591_1    1
    x[2415]   c2575     0.2
    x[2415]   c591      1
    x[2416]   c592_1    1
    x[2416]   c2576     0.2
    x[2416]   c592      1
    x[2417]   c593_1    1
    x[2417]   c2561     1
    x[2417]   c593      1
    x[2418]   c594_1    1
    x[2418]   c2562     1
    x[2418]   c594      1
    x[2419]   c595_1    1
    x[2419]   c2563     1
    x[2419]   c595      1
    x[2420]   c596_1    1
    x[2420]   c2564     1
    x[2420]   c596      1
    x[2421]   c597_1    1
    x[2421]   c2565     1
    x[2421]   c597      1
    x[2422]   c598_1    1
    x[2422]   c2566     1
    x[2422]   c598      1
    x[2423]   c599_1    1
    x[2423]   c2567     1
    x[2423]   c599      1
    x[2424]   c600_1    1
    x[2424]   c2568     1
    x[2424]   c600      1
    x[2425]   c601_1    1
    x[2425]   c2569     1
    x[2425]   c601      1
    x[2426]   c602_1    1
    x[2426]   c2570     1
    x[2426]   c602      1
    x[2427]   c603_1    1
    x[2427]   c2571     1
    x[2427]   c603      1
    x[2428]   c604_1    1
    x[2428]   c2572     1
    x[2428]   c604      1
    x[2429]   c605_1    1
    x[2429]   c2573     1
    x[2429]   c605      1
    x[2430]   c606_1    1
    x[2430]   c2574     1
    x[2430]   c606      1
    x[2431]   c607_1    1
    x[2431]   c2575     1
    x[2431]   c607      1
    x[2432]   c608_1    1
    x[2432]   c2576     1
    x[2432]   c608      1
    x[2433]   c609_1    1
    x[2433]   c2561     0.2
    x[2433]   c609      1
    x[2434]   c610_1    1
    x[2434]   c2562     0.2
    x[2434]   c610      1
    x[2435]   c611_1    1
    x[2435]   c2563     0.2
    x[2435]   c611      1
    x[2436]   c612_1    1
    x[2436]   c2564     0.2
    x[2436]   c612      1
    x[2437]   c613_1    1
    x[2437]   c2565     0.2
    x[2437]   c613      1
    x[2438]   c614_1    1
    x[2438]   c2566     0.2
    x[2438]   c614      1
    x[2439]   c615_1    1
    x[2439]   c2567     0.2
    x[2439]   c615      1
    x[2440]   c616_1    1
    x[2440]   c2568     0.2
    x[2440]   c616      1
    x[2441]   c617_1    1
    x[2441]   c2569     0.2
    x[2441]   c617      1
    x[2442]   c618_1    1
    x[2442]   c2570     0.2
    x[2442]   c618      1
    x[2443]   c619_1    1
    x[2443]   c2571     0.2
    x[2443]   c619      1
    x[2444]   c620_1    1
    x[2444]   c2572     0.2
    x[2444]   c620      1
    x[2445]   c621_1    1
    x[2445]   c2573     0.2
    x[2445]   c621      1
    x[2446]   c622_1    1
    x[2446]   c2574     0.2
    x[2446]   c622      1
    x[2447]   c623_1    1
    x[2447]   c2575     0.2
    x[2447]   c623      1
    x[2448]   c624_1    1
    x[2448]   c2576     0.2
    x[2448]   c624      1
    x[2449]   c625_1    1
    x[2449]   c2561     1
    x[2449]   c625      1
    x[2450]   c626_1    1
    x[2450]   c2562     1
    x[2450]   c626      1
    x[2451]   c627_1    1
    x[2451]   c2563     1
    x[2451]   c627      1
    x[2452]   c628_1    1
    x[2452]   c2564     1
    x[2452]   c628      1
    x[2453]   c629_1    1
    x[2453]   c2565     1
    x[2453]   c629      1
    x[2454]   c630_1    1
    x[2454]   c2566     1
    x[2454]   c630      1
    x[2455]   c631_1    1
    x[2455]   c2567     1
    x[2455]   c631      1
    x[2456]   c632_1    1
    x[2456]   c2568     1
    x[2456]   c632      1
    x[2457]   c633_1    1
    x[2457]   c2569     1
    x[2457]   c633      1
    x[2458]   c634_1    1
    x[2458]   c2570     1
    x[2458]   c634      1
    x[2459]   c635_1    1
    x[2459]   c2571     1
    x[2459]   c635      1
    x[2460]   c636_1    1
    x[2460]   c2572     1
    x[2460]   c636      1
    x[2461]   c637_1    1
    x[2461]   c2573     1
    x[2461]   c637      1
    x[2462]   c638_1    1
    x[2462]   c2574     1
    x[2462]   c638      1
    x[2463]   c639_1    1
    x[2463]   c2575     1
    x[2463]   c639      1
    x[2464]   c640_1    1
    x[2464]   c2576     1
    x[2464]   c640      1
    x[2465]   c641_1    1
    x[2465]   c2561     0.5
    x[2465]   c641      1
    x[2466]   c642_1    1
    x[2466]   c2562     0.5
    x[2466]   c642      1
    x[2467]   c643_1    1
    x[2467]   c2563     0.5
    x[2467]   c643      1
    x[2468]   c644_1    1
    x[2468]   c2564     0.5
    x[2468]   c644      1
    x[2469]   c645_1    1
    x[2469]   c2565     0.5
    x[2469]   c645      1
    x[2470]   c646_1    1
    x[2470]   c2566     0.5
    x[2470]   c646      1
    x[2471]   c647_1    1
    x[2471]   c2567     0.5
    x[2471]   c647      1
    x[2472]   c648_1    1
    x[2472]   c2568     0.5
    x[2472]   c648      1
    x[2473]   c649_1    1
    x[2473]   c2569     0.5
    x[2473]   c649      1
    x[2474]   c650_1    1
    x[2474]   c2570     0.5
    x[2474]   c650      1
    x[2475]   c651_1    1
    x[2475]   c2571     0.5
    x[2475]   c651      1
    x[2476]   c652_1    1
    x[2476]   c2572     0.5
    x[2476]   c652      1
    x[2477]   c653_1    1
    x[2477]   c2573     0.5
    x[2477]   c653      1
    x[2478]   c654_1    1
    x[2478]   c2574     0.5
    x[2478]   c654      1
    x[2479]   c655_1    1
    x[2479]   c2575     0.5
    x[2479]   c655      1
    x[2480]   c656_1    1
    x[2480]   c2576     0.5
    x[2480]   c656      1
    x[2481]   c657_1    1
    x[2481]   c2561     3
    x[2481]   c657      1
    x[2482]   c658_1    1
    x[2482]   c2562     3
    x[2482]   c658      1
    x[2483]   c659_1    1
    x[2483]   c2563     3
    x[2483]   c659      1
    x[2484]   c660_1    1
    x[2484]   c2564     3
    x[2484]   c660      1
    x[2485]   c661_1    1
    x[2485]   c2565     3
    x[2485]   c661      1
    x[2486]   c662_1    1
    x[2486]   c2566     3
    x[2486]   c662      1
    x[2487]   c663_1    1
    x[2487]   c2567     3
    x[2487]   c663      1
    x[2488]   c664_1    1
    x[2488]   c2568     3
    x[2488]   c664      1
    x[2489]   c665_1    1
    x[2489]   c2569     3
    x[2489]   c665      1
    x[2490]   c666_1    1
    x[2490]   c2570     3
    x[2490]   c666      1
    x[2491]   c667_1    1
    x[2491]   c2571     3
    x[2491]   c667      1
    x[2492]   c668_1    1
    x[2492]   c2572     3
    x[2492]   c668      1
    x[2493]   c669_1    1
    x[2493]   c2573     3
    x[2493]   c669      1
    x[2494]   c670_1    1
    x[2494]   c2574     3
    x[2494]   c670      1
    x[2495]   c671_1    1
    x[2495]   c2575     3
    x[2495]   c671      1
    x[2496]   c672_1    1
    x[2496]   c2576     3
    x[2496]   c672      1
    x[2497]   c673_1    1
    x[2497]   c2561     0.5
    x[2497]   c673      1
    x[2498]   c674_1    1
    x[2498]   c2562     0.5
    x[2498]   c674      1
    x[2499]   c675_1    1
    x[2499]   c2563     0.5
    x[2499]   c675      1
    x[2500]   c676_1    1
    x[2500]   c2564     0.5
    x[2500]   c676      1
    x[2501]   c677_1    1
    x[2501]   c2565     0.5
    x[2501]   c677      1
    x[2502]   c678_1    1
    x[2502]   c2566     0.5
    x[2502]   c678      1
    x[2503]   c679_1    1
    x[2503]   c2567     0.5
    x[2503]   c679      1
    x[2504]   c680_1    1
    x[2504]   c2568     0.5
    x[2504]   c680      1
    x[2505]   c681_1    1
    x[2505]   c2569     0.5
    x[2505]   c681      1
    x[2506]   c682_1    1
    x[2506]   c2570     0.5
    x[2506]   c682      1
    x[2507]   c683_1    1
    x[2507]   c2571     0.5
    x[2507]   c683      1
    x[2508]   c684_1    1
    x[2508]   c2572     0.5
    x[2508]   c684      1
    x[2509]   c685_1    1
    x[2509]   c2573     0.5
    x[2509]   c685      1
    x[2510]   c686_1    1
    x[2510]   c2574     0.5
    x[2510]   c686      1
    x[2511]   c687_1    1
    x[2511]   c2575     0.5
    x[2511]   c687      1
    x[2512]   c688_1    1
    x[2512]   c2576     0.5
    x[2512]   c688      1
    x[2513]   c689_1    1
    x[2513]   c2561     3
    x[2513]   c689      1
    x[2514]   c690_1    1
    x[2514]   c2562     3
    x[2514]   c690      1
    x[2515]   c691_1    1
    x[2515]   c2563     3
    x[2515]   c691      1
    x[2516]   c692_1    1
    x[2516]   c2564     3
    x[2516]   c692      1
    x[2517]   c693_1    1
    x[2517]   c2565     3
    x[2517]   c693      1
    x[2518]   c694_1    1
    x[2518]   c2566     3
    x[2518]   c694      1
    x[2519]   c695_1    1
    x[2519]   c2567     3
    x[2519]   c695      1
    x[2520]   c696_1    1
    x[2520]   c2568     3
    x[2520]   c696      1
    x[2521]   c697_1    1
    x[2521]   c2569     3
    x[2521]   c697      1
    x[2522]   c698_1    1
    x[2522]   c2570     3
    x[2522]   c698      1
    x[2523]   c699_1    1
    x[2523]   c2571     3
    x[2523]   c699      1
    x[2524]   c700_1    1
    x[2524]   c2572     3
    x[2524]   c700      1
    x[2525]   c701_1    1
    x[2525]   c2573     3
    x[2525]   c701      1
    x[2526]   c702_1    1
    x[2526]   c2574     3
    x[2526]   c702      1
    x[2527]   c703_1    1
    x[2527]   c2575     3
    x[2527]   c703      1
    x[2528]   c704_1    1
    x[2528]   c2576     3
    x[2528]   c704      1
    x[2529]   c705_1    1
    x[2529]   c2561     0.2
    x[2529]   c705      1
    x[2530]   c706_1    1
    x[2530]   c2562     0.2
    x[2530]   c706      1
    x[2531]   c707_1    1
    x[2531]   c2563     0.2
    x[2531]   c707      1
    x[2532]   c708_1    1
    x[2532]   c2564     0.2
    x[2532]   c708      1
    x[2533]   c709_1    1
    x[2533]   c2565     0.2
    x[2533]   c709      1
    x[2534]   c710_1    1
    x[2534]   c2566     0.2
    x[2534]   c710      1
    x[2535]   c711_1    1
    x[2535]   c2567     0.2
    x[2535]   c711      1
    x[2536]   c712_1    1
    x[2536]   c2568     0.2
    x[2536]   c712      1
    x[2537]   c713_1    1
    x[2537]   c2569     0.2
    x[2537]   c713      1
    x[2538]   c714_1    1
    x[2538]   c2570     0.2
    x[2538]   c714      1
    x[2539]   c715_1    1
    x[2539]   c2571     0.2
    x[2539]   c715      1
    x[2540]   c716_1    1
    x[2540]   c2572     0.2
    x[2540]   c716      1
    x[2541]   c717_1    1
    x[2541]   c2573     0.2
    x[2541]   c717      1
    x[2542]   c718_1    1
    x[2542]   c2574     0.2
    x[2542]   c718      1
    x[2543]   c719_1    1
    x[2543]   c2575     0.2
    x[2543]   c719      1
    x[2544]   c720_1    1
    x[2544]   c2576     0.2
    x[2544]   c720      1
    x[2545]   c721_1    1
    x[2545]   c2561     1.5
    x[2545]   c721      1
    x[2546]   c722_1    1
    x[2546]   c2562     1.5
    x[2546]   c722      1
    x[2547]   c723_1    1
    x[2547]   c2563     1.5
    x[2547]   c723      1
    x[2548]   c724_1    1
    x[2548]   c2564     1.5
    x[2548]   c724      1
    x[2549]   c725_1    1
    x[2549]   c2565     1.5
    x[2549]   c725      1
    x[2550]   c726_1    1
    x[2550]   c2566     1.5
    x[2550]   c726      1
    x[2551]   c727_1    1
    x[2551]   c2567     1.5
    x[2551]   c727      1
    x[2552]   c728_1    1
    x[2552]   c2568     1.5
    x[2552]   c728      1
    x[2553]   c729_1    1
    x[2553]   c2569     1.5
    x[2553]   c729      1
    x[2554]   c730_1    1
    x[2554]   c2570     1.5
    x[2554]   c730      1
    x[2555]   c731_1    1
    x[2555]   c2571     1.5
    x[2555]   c731      1
    x[2556]   c732_1    1
    x[2556]   c2572     1.5
    x[2556]   c732      1
    x[2557]   c733_1    1
    x[2557]   c2573     1.5
    x[2557]   c733      1
    x[2558]   c734_1    1
    x[2558]   c2574     1.5
    x[2558]   c734      1
    x[2559]   c735_1    1
    x[2559]   c2575     1.5
    x[2559]   c735      1
    x[2560]   c736_1    1
    x[2560]   c2576     1.5
    x[2560]   c736      1
    x[2561]   c737_1    1
    x[2561]   c2561     0.2
    x[2561]   c737      1
    x[2562]   c738_1    1
    x[2562]   c2562     0.2
    x[2562]   c738      1
    x[2563]   c739_1    1
    x[2563]   c2563     0.2
    x[2563]   c739      1
    x[2564]   c740_1    1
    x[2564]   c2564     0.2
    x[2564]   c740      1
    x[2565]   c741_1    1
    x[2565]   c2565     0.2
    x[2565]   c741      1
    x[2566]   c742_1    1
    x[2566]   c2566     0.2
    x[2566]   c742      1
    x[2567]   c743_1    1
    x[2567]   c2567     0.2
    x[2567]   c743      1
    x[2568]   c744_1    1
    x[2568]   c2568     0.2
    x[2568]   c744      1
    x[2569]   c745_1    1
    x[2569]   c2569     0.2
    x[2569]   c745      1
    x[2570]   c746_1    1
    x[2570]   c2570     0.2
    x[2570]   c746      1
    x[2571]   c747_1    1
    x[2571]   c2571     0.2
    x[2571]   c747      1
    x[2572]   c748_1    1
    x[2572]   c2572     0.2
    x[2572]   c748      1
    x[2573]   c749_1    1
    x[2573]   c2573     0.2
    x[2573]   c749      1
    x[2574]   c750_1    1
    x[2574]   c2574     0.2
    x[2574]   c750      1
    x[2575]   c751_1    1
    x[2575]   c2575     0.2
    x[2575]   c751      1
    x[2576]   c752_1    1
    x[2576]   c2576     0.2
    x[2576]   c752      1
    x[2577]   c753_1    1
    x[2577]   c2561     1.5
    x[2577]   c753      1
    x[2578]   c754_1    1
    x[2578]   c2562     1.5
    x[2578]   c754      1
    x[2579]   c755_1    1
    x[2579]   c2563     1.5
    x[2579]   c755      1
    x[2580]   c756_1    1
    x[2580]   c2564     1.5
    x[2580]   c756      1
    x[2581]   c757_1    1
    x[2581]   c2565     1.5
    x[2581]   c757      1
    x[2582]   c758_1    1
    x[2582]   c2566     1.5
    x[2582]   c758      1
    x[2583]   c759_1    1
    x[2583]   c2567     1.5
    x[2583]   c759      1
    x[2584]   c760_1    1
    x[2584]   c2568     1.5
    x[2584]   c760      1
    x[2585]   c761_1    1
    x[2585]   c2569     1.5
    x[2585]   c761      1
    x[2586]   c762_1    1
    x[2586]   c2570     1.5
    x[2586]   c762      1
    x[2587]   c763_1    1
    x[2587]   c2571     1.5
    x[2587]   c763      1
    x[2588]   c764_1    1
    x[2588]   c2572     1.5
    x[2588]   c764      1
    x[2589]   c765_1    1
    x[2589]   c2573     1.5
    x[2589]   c765      1
    x[2590]   c766_1    1
    x[2590]   c2574     1.5
    x[2590]   c766      1
    x[2591]   c767_1    1
    x[2591]   c2575     1.5
    x[2591]   c767      1
    x[2592]   c768_1    1
    x[2592]   c2576     1.5
    x[2592]   c768      1
    x[2593]   c769_1    1
    x[2593]   c2561     0.5
    x[2593]   c769      1
    x[2594]   c770_1    1
    x[2594]   c2562     0.5
    x[2594]   c770      1
    x[2595]   c771_1    1
    x[2595]   c2563     0.5
    x[2595]   c771      1
    x[2596]   c772_1    1
    x[2596]   c2564     0.5
    x[2596]   c772      1
    x[2597]   c773_1    1
    x[2597]   c2565     0.5
    x[2597]   c773      1
    x[2598]   c774_1    1
    x[2598]   c2566     0.5
    x[2598]   c774      1
    x[2599]   c775_1    1
    x[2599]   c2567     0.5
    x[2599]   c775      1
    x[2600]   c776_1    1
    x[2600]   c2568     0.5
    x[2600]   c776      1
    x[2601]   c777_1    1
    x[2601]   c2569     0.5
    x[2601]   c777      1
    x[2602]   c778_1    1
    x[2602]   c2570     0.5
    x[2602]   c778      1
    x[2603]   c779_1    1
    x[2603]   c2571     0.5
    x[2603]   c779      1
    x[2604]   c780_1    1
    x[2604]   c2572     0.5
    x[2604]   c780      1
    x[2605]   c781_1    1
    x[2605]   c2573     0.5
    x[2605]   c781      1
    x[2606]   c782_1    1
    x[2606]   c2574     0.5
    x[2606]   c782      1
    x[2607]   c783_1    1
    x[2607]   c2575     0.5
    x[2607]   c783      1
    x[2608]   c784_1    1
    x[2608]   c2576     0.5
    x[2608]   c784      1
    x[2609]   c785_1    1
    x[2609]   c2561     2.5
    x[2609]   c785      1
    x[2610]   c786_1    1
    x[2610]   c2562     2.5
    x[2610]   c786      1
    x[2611]   c787_1    1
    x[2611]   c2563     2.5
    x[2611]   c787      1
    x[2612]   c788_1    1
    x[2612]   c2564     2.5
    x[2612]   c788      1
    x[2613]   c789_1    1
    x[2613]   c2565     2.5
    x[2613]   c789      1
    x[2614]   c790_1    1
    x[2614]   c2566     2.5
    x[2614]   c790      1
    x[2615]   c791_1    1
    x[2615]   c2567     2.5
    x[2615]   c791      1
    x[2616]   c792_1    1
    x[2616]   c2568     2.5
    x[2616]   c792      1
    x[2617]   c793_1    1
    x[2617]   c2569     2.5
    x[2617]   c793      1
    x[2618]   c794_1    1
    x[2618]   c2570     2.5
    x[2618]   c794      1
    x[2619]   c795_1    1
    x[2619]   c2571     2.5
    x[2619]   c795      1
    x[2620]   c796_1    1
    x[2620]   c2572     2.5
    x[2620]   c796      1
    x[2621]   c797_1    1
    x[2621]   c2573     2.5
    x[2621]   c797      1
    x[2622]   c798_1    1
    x[2622]   c2574     2.5
    x[2622]   c798      1
    x[2623]   c799_1    1
    x[2623]   c2575     2.5
    x[2623]   c799      1
    x[2624]   c800_1    1
    x[2624]   c2576     2.5
    x[2624]   c800      1
    x[2625]   c801_1    1
    x[2625]   c2561     0.5
    x[2625]   c801      1
    x[2626]   c802_1    1
    x[2626]   c2562     0.5
    x[2626]   c802      1
    x[2627]   c803_1    1
    x[2627]   c2563     0.5
    x[2627]   c803      1
    x[2628]   c804_1    1
    x[2628]   c2564     0.5
    x[2628]   c804      1
    x[2629]   c805_1    1
    x[2629]   c2565     0.5
    x[2629]   c805      1
    x[2630]   c806_1    1
    x[2630]   c2566     0.5
    x[2630]   c806      1
    x[2631]   c807_1    1
    x[2631]   c2567     0.5
    x[2631]   c807      1
    x[2632]   c808_1    1
    x[2632]   c2568     0.5
    x[2632]   c808      1
    x[2633]   c809_1    1
    x[2633]   c2569     0.5
    x[2633]   c809      1
    x[2634]   c810_1    1
    x[2634]   c2570     0.5
    x[2634]   c810      1
    x[2635]   c811_1    1
    x[2635]   c2571     0.5
    x[2635]   c811      1
    x[2636]   c812_1    1
    x[2636]   c2572     0.5
    x[2636]   c812      1
    x[2637]   c813_1    1
    x[2637]   c2573     0.5
    x[2637]   c813      1
    x[2638]   c814_1    1
    x[2638]   c2574     0.5
    x[2638]   c814      1
    x[2639]   c815_1    1
    x[2639]   c2575     0.5
    x[2639]   c815      1
    x[2640]   c816_1    1
    x[2640]   c2576     0.5
    x[2640]   c816      1
    x[2641]   c817_1    1
    x[2641]   c2561     2.5
    x[2641]   c817      1
    x[2642]   c818_1    1
    x[2642]   c2562     2.5
    x[2642]   c818      1
    x[2643]   c819_1    1
    x[2643]   c2563     2.5
    x[2643]   c819      1
    x[2644]   c820_1    1
    x[2644]   c2564     2.5
    x[2644]   c820      1
    x[2645]   c821_1    1
    x[2645]   c2565     2.5
    x[2645]   c821      1
    x[2646]   c822_1    1
    x[2646]   c2566     2.5
    x[2646]   c822      1
    x[2647]   c823_1    1
    x[2647]   c2567     2.5
    x[2647]   c823      1
    x[2648]   c824_1    1
    x[2648]   c2568     2.5
    x[2648]   c824      1
    x[2649]   c825_1    1
    x[2649]   c2569     2.5
    x[2649]   c825      1
    x[2650]   c826_1    1
    x[2650]   c2570     2.5
    x[2650]   c826      1
    x[2651]   c827_1    1
    x[2651]   c2571     2.5
    x[2651]   c827      1
    x[2652]   c828_1    1
    x[2652]   c2572     2.5
    x[2652]   c828      1
    x[2653]   c829_1    1
    x[2653]   c2573     2.5
    x[2653]   c829      1
    x[2654]   c830_1    1
    x[2654]   c2574     2.5
    x[2654]   c830      1
    x[2655]   c831_1    1
    x[2655]   c2575     2.5
    x[2655]   c831      1
    x[2656]   c832_1    1
    x[2656]   c2576     2.5
    x[2656]   c832      1
    x[2657]   c833_1    1
    x[2657]   c2561     0.2
    x[2657]   c833      1
    x[2658]   c834_1    1
    x[2658]   c2562     0.2
    x[2658]   c834      1
    x[2659]   c835_1    1
    x[2659]   c2563     0.2
    x[2659]   c835      1
    x[2660]   c836_1    1
    x[2660]   c2564     0.2
    x[2660]   c836      1
    x[2661]   c837_1    1
    x[2661]   c2565     0.2
    x[2661]   c837      1
    x[2662]   c838_1    1
    x[2662]   c2566     0.2
    x[2662]   c838      1
    x[2663]   c839_1    1
    x[2663]   c2567     0.2
    x[2663]   c839      1
    x[2664]   c840_1    1
    x[2664]   c2568     0.2
    x[2664]   c840      1
    x[2665]   c841_1    1
    x[2665]   c2569     0.2
    x[2665]   c841      1
    x[2666]   c842_1    1
    x[2666]   c2570     0.2
    x[2666]   c842      1
    x[2667]   c843_1    1
    x[2667]   c2571     0.2
    x[2667]   c843      1
    x[2668]   c844_1    1
    x[2668]   c2572     0.2
    x[2668]   c844      1
    x[2669]   c845_1    1
    x[2669]   c2573     0.2
    x[2669]   c845      1
    x[2670]   c846_1    1
    x[2670]   c2574     0.2
    x[2670]   c846      1
    x[2671]   c847_1    1
    x[2671]   c2575     0.2
    x[2671]   c847      1
    x[2672]   c848_1    1
    x[2672]   c2576     0.2
    x[2672]   c848      1
    x[2673]   c849_1    1
    x[2673]   c2561     2
    x[2673]   c849      1
    x[2674]   c850_1    1
    x[2674]   c2562     2
    x[2674]   c850      1
    x[2675]   c851_1    1
    x[2675]   c2563     2
    x[2675]   c851      1
    x[2676]   c852_1    1
    x[2676]   c2564     2
    x[2676]   c852      1
    x[2677]   c853_1    1
    x[2677]   c2565     2
    x[2677]   c853      1
    x[2678]   c854_1    1
    x[2678]   c2566     2
    x[2678]   c854      1
    x[2679]   c855_1    1
    x[2679]   c2567     2
    x[2679]   c855      1
    x[2680]   c856_1    1
    x[2680]   c2568     2
    x[2680]   c856      1
    x[2681]   c857_1    1
    x[2681]   c2569     2
    x[2681]   c857      1
    x[2682]   c858_1    1
    x[2682]   c2570     2
    x[2682]   c858      1
    x[2683]   c859_1    1
    x[2683]   c2571     2
    x[2683]   c859      1
    x[2684]   c860_1    1
    x[2684]   c2572     2
    x[2684]   c860      1
    x[2685]   c861_1    1
    x[2685]   c2573     2
    x[2685]   c861      1
    x[2686]   c862_1    1
    x[2686]   c2574     2
    x[2686]   c862      1
    x[2687]   c863_1    1
    x[2687]   c2575     2
    x[2687]   c863      1
    x[2688]   c864_1    1
    x[2688]   c2576     2
    x[2688]   c864      1
    x[2689]   c865_1    1
    x[2689]   c2561     0.2
    x[2689]   c865      1
    x[2690]   c866_1    1
    x[2690]   c2562     0.2
    x[2690]   c866      1
    x[2691]   c867_1    1
    x[2691]   c2563     0.2
    x[2691]   c867      1
    x[2692]   c868_1    1
    x[2692]   c2564     0.2
    x[2692]   c868      1
    x[2693]   c869_1    1
    x[2693]   c2565     0.2
    x[2693]   c869      1
    x[2694]   c870_1    1
    x[2694]   c2566     0.2
    x[2694]   c870      1
    x[2695]   c871_1    1
    x[2695]   c2567     0.2
    x[2695]   c871      1
    x[2696]   c872_1    1
    x[2696]   c2568     0.2
    x[2696]   c872      1
    x[2697]   c873_1    1
    x[2697]   c2569     0.2
    x[2697]   c873      1
    x[2698]   c874_1    1
    x[2698]   c2570     0.2
    x[2698]   c874      1
    x[2699]   c875_1    1
    x[2699]   c2571     0.2
    x[2699]   c875      1
    x[2700]   c876_1    1
    x[2700]   c2572     0.2
    x[2700]   c876      1
    x[2701]   c877_1    1
    x[2701]   c2573     0.2
    x[2701]   c877      1
    x[2702]   c878_1    1
    x[2702]   c2574     0.2
    x[2702]   c878      1
    x[2703]   c879_1    1
    x[2703]   c2575     0.2
    x[2703]   c879      1
    x[2704]   c880_1    1
    x[2704]   c2576     0.2
    x[2704]   c880      1
    x[2705]   c881_1    1
    x[2705]   c2561     2
    x[2705]   c881      1
    x[2706]   c882_1    1
    x[2706]   c2562     2
    x[2706]   c882      1
    x[2707]   c883_1    1
    x[2707]   c2563     2
    x[2707]   c883      1
    x[2708]   c884_1    1
    x[2708]   c2564     2
    x[2708]   c884      1
    x[2709]   c885_1    1
    x[2709]   c2565     2
    x[2709]   c885      1
    x[2710]   c886_1    1
    x[2710]   c2566     2
    x[2710]   c886      1
    x[2711]   c887_1    1
    x[2711]   c2567     2
    x[2711]   c887      1
    x[2712]   c888_1    1
    x[2712]   c2568     2
    x[2712]   c888      1
    x[2713]   c889_1    1
    x[2713]   c2569     2
    x[2713]   c889      1
    x[2714]   c890_1    1
    x[2714]   c2570     2
    x[2714]   c890      1
    x[2715]   c891_1    1
    x[2715]   c2571     2
    x[2715]   c891      1
    x[2716]   c892_1    1
    x[2716]   c2572     2
    x[2716]   c892      1
    x[2717]   c893_1    1
    x[2717]   c2573     2
    x[2717]   c893      1
    x[2718]   c894_1    1
    x[2718]   c2574     2
    x[2718]   c894      1
    x[2719]   c895_1    1
    x[2719]   c2575     2
    x[2719]   c895      1
    x[2720]   c896_1    1
    x[2720]   c2576     2
    x[2720]   c896      1
    x[2721]   c897_1    1
    x[2721]   c2561     0.5
    x[2721]   c897      1
    x[2722]   c898_1    1
    x[2722]   c2562     0.5
    x[2722]   c898      1
    x[2723]   c899_1    1
    x[2723]   c2563     0.5
    x[2723]   c899      1
    x[2724]   c900_1    1
    x[2724]   c2564     0.5
    x[2724]   c900      1
    x[2725]   c901_1    1
    x[2725]   c2565     0.5
    x[2725]   c901      1
    x[2726]   c902_1    1
    x[2726]   c2566     0.5
    x[2726]   c902      1
    x[2727]   c903_1    1
    x[2727]   c2567     0.5
    x[2727]   c903      1
    x[2728]   c904_1    1
    x[2728]   c2568     0.5
    x[2728]   c904      1
    x[2729]   c905_1    1
    x[2729]   c2569     0.5
    x[2729]   c905      1
    x[2730]   c906_1    1
    x[2730]   c2570     0.5
    x[2730]   c906      1
    x[2731]   c907_1    1
    x[2731]   c2571     0.5
    x[2731]   c907      1
    x[2732]   c908_1    1
    x[2732]   c2572     0.5
    x[2732]   c908      1
    x[2733]   c909_1    1
    x[2733]   c2573     0.5
    x[2733]   c909      1
    x[2734]   c910_1    1
    x[2734]   c2574     0.5
    x[2734]   c910      1
    x[2735]   c911_1    1
    x[2735]   c2575     0.5
    x[2735]   c911      1
    x[2736]   c912_1    1
    x[2736]   c2576     0.5
    x[2736]   c912      1
    x[2737]   c913_1    1
    x[2737]   c2561     3.5
    x[2737]   c913      1
    x[2738]   c914_1    1
    x[2738]   c2562     3.5
    x[2738]   c914      1
    x[2739]   c915_1    1
    x[2739]   c2563     3.5
    x[2739]   c915      1
    x[2740]   c916_1    1
    x[2740]   c2564     3.5
    x[2740]   c916      1
    x[2741]   c917_1    1
    x[2741]   c2565     3.5
    x[2741]   c917      1
    x[2742]   c918_1    1
    x[2742]   c2566     3.5
    x[2742]   c918      1
    x[2743]   c919_1    1
    x[2743]   c2567     3.5
    x[2743]   c919      1
    x[2744]   c920_1    1
    x[2744]   c2568     3.5
    x[2744]   c920      1
    x[2745]   c921_1    1
    x[2745]   c2569     3.5
    x[2745]   c921      1
    x[2746]   c922_1    1
    x[2746]   c2570     3.5
    x[2746]   c922      1
    x[2747]   c923_1    1
    x[2747]   c2571     3.5
    x[2747]   c923      1
    x[2748]   c924_1    1
    x[2748]   c2572     3.5
    x[2748]   c924      1
    x[2749]   c925_1    1
    x[2749]   c2573     3.5
    x[2749]   c925      1
    x[2750]   c926_1    1
    x[2750]   c2574     3.5
    x[2750]   c926      1
    x[2751]   c927_1    1
    x[2751]   c2575     3.5
    x[2751]   c927      1
    x[2752]   c928_1    1
    x[2752]   c2576     3.5
    x[2752]   c928      1
    x[2753]   c929_1    1
    x[2753]   c2561     0.5
    x[2753]   c929      1
    x[2754]   c930_1    1
    x[2754]   c2562     0.5
    x[2754]   c930      1
    x[2755]   c931_1    1
    x[2755]   c2563     0.5
    x[2755]   c931      1
    x[2756]   c932_1    1
    x[2756]   c2564     0.5
    x[2756]   c932      1
    x[2757]   c933_1    1
    x[2757]   c2565     0.5
    x[2757]   c933      1
    x[2758]   c934_1    1
    x[2758]   c2566     0.5
    x[2758]   c934      1
    x[2759]   c935_1    1
    x[2759]   c2567     0.5
    x[2759]   c935      1
    x[2760]   c936_1    1
    x[2760]   c2568     0.5
    x[2760]   c936      1
    x[2761]   c937_1    1
    x[2761]   c2569     0.5
    x[2761]   c937      1
    x[2762]   c938_1    1
    x[2762]   c2570     0.5
    x[2762]   c938      1
    x[2763]   c939_1    1
    x[2763]   c2571     0.5
    x[2763]   c939      1
    x[2764]   c940_1    1
    x[2764]   c2572     0.5
    x[2764]   c940      1
    x[2765]   c941_1    1
    x[2765]   c2573     0.5
    x[2765]   c941      1
    x[2766]   c942_1    1
    x[2766]   c2574     0.5
    x[2766]   c942      1
    x[2767]   c943_1    1
    x[2767]   c2575     0.5
    x[2767]   c943      1
    x[2768]   c944_1    1
    x[2768]   c2576     0.5
    x[2768]   c944      1
    x[2769]   c945_1    1
    x[2769]   c2561     3.5
    x[2769]   c945      1
    x[2770]   c946_1    1
    x[2770]   c2562     3.5
    x[2770]   c946      1
    x[2771]   c947_1    1
    x[2771]   c2563     3.5
    x[2771]   c947      1
    x[2772]   c948_1    1
    x[2772]   c2564     3.5
    x[2772]   c948      1
    x[2773]   c949_1    1
    x[2773]   c2565     3.5
    x[2773]   c949      1
    x[2774]   c950_1    1
    x[2774]   c2566     3.5
    x[2774]   c950      1
    x[2775]   c951_1    1
    x[2775]   c2567     3.5
    x[2775]   c951      1
    x[2776]   c952_1    1
    x[2776]   c2568     3.5
    x[2776]   c952      1
    x[2777]   c953_1    1
    x[2777]   c2569     3.5
    x[2777]   c953      1
    x[2778]   c954_1    1
    x[2778]   c2570     3.5
    x[2778]   c954      1
    x[2779]   c955_1    1
    x[2779]   c2571     3.5
    x[2779]   c955      1
    x[2780]   c956_1    1
    x[2780]   c2572     3.5
    x[2780]   c956      1
    x[2781]   c957_1    1
    x[2781]   c2573     3.5
    x[2781]   c957      1
    x[2782]   c958_1    1
    x[2782]   c2574     3.5
    x[2782]   c958      1
    x[2783]   c959_1    1
    x[2783]   c2575     3.5
    x[2783]   c959      1
    x[2784]   c960_1    1
    x[2784]   c2576     3.5
    x[2784]   c960      1
    x[2785]   c961_1    1
    x[2785]   c2561     0.2
    x[2785]   c961      1
    x[2786]   c962_1    1
    x[2786]   c2562     0.2
    x[2786]   c962      1
    x[2787]   c963_1    1
    x[2787]   c2563     0.2
    x[2787]   c963      1
    x[2788]   c964_1    1
    x[2788]   c2564     0.2
    x[2788]   c964      1
    x[2789]   c965_1    1
    x[2789]   c2565     0.2
    x[2789]   c965      1
    x[2790]   c966_1    1
    x[2790]   c2566     0.2
    x[2790]   c966      1
    x[2791]   c967_1    1
    x[2791]   c2567     0.2
    x[2791]   c967      1
    x[2792]   c968_1    1
    x[2792]   c2568     0.2
    x[2792]   c968      1
    x[2793]   c969_1    1
    x[2793]   c2569     0.2
    x[2793]   c969      1
    x[2794]   c970_1    1
    x[2794]   c2570     0.2
    x[2794]   c970      1
    x[2795]   c971_1    1
    x[2795]   c2571     0.2
    x[2795]   c971      1
    x[2796]   c972_1    1
    x[2796]   c2572     0.2
    x[2796]   c972      1
    x[2797]   c973_1    1
    x[2797]   c2573     0.2
    x[2797]   c973      1
    x[2798]   c974_1    1
    x[2798]   c2574     0.2
    x[2798]   c974      1
    x[2799]   c975_1    1
    x[2799]   c2575     0.2
    x[2799]   c975      1
    x[2800]   c976_1    1
    x[2800]   c2576     0.2
    x[2800]   c976      1
    x[2801]   c977_1    1
    x[2801]   c2561     2.5
    x[2801]   c977      1
    x[2802]   c978_1    1
    x[2802]   c2562     2.5
    x[2802]   c978      1
    x[2803]   c979_1    1
    x[2803]   c2563     2.5
    x[2803]   c979      1
    x[2804]   c980_1    1
    x[2804]   c2564     2.5
    x[2804]   c980      1
    x[2805]   c981_1    1
    x[2805]   c2565     2.5
    x[2805]   c981      1
    x[2806]   c982_1    1
    x[2806]   c2566     2.5
    x[2806]   c982      1
    x[2807]   c983_1    1
    x[2807]   c2567     2.5
    x[2807]   c983      1
    x[2808]   c984_1    1
    x[2808]   c2568     2.5
    x[2808]   c984      1
    x[2809]   c985_1    1
    x[2809]   c2569     2.5
    x[2809]   c985      1
    x[2810]   c986_1    1
    x[2810]   c2570     2.5
    x[2810]   c986      1
    x[2811]   c987_1    1
    x[2811]   c2571     2.5
    x[2811]   c987      1
    x[2812]   c988_1    1
    x[2812]   c2572     2.5
    x[2812]   c988      1
    x[2813]   c989_1    1
    x[2813]   c2573     2.5
    x[2813]   c989      1
    x[2814]   c990_1    1
    x[2814]   c2574     2.5
    x[2814]   c990      1
    x[2815]   c991_1    1
    x[2815]   c2575     2.5
    x[2815]   c991      1
    x[2816]   c992_1    1
    x[2816]   c2576     2.5
    x[2816]   c992      1
    x[2817]   c993_1    1
    x[2817]   c2561     0.2
    x[2817]   c993      1
    x[2818]   c994_1    1
    x[2818]   c2562     0.2
    x[2818]   c994      1
    x[2819]   c995_1    1
    x[2819]   c2563     0.2
    x[2819]   c995      1
    x[2820]   c996_1    1
    x[2820]   c2564     0.2
    x[2820]   c996      1
    x[2821]   c997_1    1
    x[2821]   c2565     0.2
    x[2821]   c997      1
    x[2822]   c998_1    1
    x[2822]   c2566     0.2
    x[2822]   c998      1
    x[2823]   c999_1    1
    x[2823]   c2567     0.2
    x[2823]   c999      1
    x[2824]   c1000_1   1
    x[2824]   c2568     0.2
    x[2824]   c1000     1
    x[2825]   c1001_1   1
    x[2825]   c2569     0.2
    x[2825]   c1001     1
    x[2826]   c1002_1   1
    x[2826]   c2570     0.2
    x[2826]   c1002     1
    x[2827]   c1003_1   1
    x[2827]   c2571     0.2
    x[2827]   c1003     1
    x[2828]   c1004_1   1
    x[2828]   c2572     0.2
    x[2828]   c1004     1
    x[2829]   c1005_1   1
    x[2829]   c2573     0.2
    x[2829]   c1005     1
    x[2830]   c1006_1   1
    x[2830]   c2574     0.2
    x[2830]   c1006     1
    x[2831]   c1007_1   1
    x[2831]   c2575     0.2
    x[2831]   c1007     1
    x[2832]   c1008_1   1
    x[2832]   c2576     0.2
    x[2832]   c1008     1
    x[2833]   c1009_1   1
    x[2833]   c2561     2.5
    x[2833]   c1009     1
    x[2834]   c1010_1   1
    x[2834]   c2562     2.5
    x[2834]   c1010     1
    x[2835]   c1011_1   1
    x[2835]   c2563     2.5
    x[2835]   c1011     1
    x[2836]   c1012_1   1
    x[2836]   c2564     2.5
    x[2836]   c1012     1
    x[2837]   c1013_1   1
    x[2837]   c2565     2.5
    x[2837]   c1013     1
    x[2838]   c1014_1   1
    x[2838]   c2566     2.5
    x[2838]   c1014     1
    x[2839]   c1015_1   1
    x[2839]   c2567     2.5
    x[2839]   c1015     1
    x[2840]   c1016_1   1
    x[2840]   c2568     2.5
    x[2840]   c1016     1
    x[2841]   c1017_1   1
    x[2841]   c2569     2.5
    x[2841]   c1017     1
    x[2842]   c1018_1   1
    x[2842]   c2570     2.5
    x[2842]   c1018     1
    x[2843]   c1019_1   1
    x[2843]   c2571     2.5
    x[2843]   c1019     1
    x[2844]   c1020_1   1
    x[2844]   c2572     2.5
    x[2844]   c1020     1
    x[2845]   c1021_1   1
    x[2845]   c2573     2.5
    x[2845]   c1021     1
    x[2846]   c1022_1   1
    x[2846]   c2574     2.5
    x[2846]   c1022     1
    x[2847]   c1023_1   1
    x[2847]   c2575     2.5
    x[2847]   c1023     1
    x[2848]   c1024_1   1
    x[2848]   c2576     2.5
    x[2848]   c1024     1
    x[2849]   c1_1      -480
    x[2849]   c1025_1   1
    x[2850]   c2_1      -480
    x[2850]   c1026_1   1
    x[2851]   c3_1      -480
    x[2851]   c1027_1   1
    x[2852]   c4_1      -480
    x[2852]   c1028_1   1
    x[2853]   c5_1      -480
    x[2853]   c1029_1   1
    x[2854]   c6_1      -480
    x[2854]   c1030_1   1
    x[2855]   c7_1      -480
    x[2855]   c1031_1   1
    x[2856]   c8_1      -480
    x[2856]   c1032_1   1
    x[2857]   c9_1      -480
    x[2857]   c1033_1   1
    x[2858]   c10_1     -480
    x[2858]   c1034_1   1
    x[2859]   c11_1     -480
    x[2859]   c1035_1   1
    x[2860]   c12_1     -480
    x[2860]   c1036_1   1
    x[2861]   c13_1     -480
    x[2861]   c1037_1   1
    x[2862]   c14_1     -480
    x[2862]   c1038_1   1
    x[2863]   c15_1     -480
    x[2863]   c1039_1   1
    x[2864]   c16_1     -480
    x[2864]   c1040_1   1
    x[2865]   c17_1     -480
    x[2865]   c1041_1   1
    x[2866]   c18_1     -480
    x[2866]   c1042_1   1
    x[2867]   c19_1     -480
    x[2867]   c1043_1   1
    x[2868]   c20_1     -480
    x[2868]   c1044_1   1
    x[2869]   c21_1     -480
    x[2869]   c1045_1   1
    x[2870]   c22_1     -480
    x[2870]   c1046_1   1
    x[2871]   c23_1     -480
    x[2871]   c1047_1   1
    x[2872]   c24_1     -480
    x[2872]   c1048_1   1
    x[2873]   c25_1     -480
    x[2873]   c1049_1   1
    x[2874]   c26_1     -480
    x[2874]   c1050_1   1
    x[2875]   c27_1     -480
    x[2875]   c1051_1   1
    x[2876]   c28_1     -480
    x[2876]   c1052_1   1
    x[2877]   c29_1     -480
    x[2877]   c1053_1   1
    x[2878]   c30_1     -480
    x[2878]   c1054_1   1
    x[2879]   c31_1     -480
    x[2879]   c1055_1   1
    x[2880]   c32_1     -480
    x[2880]   c1056_1   1
    x[2881]   c33_1     -480
    x[2881]   c1057_1   1
    x[2882]   c34_1     -480
    x[2882]   c1058_1   1
    x[2883]   c35_1     -480
    x[2883]   c1059_1   1
    x[2884]   c36_1     -480
    x[2884]   c1060_1   1
    x[2885]   c37_1     -480
    x[2885]   c1061_1   1
    x[2886]   c38_1     -480
    x[2886]   c1062_1   1
    x[2887]   c39_1     -480
    x[2887]   c1063_1   1
    x[2888]   c40_1     -480
    x[2888]   c1064_1   1
    x[2889]   c41_1     -480
    x[2889]   c1065_1   1
    x[2890]   c42_1     -480
    x[2890]   c1066_1   1
    x[2891]   c43_1     -480
    x[2891]   c1067_1   1
    x[2892]   c44_1     -480
    x[2892]   c1068_1   1
    x[2893]   c45_1     -480
    x[2893]   c1069_1   1
    x[2894]   c46_1     -480
    x[2894]   c1070_1   1
    x[2895]   c47_1     -480
    x[2895]   c1071_1   1
    x[2896]   c48_1     -480
    x[2896]   c1072_1   1
    x[2897]   c49_1     -480
    x[2897]   c1073_1   1
    x[2898]   c50_1     -480
    x[2898]   c1074_1   1
    x[2899]   c51_1     -480
    x[2899]   c1075_1   1
    x[2900]   c52_1     -480
    x[2900]   c1076_1   1
    x[2901]   c53_1     -480
    x[2901]   c1077_1   1
    x[2902]   c54_1     -480
    x[2902]   c1078_1   1
    x[2903]   c55_1     -480
    x[2903]   c1079_1   1
    x[2904]   c56_1     -480
    x[2904]   c1080_1   1
    x[2905]   c57_1     -480
    x[2905]   c1081_1   1
    x[2906]   c58_1     -480
    x[2906]   c1082_1   1
    x[2907]   c59_1     -480
    x[2907]   c1083_1   1
    x[2908]   c60_1     -480
    x[2908]   c1084_1   1
    x[2909]   c61_1     -480
    x[2909]   c1085_1   1
    x[2910]   c62_1     -480
    x[2910]   c1086_1   1
    x[2911]   c63_1     -480
    x[2911]   c1087_1   1
    x[2912]   c64_1     -480
    x[2912]   c1088_1   1
    x[2913]   c65_1     -480
    x[2913]   c1089_1   1
    x[2914]   c66_1     -480
    x[2914]   c1090_1   1
    x[2915]   c67_1     -480
    x[2915]   c1091_1   1
    x[2916]   c68_1     -480
    x[2916]   c1092_1   1
    x[2917]   c69_1     -480
    x[2917]   c1093_1   1
    x[2918]   c70_1     -480
    x[2918]   c1094_1   1
    x[2919]   c71_1     -480
    x[2919]   c1095_1   1
    x[2920]   c72_1     -480
    x[2920]   c1096_1   1
    x[2921]   c73_1     -480
    x[2921]   c1097_1   1
    x[2922]   c74_1     -480
    x[2922]   c1098_1   1
    x[2923]   c75_1     -480
    x[2923]   c1099_1   1
    x[2924]   c76_1     -480
    x[2924]   c1100_1   1
    x[2925]   c77_1     -480
    x[2925]   c1101_1   1
    x[2926]   c78_1     -480
    x[2926]   c1102_1   1
    x[2927]   c79_1     -480
    x[2927]   c1103_1   1
    x[2928]   c80_1     -480
    x[2928]   c1104_1   1
    x[2929]   c81_1     -480
    x[2929]   c1105_1   1
    x[2930]   c82_1     -480
    x[2930]   c1106_1   1
    x[2931]   c83_1     -480
    x[2931]   c1107_1   1
    x[2932]   c84_1     -480
    x[2932]   c1108_1   1
    x[2933]   c85_1     -480
    x[2933]   c1109_1   1
    x[2934]   c86_1     -480
    x[2934]   c1110_1   1
    x[2935]   c87_1     -480
    x[2935]   c1111_1   1
    x[2936]   c88_1     -480
    x[2936]   c1112_1   1
    x[2937]   c89_1     -480
    x[2937]   c1113_1   1
    x[2938]   c90_1     -480
    x[2938]   c1114_1   1
    x[2939]   c91_1     -480
    x[2939]   c1115_1   1
    x[2940]   c92_1     -480
    x[2940]   c1116_1   1
    x[2941]   c93_1     -480
    x[2941]   c1117_1   1
    x[2942]   c94_1     -480
    x[2942]   c1118_1   1
    x[2943]   c95_1     -480
    x[2943]   c1119_1   1
    x[2944]   c96_1     -480
    x[2944]   c1120_1   1
    x[2945]   c97_1     -480
    x[2945]   c1121_1   1
    x[2946]   c98_1     -480
    x[2946]   c1122_1   1
    x[2947]   c99_1     -480
    x[2947]   c1123_1   1
    x[2948]   c100_1    -480
    x[2948]   c1124_1   1
    x[2949]   c101_1    -480
    x[2949]   c1125_1   1
    x[2950]   c102_1    -480
    x[2950]   c1126_1   1
    x[2951]   c103_1    -480
    x[2951]   c1127_1   1
    x[2952]   c104_1    -480
    x[2952]   c1128_1   1
    x[2953]   c105_1    -480
    x[2953]   c1129_1   1
    x[2954]   c106_1    -480
    x[2954]   c1130_1   1
    x[2955]   c107_1    -480
    x[2955]   c1131_1   1
    x[2956]   c108_1    -480
    x[2956]   c1132_1   1
    x[2957]   c109_1    -480
    x[2957]   c1133_1   1
    x[2958]   c110_1    -480
    x[2958]   c1134_1   1
    x[2959]   c111_1    -480
    x[2959]   c1135_1   1
    x[2960]   c112_1    -480
    x[2960]   c1136_1   1
    x[2961]   c113_1    -480
    x[2961]   c1137_1   1
    x[2962]   c114_1    -480
    x[2962]   c1138_1   1
    x[2963]   c115_1    -480
    x[2963]   c1139_1   1
    x[2964]   c116_1    -480
    x[2964]   c1140_1   1
    x[2965]   c117_1    -480
    x[2965]   c1141_1   1
    x[2966]   c118_1    -480
    x[2966]   c1142_1   1
    x[2967]   c119_1    -480
    x[2967]   c1143_1   1
    x[2968]   c120_1    -480
    x[2968]   c1144_1   1
    x[2969]   c121_1    -480
    x[2969]   c1145_1   1
    x[2970]   c122_1    -480
    x[2970]   c1146_1   1
    x[2971]   c123_1    -480
    x[2971]   c1147_1   1
    x[2972]   c124_1    -480
    x[2972]   c1148_1   1
    x[2973]   c125_1    -480
    x[2973]   c1149_1   1
    x[2974]   c126_1    -480
    x[2974]   c1150_1   1
    x[2975]   c127_1    -480
    x[2975]   c1151_1   1
    x[2976]   c128_1    -480
    x[2976]   c1152_1   1
    x[2977]   c129_1    -480
    x[2977]   c1153_1   1
    x[2978]   c130_1    -480
    x[2978]   c1154_1   1
    x[2979]   c131_1    -480
    x[2979]   c1155_1   1
    x[2980]   c132_1    -480
    x[2980]   c1156_1   1
    x[2981]   c133_1    -480
    x[2981]   c1157_1   1
    x[2982]   c134_1    -480
    x[2982]   c1158_1   1
    x[2983]   c135_1    -480
    x[2983]   c1159_1   1
    x[2984]   c136_1    -480
    x[2984]   c1160_1   1
    x[2985]   c137_1    -480
    x[2985]   c1161_1   1
    x[2986]   c138_1    -480
    x[2986]   c1162_1   1
    x[2987]   c139_1    -480
    x[2987]   c1163_1   1
    x[2988]   c140_1    -480
    x[2988]   c1164_1   1
    x[2989]   c141_1    -480
    x[2989]   c1165_1   1
    x[2990]   c142_1    -480
    x[2990]   c1166_1   1
    x[2991]   c143_1    -480
    x[2991]   c1167_1   1
    x[2992]   c144_1    -480
    x[2992]   c1168_1   1
    x[2993]   c145_1    -480
    x[2993]   c1169_1   1
    x[2994]   c146_1    -480
    x[2994]   c1170_1   1
    x[2995]   c147_1    -480
    x[2995]   c1171_1   1
    x[2996]   c148_1    -480
    x[2996]   c1172_1   1
    x[2997]   c149_1    -480
    x[2997]   c1173_1   1
    x[2998]   c150_1    -480
    x[2998]   c1174_1   1
    x[2999]   c151_1    -480
    x[2999]   c1175_1   1
    x[3000]   c152_1    -480
    x[3000]   c1176_1   1
    x[3001]   c153_1    -480
    x[3001]   c1177_1   1
    x[3002]   c154_1    -480
    x[3002]   c1178_1   1
    x[3003]   c155_1    -480
    x[3003]   c1179_1   1
    x[3004]   c156_1    -480
    x[3004]   c1180_1   1
    x[3005]   c157_1    -480
    x[3005]   c1181_1   1
    x[3006]   c158_1    -480
    x[3006]   c1182_1   1
    x[3007]   c159_1    -480
    x[3007]   c1183_1   1
    x[3008]   c160_1    -480
    x[3008]   c1184_1   1
    x[3009]   c161_1    -480
    x[3009]   c1185_1   1
    x[3010]   c162_1    -480
    x[3010]   c1186_1   1
    x[3011]   c163_1    -480
    x[3011]   c1187_1   1
    x[3012]   c164_1    -480
    x[3012]   c1188_1   1
    x[3013]   c165_1    -480
    x[3013]   c1189_1   1
    x[3014]   c166_1    -480
    x[3014]   c1190_1   1
    x[3015]   c167_1    -480
    x[3015]   c1191_1   1
    x[3016]   c168_1    -480
    x[3016]   c1192_1   1
    x[3017]   c169_1    -480
    x[3017]   c1193_1   1
    x[3018]   c170_1    -480
    x[3018]   c1194_1   1
    x[3019]   c171_1    -480
    x[3019]   c1195_1   1
    x[3020]   c172_1    -480
    x[3020]   c1196_1   1
    x[3021]   c173_1    -480
    x[3021]   c1197_1   1
    x[3022]   c174_1    -480
    x[3022]   c1198_1   1
    x[3023]   c175_1    -480
    x[3023]   c1199_1   1
    x[3024]   c176_1    -480
    x[3024]   c1200_1   1
    x[3025]   c177_1    -480
    x[3025]   c1201_1   1
    x[3026]   c178_1    -480
    x[3026]   c1202_1   1
    x[3027]   c179_1    -480
    x[3027]   c1203_1   1
    x[3028]   c180_1    -480
    x[3028]   c1204_1   1
    x[3029]   c181_1    -480
    x[3029]   c1205_1   1
    x[3030]   c182_1    -480
    x[3030]   c1206_1   1
    x[3031]   c183_1    -480
    x[3031]   c1207_1   1
    x[3032]   c184_1    -480
    x[3032]   c1208_1   1
    x[3033]   c185_1    -480
    x[3033]   c1209_1   1
    x[3034]   c186_1    -480
    x[3034]   c1210_1   1
    x[3035]   c187_1    -480
    x[3035]   c1211_1   1
    x[3036]   c188_1    -480
    x[3036]   c1212_1   1
    x[3037]   c189_1    -480
    x[3037]   c1213_1   1
    x[3038]   c190_1    -480
    x[3038]   c1214_1   1
    x[3039]   c191_1    -480
    x[3039]   c1215_1   1
    x[3040]   c192_1    -480
    x[3040]   c1216_1   1
    x[3041]   c193_1    -480
    x[3041]   c1217_1   1
    x[3042]   c194_1    -480
    x[3042]   c1218_1   1
    x[3043]   c195_1    -480
    x[3043]   c1219_1   1
    x[3044]   c196_1    -480
    x[3044]   c1220_1   1
    x[3045]   c197_1    -480
    x[3045]   c1221_1   1
    x[3046]   c198_1    -480
    x[3046]   c1222_1   1
    x[3047]   c199_1    -480
    x[3047]   c1223_1   1
    x[3048]   c200_1    -480
    x[3048]   c1224_1   1
    x[3049]   c201_1    -480
    x[3049]   c1225_1   1
    x[3050]   c202_1    -480
    x[3050]   c1226_1   1
    x[3051]   c203_1    -480
    x[3051]   c1227_1   1
    x[3052]   c204_1    -480
    x[3052]   c1228_1   1
    x[3053]   c205_1    -480
    x[3053]   c1229_1   1
    x[3054]   c206_1    -480
    x[3054]   c1230_1   1
    x[3055]   c207_1    -480
    x[3055]   c1231_1   1
    x[3056]   c208_1    -480
    x[3056]   c1232_1   1
    x[3057]   c209_1    -480
    x[3057]   c1233_1   1
    x[3058]   c210_1    -480
    x[3058]   c1234_1   1
    x[3059]   c211_1    -480
    x[3059]   c1235_1   1
    x[3060]   c212_1    -480
    x[3060]   c1236_1   1
    x[3061]   c213_1    -480
    x[3061]   c1237_1   1
    x[3062]   c214_1    -480
    x[3062]   c1238_1   1
    x[3063]   c215_1    -480
    x[3063]   c1239_1   1
    x[3064]   c216_1    -480
    x[3064]   c1240_1   1
    x[3065]   c217_1    -480
    x[3065]   c1241_1   1
    x[3066]   c218_1    -480
    x[3066]   c1242_1   1
    x[3067]   c219_1    -480
    x[3067]   c1243_1   1
    x[3068]   c220_1    -480
    x[3068]   c1244_1   1
    x[3069]   c221_1    -480
    x[3069]   c1245_1   1
    x[3070]   c222_1    -480
    x[3070]   c1246_1   1
    x[3071]   c223_1    -480
    x[3071]   c1247_1   1
    x[3072]   c224_1    -480
    x[3072]   c1248_1   1
    x[3073]   c225_1    -480
    x[3073]   c1249_1   1
    x[3074]   c226_1    -480
    x[3074]   c1250_1   1
    x[3075]   c227_1    -480
    x[3075]   c1251_1   1
    x[3076]   c228_1    -480
    x[3076]   c1252_1   1
    x[3077]   c229_1    -480
    x[3077]   c1253_1   1
    x[3078]   c230_1    -480
    x[3078]   c1254_1   1
    x[3079]   c231_1    -480
    x[3079]   c1255_1   1
    x[3080]   c232_1    -480
    x[3080]   c1256_1   1
    x[3081]   c233_1    -480
    x[3081]   c1257_1   1
    x[3082]   c234_1    -480
    x[3082]   c1258_1   1
    x[3083]   c235_1    -480
    x[3083]   c1259_1   1
    x[3084]   c236_1    -480
    x[3084]   c1260_1   1
    x[3085]   c237_1    -480
    x[3085]   c1261_1   1
    x[3086]   c238_1    -480
    x[3086]   c1262_1   1
    x[3087]   c239_1    -480
    x[3087]   c1263_1   1
    x[3088]   c240_1    -480
    x[3088]   c1264_1   1
    x[3089]   c241_1    -480
    x[3089]   c1265_1   1
    x[3090]   c242_1    -480
    x[3090]   c1266_1   1
    x[3091]   c243_1    -480
    x[3091]   c1267_1   1
    x[3092]   c244_1    -480
    x[3092]   c1268_1   1
    x[3093]   c245_1    -480
    x[3093]   c1269_1   1
    x[3094]   c246_1    -480
    x[3094]   c1270_1   1
    x[3095]   c247_1    -480
    x[3095]   c1271_1   1
    x[3096]   c248_1    -480
    x[3096]   c1272_1   1
    x[3097]   c249_1    -480
    x[3097]   c1273_1   1
    x[3098]   c250_1    -480
    x[3098]   c1274_1   1
    x[3099]   c251_1    -480
    x[3099]   c1275_1   1
    x[3100]   c252_1    -480
    x[3100]   c1276_1   1
    x[3101]   c253_1    -480
    x[3101]   c1277_1   1
    x[3102]   c254_1    -480
    x[3102]   c1278_1   1
    x[3103]   c255_1    -480
    x[3103]   c1279_1   1
    x[3104]   c256_1    -480
    x[3104]   c1280_1   1
    x[3105]   c257_1    -480
    x[3105]   c1281_1   1
    x[3105]   c1297_1   1
    x[3105]   c1313_1   1
    x[3106]   c258_1    -480
    x[3106]   c1282_1   1
    x[3106]   c1298_1   1
    x[3106]   c1314_1   1
    x[3107]   c259_1    -480
    x[3107]   c1283_1   1
    x[3107]   c1299_1   1
    x[3107]   c1315_1   1
    x[3108]   c260_1    -480
    x[3108]   c1284_1   1
    x[3108]   c1300_1   1
    x[3108]   c1316_1   1
    x[3109]   c261_1    -480
    x[3109]   c1285_1   1
    x[3109]   c1301_1   1
    x[3109]   c1317_1   1
    x[3110]   c262_1    -480
    x[3110]   c1286_1   1
    x[3110]   c1302_1   1
    x[3110]   c1318_1   1
    x[3111]   c263_1    -480
    x[3111]   c1287_1   1
    x[3111]   c1303_1   1
    x[3111]   c1319     1
    x[3112]   c264_1    -480
    x[3112]   c1288_1   1
    x[3112]   c1304_1   1
    x[3112]   c1320     1
    x[3113]   c265_1    -480
    x[3113]   c1289_1   1
    x[3113]   c1305_1   1
    x[3113]   c1321     1
    x[3114]   c266_1    -480
    x[3114]   c1290_1   1
    x[3114]   c1306_1   1
    x[3114]   c1322     1
    x[3115]   c267_1    -480
    x[3115]   c1291_1   1
    x[3115]   c1307_1   1
    x[3115]   c1323     1
    x[3116]   c268_1    -480
    x[3116]   c1292_1   1
    x[3116]   c1308_1   1
    x[3116]   c1324     1
    x[3117]   c269_1    -480
    x[3117]   c1293_1   1
    x[3117]   c1309_1   1
    x[3117]   c1325     1
    x[3118]   c270_1    -480
    x[3118]   c1294_1   1
    x[3118]   c1310_1   1
    x[3118]   c1326     1
    x[3119]   c271_1    -480
    x[3119]   c1295_1   1
    x[3119]   c1311_1   1
    x[3119]   c1327     1
    x[3120]   c272_1    -480
    x[3120]   c1296_1   1
    x[3120]   c1312_1   1
    x[3120]   c1328     1
    x[3121]   c273_1    -480
    x[3121]   c1329     1
    x[3121]   c1345     1
    x[3121]   c1361     1
    x[3122]   c274_1    -480
    x[3122]   c1330     1
    x[3122]   c1346     1
    x[3122]   c1362     1
    x[3123]   c275_1    -480
    x[3123]   c1331     1
    x[3123]   c1347     1
    x[3123]   c1363     1
    x[3124]   c276_1    -480
    x[3124]   c1332     1
    x[3124]   c1348     1
    x[3124]   c1364     1
    x[3125]   c277_1    -480
    x[3125]   c1333     1
    x[3125]   c1349     1
    x[3125]   c1365     1
    x[3126]   c278_1    -480
    x[3126]   c1334     1
    x[3126]   c1350     1
    x[3126]   c1366     1
    x[3127]   c279_1    -480
    x[3127]   c1335     1
    x[3127]   c1351     1
    x[3127]   c1367     1
    x[3128]   c280_1    -480
    x[3128]   c1336     1
    x[3128]   c1352     1
    x[3128]   c1368     1
    x[3129]   c281_1    -480
    x[3129]   c1337     1
    x[3129]   c1353     1
    x[3129]   c1369     1
    x[3130]   c282_1    -480
    x[3130]   c1338     1
    x[3130]   c1354     1
    x[3130]   c1370     1
    x[3131]   c283_1    -480
    x[3131]   c1339     1
    x[3131]   c1355     1
    x[3131]   c1371     1
    x[3132]   c284_1    -480
    x[3132]   c1340     1
    x[3132]   c1356     1
    x[3132]   c1372     1
    x[3133]   c285_1    -480
    x[3133]   c1341     1
    x[3133]   c1357     1
    x[3133]   c1373     1
    x[3134]   c286_1    -480
    x[3134]   c1342     1
    x[3134]   c1358     1
    x[3134]   c1374     1
    x[3135]   c287_1    -480
    x[3135]   c1343     1
    x[3135]   c1359     1
    x[3135]   c1375     1
    x[3136]   c288_1    -480
    x[3136]   c1344     1
    x[3136]   c1360     1
    x[3136]   c1376     1
    x[3137]   c289_1    -480
    x[3137]   c1377     1
    x[3137]   c1393     1
    x[3137]   c1409     1
    x[3138]   c290_1    -480
    x[3138]   c1378     1
    x[3138]   c1394     1
    x[3138]   c1410     1
    x[3139]   c291_1    -480
    x[3139]   c1379     1
    x[3139]   c1395     1
    x[3139]   c1411     1
    x[3140]   c292_1    -480
    x[3140]   c1380     1
    x[3140]   c1396     1
    x[3140]   c1412     1
    x[3141]   c293_1    -480
    x[3141]   c1381     1
    x[3141]   c1397     1
    x[3141]   c1413     1
    x[3142]   c294_1    -480
    x[3142]   c1382     1
    x[3142]   c1398     1
    x[3142]   c1414     1
    x[3143]   c295_1    -480
    x[3143]   c1383     1
    x[3143]   c1399     1
    x[3143]   c1415     1
    x[3144]   c296_1    -480
    x[3144]   c1384     1
    x[3144]   c1400     1
    x[3144]   c1416     1
    x[3145]   c297_1    -480
    x[3145]   c1385     1
    x[3145]   c1401     1
    x[3145]   c1417     1
    x[3146]   c298_1    -480
    x[3146]   c1386     1
    x[3146]   c1402     1
    x[3146]   c1418     1
    x[3147]   c299_1    -480
    x[3147]   c1387     1
    x[3147]   c1403     1
    x[3147]   c1419     1
    x[3148]   c300_1    -480
    x[3148]   c1388     1
    x[3148]   c1404     1
    x[3148]   c1420     1
    x[3149]   c301_1    -480
    x[3149]   c1389     1
    x[3149]   c1405     1
    x[3149]   c1421     1
    x[3150]   c302_1    -480
    x[3150]   c1390     1
    x[3150]   c1406     1
    x[3150]   c1422     1
    x[3151]   c303_1    -480
    x[3151]   c1391     1
    x[3151]   c1407     1
    x[3151]   c1423     1
    x[3152]   c304_1    -480
    x[3152]   c1392     1
    x[3152]   c1408     1
    x[3152]   c1424     1
    x[3153]   c305_1    -480
    x[3153]   c1425     1
    x[3153]   c1441     1
    x[3153]   c1457     1
    x[3154]   c306_1    -480
    x[3154]   c1426     1
    x[3154]   c1442     1
    x[3154]   c1458     1
    x[3155]   c307_1    -480
    x[3155]   c1427     1
    x[3155]   c1443     1
    x[3155]   c1459     1
    x[3156]   c308_1    -480
    x[3156]   c1428     1
    x[3156]   c1444     1
    x[3156]   c1460     1
    x[3157]   c309_1    -480
    x[3157]   c1429     1
    x[3157]   c1445     1
    x[3157]   c1461     1
    x[3158]   c310_1    -480
    x[3158]   c1430     1
    x[3158]   c1446     1
    x[3158]   c1462     1
    x[3159]   c311_1    -480
    x[3159]   c1431     1
    x[3159]   c1447     1
    x[3159]   c1463     1
    x[3160]   c312_1    -480
    x[3160]   c1432     1
    x[3160]   c1448     1
    x[3160]   c1464     1
    x[3161]   c313_1    -480
    x[3161]   c1433     1
    x[3161]   c1449     1
    x[3161]   c1465     1
    x[3162]   c314_1    -480
    x[3162]   c1434     1
    x[3162]   c1450     1
    x[3162]   c1466     1
    x[3163]   c315_1    -480
    x[3163]   c1435     1
    x[3163]   c1451     1
    x[3163]   c1467     1
    x[3164]   c316_1    -480
    x[3164]   c1436     1
    x[3164]   c1452     1
    x[3164]   c1468     1
    x[3165]   c317_1    -480
    x[3165]   c1437     1
    x[3165]   c1453     1
    x[3165]   c1469     1
    x[3166]   c318_1    -480
    x[3166]   c1438     1
    x[3166]   c1454     1
    x[3166]   c1470     1
    x[3167]   c319_1    -480
    x[3167]   c1439     1
    x[3167]   c1455     1
    x[3167]   c1471     1
    x[3168]   c320_1    -480
    x[3168]   c1440     1
    x[3168]   c1456     1
    x[3168]   c1472     1
    x[3169]   c321_1    -480
    x[3169]   c1473     1
    x[3169]   c1489     1
    x[3169]   c1505     1
    x[3170]   c322_1    -480
    x[3170]   c1474     1
    x[3170]   c1490     1
    x[3170]   c1506     1
    x[3171]   c323_1    -480
    x[3171]   c1475     1
    x[3171]   c1491     1
    x[3171]   c1507     1
    x[3172]   c324_1    -480
    x[3172]   c1476     1
    x[3172]   c1492     1
    x[3172]   c1508     1
    x[3173]   c325_1    -480
    x[3173]   c1477     1
    x[3173]   c1493     1
    x[3173]   c1509     1
    x[3174]   c326_1    -480
    x[3174]   c1478     1
    x[3174]   c1494     1
    x[3174]   c1510     1
    x[3175]   c327_1    -480
    x[3175]   c1479     1
    x[3175]   c1495     1
    x[3175]   c1511     1
    x[3176]   c328_1    -480
    x[3176]   c1480     1
    x[3176]   c1496     1
    x[3176]   c1512     1
    x[3177]   c329_1    -480
    x[3177]   c1481     1
    x[3177]   c1497     1
    x[3177]   c1513     1
    x[3178]   c330_1    -480
    x[3178]   c1482     1
    x[3178]   c1498     1
    x[3178]   c1514     1
    x[3179]   c331_1    -480
    x[3179]   c1483     1
    x[3179]   c1499     1
    x[3179]   c1515     1
    x[3180]   c332_1    -480
    x[3180]   c1484     1
    x[3180]   c1500     1
    x[3180]   c1516     1
    x[3181]   c333_1    -480
    x[3181]   c1485     1
    x[3181]   c1501     1
    x[3181]   c1517     1
    x[3182]   c334_1    -480
    x[3182]   c1486     1
    x[3182]   c1502     1
    x[3182]   c1518     1
    x[3183]   c335_1    -480
    x[3183]   c1487     1
    x[3183]   c1503     1
    x[3183]   c1519     1
    x[3184]   c336_1    -480
    x[3184]   c1488     1
    x[3184]   c1504     1
    x[3184]   c1520     1
    x[3185]   c337_1    -480
    x[3185]   c1521     1
    x[3185]   c1537     1
    x[3185]   c1553     1
    x[3186]   c338_1    -480
    x[3186]   c1522     1
    x[3186]   c1538     1
    x[3186]   c1554     1
    x[3187]   c339_1    -480
    x[3187]   c1523     1
    x[3187]   c1539     1
    x[3187]   c1555     1
    x[3188]   c340_1    -480
    x[3188]   c1524     1
    x[3188]   c1540     1
    x[3188]   c1556     1
    x[3189]   c341_1    -480
    x[3189]   c1525     1
    x[3189]   c1541     1
    x[3189]   c1557     1
    x[3190]   c342_1    -480
    x[3190]   c1526     1
    x[3190]   c1542     1
    x[3190]   c1558     1
    x[3191]   c343_1    -480
    x[3191]   c1527     1
    x[3191]   c1543     1
    x[3191]   c1559     1
    x[3192]   c344_1    -480
    x[3192]   c1528     1
    x[3192]   c1544     1
    x[3192]   c1560     1
    x[3193]   c345_1    -480
    x[3193]   c1529     1
    x[3193]   c1545     1
    x[3193]   c1561     1
    x[3194]   c346_1    -480
    x[3194]   c1530     1
    x[3194]   c1546     1
    x[3194]   c1562     1
    x[3195]   c347_1    -480
    x[3195]   c1531     1
    x[3195]   c1547     1
    x[3195]   c1563     1
    x[3196]   c348_1    -480
    x[3196]   c1532     1
    x[3196]   c1548     1
    x[3196]   c1564     1
    x[3197]   c349_1    -480
    x[3197]   c1533     1
    x[3197]   c1549     1
    x[3197]   c1565     1
    x[3198]   c350_1    -480
    x[3198]   c1534     1
    x[3198]   c1550     1
    x[3198]   c1566     1
    x[3199]   c351_1    -480
    x[3199]   c1535     1
    x[3199]   c1551     1
    x[3199]   c1567     1
    x[3200]   c352_1    -480
    x[3200]   c1536     1
    x[3200]   c1552     1
    x[3200]   c1568     1
    x[3201]   c353_1    -480
    x[3201]   c1569     1
    x[3201]   c1585     1
    x[3201]   c1601     1
    x[3202]   c354_1    -480
    x[3202]   c1570     1
    x[3202]   c1586     1
    x[3202]   c1602     1
    x[3203]   c355_1    -480
    x[3203]   c1571     1
    x[3203]   c1587     1
    x[3203]   c1603     1
    x[3204]   c356_1    -480
    x[3204]   c1572     1
    x[3204]   c1588     1
    x[3204]   c1604     1
    x[3205]   c357_1    -480
    x[3205]   c1573     1
    x[3205]   c1589     1
    x[3205]   c1605     1
    x[3206]   c358_1    -480
    x[3206]   c1574     1
    x[3206]   c1590     1
    x[3206]   c1606     1
    x[3207]   c359_1    -480
    x[3207]   c1575     1
    x[3207]   c1591     1
    x[3207]   c1607     1
    x[3208]   c360_1    -480
    x[3208]   c1576     1
    x[3208]   c1592     1
    x[3208]   c1608     1
    x[3209]   c361_1    -480
    x[3209]   c1577     1
    x[3209]   c1593     1
    x[3209]   c1609     1
    x[3210]   c362_1    -480
    x[3210]   c1578     1
    x[3210]   c1594     1
    x[3210]   c1610     1
    x[3211]   c363_1    -480
    x[3211]   c1579     1
    x[3211]   c1595     1
    x[3211]   c1611     1
    x[3212]   c364_1    -480
    x[3212]   c1580     1
    x[3212]   c1596     1
    x[3212]   c1612     1
    x[3213]   c365_1    -480
    x[3213]   c1581     1
    x[3213]   c1597     1
    x[3213]   c1613     1
    x[3214]   c366_1    -480
    x[3214]   c1582     1
    x[3214]   c1598     1
    x[3214]   c1614     1
    x[3215]   c367_1    -480
    x[3215]   c1583     1
    x[3215]   c1599     1
    x[3215]   c1615     1
    x[3216]   c368_1    -480
    x[3216]   c1584     1
    x[3216]   c1600     1
    x[3216]   c1616     1
    x[3217]   c369_1    -480
    x[3217]   c1617     1
    x[3217]   c1633     1
    x[3217]   c1649     1
    x[3218]   c370_1    -480
    x[3218]   c1618     1
    x[3218]   c1634     1
    x[3218]   c1650     1
    x[3219]   c371_1    -480
    x[3219]   c1619     1
    x[3219]   c1635     1
    x[3219]   c1651     1
    x[3220]   c372_1    -480
    x[3220]   c1620     1
    x[3220]   c1636     1
    x[3220]   c1652     1
    x[3221]   c373_1    -480
    x[3221]   c1621     1
    x[3221]   c1637     1
    x[3221]   c1653     1
    x[3222]   c374_1    -480
    x[3222]   c1622     1
    x[3222]   c1638     1
    x[3222]   c1654     1
    x[3223]   c375_1    -480
    x[3223]   c1623     1
    x[3223]   c1639     1
    x[3223]   c1655     1
    x[3224]   c376_1    -480
    x[3224]   c1624     1
    x[3224]   c1640     1
    x[3224]   c1656     1
    x[3225]   c377_1    -480
    x[3225]   c1625     1
    x[3225]   c1641     1
    x[3225]   c1657     1
    x[3226]   c378_1    -480
    x[3226]   c1626     1
    x[3226]   c1642     1
    x[3226]   c1658     1
    x[3227]   c379_1    -480
    x[3227]   c1627     1
    x[3227]   c1643     1
    x[3227]   c1659     1
    x[3228]   c380_1    -480
    x[3228]   c1628     1
    x[3228]   c1644     1
    x[3228]   c1660     1
    x[3229]   c381_1    -480
    x[3229]   c1629     1
    x[3229]   c1645     1
    x[3229]   c1661     1
    x[3230]   c382_1    -480
    x[3230]   c1630     1
    x[3230]   c1646     1
    x[3230]   c1662     1
    x[3231]   c383_1    -480
    x[3231]   c1631     1
    x[3231]   c1647     1
    x[3231]   c1663     1
    x[3232]   c384_1    -480
    x[3232]   c1632     1
    x[3232]   c1648     1
    x[3232]   c1664     1
    x[3233]   c385_1    -480
    x[3233]   c1665     1
    x[3233]   c1681     1
    x[3233]   c1697     1
    x[3234]   c386_1    -480
    x[3234]   c1666     1
    x[3234]   c1682     1
    x[3234]   c1698     1
    x[3235]   c387_1    -480
    x[3235]   c1667     1
    x[3235]   c1683     1
    x[3235]   c1699     1
    x[3236]   c388_1    -480
    x[3236]   c1668     1
    x[3236]   c1684     1
    x[3236]   c1700     1
    x[3237]   c389_1    -480
    x[3237]   c1669     1
    x[3237]   c1685     1
    x[3237]   c1701     1
    x[3238]   c390_1    -480
    x[3238]   c1670     1
    x[3238]   c1686     1
    x[3238]   c1702     1
    x[3239]   c391_1    -480
    x[3239]   c1671     1
    x[3239]   c1687     1
    x[3239]   c1703     1
    x[3240]   c392_1    -480
    x[3240]   c1672     1
    x[3240]   c1688     1
    x[3240]   c1704     1
    x[3241]   c393_1    -480
    x[3241]   c1673     1
    x[3241]   c1689     1
    x[3241]   c1705     1
    x[3242]   c394_1    -480
    x[3242]   c1674     1
    x[3242]   c1690     1
    x[3242]   c1706     1
    x[3243]   c395_1    -480
    x[3243]   c1675     1
    x[3243]   c1691     1
    x[3243]   c1707     1
    x[3244]   c396_1    -480
    x[3244]   c1676     1
    x[3244]   c1692     1
    x[3244]   c1708     1
    x[3245]   c397_1    -480
    x[3245]   c1677     1
    x[3245]   c1693     1
    x[3245]   c1709     1
    x[3246]   c398_1    -480
    x[3246]   c1678     1
    x[3246]   c1694     1
    x[3246]   c1710     1
    x[3247]   c399_1    -480
    x[3247]   c1679     1
    x[3247]   c1695     1
    x[3247]   c1711     1
    x[3248]   c400_1    -480
    x[3248]   c1680     1
    x[3248]   c1696     1
    x[3248]   c1712     1
    x[3249]   c401_1    -480
    x[3249]   c1713     1
    x[3249]   c1729     1
    x[3249]   c1745     1
    x[3250]   c402_1    -480
    x[3250]   c1714     1
    x[3250]   c1730     1
    x[3250]   c1746     1
    x[3251]   c403_1    -480
    x[3251]   c1715     1
    x[3251]   c1731     1
    x[3251]   c1747     1
    x[3252]   c404_1    -480
    x[3252]   c1716     1
    x[3252]   c1732     1
    x[3252]   c1748     1
    x[3253]   c405_1    -480
    x[3253]   c1717     1
    x[3253]   c1733     1
    x[3253]   c1749     1
    x[3254]   c406_1    -480
    x[3254]   c1718     1
    x[3254]   c1734     1
    x[3254]   c1750     1
    x[3255]   c407_1    -480
    x[3255]   c1719     1
    x[3255]   c1735     1
    x[3255]   c1751     1
    x[3256]   c408_1    -480
    x[3256]   c1720     1
    x[3256]   c1736     1
    x[3256]   c1752     1
    x[3257]   c409_1    -480
    x[3257]   c1721     1
    x[3257]   c1737     1
    x[3257]   c1753     1
    x[3258]   c410_1    -480
    x[3258]   c1722     1
    x[3258]   c1738     1
    x[3258]   c1754     1
    x[3259]   c411_1    -480
    x[3259]   c1723     1
    x[3259]   c1739     1
    x[3259]   c1755     1
    x[3260]   c412_1    -480
    x[3260]   c1724     1
    x[3260]   c1740     1
    x[3260]   c1756     1
    x[3261]   c413_1    -480
    x[3261]   c1725     1
    x[3261]   c1741     1
    x[3261]   c1757     1
    x[3262]   c414_1    -480
    x[3262]   c1726     1
    x[3262]   c1742     1
    x[3262]   c1758     1
    x[3263]   c415_1    -480
    x[3263]   c1727     1
    x[3263]   c1743     1
    x[3263]   c1759     1
    x[3264]   c416_1    -480
    x[3264]   c1728     1
    x[3264]   c1744     1
    x[3264]   c1760     1
    x[3265]   c417_1    -480
    x[3265]   c1761     1
    x[3265]   c1777     1
    x[3265]   c1793     1
    x[3266]   c418_1    -480
    x[3266]   c1762     1
    x[3266]   c1778     1
    x[3266]   c1794     1
    x[3267]   c419_1    -480
    x[3267]   c1763     1
    x[3267]   c1779     1
    x[3267]   c1795     1
    x[3268]   c420_1    -480
    x[3268]   c1764     1
    x[3268]   c1780     1
    x[3268]   c1796     1
    x[3269]   c421_1    -480
    x[3269]   c1765     1
    x[3269]   c1781     1
    x[3269]   c1797     1
    x[3270]   c422_1    -480
    x[3270]   c1766     1
    x[3270]   c1782     1
    x[3270]   c1798     1
    x[3271]   c423_1    -480
    x[3271]   c1767     1
    x[3271]   c1783     1
    x[3271]   c1799     1
    x[3272]   c424_1    -480
    x[3272]   c1768     1
    x[3272]   c1784     1
    x[3272]   c1800     1
    x[3273]   c425_1    -480
    x[3273]   c1769     1
    x[3273]   c1785     1
    x[3273]   c1801     1
    x[3274]   c426_1    -480
    x[3274]   c1770     1
    x[3274]   c1786     1
    x[3274]   c1802     1
    x[3275]   c427_1    -480
    x[3275]   c1771     1
    x[3275]   c1787     1
    x[3275]   c1803     1
    x[3276]   c428_1    -480
    x[3276]   c1772     1
    x[3276]   c1788     1
    x[3276]   c1804     1
    x[3277]   c429_1    -480
    x[3277]   c1773     1
    x[3277]   c1789     1
    x[3277]   c1805     1
    x[3278]   c430_1    -480
    x[3278]   c1774     1
    x[3278]   c1790     1
    x[3278]   c1806     1
    x[3279]   c431_1    -480
    x[3279]   c1775     1
    x[3279]   c1791     1
    x[3279]   c1807     1
    x[3280]   c432_1    -480
    x[3280]   c1776     1
    x[3280]   c1792     1
    x[3280]   c1808     1
    x[3281]   c433_1    -480
    x[3281]   c1809     1
    x[3281]   c1825     1
    x[3281]   c1841     1
    x[3282]   c434_1    -480
    x[3282]   c1810     1
    x[3282]   c1826     1
    x[3282]   c1842     1
    x[3283]   c435_1    -480
    x[3283]   c1811     1
    x[3283]   c1827     1
    x[3283]   c1843     1
    x[3284]   c436_1    -480
    x[3284]   c1812     1
    x[3284]   c1828     1
    x[3284]   c1844     1
    x[3285]   c437_1    -480
    x[3285]   c1813     1
    x[3285]   c1829     1
    x[3285]   c1845     1
    x[3286]   c438_1    -480
    x[3286]   c1814     1
    x[3286]   c1830     1
    x[3286]   c1846     1
    x[3287]   c439_1    -480
    x[3287]   c1815     1
    x[3287]   c1831     1
    x[3287]   c1847     1
    x[3288]   c440_1    -480
    x[3288]   c1816     1
    x[3288]   c1832     1
    x[3288]   c1848     1
    x[3289]   c441_1    -480
    x[3289]   c1817     1
    x[3289]   c1833     1
    x[3289]   c1849     1
    x[3290]   c442_1    -480
    x[3290]   c1818     1
    x[3290]   c1834     1
    x[3290]   c1850     1
    x[3291]   c443_1    -480
    x[3291]   c1819     1
    x[3291]   c1835     1
    x[3291]   c1851     1
    x[3292]   c444_1    -480
    x[3292]   c1820     1
    x[3292]   c1836     1
    x[3292]   c1852     1
    x[3293]   c445_1    -480
    x[3293]   c1821     1
    x[3293]   c1837     1
    x[3293]   c1853     1
    x[3294]   c446_1    -480
    x[3294]   c1822     1
    x[3294]   c1838     1
    x[3294]   c1854     1
    x[3295]   c447_1    -480
    x[3295]   c1823     1
    x[3295]   c1839     1
    x[3295]   c1855     1
    x[3296]   c448_1    -480
    x[3296]   c1824     1
    x[3296]   c1840     1
    x[3296]   c1856     1
    x[3297]   c449_1    -480
    x[3297]   c1857     1
    x[3297]   c1873     1
    x[3297]   c1889     1
    x[3298]   c450_1    -480
    x[3298]   c1858     1
    x[3298]   c1874     1
    x[3298]   c1890     1
    x[3299]   c451_1    -480
    x[3299]   c1859     1
    x[3299]   c1875     1
    x[3299]   c1891     1
    x[3300]   c452_1    -480
    x[3300]   c1860     1
    x[3300]   c1876     1
    x[3300]   c1892     1
    x[3301]   c453_1    -480
    x[3301]   c1861     1
    x[3301]   c1877     1
    x[3301]   c1893     1
    x[3302]   c454_1    -480
    x[3302]   c1862     1
    x[3302]   c1878     1
    x[3302]   c1894     1
    x[3303]   c455_1    -480
    x[3303]   c1863     1
    x[3303]   c1879     1
    x[3303]   c1895     1
    x[3304]   c456_1    -480
    x[3304]   c1864     1
    x[3304]   c1880     1
    x[3304]   c1896     1
    x[3305]   c457_1    -480
    x[3305]   c1865     1
    x[3305]   c1881     1
    x[3305]   c1897     1
    x[3306]   c458_1    -480
    x[3306]   c1866     1
    x[3306]   c1882     1
    x[3306]   c1898     1
    x[3307]   c459_1    -480
    x[3307]   c1867     1
    x[3307]   c1883     1
    x[3307]   c1899     1
    x[3308]   c460_1    -480
    x[3308]   c1868     1
    x[3308]   c1884     1
    x[3308]   c1900     1
    x[3309]   c461_1    -480
    x[3309]   c1869     1
    x[3309]   c1885     1
    x[3309]   c1901     1
    x[3310]   c462_1    -480
    x[3310]   c1870     1
    x[3310]   c1886     1
    x[3310]   c1902     1
    x[3311]   c463_1    -480
    x[3311]   c1871     1
    x[3311]   c1887     1
    x[3311]   c1903     1
    x[3312]   c464_1    -480
    x[3312]   c1872     1
    x[3312]   c1888     1
    x[3312]   c1904     1
    x[3313]   c465_1    -480
    x[3313]   c1905     1
    x[3313]   c1921     1
    x[3313]   c1937     1
    x[3314]   c466_1    -480
    x[3314]   c1906     1
    x[3314]   c1922     1
    x[3314]   c1938     1
    x[3315]   c467_1    -480
    x[3315]   c1907     1
    x[3315]   c1923     1
    x[3315]   c1939     1
    x[3316]   c468_1    -480
    x[3316]   c1908     1
    x[3316]   c1924     1
    x[3316]   c1940     1
    x[3317]   c469_1    -480
    x[3317]   c1909     1
    x[3317]   c1925     1
    x[3317]   c1941     1
    x[3318]   c470_1    -480
    x[3318]   c1910     1
    x[3318]   c1926     1
    x[3318]   c1942     1
    x[3319]   c471_1    -480
    x[3319]   c1911     1
    x[3319]   c1927     1
    x[3319]   c1943     1
    x[3320]   c472_1    -480
    x[3320]   c1912     1
    x[3320]   c1928     1
    x[3320]   c1944     1
    x[3321]   c473_1    -480
    x[3321]   c1913     1
    x[3321]   c1929     1
    x[3321]   c1945     1
    x[3322]   c474_1    -480
    x[3322]   c1914     1
    x[3322]   c1930     1
    x[3322]   c1946     1
    x[3323]   c475_1    -480
    x[3323]   c1915     1
    x[3323]   c1931     1
    x[3323]   c1947     1
    x[3324]   c476_1    -480
    x[3324]   c1916     1
    x[3324]   c1932     1
    x[3324]   c1948     1
    x[3325]   c477_1    -480
    x[3325]   c1917     1
    x[3325]   c1933     1
    x[3325]   c1949     1
    x[3326]   c478_1    -480
    x[3326]   c1918     1
    x[3326]   c1934     1
    x[3326]   c1950     1
    x[3327]   c479_1    -480
    x[3327]   c1919     1
    x[3327]   c1935     1
    x[3327]   c1951     1
    x[3328]   c480_1    -480
    x[3328]   c1920     1
    x[3328]   c1936     1
    x[3328]   c1952     1
    x[3329]   c481_1    -480
    x[3329]   c1953     1
    x[3329]   c1969     1
    x[3329]   c1985     1
    x[3330]   c482_1    -480
    x[3330]   c1954     1
    x[3330]   c1970     1
    x[3330]   c1986     1
    x[3331]   c483_1    -480
    x[3331]   c1955     1
    x[3331]   c1971     1
    x[3331]   c1987     1
    x[3332]   c484_1    -480
    x[3332]   c1956     1
    x[3332]   c1972     1
    x[3332]   c1988     1
    x[3333]   c485_1    -480
    x[3333]   c1957     1
    x[3333]   c1973     1
    x[3333]   c1989     1
    x[3334]   c486_1    -480
    x[3334]   c1958     1
    x[3334]   c1974     1
    x[3334]   c1990     1
    x[3335]   c487_1    -480
    x[3335]   c1959     1
    x[3335]   c1975     1
    x[3335]   c1991     1
    x[3336]   c488_1    -480
    x[3336]   c1960     1
    x[3336]   c1976     1
    x[3336]   c1992     1
    x[3337]   c489_1    -480
    x[3337]   c1961     1
    x[3337]   c1977     1
    x[3337]   c1993     1
    x[3338]   c490_1    -480
    x[3338]   c1962     1
    x[3338]   c1978     1
    x[3338]   c1994     1
    x[3339]   c491_1    -480
    x[3339]   c1963     1
    x[3339]   c1979     1
    x[3339]   c1995     1
    x[3340]   c492_1    -480
    x[3340]   c1964     1
    x[3340]   c1980     1
    x[3340]   c1996     1
    x[3341]   c493_1    -480
    x[3341]   c1965     1
    x[3341]   c1981     1
    x[3341]   c1997     1
    x[3342]   c494_1    -480
    x[3342]   c1966     1
    x[3342]   c1982     1
    x[3342]   c1998     1
    x[3343]   c495_1    -480
    x[3343]   c1967     1
    x[3343]   c1983     1
    x[3343]   c1999     1
    x[3344]   c496_1    -480
    x[3344]   c1968     1
    x[3344]   c1984     1
    x[3344]   c2000     1
    x[3345]   c497_1    -480
    x[3345]   c2001     1
    x[3345]   c2017     1
    x[3345]   c2033     1
    x[3346]   c498_1    -480
    x[3346]   c2002     1
    x[3346]   c2018     1
    x[3346]   c2034     1
    x[3347]   c499_1    -480
    x[3347]   c2003     1
    x[3347]   c2019     1
    x[3347]   c2035     1
    x[3348]   c500_1    -480
    x[3348]   c2004     1
    x[3348]   c2020     1
    x[3348]   c2036     1
    x[3349]   c501_1    -480
    x[3349]   c2005     1
    x[3349]   c2021     1
    x[3349]   c2037     1
    x[3350]   c502_1    -480
    x[3350]   c2006     1
    x[3350]   c2022     1
    x[3350]   c2038     1
    x[3351]   c503_1    -480
    x[3351]   c2007     1
    x[3351]   c2023     1
    x[3351]   c2039     1
    x[3352]   c504_1    -480
    x[3352]   c2008     1
    x[3352]   c2024     1
    x[3352]   c2040     1
    x[3353]   c505_1    -480
    x[3353]   c2009     1
    x[3353]   c2025     1
    x[3353]   c2041     1
    x[3354]   c506_1    -480
    x[3354]   c2010     1
    x[3354]   c2026     1
    x[3354]   c2042     1
    x[3355]   c507_1    -480
    x[3355]   c2011     1
    x[3355]   c2027     1
    x[3355]   c2043     1
    x[3356]   c508_1    -480
    x[3356]   c2012     1
    x[3356]   c2028     1
    x[3356]   c2044     1
    x[3357]   c509_1    -480
    x[3357]   c2013     1
    x[3357]   c2029     1
    x[3357]   c2045     1
    x[3358]   c510_1    -480
    x[3358]   c2014     1
    x[3358]   c2030     1
    x[3358]   c2046     1
    x[3359]   c511_1    -480
    x[3359]   c2015     1
    x[3359]   c2031     1
    x[3359]   c2047     1
    x[3360]   c512_1    -480
    x[3360]   c2016     1
    x[3360]   c2032     1
    x[3360]   c2048     1
    x[3361]   c513_1    -480
    x[3361]   c2049     1
    x[3362]   c514_1    -480
    x[3362]   c2050     1
    x[3363]   c515_1    -480
    x[3363]   c2051     1
    x[3364]   c516_1    -480
    x[3364]   c2052     1
    x[3365]   c517_1    -480
    x[3365]   c2053     1
    x[3366]   c518_1    -480
    x[3366]   c2054     1
    x[3367]   c519_1    -480
    x[3367]   c2055     1
    x[3368]   c520_1    -480
    x[3368]   c2056     1
    x[3369]   c521_1    -480
    x[3369]   c2057     1
    x[3370]   c522_1    -480
    x[3370]   c2058     1
    x[3371]   c523_1    -480
    x[3371]   c2059     1
    x[3372]   c524_1    -480
    x[3372]   c2060     1
    x[3373]   c525_1    -480
    x[3373]   c2061     1
    x[3374]   c526_1    -480
    x[3374]   c2062     1
    x[3375]   c527_1    -480
    x[3375]   c2063     1
    x[3376]   c528_1    -480
    x[3376]   c2064     1
    x[3377]   c529_1    -480
    x[3377]   c2065     1
    x[3378]   c530_1    -480
    x[3378]   c2066     1
    x[3379]   c531_1    -480
    x[3379]   c2067     1
    x[3380]   c532_1    -480
    x[3380]   c2068     1
    x[3381]   c533_1    -480
    x[3381]   c2069     1
    x[3382]   c534_1    -480
    x[3382]   c2070     1
    x[3383]   c535_1    -480
    x[3383]   c2071     1
    x[3384]   c536_1    -480
    x[3384]   c2072     1
    x[3385]   c537_1    -480
    x[3385]   c2073     1
    x[3386]   c538_1    -480
    x[3386]   c2074     1
    x[3387]   c539_1    -480
    x[3387]   c2075     1
    x[3388]   c540_1    -480
    x[3388]   c2076     1
    x[3389]   c541_1    -480
    x[3389]   c2077     1
    x[3390]   c542_1    -480
    x[3390]   c2078     1
    x[3391]   c543_1    -480
    x[3391]   c2079     1
    x[3392]   c544_1    -480
    x[3392]   c2080     1
    x[3393]   c545_1    -480
    x[3393]   c2081     1
    x[3394]   c546_1    -480
    x[3394]   c2082     1
    x[3395]   c547_1    -480
    x[3395]   c2083     1
    x[3396]   c548_1    -480
    x[3396]   c2084     1
    x[3397]   c549_1    -480
    x[3397]   c2085     1
    x[3398]   c550_1    -480
    x[3398]   c2086     1
    x[3399]   c551_1    -480
    x[3399]   c2087     1
    x[3400]   c552_1    -480
    x[3400]   c2088     1
    x[3401]   c553_1    -480
    x[3401]   c2089     1
    x[3402]   c554_1    -480
    x[3402]   c2090     1
    x[3403]   c555_1    -480
    x[3403]   c2091     1
    x[3404]   c556_1    -480
    x[3404]   c2092     1
    x[3405]   c557_1    -480
    x[3405]   c2093     1
    x[3406]   c558_1    -480
    x[3406]   c2094     1
    x[3407]   c559_1    -480
    x[3407]   c2095     1
    x[3408]   c560_1    -480
    x[3408]   c2096     1
    x[3409]   c561_1    -480
    x[3409]   c2097     1
    x[3410]   c562_1    -480
    x[3410]   c2098     1
    x[3411]   c563_1    -480
    x[3411]   c2099     1
    x[3412]   c564_1    -480
    x[3412]   c2100     1
    x[3413]   c565_1    -480
    x[3413]   c2101     1
    x[3414]   c566_1    -480
    x[3414]   c2102     1
    x[3415]   c567_1    -480
    x[3415]   c2103     1
    x[3416]   c568_1    -480
    x[3416]   c2104     1
    x[3417]   c569_1    -480
    x[3417]   c2105     1
    x[3418]   c570_1    -480
    x[3418]   c2106     1
    x[3419]   c571_1    -480
    x[3419]   c2107     1
    x[3420]   c572_1    -480
    x[3420]   c2108     1
    x[3421]   c573_1    -480
    x[3421]   c2109     1
    x[3422]   c574_1    -480
    x[3422]   c2110     1
    x[3423]   c575_1    -480
    x[3423]   c2111     1
    x[3424]   c576_1    -480
    x[3424]   c2112     1
    x[3425]   c577_1    -480
    x[3425]   c2113     1
    x[3426]   c578_1    -480
    x[3426]   c2114     1
    x[3427]   c579_1    -480
    x[3427]   c2115     1
    x[3428]   c580_1    -480
    x[3428]   c2116     1
    x[3429]   c581_1    -480
    x[3429]   c2117     1
    x[3430]   c582_1    -480
    x[3430]   c2118     1
    x[3431]   c583_1    -480
    x[3431]   c2119     1
    x[3432]   c584_1    -480
    x[3432]   c2120     1
    x[3433]   c585_1    -480
    x[3433]   c2121     1
    x[3434]   c586_1    -480
    x[3434]   c2122     1
    x[3435]   c587_1    -480
    x[3435]   c2123     1
    x[3436]   c588_1    -480
    x[3436]   c2124     1
    x[3437]   c589_1    -480
    x[3437]   c2125     1
    x[3438]   c590_1    -480
    x[3438]   c2126     1
    x[3439]   c591_1    -480
    x[3439]   c2127     1
    x[3440]   c592_1    -480
    x[3440]   c2128     1
    x[3441]   c593_1    -480
    x[3441]   c2129     1
    x[3442]   c594_1    -480
    x[3442]   c2130     1
    x[3443]   c595_1    -480
    x[3443]   c2131     1
    x[3444]   c596_1    -480
    x[3444]   c2132     1
    x[3445]   c597_1    -480
    x[3445]   c2133     1
    x[3446]   c598_1    -480
    x[3446]   c2134     1
    x[3447]   c599_1    -480
    x[3447]   c2135     1
    x[3448]   c600_1    -480
    x[3448]   c2136     1
    x[3449]   c601_1    -480
    x[3449]   c2137     1
    x[3450]   c602_1    -480
    x[3450]   c2138     1
    x[3451]   c603_1    -480
    x[3451]   c2139     1
    x[3452]   c604_1    -480
    x[3452]   c2140     1
    x[3453]   c605_1    -480
    x[3453]   c2141     1
    x[3454]   c606_1    -480
    x[3454]   c2142     1
    x[3455]   c607_1    -480
    x[3455]   c2143     1
    x[3456]   c608_1    -480
    x[3456]   c2144     1
    x[3457]   c609_1    -480
    x[3457]   c2145     1
    x[3458]   c610_1    -480
    x[3458]   c2146     1
    x[3459]   c611_1    -480
    x[3459]   c2147     1
    x[3460]   c612_1    -480
    x[3460]   c2148     1
    x[3461]   c613_1    -480
    x[3461]   c2149     1
    x[3462]   c614_1    -480
    x[3462]   c2150     1
    x[3463]   c615_1    -480
    x[3463]   c2151     1
    x[3464]   c616_1    -480
    x[3464]   c2152     1
    x[3465]   c617_1    -480
    x[3465]   c2153     1
    x[3466]   c618_1    -480
    x[3466]   c2154     1
    x[3467]   c619_1    -480
    x[3467]   c2155     1
    x[3468]   c620_1    -480
    x[3468]   c2156     1
    x[3469]   c621_1    -480
    x[3469]   c2157     1
    x[3470]   c622_1    -480
    x[3470]   c2158     1
    x[3471]   c623_1    -480
    x[3471]   c2159     1
    x[3472]   c624_1    -480
    x[3472]   c2160     1
    x[3473]   c625_1    -480
    x[3473]   c2161     1
    x[3474]   c626_1    -480
    x[3474]   c2162     1
    x[3475]   c627_1    -480
    x[3475]   c2163     1
    x[3476]   c628_1    -480
    x[3476]   c2164     1
    x[3477]   c629_1    -480
    x[3477]   c2165     1
    x[3478]   c630_1    -480
    x[3478]   c2166     1
    x[3479]   c631_1    -480
    x[3479]   c2167     1
    x[3480]   c632_1    -480
    x[3480]   c2168     1
    x[3481]   c633_1    -480
    x[3481]   c2169     1
    x[3482]   c634_1    -480
    x[3482]   c2170     1
    x[3483]   c635_1    -480
    x[3483]   c2171     1
    x[3484]   c636_1    -480
    x[3484]   c2172     1
    x[3485]   c637_1    -480
    x[3485]   c2173     1
    x[3486]   c638_1    -480
    x[3486]   c2174     1
    x[3487]   c639_1    -480
    x[3487]   c2175     1
    x[3488]   c640_1    -480
    x[3488]   c2176     1
    x[3489]   c641_1    -480
    x[3489]   c2177     1
    x[3490]   c642_1    -480
    x[3490]   c2178     1
    x[3491]   c643_1    -480
    x[3491]   c2179     1
    x[3492]   c644_1    -480
    x[3492]   c2180     1
    x[3493]   c645_1    -480
    x[3493]   c2181     1
    x[3494]   c646_1    -480
    x[3494]   c2182     1
    x[3495]   c647_1    -480
    x[3495]   c2183     1
    x[3496]   c648_1    -480
    x[3496]   c2184     1
    x[3497]   c649_1    -480
    x[3497]   c2185     1
    x[3498]   c650_1    -480
    x[3498]   c2186     1
    x[3499]   c651_1    -480
    x[3499]   c2187     1
    x[3500]   c652_1    -480
    x[3500]   c2188     1
    x[3501]   c653_1    -480
    x[3501]   c2189     1
    x[3502]   c654_1    -480
    x[3502]   c2190     1
    x[3503]   c655_1    -480
    x[3503]   c2191     1
    x[3504]   c656_1    -480
    x[3504]   c2192     1
    x[3505]   c657_1    -480
    x[3505]   c2193     1
    x[3506]   c658_1    -480
    x[3506]   c2194     1
    x[3507]   c659_1    -480
    x[3507]   c2195     1
    x[3508]   c660_1    -480
    x[3508]   c2196     1
    x[3509]   c661_1    -480
    x[3509]   c2197     1
    x[3510]   c662_1    -480
    x[3510]   c2198     1
    x[3511]   c663_1    -480
    x[3511]   c2199     1
    x[3512]   c664_1    -480
    x[3512]   c2200     1
    x[3513]   c665_1    -480
    x[3513]   c2201     1
    x[3514]   c666_1    -480
    x[3514]   c2202     1
    x[3515]   c667_1    -480
    x[3515]   c2203     1
    x[3516]   c668_1    -480
    x[3516]   c2204     1
    x[3517]   c669_1    -480
    x[3517]   c2205     1
    x[3518]   c670_1    -480
    x[3518]   c2206     1
    x[3519]   c671_1    -480
    x[3519]   c2207     1
    x[3520]   c672_1    -480
    x[3520]   c2208     1
    x[3521]   c673_1    -480
    x[3521]   c2209     1
    x[3522]   c674_1    -480
    x[3522]   c2210     1
    x[3523]   c675_1    -480
    x[3523]   c2211     1
    x[3524]   c676_1    -480
    x[3524]   c2212     1
    x[3525]   c677_1    -480
    x[3525]   c2213     1
    x[3526]   c678_1    -480
    x[3526]   c2214     1
    x[3527]   c679_1    -480
    x[3527]   c2215     1
    x[3528]   c680_1    -480
    x[3528]   c2216     1
    x[3529]   c681_1    -480
    x[3529]   c2217     1
    x[3530]   c682_1    -480
    x[3530]   c2218     1
    x[3531]   c683_1    -480
    x[3531]   c2219     1
    x[3532]   c684_1    -480
    x[3532]   c2220     1
    x[3533]   c685_1    -480
    x[3533]   c2221     1
    x[3534]   c686_1    -480
    x[3534]   c2222     1
    x[3535]   c687_1    -480
    x[3535]   c2223     1
    x[3536]   c688_1    -480
    x[3536]   c2224     1
    x[3537]   c689_1    -480
    x[3537]   c2225     1
    x[3538]   c690_1    -480
    x[3538]   c2226     1
    x[3539]   c691_1    -480
    x[3539]   c2227     1
    x[3540]   c692_1    -480
    x[3540]   c2228     1
    x[3541]   c693_1    -480
    x[3541]   c2229     1
    x[3542]   c694_1    -480
    x[3542]   c2230     1
    x[3543]   c695_1    -480
    x[3543]   c2231     1
    x[3544]   c696_1    -480
    x[3544]   c2232     1
    x[3545]   c697_1    -480
    x[3545]   c2233     1
    x[3546]   c698_1    -480
    x[3546]   c2234     1
    x[3547]   c699_1    -480
    x[3547]   c2235     1
    x[3548]   c700_1    -480
    x[3548]   c2236     1
    x[3549]   c701_1    -480
    x[3549]   c2237     1
    x[3550]   c702_1    -480
    x[3550]   c2238     1
    x[3551]   c703_1    -480
    x[3551]   c2239     1
    x[3552]   c704_1    -480
    x[3552]   c2240     1
    x[3553]   c705_1    -480
    x[3553]   c2241     1
    x[3554]   c706_1    -480
    x[3554]   c2242     1
    x[3555]   c707_1    -480
    x[3555]   c2243     1
    x[3556]   c708_1    -480
    x[3556]   c2244     1
    x[3557]   c709_1    -480
    x[3557]   c2245     1
    x[3558]   c710_1    -480
    x[3558]   c2246     1
    x[3559]   c711_1    -480
    x[3559]   c2247     1
    x[3560]   c712_1    -480
    x[3560]   c2248     1
    x[3561]   c713_1    -480
    x[3561]   c2249     1
    x[3562]   c714_1    -480
    x[3562]   c2250     1
    x[3563]   c715_1    -480
    x[3563]   c2251     1
    x[3564]   c716_1    -480
    x[3564]   c2252     1
    x[3565]   c717_1    -480
    x[3565]   c2253     1
    x[3566]   c718_1    -480
    x[3566]   c2254     1
    x[3567]   c719_1    -480
    x[3567]   c2255     1
    x[3568]   c720_1    -480
    x[3568]   c2256     1
    x[3569]   c721_1    -480
    x[3569]   c2257     1
    x[3570]   c722_1    -480
    x[3570]   c2258     1
    x[3571]   c723_1    -480
    x[3571]   c2259     1
    x[3572]   c724_1    -480
    x[3572]   c2260     1
    x[3573]   c725_1    -480
    x[3573]   c2261     1
    x[3574]   c726_1    -480
    x[3574]   c2262     1
    x[3575]   c727_1    -480
    x[3575]   c2263     1
    x[3576]   c728_1    -480
    x[3576]   c2264     1
    x[3577]   c729_1    -480
    x[3577]   c2265     1
    x[3578]   c730_1    -480
    x[3578]   c2266     1
    x[3579]   c731_1    -480
    x[3579]   c2267     1
    x[3580]   c732_1    -480
    x[3580]   c2268     1
    x[3581]   c733_1    -480
    x[3581]   c2269     1
    x[3582]   c734_1    -480
    x[3582]   c2270     1
    x[3583]   c735_1    -480
    x[3583]   c2271     1
    x[3584]   c736_1    -480
    x[3584]   c2272     1
    x[3585]   c737_1    -480
    x[3585]   c2273     1
    x[3586]   c738_1    -480
    x[3586]   c2274     1
    x[3587]   c739_1    -480
    x[3587]   c2275     1
    x[3588]   c740_1    -480
    x[3588]   c2276     1
    x[3589]   c741_1    -480
    x[3589]   c2277     1
    x[3590]   c742_1    -480
    x[3590]   c2278     1
    x[3591]   c743_1    -480
    x[3591]   c2279     1
    x[3592]   c744_1    -480
    x[3592]   c2280     1
    x[3593]   c745_1    -480
    x[3593]   c2281     1
    x[3594]   c746_1    -480
    x[3594]   c2282     1
    x[3595]   c747_1    -480
    x[3595]   c2283     1
    x[3596]   c748_1    -480
    x[3596]   c2284     1
    x[3597]   c749_1    -480
    x[3597]   c2285     1
    x[3598]   c750_1    -480
    x[3598]   c2286     1
    x[3599]   c751_1    -480
    x[3599]   c2287     1
    x[3600]   c752_1    -480
    x[3600]   c2288     1
    x[3601]   c753_1    -480
    x[3601]   c2289     1
    x[3602]   c754_1    -480
    x[3602]   c2290     1
    x[3603]   c755_1    -480
    x[3603]   c2291     1
    x[3604]   c756_1    -480
    x[3604]   c2292     1
    x[3605]   c757_1    -480
    x[3605]   c2293     1
    x[3606]   c758_1    -480
    x[3606]   c2294     1
    x[3607]   c759_1    -480
    x[3607]   c2295     1
    x[3608]   c760_1    -480
    x[3608]   c2296     1
    x[3609]   c761_1    -480
    x[3609]   c2297     1
    x[3610]   c762_1    -480
    x[3610]   c2298     1
    x[3611]   c763_1    -480
    x[3611]   c2299     1
    x[3612]   c764_1    -480
    x[3612]   c2300     1
    x[3613]   c765_1    -480
    x[3613]   c2301     1
    x[3614]   c766_1    -480
    x[3614]   c2302     1
    x[3615]   c767_1    -480
    x[3615]   c2303     1
    x[3616]   c768_1    -480
    x[3616]   c2304     1
    x[3617]   c769_1    -480
    x[3617]   c2305     1
    x[3618]   c770_1    -480
    x[3618]   c2306     1
    x[3619]   c771_1    -480
    x[3619]   c2307     1
    x[3620]   c772_1    -480
    x[3620]   c2308     1
    x[3621]   c773_1    -480
    x[3621]   c2309     1
    x[3622]   c774_1    -480
    x[3622]   c2310     1
    x[3623]   c775_1    -480
    x[3623]   c2311     1
    x[3624]   c776_1    -480
    x[3624]   c2312     1
    x[3625]   c777_1    -480
    x[3625]   c2313     1
    x[3626]   c778_1    -480
    x[3626]   c2314     1
    x[3627]   c779_1    -480
    x[3627]   c2315     1
    x[3628]   c780_1    -480
    x[3628]   c2316     1
    x[3629]   c781_1    -480
    x[3629]   c2317     1
    x[3630]   c782_1    -480
    x[3630]   c2318     1
    x[3631]   c783_1    -480
    x[3631]   c2319     1
    x[3632]   c784_1    -480
    x[3632]   c2320     1
    x[3633]   c785_1    -480
    x[3633]   c2321     1
    x[3634]   c786_1    -480
    x[3634]   c2322     1
    x[3635]   c787_1    -480
    x[3635]   c2323     1
    x[3636]   c788_1    -480
    x[3636]   c2324     1
    x[3637]   c789_1    -480
    x[3637]   c2325     1
    x[3638]   c790_1    -480
    x[3638]   c2326     1
    x[3639]   c791_1    -480
    x[3639]   c2327     1
    x[3640]   c792_1    -480
    x[3640]   c2328     1
    x[3641]   c793_1    -480
    x[3641]   c2329     1
    x[3642]   c794_1    -480
    x[3642]   c2330     1
    x[3643]   c795_1    -480
    x[3643]   c2331     1
    x[3644]   c796_1    -480
    x[3644]   c2332     1
    x[3645]   c797_1    -480
    x[3645]   c2333     1
    x[3646]   c798_1    -480
    x[3646]   c2334     1
    x[3647]   c799_1    -480
    x[3647]   c2335     1
    x[3648]   c800_1    -480
    x[3648]   c2336     1
    x[3649]   c801_1    -480
    x[3649]   c2337     1
    x[3650]   c802_1    -480
    x[3650]   c2338     1
    x[3651]   c803_1    -480
    x[3651]   c2339     1
    x[3652]   c804_1    -480
    x[3652]   c2340     1
    x[3653]   c805_1    -480
    x[3653]   c2341     1
    x[3654]   c806_1    -480
    x[3654]   c2342     1
    x[3655]   c807_1    -480
    x[3655]   c2343     1
    x[3656]   c808_1    -480
    x[3656]   c2344     1
    x[3657]   c809_1    -480
    x[3657]   c2345     1
    x[3658]   c810_1    -480
    x[3658]   c2346     1
    x[3659]   c811_1    -480
    x[3659]   c2347     1
    x[3660]   c812_1    -480
    x[3660]   c2348     1
    x[3661]   c813_1    -480
    x[3661]   c2349     1
    x[3662]   c814_1    -480
    x[3662]   c2350     1
    x[3663]   c815_1    -480
    x[3663]   c2351     1
    x[3664]   c816_1    -480
    x[3664]   c2352     1
    x[3665]   c817_1    -480
    x[3665]   c2353     1
    x[3666]   c818_1    -480
    x[3666]   c2354     1
    x[3667]   c819_1    -480
    x[3667]   c2355     1
    x[3668]   c820_1    -480
    x[3668]   c2356     1
    x[3669]   c821_1    -480
    x[3669]   c2357     1
    x[3670]   c822_1    -480
    x[3670]   c2358     1
    x[3671]   c823_1    -480
    x[3671]   c2359     1
    x[3672]   c824_1    -480
    x[3672]   c2360     1
    x[3673]   c825_1    -480
    x[3673]   c2361     1
    x[3674]   c826_1    -480
    x[3674]   c2362     1
    x[3675]   c827_1    -480
    x[3675]   c2363     1
    x[3676]   c828_1    -480
    x[3676]   c2364     1
    x[3677]   c829_1    -480
    x[3677]   c2365     1
    x[3678]   c830_1    -480
    x[3678]   c2366     1
    x[3679]   c831_1    -480
    x[3679]   c2367     1
    x[3680]   c832_1    -480
    x[3680]   c2368     1
    x[3681]   c833_1    -480
    x[3681]   c2369     1
    x[3682]   c834_1    -480
    x[3682]   c2370     1
    x[3683]   c835_1    -480
    x[3683]   c2371     1
    x[3684]   c836_1    -480
    x[3684]   c2372     1
    x[3685]   c837_1    -480
    x[3685]   c2373     1
    x[3686]   c838_1    -480
    x[3686]   c2374     1
    x[3687]   c839_1    -480
    x[3687]   c2375     1
    x[3688]   c840_1    -480
    x[3688]   c2376     1
    x[3689]   c841_1    -480
    x[3689]   c2377     1
    x[3690]   c842_1    -480
    x[3690]   c2378     1
    x[3691]   c843_1    -480
    x[3691]   c2379     1
    x[3692]   c844_1    -480
    x[3692]   c2380     1
    x[3693]   c845_1    -480
    x[3693]   c2381     1
    x[3694]   c846_1    -480
    x[3694]   c2382     1
    x[3695]   c847_1    -480
    x[3695]   c2383     1
    x[3696]   c848_1    -480
    x[3696]   c2384     1
    x[3697]   c849_1    -480
    x[3697]   c2385     1
    x[3698]   c850_1    -480
    x[3698]   c2386     1
    x[3699]   c851_1    -480
    x[3699]   c2387     1
    x[3700]   c852_1    -480
    x[3700]   c2388     1
    x[3701]   c853_1    -480
    x[3701]   c2389     1
    x[3702]   c854_1    -480
    x[3702]   c2390     1
    x[3703]   c855_1    -480
    x[3703]   c2391     1
    x[3704]   c856_1    -480
    x[3704]   c2392     1
    x[3705]   c857_1    -480
    x[3705]   c2393     1
    x[3706]   c858_1    -480
    x[3706]   c2394     1
    x[3707]   c859_1    -480
    x[3707]   c2395     1
    x[3708]   c860_1    -480
    x[3708]   c2396     1
    x[3709]   c861_1    -480
    x[3709]   c2397     1
    x[3710]   c862_1    -480
    x[3710]   c2398     1
    x[3711]   c863_1    -480
    x[3711]   c2399     1
    x[3712]   c864_1    -480
    x[3712]   c2400     1
    x[3713]   c865_1    -480
    x[3713]   c2401     1
    x[3714]   c866_1    -480
    x[3714]   c2402     1
    x[3715]   c867_1    -480
    x[3715]   c2403     1
    x[3716]   c868_1    -480
    x[3716]   c2404     1
    x[3717]   c869_1    -480
    x[3717]   c2405     1
    x[3718]   c870_1    -480
    x[3718]   c2406     1
    x[3719]   c871_1    -480
    x[3719]   c2407     1
    x[3720]   c872_1    -480
    x[3720]   c2408     1
    x[3721]   c873_1    -480
    x[3721]   c2409     1
    x[3722]   c874_1    -480
    x[3722]   c2410     1
    x[3723]   c875_1    -480
    x[3723]   c2411     1
    x[3724]   c876_1    -480
    x[3724]   c2412     1
    x[3725]   c877_1    -480
    x[3725]   c2413     1
    x[3726]   c878_1    -480
    x[3726]   c2414     1
    x[3727]   c879_1    -480
    x[3727]   c2415     1
    x[3728]   c880_1    -480
    x[3728]   c2416     1
    x[3729]   c881_1    -480
    x[3729]   c2417     1
    x[3730]   c882_1    -480
    x[3730]   c2418     1
    x[3731]   c883_1    -480
    x[3731]   c2419     1
    x[3732]   c884_1    -480
    x[3732]   c2420     1
    x[3733]   c885_1    -480
    x[3733]   c2421     1
    x[3734]   c886_1    -480
    x[3734]   c2422     1
    x[3735]   c887_1    -480
    x[3735]   c2423     1
    x[3736]   c888_1    -480
    x[3736]   c2424     1
    x[3737]   c889_1    -480
    x[3737]   c2425     1
    x[3738]   c890_1    -480
    x[3738]   c2426     1
    x[3739]   c891_1    -480
    x[3739]   c2427     1
    x[3740]   c892_1    -480
    x[3740]   c2428     1
    x[3741]   c893_1    -480
    x[3741]   c2429     1
    x[3742]   c894_1    -480
    x[3742]   c2430     1
    x[3743]   c895_1    -480
    x[3743]   c2431     1
    x[3744]   c896_1    -480
    x[3744]   c2432     1
    x[3745]   c897_1    -480
    x[3745]   c2433     1
    x[3746]   c898_1    -480
    x[3746]   c2434     1
    x[3747]   c899_1    -480
    x[3747]   c2435     1
    x[3748]   c900_1    -480
    x[3748]   c2436     1
    x[3749]   c901_1    -480
    x[3749]   c2437     1
    x[3750]   c902_1    -480
    x[3750]   c2438     1
    x[3751]   c903_1    -480
    x[3751]   c2439     1
    x[3752]   c904_1    -480
    x[3752]   c2440     1
    x[3753]   c905_1    -480
    x[3753]   c2441     1
    x[3754]   c906_1    -480
    x[3754]   c2442     1
    x[3755]   c907_1    -480
    x[3755]   c2443     1
    x[3756]   c908_1    -480
    x[3756]   c2444     1
    x[3757]   c909_1    -480
    x[3757]   c2445     1
    x[3758]   c910_1    -480
    x[3758]   c2446     1
    x[3759]   c911_1    -480
    x[3759]   c2447     1
    x[3760]   c912_1    -480
    x[3760]   c2448     1
    x[3761]   c913_1    -480
    x[3761]   c2449     1
    x[3762]   c914_1    -480
    x[3762]   c2450     1
    x[3763]   c915_1    -480
    x[3763]   c2451     1
    x[3764]   c916_1    -480
    x[3764]   c2452     1
    x[3765]   c917_1    -480
    x[3765]   c2453     1
    x[3766]   c918_1    -480
    x[3766]   c2454     1
    x[3767]   c919_1    -480
    x[3767]   c2455     1
    x[3768]   c920_1    -480
    x[3768]   c2456     1
    x[3769]   c921_1    -480
    x[3769]   c2457     1
    x[3770]   c922_1    -480
    x[3770]   c2458     1
    x[3771]   c923_1    -480
    x[3771]   c2459     1
    x[3772]   c924_1    -480
    x[3772]   c2460     1
    x[3773]   c925_1    -480
    x[3773]   c2461     1
    x[3774]   c926_1    -480
    x[3774]   c2462     1
    x[3775]   c927_1    -480
    x[3775]   c2463     1
    x[3776]   c928_1    -480
    x[3776]   c2464     1
    x[3777]   c929_1    -480
    x[3777]   c2465     1
    x[3778]   c930_1    -480
    x[3778]   c2466     1
    x[3779]   c931_1    -480
    x[3779]   c2467     1
    x[3780]   c932_1    -480
    x[3780]   c2468     1
    x[3781]   c933_1    -480
    x[3781]   c2469     1
    x[3782]   c934_1    -480
    x[3782]   c2470     1
    x[3783]   c935_1    -480
    x[3783]   c2471     1
    x[3784]   c936_1    -480
    x[3784]   c2472     1
    x[3785]   c937_1    -480
    x[3785]   c2473     1
    x[3786]   c938_1    -480
    x[3786]   c2474     1
    x[3787]   c939_1    -480
    x[3787]   c2475     1
    x[3788]   c940_1    -480
    x[3788]   c2476     1
    x[3789]   c941_1    -480
    x[3789]   c2477     1
    x[3790]   c942_1    -480
    x[3790]   c2478     1
    x[3791]   c943_1    -480
    x[3791]   c2479     1
    x[3792]   c944_1    -480
    x[3792]   c2480     1
    x[3793]   c945_1    -480
    x[3793]   c2481     1
    x[3794]   c946_1    -480
    x[3794]   c2482     1
    x[3795]   c947_1    -480
    x[3795]   c2483     1
    x[3796]   c948_1    -480
    x[3796]   c2484     1
    x[3797]   c949_1    -480
    x[3797]   c2485     1
    x[3798]   c950_1    -480
    x[3798]   c2486     1
    x[3799]   c951_1    -480
    x[3799]   c2487     1
    x[3800]   c952_1    -480
    x[3800]   c2488     1
    x[3801]   c953_1    -480
    x[3801]   c2489     1
    x[3802]   c954_1    -480
    x[3802]   c2490     1
    x[3803]   c955_1    -480
    x[3803]   c2491     1
    x[3804]   c956_1    -480
    x[3804]   c2492     1
    x[3805]   c957_1    -480
    x[3805]   c2493     1
    x[3806]   c958_1    -480
    x[3806]   c2494     1
    x[3807]   c959_1    -480
    x[3807]   c2495     1
    x[3808]   c960_1    -480
    x[3808]   c2496     1
    x[3809]   c961_1    -480
    x[3809]   c2497     1
    x[3810]   c962_1    -480
    x[3810]   c2498     1
    x[3811]   c963_1    -480
    x[3811]   c2499     1
    x[3812]   c964_1    -480
    x[3812]   c2500     1
    x[3813]   c965_1    -480
    x[3813]   c2501     1
    x[3814]   c966_1    -480
    x[3814]   c2502     1
    x[3815]   c967_1    -480
    x[3815]   c2503     1
    x[3816]   c968_1    -480
    x[3816]   c2504     1
    x[3817]   c969_1    -480
    x[3817]   c2505     1
    x[3818]   c970_1    -480
    x[3818]   c2506     1
    x[3819]   c971_1    -480
    x[3819]   c2507     1
    x[3820]   c972_1    -480
    x[3820]   c2508     1
    x[3821]   c973_1    -480
    x[3821]   c2509     1
    x[3822]   c974_1    -480
    x[3822]   c2510     1
    x[3823]   c975_1    -480
    x[3823]   c2511     1
    x[3824]   c976_1    -480
    x[3824]   c2512     1
    x[3825]   c977_1    -480
    x[3825]   c2513     1
    x[3826]   c978_1    -480
    x[3826]   c2514     1
    x[3827]   c979_1    -480
    x[3827]   c2515     1
    x[3828]   c980_1    -480
    x[3828]   c2516     1
    x[3829]   c981_1    -480
    x[3829]   c2517     1
    x[3830]   c982_1    -480
    x[3830]   c2518     1
    x[3831]   c983_1    -480
    x[3831]   c2519     1
    x[3832]   c984_1    -480
    x[3832]   c2520     1
    x[3833]   c985_1    -480
    x[3833]   c2521     1
    x[3834]   c986_1    -480
    x[3834]   c2522     1
    x[3835]   c987_1    -480
    x[3835]   c2523     1
    x[3836]   c988_1    -480
    x[3836]   c2524     1
    x[3837]   c989_1    -480
    x[3837]   c2525     1
    x[3838]   c990_1    -480
    x[3838]   c2526     1
    x[3839]   c991_1    -480
    x[3839]   c2527     1
    x[3840]   c992_1    -480
    x[3840]   c2528     1
    x[3841]   c993_1    -480
    x[3841]   c2529     1
    x[3842]   c994_1    -480
    x[3842]   c2530     1
    x[3843]   c995_1    -480
    x[3843]   c2531     1
    x[3844]   c996_1    -480
    x[3844]   c2532     1
    x[3845]   c997_1    -480
    x[3845]   c2533     1
    x[3846]   c998_1    -480
    x[3846]   c2534     1
    x[3847]   c999_1    -480
    x[3847]   c2535     1
    x[3848]   c1000_1   -480
    x[3848]   c2536     1
    x[3849]   c1001_1   -480
    x[3849]   c2537     1
    x[3850]   c1002_1   -480
    x[3850]   c2538     1
    x[3851]   c1003_1   -480
    x[3851]   c2539     1
    x[3852]   c1004_1   -480
    x[3852]   c2540     1
    x[3853]   c1005_1   -480
    x[3853]   c2541     1
    x[3854]   c1006_1   -480
    x[3854]   c2542     1
    x[3855]   c1007_1   -480
    x[3855]   c2543     1
    x[3856]   c1008_1   -480
    x[3856]   c2544     1
    x[3857]   c1009_1   -480
    x[3857]   c2545     1
    x[3858]   c1010_1   -480
    x[3858]   c2546     1
    x[3859]   c1011_1   -480
    x[3859]   c2547     1
    x[3860]   c1012_1   -480
    x[3860]   c2548     1
    x[3861]   c1013_1   -480
    x[3861]   c2549     1
    x[3862]   c1014_1   -480
    x[3862]   c2550     1
    x[3863]   c1015_1   -480
    x[3863]   c2551     1
    x[3864]   c1016_1   -480
    x[3864]   c2552     1
    x[3865]   c1017_1   -480
    x[3865]   c2553     1
    x[3866]   c1018_1   -480
    x[3866]   c2554     1
    x[3867]   c1019_1   -480
    x[3867]   c2555     1
    x[3868]   c1020_1   -480
    x[3868]   c2556     1
    x[3869]   c1021_1   -480
    x[3869]   c2557     1
    x[3870]   c1022_1   -480
    x[3870]   c2558     1
    x[3871]   c1023_1   -480
    x[3871]   c2559     1
    x[3872]   c1024_1   -480
    x[3872]   c2560     1
RHS
    rhs       c1_1      0
    rhs       c2_1      0
    rhs       c3_1      0
    rhs       c4_1      0
    rhs       c5_1      0
    rhs       c6_1      0
    rhs       c7_1      0
    rhs       c8_1      0
    rhs       c9_1      0
    rhs       c10_1     0
    rhs       c11_1     0
    rhs       c12_1     0
    rhs       c13_1     0
    rhs       c14_1     0
    rhs       c15_1     0
    rhs       c16_1     0
    rhs       c17_1     0
    rhs       c18_1     0
    rhs       c19_1     0
    rhs       c20_1     0
    rhs       c21_1     0
    rhs       c22_1     0
    rhs       c23_1     0
    rhs       c24_1     0
    rhs       c25_1     0
    rhs       c26_1     0
    rhs       c27_1     0
    rhs       c28_1     0
    rhs       c29_1     0
    rhs       c30_1     0
    rhs       c31_1     0
    rhs       c32_1     0
    rhs       c33_1     0
    rhs       c34_1     0
    rhs       c35_1     0
    rhs       c36_1     0
    rhs       c37_1     0
    rhs       c38_1     0
    rhs       c39_1     0
    rhs       c40_1     0
    rhs       c41_1     0
    rhs       c42_1     0
    rhs       c43_1     0
    rhs       c44_1     0
    rhs       c45_1     0
    rhs       c46_1     0
    rhs       c47_1     0
    rhs       c48_1     0
    rhs       c49_1     0
    rhs       c50_1     0
    rhs       c51_1     0
    rhs       c52_1     0
    rhs       c53_1     0
    rhs       c54_1     0
    rhs       c55_1     0
    rhs       c56_1     0
    rhs       c57_1     0
    rhs       c58_1     0
    rhs       c59_1     0
    rhs       c60_1     0
    rhs       c61_1     0
    rhs       c62_1     0
    rhs       c63_1     0
    rhs       c64_1     0
    rhs       c65_1     0
    rhs       c66_1     0
    rhs       c67_1     0
    rhs       c68_1     0
    rhs       c69_1     0
    rhs       c70_1     0
    rhs       c71_1     0
    rhs       c72_1     0
    rhs       c73_1     0
    rhs       c74_1     0
    rhs       c75_1     0
    rhs       c76_1     0
    rhs       c77_1     0
    rhs       c78_1     0
    rhs       c79_1     0
    rhs       c80_1     0
    rhs       c81_1     0
    rhs       c82_1     0
    rhs       c83_1     0
    rhs       c84_1     0
    rhs       c85_1     0
    rhs       c86_1     0
    rhs       c87_1     0
    rhs       c88_1     0
    rhs       c89_1     0
    rhs       c90_1     0
    rhs       c91_1     0
    rhs       c92_1     0
    rhs       c93_1     0
    rhs       c94_1     0
    rhs       c95_1     0
    rhs       c96_1     0
    rhs       c97_1     0
    rhs       c98_1     0
    rhs       c99_1     0
    rhs       c100_1    0
    rhs       c101_1    0
    rhs       c102_1    0
    rhs       c103_1    0
    rhs       c104_1    0
    rhs       c105_1    0
    rhs       c106_1    0
    rhs       c107_1    0
    rhs       c108_1    0
    rhs       c109_1    0
    rhs       c110_1    0
    rhs       c111_1    0
    rhs       c112_1    0
    rhs       c113_1    0
    rhs       c114_1    0
    rhs       c115_1    0
    rhs       c116_1    0
    rhs       c117_1    0
    rhs       c118_1    0
    rhs       c119_1    0
    rhs       c120_1    0
    rhs       c121_1    0
    rhs       c122_1    0
    rhs       c123_1    0
    rhs       c124_1    0
    rhs       c125_1    0
    rhs       c126_1    0
    rhs       c127_1    0
    rhs       c128_1    0
    rhs       c129_1    0
    rhs       c130_1    0
    rhs       c131_1    0
    rhs       c132_1    0
    rhs       c133_1    0
    rhs       c134_1    0
    rhs       c135_1    0
    rhs       c136_1    0
    rhs       c137_1    0
    rhs       c138_1    0
    rhs       c139_1    0
    rhs       c140_1    0
    rhs       c141_1    0
    rhs       c142_1    0
    rhs       c143_1    0
    rhs       c144_1    0
    rhs       c145_1    0
    rhs       c146_1    0
    rhs       c147_1    0
    rhs       c148_1    0
    rhs       c149_1    0
    rhs       c150_1    0
    rhs       c151_1    0
    rhs       c152_1    0
    rhs       c153_1    0
    rhs       c154_1    0
    rhs       c155_1    0
    rhs       c156_1    0
    rhs       c157_1    0
    rhs       c158_1    0
    rhs       c159_1    0
    rhs       c160_1    0
    rhs       c161_1    0
    rhs       c162_1    0
    rhs       c163_1    0
    rhs       c164_1    0
    rhs       c165_1    0
    rhs       c166_1    0
    rhs       c167_1    0
    rhs       c168_1    0
    rhs       c169_1    0
    rhs       c170_1    0
    rhs       c171_1    0
    rhs       c172_1    0
    rhs       c173_1    0
    rhs       c174_1    0
    rhs       c175_1    0
    rhs       c176_1    0
    rhs       c177_1    0
    rhs       c178_1    0
    rhs       c179_1    0
    rhs       c180_1    0
    rhs       c181_1    0
    rhs       c182_1    0
    rhs       c183_1    0
    rhs       c184_1    0
    rhs       c185_1    0
    rhs       c186_1    0
    rhs       c187_1    0
    rhs       c188_1    0
    rhs       c189_1    0
    rhs       c190_1    0
    rhs       c191_1    0
    rhs       c192_1    0
    rhs       c193_1    0
    rhs       c194_1    0
    rhs       c195_1    0
    rhs       c196_1    0
    rhs       c197_1    0
    rhs       c198_1    0
    rhs       c199_1    0
    rhs       c200_1    0
    rhs       c201_1    0
    rhs       c202_1    0
    rhs       c203_1    0
    rhs       c204_1    0
    rhs       c205_1    0
    rhs       c206_1    0
    rhs       c207_1    0
    rhs       c208_1    0
    rhs       c209_1    0
    rhs       c210_1    0
    rhs       c211_1    0
    rhs       c212_1    0
    rhs       c213_1    0
    rhs       c214_1    0
    rhs       c215_1    0
    rhs       c216_1    0
    rhs       c217_1    0
    rhs       c218_1    0
    rhs       c219_1    0
    rhs       c220_1    0
    rhs       c221_1    0
    rhs       c222_1    0
    rhs       c223_1    0
    rhs       c224_1    0
    rhs       c225_1    0
    rhs       c226_1    0
    rhs       c227_1    0
    rhs       c228_1    0
    rhs       c229_1    0
    rhs       c230_1    0
    rhs       c231_1    0
    rhs       c232_1    0
    rhs       c233_1    0
    rhs       c234_1    0
    rhs       c235_1    0
    rhs       c236_1    0
    rhs       c237_1    0
    rhs       c238_1    0
    rhs       c239_1    0
    rhs       c240_1    0
    rhs       c241_1    0
    rhs       c242_1    0
    rhs       c243_1    0
    rhs       c244_1    0
    rhs       c245_1    0
    rhs       c246_1    0
    rhs       c247_1    0
    rhs       c248_1    0
    rhs       c249_1    0
    rhs       c250_1    0
    rhs       c251_1    0
    rhs       c252_1    0
    rhs       c253_1    0
    rhs       c254_1    0
    rhs       c255_1    0
    rhs       c256_1    0
    rhs       c257_1    0
    rhs       c258_1    0
    rhs       c259_1    0
    rhs       c260_1    0
    rhs       c261_1    0
    rhs       c262_1    0
    rhs       c263_1    0
    rhs       c264_1    0
    rhs       c265_1    0
    rhs       c266_1    0
    rhs       c267_1    0
    rhs       c268_1    0
    rhs       c269_1    0
    rhs       c270_1    0
    rhs       c271_1    0
    rhs       c272_1    0
    rhs       c273_1    0
    rhs       c274_1    0
    rhs       c275_1    0
    rhs       c276_1    0
    rhs       c277_1    0
    rhs       c278_1    0
    rhs       c279_1    0
    rhs       c280_1    0
    rhs       c281_1    0
    rhs       c282_1    0
    rhs       c283_1    0
    rhs       c284_1    0
    rhs       c285_1    0
    rhs       c286_1    0
    rhs       c287_1    0
    rhs       c288_1    0
    rhs       c289_1    0
    rhs       c290_1    0
    rhs       c291_1    0
    rhs       c292_1    0
    rhs       c293_1    0
    rhs       c294_1    0
    rhs       c295_1    0
    rhs       c296_1    0
    rhs       c297_1    0
    rhs       c298_1    0
    rhs       c299_1    0
    rhs       c300_1    0
    rhs       c301_1    0
    rhs       c302_1    0
    rhs       c303_1    0
    rhs       c304_1    0
    rhs       c305_1    0
    rhs       c306_1    0
    rhs       c307_1    0
    rhs       c308_1    0
    rhs       c309_1    0
    rhs       c310_1    0
    rhs       c311_1    0
    rhs       c312_1    0
    rhs       c313_1    0
    rhs       c314_1    0
    rhs       c315_1    0
    rhs       c316_1    0
    rhs       c317_1    0
    rhs       c318_1    0
    rhs       c319_1    0
    rhs       c320_1    0
    rhs       c321_1    0
    rhs       c322_1    0
    rhs       c323_1    0
    rhs       c324_1    0
    rhs       c325_1    0
    rhs       c326_1    0
    rhs       c327_1    0
    rhs       c328_1    0
    rhs       c329_1    0
    rhs       c330_1    0
    rhs       c331_1    0
    rhs       c332_1    0
    rhs       c333_1    0
    rhs       c334_1    0
    rhs       c335_1    0
    rhs       c336_1    0
    rhs       c337_1    0
    rhs       c338_1    0
    rhs       c339_1    0
    rhs       c340_1    0
    rhs       c341_1    0
    rhs       c342_1    0
    rhs       c343_1    0
    rhs       c344_1    0
    rhs       c345_1    0
    rhs       c346_1    0
    rhs       c347_1    0
    rhs       c348_1    0
    rhs       c349_1    0
    rhs       c350_1    0
    rhs       c351_1    0
    rhs       c352_1    0
    rhs       c353_1    0
    rhs       c354_1    0
    rhs       c355_1    0
    rhs       c356_1    0
    rhs       c357_1    0
    rhs       c358_1    0
    rhs       c359_1    0
    rhs       c360_1    0
    rhs       c361_1    0
    rhs       c362_1    0
    rhs       c363_1    0
    rhs       c364_1    0
    rhs       c365_1    0
    rhs       c366_1    0
    rhs       c367_1    0
    rhs       c368_1    0
    rhs       c369_1    0
    rhs       c370_1    0
    rhs       c371_1    0
    rhs       c372_1    0
    rhs       c373_1    0
    rhs       c374_1    0
    rhs       c375_1    0
    rhs       c376_1    0
    rhs       c377_1    0
    rhs       c378_1    0
    rhs       c379_1    0
    rhs       c380_1    0
    rhs       c381_1    0
    rhs       c382_1    0
    rhs       c383_1    0
    rhs       c384_1    0
    rhs       c385_1    0
    rhs       c386_1    0
    rhs       c387_1    0
    rhs       c388_1    0
    rhs       c389_1    0
    rhs       c390_1    0
    rhs       c391_1    0
    rhs       c392_1    0
    rhs       c393_1    0
    rhs       c394_1    0
    rhs       c395_1    0
    rhs       c396_1    0
    rhs       c397_1    0
    rhs       c398_1    0
    rhs       c399_1    0
    rhs       c400_1    0
    rhs       c401_1    0
    rhs       c402_1    0
    rhs       c403_1    0
    rhs       c404_1    0
    rhs       c405_1    0
    rhs       c406_1    0
    rhs       c407_1    0
    rhs       c408_1    0
    rhs       c409_1    0
    rhs       c410_1    0
    rhs       c411_1    0
    rhs       c412_1    0
    rhs       c413_1    0
    rhs       c414_1    0
    rhs       c415_1    0
    rhs       c416_1    0
    rhs       c417_1    0
    rhs       c418_1    0
    rhs       c419_1    0
    rhs       c420_1    0
    rhs       c421_1    0
    rhs       c422_1    0
    rhs       c423_1    0
    rhs       c424_1    0
    rhs       c425_1    0
    rhs       c426_1    0
    rhs       c427_1    0
    rhs       c428_1    0
    rhs       c429_1    0
    rhs       c430_1    0
    rhs       c431_1    0
    rhs       c432_1    0
    rhs       c433_1    0
    rhs       c434_1    0
    rhs       c435_1    0
    rhs       c436_1    0
    rhs       c437_1    0
    rhs       c438_1    0
    rhs       c439_1    0
    rhs       c440_1    0
    rhs       c441_1    0
    rhs       c442_1    0
    rhs       c443_1    0
    rhs       c444_1    0
    rhs       c445_1    0
    rhs       c446_1    0
    rhs       c447_1    0
    rhs       c448_1    0
    rhs       c449_1    0
    rhs       c450_1    0
    rhs       c451_1    0
    rhs       c452_1    0
    rhs       c453_1    0
    rhs       c454_1    0
    rhs       c455_1    0
    rhs       c456_1    0
    rhs       c457_1    0
    rhs       c458_1    0
    rhs       c459_1    0
    rhs       c460_1    0
    rhs       c461_1    0
    rhs       c462_1    0
    rhs       c463_1    0
    rhs       c464_1    0
    rhs       c465_1    0
    rhs       c466_1    0
    rhs       c467_1    0
    rhs       c468_1    0
    rhs       c469_1    0
    rhs       c470_1    0
    rhs       c471_1    0
    rhs       c472_1    0
    rhs       c473_1    0
    rhs       c474_1    0
    rhs       c475_1    0
    rhs       c476_1    0
    rhs       c477_1    0
    rhs       c478_1    0
    rhs       c479_1    0
    rhs       c480_1    0
    rhs       c481_1    0
    rhs       c482_1    0
    rhs       c483_1    0
    rhs       c484_1    0
    rhs       c485_1    0
    rhs       c486_1    0
    rhs       c487_1    0
    rhs       c488_1    0
    rhs       c489_1    0
    rhs       c490_1    0
    rhs       c491_1    0
    rhs       c492_1    0
    rhs       c493_1    0
    rhs       c494_1    0
    rhs       c495_1    0
    rhs       c496_1    0
    rhs       c497_1    0
    rhs       c498_1    0
    rhs       c499_1    0
    rhs       c500_1    0
    rhs       c501_1    0
    rhs       c502_1    0
    rhs       c503_1    0
    rhs       c504_1    0
    rhs       c505_1    0
    rhs       c506_1    0
    rhs       c507_1    0
    rhs       c508_1    0
    rhs       c509_1    0
    rhs       c510_1    0
    rhs       c511_1    0
    rhs       c512_1    0
    rhs       c513_1    0
    rhs       c514_1    0
    rhs       c515_1    0
    rhs       c516_1    0
    rhs       c517_1    0
    rhs       c518_1    0
    rhs       c519_1    0
    rhs       c520_1    0
    rhs       c521_1    0
    rhs       c522_1    0
    rhs       c523_1    0
    rhs       c524_1    0
    rhs       c525_1    0
    rhs       c526_1    0
    rhs       c527_1    0
    rhs       c528_1    0
    rhs       c529_1    0
    rhs       c530_1    0
    rhs       c531_1    0
    rhs       c532_1    0
    rhs       c533_1    0
    rhs       c534_1    0
    rhs       c535_1    0
    rhs       c536_1    0
    rhs       c537_1    0
    rhs       c538_1    0
    rhs       c539_1    0
    rhs       c540_1    0
    rhs       c541_1    0
    rhs       c542_1    0
    rhs       c543_1    0
    rhs       c544_1    0
    rhs       c545_1    0
    rhs       c546_1    0
    rhs       c547_1    0
    rhs       c548_1    0
    rhs       c549_1    0
    rhs       c550_1    0
    rhs       c551_1    0
    rhs       c552_1    0
    rhs       c553_1    0
    rhs       c554_1    0
    rhs       c555_1    0
    rhs       c556_1    0
    rhs       c557_1    0
    rhs       c558_1    0
    rhs       c559_1    0
    rhs       c560_1    0
    rhs       c561_1    0
    rhs       c562_1    0
    rhs       c563_1    0
    rhs       c564_1    0
    rhs       c565_1    0
    rhs       c566_1    0
    rhs       c567_1    0
    rhs       c568_1    0
    rhs       c569_1    0
    rhs       c570_1    0
    rhs       c571_1    0
    rhs       c572_1    0
    rhs       c573_1    0
    rhs       c574_1    0
    rhs       c575_1    0
    rhs       c576_1    0
    rhs       c577_1    0
    rhs       c578_1    0
    rhs       c579_1    0
    rhs       c580_1    0
    rhs       c581_1    0
    rhs       c582_1    0
    rhs       c583_1    0
    rhs       c584_1    0
    rhs       c585_1    0
    rhs       c586_1    0
    rhs       c587_1    0
    rhs       c588_1    0
    rhs       c589_1    0
    rhs       c590_1    0
    rhs       c591_1    0
    rhs       c592_1    0
    rhs       c593_1    0
    rhs       c594_1    0
    rhs       c595_1    0
    rhs       c596_1    0
    rhs       c597_1    0
    rhs       c598_1    0
    rhs       c599_1    0
    rhs       c600_1    0
    rhs       c601_1    0
    rhs       c602_1    0
    rhs       c603_1    0
    rhs       c604_1    0
    rhs       c605_1    0
    rhs       c606_1    0
    rhs       c607_1    0
    rhs       c608_1    0
    rhs       c609_1    0
    rhs       c610_1    0
    rhs       c611_1    0
    rhs       c612_1    0
    rhs       c613_1    0
    rhs       c614_1    0
    rhs       c615_1    0
    rhs       c616_1    0
    rhs       c617_1    0
    rhs       c618_1    0
    rhs       c619_1    0
    rhs       c620_1    0
    rhs       c621_1    0
    rhs       c622_1    0
    rhs       c623_1    0
    rhs       c624_1    0
    rhs       c625_1    0
    rhs       c626_1    0
    rhs       c627_1    0
    rhs       c628_1    0
    rhs       c629_1    0
    rhs       c630_1    0
    rhs       c631_1    0
    rhs       c632_1    0
    rhs       c633_1    0
    rhs       c634_1    0
    rhs       c635_1    0
    rhs       c636_1    0
    rhs       c637_1    0
    rhs       c638_1    0
    rhs       c639_1    0
    rhs       c640_1    0
    rhs       c641_1    0
    rhs       c642_1    0
    rhs       c643_1    0
    rhs       c644_1    0
    rhs       c645_1    0
    rhs       c646_1    0
    rhs       c647_1    0
    rhs       c648_1    0
    rhs       c649_1    0
    rhs       c650_1    0
    rhs       c651_1    0
    rhs       c652_1    0
    rhs       c653_1    0
    rhs       c654_1    0
    rhs       c655_1    0
    rhs       c656_1    0
    rhs       c657_1    0
    rhs       c658_1    0
    rhs       c659_1    0
    rhs       c660_1    0
    rhs       c661_1    0
    rhs       c662_1    0
    rhs       c663_1    0
    rhs       c664_1    0
    rhs       c665_1    0
    rhs       c666_1    0
    rhs       c667_1    0
    rhs       c668_1    0
    rhs       c669_1    0
    rhs       c670_1    0
    rhs       c671_1    0
    rhs       c672_1    0
    rhs       c673_1    0
    rhs       c674_1    0
    rhs       c675_1    0
    rhs       c676_1    0
    rhs       c677_1    0
    rhs       c678_1    0
    rhs       c679_1    0
    rhs       c680_1    0
    rhs       c681_1    0
    rhs       c682_1    0
    rhs       c683_1    0
    rhs       c684_1    0
    rhs       c685_1    0
    rhs       c686_1    0
    rhs       c687_1    0
    rhs       c688_1    0
    rhs       c689_1    0
    rhs       c690_1    0
    rhs       c691_1    0
    rhs       c692_1    0
    rhs       c693_1    0
    rhs       c694_1    0
    rhs       c695_1    0
    rhs       c696_1    0
    rhs       c697_1    0
    rhs       c698_1    0
    rhs       c699_1    0
    rhs       c700_1    0
    rhs       c701_1    0
    rhs       c702_1    0
    rhs       c703_1    0
    rhs       c704_1    0
    rhs       c705_1    0
    rhs       c706_1    0
    rhs       c707_1    0
    rhs       c708_1    0
    rhs       c709_1    0
    rhs       c710_1    0
    rhs       c711_1    0
    rhs       c712_1    0
    rhs       c713_1    0
    rhs       c714_1    0
    rhs       c715_1    0
    rhs       c716_1    0
    rhs       c717_1    0
    rhs       c718_1    0
    rhs       c719_1    0
    rhs       c720_1    0
    rhs       c721_1    0
    rhs       c722_1    0
    rhs       c723_1    0
    rhs       c724_1    0
    rhs       c725_1    0
    rhs       c726_1    0
    rhs       c727_1    0
    rhs       c728_1    0
    rhs       c729_1    0
    rhs       c730_1    0
    rhs       c731_1    0
    rhs       c732_1    0
    rhs       c733_1    0
    rhs       c734_1    0
    rhs       c735_1    0
    rhs       c736_1    0
    rhs       c737_1    0
    rhs       c738_1    0
    rhs       c739_1    0
    rhs       c740_1    0
    rhs       c741_1    0
    rhs       c742_1    0
    rhs       c743_1    0
    rhs       c744_1    0
    rhs       c745_1    0
    rhs       c746_1    0
    rhs       c747_1    0
    rhs       c748_1    0
    rhs       c749_1    0
    rhs       c750_1    0
    rhs       c751_1    0
    rhs       c752_1    0
    rhs       c753_1    0
    rhs       c754_1    0
    rhs       c755_1    0
    rhs       c756_1    0
    rhs       c757_1    0
    rhs       c758_1    0
    rhs       c759_1    0
    rhs       c760_1    0
    rhs       c761_1    0
    rhs       c762_1    0
    rhs       c763_1    0
    rhs       c764_1    0
    rhs       c765_1    0
    rhs       c766_1    0
    rhs       c767_1    0
    rhs       c768_1    0
    rhs       c769_1    0
    rhs       c770_1    0
    rhs       c771_1    0
    rhs       c772_1    0
    rhs       c773_1    0
    rhs       c774_1    0
    rhs       c775_1    0
    rhs       c776_1    0
    rhs       c777_1    0
    rhs       c778_1    0
    rhs       c779_1    0
    rhs       c780_1    0
    rhs       c781_1    0
    rhs       c782_1    0
    rhs       c783_1    0
    rhs       c784_1    0
    rhs       c785_1    0
    rhs       c786_1    0
    rhs       c787_1    0
    rhs       c788_1    0
    rhs       c789_1    0
    rhs       c790_1    0
    rhs       c791_1    0
    rhs       c792_1    0
    rhs       c793_1    0
    rhs       c794_1    0
    rhs       c795_1    0
    rhs       c796_1    0
    rhs       c797_1    0
    rhs       c798_1    0
    rhs       c799_1    0
    rhs       c800_1    0
    rhs       c801_1    0
    rhs       c802_1    0
    rhs       c803_1    0
    rhs       c804_1    0
    rhs       c805_1    0
    rhs       c806_1    0
    rhs       c807_1    0
    rhs       c808_1    0
    rhs       c809_1    0
    rhs       c810_1    0
    rhs       c811_1    0
    rhs       c812_1    0
    rhs       c813_1    0
    rhs       c814_1    0
    rhs       c815_1    0
    rhs       c816_1    0
    rhs       c817_1    0
    rhs       c818_1    0
    rhs       c819_1    0
    rhs       c820_1    0
    rhs       c821_1    0
    rhs       c822_1    0
    rhs       c823_1    0
    rhs       c824_1    0
    rhs       c825_1    0
    rhs       c826_1    0
    rhs       c827_1    0
    rhs       c828_1    0
    rhs       c829_1    0
    rhs       c830_1    0
    rhs       c831_1    0
    rhs       c832_1    0
    rhs       c833_1    0
    rhs       c834_1    0
    rhs       c835_1    0
    rhs       c836_1    0
    rhs       c837_1    0
    rhs       c838_1    0
    rhs       c839_1    0
    rhs       c840_1    0
    rhs       c841_1    0
    rhs       c842_1    0
    rhs       c843_1    0
    rhs       c844_1    0
    rhs       c845_1    0
    rhs       c846_1    0
    rhs       c847_1    0
    rhs       c848_1    0
    rhs       c849_1    0
    rhs       c850_1    0
    rhs       c851_1    0
    rhs       c852_1    0
    rhs       c853_1    0
    rhs       c854_1    0
    rhs       c855_1    0
    rhs       c856_1    0
    rhs       c857_1    0
    rhs       c858_1    0
    rhs       c859_1    0
    rhs       c860_1    0
    rhs       c861_1    0
    rhs       c862_1    0
    rhs       c863_1    0
    rhs       c864_1    0
    rhs       c865_1    0
    rhs       c866_1    0
    rhs       c867_1    0
    rhs       c868_1    0
    rhs       c869_1    0
    rhs       c870_1    0
    rhs       c871_1    0
    rhs       c872_1    0
    rhs       c873_1    0
    rhs       c874_1    0
    rhs       c875_1    0
    rhs       c876_1    0
    rhs       c877_1    0
    rhs       c878_1    0
    rhs       c879_1    0
    rhs       c880_1    0
    rhs       c881_1    0
    rhs       c882_1    0
    rhs       c883_1    0
    rhs       c884_1    0
    rhs       c885_1    0
    rhs       c886_1    0
    rhs       c887_1    0
    rhs       c888_1    0
    rhs       c889_1    0
    rhs       c890_1    0
    rhs       c891_1    0
    rhs       c892_1    0
    rhs       c893_1    0
    rhs       c894_1    0
    rhs       c895_1    0
    rhs       c896_1    0
    rhs       c897_1    0
    rhs       c898_1    0
    rhs       c899_1    0
    rhs       c900_1    0
    rhs       c901_1    0
    rhs       c902_1    0
    rhs       c903_1    0
    rhs       c904_1    0
    rhs       c905_1    0
    rhs       c906_1    0
    rhs       c907_1    0
    rhs       c908_1    0
    rhs       c909_1    0
    rhs       c910_1    0
    rhs       c911_1    0
    rhs       c912_1    0
    rhs       c913_1    0
    rhs       c914_1    0
    rhs       c915_1    0
    rhs       c916_1    0
    rhs       c917_1    0
    rhs       c918_1    0
    rhs       c919_1    0
    rhs       c920_1    0
    rhs       c921_1    0
    rhs       c922_1    0
    rhs       c923_1    0
    rhs       c924_1    0
    rhs       c925_1    0
    rhs       c926_1    0
    rhs       c927_1    0
    rhs       c928_1    0
    rhs       c929_1    0
    rhs       c930_1    0
    rhs       c931_1    0
    rhs       c932_1    0
    rhs       c933_1    0
    rhs       c934_1    0
    rhs       c935_1    0
    rhs       c936_1    0
    rhs       c937_1    0
    rhs       c938_1    0
    rhs       c939_1    0
    rhs       c940_1    0
    rhs       c941_1    0
    rhs       c942_1    0
    rhs       c943_1    0
    rhs       c944_1    0
    rhs       c945_1    0
    rhs       c946_1    0
    rhs       c947_1    0
    rhs       c948_1    0
    rhs       c949_1    0
    rhs       c950_1    0
    rhs       c951_1    0
    rhs       c952_1    0
    rhs       c953_1    0
    rhs       c954_1    0
    rhs       c955_1    0
    rhs       c956_1    0
    rhs       c957_1    0
    rhs       c958_1    0
    rhs       c959_1    0
    rhs       c960_1    0
    rhs       c961_1    0
    rhs       c962_1    0
    rhs       c963_1    0
    rhs       c964_1    0
    rhs       c965_1    0
    rhs       c966_1    0
    rhs       c967_1    0
    rhs       c968_1    0
    rhs       c969_1    0
    rhs       c970_1    0
    rhs       c971_1    0
    rhs       c972_1    0
    rhs       c973_1    0
    rhs       c974_1    0
    rhs       c975_1    0
    rhs       c976_1    0
    rhs       c977_1    0
    rhs       c978_1    0
    rhs       c979_1    0
    rhs       c980_1    0
    rhs       c981_1    0
    rhs       c982_1    0
    rhs       c983_1    0
    rhs       c984_1    0
    rhs       c985_1    0
    rhs       c986_1    0
    rhs       c987_1    0
    rhs       c988_1    0
    rhs       c989_1    0
    rhs       c990_1    0
    rhs       c991_1    0
    rhs       c992_1    0
    rhs       c993_1    0
    rhs       c994_1    0
    rhs       c995_1    0
    rhs       c996_1    0
    rhs       c997_1    0
    rhs       c998_1    0
    rhs       c999_1    0
    rhs       c1000_1   0
    rhs       c1001_1   0
    rhs       c1002_1   0
    rhs       c1003_1   0
    rhs       c1004_1   0
    rhs       c1005_1   0
    rhs       c1006_1   0
    rhs       c1007_1   0
    rhs       c1008_1   0
    rhs       c1009_1   0
    rhs       c1010_1   0
    rhs       c1011_1   0
    rhs       c1012_1   0
    rhs       c1013_1   0
    rhs       c1014_1   0
    rhs       c1015_1   0
    rhs       c1016_1   0
    rhs       c1017_1   0
    rhs       c1018_1   0
    rhs       c1019_1   0
    rhs       c1020_1   0
    rhs       c1021_1   0
    rhs       c1022_1   0
    rhs       c1023_1   0
    rhs       c1024_1   0
    rhs       c1025_1   0
    rhs       c1026_1   0
    rhs       c1027_1   0
    rhs       c1028_1   0
    rhs       c1029_1   0
    rhs       c1030_1   0
    rhs       c1031_1   0
    rhs       c1032_1   0
    rhs       c1033_1   0
    rhs       c1034_1   0
    rhs       c1035_1   0
    rhs       c1036_1   0
    rhs       c1037_1   0
    rhs       c1038_1   0
    rhs       c1039_1   0
    rhs       c1040_1   0
    rhs       c1041_1   0
    rhs       c1042_1   0
    rhs       c1043_1   0
    rhs       c1044_1   0
    rhs       c1045_1   0
    rhs       c1046_1   0
    rhs       c1047_1   0
    rhs       c1048_1   0
    rhs       c1049_1   0
    rhs       c1050_1   0
    rhs       c1051_1   0
    rhs       c1052_1   0
    rhs       c1053_1   0
    rhs       c1054_1   0
    rhs       c1055_1   0
    rhs       c1056_1   0
    rhs       c1057_1   0
    rhs       c1058_1   0
    rhs       c1059_1   0
    rhs       c1060_1   0
    rhs       c1061_1   0
    rhs       c1062_1   0
    rhs       c1063_1   0
    rhs       c1064_1   0
    rhs       c1065_1   0
    rhs       c1066_1   0
    rhs       c1067_1   0
    rhs       c1068_1   0
    rhs       c1069_1   0
    rhs       c1070_1   0
    rhs       c1071_1   0
    rhs       c1072_1   0
    rhs       c1073_1   0
    rhs       c1074_1   0
    rhs       c1075_1   0
    rhs       c1076_1   0
    rhs       c1077_1   0
    rhs       c1078_1   0
    rhs       c1079_1   0
    rhs       c1080_1   0
    rhs       c1081_1   0
    rhs       c1082_1   0
    rhs       c1083_1   0
    rhs       c1084_1   0
    rhs       c1085_1   0
    rhs       c1086_1   0
    rhs       c1087_1   0
    rhs       c1088_1   0
    rhs       c1089_1   0
    rhs       c1090_1   0
    rhs       c1091_1   0
    rhs       c1092_1   0
    rhs       c1093_1   0
    rhs       c1094_1   0
    rhs       c1095_1   0
    rhs       c1096_1   0
    rhs       c1097_1   0
    rhs       c1098_1   0
    rhs       c1099_1   0
    rhs       c1100_1   0
    rhs       c1101_1   0
    rhs       c1102_1   0
    rhs       c1103_1   0
    rhs       c1104_1   0
    rhs       c1105_1   0
    rhs       c1106_1   0
    rhs       c1107_1   0
    rhs       c1108_1   0
    rhs       c1109_1   0
    rhs       c1110_1   0
    rhs       c1111_1   0
    rhs       c1112_1   0
    rhs       c1113_1   0
    rhs       c1114_1   0
    rhs       c1115_1   0
    rhs       c1116_1   0
    rhs       c1117_1   0
    rhs       c1118_1   0
    rhs       c1119_1   0
    rhs       c1120_1   0
    rhs       c1121_1   0
    rhs       c1122_1   0
    rhs       c1123_1   0
    rhs       c1124_1   0
    rhs       c1125_1   0
    rhs       c1126_1   0
    rhs       c1127_1   0
    rhs       c1128_1   0
    rhs       c1129_1   0
    rhs       c1130_1   0
    rhs       c1131_1   0
    rhs       c1132_1   0
    rhs       c1133_1   0
    rhs       c1134_1   0
    rhs       c1135_1   0
    rhs       c1136_1   0
    rhs       c1137_1   0
    rhs       c1138_1   0
    rhs       c1139_1   0
    rhs       c1140_1   0
    rhs       c1141_1   0
    rhs       c1142_1   0
    rhs       c1143_1   0
    rhs       c1144_1   0
    rhs       c1145_1   0
    rhs       c1146_1   0
    rhs       c1147_1   0
    rhs       c1148_1   0
    rhs       c1149_1   0
    rhs       c1150_1   0
    rhs       c1151_1   0
    rhs       c1152_1   0
    rhs       c1153_1   0
    rhs       c1154_1   0
    rhs       c1155_1   0
    rhs       c1156_1   0
    rhs       c1157_1   0
    rhs       c1158_1   0
    rhs       c1159_1   0
    rhs       c1160_1   0
    rhs       c1161_1   0
    rhs       c1162_1   0
    rhs       c1163_1   0
    rhs       c1164_1   0
    rhs       c1165_1   0
    rhs       c1166_1   0
    rhs       c1167_1   0
    rhs       c1168_1   0
    rhs       c1169_1   0
    rhs       c1170_1   0
    rhs       c1171_1   0
    rhs       c1172_1   0
    rhs       c1173_1   0
    rhs       c1174_1   0
    rhs       c1175_1   0
    rhs       c1176_1   0
    rhs       c1177_1   0
    rhs       c1178_1   0
    rhs       c1179_1   0
    rhs       c1180_1   0
    rhs       c1181_1   0
    rhs       c1182_1   0
    rhs       c1183_1   0
    rhs       c1184_1   0
    rhs       c1185_1   0
    rhs       c1186_1   0
    rhs       c1187_1   0
    rhs       c1188_1   0
    rhs       c1189_1   0
    rhs       c1190_1   0
    rhs       c1191_1   0
    rhs       c1192_1   0
    rhs       c1193_1   0
    rhs       c1194_1   0
    rhs       c1195_1   0
    rhs       c1196_1   0
    rhs       c1197_1   0
    rhs       c1198_1   0
    rhs       c1199_1   0
    rhs       c1200_1   0
    rhs       c1201_1   0
    rhs       c1202_1   0
    rhs       c1203_1   0
    rhs       c1204_1   0
    rhs       c1205_1   0
    rhs       c1206_1   0
    rhs       c1207_1   0
    rhs       c1208_1   0
    rhs       c1209_1   0
    rhs       c1210_1   0
    rhs       c1211_1   0
    rhs       c1212_1   0
    rhs       c1213_1   0
    rhs       c1214_1   0
    rhs       c1215_1   0
    rhs       c1216_1   0
    rhs       c1217_1   0
    rhs       c1218_1   0
    rhs       c1219_1   0
    rhs       c1220_1   0
    rhs       c1221_1   0
    rhs       c1222_1   0
    rhs       c1223_1   0
    rhs       c1224_1   0
    rhs       c1225_1   0
    rhs       c1226_1   0
    rhs       c1227_1   0
    rhs       c1228_1   0
    rhs       c1229_1   0
    rhs       c1230_1   0
    rhs       c1231_1   0
    rhs       c1232_1   0
    rhs       c1233_1   0
    rhs       c1234_1   0
    rhs       c1235_1   0
    rhs       c1236_1   0
    rhs       c1237_1   0
    rhs       c1238_1   0
    rhs       c1239_1   0
    rhs       c1240_1   0
    rhs       c1241_1   0
    rhs       c1242_1   0
    rhs       c1243_1   0
    rhs       c1244_1   0
    rhs       c1245_1   0
    rhs       c1246_1   0
    rhs       c1247_1   0
    rhs       c1248_1   0
    rhs       c1249_1   0
    rhs       c1250_1   0
    rhs       c1251_1   0
    rhs       c1252_1   0
    rhs       c1253_1   0
    rhs       c1254_1   0
    rhs       c1255_1   0
    rhs       c1256_1   0
    rhs       c1257_1   0
    rhs       c1258_1   0
    rhs       c1259_1   0
    rhs       c1260_1   0
    rhs       c1261_1   0
    rhs       c1262_1   0
    rhs       c1263_1   0
    rhs       c1264_1   0
    rhs       c1265_1   0
    rhs       c1266_1   0
    rhs       c1267_1   0
    rhs       c1268_1   0
    rhs       c1269_1   0
    rhs       c1270_1   0
    rhs       c1271_1   0
    rhs       c1272_1   0
    rhs       c1273_1   0
    rhs       c1274_1   0
    rhs       c1275_1   0
    rhs       c1276_1   0
    rhs       c1277_1   0
    rhs       c1278_1   0
    rhs       c1279_1   0
    rhs       c1280_1   0
    rhs       c1281_1   0
    rhs       c1282_1   0
    rhs       c1283_1   0
    rhs       c1284_1   0
    rhs       c1285_1   0
    rhs       c1286_1   0
    rhs       c1287_1   0
    rhs       c1288_1   0
    rhs       c1289_1   0
    rhs       c1290_1   0
    rhs       c1291_1   0
    rhs       c1292_1   0
    rhs       c1293_1   0
    rhs       c1294_1   0
    rhs       c1295_1   0
    rhs       c1296_1   0
    rhs       c1297_1   0
    rhs       c1298_1   0
    rhs       c1299_1   0
    rhs       c1300_1   0
    rhs       c1301_1   0
    rhs       c1302_1   0
    rhs       c1303_1   0
    rhs       c1304_1   0
    rhs       c1305_1   0
    rhs       c1306_1   0
    rhs       c1307_1   0
    rhs       c1308_1   0
    rhs       c1309_1   0
    rhs       c1310_1   0
    rhs       c1311_1   0
    rhs       c1312_1   0
    rhs       c1313_1   0
    rhs       c1314_1   0
    rhs       c1315_1   0
    rhs       c1316_1   0
    rhs       c1317_1   0
    rhs       c1318_1   0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
    rhs       c1981     0
    rhs       c1982     0
    rhs       c1983     0
    rhs       c1984     0
    rhs       c1985     0
    rhs       c1986     0
    rhs       c1987     0
    rhs       c1988     0
    rhs       c1989     0
    rhs       c1990     0
    rhs       c1991     0
    rhs       c1992     0
    rhs       c1993     0
    rhs       c1994     0
    rhs       c1995     0
    rhs       c1996     0
    rhs       c1997     0
    rhs       c1998     0
    rhs       c1999     0
    rhs       c2000     0
    rhs       c2001     0
    rhs       c2002     0
    rhs       c2003     0
    rhs       c2004     0
    rhs       c2005     0
    rhs       c2006     0
    rhs       c2007     0
    rhs       c2008     0
    rhs       c2009     0
    rhs       c2010     0
    rhs       c2011     0
    rhs       c2012     0
    rhs       c2013     0
    rhs       c2014     0
    rhs       c2015     0
    rhs       c2016     0
    rhs       c2017     0
    rhs       c2018     0
    rhs       c2019     0
    rhs       c2020     0
    rhs       c2021     0
    rhs       c2022     0
    rhs       c2023     0
    rhs       c2024     0
    rhs       c2025     0
    rhs       c2026     0
    rhs       c2027     0
    rhs       c2028     0
    rhs       c2029     0
    rhs       c2030     0
    rhs       c2031     0
    rhs       c2032     0
    rhs       c2033     0
    rhs       c2034     0
    rhs       c2035     0
    rhs       c2036     0
    rhs       c2037     0
    rhs       c2038     0
    rhs       c2039     0
    rhs       c2040     0
    rhs       c2041     0
    rhs       c2042     0
    rhs       c2043     0
    rhs       c2044     0
    rhs       c2045     0
    rhs       c2046     0
    rhs       c2047     0
    rhs       c2048     0
    rhs       c2049     0
    rhs       c2050     0
    rhs       c2051     0
    rhs       c2052     0
    rhs       c2053     0
    rhs       c2054     0
    rhs       c2055     0
    rhs       c2056     0
    rhs       c2057     0
    rhs       c2058     0
    rhs       c2059     0
    rhs       c2060     0
    rhs       c2061     0
    rhs       c2062     0
    rhs       c2063     0
    rhs       c2064     0
    rhs       c2065     0
    rhs       c2066     0
    rhs       c2067     0
    rhs       c2068     0
    rhs       c2069     0
    rhs       c2070     0
    rhs       c2071     0
    rhs       c2072     0
    rhs       c2073     0
    rhs       c2074     0
    rhs       c2075     0
    rhs       c2076     0
    rhs       c2077     0
    rhs       c2078     0
    rhs       c2079     0
    rhs       c2080     0
    rhs       c2081     0
    rhs       c2082     0
    rhs       c2083     0
    rhs       c2084     0
    rhs       c2085     0
    rhs       c2086     0
    rhs       c2087     0
    rhs       c2088     0
    rhs       c2089     0
    rhs       c2090     0
    rhs       c2091     0
    rhs       c2092     0
    rhs       c2093     0
    rhs       c2094     0
    rhs       c2095     0
    rhs       c2096     0
    rhs       c2097     0
    rhs       c2098     0
    rhs       c2099     0
    rhs       c2100     0
    rhs       c2101     0
    rhs       c2102     0
    rhs       c2103     0
    rhs       c2104     0
    rhs       c2105     0
    rhs       c2106     0
    rhs       c2107     0
    rhs       c2108     0
    rhs       c2109     0
    rhs       c2110     0
    rhs       c2111     0
    rhs       c2112     0
    rhs       c2113     0
    rhs       c2114     0
    rhs       c2115     0
    rhs       c2116     0
    rhs       c2117     0
    rhs       c2118     0
    rhs       c2119     0
    rhs       c2120     0
    rhs       c2121     0
    rhs       c2122     0
    rhs       c2123     0
    rhs       c2124     0
    rhs       c2125     0
    rhs       c2126     0
    rhs       c2127     0
    rhs       c2128     0
    rhs       c2129     0
    rhs       c2130     0
    rhs       c2131     0
    rhs       c2132     0
    rhs       c2133     0
    rhs       c2134     0
    rhs       c2135     0
    rhs       c2136     0
    rhs       c2137     0
    rhs       c2138     0
    rhs       c2139     0
    rhs       c2140     0
    rhs       c2141     0
    rhs       c2142     0
    rhs       c2143     0
    rhs       c2144     0
    rhs       c2145     0
    rhs       c2146     0
    rhs       c2147     0
    rhs       c2148     0
    rhs       c2149     0
    rhs       c2150     0
    rhs       c2151     0
    rhs       c2152     0
    rhs       c2153     0
    rhs       c2154     0
    rhs       c2155     0
    rhs       c2156     0
    rhs       c2157     0
    rhs       c2158     0
    rhs       c2159     0
    rhs       c2160     0
    rhs       c2161     0
    rhs       c2162     0
    rhs       c2163     0
    rhs       c2164     0
    rhs       c2165     0
    rhs       c2166     0
    rhs       c2167     0
    rhs       c2168     0
    rhs       c2169     0
    rhs       c2170     0
    rhs       c2171     0
    rhs       c2172     0
    rhs       c2173     0
    rhs       c2174     0
    rhs       c2175     0
    rhs       c2176     0
    rhs       c2177     0
    rhs       c2178     0
    rhs       c2179     0
    rhs       c2180     0
    rhs       c2181     0
    rhs       c2182     0
    rhs       c2183     0
    rhs       c2184     0
    rhs       c2185     0
    rhs       c2186     0
    rhs       c2187     0
    rhs       c2188     0
    rhs       c2189     0
    rhs       c2190     0
    rhs       c2191     0
    rhs       c2192     0
    rhs       c2193     0
    rhs       c2194     0
    rhs       c2195     0
    rhs       c2196     0
    rhs       c2197     0
    rhs       c2198     0
    rhs       c2199     0
    rhs       c2200     0
    rhs       c2201     0
    rhs       c2202     0
    rhs       c2203     0
    rhs       c2204     0
    rhs       c2205     0
    rhs       c2206     0
    rhs       c2207     0
    rhs       c2208     0
    rhs       c2209     0
    rhs       c2210     0
    rhs       c2211     0
    rhs       c2212     0
    rhs       c2213     0
    rhs       c2214     0
    rhs       c2215     0
    rhs       c2216     0
    rhs       c2217     0
    rhs       c2218     0
    rhs       c2219     0
    rhs       c2220     0
    rhs       c2221     0
    rhs       c2222     0
    rhs       c2223     0
    rhs       c2224     0
    rhs       c2225     0
    rhs       c2226     0
    rhs       c2227     0
    rhs       c2228     0
    rhs       c2229     0
    rhs       c2230     0
    rhs       c2231     0
    rhs       c2232     0
    rhs       c2233     0
    rhs       c2234     0
    rhs       c2235     0
    rhs       c2236     0
    rhs       c2237     0
    rhs       c2238     0
    rhs       c2239     0
    rhs       c2240     0
    rhs       c2241     0
    rhs       c2242     0
    rhs       c2243     0
    rhs       c2244     0
    rhs       c2245     0
    rhs       c2246     0
    rhs       c2247     0
    rhs       c2248     0
    rhs       c2249     0
    rhs       c2250     0
    rhs       c2251     0
    rhs       c2252     0
    rhs       c2253     0
    rhs       c2254     0
    rhs       c2255     0
    rhs       c2256     0
    rhs       c2257     0
    rhs       c2258     0
    rhs       c2259     0
    rhs       c2260     0
    rhs       c2261     0
    rhs       c2262     0
    rhs       c2263     0
    rhs       c2264     0
    rhs       c2265     0
    rhs       c2266     0
    rhs       c2267     0
    rhs       c2268     0
    rhs       c2269     0
    rhs       c2270     0
    rhs       c2271     0
    rhs       c2272     0
    rhs       c2273     0
    rhs       c2274     0
    rhs       c2275     0
    rhs       c2276     0
    rhs       c2277     0
    rhs       c2278     0
    rhs       c2279     0
    rhs       c2280     0
    rhs       c2281     0
    rhs       c2282     0
    rhs       c2283     0
    rhs       c2284     0
    rhs       c2285     0
    rhs       c2286     0
    rhs       c2287     0
    rhs       c2288     0
    rhs       c2289     0
    rhs       c2290     0
    rhs       c2291     0
    rhs       c2292     0
    rhs       c2293     0
    rhs       c2294     0
    rhs       c2295     0
    rhs       c2296     0
    rhs       c2297     0
    rhs       c2298     0
    rhs       c2299     0
    rhs       c2300     0
    rhs       c2301     0
    rhs       c2302     0
    rhs       c2303     0
    rhs       c2304     0
    rhs       c2305     0
    rhs       c2306     0
    rhs       c2307     0
    rhs       c2308     0
    rhs       c2309     0
    rhs       c2310     0
    rhs       c2311     0
    rhs       c2312     0
    rhs       c2313     0
    rhs       c2314     0
    rhs       c2315     0
    rhs       c2316     0
    rhs       c2317     0
    rhs       c2318     0
    rhs       c2319     0
    rhs       c2320     0
    rhs       c2321     0
    rhs       c2322     0
    rhs       c2323     0
    rhs       c2324     0
    rhs       c2325     0
    rhs       c2326     0
    rhs       c2327     0
    rhs       c2328     0
    rhs       c2329     0
    rhs       c2330     0
    rhs       c2331     0
    rhs       c2332     0
    rhs       c2333     0
    rhs       c2334     0
    rhs       c2335     0
    rhs       c2336     0
    rhs       c2337     0
    rhs       c2338     0
    rhs       c2339     0
    rhs       c2340     0
    rhs       c2341     0
    rhs       c2342     0
    rhs       c2343     0
    rhs       c2344     0
    rhs       c2345     0
    rhs       c2346     0
    rhs       c2347     0
    rhs       c2348     0
    rhs       c2349     0
    rhs       c2350     0
    rhs       c2351     0
    rhs       c2352     0
    rhs       c2353     0
    rhs       c2354     0
    rhs       c2355     0
    rhs       c2356     0
    rhs       c2357     0
    rhs       c2358     0
    rhs       c2359     0
    rhs       c2360     0
    rhs       c2361     0
    rhs       c2362     0
    rhs       c2363     0
    rhs       c2364     0
    rhs       c2365     0
    rhs       c2366     0
    rhs       c2367     0
    rhs       c2368     0
    rhs       c2369     0
    rhs       c2370     0
    rhs       c2371     0
    rhs       c2372     0
    rhs       c2373     0
    rhs       c2374     0
    rhs       c2375     0
    rhs       c2376     0
    rhs       c2377     0
    rhs       c2378     0
    rhs       c2379     0
    rhs       c2380     0
    rhs       c2381     0
    rhs       c2382     0
    rhs       c2383     0
    rhs       c2384     0
    rhs       c2385     0
    rhs       c2386     0
    rhs       c2387     0
    rhs       c2388     0
    rhs       c2389     0
    rhs       c2390     0
    rhs       c2391     0
    rhs       c2392     0
    rhs       c2393     0
    rhs       c2394     0
    rhs       c2395     0
    rhs       c2396     0
    rhs       c2397     0
    rhs       c2398     0
    rhs       c2399     0
    rhs       c2400     0
    rhs       c2401     0
    rhs       c2402     0
    rhs       c2403     0
    rhs       c2404     0
    rhs       c2405     0
    rhs       c2406     0
    rhs       c2407     0
    rhs       c2408     0
    rhs       c2409     0
    rhs       c2410     0
    rhs       c2411     0
    rhs       c2412     0
    rhs       c2413     0
    rhs       c2414     0
    rhs       c2415     0
    rhs       c2416     0
    rhs       c2417     0
    rhs       c2418     0
    rhs       c2419     0
    rhs       c2420     0
    rhs       c2421     0
    rhs       c2422     0
    rhs       c2423     0
    rhs       c2424     0
    rhs       c2425     0
    rhs       c2426     0
    rhs       c2427     0
    rhs       c2428     0
    rhs       c2429     0
    rhs       c2430     0
    rhs       c2431     0
    rhs       c2432     0
    rhs       c2433     0
    rhs       c2434     0
    rhs       c2435     0
    rhs       c2436     0
    rhs       c2437     0
    rhs       c2438     0
    rhs       c2439     0
    rhs       c2440     0
    rhs       c2441     0
    rhs       c2442     0
    rhs       c2443     0
    rhs       c2444     0
    rhs       c2445     0
    rhs       c2446     0
    rhs       c2447     0
    rhs       c2448     0
    rhs       c2449     0
    rhs       c2450     0
    rhs       c2451     0
    rhs       c2452     0
    rhs       c2453     0
    rhs       c2454     0
    rhs       c2455     0
    rhs       c2456     0
    rhs       c2457     0
    rhs       c2458     0
    rhs       c2459     0
    rhs       c2460     0
    rhs       c2461     0
    rhs       c2462     0
    rhs       c2463     0
    rhs       c2464     0
    rhs       c2465     0
    rhs       c2466     0
    rhs       c2467     0
    rhs       c2468     0
    rhs       c2469     0
    rhs       c2470     0
    rhs       c2471     0
    rhs       c2472     0
    rhs       c2473     0
    rhs       c2474     0
    rhs       c2475     0
    rhs       c2476     0
    rhs       c2477     0
    rhs       c2478     0
    rhs       c2479     0
    rhs       c2480     0
    rhs       c2481     0
    rhs       c2482     0
    rhs       c2483     0
    rhs       c2484     0
    rhs       c2485     0
    rhs       c2486     0
    rhs       c2487     0
    rhs       c2488     0
    rhs       c2489     0
    rhs       c2490     0
    rhs       c2491     0
    rhs       c2492     0
    rhs       c2493     0
    rhs       c2494     0
    rhs       c2495     0
    rhs       c2496     0
    rhs       c2497     0
    rhs       c2498     0
    rhs       c2499     0
    rhs       c2500     0
    rhs       c2501     0
    rhs       c2502     0
    rhs       c2503     0
    rhs       c2504     0
    rhs       c2505     0
    rhs       c2506     0
    rhs       c2507     0
    rhs       c2508     0
    rhs       c2509     0
    rhs       c2510     0
    rhs       c2511     0
    rhs       c2512     0
    rhs       c2513     0
    rhs       c2514     0
    rhs       c2515     0
    rhs       c2516     0
    rhs       c2517     0
    rhs       c2518     0
    rhs       c2519     0
    rhs       c2520     0
    rhs       c2521     0
    rhs       c2522     0
    rhs       c2523     0
    rhs       c2524     0
    rhs       c2525     0
    rhs       c2526     0
    rhs       c2527     0
    rhs       c2528     0
    rhs       c2529     0
    rhs       c2530     0
    rhs       c2531     0
    rhs       c2532     0
    rhs       c2533     0
    rhs       c2534     0
    rhs       c2535     0
    rhs       c2536     0
    rhs       c2537     0
    rhs       c2538     0
    rhs       c2539     0
    rhs       c2540     0
    rhs       c2541     0
    rhs       c2542     0
    rhs       c2543     0
    rhs       c2544     0
    rhs       c2545     0
    rhs       c2546     0
    rhs       c2547     0
    rhs       c2548     0
    rhs       c2549     0
    rhs       c2550     0
    rhs       c2551     0
    rhs       c2552     0
    rhs       c2553     0
    rhs       c2554     0
    rhs       c2555     0
    rhs       c2556     0
    rhs       c2557     0
    rhs       c2558     0
    rhs       c2559     0
    rhs       c2560     0
    rhs       c2561     7500
    rhs       c2562     7500
    rhs       c2563     7500
    rhs       c2564     7500
    rhs       c2565     7500
    rhs       c2566     7500
    rhs       c2567     7500
    rhs       c2568     7500
    rhs       c2569     7500
    rhs       c2570     7500
    rhs       c2571     7500
    rhs       c2572     7500
    rhs       c2573     7500
    rhs       c2574     7500
    rhs       c2575     7500
    rhs       c2576     7500
    rhs       c2577     400
    rhs       c2578     400
    rhs       c2579     400
    rhs       c2580     400
    rhs       c2581     400
    rhs       c2582     400
    rhs       c2583     400
    rhs       c2584     400
    rhs       c2585     400
    rhs       c2586     400
    rhs       c2587     400
    rhs       c2588     400
    rhs       c2589     400
    rhs       c2590     400
    rhs       c2591     400
    rhs       c2592     400
    rhs       c2593     120
    rhs       c2594     120
    rhs       c2595     120
    rhs       c2596     120
    rhs       c2597     120
    rhs       c2598     120
    rhs       c2599     120
    rhs       c2600     120
    rhs       c2601     120
    rhs       c2602     120
    rhs       c2603     120
    rhs       c2604     120
    rhs       c2605     120
    rhs       c2606     120
    rhs       c2607     120
    rhs       c2608     120
    rhs       c2609     120
    rhs       c2610     120
    rhs       c2611     120
    rhs       c2612     120
    rhs       c2613     120
    rhs       c2614     120
    rhs       c2615     120
    rhs       c2616     120
    rhs       c2617     120
    rhs       c2618     120
    rhs       c2619     120
    rhs       c2620     120
    rhs       c2621     120
    rhs       c2622     120
    rhs       c2623     120
    rhs       c2624     120
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      0
    rhs       c262      0
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      0
    rhs       c275      0
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      0
    rhs       c289      0
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      0
    rhs       c299      0
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      0
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      0
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      0
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     1
    rhs       c1028     1
    rhs       c1029     2
    rhs       c1030     3
    rhs       c1031     0
    rhs       c1032     5
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     5
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     1
    rhs       c1039     1
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     1
    rhs       c1043     1
    rhs       c1044     2
    rhs       c1045     0
    rhs       c1046     1
    rhs       c1047     2
    rhs       c1048     4
    rhs       c1049     5
    rhs       c1050     1
    rhs       c1051     1
    rhs       c1052     4
    rhs       c1053     0
    rhs       c1054     3
    rhs       c1055     2
    rhs       c1056     3
    rhs       c1057     0
    rhs       c1058     1
    rhs       c1059     3
    rhs       c1060     7
    rhs       c1061     8
    rhs       c1062     6
    rhs       c1063     7
    rhs       c1064     9
    rhs       c1065     10
    rhs       c1066     6
    rhs       c1067     9
    rhs       c1068     9
    rhs       c1069     10
    rhs       c1070     10
    rhs       c1071     7
    rhs       c1072     6
    rhs       c1073     0
    rhs       c1074     1
    rhs       c1075     3
    rhs       c1076     5
    rhs       c1077     5
    rhs       c1078     5
    rhs       c1079     8
    rhs       c1080     9
    rhs       c1081     5
    rhs       c1082     10
    rhs       c1083     9
    rhs       c1084     9
    rhs       c1085     7
    rhs       c1086     9
    rhs       c1087     7
    rhs       c1088     10
    rhs       c1089     0
    rhs       c1090     5
    rhs       c1091     0
    rhs       c1092     14
    rhs       c1093     0
    rhs       c1094     20
    rhs       c1095     21
    rhs       c1096     0
    rhs       c1097     18
    rhs       c1098     17
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     18
    rhs       c1102     18
    rhs       c1103     18
    rhs       c1104     18
    rhs       c1105     0
    rhs       c1106     4
    rhs       c1107     0
    rhs       c1108     14
    rhs       c1109     16
    rhs       c1110     16
    rhs       c1111     20
    rhs       c1112     17
    rhs       c1113     20
    rhs       c1114     18
    rhs       c1115     21
    rhs       c1116     20
    rhs       c1117     19
    rhs       c1118     21
    rhs       c1119     16
    rhs       c1120     16
    rhs       c1121     0
    rhs       c1122     5
    rhs       c1123     11
    rhs       c1124     15
    rhs       c1125     20
    rhs       c1126     24
    rhs       c1127     24
    rhs       c1128     22
    rhs       c1129     23
    rhs       c1130     20
    rhs       c1131     20
    rhs       c1132     21
    rhs       c1133     23
    rhs       c1134     23
    rhs       c1135     24
    rhs       c1136     23
    rhs       c1137     0
    rhs       c1138     5
    rhs       c1139     11
    rhs       c1140     17
    rhs       c1141     24
    rhs       c1142     24
    rhs       c1143     22
    rhs       c1144     20
    rhs       c1145     25
    rhs       c1146     23
    rhs       c1147     24
    rhs       c1148     21
    rhs       c1149     21
    rhs       c1150     24
    rhs       c1151     25
    rhs       c1152     24
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     2
    rhs       c1156     0
    rhs       c1157     3
    rhs       c1158     4
    rhs       c1159     5
    rhs       c1160     0
    rhs       c1161     4
    rhs       c1162     1
    rhs       c1163     5
    rhs       c1164     3
    rhs       c1165     1
    rhs       c1166     2
    rhs       c1167     0
    rhs       c1168     4
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     2
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     5
    rhs       c1175     2
    rhs       c1176     5
    rhs       c1177     1
    rhs       c1178     4
    rhs       c1179     5
    rhs       c1180     3
    rhs       c1181     0
    rhs       c1182     3
    rhs       c1183     2
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     2
    rhs       c1187     3
    rhs       c1188     4
    rhs       c1189     6
    rhs       c1190     7
    rhs       c1191     10
    rhs       c1192     7
    rhs       c1193     7
    rhs       c1194     8
    rhs       c1195     9
    rhs       c1196     10
    rhs       c1197     6
    rhs       c1198     5
    rhs       c1199     7
    rhs       c1200     6
    rhs       c1201     0
    rhs       c1202     1
    rhs       c1203     4
    rhs       c1204     6
    rhs       c1205     9
    rhs       c1206     9
    rhs       c1207     5
    rhs       c1208     5
    rhs       c1209     6
    rhs       c1210     7
    rhs       c1211     8
    rhs       c1212     6
    rhs       c1213     9
    rhs       c1214     6
    rhs       c1215     6
    rhs       c1216     6
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     10
    rhs       c1220     0
    rhs       c1221     19
    rhs       c1222     0
    rhs       c1223     17
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     17
    rhs       c1227     16
    rhs       c1228     18
    rhs       c1229     18
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     17
    rhs       c1233     0
    rhs       c1234     5
    rhs       c1235     10
    rhs       c1236     12
    rhs       c1237     19
    rhs       c1238     17
    rhs       c1239     18
    rhs       c1240     19
    rhs       c1241     17
    rhs       c1242     18
    rhs       c1243     16
    rhs       c1244     18
    rhs       c1245     0
    rhs       c1246     19
    rhs       c1247     21
    rhs       c1248     17
    rhs       c1249     0
    rhs       c1250     6
    rhs       c1251     10
    rhs       c1252     18
    rhs       c1253     22
    rhs       c1254     20
    rhs       c1255     25
    rhs       c1256     20
    rhs       c1257     20
    rhs       c1258     21
    rhs       c1259     20
    rhs       c1260     24
    rhs       c1261     24
    rhs       c1262     24
    rhs       c1263     23
    rhs       c1264     23
    rhs       c1265     0
    rhs       c1266     5
    rhs       c1267     11
    rhs       c1268     17
    rhs       c1269     20
    rhs       c1270     21
    rhs       c1271     22
    rhs       c1272     23
    rhs       c1273     23
    rhs       c1274     24
    rhs       c1275     24
    rhs       c1276     22
    rhs       c1277     21
    rhs       c1278     24
    rhs       c1279     22
    rhs       c1280     25
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
RANGES
BOUNDS
 LO bounds    x[1]      0
 PL bounds    x[1]
 LO bounds    x[2]      0
 PL bounds    x[2]
 LO bounds    x[3]      0
 PL bounds    x[3]
 LO bounds    x[4]      0
 PL bounds    x[4]
 LO bounds    x[5]      0
 PL bounds    x[5]
 LO bounds    x[6]      0
 PL bounds    x[6]
 LO bounds    x[7]      0
 PL bounds    x[7]
 LO bounds    x[8]      0
 PL bounds    x[8]
 LO bounds    x[9]      0
 PL bounds    x[9]
 LO bounds    x[10]     0
 PL bounds    x[10]
 LO bounds    x[11]     0
 PL bounds    x[11]
 LO bounds    x[12]     0
 PL bounds    x[12]
 LO bounds    x[13]     0
 PL bounds    x[13]
 LO bounds    x[14]     0
 PL bounds    x[14]
 LO bounds    x[15]     0
 PL bounds    x[15]
 LO bounds    x[16]     0
 PL bounds    x[16]
 LO bounds    x[17]     0
 PL bounds    x[17]
 LO bounds    x[18]     0
 PL bounds    x[18]
 LO bounds    x[19]     0
 PL bounds    x[19]
 LO bounds    x[20]     0
 PL bounds    x[20]
 LO bounds    x[21]     0
 PL bounds    x[21]
 LO bounds    x[22]     0
 PL bounds    x[22]
 LO bounds    x[23]     0
 PL bounds    x[23]
 LO bounds    x[24]     0
 PL bounds    x[24]
 LO bounds    x[25]     0
 PL bounds    x[25]
 LO bounds    x[26]     0
 PL bounds    x[26]
 LO bounds    x[27]     0
 PL bounds    x[27]
 LO bounds    x[28]     0
 PL bounds    x[28]
 LO bounds    x[29]     0
 PL bounds    x[29]
 LO bounds    x[30]     0
 PL bounds    x[30]
 LO bounds    x[31]     0
 PL bounds    x[31]
 LO bounds    x[32]     0
 PL bounds    x[32]
 LO bounds    x[33]     0
 PL bounds    x[33]
 LO bounds    x[34]     0
 PL bounds    x[34]
 LO bounds    x[35]     0
 PL bounds    x[35]
 LO bounds    x[36]     0
 PL bounds    x[36]
 LO bounds    x[37]     0
 PL bounds    x[37]
 LO bounds    x[38]     0
 PL bounds    x[38]
 LO bounds    x[39]     0
 PL bounds    x[39]
 LO bounds    x[40]     0
 PL bounds    x[40]
 LO bounds    x[41]     0
 PL bounds    x[41]
 LO bounds    x[42]     0
 PL bounds    x[42]
 LO bounds    x[43]     0
 PL bounds    x[43]
 LO bounds    x[44]     0
 PL bounds    x[44]
 LO bounds    x[45]     0
 PL bounds    x[45]
 LO bounds    x[46]     0
 PL bounds    x[46]
 LO bounds    x[47]     0
 PL bounds    x[47]
 LO bounds    x[48]     0
 PL bounds    x[48]
 LO bounds    x[49]     0
 PL bounds    x[49]
 LO bounds    x[50]     0
 PL bounds    x[50]
 LO bounds    x[51]     0
 PL bounds    x[51]
 LO bounds    x[52]     0
 PL bounds    x[52]
 LO bounds    x[53]     0
 PL bounds    x[53]
 LO bounds    x[54]     0
 PL bounds    x[54]
 LO bounds    x[55]     0
 PL bounds    x[55]
 LO bounds    x[56]     0
 PL bounds    x[56]
 LO bounds    x[57]     0
 PL bounds    x[57]
 LO bounds    x[58]     0
 PL bounds    x[58]
 LO bounds    x[59]     0
 PL bounds    x[59]
 LO bounds    x[60]     0
 PL bounds    x[60]
 LO bounds    x[61]     0
 PL bounds    x[61]
 LO bounds    x[62]     0
 PL bounds    x[62]
 LO bounds    x[63]     0
 PL bounds    x[63]
 LO bounds    x[64]     0
 PL bounds    x[64]
 LO bounds    x[65]     0
 PL bounds    x[65]
 LO bounds    x[66]     0
 PL bounds    x[66]
 LO bounds    x[67]     0
 PL bounds    x[67]
 LO bounds    x[68]     0
 PL bounds    x[68]
 LO bounds    x[69]     0
 PL bounds    x[69]
 LO bounds    x[70]     0
 PL bounds    x[70]
 LO bounds    x[71]     0
 PL bounds    x[71]
 LO bounds    x[72]     0
 PL bounds    x[72]
 LO bounds    x[73]     0
 PL bounds    x[73]
 LO bounds    x[74]     0
 PL bounds    x[74]
 LO bounds    x[75]     0
 PL bounds    x[75]
 LO bounds    x[76]     0
 PL bounds    x[76]
 LO bounds    x[77]     0
 PL bounds    x[77]
 LO bounds    x[78]     0
 PL bounds    x[78]
 LO bounds    x[79]     0
 PL bounds    x[79]
 LO bounds    x[80]     0
 PL bounds    x[80]
 LO bounds    x[81]     0
 PL bounds    x[81]
 LO bounds    x[82]     0
 PL bounds    x[82]
 LO bounds    x[83]     0
 PL bounds    x[83]
 LO bounds    x[84]     0
 PL bounds    x[84]
 LO bounds    x[85]     0
 PL bounds    x[85]
 LO bounds    x[86]     0
 PL bounds    x[86]
 LO bounds    x[87]     0
 PL bounds    x[87]
 LO bounds    x[88]     0
 PL bounds    x[88]
 LO bounds    x[89]     0
 PL bounds    x[89]
 LO bounds    x[90]     0
 PL bounds    x[90]
 LO bounds    x[91]     0
 PL bounds    x[91]
 LO bounds    x[92]     0
 PL bounds    x[92]
 LO bounds    x[93]     0
 PL bounds    x[93]
 LO bounds    x[94]     0
 PL bounds    x[94]
 LO bounds    x[95]     0
 PL bounds    x[95]
 LO bounds    x[96]     0
 PL bounds    x[96]
 LO bounds    x[97]     0
 PL bounds    x[97]
 LO bounds    x[98]     0
 PL bounds    x[98]
 LO bounds    x[99]     0
 PL bounds    x[99]
 LO bounds    x[100]    0
 PL bounds    x[100]
 LO bounds    x[101]    0
 PL bounds    x[101]
 LO bounds    x[102]    0
 PL bounds    x[102]
 LO bounds    x[103]    0
 PL bounds    x[103]
 LO bounds    x[104]    0
 PL bounds    x[104]
 LO bounds    x[105]    0
 PL bounds    x[105]
 LO bounds    x[106]    0
 PL bounds    x[106]
 LO bounds    x[107]    0
 PL bounds    x[107]
 LO bounds    x[108]    0
 PL bounds    x[108]
 LO bounds    x[109]    0
 PL bounds    x[109]
 LO bounds    x[110]    0
 PL bounds    x[110]
 LO bounds    x[111]    0
 PL bounds    x[111]
 LO bounds    x[112]    0
 PL bounds    x[112]
 LO bounds    x[113]    0
 PL bounds    x[113]
 LO bounds    x[114]    0
 PL bounds    x[114]
 LO bounds    x[115]    0
 PL bounds    x[115]
 LO bounds    x[116]    0
 PL bounds    x[116]
 LO bounds    x[117]    0
 PL bounds    x[117]
 LO bounds    x[118]    0
 PL bounds    x[118]
 LO bounds    x[119]    0
 PL bounds    x[119]
 LO bounds    x[120]    0
 PL bounds    x[120]
 LO bounds    x[121]    0
 PL bounds    x[121]
 LO bounds    x[122]    0
 PL bounds    x[122]
 LO bounds    x[123]    0
 PL bounds    x[123]
 LO bounds    x[124]    0
 PL bounds    x[124]
 LO bounds    x[125]    0
 PL bounds    x[125]
 LO bounds    x[126]    0
 PL bounds    x[126]
 LO bounds    x[127]    0
 PL bounds    x[127]
 LO bounds    x[128]    0
 PL bounds    x[128]
 LO bounds    x[129]    0
 PL bounds    x[129]
 LO bounds    x[130]    0
 PL bounds    x[130]
 LO bounds    x[131]    0
 PL bounds    x[131]
 LO bounds    x[132]    0
 PL bounds    x[132]
 LO bounds    x[133]    0
 PL bounds    x[133]
 LO bounds    x[134]    0
 PL bounds    x[134]
 LO bounds    x[135]    0
 PL bounds    x[135]
 LO bounds    x[136]    0
 PL bounds    x[136]
 LO bounds    x[137]    0
 PL bounds    x[137]
 LO bounds    x[138]    0
 PL bounds    x[138]
 LO bounds    x[139]    0
 PL bounds    x[139]
 LO bounds    x[140]    0
 PL bounds    x[140]
 LO bounds    x[141]    0
 PL bounds    x[141]
 LO bounds    x[142]    0
 PL bounds    x[142]
 LO bounds    x[143]    0
 PL bounds    x[143]
 LO bounds    x[144]    0
 PL bounds    x[144]
 LO bounds    x[145]    0
 PL bounds    x[145]
 LO bounds    x[146]    0
 PL bounds    x[146]
 LO bounds    x[147]    0
 PL bounds    x[147]
 LO bounds    x[148]    0
 PL bounds    x[148]
 LO bounds    x[149]    0
 PL bounds    x[149]
 LO bounds    x[150]    0
 PL bounds    x[150]
 LO bounds    x[151]    0
 PL bounds    x[151]
 LO bounds    x[152]    0
 PL bounds    x[152]
 LO bounds    x[153]    0
 PL bounds    x[153]
 LO bounds    x[154]    0
 PL bounds    x[154]
 LO bounds    x[155]    0
 PL bounds    x[155]
 LO bounds    x[156]    0
 PL bounds    x[156]
 LO bounds    x[157]    0
 PL bounds    x[157]
 LO bounds    x[158]    0
 PL bounds    x[158]
 LO bounds    x[159]    0
 PL bounds    x[159]
 LO bounds    x[160]    0
 PL bounds    x[160]
 LO bounds    x[161]    0
 PL bounds    x[161]
 LO bounds    x[162]    0
 PL bounds    x[162]
 LO bounds    x[163]    0
 PL bounds    x[163]
 LO bounds    x[164]    0
 PL bounds    x[164]
 LO bounds    x[165]    0
 PL bounds    x[165]
 LO bounds    x[166]    0
 PL bounds    x[166]
 LO bounds    x[167]    0
 PL bounds    x[167]
 LO bounds    x[168]    0
 PL bounds    x[168]
 LO bounds    x[169]    0
 PL bounds    x[169]
 LO bounds    x[170]    0
 PL bounds    x[170]
 LO bounds    x[171]    0
 PL bounds    x[171]
 LO bounds    x[172]    0
 PL bounds    x[172]
 LO bounds    x[173]    0
 PL bounds    x[173]
 LO bounds    x[174]    0
 PL bounds    x[174]
 LO bounds    x[175]    0
 PL bounds    x[175]
 LO bounds    x[176]    0
 PL bounds    x[176]
 LO bounds    x[177]    0
 PL bounds    x[177]
 LO bounds    x[178]    0
 PL bounds    x[178]
 LO bounds    x[179]    0
 PL bounds    x[179]
 LO bounds    x[180]    0
 PL bounds    x[180]
 LO bounds    x[181]    0
 PL bounds    x[181]
 LO bounds    x[182]    0
 PL bounds    x[182]
 LO bounds    x[183]    0
 PL bounds    x[183]
 LO bounds    x[184]    0
 PL bounds    x[184]
 LO bounds    x[185]    0
 PL bounds    x[185]
 LO bounds    x[186]    0
 PL bounds    x[186]
 LO bounds    x[187]    0
 PL bounds    x[187]
 LO bounds    x[188]    0
 PL bounds    x[188]
 LO bounds    x[189]    0
 PL bounds    x[189]
 LO bounds    x[190]    0
 PL bounds    x[190]
 LO bounds    x[191]    0
 PL bounds    x[191]
 LO bounds    x[192]    0
 PL bounds    x[192]
 LO bounds    x[193]    0
 PL bounds    x[193]
 LO bounds    x[194]    0
 PL bounds    x[194]
 LO bounds    x[195]    0
 PL bounds    x[195]
 LO bounds    x[196]    0
 PL bounds    x[196]
 LO bounds    x[197]    0
 PL bounds    x[197]
 LO bounds    x[198]    0
 PL bounds    x[198]
 LO bounds    x[199]    0
 PL bounds    x[199]
 LO bounds    x[200]    0
 PL bounds    x[200]
 LO bounds    x[201]    0
 PL bounds    x[201]
 LO bounds    x[202]    0
 PL bounds    x[202]
 LO bounds    x[203]    0
 PL bounds    x[203]
 LO bounds    x[204]    0
 PL bounds    x[204]
 LO bounds    x[205]    0
 PL bounds    x[205]
 LO bounds    x[206]    0
 PL bounds    x[206]
 LO bounds    x[207]    0
 PL bounds    x[207]
 LO bounds    x[208]    0
 PL bounds    x[208]
 LO bounds    x[209]    0
 PL bounds    x[209]
 LO bounds    x[210]    0
 PL bounds    x[210]
 LO bounds    x[211]    0
 PL bounds    x[211]
 LO bounds    x[212]    0
 PL bounds    x[212]
 LO bounds    x[213]    0
 PL bounds    x[213]
 LO bounds    x[214]    0
 PL bounds    x[214]
 LO bounds    x[215]    0
 PL bounds    x[215]
 LO bounds    x[216]    0
 PL bounds    x[216]
 LO bounds    x[217]    0
 PL bounds    x[217]
 LO bounds    x[218]    0
 PL bounds    x[218]
 LO bounds    x[219]    0
 PL bounds    x[219]
 LO bounds    x[220]    0
 PL bounds    x[220]
 LO bounds    x[221]    0
 PL bounds    x[221]
 LO bounds    x[222]    0
 PL bounds    x[222]
 LO bounds    x[223]    0
 PL bounds    x[223]
 LO bounds    x[224]    0
 PL bounds    x[224]
 LO bounds    x[225]    0
 PL bounds    x[225]
 LO bounds    x[226]    0
 PL bounds    x[226]
 LO bounds    x[227]    0
 PL bounds    x[227]
 LO bounds    x[228]    0
 PL bounds    x[228]
 LO bounds    x[229]    0
 PL bounds    x[229]
 LO bounds    x[230]    0
 PL bounds    x[230]
 LO bounds    x[231]    0
 PL bounds    x[231]
 LO bounds    x[232]    0
 PL bounds    x[232]
 LO bounds    x[233]    0
 PL bounds    x[233]
 LO bounds    x[234]    0
 PL bounds    x[234]
 LO bounds    x[235]    0
 PL bounds    x[235]
 LO bounds    x[236]    0
 PL bounds    x[236]
 LO bounds    x[237]    0
 PL bounds    x[237]
 LO bounds    x[238]    0
 PL bounds    x[238]
 LO bounds    x[239]    0
 PL bounds    x[239]
 LO bounds    x[240]    0
 PL bounds    x[240]
 LO bounds    x[241]    0
 PL bounds    x[241]
 LO bounds    x[242]    0
 PL bounds    x[242]
 LO bounds    x[243]    0
 PL bounds    x[243]
 LO bounds    x[244]    0
 PL bounds    x[244]
 LO bounds    x[245]    0
 PL bounds    x[245]
 LO bounds    x[246]    0
 PL bounds    x[246]
 LO bounds    x[247]    0
 PL bounds    x[247]
 LO bounds    x[248]    0
 PL bounds    x[248]
 LO bounds    x[249]    0
 PL bounds    x[249]
 LO bounds    x[250]    0
 PL bounds    x[250]
 LO bounds    x[251]    0
 PL bounds    x[251]
 LO bounds    x[252]    0
 PL bounds    x[252]
 LO bounds    x[253]    0
 PL bounds    x[253]
 LO bounds    x[254]    0
 PL bounds    x[254]
 LO bounds    x[255]    0
 PL bounds    x[255]
 LO bounds    x[256]    0
 PL bounds    x[256]
 LO bounds    x[257]    0
 PL bounds    x[257]
 LO bounds    x[258]    0
 PL bounds    x[258]
 LO bounds    x[259]    0
 PL bounds    x[259]
 LO bounds    x[260]    0
 PL bounds    x[260]
 LO bounds    x[261]    0
 PL bounds    x[261]
 LO bounds    x[262]    0
 PL bounds    x[262]
 LO bounds    x[263]    0
 PL bounds    x[263]
 LO bounds    x[264]    0
 PL bounds    x[264]
 LO bounds    x[265]    0
 PL bounds    x[265]
 LO bounds    x[266]    0
 PL bounds    x[266]
 LO bounds    x[267]    0
 PL bounds    x[267]
 LO bounds    x[268]    0
 PL bounds    x[268]
 LO bounds    x[269]    0
 PL bounds    x[269]
 LO bounds    x[270]    0
 PL bounds    x[270]
 LO bounds    x[271]    0
 PL bounds    x[271]
 LO bounds    x[272]    0
 PL bounds    x[272]
 LO bounds    x[273]    0
 PL bounds    x[273]
 LO bounds    x[274]    0
 PL bounds    x[274]
 LO bounds    x[275]    0
 PL bounds    x[275]
 LO bounds    x[276]    0
 PL bounds    x[276]
 LO bounds    x[277]    0
 PL bounds    x[277]
 LO bounds    x[278]    0
 PL bounds    x[278]
 LO bounds    x[279]    0
 PL bounds    x[279]
 LO bounds    x[280]    0
 PL bounds    x[280]
 LO bounds    x[281]    0
 PL bounds    x[281]
 LO bounds    x[282]    0
 PL bounds    x[282]
 LO bounds    x[283]    0
 PL bounds    x[283]
 LO bounds    x[284]    0
 PL bounds    x[284]
 LO bounds    x[285]    0
 PL bounds    x[285]
 LO bounds    x[286]    0
 PL bounds    x[286]
 LO bounds    x[287]    0
 PL bounds    x[287]
 LO bounds    x[288]    0
 PL bounds    x[288]
 LO bounds    x[289]    0
 PL bounds    x[289]
 LO bounds    x[290]    0
 PL bounds    x[290]
 LO bounds    x[291]    0
 PL bounds    x[291]
 LO bounds    x[292]    0
 PL bounds    x[292]
 LO bounds    x[293]    0
 PL bounds    x[293]
 LO bounds    x[294]    0
 PL bounds    x[294]
 LO bounds    x[295]    0
 PL bounds    x[295]
 LO bounds    x[296]    0
 PL bounds    x[296]
 LO bounds    x[297]    0
 PL bounds    x[297]
 LO bounds    x[298]    0
 PL bounds    x[298]
 LO bounds    x[299]    0
 PL bounds    x[299]
 LO bounds    x[300]    0
 PL bounds    x[300]
 LO bounds    x[301]    0
 PL bounds    x[301]
 LO bounds    x[302]    0
 PL bounds    x[302]
 LO bounds    x[303]    0
 PL bounds    x[303]
 LO bounds    x[304]    0
 PL bounds    x[304]
 LO bounds    x[305]    0
 PL bounds    x[305]
 LO bounds    x[306]    0
 PL bounds    x[306]
 LO bounds    x[307]    0
 PL bounds    x[307]
 LO bounds    x[308]    0
 PL bounds    x[308]
 LO bounds    x[309]    0
 PL bounds    x[309]
 LO bounds    x[310]    0
 PL bounds    x[310]
 LO bounds    x[311]    0
 PL bounds    x[311]
 LO bounds    x[312]    0
 PL bounds    x[312]
 LO bounds    x[313]    0
 PL bounds    x[313]
 LO bounds    x[314]    0
 PL bounds    x[314]
 LO bounds    x[315]    0
 PL bounds    x[315]
 LO bounds    x[316]    0
 PL bounds    x[316]
 LO bounds    x[317]    0
 PL bounds    x[317]
 LO bounds    x[318]    0
 PL bounds    x[318]
 LO bounds    x[319]    0
 PL bounds    x[319]
 LO bounds    x[320]    0
 PL bounds    x[320]
 LO bounds    x[321]    0
 PL bounds    x[321]
 LO bounds    x[322]    0
 PL bounds    x[322]
 LO bounds    x[323]    0
 PL bounds    x[323]
 LO bounds    x[324]    0
 PL bounds    x[324]
 LO bounds    x[325]    0
 PL bounds    x[325]
 LO bounds    x[326]    0
 PL bounds    x[326]
 LO bounds    x[327]    0
 PL bounds    x[327]
 LO bounds    x[328]    0
 PL bounds    x[328]
 LO bounds    x[329]    0
 PL bounds    x[329]
 LO bounds    x[330]    0
 PL bounds    x[330]
 LO bounds    x[331]    0
 PL bounds    x[331]
 LO bounds    x[332]    0
 PL bounds    x[332]
 LO bounds    x[333]    0
 PL bounds    x[333]
 LO bounds    x[334]    0
 PL bounds    x[334]
 LO bounds    x[335]    0
 PL bounds    x[335]
 LO bounds    x[336]    0
 PL bounds    x[336]
 LO bounds    x[337]    0
 PL bounds    x[337]
 LO bounds    x[338]    0
 PL bounds    x[338]
 LO bounds    x[339]    0
 PL bounds    x[339]
 LO bounds    x[340]    0
 PL bounds    x[340]
 LO bounds    x[341]    0
 PL bounds    x[341]
 LO bounds    x[342]    0
 PL bounds    x[342]
 LO bounds    x[343]    0
 PL bounds    x[343]
 LO bounds    x[344]    0
 PL bounds    x[344]
 LO bounds    x[345]    0
 PL bounds    x[345]
 LO bounds    x[346]    0
 PL bounds    x[346]
 LO bounds    x[347]    0
 PL bounds    x[347]
 LO bounds    x[348]    0
 PL bounds    x[348]
 LO bounds    x[349]    0
 PL bounds    x[349]
 LO bounds    x[350]    0
 PL bounds    x[350]
 LO bounds    x[351]    0
 PL bounds    x[351]
 LO bounds    x[352]    0
 PL bounds    x[352]
 LO bounds    x[353]    0
 PL bounds    x[353]
 LO bounds    x[354]    0
 PL bounds    x[354]
 LO bounds    x[355]    0
 PL bounds    x[355]
 LO bounds    x[356]    0
 PL bounds    x[356]
 LO bounds    x[357]    0
 PL bounds    x[357]
 LO bounds    x[358]    0
 PL bounds    x[358]
 LO bounds    x[359]    0
 PL bounds    x[359]
 LO bounds    x[360]    0
 PL bounds    x[360]
 LO bounds    x[361]    0
 PL bounds    x[361]
 LO bounds    x[362]    0
 PL bounds    x[362]
 LO bounds    x[363]    0
 PL bounds    x[363]
 LO bounds    x[364]    0
 PL bounds    x[364]
 LO bounds    x[365]    0
 PL bounds    x[365]
 LO bounds    x[366]    0
 PL bounds    x[366]
 LO bounds    x[367]    0
 PL bounds    x[367]
 LO bounds    x[368]    0
 PL bounds    x[368]
 LO bounds    x[369]    0
 PL bounds    x[369]
 LO bounds    x[370]    0
 PL bounds    x[370]
 LO bounds    x[371]    0
 PL bounds    x[371]
 LO bounds    x[372]    0
 PL bounds    x[372]
 LO bounds    x[373]    0
 PL bounds    x[373]
 LO bounds    x[374]    0
 PL bounds    x[374]
 LO bounds    x[375]    0
 PL bounds    x[375]
 LO bounds    x[376]    0
 PL bounds    x[376]
 LO bounds    x[377]    0
 PL bounds    x[377]
 LO bounds    x[378]    0
 PL bounds    x[378]
 LO bounds    x[379]    0
 PL bounds    x[379]
 LO bounds    x[380]    0
 PL bounds    x[380]
 LO bounds    x[381]    0
 PL bounds    x[381]
 LO bounds    x[382]    0
 PL bounds    x[382]
 LO bounds    x[383]    0
 PL bounds    x[383]
 LO bounds    x[384]    0
 PL bounds    x[384]
 LO bounds    x[385]    0
 PL bounds    x[385]
 LO bounds    x[386]    0
 PL bounds    x[386]
 LO bounds    x[387]    0
 PL bounds    x[387]
 LO bounds    x[388]    0
 PL bounds    x[388]
 LO bounds    x[389]    0
 PL bounds    x[389]
 LO bounds    x[390]    0
 PL bounds    x[390]
 LO bounds    x[391]    0
 PL bounds    x[391]
 LO bounds    x[392]    0
 PL bounds    x[392]
 LO bounds    x[393]    0
 PL bounds    x[393]
 LO bounds    x[394]    0
 PL bounds    x[394]
 LO bounds    x[395]    0
 PL bounds    x[395]
 LO bounds    x[396]    0
 PL bounds    x[396]
 LO bounds    x[397]    0
 PL bounds    x[397]
 LO bounds    x[398]    0
 PL bounds    x[398]
 LO bounds    x[399]    0
 PL bounds    x[399]
 LO bounds    x[400]    0
 PL bounds    x[400]
 LO bounds    x[401]    0
 PL bounds    x[401]
 LO bounds    x[402]    0
 PL bounds    x[402]
 LO bounds    x[403]    0
 PL bounds    x[403]
 LO bounds    x[404]    0
 PL bounds    x[404]
 LO bounds    x[405]    0
 PL bounds    x[405]
 LO bounds    x[406]    0
 PL bounds    x[406]
 LO bounds    x[407]    0
 PL bounds    x[407]
 LO bounds    x[408]    0
 PL bounds    x[408]
 LO bounds    x[409]    0
 PL bounds    x[409]
 LO bounds    x[410]    0
 PL bounds    x[410]
 LO bounds    x[411]    0
 PL bounds    x[411]
 LO bounds    x[412]    0
 PL bounds    x[412]
 LO bounds    x[413]    0
 PL bounds    x[413]
 LO bounds    x[414]    0
 PL bounds    x[414]
 LO bounds    x[415]    0
 PL bounds    x[415]
 LO bounds    x[416]    0
 PL bounds    x[416]
 LO bounds    x[417]    0
 PL bounds    x[417]
 LO bounds    x[418]    0
 PL bounds    x[418]
 LO bounds    x[419]    0
 PL bounds    x[419]
 LO bounds    x[420]    0
 PL bounds    x[420]
 LO bounds    x[421]    0
 PL bounds    x[421]
 LO bounds    x[422]    0
 PL bounds    x[422]
 LO bounds    x[423]    0
 PL bounds    x[423]
 LO bounds    x[424]    0
 PL bounds    x[424]
 LO bounds    x[425]    0
 PL bounds    x[425]
 LO bounds    x[426]    0
 PL bounds    x[426]
 LO bounds    x[427]    0
 PL bounds    x[427]
 LO bounds    x[428]    0
 PL bounds    x[428]
 LO bounds    x[429]    0
 PL bounds    x[429]
 LO bounds    x[430]    0
 PL bounds    x[430]
 LO bounds    x[431]    0
 PL bounds    x[431]
 LO bounds    x[432]    0
 PL bounds    x[432]
 LO bounds    x[433]    0
 PL bounds    x[433]
 LO bounds    x[434]    0
 PL bounds    x[434]
 LO bounds    x[435]    0
 PL bounds    x[435]
 LO bounds    x[436]    0
 PL bounds    x[436]
 LO bounds    x[437]    0
 PL bounds    x[437]
 LO bounds    x[438]    0
 PL bounds    x[438]
 LO bounds    x[439]    0
 PL bounds    x[439]
 LO bounds    x[440]    0
 PL bounds    x[440]
 LO bounds    x[441]    0
 PL bounds    x[441]
 LO bounds    x[442]    0
 PL bounds    x[442]
 LO bounds    x[443]    0
 PL bounds    x[443]
 LO bounds    x[444]    0
 PL bounds    x[444]
 LO bounds    x[445]    0
 PL bounds    x[445]
 LO bounds    x[446]    0
 PL bounds    x[446]
 LO bounds    x[447]    0
 PL bounds    x[447]
 LO bounds    x[448]    0
 PL bounds    x[448]
 LO bounds    x[449]    0
 PL bounds    x[449]
 LO bounds    x[450]    0
 PL bounds    x[450]
 LO bounds    x[451]    0
 PL bounds    x[451]
 LO bounds    x[452]    0
 PL bounds    x[452]
 LO bounds    x[453]    0
 PL bounds    x[453]
 LO bounds    x[454]    0
 PL bounds    x[454]
 LO bounds    x[455]    0
 PL bounds    x[455]
 LO bounds    x[456]    0
 PL bounds    x[456]
 LO bounds    x[457]    0
 PL bounds    x[457]
 LO bounds    x[458]    0
 PL bounds    x[458]
 LO bounds    x[459]    0
 PL bounds    x[459]
 LO bounds    x[460]    0
 PL bounds    x[460]
 LO bounds    x[461]    0
 PL bounds    x[461]
 LO bounds    x[462]    0
 PL bounds    x[462]
 LO bounds    x[463]    0
 PL bounds    x[463]
 LO bounds    x[464]    0
 PL bounds    x[464]
 LO bounds    x[465]    0
 PL bounds    x[465]
 LO bounds    x[466]    0
 PL bounds    x[466]
 LO bounds    x[467]    0
 PL bounds    x[467]
 LO bounds    x[468]    0
 PL bounds    x[468]
 LO bounds    x[469]    0
 PL bounds    x[469]
 LO bounds    x[470]    0
 PL bounds    x[470]
 LO bounds    x[471]    0
 PL bounds    x[471]
 LO bounds    x[472]    0
 PL bounds    x[472]
 LO bounds    x[473]    0
 PL bounds    x[473]
 LO bounds    x[474]    0
 PL bounds    x[474]
 LO bounds    x[475]    0
 PL bounds    x[475]
 LO bounds    x[476]    0
 PL bounds    x[476]
 LO bounds    x[477]    0
 PL bounds    x[477]
 LO bounds    x[478]    0
 PL bounds    x[478]
 LO bounds    x[479]    0
 PL bounds    x[479]
 LO bounds    x[480]    0
 PL bounds    x[480]
 LO bounds    x[481]    0
 PL bounds    x[481]
 LO bounds    x[482]    0
 PL bounds    x[482]
 LO bounds    x[483]    0
 PL bounds    x[483]
 LO bounds    x[484]    0
 PL bounds    x[484]
 LO bounds    x[485]    0
 PL bounds    x[485]
 LO bounds    x[486]    0
 PL bounds    x[486]
 LO bounds    x[487]    0
 PL bounds    x[487]
 LO bounds    x[488]    0
 PL bounds    x[488]
 LO bounds    x[489]    0
 PL bounds    x[489]
 LO bounds    x[490]    0
 PL bounds    x[490]
 LO bounds    x[491]    0
 PL bounds    x[491]
 LO bounds    x[492]    0
 PL bounds    x[492]
 LO bounds    x[493]    0
 PL bounds    x[493]
 LO bounds    x[494]    0
 PL bounds    x[494]
 LO bounds    x[495]    0
 PL bounds    x[495]
 LO bounds    x[496]    0
 PL bounds    x[496]
 LO bounds    x[497]    0
 PL bounds    x[497]
 LO bounds    x[498]    0
 PL bounds    x[498]
 LO bounds    x[499]    0
 PL bounds    x[499]
 LO bounds    x[500]    0
 PL bounds    x[500]
 LO bounds    x[501]    0
 PL bounds    x[501]
 LO bounds    x[502]    0
 PL bounds    x[502]
 LO bounds    x[503]    0
 PL bounds    x[503]
 LO bounds    x[504]    0
 PL bounds    x[504]
 LO bounds    x[505]    0
 PL bounds    x[505]
 LO bounds    x[506]    0
 PL bounds    x[506]
 LO bounds    x[507]    0
 PL bounds    x[507]
 LO bounds    x[508]    0
 PL bounds    x[508]
 LO bounds    x[509]    0
 PL bounds    x[509]
 LO bounds    x[510]    0
 PL bounds    x[510]
 LO bounds    x[511]    0
 PL bounds    x[511]
 LO bounds    x[512]    0
 PL bounds    x[512]
 LO bounds    x[513]    0
 PL bounds    x[513]
 LO bounds    x[514]    0
 PL bounds    x[514]
 LO bounds    x[515]    0
 PL bounds    x[515]
 LO bounds    x[516]    0
 PL bounds    x[516]
 LO bounds    x[517]    0
 PL bounds    x[517]
 LO bounds    x[518]    0
 PL bounds    x[518]
 LO bounds    x[519]    0
 PL bounds    x[519]
 LO bounds    x[520]    0
 PL bounds    x[520]
 LO bounds    x[521]    0
 PL bounds    x[521]
 LO bounds    x[522]    0
 PL bounds    x[522]
 LO bounds    x[523]    0
 PL bounds    x[523]
 LO bounds    x[524]    0
 PL bounds    x[524]
 LO bounds    x[525]    0
 PL bounds    x[525]
 LO bounds    x[526]    0
 PL bounds    x[526]
 LO bounds    x[527]    0
 PL bounds    x[527]
 LO bounds    x[528]    0
 PL bounds    x[528]
 LO bounds    x[529]    0
 PL bounds    x[529]
 LO bounds    x[530]    0
 PL bounds    x[530]
 LO bounds    x[531]    0
 PL bounds    x[531]
 LO bounds    x[532]    0
 PL bounds    x[532]
 LO bounds    x[533]    0
 PL bounds    x[533]
 LO bounds    x[534]    0
 PL bounds    x[534]
 LO bounds    x[535]    0
 PL bounds    x[535]
 LO bounds    x[536]    0
 PL bounds    x[536]
 LO bounds    x[537]    0
 PL bounds    x[537]
 LO bounds    x[538]    0
 PL bounds    x[538]
 LO bounds    x[539]    0
 PL bounds    x[539]
 LO bounds    x[540]    0
 PL bounds    x[540]
 LO bounds    x[541]    0
 PL bounds    x[541]
 LO bounds    x[542]    0
 PL bounds    x[542]
 LO bounds    x[543]    0
 PL bounds    x[543]
 LO bounds    x[544]    0
 PL bounds    x[544]
 LO bounds    x[545]    0
 PL bounds    x[545]
 LO bounds    x[546]    0
 PL bounds    x[546]
 LO bounds    x[547]    0
 PL bounds    x[547]
 LO bounds    x[548]    0
 PL bounds    x[548]
 LO bounds    x[549]    0
 PL bounds    x[549]
 LO bounds    x[550]    0
 PL bounds    x[550]
 LO bounds    x[551]    0
 PL bounds    x[551]
 LO bounds    x[552]    0
 PL bounds    x[552]
 LO bounds    x[553]    0
 PL bounds    x[553]
 LO bounds    x[554]    0
 PL bounds    x[554]
 LO bounds    x[555]    0
 PL bounds    x[555]
 LO bounds    x[556]    0
 PL bounds    x[556]
 LO bounds    x[557]    0
 PL bounds    x[557]
 LO bounds    x[558]    0
 PL bounds    x[558]
 LO bounds    x[559]    0
 PL bounds    x[559]
 LO bounds    x[560]    0
 PL bounds    x[560]
 LO bounds    x[561]    0
 PL bounds    x[561]
 LO bounds    x[562]    0
 PL bounds    x[562]
 LO bounds    x[563]    0
 PL bounds    x[563]
 LO bounds    x[564]    0
 PL bounds    x[564]
 LO bounds    x[565]    0
 PL bounds    x[565]
 LO bounds    x[566]    0
 PL bounds    x[566]
 LO bounds    x[567]    0
 PL bounds    x[567]
 LO bounds    x[568]    0
 PL bounds    x[568]
 LO bounds    x[569]    0
 PL bounds    x[569]
 LO bounds    x[570]    0
 PL bounds    x[570]
 LO bounds    x[571]    0
 PL bounds    x[571]
 LO bounds    x[572]    0
 PL bounds    x[572]
 LO bounds    x[573]    0
 PL bounds    x[573]
 LO bounds    x[574]    0
 PL bounds    x[574]
 LO bounds    x[575]    0
 PL bounds    x[575]
 LO bounds    x[576]    0
 PL bounds    x[576]
 LO bounds    x[577]    0
 PL bounds    x[577]
 LO bounds    x[578]    0
 PL bounds    x[578]
 LO bounds    x[579]    0
 PL bounds    x[579]
 LO bounds    x[580]    0
 PL bounds    x[580]
 LO bounds    x[581]    0
 PL bounds    x[581]
 LO bounds    x[582]    0
 PL bounds    x[582]
 LO bounds    x[583]    0
 PL bounds    x[583]
 LO bounds    x[584]    0
 PL bounds    x[584]
 LO bounds    x[585]    0
 PL bounds    x[585]
 LO bounds    x[586]    0
 PL bounds    x[586]
 LO bounds    x[587]    0
 PL bounds    x[587]
 LO bounds    x[588]    0
 PL bounds    x[588]
 LO bounds    x[589]    0
 PL bounds    x[589]
 LO bounds    x[590]    0
 PL bounds    x[590]
 LO bounds    x[591]    0
 PL bounds    x[591]
 LO bounds    x[592]    0
 PL bounds    x[592]
 LO bounds    x[593]    0
 PL bounds    x[593]
 LO bounds    x[594]    0
 PL bounds    x[594]
 LO bounds    x[595]    0
 PL bounds    x[595]
 LO bounds    x[596]    0
 PL bounds    x[596]
 LO bounds    x[597]    0
 PL bounds    x[597]
 LO bounds    x[598]    0
 PL bounds    x[598]
 LO bounds    x[599]    0
 PL bounds    x[599]
 LO bounds    x[600]    0
 PL bounds    x[600]
 LO bounds    x[601]    0
 PL bounds    x[601]
 LO bounds    x[602]    0
 PL bounds    x[602]
 LO bounds    x[603]    0
 PL bounds    x[603]
 LO bounds    x[604]    0
 PL bounds    x[604]
 LO bounds    x[605]    0
 PL bounds    x[605]
 LO bounds    x[606]    0
 PL bounds    x[606]
 LO bounds    x[607]    0
 PL bounds    x[607]
 LO bounds    x[608]    0
 PL bounds    x[608]
 LO bounds    x[609]    0
 PL bounds    x[609]
 LO bounds    x[610]    0
 PL bounds    x[610]
 LO bounds    x[611]    0
 PL bounds    x[611]
 LO bounds    x[612]    0
 PL bounds    x[612]
 LO bounds    x[613]    0
 PL bounds    x[613]
 LO bounds    x[614]    0
 PL bounds    x[614]
 LO bounds    x[615]    0
 PL bounds    x[615]
 LO bounds    x[616]    0
 PL bounds    x[616]
 LO bounds    x[617]    0
 PL bounds    x[617]
 LO bounds    x[618]    0
 PL bounds    x[618]
 LO bounds    x[619]    0
 PL bounds    x[619]
 LO bounds    x[620]    0
 PL bounds    x[620]
 LO bounds    x[621]    0
 PL bounds    x[621]
 LO bounds    x[622]    0
 PL bounds    x[622]
 LO bounds    x[623]    0
 PL bounds    x[623]
 LO bounds    x[624]    0
 PL bounds    x[624]
 LO bounds    x[625]    0
 PL bounds    x[625]
 LO bounds    x[626]    0
 PL bounds    x[626]
 LO bounds    x[627]    0
 PL bounds    x[627]
 LO bounds    x[628]    0
 PL bounds    x[628]
 LO bounds    x[629]    0
 PL bounds    x[629]
 LO bounds    x[630]    0
 PL bounds    x[630]
 LO bounds    x[631]    0
 PL bounds    x[631]
 LO bounds    x[632]    0
 PL bounds    x[632]
 LO bounds    x[633]    0
 PL bounds    x[633]
 LO bounds    x[634]    0
 PL bounds    x[634]
 LO bounds    x[635]    0
 PL bounds    x[635]
 LO bounds    x[636]    0
 PL bounds    x[636]
 LO bounds    x[637]    0
 PL bounds    x[637]
 LO bounds    x[638]    0
 PL bounds    x[638]
 LO bounds    x[639]    0
 PL bounds    x[639]
 LO bounds    x[640]    0
 PL bounds    x[640]
 LO bounds    x[641]    0
 PL bounds    x[641]
 LO bounds    x[642]    0
 PL bounds    x[642]
 LO bounds    x[643]    0
 PL bounds    x[643]
 LO bounds    x[644]    0
 PL bounds    x[644]
 LO bounds    x[645]    0
 PL bounds    x[645]
 LO bounds    x[646]    0
 PL bounds    x[646]
 LO bounds    x[647]    0
 PL bounds    x[647]
 LO bounds    x[648]    0
 PL bounds    x[648]
 LO bounds    x[649]    0
 PL bounds    x[649]
 LO bounds    x[650]    0
 PL bounds    x[650]
 LO bounds    x[651]    0
 PL bounds    x[651]
 LO bounds    x[652]    0
 PL bounds    x[652]
 LO bounds    x[653]    0
 PL bounds    x[653]
 LO bounds    x[654]    0
 PL bounds    x[654]
 LO bounds    x[655]    0
 PL bounds    x[655]
 LO bounds    x[656]    0
 PL bounds    x[656]
 LO bounds    x[657]    0
 PL bounds    x[657]
 LO bounds    x[658]    0
 PL bounds    x[658]
 LO bounds    x[659]    0
 PL bounds    x[659]
 LO bounds    x[660]    0
 PL bounds    x[660]
 LO bounds    x[661]    0
 PL bounds    x[661]
 LO bounds    x[662]    0
 PL bounds    x[662]
 LO bounds    x[663]    0
 PL bounds    x[663]
 LO bounds    x[664]    0
 PL bounds    x[664]
 LO bounds    x[665]    0
 PL bounds    x[665]
 LO bounds    x[666]    0
 PL bounds    x[666]
 LO bounds    x[667]    0
 PL bounds    x[667]
 LO bounds    x[668]    0
 PL bounds    x[668]
 LO bounds    x[669]    0
 PL bounds    x[669]
 LO bounds    x[670]    0
 PL bounds    x[670]
 LO bounds    x[671]    0
 PL bounds    x[671]
 LO bounds    x[672]    0
 PL bounds    x[672]
 LO bounds    x[673]    0
 PL bounds    x[673]
 LO bounds    x[674]    0
 PL bounds    x[674]
 LO bounds    x[675]    0
 PL bounds    x[675]
 LO bounds    x[676]    0
 PL bounds    x[676]
 LO bounds    x[677]    0
 PL bounds    x[677]
 LO bounds    x[678]    0
 PL bounds    x[678]
 LO bounds    x[679]    0
 PL bounds    x[679]
 LO bounds    x[680]    0
 PL bounds    x[680]
 LO bounds    x[681]    0
 PL bounds    x[681]
 LO bounds    x[682]    0
 PL bounds    x[682]
 LO bounds    x[683]    0
 PL bounds    x[683]
 LO bounds    x[684]    0
 PL bounds    x[684]
 LO bounds    x[685]    0
 PL bounds    x[685]
 LO bounds    x[686]    0
 PL bounds    x[686]
 LO bounds    x[687]    0
 PL bounds    x[687]
 LO bounds    x[688]    0
 PL bounds    x[688]
 LO bounds    x[689]    0
 PL bounds    x[689]
 LO bounds    x[690]    0
 PL bounds    x[690]
 LO bounds    x[691]    0
 PL bounds    x[691]
 LO bounds    x[692]    0
 PL bounds    x[692]
 LO bounds    x[693]    0
 PL bounds    x[693]
 LO bounds    x[694]    0
 PL bounds    x[694]
 LO bounds    x[695]    0
 PL bounds    x[695]
 LO bounds    x[696]    0
 PL bounds    x[696]
 LO bounds    x[697]    0
 PL bounds    x[697]
 LO bounds    x[698]    0
 PL bounds    x[698]
 LO bounds    x[699]    0
 PL bounds    x[699]
 LO bounds    x[700]    0
 PL bounds    x[700]
 LO bounds    x[701]    0
 PL bounds    x[701]
 LO bounds    x[702]    0
 PL bounds    x[702]
 LO bounds    x[703]    0
 PL bounds    x[703]
 LO bounds    x[704]    0
 PL bounds    x[704]
 LO bounds    x[705]    0
 PL bounds    x[705]
 LO bounds    x[706]    0
 PL bounds    x[706]
 LO bounds    x[707]    0
 PL bounds    x[707]
 LO bounds    x[708]    0
 PL bounds    x[708]
 LO bounds    x[709]    0
 PL bounds    x[709]
 LO bounds    x[710]    0
 PL bounds    x[710]
 LO bounds    x[711]    0
 PL bounds    x[711]
 LO bounds    x[712]    0
 PL bounds    x[712]
 LO bounds    x[713]    0
 PL bounds    x[713]
 LO bounds    x[714]    0
 PL bounds    x[714]
 LO bounds    x[715]    0
 PL bounds    x[715]
 LO bounds    x[716]    0
 PL bounds    x[716]
 LO bounds    x[717]    0
 PL bounds    x[717]
 LO bounds    x[718]    0
 PL bounds    x[718]
 LO bounds    x[719]    0
 PL bounds    x[719]
 LO bounds    x[720]    0
 PL bounds    x[720]
 LO bounds    x[721]    0
 PL bounds    x[721]
 LO bounds    x[722]    0
 PL bounds    x[722]
 LO bounds    x[723]    0
 PL bounds    x[723]
 LO bounds    x[724]    0
 PL bounds    x[724]
 LO bounds    x[725]    0
 PL bounds    x[725]
 LO bounds    x[726]    0
 PL bounds    x[726]
 LO bounds    x[727]    0
 PL bounds    x[727]
 LO bounds    x[728]    0
 PL bounds    x[728]
 LO bounds    x[729]    0
 PL bounds    x[729]
 LO bounds    x[730]    0
 PL bounds    x[730]
 LO bounds    x[731]    0
 PL bounds    x[731]
 LO bounds    x[732]    0
 PL bounds    x[732]
 LO bounds    x[733]    0
 PL bounds    x[733]
 LO bounds    x[734]    0
 PL bounds    x[734]
 LO bounds    x[735]    0
 PL bounds    x[735]
 LO bounds    x[736]    0
 PL bounds    x[736]
 LO bounds    x[737]    0
 PL bounds    x[737]
 LO bounds    x[738]    0
 PL bounds    x[738]
 LO bounds    x[739]    0
 PL bounds    x[739]
 LO bounds    x[740]    0
 PL bounds    x[740]
 LO bounds    x[741]    0
 PL bounds    x[741]
 LO bounds    x[742]    0
 PL bounds    x[742]
 LO bounds    x[743]    0
 PL bounds    x[743]
 LO bounds    x[744]    0
 PL bounds    x[744]
 LO bounds    x[745]    0
 PL bounds    x[745]
 LO bounds    x[746]    0
 PL bounds    x[746]
 LO bounds    x[747]    0
 PL bounds    x[747]
 LO bounds    x[748]    0
 PL bounds    x[748]
 LO bounds    x[749]    0
 PL bounds    x[749]
 LO bounds    x[750]    0
 PL bounds    x[750]
 LO bounds    x[751]    0
 PL bounds    x[751]
 LO bounds    x[752]    0
 PL bounds    x[752]
 LO bounds    x[753]    0
 PL bounds    x[753]
 LO bounds    x[754]    0
 PL bounds    x[754]
 LO bounds    x[755]    0
 PL bounds    x[755]
 LO bounds    x[756]    0
 PL bounds    x[756]
 LO bounds    x[757]    0
 PL bounds    x[757]
 LO bounds    x[758]    0
 PL bounds    x[758]
 LO bounds    x[759]    0
 PL bounds    x[759]
 LO bounds    x[760]    0
 PL bounds    x[760]
 LO bounds    x[761]    0
 PL bounds    x[761]
 LO bounds    x[762]    0
 PL bounds    x[762]
 LO bounds    x[763]    0
 PL bounds    x[763]
 LO bounds    x[764]    0
 PL bounds    x[764]
 LO bounds    x[765]    0
 PL bounds    x[765]
 LO bounds    x[766]    0
 PL bounds    x[766]
 LO bounds    x[767]    0
 PL bounds    x[767]
 LO bounds    x[768]    0
 PL bounds    x[768]
 LO bounds    x[769]    0
 PL bounds    x[769]
 LO bounds    x[770]    0
 PL bounds    x[770]
 LO bounds    x[771]    0
 PL bounds    x[771]
 LO bounds    x[772]    0
 PL bounds    x[772]
 LO bounds    x[773]    0
 PL bounds    x[773]
 LO bounds    x[774]    0
 PL bounds    x[774]
 LO bounds    x[775]    0
 PL bounds    x[775]
 LO bounds    x[776]    0
 PL bounds    x[776]
 LO bounds    x[777]    0
 PL bounds    x[777]
 LO bounds    x[778]    0
 PL bounds    x[778]
 LO bounds    x[779]    0
 PL bounds    x[779]
 LO bounds    x[780]    0
 PL bounds    x[780]
 LO bounds    x[781]    0
 PL bounds    x[781]
 LO bounds    x[782]    0
 PL bounds    x[782]
 LO bounds    x[783]    0
 PL bounds    x[783]
 LO bounds    x[784]    0
 PL bounds    x[784]
 LO bounds    x[785]    0
 PL bounds    x[785]
 LO bounds    x[786]    0
 PL bounds    x[786]
 LO bounds    x[787]    0
 PL bounds    x[787]
 LO bounds    x[788]    0
 PL bounds    x[788]
 LO bounds    x[789]    0
 PL bounds    x[789]
 LO bounds    x[790]    0
 PL bounds    x[790]
 LO bounds    x[791]    0
 PL bounds    x[791]
 LO bounds    x[792]    0
 PL bounds    x[792]
 LO bounds    x[793]    0
 PL bounds    x[793]
 LO bounds    x[794]    0
 PL bounds    x[794]
 LO bounds    x[795]    0
 PL bounds    x[795]
 LO bounds    x[796]    0
 PL bounds    x[796]
 LO bounds    x[797]    0
 PL bounds    x[797]
 LO bounds    x[798]    0
 PL bounds    x[798]
 LO bounds    x[799]    0
 PL bounds    x[799]
 LO bounds    x[800]    0
 PL bounds    x[800]
 LO bounds    x[801]    0
 PL bounds    x[801]
 LO bounds    x[802]    0
 PL bounds    x[802]
 LO bounds    x[803]    0
 PL bounds    x[803]
 LO bounds    x[804]    0
 PL bounds    x[804]
 LO bounds    x[805]    0
 PL bounds    x[805]
 LO bounds    x[806]    0
 PL bounds    x[806]
 LO bounds    x[807]    0
 PL bounds    x[807]
 LO bounds    x[808]    0
 PL bounds    x[808]
 LO bounds    x[809]    0
 PL bounds    x[809]
 LO bounds    x[810]    0
 PL bounds    x[810]
 LO bounds    x[811]    0
 PL bounds    x[811]
 LO bounds    x[812]    0
 PL bounds    x[812]
 LO bounds    x[813]    0
 PL bounds    x[813]
 LO bounds    x[814]    0
 PL bounds    x[814]
 LO bounds    x[815]    0
 PL bounds    x[815]
 LO bounds    x[816]    0
 PL bounds    x[816]
 LO bounds    x[817]    0
 PL bounds    x[817]
 LO bounds    x[818]    0
 PL bounds    x[818]
 LO bounds    x[819]    0
 PL bounds    x[819]
 LO bounds    x[820]    0
 PL bounds    x[820]
 LO bounds    x[821]    0
 PL bounds    x[821]
 LO bounds    x[822]    0
 PL bounds    x[822]
 LO bounds    x[823]    0
 PL bounds    x[823]
 LO bounds    x[824]    0
 PL bounds    x[824]
 LO bounds    x[825]    0
 PL bounds    x[825]
 LO bounds    x[826]    0
 PL bounds    x[826]
 LO bounds    x[827]    0
 PL bounds    x[827]
 LO bounds    x[828]    0
 PL bounds    x[828]
 LO bounds    x[829]    0
 PL bounds    x[829]
 LO bounds    x[830]    0
 PL bounds    x[830]
 LO bounds    x[831]    0
 PL bounds    x[831]
 LO bounds    x[832]    0
 PL bounds    x[832]
 LO bounds    x[833]    0
 PL bounds    x[833]
 LO bounds    x[834]    0
 PL bounds    x[834]
 LO bounds    x[835]    0
 PL bounds    x[835]
 LO bounds    x[836]    0
 PL bounds    x[836]
 LO bounds    x[837]    0
 PL bounds    x[837]
 LO bounds    x[838]    0
 PL bounds    x[838]
 LO bounds    x[839]    0
 PL bounds    x[839]
 LO bounds    x[840]    0
 PL bounds    x[840]
 LO bounds    x[841]    0
 PL bounds    x[841]
 LO bounds    x[842]    0
 PL bounds    x[842]
 LO bounds    x[843]    0
 PL bounds    x[843]
 LO bounds    x[844]    0
 PL bounds    x[844]
 LO bounds    x[845]    0
 PL bounds    x[845]
 LO bounds    x[846]    0
 PL bounds    x[846]
 LO bounds    x[847]    0
 PL bounds    x[847]
 LO bounds    x[848]    0
 PL bounds    x[848]
 LO bounds    x[849]    0
 PL bounds    x[849]
 LO bounds    x[850]    0
 PL bounds    x[850]
 LO bounds    x[851]    0
 PL bounds    x[851]
 LO bounds    x[852]    0
 PL bounds    x[852]
 LO bounds    x[853]    0
 PL bounds    x[853]
 LO bounds    x[854]    0
 PL bounds    x[854]
 LO bounds    x[855]    0
 PL bounds    x[855]
 LO bounds    x[856]    0
 PL bounds    x[856]
 LO bounds    x[857]    0
 PL bounds    x[857]
 LO bounds    x[858]    0
 PL bounds    x[858]
 LO bounds    x[859]    0
 PL bounds    x[859]
 LO bounds    x[860]    0
 PL bounds    x[860]
 LO bounds    x[861]    0
 PL bounds    x[861]
 LO bounds    x[862]    0
 PL bounds    x[862]
 LO bounds    x[863]    0
 PL bounds    x[863]
 LO bounds    x[864]    0
 PL bounds    x[864]
 LO bounds    x[865]    0
 PL bounds    x[865]
 LO bounds    x[866]    0
 PL bounds    x[866]
 LO bounds    x[867]    0
 PL bounds    x[867]
 LO bounds    x[868]    0
 PL bounds    x[868]
 LO bounds    x[869]    0
 PL bounds    x[869]
 LO bounds    x[870]    0
 PL bounds    x[870]
 LO bounds    x[871]    0
 PL bounds    x[871]
 LO bounds    x[872]    0
 PL bounds    x[872]
 LO bounds    x[873]    0
 PL bounds    x[873]
 LO bounds    x[874]    0
 PL bounds    x[874]
 LO bounds    x[875]    0
 PL bounds    x[875]
 LO bounds    x[876]    0
 PL bounds    x[876]
 LO bounds    x[877]    0
 PL bounds    x[877]
 LO bounds    x[878]    0
 PL bounds    x[878]
 LO bounds    x[879]    0
 PL bounds    x[879]
 LO bounds    x[880]    0
 PL bounds    x[880]
 LO bounds    x[881]    0
 PL bounds    x[881]
 LO bounds    x[882]    0
 PL bounds    x[882]
 LO bounds    x[883]    0
 PL bounds    x[883]
 LO bounds    x[884]    0
 PL bounds    x[884]
 LO bounds    x[885]    0
 PL bounds    x[885]
 LO bounds    x[886]    0
 PL bounds    x[886]
 LO bounds    x[887]    0
 PL bounds    x[887]
 LO bounds    x[888]    0
 PL bounds    x[888]
 LO bounds    x[889]    0
 PL bounds    x[889]
 LO bounds    x[890]    0
 PL bounds    x[890]
 LO bounds    x[891]    0
 PL bounds    x[891]
 LO bounds    x[892]    0
 PL bounds    x[892]
 LO bounds    x[893]    0
 PL bounds    x[893]
 LO bounds    x[894]    0
 PL bounds    x[894]
 LO bounds    x[895]    0
 PL bounds    x[895]
 LO bounds    x[896]    0
 PL bounds    x[896]
 LO bounds    x[897]    0
 PL bounds    x[897]
 LO bounds    x[898]    0
 PL bounds    x[898]
 LO bounds    x[899]    0
 PL bounds    x[899]
 LO bounds    x[900]    0
 PL bounds    x[900]
 LO bounds    x[901]    0
 PL bounds    x[901]
 LO bounds    x[902]    0
 PL bounds    x[902]
 LO bounds    x[903]    0
 PL bounds    x[903]
 LO bounds    x[904]    0
 PL bounds    x[904]
 LO bounds    x[905]    0
 PL bounds    x[905]
 LO bounds    x[906]    0
 PL bounds    x[906]
 LO bounds    x[907]    0
 PL bounds    x[907]
 LO bounds    x[908]    0
 PL bounds    x[908]
 LO bounds    x[909]    0
 PL bounds    x[909]
 LO bounds    x[910]    0
 PL bounds    x[910]
 LO bounds    x[911]    0
 PL bounds    x[911]
 LO bounds    x[912]    0
 PL bounds    x[912]
 LO bounds    x[913]    0
 PL bounds    x[913]
 LO bounds    x[914]    0
 PL bounds    x[914]
 LO bounds    x[915]    0
 PL bounds    x[915]
 LO bounds    x[916]    0
 PL bounds    x[916]
 LO bounds    x[917]    0
 PL bounds    x[917]
 LO bounds    x[918]    0
 PL bounds    x[918]
 LO bounds    x[919]    0
 PL bounds    x[919]
 LO bounds    x[920]    0
 PL bounds    x[920]
 LO bounds    x[921]    0
 PL bounds    x[921]
 LO bounds    x[922]    0
 PL bounds    x[922]
 LO bounds    x[923]    0
 PL bounds    x[923]
 LO bounds    x[924]    0
 PL bounds    x[924]
 LO bounds    x[925]    0
 PL bounds    x[925]
 LO bounds    x[926]    0
 PL bounds    x[926]
 LO bounds    x[927]    0
 PL bounds    x[927]
 LO bounds    x[928]    0
 PL bounds    x[928]
 LO bounds    x[929]    0
 PL bounds    x[929]
 LO bounds    x[930]    0
 PL bounds    x[930]
 LO bounds    x[931]    0
 PL bounds    x[931]
 LO bounds    x[932]    0
 PL bounds    x[932]
 LO bounds    x[933]    0
 PL bounds    x[933]
 LO bounds    x[934]    0
 PL bounds    x[934]
 LO bounds    x[935]    0
 PL bounds    x[935]
 LO bounds    x[936]    0
 PL bounds    x[936]
 LO bounds    x[937]    0
 PL bounds    x[937]
 LO bounds    x[938]    0
 PL bounds    x[938]
 LO bounds    x[939]    0
 PL bounds    x[939]
 LO bounds    x[940]    0
 PL bounds    x[940]
 LO bounds    x[941]    0
 PL bounds    x[941]
 LO bounds    x[942]    0
 PL bounds    x[942]
 LO bounds    x[943]    0
 PL bounds    x[943]
 LO bounds    x[944]    0
 PL bounds    x[944]
 LO bounds    x[945]    0
 PL bounds    x[945]
 LO bounds    x[946]    0
 PL bounds    x[946]
 LO bounds    x[947]    0
 PL bounds    x[947]
 LO bounds    x[948]    0
 PL bounds    x[948]
 LO bounds    x[949]    0
 PL bounds    x[949]
 LO bounds    x[950]    0
 PL bounds    x[950]
 LO bounds    x[951]    0
 PL bounds    x[951]
 LO bounds    x[952]    0
 PL bounds    x[952]
 LO bounds    x[953]    0
 PL bounds    x[953]
 LO bounds    x[954]    0
 PL bounds    x[954]
 LO bounds    x[955]    0
 PL bounds    x[955]
 LO bounds    x[956]    0
 PL bounds    x[956]
 LO bounds    x[957]    0
 PL bounds    x[957]
 LO bounds    x[958]    0
 PL bounds    x[958]
 LO bounds    x[959]    0
 PL bounds    x[959]
 LO bounds    x[960]    0
 PL bounds    x[960]
 LO bounds    x[961]    0
 PL bounds    x[961]
 LO bounds    x[962]    0
 PL bounds    x[962]
 LO bounds    x[963]    0
 PL bounds    x[963]
 LO bounds    x[964]    0
 PL bounds    x[964]
 LO bounds    x[965]    0
 PL bounds    x[965]
 LO bounds    x[966]    0
 PL bounds    x[966]
 LO bounds    x[967]    0
 PL bounds    x[967]
 LO bounds    x[968]    0
 PL bounds    x[968]
 LO bounds    x[969]    0
 PL bounds    x[969]
 LO bounds    x[970]    0
 PL bounds    x[970]
 LO bounds    x[971]    0
 PL bounds    x[971]
 LO bounds    x[972]    0
 PL bounds    x[972]
 LO bounds    x[973]    0
 PL bounds    x[973]
 LO bounds    x[974]    0
 PL bounds    x[974]
 LO bounds    x[975]    0
 PL bounds    x[975]
 LO bounds    x[976]    0
 PL bounds    x[976]
 LO bounds    x[977]    0
 PL bounds    x[977]
 LO bounds    x[978]    0
 PL bounds    x[978]
 LO bounds    x[979]    0
 PL bounds    x[979]
 LO bounds    x[980]    0
 PL bounds    x[980]
 LO bounds    x[981]    0
 PL bounds    x[981]
 LO bounds    x[982]    0
 PL bounds    x[982]
 LO bounds    x[983]    0
 PL bounds    x[983]
 LO bounds    x[984]    0
 PL bounds    x[984]
 LO bounds    x[985]    0
 PL bounds    x[985]
 LO bounds    x[986]    0
 PL bounds    x[986]
 LO bounds    x[987]    0
 PL bounds    x[987]
 LO bounds    x[988]    0
 PL bounds    x[988]
 LO bounds    x[989]    0
 PL bounds    x[989]
 LO bounds    x[990]    0
 PL bounds    x[990]
 LO bounds    x[991]    0
 PL bounds    x[991]
 LO bounds    x[992]    0
 PL bounds    x[992]
 LO bounds    x[993]    0
 PL bounds    x[993]
 LO bounds    x[994]    0
 PL bounds    x[994]
 LO bounds    x[995]    0
 PL bounds    x[995]
 LO bounds    x[996]    0
 PL bounds    x[996]
 LO bounds    x[997]    0
 PL bounds    x[997]
 LO bounds    x[998]    0
 PL bounds    x[998]
 LO bounds    x[999]    0
 PL bounds    x[999]
 LO bounds    x[1000]   0
 PL bounds    x[1000]
 LO bounds    x[1001]   0
 PL bounds    x[1001]
 LO bounds    x[1002]   0
 PL bounds    x[1002]
 LO bounds    x[1003]   0
 PL bounds    x[1003]
 LO bounds    x[1004]   0
 PL bounds    x[1004]
 LO bounds    x[1005]   0
 PL bounds    x[1005]
 LO bounds    x[1006]   0
 PL bounds    x[1006]
 LO bounds    x[1007]   0
 PL bounds    x[1007]
 LO bounds    x[1008]   0
 PL bounds    x[1008]
 LO bounds    x[1009]   0
 PL bounds    x[1009]
 LO bounds    x[1010]   0
 PL bounds    x[1010]
 LO bounds    x[1011]   0
 PL bounds    x[1011]
 LO bounds    x[1012]   0
 PL bounds    x[1012]
 LO bounds    x[1013]   0
 PL bounds    x[1013]
 LO bounds    x[1014]   0
 PL bounds    x[1014]
 LO bounds    x[1015]   0
 PL bounds    x[1015]
 LO bounds    x[1016]   0
 PL bounds    x[1016]
 LO bounds    x[1017]   0
 PL bounds    x[1017]
 LO bounds    x[1018]   0
 PL bounds    x[1018]
 LO bounds    x[1019]   0
 PL bounds    x[1019]
 LO bounds    x[1020]   0
 PL bounds    x[1020]
 LO bounds    x[1021]   0
 PL bounds    x[1021]
 LO bounds    x[1022]   0
 PL bounds    x[1022]
 LO bounds    x[1023]   0
 PL bounds    x[1023]
 LO bounds    x[1024]   0
 PL bounds    x[1024]
 LO bounds    x[1025]   0
 PL bounds    x[1025]
 LO bounds    x[1026]   0
 PL bounds    x[1026]
 LO bounds    x[1027]   0
 PL bounds    x[1027]
 LO bounds    x[1028]   0
 PL bounds    x[1028]
 LO bounds    x[1029]   0
 PL bounds    x[1029]
 LO bounds    x[1030]   0
 PL bounds    x[1030]
 LO bounds    x[1031]   0
 PL bounds    x[1031]
 LO bounds    x[1032]   0
 PL bounds    x[1032]
 LO bounds    x[1033]   0
 PL bounds    x[1033]
 LO bounds    x[1034]   0
 PL bounds    x[1034]
 LO bounds    x[1035]   0
 PL bounds    x[1035]
 LO bounds    x[1036]   0
 PL bounds    x[1036]
 LO bounds    x[1037]   0
 PL bounds    x[1037]
 LO bounds    x[1038]   0
 PL bounds    x[1038]
 LO bounds    x[1039]   0
 PL bounds    x[1039]
 LO bounds    x[1040]   0
 PL bounds    x[1040]
 LO bounds    x[1041]   0
 PL bounds    x[1041]
 LO bounds    x[1042]   0
 PL bounds    x[1042]
 LO bounds    x[1043]   0
 PL bounds    x[1043]
 LO bounds    x[1044]   0
 PL bounds    x[1044]
 LO bounds    x[1045]   0
 PL bounds    x[1045]
 LO bounds    x[1046]   0
 PL bounds    x[1046]
 LO bounds    x[1047]   0
 PL bounds    x[1047]
 LO bounds    x[1048]   0
 PL bounds    x[1048]
 LO bounds    x[1049]   0
 PL bounds    x[1049]
 LO bounds    x[1050]   0
 PL bounds    x[1050]
 LO bounds    x[1051]   0
 PL bounds    x[1051]
 LO bounds    x[1052]   0
 PL bounds    x[1052]
 LO bounds    x[1053]   0
 PL bounds    x[1053]
 LO bounds    x[1054]   0
 PL bounds    x[1054]
 LO bounds    x[1055]   0
 PL bounds    x[1055]
 LO bounds    x[1056]   0
 PL bounds    x[1056]
 LO bounds    x[1057]   0
 PL bounds    x[1057]
 LO bounds    x[1058]   0
 PL bounds    x[1058]
 LO bounds    x[1059]   0
 PL bounds    x[1059]
 LO bounds    x[1060]   0
 PL bounds    x[1060]
 LO bounds    x[1061]   0
 PL bounds    x[1061]
 LO bounds    x[1062]   0
 PL bounds    x[1062]
 LO bounds    x[1063]   0
 PL bounds    x[1063]
 LO bounds    x[1064]   0
 PL bounds    x[1064]
 LO bounds    x[1065]   0
 PL bounds    x[1065]
 LO bounds    x[1066]   0
 PL bounds    x[1066]
 LO bounds    x[1067]   0
 PL bounds    x[1067]
 LO bounds    x[1068]   0
 PL bounds    x[1068]
 LO bounds    x[1069]   0
 PL bounds    x[1069]
 LO bounds    x[1070]   0
 PL bounds    x[1070]
 LO bounds    x[1071]   0
 PL bounds    x[1071]
 LO bounds    x[1072]   0
 PL bounds    x[1072]
 LO bounds    x[1073]   0
 PL bounds    x[1073]
 LO bounds    x[1074]   0
 PL bounds    x[1074]
 LO bounds    x[1075]   0
 PL bounds    x[1075]
 LO bounds    x[1076]   0
 PL bounds    x[1076]
 LO bounds    x[1077]   0
 PL bounds    x[1077]
 LO bounds    x[1078]   0
 PL bounds    x[1078]
 LO bounds    x[1079]   0
 PL bounds    x[1079]
 LO bounds    x[1080]   0
 PL bounds    x[1080]
 LO bounds    x[1081]   0
 PL bounds    x[1081]
 LO bounds    x[1082]   0
 PL bounds    x[1082]
 LO bounds    x[1083]   0
 PL bounds    x[1083]
 LO bounds    x[1084]   0
 PL bounds    x[1084]
 LO bounds    x[1085]   0
 PL bounds    x[1085]
 LO bounds    x[1086]   0
 PL bounds    x[1086]
 LO bounds    x[1087]   0
 PL bounds    x[1087]
 LO bounds    x[1088]   0
 PL bounds    x[1088]
 LO bounds    x[1089]   0
 PL bounds    x[1089]
 LO bounds    x[1090]   0
 PL bounds    x[1090]
 LO bounds    x[1091]   0
 PL bounds    x[1091]
 LO bounds    x[1092]   0
 PL bounds    x[1092]
 LO bounds    x[1093]   0
 PL bounds    x[1093]
 LO bounds    x[1094]   0
 PL bounds    x[1094]
 LO bounds    x[1095]   0
 PL bounds    x[1095]
 LO bounds    x[1096]   0
 PL bounds    x[1096]
 LO bounds    x[1097]   0
 PL bounds    x[1097]
 LO bounds    x[1098]   0
 PL bounds    x[1098]
 LO bounds    x[1099]   0
 PL bounds    x[1099]
 LO bounds    x[1100]   0
 PL bounds    x[1100]
 LO bounds    x[1101]   0
 PL bounds    x[1101]
 LO bounds    x[1102]   0
 PL bounds    x[1102]
 LO bounds    x[1103]   0
 PL bounds    x[1103]
 LO bounds    x[1104]   0
 PL bounds    x[1104]
 LO bounds    x[1105]   0
 PL bounds    x[1105]
 LO bounds    x[1106]   0
 PL bounds    x[1106]
 LO bounds    x[1107]   0
 PL bounds    x[1107]
 LO bounds    x[1108]   0
 PL bounds    x[1108]
 LO bounds    x[1109]   0
 PL bounds    x[1109]
 LO bounds    x[1110]   0
 PL bounds    x[1110]
 LO bounds    x[1111]   0
 PL bounds    x[1111]
 LO bounds    x[1112]   0
 PL bounds    x[1112]
 LO bounds    x[1113]   0
 PL bounds    x[1113]
 LO bounds    x[1114]   0
 PL bounds    x[1114]
 LO bounds    x[1115]   0
 PL bounds    x[1115]
 LO bounds    x[1116]   0
 PL bounds    x[1116]
 LO bounds    x[1117]   0
 PL bounds    x[1117]
 LO bounds    x[1118]   0
 PL bounds    x[1118]
 LO bounds    x[1119]   0
 PL bounds    x[1119]
 LO bounds    x[1120]   0
 PL bounds    x[1120]
 LO bounds    x[1121]   0
 PL bounds    x[1121]
 LO bounds    x[1122]   0
 PL bounds    x[1122]
 LO bounds    x[1123]   0
 PL bounds    x[1123]
 LO bounds    x[1124]   0
 PL bounds    x[1124]
 LO bounds    x[1125]   0
 PL bounds    x[1125]
 LO bounds    x[1126]   0
 PL bounds    x[1126]
 LO bounds    x[1127]   0
 PL bounds    x[1127]
 LO bounds    x[1128]   0
 PL bounds    x[1128]
 LO bounds    x[1129]   0
 PL bounds    x[1129]
 LO bounds    x[1130]   0
 PL bounds    x[1130]
 LO bounds    x[1131]   0
 PL bounds    x[1131]
 LO bounds    x[1132]   0
 PL bounds    x[1132]
 LO bounds    x[1133]   0
 PL bounds    x[1133]
 LO bounds    x[1134]   0
 PL bounds    x[1134]
 LO bounds    x[1135]   0
 PL bounds    x[1135]
 LO bounds    x[1136]   0
 PL bounds    x[1136]
 LO bounds    x[1137]   0
 PL bounds    x[1137]
 LO bounds    x[1138]   0
 PL bounds    x[1138]
 LO bounds    x[1139]   0
 PL bounds    x[1139]
 LO bounds    x[1140]   0
 PL bounds    x[1140]
 LO bounds    x[1141]   0
 PL bounds    x[1141]
 LO bounds    x[1142]   0
 PL bounds    x[1142]
 LO bounds    x[1143]   0
 PL bounds    x[1143]
 LO bounds    x[1144]   0
 PL bounds    x[1144]
 LO bounds    x[1145]   0
 PL bounds    x[1145]
 LO bounds    x[1146]   0
 PL bounds    x[1146]
 LO bounds    x[1147]   0
 PL bounds    x[1147]
 LO bounds    x[1148]   0
 PL bounds    x[1148]
 LO bounds    x[1149]   0
 PL bounds    x[1149]
 LO bounds    x[1150]   0
 PL bounds    x[1150]
 LO bounds    x[1151]   0
 PL bounds    x[1151]
 LO bounds    x[1152]   0
 PL bounds    x[1152]
 LO bounds    x[1153]   0
 PL bounds    x[1153]
 LO bounds    x[1154]   0
 PL bounds    x[1154]
 LO bounds    x[1155]   0
 PL bounds    x[1155]
 LO bounds    x[1156]   0
 PL bounds    x[1156]
 LO bounds    x[1157]   0
 PL bounds    x[1157]
 LO bounds    x[1158]   0
 PL bounds    x[1158]
 LO bounds    x[1159]   0
 PL bounds    x[1159]
 LO bounds    x[1160]   0
 PL bounds    x[1160]
 LO bounds    x[1161]   0
 PL bounds    x[1161]
 LO bounds    x[1162]   0
 PL bounds    x[1162]
 LO bounds    x[1163]   0
 PL bounds    x[1163]
 LO bounds    x[1164]   0
 PL bounds    x[1164]
 LO bounds    x[1165]   0
 PL bounds    x[1165]
 LO bounds    x[1166]   0
 PL bounds    x[1166]
 LO bounds    x[1167]   0
 PL bounds    x[1167]
 LO bounds    x[1168]   0
 PL bounds    x[1168]
 LO bounds    x[1169]   0
 PL bounds    x[1169]
 LO bounds    x[1170]   0
 PL bounds    x[1170]
 LO bounds    x[1171]   0
 PL bounds    x[1171]
 LO bounds    x[1172]   0
 PL bounds    x[1172]
 LO bounds    x[1173]   0
 PL bounds    x[1173]
 LO bounds    x[1174]   0
 PL bounds    x[1174]
 LO bounds    x[1175]   0
 PL bounds    x[1175]
 LO bounds    x[1176]   0
 PL bounds    x[1176]
 LO bounds    x[1177]   0
 PL bounds    x[1177]
 LO bounds    x[1178]   0
 PL bounds    x[1178]
 LO bounds    x[1179]   0
 PL bounds    x[1179]
 LO bounds    x[1180]   0
 PL bounds    x[1180]
 LO bounds    x[1181]   0
 PL bounds    x[1181]
 LO bounds    x[1182]   0
 PL bounds    x[1182]
 LO bounds    x[1183]   0
 PL bounds    x[1183]
 LO bounds    x[1184]   0
 PL bounds    x[1184]
 LO bounds    x[1185]   0
 PL bounds    x[1185]
 LO bounds    x[1186]   0
 PL bounds    x[1186]
 LO bounds    x[1187]   0
 PL bounds    x[1187]
 LO bounds    x[1188]   0
 PL bounds    x[1188]
 LO bounds    x[1189]   0
 PL bounds    x[1189]
 LO bounds    x[1190]   0
 PL bounds    x[1190]
 LO bounds    x[1191]   0
 PL bounds    x[1191]
 LO bounds    x[1192]   0
 PL bounds    x[1192]
 LO bounds    x[1193]   0
 PL bounds    x[1193]
 LO bounds    x[1194]   0
 PL bounds    x[1194]
 LO bounds    x[1195]   0
 PL bounds    x[1195]
 LO bounds    x[1196]   0
 PL bounds    x[1196]
 LO bounds    x[1197]   0
 PL bounds    x[1197]
 LO bounds    x[1198]   0
 PL bounds    x[1198]
 LO bounds    x[1199]   0
 PL bounds    x[1199]
 LO bounds    x[1200]   0
 PL bounds    x[1200]
 LO bounds    x[1201]   0
 PL bounds    x[1201]
 LO bounds    x[1202]   0
 PL bounds    x[1202]
 LO bounds    x[1203]   0
 PL bounds    x[1203]
 LO bounds    x[1204]   0
 PL bounds    x[1204]
 LO bounds    x[1205]   0
 PL bounds    x[1205]
 LO bounds    x[1206]   0
 PL bounds    x[1206]
 LO bounds    x[1207]   0
 PL bounds    x[1207]
 LO bounds    x[1208]   0
 PL bounds    x[1208]
 LO bounds    x[1209]   0
 PL bounds    x[1209]
 LO bounds    x[1210]   0
 PL bounds    x[1210]
 LO bounds    x[1211]   0
 PL bounds    x[1211]
 LO bounds    x[1212]   0
 PL bounds    x[1212]
 LO bounds    x[1213]   0
 PL bounds    x[1213]
 LO bounds    x[1214]   0
 PL bounds    x[1214]
 LO bounds    x[1215]   0
 PL bounds    x[1215]
 LO bounds    x[1216]   0
 PL bounds    x[1216]
 LO bounds    x[1217]   0
 PL bounds    x[1217]
 LO bounds    x[1218]   0
 PL bounds    x[1218]
 LO bounds    x[1219]   0
 PL bounds    x[1219]
 LO bounds    x[1220]   0
 PL bounds    x[1220]
 LO bounds    x[1221]   0
 PL bounds    x[1221]
 LO bounds    x[1222]   0
 PL bounds    x[1222]
 LO bounds    x[1223]   0
 PL bounds    x[1223]
 LO bounds    x[1224]   0
 PL bounds    x[1224]
 LO bounds    x[1225]   0
 PL bounds    x[1225]
 LO bounds    x[1226]   0
 PL bounds    x[1226]
 LO bounds    x[1227]   0
 PL bounds    x[1227]
 LO bounds    x[1228]   0
 PL bounds    x[1228]
 LO bounds    x[1229]   0
 PL bounds    x[1229]
 LO bounds    x[1230]   0
 PL bounds    x[1230]
 LO bounds    x[1231]   0
 PL bounds    x[1231]
 LO bounds    x[1232]   0
 PL bounds    x[1232]
 LO bounds    x[1233]   0
 PL bounds    x[1233]
 LO bounds    x[1234]   0
 PL bounds    x[1234]
 LO bounds    x[1235]   0
 PL bounds    x[1235]
 LO bounds    x[1236]   0
 PL bounds    x[1236]
 LO bounds    x[1237]   0
 PL bounds    x[1237]
 LO bounds    x[1238]   0
 PL bounds    x[1238]
 LO bounds    x[1239]   0
 PL bounds    x[1239]
 LO bounds    x[1240]   0
 PL bounds    x[1240]
 LO bounds    x[1241]   0
 PL bounds    x[1241]
 LO bounds    x[1242]   0
 PL bounds    x[1242]
 LO bounds    x[1243]   0
 PL bounds    x[1243]
 LO bounds    x[1244]   0
 PL bounds    x[1244]
 LO bounds    x[1245]   0
 PL bounds    x[1245]
 LO bounds    x[1246]   0
 PL bounds    x[1246]
 LO bounds    x[1247]   0
 PL bounds    x[1247]
 LO bounds    x[1248]   0
 PL bounds    x[1248]
 LO bounds    x[1249]   0
 PL bounds    x[1249]
 LO bounds    x[1250]   0
 PL bounds    x[1250]
 LO bounds    x[1251]   0
 PL bounds    x[1251]
 LO bounds    x[1252]   0
 PL bounds    x[1252]
 LO bounds    x[1253]   0
 PL bounds    x[1253]
 LO bounds    x[1254]   0
 PL bounds    x[1254]
 LO bounds    x[1255]   0
 PL bounds    x[1255]
 LO bounds    x[1256]   0
 PL bounds    x[1256]
 LO bounds    x[1257]   0
 PL bounds    x[1257]
 LO bounds    x[1258]   0
 PL bounds    x[1258]
 LO bounds    x[1259]   0
 PL bounds    x[1259]
 LO bounds    x[1260]   0
 PL bounds    x[1260]
 LO bounds    x[1261]   0
 PL bounds    x[1261]
 LO bounds    x[1262]   0
 PL bounds    x[1262]
 LO bounds    x[1263]   0
 PL bounds    x[1263]
 LO bounds    x[1264]   0
 PL bounds    x[1264]
 LO bounds    x[1265]   0
 PL bounds    x[1265]
 LO bounds    x[1266]   0
 PL bounds    x[1266]
 LO bounds    x[1267]   0
 PL bounds    x[1267]
 LO bounds    x[1268]   0
 PL bounds    x[1268]
 LO bounds    x[1269]   0
 PL bounds    x[1269]
 LO bounds    x[1270]   0
 PL bounds    x[1270]
 LO bounds    x[1271]   0
 PL bounds    x[1271]
 LO bounds    x[1272]   0
 PL bounds    x[1272]
 LO bounds    x[1273]   0
 PL bounds    x[1273]
 LO bounds    x[1274]   0
 PL bounds    x[1274]
 LO bounds    x[1275]   0
 PL bounds    x[1275]
 LO bounds    x[1276]   0
 PL bounds    x[1276]
 LO bounds    x[1277]   0
 PL bounds    x[1277]
 LO bounds    x[1278]   0
 PL bounds    x[1278]
 LO bounds    x[1279]   0
 PL bounds    x[1279]
 LO bounds    x[1280]   0
 PL bounds    x[1280]
 BV bounds    x[1281]
 BV bounds    x[1282]
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 BV bounds    x[1293]
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 BV bounds    x[1311]
 BV bounds    x[1312]
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 BV bounds    x[1317]
 BV bounds    x[1318]
 BV bounds    x[1319]
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 BV bounds    x[1323]
 BV bounds    x[1324]
 BV bounds    x[1325]
 BV bounds    x[1326]
 BV bounds    x[1327]
 BV bounds    x[1328]
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 BV bounds    x[1336]
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 BV bounds    x[1341]
 BV bounds    x[1342]
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 BV bounds    x[1353]
 BV bounds    x[1354]
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 BV bounds    x[1359]
 BV bounds    x[1360]
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 BV bounds    x[1364]
 BV bounds    x[1365]
 BV bounds    x[1366]
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 BV bounds    x[1401]
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 BV bounds    x[1409]
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 BV bounds    x[1442]
 BV bounds    x[1443]
 BV bounds    x[1444]
 BV bounds    x[1445]
 BV bounds    x[1446]
 BV bounds    x[1447]
 BV bounds    x[1448]
 BV bounds    x[1449]
 BV bounds    x[1450]
 BV bounds    x[1451]
 BV bounds    x[1452]
 BV bounds    x[1453]
 BV bounds    x[1454]
 BV bounds    x[1455]
 BV bounds    x[1456]
 BV bounds    x[1457]
 BV bounds    x[1458]
 BV bounds    x[1459]
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 BV bounds    x[1478]
 BV bounds    x[1479]
 BV bounds    x[1480]
 BV bounds    x[1481]
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 BV bounds    x[1485]
 BV bounds    x[1486]
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 BV bounds    x[1491]
 BV bounds    x[1492]
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 BV bounds    x[1515]
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 BV bounds    x[1521]
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 BV bounds    x[1527]
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 BV bounds    x[1532]
 BV bounds    x[1533]
 BV bounds    x[1534]
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 BV bounds    x[1539]
 BV bounds    x[1540]
 BV bounds    x[1541]
 BV bounds    x[1542]
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 BV bounds    x[1550]
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 BV bounds    x[1566]
 BV bounds    x[1567]
 BV bounds    x[1568]
 LO bounds    x[1569]   0
 UP bounds    x[1569]   120
 LO bounds    x[1570]   0
 UP bounds    x[1570]   150
 LO bounds    x[1571]   0
 UP bounds    x[1571]   120
 LO bounds    x[1572]   0
 UP bounds    x[1572]   150
 LO bounds    x[1573]   0
 UP bounds    x[1573]   120
 LO bounds    x[1574]   0
 UP bounds    x[1574]   150
 LO bounds    x[1575]   0
 UP bounds    x[1575]   120
 LO bounds    x[1576]   0
 UP bounds    x[1576]   150
 LO bounds    x[1577]   0
 UP bounds    x[1577]   120
 LO bounds    x[1578]   0
 UP bounds    x[1578]   150
 LO bounds    x[1579]   0
 UP bounds    x[1579]   120
 LO bounds    x[1580]   0
 UP bounds    x[1580]   150
 LO bounds    x[1581]   0
 UP bounds    x[1581]   120
 LO bounds    x[1582]   0
 UP bounds    x[1582]   150
 LO bounds    x[1583]   0
 UP bounds    x[1583]   120
 LO bounds    x[1584]   0
 UP bounds    x[1584]   150
 LO bounds    x[1585]   0
 UP bounds    x[1585]   120
 LO bounds    x[1586]   0
 UP bounds    x[1586]   150
 LO bounds    x[1587]   0
 UP bounds    x[1587]   120
 LO bounds    x[1588]   0
 UP bounds    x[1588]   150
 LO bounds    x[1589]   0
 UP bounds    x[1589]   120
 LO bounds    x[1590]   0
 UP bounds    x[1590]   150
 LO bounds    x[1591]   0
 UP bounds    x[1591]   120
 LO bounds    x[1592]   0
 UP bounds    x[1592]   150
 LO bounds    x[1593]   0
 UP bounds    x[1593]   120
 LO bounds    x[1594]   0
 UP bounds    x[1594]   150
 LO bounds    x[1595]   0
 UP bounds    x[1595]   120
 LO bounds    x[1596]   0
 UP bounds    x[1596]   150
 LO bounds    x[1597]   0
 UP bounds    x[1597]   120
 LO bounds    x[1598]   0
 UP bounds    x[1598]   150
 LO bounds    x[1599]   0
 UP bounds    x[1599]   120
 LO bounds    x[1600]   0
 UP bounds    x[1600]   150
 LO bounds    x[1601]   0
 UP bounds    x[1601]   400
 LO bounds    x[1602]   0
 UP bounds    x[1602]   400
 LO bounds    x[1603]   0
 UP bounds    x[1603]   400
 LO bounds    x[1604]   0
 UP bounds    x[1604]   400
 LO bounds    x[1605]   0
 UP bounds    x[1605]   400
 LO bounds    x[1606]   0
 UP bounds    x[1606]   400
 LO bounds    x[1607]   0
 UP bounds    x[1607]   400
 LO bounds    x[1608]   0
 UP bounds    x[1608]   400
 LO bounds    x[1609]   0
 UP bounds    x[1609]   400
 LO bounds    x[1610]   0
 UP bounds    x[1610]   400
 LO bounds    x[1611]   0
 UP bounds    x[1611]   400
 LO bounds    x[1612]   0
 UP bounds    x[1612]   400
 LO bounds    x[1613]   0
 UP bounds    x[1613]   400
 LO bounds    x[1614]   0
 UP bounds    x[1614]   400
 LO bounds    x[1615]   0
 UP bounds    x[1615]   400
 LO bounds    x[1616]   0
 UP bounds    x[1616]   400
 LO bounds    x[1617]   0
 UP bounds    x[1617]   120
 LO bounds    x[1618]   0
 UP bounds    x[1618]   750
 LO bounds    x[1619]   0
 UP bounds    x[1619]   120
 LO bounds    x[1620]   0
 UP bounds    x[1620]   750
 LO bounds    x[1621]   0
 UP bounds    x[1621]   120
 LO bounds    x[1622]   0
 UP bounds    x[1622]   750
 LO bounds    x[1623]   0
 UP bounds    x[1623]   120
 LO bounds    x[1624]   0
 UP bounds    x[1624]   750
 LO bounds    x[1625]   0
 UP bounds    x[1625]   120
 LO bounds    x[1626]   0
 UP bounds    x[1626]   750
 LO bounds    x[1627]   0
 UP bounds    x[1627]   120
 LO bounds    x[1628]   0
 UP bounds    x[1628]   750
 LO bounds    x[1629]   0
 UP bounds    x[1629]   120
 LO bounds    x[1630]   0
 UP bounds    x[1630]   750
 LO bounds    x[1631]   0
 UP bounds    x[1631]   120
 LO bounds    x[1632]   0
 UP bounds    x[1632]   750
 LO bounds    x[1633]   0
 UP bounds    x[1633]   120
 LO bounds    x[1634]   0
 UP bounds    x[1634]   750
 LO bounds    x[1635]   0
 UP bounds    x[1635]   120
 LO bounds    x[1636]   0
 UP bounds    x[1636]   750
 LO bounds    x[1637]   0
 UP bounds    x[1637]   120
 LO bounds    x[1638]   0
 UP bounds    x[1638]   750
 LO bounds    x[1639]   0
 UP bounds    x[1639]   120
 LO bounds    x[1640]   0
 UP bounds    x[1640]   750
 LO bounds    x[1641]   0
 UP bounds    x[1641]   120
 LO bounds    x[1642]   0
 UP bounds    x[1642]   750
 LO bounds    x[1643]   0
 UP bounds    x[1643]   120
 LO bounds    x[1644]   0
 UP bounds    x[1644]   750
 LO bounds    x[1645]   0
 UP bounds    x[1645]   120
 LO bounds    x[1646]   0
 UP bounds    x[1646]   750
 LO bounds    x[1647]   0
 UP bounds    x[1647]   120
 LO bounds    x[1648]   0
 UP bounds    x[1648]   750
 LO bounds    x[1649]   0
 UP bounds    x[1649]   400
 LO bounds    x[1650]   0
 UP bounds    x[1650]   400
 LO bounds    x[1651]   0
 UP bounds    x[1651]   400
 LO bounds    x[1652]   0
 UP bounds    x[1652]   400
 LO bounds    x[1653]   0
 UP bounds    x[1653]   400
 LO bounds    x[1654]   0
 UP bounds    x[1654]   400
 LO bounds    x[1655]   0
 UP bounds    x[1655]   400
 LO bounds    x[1656]   0
 UP bounds    x[1656]   400
 LO bounds    x[1657]   0
 UP bounds    x[1657]   400
 LO bounds    x[1658]   0
 UP bounds    x[1658]   400
 LO bounds    x[1659]   0
 UP bounds    x[1659]   400
 LO bounds    x[1660]   0
 UP bounds    x[1660]   400
 LO bounds    x[1661]   0
 UP bounds    x[1661]   400
 LO bounds    x[1662]   0
 UP bounds    x[1662]   400
 LO bounds    x[1663]   0
 UP bounds    x[1663]   400
 LO bounds    x[1664]   0
 UP bounds    x[1664]   400
 LO bounds    x[1665]   0
 UP bounds    x[1665]   120
 LO bounds    x[1666]   0
 UP bounds    x[1666]   150
 LO bounds    x[1667]   0
 UP bounds    x[1667]   120
 LO bounds    x[1668]   0
 UP bounds    x[1668]   150
 LO bounds    x[1669]   0
 UP bounds    x[1669]   120
 LO bounds    x[1670]   0
 UP bounds    x[1670]   150
 LO bounds    x[1671]   0
 UP bounds    x[1671]   120
 LO bounds    x[1672]   0
 UP bounds    x[1672]   150
 LO bounds    x[1673]   0
 UP bounds    x[1673]   120
 LO bounds    x[1674]   0
 UP bounds    x[1674]   150
 LO bounds    x[1675]   0
 UP bounds    x[1675]   120
 LO bounds    x[1676]   0
 UP bounds    x[1676]   150
 LO bounds    x[1677]   0
 UP bounds    x[1677]   120
 LO bounds    x[1678]   0
 UP bounds    x[1678]   150
 LO bounds    x[1679]   0
 UP bounds    x[1679]   120
 LO bounds    x[1680]   0
 UP bounds    x[1680]   150
 LO bounds    x[1681]   0
 UP bounds    x[1681]   120
 LO bounds    x[1682]   0
 UP bounds    x[1682]   150
 LO bounds    x[1683]   0
 UP bounds    x[1683]   120
 LO bounds    x[1684]   0
 UP bounds    x[1684]   150
 LO bounds    x[1685]   0
 UP bounds    x[1685]   120
 LO bounds    x[1686]   0
 UP bounds    x[1686]   150
 LO bounds    x[1687]   0
 UP bounds    x[1687]   120
 LO bounds    x[1688]   0
 UP bounds    x[1688]   150
 LO bounds    x[1689]   0
 UP bounds    x[1689]   120
 LO bounds    x[1690]   0
 UP bounds    x[1690]   150
 LO bounds    x[1691]   0
 UP bounds    x[1691]   120
 LO bounds    x[1692]   0
 UP bounds    x[1692]   150
 LO bounds    x[1693]   0
 UP bounds    x[1693]   120
 LO bounds    x[1694]   0
 UP bounds    x[1694]   150
 LO bounds    x[1695]   0
 UP bounds    x[1695]   120
 LO bounds    x[1696]   0
 UP bounds    x[1696]   150
 LO bounds    x[1697]   0
 UP bounds    x[1697]   400
 LO bounds    x[1698]   0
 UP bounds    x[1698]   400
 LO bounds    x[1699]   0
 UP bounds    x[1699]   400
 LO bounds    x[1700]   0
 UP bounds    x[1700]   400
 LO bounds    x[1701]   0
 UP bounds    x[1701]   400
 LO bounds    x[1702]   0
 UP bounds    x[1702]   400
 LO bounds    x[1703]   0
 UP bounds    x[1703]   400
 LO bounds    x[1704]   0
 UP bounds    x[1704]   400
 LO bounds    x[1705]   0
 UP bounds    x[1705]   400
 LO bounds    x[1706]   0
 UP bounds    x[1706]   400
 LO bounds    x[1707]   0
 UP bounds    x[1707]   400
 LO bounds    x[1708]   0
 UP bounds    x[1708]   400
 LO bounds    x[1709]   0
 UP bounds    x[1709]   400
 LO bounds    x[1710]   0
 UP bounds    x[1710]   400
 LO bounds    x[1711]   0
 UP bounds    x[1711]   400
 LO bounds    x[1712]   0
 UP bounds    x[1712]   400
 LO bounds    x[1713]   0
 UP bounds    x[1713]   120
 LO bounds    x[1714]   0
 UP bounds    x[1714]   250
 LO bounds    x[1715]   0
 UP bounds    x[1715]   120
 LO bounds    x[1716]   0
 UP bounds    x[1716]   250
 LO bounds    x[1717]   0
 UP bounds    x[1717]   120
 LO bounds    x[1718]   0
 UP bounds    x[1718]   250
 LO bounds    x[1719]   0
 UP bounds    x[1719]   120
 LO bounds    x[1720]   0
 UP bounds    x[1720]   250
 LO bounds    x[1721]   0
 UP bounds    x[1721]   120
 LO bounds    x[1722]   0
 UP bounds    x[1722]   250
 LO bounds    x[1723]   0
 UP bounds    x[1723]   120
 LO bounds    x[1724]   0
 UP bounds    x[1724]   250
 LO bounds    x[1725]   0
 UP bounds    x[1725]   120
 LO bounds    x[1726]   0
 UP bounds    x[1726]   250
 LO bounds    x[1727]   0
 UP bounds    x[1727]   120
 LO bounds    x[1728]   0
 UP bounds    x[1728]   250
 LO bounds    x[1729]   0
 UP bounds    x[1729]   120
 LO bounds    x[1730]   0
 UP bounds    x[1730]   250
 LO bounds    x[1731]   0
 UP bounds    x[1731]   120
 LO bounds    x[1732]   0
 UP bounds    x[1732]   250
 LO bounds    x[1733]   0
 UP bounds    x[1733]   120
 LO bounds    x[1734]   0
 UP bounds    x[1734]   250
 LO bounds    x[1735]   0
 UP bounds    x[1735]   120
 LO bounds    x[1736]   0
 UP bounds    x[1736]   250
 LO bounds    x[1737]   0
 UP bounds    x[1737]   120
 LO bounds    x[1738]   0
 UP bounds    x[1738]   250
 LO bounds    x[1739]   0
 UP bounds    x[1739]   120
 LO bounds    x[1740]   0
 UP bounds    x[1740]   250
 LO bounds    x[1741]   0
 UP bounds    x[1741]   120
 LO bounds    x[1742]   0
 UP bounds    x[1742]   250
 LO bounds    x[1743]   0
 UP bounds    x[1743]   120
 LO bounds    x[1744]   0
 UP bounds    x[1744]   250
 LO bounds    x[1745]   0
 UP bounds    x[1745]   400
 LO bounds    x[1746]   0
 UP bounds    x[1746]   400
 LO bounds    x[1747]   0
 UP bounds    x[1747]   400
 LO bounds    x[1748]   0
 UP bounds    x[1748]   400
 LO bounds    x[1749]   0
 UP bounds    x[1749]   400
 LO bounds    x[1750]   0
 UP bounds    x[1750]   400
 LO bounds    x[1751]   0
 UP bounds    x[1751]   400
 LO bounds    x[1752]   0
 UP bounds    x[1752]   400
 LO bounds    x[1753]   0
 UP bounds    x[1753]   400
 LO bounds    x[1754]   0
 UP bounds    x[1754]   400
 LO bounds    x[1755]   0
 UP bounds    x[1755]   400
 LO bounds    x[1756]   0
 UP bounds    x[1756]   400
 LO bounds    x[1757]   0
 UP bounds    x[1757]   400
 LO bounds    x[1758]   0
 UP bounds    x[1758]   400
 LO bounds    x[1759]   0
 UP bounds    x[1759]   400
 LO bounds    x[1760]   0
 UP bounds    x[1760]   400
 LO bounds    x[1761]   0
 UP bounds    x[1761]   120
 LO bounds    x[1762]   0
 UP bounds    x[1762]   150
 LO bounds    x[1763]   0
 UP bounds    x[1763]   120
 LO bounds    x[1764]   0
 UP bounds    x[1764]   150
 LO bounds    x[1765]   0
 UP bounds    x[1765]   120
 LO bounds    x[1766]   0
 UP bounds    x[1766]   150
 LO bounds    x[1767]   0
 UP bounds    x[1767]   120
 LO bounds    x[1768]   0
 UP bounds    x[1768]   150
 LO bounds    x[1769]   0
 UP bounds    x[1769]   120
 LO bounds    x[1770]   0
 UP bounds    x[1770]   150
 LO bounds    x[1771]   0
 UP bounds    x[1771]   120
 LO bounds    x[1772]   0
 UP bounds    x[1772]   150
 LO bounds    x[1773]   0
 UP bounds    x[1773]   120
 LO bounds    x[1774]   0
 UP bounds    x[1774]   150
 LO bounds    x[1775]   0
 UP bounds    x[1775]   120
 LO bounds    x[1776]   0
 UP bounds    x[1776]   150
 LO bounds    x[1777]   0
 UP bounds    x[1777]   120
 LO bounds    x[1778]   0
 UP bounds    x[1778]   150
 LO bounds    x[1779]   0
 UP bounds    x[1779]   120
 LO bounds    x[1780]   0
 UP bounds    x[1780]   150
 LO bounds    x[1781]   0
 UP bounds    x[1781]   120
 LO bounds    x[1782]   0
 UP bounds    x[1782]   150
 LO bounds    x[1783]   0
 UP bounds    x[1783]   120
 LO bounds    x[1784]   0
 UP bounds    x[1784]   150
 LO bounds    x[1785]   0
 UP bounds    x[1785]   120
 LO bounds    x[1786]   0
 UP bounds    x[1786]   150
 LO bounds    x[1787]   0
 UP bounds    x[1787]   120
 LO bounds    x[1788]   0
 UP bounds    x[1788]   150
 LO bounds    x[1789]   0
 UP bounds    x[1789]   120
 LO bounds    x[1790]   0
 UP bounds    x[1790]   150
 LO bounds    x[1791]   0
 UP bounds    x[1791]   120
 LO bounds    x[1792]   0
 UP bounds    x[1792]   150
 LO bounds    x[1793]   0
 UP bounds    x[1793]   400
 LO bounds    x[1794]   0
 UP bounds    x[1794]   400
 LO bounds    x[1795]   0
 UP bounds    x[1795]   400
 LO bounds    x[1796]   0
 UP bounds    x[1796]   400
 LO bounds    x[1797]   0
 UP bounds    x[1797]   400
 LO bounds    x[1798]   0
 UP bounds    x[1798]   400
 LO bounds    x[1799]   0
 UP bounds    x[1799]   400
 LO bounds    x[1800]   0
 UP bounds    x[1800]   400
 LO bounds    x[1801]   0
 UP bounds    x[1801]   400
 LO bounds    x[1802]   0
 UP bounds    x[1802]   400
 LO bounds    x[1803]   0
 UP bounds    x[1803]   400
 LO bounds    x[1804]   0
 UP bounds    x[1804]   400
 LO bounds    x[1805]   0
 UP bounds    x[1805]   400
 LO bounds    x[1806]   0
 UP bounds    x[1806]   400
 LO bounds    x[1807]   0
 UP bounds    x[1807]   400
 LO bounds    x[1808]   0
 UP bounds    x[1808]   400
 LO bounds    x[1809]   0
 UP bounds    x[1809]   120
 LO bounds    x[1810]   0
 UP bounds    x[1810]   750
 LO bounds    x[1811]   0
 UP bounds    x[1811]   120
 LO bounds    x[1812]   0
 UP bounds    x[1812]   750
 LO bounds    x[1813]   0
 UP bounds    x[1813]   120
 LO bounds    x[1814]   0
 UP bounds    x[1814]   750
 LO bounds    x[1815]   0
 UP bounds    x[1815]   120
 LO bounds    x[1816]   0
 UP bounds    x[1816]   750
 LO bounds    x[1817]   0
 UP bounds    x[1817]   120
 LO bounds    x[1818]   0
 UP bounds    x[1818]   750
 LO bounds    x[1819]   0
 UP bounds    x[1819]   120
 LO bounds    x[1820]   0
 UP bounds    x[1820]   750
 LO bounds    x[1821]   0
 UP bounds    x[1821]   120
 LO bounds    x[1822]   0
 UP bounds    x[1822]   750
 LO bounds    x[1823]   0
 UP bounds    x[1823]   120
 LO bounds    x[1824]   0
 UP bounds    x[1824]   750
 LO bounds    x[1825]   0
 UP bounds    x[1825]   120
 LO bounds    x[1826]   0
 UP bounds    x[1826]   750
 LO bounds    x[1827]   0
 UP bounds    x[1827]   120
 LO bounds    x[1828]   0
 UP bounds    x[1828]   750
 LO bounds    x[1829]   0
 UP bounds    x[1829]   120
 LO bounds    x[1830]   0
 UP bounds    x[1830]   750
 LO bounds    x[1831]   0
 UP bounds    x[1831]   120
 LO bounds    x[1832]   0
 UP bounds    x[1832]   750
 LO bounds    x[1833]   0
 UP bounds    x[1833]   120
 LO bounds    x[1834]   0
 UP bounds    x[1834]   750
 LO bounds    x[1835]   0
 UP bounds    x[1835]   120
 LO bounds    x[1836]   0
 UP bounds    x[1836]   750
 LO bounds    x[1837]   0
 UP bounds    x[1837]   120
 LO bounds    x[1838]   0
 UP bounds    x[1838]   750
 LO bounds    x[1839]   0
 UP bounds    x[1839]   120
 LO bounds    x[1840]   0
 UP bounds    x[1840]   750
 LO bounds    x[1841]   0
 UP bounds    x[1841]   400
 LO bounds    x[1842]   0
 UP bounds    x[1842]   400
 LO bounds    x[1843]   0
 UP bounds    x[1843]   400
 LO bounds    x[1844]   0
 UP bounds    x[1844]   400
 LO bounds    x[1845]   0
 UP bounds    x[1845]   400
 LO bounds    x[1846]   0
 UP bounds    x[1846]   400
 LO bounds    x[1847]   0
 UP bounds    x[1847]   400
 LO bounds    x[1848]   0
 UP bounds    x[1848]   400
 LO bounds    x[1849]   0
 UP bounds    x[1849]   400
 LO bounds    x[1850]   0
 UP bounds    x[1850]   400
 LO bounds    x[1851]   0
 UP bounds    x[1851]   400
 LO bounds    x[1852]   0
 UP bounds    x[1852]   400
 LO bounds    x[1853]   0
 UP bounds    x[1853]   400
 LO bounds    x[1854]   0
 UP bounds    x[1854]   400
 LO bounds    x[1855]   0
 UP bounds    x[1855]   400
 LO bounds    x[1856]   0
 UP bounds    x[1856]   400
 LO bounds    x[1857]   0
 UP bounds    x[1857]   120
 LO bounds    x[1858]   0
 UP bounds    x[1858]   150
 LO bounds    x[1859]   0
 UP bounds    x[1859]   120
 LO bounds    x[1860]   0
 UP bounds    x[1860]   150
 LO bounds    x[1861]   0
 UP bounds    x[1861]   120
 LO bounds    x[1862]   0
 UP bounds    x[1862]   150
 LO bounds    x[1863]   0
 UP bounds    x[1863]   120
 LO bounds    x[1864]   0
 UP bounds    x[1864]   150
 LO bounds    x[1865]   0
 UP bounds    x[1865]   120
 LO bounds    x[1866]   0
 UP bounds    x[1866]   150
 LO bounds    x[1867]   0
 UP bounds    x[1867]   120
 LO bounds    x[1868]   0
 UP bounds    x[1868]   150
 LO bounds    x[1869]   0
 UP bounds    x[1869]   120
 LO bounds    x[1870]   0
 UP bounds    x[1870]   150
 LO bounds    x[1871]   0
 UP bounds    x[1871]   120
 LO bounds    x[1872]   0
 UP bounds    x[1872]   150
 LO bounds    x[1873]   0
 UP bounds    x[1873]   120
 LO bounds    x[1874]   0
 UP bounds    x[1874]   150
 LO bounds    x[1875]   0
 UP bounds    x[1875]   120
 LO bounds    x[1876]   0
 UP bounds    x[1876]   150
 LO bounds    x[1877]   0
 UP bounds    x[1877]   120
 LO bounds    x[1878]   0
 UP bounds    x[1878]   150
 LO bounds    x[1879]   0
 UP bounds    x[1879]   120
 LO bounds    x[1880]   0
 UP bounds    x[1880]   150
 LO bounds    x[1881]   0
 UP bounds    x[1881]   120
 LO bounds    x[1882]   0
 UP bounds    x[1882]   150
 LO bounds    x[1883]   0
 UP bounds    x[1883]   120
 LO bounds    x[1884]   0
 UP bounds    x[1884]   150
 LO bounds    x[1885]   0
 UP bounds    x[1885]   120
 LO bounds    x[1886]   0
 UP bounds    x[1886]   150
 LO bounds    x[1887]   0
 UP bounds    x[1887]   120
 LO bounds    x[1888]   0
 UP bounds    x[1888]   150
 LO bounds    x[1889]   0
 UP bounds    x[1889]   400
 LO bounds    x[1890]   0
 UP bounds    x[1890]   400
 LO bounds    x[1891]   0
 UP bounds    x[1891]   400
 LO bounds    x[1892]   0
 UP bounds    x[1892]   400
 LO bounds    x[1893]   0
 UP bounds    x[1893]   400
 LO bounds    x[1894]   0
 UP bounds    x[1894]   400
 LO bounds    x[1895]   0
 UP bounds    x[1895]   400
 LO bounds    x[1896]   0
 UP bounds    x[1896]   400
 LO bounds    x[1897]   0
 UP bounds    x[1897]   400
 LO bounds    x[1898]   0
 UP bounds    x[1898]   400
 LO bounds    x[1899]   0
 UP bounds    x[1899]   400
 LO bounds    x[1900]   0
 UP bounds    x[1900]   400
 LO bounds    x[1901]   0
 UP bounds    x[1901]   400
 LO bounds    x[1902]   0
 UP bounds    x[1902]   400
 LO bounds    x[1903]   0
 UP bounds    x[1903]   400
 LO bounds    x[1904]   0
 UP bounds    x[1904]   400
 LO bounds    x[1905]   0
 UP bounds    x[1905]   120
 LO bounds    x[1906]   0
 UP bounds    x[1906]   250
 LO bounds    x[1907]   0
 UP bounds    x[1907]   120
 LO bounds    x[1908]   0
 UP bounds    x[1908]   250
 LO bounds    x[1909]   0
 UP bounds    x[1909]   120
 LO bounds    x[1910]   0
 UP bounds    x[1910]   250
 LO bounds    x[1911]   0
 UP bounds    x[1911]   120
 LO bounds    x[1912]   0
 UP bounds    x[1912]   250
 LO bounds    x[1913]   0
 UP bounds    x[1913]   120
 LO bounds    x[1914]   0
 UP bounds    x[1914]   250
 LO bounds    x[1915]   0
 UP bounds    x[1915]   120
 LO bounds    x[1916]   0
 UP bounds    x[1916]   250
 LO bounds    x[1917]   0
 UP bounds    x[1917]   120
 LO bounds    x[1918]   0
 UP bounds    x[1918]   250
 LO bounds    x[1919]   0
 UP bounds    x[1919]   120
 LO bounds    x[1920]   0
 UP bounds    x[1920]   250
 LO bounds    x[1921]   0
 UP bounds    x[1921]   120
 LO bounds    x[1922]   0
 UP bounds    x[1922]   250
 LO bounds    x[1923]   0
 UP bounds    x[1923]   120
 LO bounds    x[1924]   0
 UP bounds    x[1924]   250
 LO bounds    x[1925]   0
 UP bounds    x[1925]   120
 LO bounds    x[1926]   0
 UP bounds    x[1926]   250
 LO bounds    x[1927]   0
 UP bounds    x[1927]   120
 LO bounds    x[1928]   0
 UP bounds    x[1928]   250
 LO bounds    x[1929]   0
 UP bounds    x[1929]   120
 LO bounds    x[1930]   0
 UP bounds    x[1930]   250
 LO bounds    x[1931]   0
 UP bounds    x[1931]   120
 LO bounds    x[1932]   0
 UP bounds    x[1932]   250
 LO bounds    x[1933]   0
 UP bounds    x[1933]   120
 LO bounds    x[1934]   0
 UP bounds    x[1934]   250
 LO bounds    x[1935]   0
 UP bounds    x[1935]   120
 LO bounds    x[1936]   0
 UP bounds    x[1936]   250
 LO bounds    x[1937]   0
 UP bounds    x[1937]   400
 LO bounds    x[1938]   0
 UP bounds    x[1938]   400
 LO bounds    x[1939]   0
 UP bounds    x[1939]   400
 LO bounds    x[1940]   0
 UP bounds    x[1940]   400
 LO bounds    x[1941]   0
 UP bounds    x[1941]   400
 LO bounds    x[1942]   0
 UP bounds    x[1942]   400
 LO bounds    x[1943]   0
 UP bounds    x[1943]   400
 LO bounds    x[1944]   0
 UP bounds    x[1944]   400
 LO bounds    x[1945]   0
 UP bounds    x[1945]   400
 LO bounds    x[1946]   0
 UP bounds    x[1946]   400
 LO bounds    x[1947]   0
 UP bounds    x[1947]   400
 LO bounds    x[1948]   0
 UP bounds    x[1948]   400
 LO bounds    x[1949]   0
 UP bounds    x[1949]   400
 LO bounds    x[1950]   0
 UP bounds    x[1950]   400
 LO bounds    x[1951]   0
 UP bounds    x[1951]   400
 LO bounds    x[1952]   0
 UP bounds    x[1952]   400
 LO bounds    x[1953]   0
 UP bounds    x[1953]   120
 LO bounds    x[1954]   0
 UP bounds    x[1954]   150
 LO bounds    x[1955]   0
 UP bounds    x[1955]   120
 LO bounds    x[1956]   0
 UP bounds    x[1956]   150
 LO bounds    x[1957]   0
 UP bounds    x[1957]   120
 LO bounds    x[1958]   0
 UP bounds    x[1958]   150
 LO bounds    x[1959]   0
 UP bounds    x[1959]   120
 LO bounds    x[1960]   0
 UP bounds    x[1960]   150
 LO bounds    x[1961]   0
 UP bounds    x[1961]   120
 LO bounds    x[1962]   0
 UP bounds    x[1962]   150
 LO bounds    x[1963]   0
 UP bounds    x[1963]   120
 LO bounds    x[1964]   0
 UP bounds    x[1964]   150
 LO bounds    x[1965]   0
 UP bounds    x[1965]   120
 LO bounds    x[1966]   0
 UP bounds    x[1966]   150
 LO bounds    x[1967]   0
 UP bounds    x[1967]   120
 LO bounds    x[1968]   0
 UP bounds    x[1968]   150
 LO bounds    x[1969]   0
 UP bounds    x[1969]   120
 LO bounds    x[1970]   0
 UP bounds    x[1970]   150
 LO bounds    x[1971]   0
 UP bounds    x[1971]   120
 LO bounds    x[1972]   0
 UP bounds    x[1972]   150
 LO bounds    x[1973]   0
 UP bounds    x[1973]   120
 LO bounds    x[1974]   0
 UP bounds    x[1974]   150
 LO bounds    x[1975]   0
 UP bounds    x[1975]   120
 LO bounds    x[1976]   0
 UP bounds    x[1976]   150
 LO bounds    x[1977]   0
 UP bounds    x[1977]   120
 LO bounds    x[1978]   0
 UP bounds    x[1978]   150
 LO bounds    x[1979]   0
 UP bounds    x[1979]   120
 LO bounds    x[1980]   0
 UP bounds    x[1980]   150
 LO bounds    x[1981]   0
 UP bounds    x[1981]   120
 LO bounds    x[1982]   0
 UP bounds    x[1982]   150
 LO bounds    x[1983]   0
 UP bounds    x[1983]   120
 LO bounds    x[1984]   0
 UP bounds    x[1984]   150
 LO bounds    x[1985]   0
 UP bounds    x[1985]   400
 LO bounds    x[1986]   0
 UP bounds    x[1986]   400
 LO bounds    x[1987]   0
 UP bounds    x[1987]   400
 LO bounds    x[1988]   0
 UP bounds    x[1988]   400
 LO bounds    x[1989]   0
 UP bounds    x[1989]   400
 LO bounds    x[1990]   0
 UP bounds    x[1990]   400
 LO bounds    x[1991]   0
 UP bounds    x[1991]   400
 LO bounds    x[1992]   0
 UP bounds    x[1992]   400
 LO bounds    x[1993]   0
 UP bounds    x[1993]   400
 LO bounds    x[1994]   0
 UP bounds    x[1994]   400
 LO bounds    x[1995]   0
 UP bounds    x[1995]   400
 LO bounds    x[1996]   0
 UP bounds    x[1996]   400
 LO bounds    x[1997]   0
 UP bounds    x[1997]   400
 LO bounds    x[1998]   0
 UP bounds    x[1998]   400
 LO bounds    x[1999]   0
 UP bounds    x[1999]   400
 LO bounds    x[2000]   0
 UP bounds    x[2000]   400
 LO bounds    x[2001]   0
 UP bounds    x[2001]   120
 LO bounds    x[2002]   0
 UP bounds    x[2002]   750
 LO bounds    x[2003]   0
 UP bounds    x[2003]   120
 LO bounds    x[2004]   0
 UP bounds    x[2004]   750
 LO bounds    x[2005]   0
 UP bounds    x[2005]   120
 LO bounds    x[2006]   0
 UP bounds    x[2006]   750
 LO bounds    x[2007]   0
 UP bounds    x[2007]   120
 LO bounds    x[2008]   0
 UP bounds    x[2008]   750
 LO bounds    x[2009]   0
 UP bounds    x[2009]   120
 LO bounds    x[2010]   0
 UP bounds    x[2010]   750
 LO bounds    x[2011]   0
 UP bounds    x[2011]   120
 LO bounds    x[2012]   0
 UP bounds    x[2012]   750
 LO bounds    x[2013]   0
 UP bounds    x[2013]   120
 LO bounds    x[2014]   0
 UP bounds    x[2014]   750
 LO bounds    x[2015]   0
 UP bounds    x[2015]   120
 LO bounds    x[2016]   0
 UP bounds    x[2016]   750
 LO bounds    x[2017]   0
 UP bounds    x[2017]   120
 LO bounds    x[2018]   0
 UP bounds    x[2018]   750
 LO bounds    x[2019]   0
 UP bounds    x[2019]   120
 LO bounds    x[2020]   0
 UP bounds    x[2020]   750
 LO bounds    x[2021]   0
 UP bounds    x[2021]   120
 LO bounds    x[2022]   0
 UP bounds    x[2022]   750
 LO bounds    x[2023]   0
 UP bounds    x[2023]   120
 LO bounds    x[2024]   0
 UP bounds    x[2024]   750
 LO bounds    x[2025]   0
 UP bounds    x[2025]   120
 LO bounds    x[2026]   0
 UP bounds    x[2026]   750
 LO bounds    x[2027]   0
 UP bounds    x[2027]   120
 LO bounds    x[2028]   0
 UP bounds    x[2028]   750
 LO bounds    x[2029]   0
 UP bounds    x[2029]   120
 LO bounds    x[2030]   0
 UP bounds    x[2030]   750
 LO bounds    x[2031]   0
 UP bounds    x[2031]   120
 LO bounds    x[2032]   0
 UP bounds    x[2032]   750
 LO bounds    x[2033]   0
 UP bounds    x[2033]   400
 LO bounds    x[2034]   0
 UP bounds    x[2034]   400
 LO bounds    x[2035]   0
 UP bounds    x[2035]   400
 LO bounds    x[2036]   0
 UP bounds    x[2036]   400
 LO bounds    x[2037]   0
 UP bounds    x[2037]   400
 LO bounds    x[2038]   0
 UP bounds    x[2038]   400
 LO bounds    x[2039]   0
 UP bounds    x[2039]   400
 LO bounds    x[2040]   0
 UP bounds    x[2040]   400
 LO bounds    x[2041]   0
 UP bounds    x[2041]   400
 LO bounds    x[2042]   0
 UP bounds    x[2042]   400
 LO bounds    x[2043]   0
 UP bounds    x[2043]   400
 LO bounds    x[2044]   0
 UP bounds    x[2044]   400
 LO bounds    x[2045]   0
 UP bounds    x[2045]   400
 LO bounds    x[2046]   0
 UP bounds    x[2046]   400
 LO bounds    x[2047]   0
 UP bounds    x[2047]   400
 LO bounds    x[2048]   0
 UP bounds    x[2048]   400
 LO bounds    x[2049]   0
 UP bounds    x[2049]   120
 LO bounds    x[2050]   0
 UP bounds    x[2050]   150
 LO bounds    x[2051]   0
 UP bounds    x[2051]   120
 LO bounds    x[2052]   0
 UP bounds    x[2052]   150
 LO bounds    x[2053]   0
 UP bounds    x[2053]   120
 LO bounds    x[2054]   0
 UP bounds    x[2054]   150
 LO bounds    x[2055]   0
 UP bounds    x[2055]   120
 LO bounds    x[2056]   0
 UP bounds    x[2056]   150
 LO bounds    x[2057]   0
 UP bounds    x[2057]   120
 LO bounds    x[2058]   0
 UP bounds    x[2058]   150
 LO bounds    x[2059]   0
 UP bounds    x[2059]   120
 LO bounds    x[2060]   0
 UP bounds    x[2060]   150
 LO bounds    x[2061]   0
 UP bounds    x[2061]   120
 LO bounds    x[2062]   0
 UP bounds    x[2062]   150
 LO bounds    x[2063]   0
 UP bounds    x[2063]   120
 LO bounds    x[2064]   0
 UP bounds    x[2064]   150
 LO bounds    x[2065]   0
 UP bounds    x[2065]   120
 LO bounds    x[2066]   0
 UP bounds    x[2066]   150
 LO bounds    x[2067]   0
 UP bounds    x[2067]   120
 LO bounds    x[2068]   0
 UP bounds    x[2068]   150
 LO bounds    x[2069]   0
 UP bounds    x[2069]   120
 LO bounds    x[2070]   0
 UP bounds    x[2070]   150
 LO bounds    x[2071]   0
 UP bounds    x[2071]   120
 LO bounds    x[2072]   0
 UP bounds    x[2072]   150
 LO bounds    x[2073]   0
 UP bounds    x[2073]   120
 LO bounds    x[2074]   0
 UP bounds    x[2074]   150
 LO bounds    x[2075]   0
 UP bounds    x[2075]   120
 LO bounds    x[2076]   0
 UP bounds    x[2076]   150
 LO bounds    x[2077]   0
 UP bounds    x[2077]   120
 LO bounds    x[2078]   0
 UP bounds    x[2078]   150
 LO bounds    x[2079]   0
 UP bounds    x[2079]   120
 LO bounds    x[2080]   0
 UP bounds    x[2080]   150
 LO bounds    x[2081]   0
 UP bounds    x[2081]   400
 LO bounds    x[2082]   0
 UP bounds    x[2082]   400
 LO bounds    x[2083]   0
 UP bounds    x[2083]   400
 LO bounds    x[2084]   0
 UP bounds    x[2084]   400
 LO bounds    x[2085]   0
 UP bounds    x[2085]   400
 LO bounds    x[2086]   0
 UP bounds    x[2086]   400
 LO bounds    x[2087]   0
 UP bounds    x[2087]   400
 LO bounds    x[2088]   0
 UP bounds    x[2088]   400
 LO bounds    x[2089]   0
 UP bounds    x[2089]   400
 LO bounds    x[2090]   0
 UP bounds    x[2090]   400
 LO bounds    x[2091]   0
 UP bounds    x[2091]   400
 LO bounds    x[2092]   0
 UP bounds    x[2092]   400
 LO bounds    x[2093]   0
 UP bounds    x[2093]   400
 LO bounds    x[2094]   0
 UP bounds    x[2094]   400
 LO bounds    x[2095]   0
 UP bounds    x[2095]   400
 LO bounds    x[2096]   0
 UP bounds    x[2096]   400
 LO bounds    x[2097]   0
 UP bounds    x[2097]   120
 LO bounds    x[2098]   0
 UP bounds    x[2098]   250
 LO bounds    x[2099]   0
 UP bounds    x[2099]   120
 LO bounds    x[2100]   0
 UP bounds    x[2100]   250
 LO bounds    x[2101]   0
 UP bounds    x[2101]   120
 LO bounds    x[2102]   0
 UP bounds    x[2102]   250
 LO bounds    x[2103]   0
 UP bounds    x[2103]   120
 LO bounds    x[2104]   0
 UP bounds    x[2104]   250
 LO bounds    x[2105]   0
 UP bounds    x[2105]   120
 LO bounds    x[2106]   0
 UP bounds    x[2106]   250
 LO bounds    x[2107]   0
 UP bounds    x[2107]   120
 LO bounds    x[2108]   0
 UP bounds    x[2108]   250
 LO bounds    x[2109]   0
 UP bounds    x[2109]   120
 LO bounds    x[2110]   0
 UP bounds    x[2110]   250
 LO bounds    x[2111]   0
 UP bounds    x[2111]   120
 LO bounds    x[2112]   0
 UP bounds    x[2112]   250
 LO bounds    x[2113]   0
 UP bounds    x[2113]   120
 LO bounds    x[2114]   0
 UP bounds    x[2114]   250
 LO bounds    x[2115]   0
 UP bounds    x[2115]   120
 LO bounds    x[2116]   0
 UP bounds    x[2116]   250
 LO bounds    x[2117]   0
 UP bounds    x[2117]   120
 LO bounds    x[2118]   0
 UP bounds    x[2118]   250
 LO bounds    x[2119]   0
 UP bounds    x[2119]   120
 LO bounds    x[2120]   0
 UP bounds    x[2120]   250
 LO bounds    x[2121]   0
 UP bounds    x[2121]   120
 LO bounds    x[2122]   0
 UP bounds    x[2122]   250
 LO bounds    x[2123]   0
 UP bounds    x[2123]   120
 LO bounds    x[2124]   0
 UP bounds    x[2124]   250
 LO bounds    x[2125]   0
 UP bounds    x[2125]   120
 LO bounds    x[2126]   0
 UP bounds    x[2126]   250
 LO bounds    x[2127]   0
 UP bounds    x[2127]   120
 LO bounds    x[2128]   0
 UP bounds    x[2128]   250
 LO bounds    x[2129]   0
 UP bounds    x[2129]   400
 LO bounds    x[2130]   0
 UP bounds    x[2130]   400
 LO bounds    x[2131]   0
 UP bounds    x[2131]   400
 LO bounds    x[2132]   0
 UP bounds    x[2132]   400
 LO bounds    x[2133]   0
 UP bounds    x[2133]   400
 LO bounds    x[2134]   0
 UP bounds    x[2134]   400
 LO bounds    x[2135]   0
 UP bounds    x[2135]   400
 LO bounds    x[2136]   0
 UP bounds    x[2136]   400
 LO bounds    x[2137]   0
 UP bounds    x[2137]   400
 LO bounds    x[2138]   0
 UP bounds    x[2138]   400
 LO bounds    x[2139]   0
 UP bounds    x[2139]   400
 LO bounds    x[2140]   0
 UP bounds    x[2140]   400
 LO bounds    x[2141]   0
 UP bounds    x[2141]   400
 LO bounds    x[2142]   0
 UP bounds    x[2142]   400
 LO bounds    x[2143]   0
 UP bounds    x[2143]   400
 LO bounds    x[2144]   0
 UP bounds    x[2144]   400
 LO bounds    x[2145]   0
 UP bounds    x[2145]   120
 LO bounds    x[2146]   0
 UP bounds    x[2146]   150
 LO bounds    x[2147]   0
 UP bounds    x[2147]   120
 LO bounds    x[2148]   0
 UP bounds    x[2148]   150
 LO bounds    x[2149]   0
 UP bounds    x[2149]   120
 LO bounds    x[2150]   0
 UP bounds    x[2150]   150
 LO bounds    x[2151]   0
 UP bounds    x[2151]   120
 LO bounds    x[2152]   0
 UP bounds    x[2152]   150
 LO bounds    x[2153]   0
 UP bounds    x[2153]   120
 LO bounds    x[2154]   0
 UP bounds    x[2154]   150
 LO bounds    x[2155]   0
 UP bounds    x[2155]   120
 LO bounds    x[2156]   0
 UP bounds    x[2156]   150
 LO bounds    x[2157]   0
 UP bounds    x[2157]   120
 LO bounds    x[2158]   0
 UP bounds    x[2158]   150
 LO bounds    x[2159]   0
 UP bounds    x[2159]   120
 LO bounds    x[2160]   0
 UP bounds    x[2160]   150
 LO bounds    x[2161]   0
 UP bounds    x[2161]   120
 LO bounds    x[2162]   0
 UP bounds    x[2162]   150
 LO bounds    x[2163]   0
 UP bounds    x[2163]   120
 LO bounds    x[2164]   0
 UP bounds    x[2164]   150
 LO bounds    x[2165]   0
 UP bounds    x[2165]   120
 LO bounds    x[2166]   0
 UP bounds    x[2166]   150
 LO bounds    x[2167]   0
 UP bounds    x[2167]   120
 LO bounds    x[2168]   0
 UP bounds    x[2168]   150
 LO bounds    x[2169]   0
 UP bounds    x[2169]   120
 LO bounds    x[2170]   0
 UP bounds    x[2170]   150
 LO bounds    x[2171]   0
 UP bounds    x[2171]   120
 LO bounds    x[2172]   0
 UP bounds    x[2172]   150
 LO bounds    x[2173]   0
 UP bounds    x[2173]   120
 LO bounds    x[2174]   0
 UP bounds    x[2174]   150
 LO bounds    x[2175]   0
 UP bounds    x[2175]   120
 LO bounds    x[2176]   0
 UP bounds    x[2176]   150
 LO bounds    x[2177]   0
 UP bounds    x[2177]   400
 LO bounds    x[2178]   0
 UP bounds    x[2178]   400
 LO bounds    x[2179]   0
 UP bounds    x[2179]   400
 LO bounds    x[2180]   0
 UP bounds    x[2180]   400
 LO bounds    x[2181]   0
 UP bounds    x[2181]   400
 LO bounds    x[2182]   0
 UP bounds    x[2182]   400
 LO bounds    x[2183]   0
 UP bounds    x[2183]   400
 LO bounds    x[2184]   0
 UP bounds    x[2184]   400
 LO bounds    x[2185]   0
 UP bounds    x[2185]   400
 LO bounds    x[2186]   0
 UP bounds    x[2186]   400
 LO bounds    x[2187]   0
 UP bounds    x[2187]   400
 LO bounds    x[2188]   0
 UP bounds    x[2188]   400
 LO bounds    x[2189]   0
 UP bounds    x[2189]   400
 LO bounds    x[2190]   0
 UP bounds    x[2190]   400
 LO bounds    x[2191]   0
 UP bounds    x[2191]   400
 LO bounds    x[2192]   0
 UP bounds    x[2192]   400
 LO bounds    x[2193]   0
 UP bounds    x[2193]   120
 LO bounds    x[2194]   0
 UP bounds    x[2194]   750
 LO bounds    x[2195]   0
 UP bounds    x[2195]   120
 LO bounds    x[2196]   0
 UP bounds    x[2196]   750
 LO bounds    x[2197]   0
 UP bounds    x[2197]   120
 LO bounds    x[2198]   0
 UP bounds    x[2198]   750
 LO bounds    x[2199]   0
 UP bounds    x[2199]   120
 LO bounds    x[2200]   0
 UP bounds    x[2200]   750
 LO bounds    x[2201]   0
 UP bounds    x[2201]   120
 LO bounds    x[2202]   0
 UP bounds    x[2202]   750
 LO bounds    x[2203]   0
 UP bounds    x[2203]   120
 LO bounds    x[2204]   0
 UP bounds    x[2204]   750
 LO bounds    x[2205]   0
 UP bounds    x[2205]   120
 LO bounds    x[2206]   0
 UP bounds    x[2206]   750
 LO bounds    x[2207]   0
 UP bounds    x[2207]   120
 LO bounds    x[2208]   0
 UP bounds    x[2208]   750
 LO bounds    x[2209]   0
 UP bounds    x[2209]   120
 LO bounds    x[2210]   0
 UP bounds    x[2210]   750
 LO bounds    x[2211]   0
 UP bounds    x[2211]   120
 LO bounds    x[2212]   0
 UP bounds    x[2212]   750
 LO bounds    x[2213]   0
 UP bounds    x[2213]   120
 LO bounds    x[2214]   0
 UP bounds    x[2214]   750
 LO bounds    x[2215]   0
 UP bounds    x[2215]   120
 LO bounds    x[2216]   0
 UP bounds    x[2216]   750
 LO bounds    x[2217]   0
 UP bounds    x[2217]   120
 LO bounds    x[2218]   0
 UP bounds    x[2218]   750
 LO bounds    x[2219]   0
 UP bounds    x[2219]   120
 LO bounds    x[2220]   0
 UP bounds    x[2220]   750
 LO bounds    x[2221]   0
 UP bounds    x[2221]   120
 LO bounds    x[2222]   0
 UP bounds    x[2222]   750
 LO bounds    x[2223]   0
 UP bounds    x[2223]   120
 LO bounds    x[2224]   0
 UP bounds    x[2224]   750
 LO bounds    x[2225]   0
 UP bounds    x[2225]   400
 LO bounds    x[2226]   0
 UP bounds    x[2226]   400
 LO bounds    x[2227]   0
 UP bounds    x[2227]   400
 LO bounds    x[2228]   0
 UP bounds    x[2228]   400
 LO bounds    x[2229]   0
 UP bounds    x[2229]   400
 LO bounds    x[2230]   0
 UP bounds    x[2230]   400
 LO bounds    x[2231]   0
 UP bounds    x[2231]   400
 LO bounds    x[2232]   0
 UP bounds    x[2232]   400
 LO bounds    x[2233]   0
 UP bounds    x[2233]   400
 LO bounds    x[2234]   0
 UP bounds    x[2234]   400
 LO bounds    x[2235]   0
 UP bounds    x[2235]   400
 LO bounds    x[2236]   0
 UP bounds    x[2236]   400
 LO bounds    x[2237]   0
 UP bounds    x[2237]   400
 LO bounds    x[2238]   0
 UP bounds    x[2238]   400
 LO bounds    x[2239]   0
 UP bounds    x[2239]   400
 LO bounds    x[2240]   0
 UP bounds    x[2240]   400
 LO bounds    x[2241]   0
 UP bounds    x[2241]   120
 LO bounds    x[2242]   0
 UP bounds    x[2242]   150
 LO bounds    x[2243]   0
 UP bounds    x[2243]   120
 LO bounds    x[2244]   0
 UP bounds    x[2244]   150
 LO bounds    x[2245]   0
 UP bounds    x[2245]   120
 LO bounds    x[2246]   0
 UP bounds    x[2246]   150
 LO bounds    x[2247]   0
 UP bounds    x[2247]   120
 LO bounds    x[2248]   0
 UP bounds    x[2248]   150
 LO bounds    x[2249]   0
 UP bounds    x[2249]   120
 LO bounds    x[2250]   0
 UP bounds    x[2250]   150
 LO bounds    x[2251]   0
 UP bounds    x[2251]   120
 LO bounds    x[2252]   0
 UP bounds    x[2252]   150
 LO bounds    x[2253]   0
 UP bounds    x[2253]   120
 LO bounds    x[2254]   0
 UP bounds    x[2254]   150
 LO bounds    x[2255]   0
 UP bounds    x[2255]   120
 LO bounds    x[2256]   0
 UP bounds    x[2256]   150
 LO bounds    x[2257]   0
 UP bounds    x[2257]   120
 LO bounds    x[2258]   0
 UP bounds    x[2258]   150
 LO bounds    x[2259]   0
 UP bounds    x[2259]   120
 LO bounds    x[2260]   0
 UP bounds    x[2260]   150
 LO bounds    x[2261]   0
 UP bounds    x[2261]   120
 LO bounds    x[2262]   0
 UP bounds    x[2262]   150
 LO bounds    x[2263]   0
 UP bounds    x[2263]   120
 LO bounds    x[2264]   0
 UP bounds    x[2264]   150
 LO bounds    x[2265]   0
 UP bounds    x[2265]   120
 LO bounds    x[2266]   0
 UP bounds    x[2266]   150
 LO bounds    x[2267]   0
 UP bounds    x[2267]   120
 LO bounds    x[2268]   0
 UP bounds    x[2268]   150
 LO bounds    x[2269]   0
 UP bounds    x[2269]   120
 LO bounds    x[2270]   0
 UP bounds    x[2270]   150
 LO bounds    x[2271]   0
 UP bounds    x[2271]   120
 LO bounds    x[2272]   0
 UP bounds    x[2272]   150
 LO bounds    x[2273]   0
 UP bounds    x[2273]   400
 LO bounds    x[2274]   0
 UP bounds    x[2274]   400
 LO bounds    x[2275]   0
 UP bounds    x[2275]   400
 LO bounds    x[2276]   0
 UP bounds    x[2276]   400
 LO bounds    x[2277]   0
 UP bounds    x[2277]   400
 LO bounds    x[2278]   0
 UP bounds    x[2278]   400
 LO bounds    x[2279]   0
 UP bounds    x[2279]   400
 LO bounds    x[2280]   0
 UP bounds    x[2280]   400
 LO bounds    x[2281]   0
 UP bounds    x[2281]   400
 LO bounds    x[2282]   0
 UP bounds    x[2282]   400
 LO bounds    x[2283]   0
 UP bounds    x[2283]   400
 LO bounds    x[2284]   0
 UP bounds    x[2284]   400
 LO bounds    x[2285]   0
 UP bounds    x[2285]   400
 LO bounds    x[2286]   0
 UP bounds    x[2286]   400
 LO bounds    x[2287]   0
 UP bounds    x[2287]   400
 LO bounds    x[2288]   0
 UP bounds    x[2288]   400
 LO bounds    x[2289]   0
 UP bounds    x[2289]   120
 LO bounds    x[2290]   0
 UP bounds    x[2290]   250
 LO bounds    x[2291]   0
 UP bounds    x[2291]   120
 LO bounds    x[2292]   0
 UP bounds    x[2292]   250
 LO bounds    x[2293]   0
 UP bounds    x[2293]   120
 LO bounds    x[2294]   0
 UP bounds    x[2294]   250
 LO bounds    x[2295]   0
 UP bounds    x[2295]   120
 LO bounds    x[2296]   0
 UP bounds    x[2296]   250
 LO bounds    x[2297]   0
 UP bounds    x[2297]   120
 LO bounds    x[2298]   0
 UP bounds    x[2298]   250
 LO bounds    x[2299]   0
 UP bounds    x[2299]   120
 LO bounds    x[2300]   0
 UP bounds    x[2300]   250
 LO bounds    x[2301]   0
 UP bounds    x[2301]   120
 LO bounds    x[2302]   0
 UP bounds    x[2302]   250
 LO bounds    x[2303]   0
 UP bounds    x[2303]   120
 LO bounds    x[2304]   0
 UP bounds    x[2304]   250
 LO bounds    x[2305]   0
 UP bounds    x[2305]   120
 LO bounds    x[2306]   0
 UP bounds    x[2306]   250
 LO bounds    x[2307]   0
 UP bounds    x[2307]   120
 LO bounds    x[2308]   0
 UP bounds    x[2308]   250
 LO bounds    x[2309]   0
 UP bounds    x[2309]   120
 LO bounds    x[2310]   0
 UP bounds    x[2310]   250
 LO bounds    x[2311]   0
 UP bounds    x[2311]   120
 LO bounds    x[2312]   0
 UP bounds    x[2312]   250
 LO bounds    x[2313]   0
 UP bounds    x[2313]   120
 LO bounds    x[2314]   0
 UP bounds    x[2314]   250
 LO bounds    x[2315]   0
 UP bounds    x[2315]   120
 LO bounds    x[2316]   0
 UP bounds    x[2316]   250
 LO bounds    x[2317]   0
 UP bounds    x[2317]   120
 LO bounds    x[2318]   0
 UP bounds    x[2318]   250
 LO bounds    x[2319]   0
 UP bounds    x[2319]   120
 LO bounds    x[2320]   0
 UP bounds    x[2320]   250
 LO bounds    x[2321]   0
 UP bounds    x[2321]   400
 LO bounds    x[2322]   0
 UP bounds    x[2322]   400
 LO bounds    x[2323]   0
 UP bounds    x[2323]   400
 LO bounds    x[2324]   0
 UP bounds    x[2324]   400
 LO bounds    x[2325]   0
 UP bounds    x[2325]   400
 LO bounds    x[2326]   0
 UP bounds    x[2326]   400
 LO bounds    x[2327]   0
 UP bounds    x[2327]   400
 LO bounds    x[2328]   0
 UP bounds    x[2328]   400
 LO bounds    x[2329]   0
 UP bounds    x[2329]   400
 LO bounds    x[2330]   0
 UP bounds    x[2330]   400
 LO bounds    x[2331]   0
 UP bounds    x[2331]   400
 LO bounds    x[2332]   0
 UP bounds    x[2332]   400
 LO bounds    x[2333]   0
 UP bounds    x[2333]   400
 LO bounds    x[2334]   0
 UP bounds    x[2334]   400
 LO bounds    x[2335]   0
 UP bounds    x[2335]   400
 LO bounds    x[2336]   0
 UP bounds    x[2336]   400
 LO bounds    x[2337]   0
 UP bounds    x[2337]   7500
 LO bounds    x[2338]   0
 UP bounds    x[2338]   7500
 LO bounds    x[2339]   0
 UP bounds    x[2339]   7500
 LO bounds    x[2340]   0
 UP bounds    x[2340]   7500
 LO bounds    x[2341]   0
 UP bounds    x[2341]   7500
 LO bounds    x[2342]   0
 UP bounds    x[2342]   7500
 LO bounds    x[2343]   0
 UP bounds    x[2343]   7500
 LO bounds    x[2344]   0
 UP bounds    x[2344]   7500
 LO bounds    x[2345]   0
 UP bounds    x[2345]   7500
 LO bounds    x[2346]   0
 UP bounds    x[2346]   7500
 LO bounds    x[2347]   0
 UP bounds    x[2347]   7500
 LO bounds    x[2348]   0
 UP bounds    x[2348]   7500
 LO bounds    x[2349]   0
 UP bounds    x[2349]   7500
 LO bounds    x[2350]   0
 UP bounds    x[2350]   7500
 LO bounds    x[2351]   0
 UP bounds    x[2351]   7500
 LO bounds    x[2352]   0
 UP bounds    x[2352]   7500
 LO bounds    x[2353]   0
 UP bounds    x[2353]   5000
 LO bounds    x[2354]   0
 UP bounds    x[2354]   5000
 LO bounds    x[2355]   0
 UP bounds    x[2355]   5000
 LO bounds    x[2356]   0
 UP bounds    x[2356]   5000
 LO bounds    x[2357]   0
 UP bounds    x[2357]   5000
 LO bounds    x[2358]   0
 UP bounds    x[2358]   5000
 LO bounds    x[2359]   0
 UP bounds    x[2359]   5000
 LO bounds    x[2360]   0
 UP bounds    x[2360]   5000
 LO bounds    x[2361]   0
 UP bounds    x[2361]   5000
 LO bounds    x[2362]   0
 UP bounds    x[2362]   5000
 LO bounds    x[2363]   0
 UP bounds    x[2363]   5000
 LO bounds    x[2364]   0
 UP bounds    x[2364]   5000
 LO bounds    x[2365]   0
 UP bounds    x[2365]   5000
 LO bounds    x[2366]   0
 UP bounds    x[2366]   5000
 LO bounds    x[2367]   0
 UP bounds    x[2367]   5000
 LO bounds    x[2368]   0
 UP bounds    x[2368]   5000
 LO bounds    x[2369]   0
 UP bounds    x[2369]   7500
 LO bounds    x[2370]   0
 UP bounds    x[2370]   7500
 LO bounds    x[2371]   0
 UP bounds    x[2371]   7500
 LO bounds    x[2372]   0
 UP bounds    x[2372]   7500
 LO bounds    x[2373]   0
 UP bounds    x[2373]   7500
 LO bounds    x[2374]   0
 UP bounds    x[2374]   7500
 LO bounds    x[2375]   0
 UP bounds    x[2375]   7500
 LO bounds    x[2376]   0
 UP bounds    x[2376]   7500
 LO bounds    x[2377]   0
 UP bounds    x[2377]   7500
 LO bounds    x[2378]   0
 UP bounds    x[2378]   7500
 LO bounds    x[2379]   0
 UP bounds    x[2379]   7500
 LO bounds    x[2380]   0
 UP bounds    x[2380]   7500
 LO bounds    x[2381]   0
 UP bounds    x[2381]   7500
 LO bounds    x[2382]   0
 UP bounds    x[2382]   7500
 LO bounds    x[2383]   0
 UP bounds    x[2383]   7500
 LO bounds    x[2384]   0
 UP bounds    x[2384]   7500
 LO bounds    x[2385]   0
 UP bounds    x[2385]   5000
 LO bounds    x[2386]   0
 UP bounds    x[2386]   5000
 LO bounds    x[2387]   0
 UP bounds    x[2387]   5000
 LO bounds    x[2388]   0
 UP bounds    x[2388]   5000
 LO bounds    x[2389]   0
 UP bounds    x[2389]   5000
 LO bounds    x[2390]   0
 UP bounds    x[2390]   5000
 LO bounds    x[2391]   0
 UP bounds    x[2391]   5000
 LO bounds    x[2392]   0
 UP bounds    x[2392]   5000
 LO bounds    x[2393]   0
 UP bounds    x[2393]   5000
 LO bounds    x[2394]   0
 UP bounds    x[2394]   5000
 LO bounds    x[2395]   0
 UP bounds    x[2395]   5000
 LO bounds    x[2396]   0
 UP bounds    x[2396]   5000
 LO bounds    x[2397]   0
 UP bounds    x[2397]   5000
 LO bounds    x[2398]   0
 UP bounds    x[2398]   5000
 LO bounds    x[2399]   0
 UP bounds    x[2399]   5000
 LO bounds    x[2400]   0
 UP bounds    x[2400]   5000
 LO bounds    x[2401]   0
 UP bounds    x[2401]   37500
 LO bounds    x[2402]   0
 UP bounds    x[2402]   37500
 LO bounds    x[2403]   0
 UP bounds    x[2403]   37500
 LO bounds    x[2404]   0
 UP bounds    x[2404]   37500
 LO bounds    x[2405]   0
 UP bounds    x[2405]   37500
 LO bounds    x[2406]   0
 UP bounds    x[2406]   37500
 LO bounds    x[2407]   0
 UP bounds    x[2407]   37500
 LO bounds    x[2408]   0
 UP bounds    x[2408]   37500
 LO bounds    x[2409]   0
 UP bounds    x[2409]   37500
 LO bounds    x[2410]   0
 UP bounds    x[2410]   37500
 LO bounds    x[2411]   0
 UP bounds    x[2411]   37500
 LO bounds    x[2412]   0
 UP bounds    x[2412]   37500
 LO bounds    x[2413]   0
 UP bounds    x[2413]   37500
 LO bounds    x[2414]   0
 UP bounds    x[2414]   37500
 LO bounds    x[2415]   0
 UP bounds    x[2415]   37500
 LO bounds    x[2416]   0
 UP bounds    x[2416]   37500
 LO bounds    x[2417]   0
 UP bounds    x[2417]   7500
 LO bounds    x[2418]   0
 UP bounds    x[2418]   7500
 LO bounds    x[2419]   0
 UP bounds    x[2419]   7500
 LO bounds    x[2420]   0
 UP bounds    x[2420]   7500
 LO bounds    x[2421]   0
 UP bounds    x[2421]   7500
 LO bounds    x[2422]   0
 UP bounds    x[2422]   7500
 LO bounds    x[2423]   0
 UP bounds    x[2423]   7500
 LO bounds    x[2424]   0
 UP bounds    x[2424]   7500
 LO bounds    x[2425]   0
 UP bounds    x[2425]   7500
 LO bounds    x[2426]   0
 UP bounds    x[2426]   7500
 LO bounds    x[2427]   0
 UP bounds    x[2427]   7500
 LO bounds    x[2428]   0
 UP bounds    x[2428]   7500
 LO bounds    x[2429]   0
 UP bounds    x[2429]   7500
 LO bounds    x[2430]   0
 UP bounds    x[2430]   7500
 LO bounds    x[2431]   0
 UP bounds    x[2431]   7500
 LO bounds    x[2432]   0
 UP bounds    x[2432]   7500
 LO bounds    x[2433]   0
 UP bounds    x[2433]   37500
 LO bounds    x[2434]   0
 UP bounds    x[2434]   37500
 LO bounds    x[2435]   0
 UP bounds    x[2435]   37500
 LO bounds    x[2436]   0
 UP bounds    x[2436]   37500
 LO bounds    x[2437]   0
 UP bounds    x[2437]   37500
 LO bounds    x[2438]   0
 UP bounds    x[2438]   37500
 LO bounds    x[2439]   0
 UP bounds    x[2439]   37500
 LO bounds    x[2440]   0
 UP bounds    x[2440]   37500
 LO bounds    x[2441]   0
 UP bounds    x[2441]   37500
 LO bounds    x[2442]   0
 UP bounds    x[2442]   37500
 LO bounds    x[2443]   0
 UP bounds    x[2443]   37500
 LO bounds    x[2444]   0
 UP bounds    x[2444]   37500
 LO bounds    x[2445]   0
 UP bounds    x[2445]   37500
 LO bounds    x[2446]   0
 UP bounds    x[2446]   37500
 LO bounds    x[2447]   0
 UP bounds    x[2447]   37500
 LO bounds    x[2448]   0
 UP bounds    x[2448]   37500
 LO bounds    x[2449]   0
 UP bounds    x[2449]   7500
 LO bounds    x[2450]   0
 UP bounds    x[2450]   7500
 LO bounds    x[2451]   0
 UP bounds    x[2451]   7500
 LO bounds    x[2452]   0
 UP bounds    x[2452]   7500
 LO bounds    x[2453]   0
 UP bounds    x[2453]   7500
 LO bounds    x[2454]   0
 UP bounds    x[2454]   7500
 LO bounds    x[2455]   0
 UP bounds    x[2455]   7500
 LO bounds    x[2456]   0
 UP bounds    x[2456]   7500
 LO bounds    x[2457]   0
 UP bounds    x[2457]   7500
 LO bounds    x[2458]   0
 UP bounds    x[2458]   7500
 LO bounds    x[2459]   0
 UP bounds    x[2459]   7500
 LO bounds    x[2460]   0
 UP bounds    x[2460]   7500
 LO bounds    x[2461]   0
 UP bounds    x[2461]   7500
 LO bounds    x[2462]   0
 UP bounds    x[2462]   7500
 LO bounds    x[2463]   0
 UP bounds    x[2463]   7500
 LO bounds    x[2464]   0
 UP bounds    x[2464]   7500
 LO bounds    x[2465]   0
 UP bounds    x[2465]   15000
 LO bounds    x[2466]   0
 UP bounds    x[2466]   15000
 LO bounds    x[2467]   0
 UP bounds    x[2467]   15000
 LO bounds    x[2468]   0
 UP bounds    x[2468]   15000
 LO bounds    x[2469]   0
 UP bounds    x[2469]   15000
 LO bounds    x[2470]   0
 UP bounds    x[2470]   15000
 LO bounds    x[2471]   0
 UP bounds    x[2471]   15000
 LO bounds    x[2472]   0
 UP bounds    x[2472]   15000
 LO bounds    x[2473]   0
 UP bounds    x[2473]   15000
 LO bounds    x[2474]   0
 UP bounds    x[2474]   15000
 LO bounds    x[2475]   0
 UP bounds    x[2475]   15000
 LO bounds    x[2476]   0
 UP bounds    x[2476]   15000
 LO bounds    x[2477]   0
 UP bounds    x[2477]   15000
 LO bounds    x[2478]   0
 UP bounds    x[2478]   15000
 LO bounds    x[2479]   0
 UP bounds    x[2479]   15000
 LO bounds    x[2480]   0
 UP bounds    x[2480]   15000
 LO bounds    x[2481]   0
 UP bounds    x[2481]   2500
 LO bounds    x[2482]   0
 UP bounds    x[2482]   2500
 LO bounds    x[2483]   0
 UP bounds    x[2483]   2500
 LO bounds    x[2484]   0
 UP bounds    x[2484]   2500
 LO bounds    x[2485]   0
 UP bounds    x[2485]   2500
 LO bounds    x[2486]   0
 UP bounds    x[2486]   2500
 LO bounds    x[2487]   0
 UP bounds    x[2487]   2500
 LO bounds    x[2488]   0
 UP bounds    x[2488]   2500
 LO bounds    x[2489]   0
 UP bounds    x[2489]   2500
 LO bounds    x[2490]   0
 UP bounds    x[2490]   2500
 LO bounds    x[2491]   0
 UP bounds    x[2491]   2500
 LO bounds    x[2492]   0
 UP bounds    x[2492]   2500
 LO bounds    x[2493]   0
 UP bounds    x[2493]   2500
 LO bounds    x[2494]   0
 UP bounds    x[2494]   2500
 LO bounds    x[2495]   0
 UP bounds    x[2495]   2500
 LO bounds    x[2496]   0
 UP bounds    x[2496]   2500
 LO bounds    x[2497]   0
 UP bounds    x[2497]   15000
 LO bounds    x[2498]   0
 UP bounds    x[2498]   15000
 LO bounds    x[2499]   0
 UP bounds    x[2499]   15000
 LO bounds    x[2500]   0
 UP bounds    x[2500]   15000
 LO bounds    x[2501]   0
 UP bounds    x[2501]   15000
 LO bounds    x[2502]   0
 UP bounds    x[2502]   15000
 LO bounds    x[2503]   0
 UP bounds    x[2503]   15000
 LO bounds    x[2504]   0
 UP bounds    x[2504]   15000
 LO bounds    x[2505]   0
 UP bounds    x[2505]   15000
 LO bounds    x[2506]   0
 UP bounds    x[2506]   15000
 LO bounds    x[2507]   0
 UP bounds    x[2507]   15000
 LO bounds    x[2508]   0
 UP bounds    x[2508]   15000
 LO bounds    x[2509]   0
 UP bounds    x[2509]   15000
 LO bounds    x[2510]   0
 UP bounds    x[2510]   15000
 LO bounds    x[2511]   0
 UP bounds    x[2511]   15000
 LO bounds    x[2512]   0
 UP bounds    x[2512]   15000
 LO bounds    x[2513]   0
 UP bounds    x[2513]   2500
 LO bounds    x[2514]   0
 UP bounds    x[2514]   2500
 LO bounds    x[2515]   0
 UP bounds    x[2515]   2500
 LO bounds    x[2516]   0
 UP bounds    x[2516]   2500
 LO bounds    x[2517]   0
 UP bounds    x[2517]   2500
 LO bounds    x[2518]   0
 UP bounds    x[2518]   2500
 LO bounds    x[2519]   0
 UP bounds    x[2519]   2500
 LO bounds    x[2520]   0
 UP bounds    x[2520]   2500
 LO bounds    x[2521]   0
 UP bounds    x[2521]   2500
 LO bounds    x[2522]   0
 UP bounds    x[2522]   2500
 LO bounds    x[2523]   0
 UP bounds    x[2523]   2500
 LO bounds    x[2524]   0
 UP bounds    x[2524]   2500
 LO bounds    x[2525]   0
 UP bounds    x[2525]   2500
 LO bounds    x[2526]   0
 UP bounds    x[2526]   2500
 LO bounds    x[2527]   0
 UP bounds    x[2527]   2500
 LO bounds    x[2528]   0
 UP bounds    x[2528]   2500
 LO bounds    x[2529]   0
 UP bounds    x[2529]   37500
 LO bounds    x[2530]   0
 UP bounds    x[2530]   37500
 LO bounds    x[2531]   0
 UP bounds    x[2531]   37500
 LO bounds    x[2532]   0
 UP bounds    x[2532]   37500
 LO bounds    x[2533]   0
 UP bounds    x[2533]   37500
 LO bounds    x[2534]   0
 UP bounds    x[2534]   37500
 LO bounds    x[2535]   0
 UP bounds    x[2535]   37500
 LO bounds    x[2536]   0
 UP bounds    x[2536]   37500
 LO bounds    x[2537]   0
 UP bounds    x[2537]   37500
 LO bounds    x[2538]   0
 UP bounds    x[2538]   37500
 LO bounds    x[2539]   0
 UP bounds    x[2539]   37500
 LO bounds    x[2540]   0
 UP bounds    x[2540]   37500
 LO bounds    x[2541]   0
 UP bounds    x[2541]   37500
 LO bounds    x[2542]   0
 UP bounds    x[2542]   37500
 LO bounds    x[2543]   0
 UP bounds    x[2543]   37500
 LO bounds    x[2544]   0
 UP bounds    x[2544]   37500
 LO bounds    x[2545]   0
 UP bounds    x[2545]   5000
 LO bounds    x[2546]   0
 UP bounds    x[2546]   5000
 LO bounds    x[2547]   0
 UP bounds    x[2547]   5000
 LO bounds    x[2548]   0
 UP bounds    x[2548]   5000
 LO bounds    x[2549]   0
 UP bounds    x[2549]   5000
 LO bounds    x[2550]   0
 UP bounds    x[2550]   5000
 LO bounds    x[2551]   0
 UP bounds    x[2551]   5000
 LO bounds    x[2552]   0
 UP bounds    x[2552]   5000
 LO bounds    x[2553]   0
 UP bounds    x[2553]   5000
 LO bounds    x[2554]   0
 UP bounds    x[2554]   5000
 LO bounds    x[2555]   0
 UP bounds    x[2555]   5000
 LO bounds    x[2556]   0
 UP bounds    x[2556]   5000
 LO bounds    x[2557]   0
 UP bounds    x[2557]   5000
 LO bounds    x[2558]   0
 UP bounds    x[2558]   5000
 LO bounds    x[2559]   0
 UP bounds    x[2559]   5000
 LO bounds    x[2560]   0
 UP bounds    x[2560]   5000
 LO bounds    x[2561]   0
 UP bounds    x[2561]   37500
 LO bounds    x[2562]   0
 UP bounds    x[2562]   37500
 LO bounds    x[2563]   0
 UP bounds    x[2563]   37500
 LO bounds    x[2564]   0
 UP bounds    x[2564]   37500
 LO bounds    x[2565]   0
 UP bounds    x[2565]   37500
 LO bounds    x[2566]   0
 UP bounds    x[2566]   37500
 LO bounds    x[2567]   0
 UP bounds    x[2567]   37500
 LO bounds    x[2568]   0
 UP bounds    x[2568]   37500
 LO bounds    x[2569]   0
 UP bounds    x[2569]   37500
 LO bounds    x[2570]   0
 UP bounds    x[2570]   37500
 LO bounds    x[2571]   0
 UP bounds    x[2571]   37500
 LO bounds    x[2572]   0
 UP bounds    x[2572]   37500
 LO bounds    x[2573]   0
 UP bounds    x[2573]   37500
 LO bounds    x[2574]   0
 UP bounds    x[2574]   37500
 LO bounds    x[2575]   0
 UP bounds    x[2575]   37500
 LO bounds    x[2576]   0
 UP bounds    x[2576]   37500
 LO bounds    x[2577]   0
 UP bounds    x[2577]   5000
 LO bounds    x[2578]   0
 UP bounds    x[2578]   5000
 LO bounds    x[2579]   0
 UP bounds    x[2579]   5000
 LO bounds    x[2580]   0
 UP bounds    x[2580]   5000
 LO bounds    x[2581]   0
 UP bounds    x[2581]   5000
 LO bounds    x[2582]   0
 UP bounds    x[2582]   5000
 LO bounds    x[2583]   0
 UP bounds    x[2583]   5000
 LO bounds    x[2584]   0
 UP bounds    x[2584]   5000
 LO bounds    x[2585]   0
 UP bounds    x[2585]   5000
 LO bounds    x[2586]   0
 UP bounds    x[2586]   5000
 LO bounds    x[2587]   0
 UP bounds    x[2587]   5000
 LO bounds    x[2588]   0
 UP bounds    x[2588]   5000
 LO bounds    x[2589]   0
 UP bounds    x[2589]   5000
 LO bounds    x[2590]   0
 UP bounds    x[2590]   5000
 LO bounds    x[2591]   0
 UP bounds    x[2591]   5000
 LO bounds    x[2592]   0
 UP bounds    x[2592]   5000
 LO bounds    x[2593]   0
 UP bounds    x[2593]   15000
 LO bounds    x[2594]   0
 UP bounds    x[2594]   15000
 LO bounds    x[2595]   0
 UP bounds    x[2595]   15000
 LO bounds    x[2596]   0
 UP bounds    x[2596]   15000
 LO bounds    x[2597]   0
 UP bounds    x[2597]   15000
 LO bounds    x[2598]   0
 UP bounds    x[2598]   15000
 LO bounds    x[2599]   0
 UP bounds    x[2599]   15000
 LO bounds    x[2600]   0
 UP bounds    x[2600]   15000
 LO bounds    x[2601]   0
 UP bounds    x[2601]   15000
 LO bounds    x[2602]   0
 UP bounds    x[2602]   15000
 LO bounds    x[2603]   0
 UP bounds    x[2603]   15000
 LO bounds    x[2604]   0
 UP bounds    x[2604]   15000
 LO bounds    x[2605]   0
 UP bounds    x[2605]   15000
 LO bounds    x[2606]   0
 UP bounds    x[2606]   15000
 LO bounds    x[2607]   0
 UP bounds    x[2607]   15000
 LO bounds    x[2608]   0
 UP bounds    x[2608]   15000
 LO bounds    x[2609]   0
 UP bounds    x[2609]   3000
 LO bounds    x[2610]   0
 UP bounds    x[2610]   3000
 LO bounds    x[2611]   0
 UP bounds    x[2611]   3000
 LO bounds    x[2612]   0
 UP bounds    x[2612]   3000
 LO bounds    x[2613]   0
 UP bounds    x[2613]   3000
 LO bounds    x[2614]   0
 UP bounds    x[2614]   3000
 LO bounds    x[2615]   0
 UP bounds    x[2615]   3000
 LO bounds    x[2616]   0
 UP bounds    x[2616]   3000
 LO bounds    x[2617]   0
 UP bounds    x[2617]   3000
 LO bounds    x[2618]   0
 UP bounds    x[2618]   3000
 LO bounds    x[2619]   0
 UP bounds    x[2619]   3000
 LO bounds    x[2620]   0
 UP bounds    x[2620]   3000
 LO bounds    x[2621]   0
 UP bounds    x[2621]   3000
 LO bounds    x[2622]   0
 UP bounds    x[2622]   3000
 LO bounds    x[2623]   0
 UP bounds    x[2623]   3000
 LO bounds    x[2624]   0
 UP bounds    x[2624]   3000
 LO bounds    x[2625]   0
 UP bounds    x[2625]   15000
 LO bounds    x[2626]   0
 UP bounds    x[2626]   15000
 LO bounds    x[2627]   0
 UP bounds    x[2627]   15000
 LO bounds    x[2628]   0
 UP bounds    x[2628]   15000
 LO bounds    x[2629]   0
 UP bounds    x[2629]   15000
 LO bounds    x[2630]   0
 UP bounds    x[2630]   15000
 LO bounds    x[2631]   0
 UP bounds    x[2631]   15000
 LO bounds    x[2632]   0
 UP bounds    x[2632]   15000
 LO bounds    x[2633]   0
 UP bounds    x[2633]   15000
 LO bounds    x[2634]   0
 UP bounds    x[2634]   15000
 LO bounds    x[2635]   0
 UP bounds    x[2635]   15000
 LO bounds    x[2636]   0
 UP bounds    x[2636]   15000
 LO bounds    x[2637]   0
 UP bounds    x[2637]   15000
 LO bounds    x[2638]   0
 UP bounds    x[2638]   15000
 LO bounds    x[2639]   0
 UP bounds    x[2639]   15000
 LO bounds    x[2640]   0
 UP bounds    x[2640]   15000
 LO bounds    x[2641]   0
 UP bounds    x[2641]   3000
 LO bounds    x[2642]   0
 UP bounds    x[2642]   3000
 LO bounds    x[2643]   0
 UP bounds    x[2643]   3000
 LO bounds    x[2644]   0
 UP bounds    x[2644]   3000
 LO bounds    x[2645]   0
 UP bounds    x[2645]   3000
 LO bounds    x[2646]   0
 UP bounds    x[2646]   3000
 LO bounds    x[2647]   0
 UP bounds    x[2647]   3000
 LO bounds    x[2648]   0
 UP bounds    x[2648]   3000
 LO bounds    x[2649]   0
 UP bounds    x[2649]   3000
 LO bounds    x[2650]   0
 UP bounds    x[2650]   3000
 LO bounds    x[2651]   0
 UP bounds    x[2651]   3000
 LO bounds    x[2652]   0
 UP bounds    x[2652]   3000
 LO bounds    x[2653]   0
 UP bounds    x[2653]   3000
 LO bounds    x[2654]   0
 UP bounds    x[2654]   3000
 LO bounds    x[2655]   0
 UP bounds    x[2655]   3000
 LO bounds    x[2656]   0
 UP bounds    x[2656]   3000
 LO bounds    x[2657]   0
 UP bounds    x[2657]   37500
 LO bounds    x[2658]   0
 UP bounds    x[2658]   37500
 LO bounds    x[2659]   0
 UP bounds    x[2659]   37500
 LO bounds    x[2660]   0
 UP bounds    x[2660]   37500
 LO bounds    x[2661]   0
 UP bounds    x[2661]   37500
 LO bounds    x[2662]   0
 UP bounds    x[2662]   37500
 LO bounds    x[2663]   0
 UP bounds    x[2663]   37500
 LO bounds    x[2664]   0
 UP bounds    x[2664]   37500
 LO bounds    x[2665]   0
 UP bounds    x[2665]   37500
 LO bounds    x[2666]   0
 UP bounds    x[2666]   37500
 LO bounds    x[2667]   0
 UP bounds    x[2667]   37500
 LO bounds    x[2668]   0
 UP bounds    x[2668]   37500
 LO bounds    x[2669]   0
 UP bounds    x[2669]   37500
 LO bounds    x[2670]   0
 UP bounds    x[2670]   37500
 LO bounds    x[2671]   0
 UP bounds    x[2671]   37500
 LO bounds    x[2672]   0
 UP bounds    x[2672]   37500
 LO bounds    x[2673]   0
 UP bounds    x[2673]   3750
 LO bounds    x[2674]   0
 UP bounds    x[2674]   3750
 LO bounds    x[2675]   0
 UP bounds    x[2675]   3750
 LO bounds    x[2676]   0
 UP bounds    x[2676]   3750
 LO bounds    x[2677]   0
 UP bounds    x[2677]   3750
 LO bounds    x[2678]   0
 UP bounds    x[2678]   3750
 LO bounds    x[2679]   0
 UP bounds    x[2679]   3750
 LO bounds    x[2680]   0
 UP bounds    x[2680]   3750
 LO bounds    x[2681]   0
 UP bounds    x[2681]   3750
 LO bounds    x[2682]   0
 UP bounds    x[2682]   3750
 LO bounds    x[2683]   0
 UP bounds    x[2683]   3750
 LO bounds    x[2684]   0
 UP bounds    x[2684]   3750
 LO bounds    x[2685]   0
 UP bounds    x[2685]   3750
 LO bounds    x[2686]   0
 UP bounds    x[2686]   3750
 LO bounds    x[2687]   0
 UP bounds    x[2687]   3750
 LO bounds    x[2688]   0
 UP bounds    x[2688]   3750
 LO bounds    x[2689]   0
 UP bounds    x[2689]   37500
 LO bounds    x[2690]   0
 UP bounds    x[2690]   37500
 LO bounds    x[2691]   0
 UP bounds    x[2691]   37500
 LO bounds    x[2692]   0
 UP bounds    x[2692]   37500
 LO bounds    x[2693]   0
 UP bounds    x[2693]   37500
 LO bounds    x[2694]   0
 UP bounds    x[2694]   37500
 LO bounds    x[2695]   0
 UP bounds    x[2695]   37500
 LO bounds    x[2696]   0
 UP bounds    x[2696]   37500
 LO bounds    x[2697]   0
 UP bounds    x[2697]   37500
 LO bounds    x[2698]   0
 UP bounds    x[2698]   37500
 LO bounds    x[2699]   0
 UP bounds    x[2699]   37500
 LO bounds    x[2700]   0
 UP bounds    x[2700]   37500
 LO bounds    x[2701]   0
 UP bounds    x[2701]   37500
 LO bounds    x[2702]   0
 UP bounds    x[2702]   37500
 LO bounds    x[2703]   0
 UP bounds    x[2703]   37500
 LO bounds    x[2704]   0
 UP bounds    x[2704]   37500
 LO bounds    x[2705]   0
 UP bounds    x[2705]   3750
 LO bounds    x[2706]   0
 UP bounds    x[2706]   3750
 LO bounds    x[2707]   0
 UP bounds    x[2707]   3750
 LO bounds    x[2708]   0
 UP bounds    x[2708]   3750
 LO bounds    x[2709]   0
 UP bounds    x[2709]   3750
 LO bounds    x[2710]   0
 UP bounds    x[2710]   3750
 LO bounds    x[2711]   0
 UP bounds    x[2711]   3750
 LO bounds    x[2712]   0
 UP bounds    x[2712]   3750
 LO bounds    x[2713]   0
 UP bounds    x[2713]   3750
 LO bounds    x[2714]   0
 UP bounds    x[2714]   3750
 LO bounds    x[2715]   0
 UP bounds    x[2715]   3750
 LO bounds    x[2716]   0
 UP bounds    x[2716]   3750
 LO bounds    x[2717]   0
 UP bounds    x[2717]   3750
 LO bounds    x[2718]   0
 UP bounds    x[2718]   3750
 LO bounds    x[2719]   0
 UP bounds    x[2719]   3750
 LO bounds    x[2720]   0
 UP bounds    x[2720]   3750
 LO bounds    x[2721]   0
 UP bounds    x[2721]   15000
 LO bounds    x[2722]   0
 UP bounds    x[2722]   15000
 LO bounds    x[2723]   0
 UP bounds    x[2723]   15000
 LO bounds    x[2724]   0
 UP bounds    x[2724]   15000
 LO bounds    x[2725]   0
 UP bounds    x[2725]   15000
 LO bounds    x[2726]   0
 UP bounds    x[2726]   15000
 LO bounds    x[2727]   0
 UP bounds    x[2727]   15000
 LO bounds    x[2728]   0
 UP bounds    x[2728]   15000
 LO bounds    x[2729]   0
 UP bounds    x[2729]   15000
 LO bounds    x[2730]   0
 UP bounds    x[2730]   15000
 LO bounds    x[2731]   0
 UP bounds    x[2731]   15000
 LO bounds    x[2732]   0
 UP bounds    x[2732]   15000
 LO bounds    x[2733]   0
 UP bounds    x[2733]   15000
 LO bounds    x[2734]   0
 UP bounds    x[2734]   15000
 LO bounds    x[2735]   0
 UP bounds    x[2735]   15000
 LO bounds    x[2736]   0
 UP bounds    x[2736]   15000
 LO bounds    x[2737]   0
 UP bounds    x[2737]   2142.8571428571427
 LO bounds    x[2738]   0
 UP bounds    x[2738]   2142.8571428571427
 LO bounds    x[2739]   0
 UP bounds    x[2739]   2142.8571428571427
 LO bounds    x[2740]   0
 UP bounds    x[2740]   2142.8571428571427
 LO bounds    x[2741]   0
 UP bounds    x[2741]   2142.8571428571427
 LO bounds    x[2742]   0
 UP bounds    x[2742]   2142.8571428571427
 LO bounds    x[2743]   0
 UP bounds    x[2743]   2142.8571428571427
 LO bounds    x[2744]   0
 UP bounds    x[2744]   2142.8571428571427
 LO bounds    x[2745]   0
 UP bounds    x[2745]   2142.8571428571427
 LO bounds    x[2746]   0
 UP bounds    x[2746]   2142.8571428571427
 LO bounds    x[2747]   0
 UP bounds    x[2747]   2142.8571428571427
 LO bounds    x[2748]   0
 UP bounds    x[2748]   2142.8571428571427
 LO bounds    x[2749]   0
 UP bounds    x[2749]   2142.8571428571427
 LO bounds    x[2750]   0
 UP bounds    x[2750]   2142.8571428571427
 LO bounds    x[2751]   0
 UP bounds    x[2751]   2142.8571428571427
 LO bounds    x[2752]   0
 UP bounds    x[2752]   2142.8571428571427
 LO bounds    x[2753]   0
 UP bounds    x[2753]   15000
 LO bounds    x[2754]   0
 UP bounds    x[2754]   15000
 LO bounds    x[2755]   0
 UP bounds    x[2755]   15000
 LO bounds    x[2756]   0
 UP bounds    x[2756]   15000
 LO bounds    x[2757]   0
 UP bounds    x[2757]   15000
 LO bounds    x[2758]   0
 UP bounds    x[2758]   15000
 LO bounds    x[2759]   0
 UP bounds    x[2759]   15000
 LO bounds    x[2760]   0
 UP bounds    x[2760]   15000
 LO bounds    x[2761]   0
 UP bounds    x[2761]   15000
 LO bounds    x[2762]   0
 UP bounds    x[2762]   15000
 LO bounds    x[2763]   0
 UP bounds    x[2763]   15000
 LO bounds    x[2764]   0
 UP bounds    x[2764]   15000
 LO bounds    x[2765]   0
 UP bounds    x[2765]   15000
 LO bounds    x[2766]   0
 UP bounds    x[2766]   15000
 LO bounds    x[2767]   0
 UP bounds    x[2767]   15000
 LO bounds    x[2768]   0
 UP bounds    x[2768]   15000
 LO bounds    x[2769]   0
 UP bounds    x[2769]   2142.8571428571427
 LO bounds    x[2770]   0
 UP bounds    x[2770]   2142.8571428571427
 LO bounds    x[2771]   0
 UP bounds    x[2771]   2142.8571428571427
 LO bounds    x[2772]   0
 UP bounds    x[2772]   2142.8571428571427
 LO bounds    x[2773]   0
 UP bounds    x[2773]   2142.8571428571427
 LO bounds    x[2774]   0
 UP bounds    x[2774]   2142.8571428571427
 LO bounds    x[2775]   0
 UP bounds    x[2775]   2142.8571428571427
 LO bounds    x[2776]   0
 UP bounds    x[2776]   2142.8571428571427
 LO bounds    x[2777]   0
 UP bounds    x[2777]   2142.8571428571427
 LO bounds    x[2778]   0
 UP bounds    x[2778]   2142.8571428571427
 LO bounds    x[2779]   0
 UP bounds    x[2779]   2142.8571428571427
 LO bounds    x[2780]   0
 UP bounds    x[2780]   2142.8571428571427
 LO bounds    x[2781]   0
 UP bounds    x[2781]   2142.8571428571427
 LO bounds    x[2782]   0
 UP bounds    x[2782]   2142.8571428571427
 LO bounds    x[2783]   0
 UP bounds    x[2783]   2142.8571428571427
 LO bounds    x[2784]   0
 UP bounds    x[2784]   2142.8571428571427
 LO bounds    x[2785]   0
 UP bounds    x[2785]   37500
 LO bounds    x[2786]   0
 UP bounds    x[2786]   37500
 LO bounds    x[2787]   0
 UP bounds    x[2787]   37500
 LO bounds    x[2788]   0
 UP bounds    x[2788]   37500
 LO bounds    x[2789]   0
 UP bounds    x[2789]   37500
 LO bounds    x[2790]   0
 UP bounds    x[2790]   37500
 LO bounds    x[2791]   0
 UP bounds    x[2791]   37500
 LO bounds    x[2792]   0
 UP bounds    x[2792]   37500
 LO bounds    x[2793]   0
 UP bounds    x[2793]   37500
 LO bounds    x[2794]   0
 UP bounds    x[2794]   37500
 LO bounds    x[2795]   0
 UP bounds    x[2795]   37500
 LO bounds    x[2796]   0
 UP bounds    x[2796]   37500
 LO bounds    x[2797]   0
 UP bounds    x[2797]   37500
 LO bounds    x[2798]   0
 UP bounds    x[2798]   37500
 LO bounds    x[2799]   0
 UP bounds    x[2799]   37500
 LO bounds    x[2800]   0
 UP bounds    x[2800]   37500
 LO bounds    x[2801]   0
 UP bounds    x[2801]   3000
 LO bounds    x[2802]   0
 UP bounds    x[2802]   3000
 LO bounds    x[2803]   0
 UP bounds    x[2803]   3000
 LO bounds    x[2804]   0
 UP bounds    x[2804]   3000
 LO bounds    x[2805]   0
 UP bounds    x[2805]   3000
 LO bounds    x[2806]   0
 UP bounds    x[2806]   3000
 LO bounds    x[2807]   0
 UP bounds    x[2807]   3000
 LO bounds    x[2808]   0
 UP bounds    x[2808]   3000
 LO bounds    x[2809]   0
 UP bounds    x[2809]   3000
 LO bounds    x[2810]   0
 UP bounds    x[2810]   3000
 LO bounds    x[2811]   0
 UP bounds    x[2811]   3000
 LO bounds    x[2812]   0
 UP bounds    x[2812]   3000
 LO bounds    x[2813]   0
 UP bounds    x[2813]   3000
 LO bounds    x[2814]   0
 UP bounds    x[2814]   3000
 LO bounds    x[2815]   0
 UP bounds    x[2815]   3000
 LO bounds    x[2816]   0
 UP bounds    x[2816]   3000
 LO bounds    x[2817]   0
 UP bounds    x[2817]   37500
 LO bounds    x[2818]   0
 UP bounds    x[2818]   37500
 LO bounds    x[2819]   0
 UP bounds    x[2819]   37500
 LO bounds    x[2820]   0
 UP bounds    x[2820]   37500
 LO bounds    x[2821]   0
 UP bounds    x[2821]   37500
 LO bounds    x[2822]   0
 UP bounds    x[2822]   37500
 LO bounds    x[2823]   0
 UP bounds    x[2823]   37500
 LO bounds    x[2824]   0
 UP bounds    x[2824]   37500
 LO bounds    x[2825]   0
 UP bounds    x[2825]   37500
 LO bounds    x[2826]   0
 UP bounds    x[2826]   37500
 LO bounds    x[2827]   0
 UP bounds    x[2827]   37500
 LO bounds    x[2828]   0
 UP bounds    x[2828]   37500
 LO bounds    x[2829]   0
 UP bounds    x[2829]   37500
 LO bounds    x[2830]   0
 UP bounds    x[2830]   37500
 LO bounds    x[2831]   0
 UP bounds    x[2831]   37500
 LO bounds    x[2832]   0
 UP bounds    x[2832]   37500
 LO bounds    x[2833]   0
 UP bounds    x[2833]   3000
 LO bounds    x[2834]   0
 UP bounds    x[2834]   3000
 LO bounds    x[2835]   0
 UP bounds    x[2835]   3000
 LO bounds    x[2836]   0
 UP bounds    x[2836]   3000
 LO bounds    x[2837]   0
 UP bounds    x[2837]   3000
 LO bounds    x[2838]   0
 UP bounds    x[2838]   3000
 LO bounds    x[2839]   0
 UP bounds    x[2839]   3000
 LO bounds    x[2840]   0
 UP bounds    x[2840]   3000
 LO bounds    x[2841]   0
 UP bounds    x[2841]   3000
 LO bounds    x[2842]   0
 UP bounds    x[2842]   3000
 LO bounds    x[2843]   0
 UP bounds    x[2843]   3000
 LO bounds    x[2844]   0
 UP bounds    x[2844]   3000
 LO bounds    x[2845]   0
 UP bounds    x[2845]   3000
 LO bounds    x[2846]   0
 UP bounds    x[2846]   3000
 LO bounds    x[2847]   0
 UP bounds    x[2847]   3000
 LO bounds    x[2848]   0
 UP bounds    x[2848]   3000
 LO bounds    x[2849]   0
 UP bounds    x[2849]   1
 LO bounds    x[2850]   0
 UP bounds    x[2850]   1
 LO bounds    x[2851]   0
 UP bounds    x[2851]   1
 LO bounds    x[2852]   0
 UP bounds    x[2852]   1
 LO bounds    x[2853]   0
 UP bounds    x[2853]   1
 LO bounds    x[2854]   0
 UP bounds    x[2854]   1
 LO bounds    x[2855]   0
 UP bounds    x[2855]   1
 LO bounds    x[2856]   0
 UP bounds    x[2856]   1
 LO bounds    x[2857]   0
 UP bounds    x[2857]   1
 LO bounds    x[2858]   0
 UP bounds    x[2858]   1
 LO bounds    x[2859]   0
 UP bounds    x[2859]   1
 LO bounds    x[2860]   0
 UP bounds    x[2860]   1
 LO bounds    x[2861]   0
 UP bounds    x[2861]   1
 LO bounds    x[2862]   0
 UP bounds    x[2862]   1
 LO bounds    x[2863]   0
 UP bounds    x[2863]   1
 LO bounds    x[2864]   0
 UP bounds    x[2864]   1
 LO bounds    x[2865]   0
 UP bounds    x[2865]   1
 LO bounds    x[2866]   0
 UP bounds    x[2866]   1
 LO bounds    x[2867]   0
 UP bounds    x[2867]   1
 LO bounds    x[2868]   0
 UP bounds    x[2868]   1
 LO bounds    x[2869]   0
 UP bounds    x[2869]   1
 LO bounds    x[2870]   0
 UP bounds    x[2870]   1
 LO bounds    x[2871]   0
 UP bounds    x[2871]   1
 LO bounds    x[2872]   0
 UP bounds    x[2872]   1
 LO bounds    x[2873]   0
 UP bounds    x[2873]   1
 LO bounds    x[2874]   0
 UP bounds    x[2874]   1
 LO bounds    x[2875]   0
 UP bounds    x[2875]   1
 LO bounds    x[2876]   0
 UP bounds    x[2876]   1
 LO bounds    x[2877]   0
 UP bounds    x[2877]   1
 LO bounds    x[2878]   0
 UP bounds    x[2878]   1
 LO bounds    x[2879]   0
 UP bounds    x[2879]   1
 LO bounds    x[2880]   0
 UP bounds    x[2880]   1
 LO bounds    x[2881]   0
 UP bounds    x[2881]   1
 LO bounds    x[2882]   0
 UP bounds    x[2882]   1
 LO bounds    x[2883]   0
 UP bounds    x[2883]   1
 LO bounds    x[2884]   0
 UP bounds    x[2884]   1
 LO bounds    x[2885]   0
 UP bounds    x[2885]   1
 LO bounds    x[2886]   0
 UP bounds    x[2886]   1
 LO bounds    x[2887]   0
 UP bounds    x[2887]   1
 LO bounds    x[2888]   0
 UP bounds    x[2888]   1
 LO bounds    x[2889]   0
 UP bounds    x[2889]   1
 LO bounds    x[2890]   0
 UP bounds    x[2890]   1
 LO bounds    x[2891]   0
 UP bounds    x[2891]   1
 LO bounds    x[2892]   0
 UP bounds    x[2892]   1
 LO bounds    x[2893]   0
 UP bounds    x[2893]   1
 LO bounds    x[2894]   0
 UP bounds    x[2894]   1
 LO bounds    x[2895]   0
 UP bounds    x[2895]   1
 LO bounds    x[2896]   0
 UP bounds    x[2896]   1
 LO bounds    x[2897]   0
 UP bounds    x[2897]   1
 LO bounds    x[2898]   0
 UP bounds    x[2898]   1
 LO bounds    x[2899]   0
 UP bounds    x[2899]   1
 LO bounds    x[2900]   0
 UP bounds    x[2900]   1
 LO bounds    x[2901]   0
 UP bounds    x[2901]   1
 LO bounds    x[2902]   0
 UP bounds    x[2902]   1
 LO bounds    x[2903]   0
 UP bounds    x[2903]   1
 LO bounds    x[2904]   0
 UP bounds    x[2904]   1
 LO bounds    x[2905]   0
 UP bounds    x[2905]   1
 LO bounds    x[2906]   0
 UP bounds    x[2906]   1
 LO bounds    x[2907]   0
 UP bounds    x[2907]   1
 LO bounds    x[2908]   0
 UP bounds    x[2908]   1
 LO bounds    x[2909]   0
 UP bounds    x[2909]   1
 LO bounds    x[2910]   0
 UP bounds    x[2910]   1
 LO bounds    x[2911]   0
 UP bounds    x[2911]   1
 LO bounds    x[2912]   0
 UP bounds    x[2912]   1
 LO bounds    x[2913]   0
 UP bounds    x[2913]   1
 LO bounds    x[2914]   0
 UP bounds    x[2914]   1
 LO bounds    x[2915]   0
 UP bounds    x[2915]   1
 LO bounds    x[2916]   0
 UP bounds    x[2916]   1
 LO bounds    x[2917]   0
 UP bounds    x[2917]   1
 LO bounds    x[2918]   0
 UP bounds    x[2918]   1
 LO bounds    x[2919]   0
 UP bounds    x[2919]   1
 LO bounds    x[2920]   0
 UP bounds    x[2920]   1
 LO bounds    x[2921]   0
 UP bounds    x[2921]   1
 LO bounds    x[2922]   0
 UP bounds    x[2922]   1
 LO bounds    x[2923]   0
 UP bounds    x[2923]   1
 LO bounds    x[2924]   0
 UP bounds    x[2924]   1
 LO bounds    x[2925]   0
 UP bounds    x[2925]   1
 LO bounds    x[2926]   0
 UP bounds    x[2926]   1
 LO bounds    x[2927]   0
 UP bounds    x[2927]   1
 LO bounds    x[2928]   0
 UP bounds    x[2928]   1
 LO bounds    x[2929]   0
 UP bounds    x[2929]   1
 LO bounds    x[2930]   0
 UP bounds    x[2930]   1
 LO bounds    x[2931]   0
 UP bounds    x[2931]   1
 LO bounds    x[2932]   0
 UP bounds    x[2932]   1
 LO bounds    x[2933]   0
 UP bounds    x[2933]   1
 LO bounds    x[2934]   0
 UP bounds    x[2934]   1
 LO bounds    x[2935]   0
 UP bounds    x[2935]   1
 LO bounds    x[2936]   0
 UP bounds    x[2936]   1
 LO bounds    x[2937]   0
 UP bounds    x[2937]   1
 LO bounds    x[2938]   0
 UP bounds    x[2938]   1
 LO bounds    x[2939]   0
 UP bounds    x[2939]   1
 LO bounds    x[2940]   0
 UP bounds    x[2940]   1
 LO bounds    x[2941]   0
 UP bounds    x[2941]   1
 LO bounds    x[2942]   0
 UP bounds    x[2942]   1
 LO bounds    x[2943]   0
 UP bounds    x[2943]   1
 LO bounds    x[2944]   0
 UP bounds    x[2944]   1
 LO bounds    x[2945]   0
 UP bounds    x[2945]   1
 LO bounds    x[2946]   0
 UP bounds    x[2946]   1
 LO bounds    x[2947]   0
 UP bounds    x[2947]   1
 LO bounds    x[2948]   0
 UP bounds    x[2948]   1
 LO bounds    x[2949]   0
 UP bounds    x[2949]   1
 LO bounds    x[2950]   0
 UP bounds    x[2950]   1
 LO bounds    x[2951]   0
 UP bounds    x[2951]   1
 LO bounds    x[2952]   0
 UP bounds    x[2952]   1
 LO bounds    x[2953]   0
 UP bounds    x[2953]   1
 LO bounds    x[2954]   0
 UP bounds    x[2954]   1
 LO bounds    x[2955]   0
 UP bounds    x[2955]   1
 LO bounds    x[2956]   0
 UP bounds    x[2956]   1
 LO bounds    x[2957]   0
 UP bounds    x[2957]   1
 LO bounds    x[2958]   0
 UP bounds    x[2958]   1
 LO bounds    x[2959]   0
 UP bounds    x[2959]   1
 LO bounds    x[2960]   0
 UP bounds    x[2960]   1
 LO bounds    x[2961]   0
 UP bounds    x[2961]   1
 LO bounds    x[2962]   0
 UP bounds    x[2962]   1
 LO bounds    x[2963]   0
 UP bounds    x[2963]   1
 LO bounds    x[2964]   0
 UP bounds    x[2964]   1
 LO bounds    x[2965]   0
 UP bounds    x[2965]   1
 LO bounds    x[2966]   0
 UP bounds    x[2966]   1
 LO bounds    x[2967]   0
 UP bounds    x[2967]   1
 LO bounds    x[2968]   0
 UP bounds    x[2968]   1
 LO bounds    x[2969]   0
 UP bounds    x[2969]   1
 LO bounds    x[2970]   0
 UP bounds    x[2970]   1
 LO bounds    x[2971]   0
 UP bounds    x[2971]   1
 LO bounds    x[2972]   0
 UP bounds    x[2972]   1
 LO bounds    x[2973]   0
 UP bounds    x[2973]   1
 LO bounds    x[2974]   0
 UP bounds    x[2974]   1
 LO bounds    x[2975]   0
 UP bounds    x[2975]   1
 LO bounds    x[2976]   0
 UP bounds    x[2976]   1
 LO bounds    x[2977]   0
 UP bounds    x[2977]   1
 LO bounds    x[2978]   0
 UP bounds    x[2978]   1
 LO bounds    x[2979]   0
 UP bounds    x[2979]   1
 LO bounds    x[2980]   0
 UP bounds    x[2980]   1
 LO bounds    x[2981]   0
 UP bounds    x[2981]   1
 LO bounds    x[2982]   0
 UP bounds    x[2982]   1
 LO bounds    x[2983]   0
 UP bounds    x[2983]   1
 LO bounds    x[2984]   0
 UP bounds    x[2984]   1
 LO bounds    x[2985]   0
 UP bounds    x[2985]   1
 LO bounds    x[2986]   0
 UP bounds    x[2986]   1
 LO bounds    x[2987]   0
 UP bounds    x[2987]   1
 LO bounds    x[2988]   0
 UP bounds    x[2988]   1
 LO bounds    x[2989]   0
 UP bounds    x[2989]   1
 LO bounds    x[2990]   0
 UP bounds    x[2990]   1
 LO bounds    x[2991]   0
 UP bounds    x[2991]   1
 LO bounds    x[2992]   0
 UP bounds    x[2992]   1
 LO bounds    x[2993]   0
 UP bounds    x[2993]   1
 LO bounds    x[2994]   0
 UP bounds    x[2994]   1
 LO bounds    x[2995]   0
 UP bounds    x[2995]   1
 LO bounds    x[2996]   0
 UP bounds    x[2996]   1
 LO bounds    x[2997]   0
 UP bounds    x[2997]   1
 LO bounds    x[2998]   0
 UP bounds    x[2998]   1
 LO bounds    x[2999]   0
 UP bounds    x[2999]   1
 LO bounds    x[3000]   0
 UP bounds    x[3000]   1
 LO bounds    x[3001]   0
 UP bounds    x[3001]   1
 LO bounds    x[3002]   0
 UP bounds    x[3002]   1
 LO bounds    x[3003]   0
 UP bounds    x[3003]   1
 LO bounds    x[3004]   0
 UP bounds    x[3004]   1
 LO bounds    x[3005]   0
 UP bounds    x[3005]   1
 LO bounds    x[3006]   0
 UP bounds    x[3006]   1
 LO bounds    x[3007]   0
 UP bounds    x[3007]   1
 LO bounds    x[3008]   0
 UP bounds    x[3008]   1
 LO bounds    x[3009]   0
 UP bounds    x[3009]   1
 LO bounds    x[3010]   0
 UP bounds    x[3010]   1
 LO bounds    x[3011]   0
 UP bounds    x[3011]   1
 LO bounds    x[3012]   0
 UP bounds    x[3012]   1
 LO bounds    x[3013]   0
 UP bounds    x[3013]   1
 LO bounds    x[3014]   0
 UP bounds    x[3014]   1
 LO bounds    x[3015]   0
 UP bounds    x[3015]   1
 LO bounds    x[3016]   0
 UP bounds    x[3016]   1
 LO bounds    x[3017]   0
 UP bounds    x[3017]   1
 LO bounds    x[3018]   0
 UP bounds    x[3018]   1
 LO bounds    x[3019]   0
 UP bounds    x[3019]   1
 LO bounds    x[3020]   0
 UP bounds    x[3020]   1
 LO bounds    x[3021]   0
 UP bounds    x[3021]   1
 LO bounds    x[3022]   0
 UP bounds    x[3022]   1
 LO bounds    x[3023]   0
 UP bounds    x[3023]   1
 LO bounds    x[3024]   0
 UP bounds    x[3024]   1
 LO bounds    x[3025]   0
 UP bounds    x[3025]   1
 LO bounds    x[3026]   0
 UP bounds    x[3026]   1
 LO bounds    x[3027]   0
 UP bounds    x[3027]   1
 LO bounds    x[3028]   0
 UP bounds    x[3028]   1
 LO bounds    x[3029]   0
 UP bounds    x[3029]   1
 LO bounds    x[3030]   0
 UP bounds    x[3030]   1
 LO bounds    x[3031]   0
 UP bounds    x[3031]   1
 LO bounds    x[3032]   0
 UP bounds    x[3032]   1
 LO bounds    x[3033]   0
 UP bounds    x[3033]   1
 LO bounds    x[3034]   0
 UP bounds    x[3034]   1
 LO bounds    x[3035]   0
 UP bounds    x[3035]   1
 LO bounds    x[3036]   0
 UP bounds    x[3036]   1
 LO bounds    x[3037]   0
 UP bounds    x[3037]   1
 LO bounds    x[3038]   0
 UP bounds    x[3038]   1
 LO bounds    x[3039]   0
 UP bounds    x[3039]   1
 LO bounds    x[3040]   0
 UP bounds    x[3040]   1
 LO bounds    x[3041]   0
 UP bounds    x[3041]   1
 LO bounds    x[3042]   0
 UP bounds    x[3042]   1
 LO bounds    x[3043]   0
 UP bounds    x[3043]   1
 LO bounds    x[3044]   0
 UP bounds    x[3044]   1
 LO bounds    x[3045]   0
 UP bounds    x[3045]   1
 LO bounds    x[3046]   0
 UP bounds    x[3046]   1
 LO bounds    x[3047]   0
 UP bounds    x[3047]   1
 LO bounds    x[3048]   0
 UP bounds    x[3048]   1
 LO bounds    x[3049]   0
 UP bounds    x[3049]   1
 LO bounds    x[3050]   0
 UP bounds    x[3050]   1
 LO bounds    x[3051]   0
 UP bounds    x[3051]   1
 LO bounds    x[3052]   0
 UP bounds    x[3052]   1
 LO bounds    x[3053]   0
 UP bounds    x[3053]   1
 LO bounds    x[3054]   0
 UP bounds    x[3054]   1
 LO bounds    x[3055]   0
 UP bounds    x[3055]   1
 LO bounds    x[3056]   0
 UP bounds    x[3056]   1
 LO bounds    x[3057]   0
 UP bounds    x[3057]   1
 LO bounds    x[3058]   0
 UP bounds    x[3058]   1
 LO bounds    x[3059]   0
 UP bounds    x[3059]   1
 LO bounds    x[3060]   0
 UP bounds    x[3060]   1
 LO bounds    x[3061]   0
 UP bounds    x[3061]   1
 LO bounds    x[3062]   0
 UP bounds    x[3062]   1
 LO bounds    x[3063]   0
 UP bounds    x[3063]   1
 LO bounds    x[3064]   0
 UP bounds    x[3064]   1
 LO bounds    x[3065]   0
 UP bounds    x[3065]   1
 LO bounds    x[3066]   0
 UP bounds    x[3066]   1
 LO bounds    x[3067]   0
 UP bounds    x[3067]   1
 LO bounds    x[3068]   0
 UP bounds    x[3068]   1
 LO bounds    x[3069]   0
 UP bounds    x[3069]   1
 LO bounds    x[3070]   0
 UP bounds    x[3070]   1
 LO bounds    x[3071]   0
 UP bounds    x[3071]   1
 LO bounds    x[3072]   0
 UP bounds    x[3072]   1
 LO bounds    x[3073]   0
 UP bounds    x[3073]   1
 LO bounds    x[3074]   0
 UP bounds    x[3074]   1
 LO bounds    x[3075]   0
 UP bounds    x[3075]   1
 LO bounds    x[3076]   0
 UP bounds    x[3076]   1
 LO bounds    x[3077]   0
 UP bounds    x[3077]   1
 LO bounds    x[3078]   0
 UP bounds    x[3078]   1
 LO bounds    x[3079]   0
 UP bounds    x[3079]   1
 LO bounds    x[3080]   0
 UP bounds    x[3080]   1
 LO bounds    x[3081]   0
 UP bounds    x[3081]   1
 LO bounds    x[3082]   0
 UP bounds    x[3082]   1
 LO bounds    x[3083]   0
 UP bounds    x[3083]   1
 LO bounds    x[3084]   0
 UP bounds    x[3084]   1
 LO bounds    x[3085]   0
 UP bounds    x[3085]   1
 LO bounds    x[3086]   0
 UP bounds    x[3086]   1
 LO bounds    x[3087]   0
 UP bounds    x[3087]   1
 LO bounds    x[3088]   0
 UP bounds    x[3088]   1
 LO bounds    x[3089]   0
 UP bounds    x[3089]   1
 LO bounds    x[3090]   0
 UP bounds    x[3090]   1
 LO bounds    x[3091]   0
 UP bounds    x[3091]   1
 LO bounds    x[3092]   0
 UP bounds    x[3092]   1
 LO bounds    x[3093]   0
 UP bounds    x[3093]   1
 LO bounds    x[3094]   0
 UP bounds    x[3094]   1
 LO bounds    x[3095]   0
 UP bounds    x[3095]   1
 LO bounds    x[3096]   0
 UP bounds    x[3096]   1
 LO bounds    x[3097]   0
 UP bounds    x[3097]   1
 LO bounds    x[3098]   0
 UP bounds    x[3098]   1
 LO bounds    x[3099]   0
 UP bounds    x[3099]   1
 LO bounds    x[3100]   0
 UP bounds    x[3100]   1
 LO bounds    x[3101]   0
 UP bounds    x[3101]   1
 LO bounds    x[3102]   0
 UP bounds    x[3102]   1
 LO bounds    x[3103]   0
 UP bounds    x[3103]   1
 LO bounds    x[3104]   0
 UP bounds    x[3104]   1
 LO bounds    x[3105]   0
 UP bounds    x[3105]   1
 LO bounds    x[3106]   0
 UP bounds    x[3106]   1
 LO bounds    x[3107]   0
 UP bounds    x[3107]   1
 LO bounds    x[3108]   0
 UP bounds    x[3108]   1
 LO bounds    x[3109]   0
 UP bounds    x[3109]   1
 LO bounds    x[3110]   0
 UP bounds    x[3110]   1
 LO bounds    x[3111]   0
 UP bounds    x[3111]   1
 LO bounds    x[3112]   0
 UP bounds    x[3112]   1
 LO bounds    x[3113]   0
 UP bounds    x[3113]   1
 LO bounds    x[3114]   0
 UP bounds    x[3114]   1
 LO bounds    x[3115]   0
 UP bounds    x[3115]   1
 LO bounds    x[3116]   0
 UP bounds    x[3116]   1
 LO bounds    x[3117]   0
 UP bounds    x[3117]   1
 LO bounds    x[3118]   0
 UP bounds    x[3118]   1
 LO bounds    x[3119]   0
 UP bounds    x[3119]   1
 LO bounds    x[3120]   0
 UP bounds    x[3120]   1
 LO bounds    x[3121]   0
 UP bounds    x[3121]   1
 LO bounds    x[3122]   0
 UP bounds    x[3122]   1
 LO bounds    x[3123]   0
 UP bounds    x[3123]   1
 LO bounds    x[3124]   0
 UP bounds    x[3124]   1
 LO bounds    x[3125]   0
 UP bounds    x[3125]   1
 LO bounds    x[3126]   0
 UP bounds    x[3126]   1
 LO bounds    x[3127]   0
 UP bounds    x[3127]   1
 LO bounds    x[3128]   0
 UP bounds    x[3128]   1
 LO bounds    x[3129]   0
 UP bounds    x[3129]   1
 LO bounds    x[3130]   0
 UP bounds    x[3130]   1
 LO bounds    x[3131]   0
 UP bounds    x[3131]   1
 LO bounds    x[3132]   0
 UP bounds    x[3132]   1
 LO bounds    x[3133]   0
 UP bounds    x[3133]   1
 LO bounds    x[3134]   0
 UP bounds    x[3134]   1
 LO bounds    x[3135]   0
 UP bounds    x[3135]   1
 LO bounds    x[3136]   0
 UP bounds    x[3136]   1
 LO bounds    x[3137]   0
 UP bounds    x[3137]   1
 LO bounds    x[3138]   0
 UP bounds    x[3138]   1
 LO bounds    x[3139]   0
 UP bounds    x[3139]   1
 LO bounds    x[3140]   0
 UP bounds    x[3140]   1
 LO bounds    x[3141]   0
 UP bounds    x[3141]   1
 LO bounds    x[3142]   0
 UP bounds    x[3142]   1
 LO bounds    x[3143]   0
 UP bounds    x[3143]   1
 LO bounds    x[3144]   0
 UP bounds    x[3144]   1
 LO bounds    x[3145]   0
 UP bounds    x[3145]   1
 LO bounds    x[3146]   0
 UP bounds    x[3146]   1
 LO bounds    x[3147]   0
 UP bounds    x[3147]   1
 LO bounds    x[3148]   0
 UP bounds    x[3148]   1
 LO bounds    x[3149]   0
 UP bounds    x[3149]   1
 LO bounds    x[3150]   0
 UP bounds    x[3150]   1
 LO bounds    x[3151]   0
 UP bounds    x[3151]   1
 LO bounds    x[3152]   0
 UP bounds    x[3152]   1
 LO bounds    x[3153]   0
 UP bounds    x[3153]   1
 LO bounds    x[3154]   0
 UP bounds    x[3154]   1
 LO bounds    x[3155]   0
 UP bounds    x[3155]   1
 LO bounds    x[3156]   0
 UP bounds    x[3156]   1
 LO bounds    x[3157]   0
 UP bounds    x[3157]   1
 LO bounds    x[3158]   0
 UP bounds    x[3158]   1
 LO bounds    x[3159]   0
 UP bounds    x[3159]   1
 LO bounds    x[3160]   0
 UP bounds    x[3160]   1
 LO bounds    x[3161]   0
 UP bounds    x[3161]   1
 LO bounds    x[3162]   0
 UP bounds    x[3162]   1
 LO bounds    x[3163]   0
 UP bounds    x[3163]   1
 LO bounds    x[3164]   0
 UP bounds    x[3164]   1
 LO bounds    x[3165]   0
 UP bounds    x[3165]   1
 LO bounds    x[3166]   0
 UP bounds    x[3166]   1
 LO bounds    x[3167]   0
 UP bounds    x[3167]   1
 LO bounds    x[3168]   0
 UP bounds    x[3168]   1
 LO bounds    x[3169]   0
 UP bounds    x[3169]   1
 LO bounds    x[3170]   0
 UP bounds    x[3170]   1
 LO bounds    x[3171]   0
 UP bounds    x[3171]   1
 LO bounds    x[3172]   0
 UP bounds    x[3172]   1
 LO bounds    x[3173]   0
 UP bounds    x[3173]   1
 LO bounds    x[3174]   0
 UP bounds    x[3174]   1
 LO bounds    x[3175]   0
 UP bounds    x[3175]   1
 LO bounds    x[3176]   0
 UP bounds    x[3176]   1
 LO bounds    x[3177]   0
 UP bounds    x[3177]   1
 LO bounds    x[3178]   0
 UP bounds    x[3178]   1
 LO bounds    x[3179]   0
 UP bounds    x[3179]   1
 LO bounds    x[3180]   0
 UP bounds    x[3180]   1
 LO bounds    x[3181]   0
 UP bounds    x[3181]   1
 LO bounds    x[3182]   0
 UP bounds    x[3182]   1
 LO bounds    x[3183]   0
 UP bounds    x[3183]   1
 LO bounds    x[3184]   0
 UP bounds    x[3184]   1
 LO bounds    x[3185]   0
 UP bounds    x[3185]   1
 LO bounds    x[3186]   0
 UP bounds    x[3186]   1
 LO bounds    x[3187]   0
 UP bounds    x[3187]   1
 LO bounds    x[3188]   0
 UP bounds    x[3188]   1
 LO bounds    x[3189]   0
 UP bounds    x[3189]   1
 LO bounds    x[3190]   0
 UP bounds    x[3190]   1
 LO bounds    x[3191]   0
 UP bounds    x[3191]   1
 LO bounds    x[3192]   0
 UP bounds    x[3192]   1
 LO bounds    x[3193]   0
 UP bounds    x[3193]   1
 LO bounds    x[3194]   0
 UP bounds    x[3194]   1
 LO bounds    x[3195]   0
 UP bounds    x[3195]   1
 LO bounds    x[3196]   0
 UP bounds    x[3196]   1
 LO bounds    x[3197]   0
 UP bounds    x[3197]   1
 LO bounds    x[3198]   0
 UP bounds    x[3198]   1
 LO bounds    x[3199]   0
 UP bounds    x[3199]   1
 LO bounds    x[3200]   0
 UP bounds    x[3200]   1
 LO bounds    x[3201]   0
 UP bounds    x[3201]   1
 LO bounds    x[3202]   0
 UP bounds    x[3202]   1
 LO bounds    x[3203]   0
 UP bounds    x[3203]   1
 LO bounds    x[3204]   0
 UP bounds    x[3204]   1
 LO bounds    x[3205]   0
 UP bounds    x[3205]   1
 LO bounds    x[3206]   0
 UP bounds    x[3206]   1
 LO bounds    x[3207]   0
 UP bounds    x[3207]   1
 LO bounds    x[3208]   0
 UP bounds    x[3208]   1
 LO bounds    x[3209]   0
 UP bounds    x[3209]   1
 LO bounds    x[3210]   0
 UP bounds    x[3210]   1
 LO bounds    x[3211]   0
 UP bounds    x[3211]   1
 LO bounds    x[3212]   0
 UP bounds    x[3212]   1
 LO bounds    x[3213]   0
 UP bounds    x[3213]   1
 LO bounds    x[3214]   0
 UP bounds    x[3214]   1
 LO bounds    x[3215]   0
 UP bounds    x[3215]   1
 LO bounds    x[3216]   0
 UP bounds    x[3216]   1
 LO bounds    x[3217]   0
 UP bounds    x[3217]   1
 LO bounds    x[3218]   0
 UP bounds    x[3218]   1
 LO bounds    x[3219]   0
 UP bounds    x[3219]   1
 LO bounds    x[3220]   0
 UP bounds    x[3220]   1
 LO bounds    x[3221]   0
 UP bounds    x[3221]   1
 LO bounds    x[3222]   0
 UP bounds    x[3222]   1
 LO bounds    x[3223]   0
 UP bounds    x[3223]   1
 LO bounds    x[3224]   0
 UP bounds    x[3224]   1
 LO bounds    x[3225]   0
 UP bounds    x[3225]   1
 LO bounds    x[3226]   0
 UP bounds    x[3226]   1
 LO bounds    x[3227]   0
 UP bounds    x[3227]   1
 LO bounds    x[3228]   0
 UP bounds    x[3228]   1
 LO bounds    x[3229]   0
 UP bounds    x[3229]   1
 LO bounds    x[3230]   0
 UP bounds    x[3230]   1
 LO bounds    x[3231]   0
 UP bounds    x[3231]   1
 LO bounds    x[3232]   0
 UP bounds    x[3232]   1
 LO bounds    x[3233]   0
 UP bounds    x[3233]   1
 LO bounds    x[3234]   0
 UP bounds    x[3234]   1
 LO bounds    x[3235]   0
 UP bounds    x[3235]   1
 LO bounds    x[3236]   0
 UP bounds    x[3236]   1
 LO bounds    x[3237]   0
 UP bounds    x[3237]   1
 LO bounds    x[3238]   0
 UP bounds    x[3238]   1
 LO bounds    x[3239]   0
 UP bounds    x[3239]   1
 LO bounds    x[3240]   0
 UP bounds    x[3240]   1
 LO bounds    x[3241]   0
 UP bounds    x[3241]   1
 LO bounds    x[3242]   0
 UP bounds    x[3242]   1
 LO bounds    x[3243]   0
 UP bounds    x[3243]   1
 LO bounds    x[3244]   0
 UP bounds    x[3244]   1
 LO bounds    x[3245]   0
 UP bounds    x[3245]   1
 LO bounds    x[3246]   0
 UP bounds    x[3246]   1
 LO bounds    x[3247]   0
 UP bounds    x[3247]   1
 LO bounds    x[3248]   0
 UP bounds    x[3248]   1
 LO bounds    x[3249]   0
 UP bounds    x[3249]   1
 LO bounds    x[3250]   0
 UP bounds    x[3250]   1
 LO bounds    x[3251]   0
 UP bounds    x[3251]   1
 LO bounds    x[3252]   0
 UP bounds    x[3252]   1
 LO bounds    x[3253]   0
 UP bounds    x[3253]   1
 LO bounds    x[3254]   0
 UP bounds    x[3254]   1
 LO bounds    x[3255]   0
 UP bounds    x[3255]   1
 LO bounds    x[3256]   0
 UP bounds    x[3256]   1
 LO bounds    x[3257]   0
 UP bounds    x[3257]   1
 LO bounds    x[3258]   0
 UP bounds    x[3258]   1
 LO bounds    x[3259]   0
 UP bounds    x[3259]   1
 LO bounds    x[3260]   0
 UP bounds    x[3260]   1
 LO bounds    x[3261]   0
 UP bounds    x[3261]   1
 LO bounds    x[3262]   0
 UP bounds    x[3262]   1
 LO bounds    x[3263]   0
 UP bounds    x[3263]   1
 LO bounds    x[3264]   0
 UP bounds    x[3264]   1
 LO bounds    x[3265]   0
 UP bounds    x[3265]   1
 LO bounds    x[3266]   0
 UP bounds    x[3266]   1
 LO bounds    x[3267]   0
 UP bounds    x[3267]   1
 LO bounds    x[3268]   0
 UP bounds    x[3268]   1
 LO bounds    x[3269]   0
 UP bounds    x[3269]   1
 LO bounds    x[3270]   0
 UP bounds    x[3270]   1
 LO bounds    x[3271]   0
 UP bounds    x[3271]   1
 LO bounds    x[3272]   0
 UP bounds    x[3272]   1
 LO bounds    x[3273]   0
 UP bounds    x[3273]   1
 LO bounds    x[3274]   0
 UP bounds    x[3274]   1
 LO bounds    x[3275]   0
 UP bounds    x[3275]   1
 LO bounds    x[3276]   0
 UP bounds    x[3276]   1
 LO bounds    x[3277]   0
 UP bounds    x[3277]   1
 LO bounds    x[3278]   0
 UP bounds    x[3278]   1
 LO bounds    x[3279]   0
 UP bounds    x[3279]   1
 LO bounds    x[3280]   0
 UP bounds    x[3280]   1
 LO bounds    x[3281]   0
 UP bounds    x[3281]   1
 LO bounds    x[3282]   0
 UP bounds    x[3282]   1
 LO bounds    x[3283]   0
 UP bounds    x[3283]   1
 LO bounds    x[3284]   0
 UP bounds    x[3284]   1
 LO bounds    x[3285]   0
 UP bounds    x[3285]   1
 LO bounds    x[3286]   0
 UP bounds    x[3286]   1
 LO bounds    x[3287]   0
 UP bounds    x[3287]   1
 LO bounds    x[3288]   0
 UP bounds    x[3288]   1
 LO bounds    x[3289]   0
 UP bounds    x[3289]   1
 LO bounds    x[3290]   0
 UP bounds    x[3290]   1
 LO bounds    x[3291]   0
 UP bounds    x[3291]   1
 LO bounds    x[3292]   0
 UP bounds    x[3292]   1
 LO bounds    x[3293]   0
 UP bounds    x[3293]   1
 LO bounds    x[3294]   0
 UP bounds    x[3294]   1
 LO bounds    x[3295]   0
 UP bounds    x[3295]   1
 LO bounds    x[3296]   0
 UP bounds    x[3296]   1
 LO bounds    x[3297]   0
 UP bounds    x[3297]   1
 LO bounds    x[3298]   0
 UP bounds    x[3298]   1
 LO bounds    x[3299]   0
 UP bounds    x[3299]   1
 LO bounds    x[3300]   0
 UP bounds    x[3300]   1
 LO bounds    x[3301]   0
 UP bounds    x[3301]   1
 LO bounds    x[3302]   0
 UP bounds    x[3302]   1
 LO bounds    x[3303]   0
 UP bounds    x[3303]   1
 LO bounds    x[3304]   0
 UP bounds    x[3304]   1
 LO bounds    x[3305]   0
 UP bounds    x[3305]   1
 LO bounds    x[3306]   0
 UP bounds    x[3306]   1
 LO bounds    x[3307]   0
 UP bounds    x[3307]   1
 LO bounds    x[3308]   0
 UP bounds    x[3308]   1
 LO bounds    x[3309]   0
 UP bounds    x[3309]   1
 LO bounds    x[3310]   0
 UP bounds    x[3310]   1
 LO bounds    x[3311]   0
 UP bounds    x[3311]   1
 LO bounds    x[3312]   0
 UP bounds    x[3312]   1
 LO bounds    x[3313]   0
 UP bounds    x[3313]   1
 LO bounds    x[3314]   0
 UP bounds    x[3314]   1
 LO bounds    x[3315]   0
 UP bounds    x[3315]   1
 LO bounds    x[3316]   0
 UP bounds    x[3316]   1
 LO bounds    x[3317]   0
 UP bounds    x[3317]   1
 LO bounds    x[3318]   0
 UP bounds    x[3318]   1
 LO bounds    x[3319]   0
 UP bounds    x[3319]   1
 LO bounds    x[3320]   0
 UP bounds    x[3320]   1
 LO bounds    x[3321]   0
 UP bounds    x[3321]   1
 LO bounds    x[3322]   0
 UP bounds    x[3322]   1
 LO bounds    x[3323]   0
 UP bounds    x[3323]   1
 LO bounds    x[3324]   0
 UP bounds    x[3324]   1
 LO bounds    x[3325]   0
 UP bounds    x[3325]   1
 LO bounds    x[3326]   0
 UP bounds    x[3326]   1
 LO bounds    x[3327]   0
 UP bounds    x[3327]   1
 LO bounds    x[3328]   0
 UP bounds    x[3328]   1
 LO bounds    x[3329]   0
 UP bounds    x[3329]   1
 LO bounds    x[3330]   0
 UP bounds    x[3330]   1
 LO bounds    x[3331]   0
 UP bounds    x[3331]   1
 LO bounds    x[3332]   0
 UP bounds    x[3332]   1
 LO bounds    x[3333]   0
 UP bounds    x[3333]   1
 LO bounds    x[3334]   0
 UP bounds    x[3334]   1
 LO bounds    x[3335]   0
 UP bounds    x[3335]   1
 LO bounds    x[3336]   0
 UP bounds    x[3336]   1
 LO bounds    x[3337]   0
 UP bounds    x[3337]   1
 LO bounds    x[3338]   0
 UP bounds    x[3338]   1
 LO bounds    x[3339]   0
 UP bounds    x[3339]   1
 LO bounds    x[3340]   0
 UP bounds    x[3340]   1
 LO bounds    x[3341]   0
 UP bounds    x[3341]   1
 LO bounds    x[3342]   0
 UP bounds    x[3342]   1
 LO bounds    x[3343]   0
 UP bounds    x[3343]   1
 LO bounds    x[3344]   0
 UP bounds    x[3344]   1
 LO bounds    x[3345]   0
 UP bounds    x[3345]   1
 LO bounds    x[3346]   0
 UP bounds    x[3346]   1
 LO bounds    x[3347]   0
 UP bounds    x[3347]   1
 LO bounds    x[3348]   0
 UP bounds    x[3348]   1
 LO bounds    x[3349]   0
 UP bounds    x[3349]   1
 LO bounds    x[3350]   0
 UP bounds    x[3350]   1
 LO bounds    x[3351]   0
 UP bounds    x[3351]   1
 LO bounds    x[3352]   0
 UP bounds    x[3352]   1
 LO bounds    x[3353]   0
 UP bounds    x[3353]   1
 LO bounds    x[3354]   0
 UP bounds    x[3354]   1
 LO bounds    x[3355]   0
 UP bounds    x[3355]   1
 LO bounds    x[3356]   0
 UP bounds    x[3356]   1
 LO bounds    x[3357]   0
 UP bounds    x[3357]   1
 LO bounds    x[3358]   0
 UP bounds    x[3358]   1
 LO bounds    x[3359]   0
 UP bounds    x[3359]   1
 LO bounds    x[3360]   0
 UP bounds    x[3360]   1
 LO bounds    x[3361]   0
 UP bounds    x[3361]   1
 LO bounds    x[3362]   0
 UP bounds    x[3362]   1
 LO bounds    x[3363]   0
 UP bounds    x[3363]   1
 LO bounds    x[3364]   0
 UP bounds    x[3364]   1
 LO bounds    x[3365]   0
 UP bounds    x[3365]   1
 LO bounds    x[3366]   0
 UP bounds    x[3366]   1
 LO bounds    x[3367]   0
 UP bounds    x[3367]   1
 LO bounds    x[3368]   0
 UP bounds    x[3368]   1
 LO bounds    x[3369]   0
 UP bounds    x[3369]   1
 LO bounds    x[3370]   0
 UP bounds    x[3370]   1
 LO bounds    x[3371]   0
 UP bounds    x[3371]   1
 LO bounds    x[3372]   0
 UP bounds    x[3372]   1
 LO bounds    x[3373]   0
 UP bounds    x[3373]   1
 LO bounds    x[3374]   0
 UP bounds    x[3374]   1
 LO bounds    x[3375]   0
 UP bounds    x[3375]   1
 LO bounds    x[3376]   0
 UP bounds    x[3376]   1
 LO bounds    x[3377]   0
 UP bounds    x[3377]   1
 LO bounds    x[3378]   0
 UP bounds    x[3378]   1
 LO bounds    x[3379]   0
 UP bounds    x[3379]   1
 LO bounds    x[3380]   0
 UP bounds    x[3380]   1
 LO bounds    x[3381]   0
 UP bounds    x[3381]   1
 LO bounds    x[3382]   0
 UP bounds    x[3382]   1
 LO bounds    x[3383]   0
 UP bounds    x[3383]   1
 LO bounds    x[3384]   0
 UP bounds    x[3384]   1
 LO bounds    x[3385]   0
 UP bounds    x[3385]   1
 LO bounds    x[3386]   0
 UP bounds    x[3386]   1
 LO bounds    x[3387]   0
 UP bounds    x[3387]   1
 LO bounds    x[3388]   0
 UP bounds    x[3388]   1
 LO bounds    x[3389]   0
 UP bounds    x[3389]   1
 LO bounds    x[3390]   0
 UP bounds    x[3390]   1
 LO bounds    x[3391]   0
 UP bounds    x[3391]   1
 LO bounds    x[3392]   0
 UP bounds    x[3392]   1
 LO bounds    x[3393]   0
 UP bounds    x[3393]   1
 LO bounds    x[3394]   0
 UP bounds    x[3394]   1
 LO bounds    x[3395]   0
 UP bounds    x[3395]   1
 LO bounds    x[3396]   0
 UP bounds    x[3396]   1
 LO bounds    x[3397]   0
 UP bounds    x[3397]   1
 LO bounds    x[3398]   0
 UP bounds    x[3398]   1
 LO bounds    x[3399]   0
 UP bounds    x[3399]   1
 LO bounds    x[3400]   0
 UP bounds    x[3400]   1
 LO bounds    x[3401]   0
 UP bounds    x[3401]   1
 LO bounds    x[3402]   0
 UP bounds    x[3402]   1
 LO bounds    x[3403]   0
 UP bounds    x[3403]   1
 LO bounds    x[3404]   0
 UP bounds    x[3404]   1
 LO bounds    x[3405]   0
 UP bounds    x[3405]   1
 LO bounds    x[3406]   0
 UP bounds    x[3406]   1
 LO bounds    x[3407]   0
 UP bounds    x[3407]   1
 LO bounds    x[3408]   0
 UP bounds    x[3408]   1
 LO bounds    x[3409]   0
 UP bounds    x[3409]   1
 LO bounds    x[3410]   0
 UP bounds    x[3410]   1
 LO bounds    x[3411]   0
 UP bounds    x[3411]   1
 LO bounds    x[3412]   0
 UP bounds    x[3412]   1
 LO bounds    x[3413]   0
 UP bounds    x[3413]   1
 LO bounds    x[3414]   0
 UP bounds    x[3414]   1
 LO bounds    x[3415]   0
 UP bounds    x[3415]   1
 LO bounds    x[3416]   0
 UP bounds    x[3416]   1
 LO bounds    x[3417]   0
 UP bounds    x[3417]   1
 LO bounds    x[3418]   0
 UP bounds    x[3418]   1
 LO bounds    x[3419]   0
 UP bounds    x[3419]   1
 LO bounds    x[3420]   0
 UP bounds    x[3420]   1
 LO bounds    x[3421]   0
 UP bounds    x[3421]   1
 LO bounds    x[3422]   0
 UP bounds    x[3422]   1
 LO bounds    x[3423]   0
 UP bounds    x[3423]   1
 LO bounds    x[3424]   0
 UP bounds    x[3424]   1
 LO bounds    x[3425]   0
 UP bounds    x[3425]   1
 LO bounds    x[3426]   0
 UP bounds    x[3426]   1
 LO bounds    x[3427]   0
 UP bounds    x[3427]   1
 LO bounds    x[3428]   0
 UP bounds    x[3428]   1
 LO bounds    x[3429]   0
 UP bounds    x[3429]   1
 LO bounds    x[3430]   0
 UP bounds    x[3430]   1
 LO bounds    x[3431]   0
 UP bounds    x[3431]   1
 LO bounds    x[3432]   0
 UP bounds    x[3432]   1
 LO bounds    x[3433]   0
 UP bounds    x[3433]   1
 LO bounds    x[3434]   0
 UP bounds    x[3434]   1
 LO bounds    x[3435]   0
 UP bounds    x[3435]   1
 LO bounds    x[3436]   0
 UP bounds    x[3436]   1
 LO bounds    x[3437]   0
 UP bounds    x[3437]   1
 LO bounds    x[3438]   0
 UP bounds    x[3438]   1
 LO bounds    x[3439]   0
 UP bounds    x[3439]   1
 LO bounds    x[3440]   0
 UP bounds    x[3440]   1
 LO bounds    x[3441]   0
 UP bounds    x[3441]   1
 LO bounds    x[3442]   0
 UP bounds    x[3442]   1
 LO bounds    x[3443]   0
 UP bounds    x[3443]   1
 LO bounds    x[3444]   0
 UP bounds    x[3444]   1
 LO bounds    x[3445]   0
 UP bounds    x[3445]   1
 LO bounds    x[3446]   0
 UP bounds    x[3446]   1
 LO bounds    x[3447]   0
 UP bounds    x[3447]   1
 LO bounds    x[3448]   0
 UP bounds    x[3448]   1
 LO bounds    x[3449]   0
 UP bounds    x[3449]   1
 LO bounds    x[3450]   0
 UP bounds    x[3450]   1
 LO bounds    x[3451]   0
 UP bounds    x[3451]   1
 LO bounds    x[3452]   0
 UP bounds    x[3452]   1
 LO bounds    x[3453]   0
 UP bounds    x[3453]   1
 LO bounds    x[3454]   0
 UP bounds    x[3454]   1
 LO bounds    x[3455]   0
 UP bounds    x[3455]   1
 LO bounds    x[3456]   0
 UP bounds    x[3456]   1
 LO bounds    x[3457]   0
 UP bounds    x[3457]   1
 LO bounds    x[3458]   0
 UP bounds    x[3458]   1
 LO bounds    x[3459]   0
 UP bounds    x[3459]   1
 LO bounds    x[3460]   0
 UP bounds    x[3460]   1
 LO bounds    x[3461]   0
 UP bounds    x[3461]   1
 LO bounds    x[3462]   0
 UP bounds    x[3462]   1
 LO bounds    x[3463]   0
 UP bounds    x[3463]   1
 LO bounds    x[3464]   0
 UP bounds    x[3464]   1
 LO bounds    x[3465]   0
 UP bounds    x[3465]   1
 LO bounds    x[3466]   0
 UP bounds    x[3466]   1
 LO bounds    x[3467]   0
 UP bounds    x[3467]   1
 LO bounds    x[3468]   0
 UP bounds    x[3468]   1
 LO bounds    x[3469]   0
 UP bounds    x[3469]   1
 LO bounds    x[3470]   0
 UP bounds    x[3470]   1
 LO bounds    x[3471]   0
 UP bounds    x[3471]   1
 LO bounds    x[3472]   0
 UP bounds    x[3472]   1
 LO bounds    x[3473]   0
 UP bounds    x[3473]   1
 LO bounds    x[3474]   0
 UP bounds    x[3474]   1
 LO bounds    x[3475]   0
 UP bounds    x[3475]   1
 LO bounds    x[3476]   0
 UP bounds    x[3476]   1
 LO bounds    x[3477]   0
 UP bounds    x[3477]   1
 LO bounds    x[3478]   0
 UP bounds    x[3478]   1
 LO bounds    x[3479]   0
 UP bounds    x[3479]   1
 LO bounds    x[3480]   0
 UP bounds    x[3480]   1
 LO bounds    x[3481]   0
 UP bounds    x[3481]   1
 LO bounds    x[3482]   0
 UP bounds    x[3482]   1
 LO bounds    x[3483]   0
 UP bounds    x[3483]   1
 LO bounds    x[3484]   0
 UP bounds    x[3484]   1
 LO bounds    x[3485]   0
 UP bounds    x[3485]   1
 LO bounds    x[3486]   0
 UP bounds    x[3486]   1
 LO bounds    x[3487]   0
 UP bounds    x[3487]   1
 LO bounds    x[3488]   0
 UP bounds    x[3488]   1
 LO bounds    x[3489]   0
 UP bounds    x[3489]   1
 LO bounds    x[3490]   0
 UP bounds    x[3490]   1
 LO bounds    x[3491]   0
 UP bounds    x[3491]   1
 LO bounds    x[3492]   0
 UP bounds    x[3492]   1
 LO bounds    x[3493]   0
 UP bounds    x[3493]   1
 LO bounds    x[3494]   0
 UP bounds    x[3494]   1
 LO bounds    x[3495]   0
 UP bounds    x[3495]   1
 LO bounds    x[3496]   0
 UP bounds    x[3496]   1
 LO bounds    x[3497]   0
 UP bounds    x[3497]   1
 LO bounds    x[3498]   0
 UP bounds    x[3498]   1
 LO bounds    x[3499]   0
 UP bounds    x[3499]   1
 LO bounds    x[3500]   0
 UP bounds    x[3500]   1
 LO bounds    x[3501]   0
 UP bounds    x[3501]   1
 LO bounds    x[3502]   0
 UP bounds    x[3502]   1
 LO bounds    x[3503]   0
 UP bounds    x[3503]   1
 LO bounds    x[3504]   0
 UP bounds    x[3504]   1
 LO bounds    x[3505]   0
 UP bounds    x[3505]   1
 LO bounds    x[3506]   0
 UP bounds    x[3506]   1
 LO bounds    x[3507]   0
 UP bounds    x[3507]   1
 LO bounds    x[3508]   0
 UP bounds    x[3508]   1
 LO bounds    x[3509]   0
 UP bounds    x[3509]   1
 LO bounds    x[3510]   0
 UP bounds    x[3510]   1
 LO bounds    x[3511]   0
 UP bounds    x[3511]   1
 LO bounds    x[3512]   0
 UP bounds    x[3512]   1
 LO bounds    x[3513]   0
 UP bounds    x[3513]   1
 LO bounds    x[3514]   0
 UP bounds    x[3514]   1
 LO bounds    x[3515]   0
 UP bounds    x[3515]   1
 LO bounds    x[3516]   0
 UP bounds    x[3516]   1
 LO bounds    x[3517]   0
 UP bounds    x[3517]   1
 LO bounds    x[3518]   0
 UP bounds    x[3518]   1
 LO bounds    x[3519]   0
 UP bounds    x[3519]   1
 LO bounds    x[3520]   0
 UP bounds    x[3520]   1
 LO bounds    x[3521]   0
 UP bounds    x[3521]   1
 LO bounds    x[3522]   0
 UP bounds    x[3522]   1
 LO bounds    x[3523]   0
 UP bounds    x[3523]   1
 LO bounds    x[3524]   0
 UP bounds    x[3524]   1
 LO bounds    x[3525]   0
 UP bounds    x[3525]   1
 LO bounds    x[3526]   0
 UP bounds    x[3526]   1
 LO bounds    x[3527]   0
 UP bounds    x[3527]   1
 LO bounds    x[3528]   0
 UP bounds    x[3528]   1
 LO bounds    x[3529]   0
 UP bounds    x[3529]   1
 LO bounds    x[3530]   0
 UP bounds    x[3530]   1
 LO bounds    x[3531]   0
 UP bounds    x[3531]   1
 LO bounds    x[3532]   0
 UP bounds    x[3532]   1
 LO bounds    x[3533]   0
 UP bounds    x[3533]   1
 LO bounds    x[3534]   0
 UP bounds    x[3534]   1
 LO bounds    x[3535]   0
 UP bounds    x[3535]   1
 LO bounds    x[3536]   0
 UP bounds    x[3536]   1
 LO bounds    x[3537]   0
 UP bounds    x[3537]   1
 LO bounds    x[3538]   0
 UP bounds    x[3538]   1
 LO bounds    x[3539]   0
 UP bounds    x[3539]   1
 LO bounds    x[3540]   0
 UP bounds    x[3540]   1
 LO bounds    x[3541]   0
 UP bounds    x[3541]   1
 LO bounds    x[3542]   0
 UP bounds    x[3542]   1
 LO bounds    x[3543]   0
 UP bounds    x[3543]   1
 LO bounds    x[3544]   0
 UP bounds    x[3544]   1
 LO bounds    x[3545]   0
 UP bounds    x[3545]   1
 LO bounds    x[3546]   0
 UP bounds    x[3546]   1
 LO bounds    x[3547]   0
 UP bounds    x[3547]   1
 LO bounds    x[3548]   0
 UP bounds    x[3548]   1
 LO bounds    x[3549]   0
 UP bounds    x[3549]   1
 LO bounds    x[3550]   0
 UP bounds    x[3550]   1
 LO bounds    x[3551]   0
 UP bounds    x[3551]   1
 LO bounds    x[3552]   0
 UP bounds    x[3552]   1
 LO bounds    x[3553]   0
 UP bounds    x[3553]   1
 LO bounds    x[3554]   0
 UP bounds    x[3554]   1
 LO bounds    x[3555]   0
 UP bounds    x[3555]   1
 LO bounds    x[3556]   0
 UP bounds    x[3556]   1
 LO bounds    x[3557]   0
 UP bounds    x[3557]   1
 LO bounds    x[3558]   0
 UP bounds    x[3558]   1
 LO bounds    x[3559]   0
 UP bounds    x[3559]   1
 LO bounds    x[3560]   0
 UP bounds    x[3560]   1
 LO bounds    x[3561]   0
 UP bounds    x[3561]   1
 LO bounds    x[3562]   0
 UP bounds    x[3562]   1
 LO bounds    x[3563]   0
 UP bounds    x[3563]   1
 LO bounds    x[3564]   0
 UP bounds    x[3564]   1
 LO bounds    x[3565]   0
 UP bounds    x[3565]   1
 LO bounds    x[3566]   0
 UP bounds    x[3566]   1
 LO bounds    x[3567]   0
 UP bounds    x[3567]   1
 LO bounds    x[3568]   0
 UP bounds    x[3568]   1
 LO bounds    x[3569]   0
 UP bounds    x[3569]   1
 LO bounds    x[3570]   0
 UP bounds    x[3570]   1
 LO bounds    x[3571]   0
 UP bounds    x[3571]   1
 LO bounds    x[3572]   0
 UP bounds    x[3572]   1
 LO bounds    x[3573]   0
 UP bounds    x[3573]   1
 LO bounds    x[3574]   0
 UP bounds    x[3574]   1
 LO bounds    x[3575]   0
 UP bounds    x[3575]   1
 LO bounds    x[3576]   0
 UP bounds    x[3576]   1
 LO bounds    x[3577]   0
 UP bounds    x[3577]   1
 LO bounds    x[3578]   0
 UP bounds    x[3578]   1
 LO bounds    x[3579]   0
 UP bounds    x[3579]   1
 LO bounds    x[3580]   0
 UP bounds    x[3580]   1
 LO bounds    x[3581]   0
 UP bounds    x[3581]   1
 LO bounds    x[3582]   0
 UP bounds    x[3582]   1
 LO bounds    x[3583]   0
 UP bounds    x[3583]   1
 LO bounds    x[3584]   0
 UP bounds    x[3584]   1
 LO bounds    x[3585]   0
 UP bounds    x[3585]   1
 LO bounds    x[3586]   0
 UP bounds    x[3586]   1
 LO bounds    x[3587]   0
 UP bounds    x[3587]   1
 LO bounds    x[3588]   0
 UP bounds    x[3588]   1
 LO bounds    x[3589]   0
 UP bounds    x[3589]   1
 LO bounds    x[3590]   0
 UP bounds    x[3590]   1
 LO bounds    x[3591]   0
 UP bounds    x[3591]   1
 LO bounds    x[3592]   0
 UP bounds    x[3592]   1
 LO bounds    x[3593]   0
 UP bounds    x[3593]   1
 LO bounds    x[3594]   0
 UP bounds    x[3594]   1
 LO bounds    x[3595]   0
 UP bounds    x[3595]   1
 LO bounds    x[3596]   0
 UP bounds    x[3596]   1
 LO bounds    x[3597]   0
 UP bounds    x[3597]   1
 LO bounds    x[3598]   0
 UP bounds    x[3598]   1
 LO bounds    x[3599]   0
 UP bounds    x[3599]   1
 LO bounds    x[3600]   0
 UP bounds    x[3600]   1
 LO bounds    x[3601]   0
 UP bounds    x[3601]   1
 LO bounds    x[3602]   0
 UP bounds    x[3602]   1
 LO bounds    x[3603]   0
 UP bounds    x[3603]   1
 LO bounds    x[3604]   0
 UP bounds    x[3604]   1
 LO bounds    x[3605]   0
 UP bounds    x[3605]   1
 LO bounds    x[3606]   0
 UP bounds    x[3606]   1
 LO bounds    x[3607]   0
 UP bounds    x[3607]   1
 LO bounds    x[3608]   0
 UP bounds    x[3608]   1
 LO bounds    x[3609]   0
 UP bounds    x[3609]   1
 LO bounds    x[3610]   0
 UP bounds    x[3610]   1
 LO bounds    x[3611]   0
 UP bounds    x[3611]   1
 LO bounds    x[3612]   0
 UP bounds    x[3612]   1
 LO bounds    x[3613]   0
 UP bounds    x[3613]   1
 LO bounds    x[3614]   0
 UP bounds    x[3614]   1
 LO bounds    x[3615]   0
 UP bounds    x[3615]   1
 LO bounds    x[3616]   0
 UP bounds    x[3616]   1
 LO bounds    x[3617]   0
 UP bounds    x[3617]   1
 LO bounds    x[3618]   0
 UP bounds    x[3618]   1
 LO bounds    x[3619]   0
 UP bounds    x[3619]   1
 LO bounds    x[3620]   0
 UP bounds    x[3620]   1
 LO bounds    x[3621]   0
 UP bounds    x[3621]   1
 LO bounds    x[3622]   0
 UP bounds    x[3622]   1
 LO bounds    x[3623]   0
 UP bounds    x[3623]   1
 LO bounds    x[3624]   0
 UP bounds    x[3624]   1
 LO bounds    x[3625]   0
 UP bounds    x[3625]   1
 LO bounds    x[3626]   0
 UP bounds    x[3626]   1
 LO bounds    x[3627]   0
 UP bounds    x[3627]   1
 LO bounds    x[3628]   0
 UP bounds    x[3628]   1
 LO bounds    x[3629]   0
 UP bounds    x[3629]   1
 LO bounds    x[3630]   0
 UP bounds    x[3630]   1
 LO bounds    x[3631]   0
 UP bounds    x[3631]   1
 LO bounds    x[3632]   0
 UP bounds    x[3632]   1
 LO bounds    x[3633]   0
 UP bounds    x[3633]   1
 LO bounds    x[3634]   0
 UP bounds    x[3634]   1
 LO bounds    x[3635]   0
 UP bounds    x[3635]   1
 LO bounds    x[3636]   0
 UP bounds    x[3636]   1
 LO bounds    x[3637]   0
 UP bounds    x[3637]   1
 LO bounds    x[3638]   0
 UP bounds    x[3638]   1
 LO bounds    x[3639]   0
 UP bounds    x[3639]   1
 LO bounds    x[3640]   0
 UP bounds    x[3640]   1
 LO bounds    x[3641]   0
 UP bounds    x[3641]   1
 LO bounds    x[3642]   0
 UP bounds    x[3642]   1
 LO bounds    x[3643]   0
 UP bounds    x[3643]   1
 LO bounds    x[3644]   0
 UP bounds    x[3644]   1
 LO bounds    x[3645]   0
 UP bounds    x[3645]   1
 LO bounds    x[3646]   0
 UP bounds    x[3646]   1
 LO bounds    x[3647]   0
 UP bounds    x[3647]   1
 LO bounds    x[3648]   0
 UP bounds    x[3648]   1
 LO bounds    x[3649]   0
 UP bounds    x[3649]   1
 LO bounds    x[3650]   0
 UP bounds    x[3650]   1
 LO bounds    x[3651]   0
 UP bounds    x[3651]   1
 LO bounds    x[3652]   0
 UP bounds    x[3652]   1
 LO bounds    x[3653]   0
 UP bounds    x[3653]   1
 LO bounds    x[3654]   0
 UP bounds    x[3654]   1
 LO bounds    x[3655]   0
 UP bounds    x[3655]   1
 LO bounds    x[3656]   0
 UP bounds    x[3656]   1
 LO bounds    x[3657]   0
 UP bounds    x[3657]   1
 LO bounds    x[3658]   0
 UP bounds    x[3658]   1
 LO bounds    x[3659]   0
 UP bounds    x[3659]   1
 LO bounds    x[3660]   0
 UP bounds    x[3660]   1
 LO bounds    x[3661]   0
 UP bounds    x[3661]   1
 LO bounds    x[3662]   0
 UP bounds    x[3662]   1
 LO bounds    x[3663]   0
 UP bounds    x[3663]   1
 LO bounds    x[3664]   0
 UP bounds    x[3664]   1
 LO bounds    x[3665]   0
 UP bounds    x[3665]   1
 LO bounds    x[3666]   0
 UP bounds    x[3666]   1
 LO bounds    x[3667]   0
 UP bounds    x[3667]   1
 LO bounds    x[3668]   0
 UP bounds    x[3668]   1
 LO bounds    x[3669]   0
 UP bounds    x[3669]   1
 LO bounds    x[3670]   0
 UP bounds    x[3670]   1
 LO bounds    x[3671]   0
 UP bounds    x[3671]   1
 LO bounds    x[3672]   0
 UP bounds    x[3672]   1
 LO bounds    x[3673]   0
 UP bounds    x[3673]   1
 LO bounds    x[3674]   0
 UP bounds    x[3674]   1
 LO bounds    x[3675]   0
 UP bounds    x[3675]   1
 LO bounds    x[3676]   0
 UP bounds    x[3676]   1
 LO bounds    x[3677]   0
 UP bounds    x[3677]   1
 LO bounds    x[3678]   0
 UP bounds    x[3678]   1
 LO bounds    x[3679]   0
 UP bounds    x[3679]   1
 LO bounds    x[3680]   0
 UP bounds    x[3680]   1
 LO bounds    x[3681]   0
 UP bounds    x[3681]   1
 LO bounds    x[3682]   0
 UP bounds    x[3682]   1
 LO bounds    x[3683]   0
 UP bounds    x[3683]   1
 LO bounds    x[3684]   0
 UP bounds    x[3684]   1
 LO bounds    x[3685]   0
 UP bounds    x[3685]   1
 LO bounds    x[3686]   0
 UP bounds    x[3686]   1
 LO bounds    x[3687]   0
 UP bounds    x[3687]   1
 LO bounds    x[3688]   0
 UP bounds    x[3688]   1
 LO bounds    x[3689]   0
 UP bounds    x[3689]   1
 LO bounds    x[3690]   0
 UP bounds    x[3690]   1
 LO bounds    x[3691]   0
 UP bounds    x[3691]   1
 LO bounds    x[3692]   0
 UP bounds    x[3692]   1
 LO bounds    x[3693]   0
 UP bounds    x[3693]   1
 LO bounds    x[3694]   0
 UP bounds    x[3694]   1
 LO bounds    x[3695]   0
 UP bounds    x[3695]   1
 LO bounds    x[3696]   0
 UP bounds    x[3696]   1
 LO bounds    x[3697]   0
 UP bounds    x[3697]   1
 LO bounds    x[3698]   0
 UP bounds    x[3698]   1
 LO bounds    x[3699]   0
 UP bounds    x[3699]   1
 LO bounds    x[3700]   0
 UP bounds    x[3700]   1
 LO bounds    x[3701]   0
 UP bounds    x[3701]   1
 LO bounds    x[3702]   0
 UP bounds    x[3702]   1
 LO bounds    x[3703]   0
 UP bounds    x[3703]   1
 LO bounds    x[3704]   0
 UP bounds    x[3704]   1
 LO bounds    x[3705]   0
 UP bounds    x[3705]   1
 LO bounds    x[3706]   0
 UP bounds    x[3706]   1
 LO bounds    x[3707]   0
 UP bounds    x[3707]   1
 LO bounds    x[3708]   0
 UP bounds    x[3708]   1
 LO bounds    x[3709]   0
 UP bounds    x[3709]   1
 LO bounds    x[3710]   0
 UP bounds    x[3710]   1
 LO bounds    x[3711]   0
 UP bounds    x[3711]   1
 LO bounds    x[3712]   0
 UP bounds    x[3712]   1
 LO bounds    x[3713]   0
 UP bounds    x[3713]   1
 LO bounds    x[3714]   0
 UP bounds    x[3714]   1
 LO bounds    x[3715]   0
 UP bounds    x[3715]   1
 LO bounds    x[3716]   0
 UP bounds    x[3716]   1
 LO bounds    x[3717]   0
 UP bounds    x[3717]   1
 LO bounds    x[3718]   0
 UP bounds    x[3718]   1
 LO bounds    x[3719]   0
 UP bounds    x[3719]   1
 LO bounds    x[3720]   0
 UP bounds    x[3720]   1
 LO bounds    x[3721]   0
 UP bounds    x[3721]   1
 LO bounds    x[3722]   0
 UP bounds    x[3722]   1
 LO bounds    x[3723]   0
 UP bounds    x[3723]   1
 LO bounds    x[3724]   0
 UP bounds    x[3724]   1
 LO bounds    x[3725]   0
 UP bounds    x[3725]   1
 LO bounds    x[3726]   0
 UP bounds    x[3726]   1
 LO bounds    x[3727]   0
 UP bounds    x[3727]   1
 LO bounds    x[3728]   0
 UP bounds    x[3728]   1
 LO bounds    x[3729]   0
 UP bounds    x[3729]   1
 LO bounds    x[3730]   0
 UP bounds    x[3730]   1
 LO bounds    x[3731]   0
 UP bounds    x[3731]   1
 LO bounds    x[3732]   0
 UP bounds    x[3732]   1
 LO bounds    x[3733]   0
 UP bounds    x[3733]   1
 LO bounds    x[3734]   0
 UP bounds    x[3734]   1
 LO bounds    x[3735]   0
 UP bounds    x[3735]   1
 LO bounds    x[3736]   0
 UP bounds    x[3736]   1
 LO bounds    x[3737]   0
 UP bounds    x[3737]   1
 LO bounds    x[3738]   0
 UP bounds    x[3738]   1
 LO bounds    x[3739]   0
 UP bounds    x[3739]   1
 LO bounds    x[3740]   0
 UP bounds    x[3740]   1
 LO bounds    x[3741]   0
 UP bounds    x[3741]   1
 LO bounds    x[3742]   0
 UP bounds    x[3742]   1
 LO bounds    x[3743]   0
 UP bounds    x[3743]   1
 LO bounds    x[3744]   0
 UP bounds    x[3744]   1
 LO bounds    x[3745]   0
 UP bounds    x[3745]   1
 LO bounds    x[3746]   0
 UP bounds    x[3746]   1
 LO bounds    x[3747]   0
 UP bounds    x[3747]   1
 LO bounds    x[3748]   0
 UP bounds    x[3748]   1
 LO bounds    x[3749]   0
 UP bounds    x[3749]   1
 LO bounds    x[3750]   0
 UP bounds    x[3750]   1
 LO bounds    x[3751]   0
 UP bounds    x[3751]   1
 LO bounds    x[3752]   0
 UP bounds    x[3752]   1
 LO bounds    x[3753]   0
 UP bounds    x[3753]   1
 LO bounds    x[3754]   0
 UP bounds    x[3754]   1
 LO bounds    x[3755]   0
 UP bounds    x[3755]   1
 LO bounds    x[3756]   0
 UP bounds    x[3756]   1
 LO bounds    x[3757]   0
 UP bounds    x[3757]   1
 LO bounds    x[3758]   0
 UP bounds    x[3758]   1
 LO bounds    x[3759]   0
 UP bounds    x[3759]   1
 LO bounds    x[3760]   0
 UP bounds    x[3760]   1
 LO bounds    x[3761]   0
 UP bounds    x[3761]   1
 LO bounds    x[3762]   0
 UP bounds    x[3762]   1
 LO bounds    x[3763]   0
 UP bounds    x[3763]   1
 LO bounds    x[3764]   0
 UP bounds    x[3764]   1
 LO bounds    x[3765]   0
 UP bounds    x[3765]   1
 LO bounds    x[3766]   0
 UP bounds    x[3766]   1
 LO bounds    x[3767]   0
 UP bounds    x[3767]   1
 LO bounds    x[3768]   0
 UP bounds    x[3768]   1
 LO bounds    x[3769]   0
 UP bounds    x[3769]   1
 LO bounds    x[3770]   0
 UP bounds    x[3770]   1
 LO bounds    x[3771]   0
 UP bounds    x[3771]   1
 LO bounds    x[3772]   0
 UP bounds    x[3772]   1
 LO bounds    x[3773]   0
 UP bounds    x[3773]   1
 LO bounds    x[3774]   0
 UP bounds    x[3774]   1
 LO bounds    x[3775]   0
 UP bounds    x[3775]   1
 LO bounds    x[3776]   0
 UP bounds    x[3776]   1
 LO bounds    x[3777]   0
 UP bounds    x[3777]   1
 LO bounds    x[3778]   0
 UP bounds    x[3778]   1
 LO bounds    x[3779]   0
 UP bounds    x[3779]   1
 LO bounds    x[3780]   0
 UP bounds    x[3780]   1
 LO bounds    x[3781]   0
 UP bounds    x[3781]   1
 LO bounds    x[3782]   0
 UP bounds    x[3782]   1
 LO bounds    x[3783]   0
 UP bounds    x[3783]   1
 LO bounds    x[3784]   0
 UP bounds    x[3784]   1
 LO bounds    x[3785]   0
 UP bounds    x[3785]   1
 LO bounds    x[3786]   0
 UP bounds    x[3786]   1
 LO bounds    x[3787]   0
 UP bounds    x[3787]   1
 LO bounds    x[3788]   0
 UP bounds    x[3788]   1
 LO bounds    x[3789]   0
 UP bounds    x[3789]   1
 LO bounds    x[3790]   0
 UP bounds    x[3790]   1
 LO bounds    x[3791]   0
 UP bounds    x[3791]   1
 LO bounds    x[3792]   0
 UP bounds    x[3792]   1
 LO bounds    x[3793]   0
 UP bounds    x[3793]   1
 LO bounds    x[3794]   0
 UP bounds    x[3794]   1
 LO bounds    x[3795]   0
 UP bounds    x[3795]   1
 LO bounds    x[3796]   0
 UP bounds    x[3796]   1
 LO bounds    x[3797]   0
 UP bounds    x[3797]   1
 LO bounds    x[3798]   0
 UP bounds    x[3798]   1
 LO bounds    x[3799]   0
 UP bounds    x[3799]   1
 LO bounds    x[3800]   0
 UP bounds    x[3800]   1
 LO bounds    x[3801]   0
 UP bounds    x[3801]   1
 LO bounds    x[3802]   0
 UP bounds    x[3802]   1
 LO bounds    x[3803]   0
 UP bounds    x[3803]   1
 LO bounds    x[3804]   0
 UP bounds    x[3804]   1
 LO bounds    x[3805]   0
 UP bounds    x[3805]   1
 LO bounds    x[3806]   0
 UP bounds    x[3806]   1
 LO bounds    x[3807]   0
 UP bounds    x[3807]   1
 LO bounds    x[3808]   0
 UP bounds    x[3808]   1
 LO bounds    x[3809]   0
 UP bounds    x[3809]   1
 LO bounds    x[3810]   0
 UP bounds    x[3810]   1
 LO bounds    x[3811]   0
 UP bounds    x[3811]   1
 LO bounds    x[3812]   0
 UP bounds    x[3812]   1
 LO bounds    x[3813]   0
 UP bounds    x[3813]   1
 LO bounds    x[3814]   0
 UP bounds    x[3814]   1
 LO bounds    x[3815]   0
 UP bounds    x[3815]   1
 LO bounds    x[3816]   0
 UP bounds    x[3816]   1
 LO bounds    x[3817]   0
 UP bounds    x[3817]   1
 LO bounds    x[3818]   0
 UP bounds    x[3818]   1
 LO bounds    x[3819]   0
 UP bounds    x[3819]   1
 LO bounds    x[3820]   0
 UP bounds    x[3820]   1
 LO bounds    x[3821]   0
 UP bounds    x[3821]   1
 LO bounds    x[3822]   0
 UP bounds    x[3822]   1
 LO bounds    x[3823]   0
 UP bounds    x[3823]   1
 LO bounds    x[3824]   0
 UP bounds    x[3824]   1
 LO bounds    x[3825]   0
 UP bounds    x[3825]   1
 LO bounds    x[3826]   0
 UP bounds    x[3826]   1
 LO bounds    x[3827]   0
 UP bounds    x[3827]   1
 LO bounds    x[3828]   0
 UP bounds    x[3828]   1
 LO bounds    x[3829]   0
 UP bounds    x[3829]   1
 LO bounds    x[3830]   0
 UP bounds    x[3830]   1
 LO bounds    x[3831]   0
 UP bounds    x[3831]   1
 LO bounds    x[3832]   0
 UP bounds    x[3832]   1
 LO bounds    x[3833]   0
 UP bounds    x[3833]   1
 LO bounds    x[3834]   0
 UP bounds    x[3834]   1
 LO bounds    x[3835]   0
 UP bounds    x[3835]   1
 LO bounds    x[3836]   0
 UP bounds    x[3836]   1
 LO bounds    x[3837]   0
 UP bounds    x[3837]   1
 LO bounds    x[3838]   0
 UP bounds    x[3838]   1
 LO bounds    x[3839]   0
 UP bounds    x[3839]   1
 LO bounds    x[3840]   0
 UP bounds    x[3840]   1
 LO bounds    x[3841]   0
 UP bounds    x[3841]   1
 LO bounds    x[3842]   0
 UP bounds    x[3842]   1
 LO bounds    x[3843]   0
 UP bounds    x[3843]   1
 LO bounds    x[3844]   0
 UP bounds    x[3844]   1
 LO bounds    x[3845]   0
 UP bounds    x[3845]   1
 LO bounds    x[3846]   0
 UP bounds    x[3846]   1
 LO bounds    x[3847]   0
 UP bounds    x[3847]   1
 LO bounds    x[3848]   0
 UP bounds    x[3848]   1
 LO bounds    x[3849]   0
 UP bounds    x[3849]   1
 LO bounds    x[3850]   0
 UP bounds    x[3850]   1
 LO bounds    x[3851]   0
 UP bounds    x[3851]   1
 LO bounds    x[3852]   0
 UP bounds    x[3852]   1
 LO bounds    x[3853]   0
 UP bounds    x[3853]   1
 LO bounds    x[3854]   0
 UP bounds    x[3854]   1
 LO bounds    x[3855]   0
 UP bounds    x[3855]   1
 LO bounds    x[3856]   0
 UP bounds    x[3856]   1
 LO bounds    x[3857]   0
 UP bounds    x[3857]   1
 LO bounds    x[3858]   0
 UP bounds    x[3858]   1
 LO bounds    x[3859]   0
 UP bounds    x[3859]   1
 LO bounds    x[3860]   0
 UP bounds    x[3860]   1
 LO bounds    x[3861]   0
 UP bounds    x[3861]   1
 LO bounds    x[3862]   0
 UP bounds    x[3862]   1
 LO bounds    x[3863]   0
 UP bounds    x[3863]   1
 LO bounds    x[3864]   0
 UP bounds    x[3864]   1
 LO bounds    x[3865]   0
 UP bounds    x[3865]   1
 LO bounds    x[3866]   0
 UP bounds    x[3866]   1
 LO bounds    x[3867]   0
 UP bounds    x[3867]   1
 LO bounds    x[3868]   0
 UP bounds    x[3868]   1
 LO bounds    x[3869]   0
 UP bounds    x[3869]   1
 LO bounds    x[3870]   0
 UP bounds    x[3870]   1
 LO bounds    x[3871]   0
 UP bounds    x[3871]   1
 LO bounds    x[3872]   0
 UP bounds    x[3872]   1
ENDATA
