NAME
ROWS
 N  OBJ
 L  c1
 L  c2
 L  c3
 L  c4
 L  c5
 L  c6
 L  c7
 L  c8
 L  c9
 L  c10
 L  c11
 L  c12
 L  c13
 L  c14
 L  c15
 L  c16
 L  c17
 L  c18
 L  c19
 L  c20
 L  c21
 L  c22
 L  c23
 L  c24
 L  c25
 L  c26
 L  c27
 L  c28
 L  c29
 L  c30
 L  c31
 L  c32
 L  c33
 L  c34
 L  c35
 L  c36
 L  c37
 L  c38
 L  c39
 L  c40
 L  c41
 L  c42
 L  c43
 L  c44
 L  c45
 L  c46
 L  c47
 L  c48
 L  c49
 L  c50
 L  c51
 L  c52
 L  c53
 L  c54
 L  c55
 L  c56
 L  c57
 L  c58
 L  c59
 L  c60
 L  c61
 L  c62
 L  c63
 L  c64
 L  c65
 L  c66
 L  c67
 L  c68
 L  c69
 L  c70
 L  c71
 L  c72
 L  c73
 L  c74
 L  c75
 L  c76
 L  c77
 L  c78
 L  c79
 L  c80
 L  c81
 L  c82
 L  c83
 L  c84
 L  c85
 L  c86
 L  c87
 L  c88
 L  c89
 L  c90
 L  c91
 L  c92
 L  c93
 L  c94
 L  c95
 L  c96
 L  c97
 L  c98
 L  c99
 L  c100
 L  c101
 L  c102
 L  c103
 L  c104
 L  c105
 L  c106
 L  c107
 L  c108
 L  c109
 L  c110
 L  c111
 L  c112
 L  c113
 L  c114
 L  c115
 L  c116
 L  c117
 L  c118
 L  c119
 L  c120
 L  c121
 L  c122
 L  c123
 L  c124
 L  c125
 L  c126
 L  c127
 L  c128
 L  c129
 L  c130
 L  c131
 L  c132
 L  c133
 L  c134
 L  c135
 L  c136
 L  c137
 L  c138
 L  c139
 L  c140
 L  c141
 L  c142
 L  c143
 L  c144
 L  c145
 L  c146
 L  c147
 L  c148
 L  c149
 L  c150
 L  c151
 L  c152
 L  c153
 L  c154
 L  c155
 L  c156
 L  c157
 L  c158
 L  c159
 L  c160
 L  c161
 L  c162
 L  c163
 L  c164
 L  c165
 L  c166
 L  c167
 L  c168
 L  c169
 L  c170
 L  c171
 L  c172
 L  c173
 L  c174
 L  c175
 L  c176
 L  c177
 L  c178
 L  c179
 L  c180
 L  c181
 L  c182
 L  c183
 L  c184
 L  c185
 L  c186
 L  c187
 L  c188
 L  c189
 L  c190
 L  c191
 L  c192
 L  c193
 L  c194
 L  c195
 L  c196
 L  c197
 L  c198
 L  c199
 L  c200
 L  c201
 L  c202
 L  c203
 L  c204
 L  c205
 L  c206
 L  c207
 L  c208
 L  c209
 L  c210
 L  c211
 L  c212
 L  c213
 L  c214
 L  c215
 L  c216
 L  c217
 L  c218
 L  c219
 L  c220
 L  c221
 L  c222
 L  c223
 L  c224
 L  c225
 L  c226
 L  c227
 L  c228
 L  c229
 L  c230
 L  c231
 L  c232
 L  c233
 L  c234
 L  c235
 L  c236
 L  c237
 L  c238
 L  c239
 L  c240
 L  c241
 L  c242
 L  c243
 L  c244
 L  c245
 L  c246
 L  c247
 L  c248
 L  c249
 L  c250
 L  c251
 L  c252
 L  c253
 L  c254
 L  c255
 L  c256
 L  c257
 L  c258
 L  c259
 L  c260
 L  c261
 L  c262
 L  c263
 L  c264
 L  c265
 L  c266
 L  c267
 L  c268
 L  c269
 L  c270
 L  c271
 L  c272
 L  c273
 L  c274
 L  c275
 L  c276
 L  c277
 L  c278
 L  c279
 L  c280
 L  c281
 L  c282
 L  c283
 L  c284
 L  c285
 L  c286
 L  c287
 L  c288
 L  c289
 L  c290
 L  c291
 L  c292
 L  c293
 L  c294
 L  c295
 L  c296
 L  c297
 L  c298
 L  c299
 L  c300
 L  c301
 L  c302
 L  c303
 L  c304
 L  c305
 L  c306
 L  c307
 L  c308
 L  c309
 L  c310
 L  c311
 L  c312
 L  c313
 L  c314
 L  c315
 L  c316
 L  c317
 L  c318
 L  c319
 L  c320
 L  c321
 L  c322
 L  c323
 L  c324
 L  c325
 L  c326
 L  c327
 L  c328
 L  c329
 L  c330
 L  c331
 L  c332
 L  c333
 L  c334
 L  c335
 L  c336
 L  c337
 L  c338
 L  c339
 L  c340
 L  c341
 L  c342
 L  c343
 L  c344
 L  c345
 L  c346
 L  c347
 L  c348
 L  c349
 L  c350
 L  c351
 L  c352
 L  c353
 L  c354
 L  c355
 L  c356
 L  c357
 L  c358
 L  c359
 L  c360
 L  c361
 L  c362
 L  c363
 L  c364
 L  c365
 L  c366
 L  c367
 L  c368
 L  c369
 L  c370
 L  c371
 L  c372
 L  c373
 L  c374
 L  c375
 L  c376
 L  c377
 L  c378
 L  c379
 L  c380
 L  c381
 L  c382
 L  c383
 L  c384
 L  c385
 L  c386
 L  c387
 L  c388
 L  c389
 L  c390
 L  c391
 L  c392
 L  c393
 L  c394
 L  c395
 L  c396
 L  c397
 L  c398
 L  c399
 L  c400
 L  c401
 L  c402
 L  c403
 L  c404
 L  c405
 L  c406
 L  c407
 L  c408
 L  c409
 L  c410
 L  c411
 L  c412
 L  c413
 L  c414
 L  c415
 L  c416
 L  c417
 L  c418
 L  c419
 L  c420
 L  c421
 L  c422
 L  c423
 L  c424
 L  c425
 L  c426
 L  c427
 L  c428
 L  c429
 L  c430
 L  c431
 L  c432
 L  c433
 L  c434
 L  c435
 L  c436
 L  c437
 L  c438
 L  c439
 L  c440
 L  c441
 L  c442
 L  c443
 L  c444
 L  c445
 L  c446
 L  c447
 L  c448
 L  c449
 L  c450
 L  c451
 L  c452
 L  c453
 L  c454
 L  c455
 L  c456
 L  c457
 L  c458
 L  c459
 L  c460
 L  c461
 L  c462
 L  c463
 L  c464
 L  c465
 L  c466
 L  c467
 L  c468
 L  c469
 L  c470
 L  c471
 L  c472
 L  c473
 L  c474
 L  c475
 L  c476
 L  c477
 L  c478
 L  c479
 L  c480
 L  c481
 L  c482
 L  c483
 L  c484
 L  c485
 L  c486
 L  c487
 L  c488
 L  c489
 L  c490
 L  c491
 L  c492
 L  c493
 L  c494
 L  c495
 L  c496
 L  c497
 L  c498
 L  c499
 L  c500
 L  c501
 L  c502
 L  c503
 L  c504
 L  c505
 L  c506
 L  c507
 L  c508
 L  c509
 L  c510
 L  c511
 L  c512
 L  c513
 L  c514
 L  c515
 L  c516
 L  c517
 L  c518
 L  c519
 L  c520
 L  c521
 L  c522
 L  c523
 L  c524
 L  c525
 L  c526
 L  c527
 L  c528
 L  c529
 L  c530
 L  c531
 L  c532
 L  c533
 L  c534
 L  c535
 L  c536
 L  c537
 L  c538
 L  c539
 L  c540
 L  c541
 L  c542
 L  c543
 L  c544
 L  c545
 L  c546
 L  c547
 L  c548
 L  c549
 L  c550
 L  c551
 L  c552
 L  c553
 L  c554
 L  c555
 L  c556
 L  c557
 L  c558
 L  c559
 L  c560
 L  c561
 L  c562
 L  c563
 L  c564
 L  c565
 L  c566
 L  c567
 L  c568
 L  c569
 L  c570
 L  c571
 L  c572
 L  c573
 L  c574
 L  c575
 L  c576
 L  c577
 L  c578
 L  c579
 L  c580
 L  c581
 L  c582
 L  c583
 L  c584
 L  c585
 L  c586
 L  c587
 L  c588
 L  c589
 L  c590
 L  c591
 L  c592
 L  c593
 L  c594
 L  c595
 L  c596
 L  c597
 L  c598
 L  c599
 L  c600
 L  c601
 L  c602
 L  c603
 L  c604
 L  c605
 L  c606
 L  c607
 L  c608
 L  c609
 L  c610
 L  c611
 L  c612
 L  c613
 L  c614
 L  c615
 L  c616
 L  c617
 L  c618
 L  c619
 L  c620
 L  c621
 L  c622
 L  c623
 L  c624
 L  c625
 L  c626
 L  c627
 L  c628
 L  c629
 L  c630
 L  c631
 L  c632
 L  c633
 L  c634
 L  c635
 L  c636
 L  c637
 L  c638
 L  c639
 L  c640
 L  c641
 L  c642
 L  c643
 L  c644
 L  c645
 L  c646
 L  c647
 L  c648
 L  c649
 L  c650
 L  c651
 L  c652
 L  c653
 L  c654
 L  c655
 L  c656
 L  c657
 L  c658
 L  c659
 L  c660
 L  c661
 L  c662
 L  c663
 L  c664
 L  c665
 L  c666
 L  c667
 L  c668
 L  c669
 L  c670
 L  c671
 L  c672
 L  c673
 L  c674
 L  c675
 L  c676
 L  c677
 L  c678
 L  c679
 L  c680
 L  c681
 L  c682
 L  c683
 L  c684
 L  c685
 L  c686
 L  c687
 L  c688
 L  c689
 L  c690
 L  c691
 L  c692
 L  c693
 L  c694
 L  c695
 L  c696
 L  c697
 L  c698
 L  c699
 L  c700
 L  c701
 L  c702
 L  c703
 L  c704
 L  c705
 L  c706
 L  c707
 L  c708
 L  c709
 L  c710
 L  c711
 L  c712
 L  c713
 L  c714
 L  c715
 L  c716
 L  c717
 L  c718
 L  c719
 L  c720
 L  c721
 L  c722
 L  c723
 L  c724
 L  c725
 L  c726
 L  c727
 L  c728
 L  c729
 L  c730
 L  c731
 L  c732
 L  c733
 L  c734
 L  c735
 L  c736
 L  c737
 L  c738
 L  c739
 L  c740
 L  c741
 L  c742
 L  c743
 L  c744
 L  c745
 L  c746
 L  c747
 L  c748
 L  c749
 L  c750
 L  c751
 L  c752
 L  c753
 L  c754
 L  c755
 L  c756
 L  c757
 L  c758
 L  c759
 L  c760
 L  c761
 L  c762
 L  c763
 L  c764
 L  c765
 L  c766
 L  c767
 L  c768
 L  c769
 L  c770
 L  c771
 L  c772
 L  c773
 L  c774
 L  c775
 L  c776
 L  c777
 L  c778
 L  c779
 L  c780
 L  c781
 L  c782
 L  c783
 L  c784
 L  c785
 L  c786
 L  c787
 L  c788
 L  c789
 L  c790
 L  c791
 L  c792
 L  c793
 L  c794
 L  c795
 L  c796
 L  c797
 L  c798
 L  c799
 L  c800
 L  c801
 L  c802
 L  c803
 L  c804
 L  c805
 L  c806
 L  c807
 L  c808
 L  c809
 L  c810
 L  c811
 L  c812
 L  c813
 L  c814
 L  c815
 L  c816
 L  c817
 L  c818
 L  c819
 L  c820
 L  c821
 L  c822
 L  c823
 L  c824
 L  c825
 L  c826
 L  c827
 L  c828
 L  c829
 L  c830
 L  c831
 L  c832
 L  c833
 L  c834
 L  c835
 L  c836
 L  c837
 L  c838
 L  c839
 L  c840
 L  c841
 L  c842
 L  c843
 L  c844
 L  c845
 L  c846
 L  c847
 L  c848
 L  c849
 L  c850
 L  c851
 L  c852
 L  c853
 L  c854
 L  c855
 L  c856
 L  c857
 L  c858
 L  c859
 L  c860
 L  c861
 L  c862
 L  c863
 L  c864
 L  c865
 L  c866
 L  c867
 L  c868
 L  c869
 L  c870
 L  c871
 L  c872
 L  c873
 L  c874
 L  c875
 L  c876
 L  c877
 L  c878
 L  c879
 L  c880
 L  c881
 L  c882
 L  c883
 L  c884
 L  c885
 L  c886
 L  c887
 L  c888
 L  c889
 L  c890
 L  c891
 L  c892
 L  c893
 L  c894
 L  c895
 L  c896
 L  c897
 L  c898
 L  c899
 L  c900
 L  c901
 L  c902
 L  c903
 L  c904
 L  c905
 L  c906
 L  c907
 L  c908
 L  c909
 L  c910
 L  c911
 L  c912
 L  c913
 L  c914
 L  c915
 L  c916
 L  c917
 L  c918
 L  c919
 L  c920
 L  c921
 L  c922
 L  c923
 L  c924
 L  c925
 L  c926
 L  c927
 L  c928
 L  c929
 L  c930
 L  c931
 L  c932
 L  c933
 L  c934
 L  c935
 L  c936
 L  c937
 L  c938
 L  c939
 L  c940
 L  c941
 L  c942
 L  c943
 L  c944
 L  c945
 L  c946
 L  c947
 L  c948
 L  c949
 L  c950
 L  c951
 L  c952
 L  c953
 L  c954
 L  c955
 L  c956
 L  c957
 L  c958
 L  c959
 L  c960
 L  c961
 L  c962
 L  c963
 L  c964
 L  c965
 L  c966
 L  c967
 L  c968
 L  c969
 L  c970
 L  c971
 L  c972
 L  c973
 L  c974
 L  c975
 L  c976
 L  c977
 L  c978
 L  c979
 L  c980
 L  c981
 L  c982
 L  c983
 L  c984
 L  c985
 L  c986
 L  c987
 L  c988
 L  c989
 L  c990
 L  c991
 L  c992
 L  c993
 L  c994
 L  c995
 L  c996
 L  c997
 L  c998
 L  c999
 L  c1000
 L  c1001
 L  c1002
 L  c1003
 L  c1004
 L  c1005
 L  c1006
 L  c1007
 L  c1008
 L  c1009
 L  c1010
 L  c1011
 L  c1012
 L  c1013
 L  c1014
 L  c1015
 L  c1016
 L  c1017
 L  c1018
 L  c1019
 L  c1020
 L  c1021
 L  c1022
 L  c1023
 L  c1024
 L  c1025
 L  c1026
 L  c1027
 L  c1028
 L  c1029
 L  c1030
 L  c1031
 L  c1032
 L  c1033
 L  c1034
 L  c1035
 L  c1036
 L  c1037
 L  c1038
 L  c1039
 L  c1040
 L  c1041
 L  c1042
 L  c1043
 L  c1044
 L  c1045
 L  c1046
 L  c1047
 L  c1048
 L  c1049
 L  c1050
 L  c1051
 L  c1052
 L  c1053
 L  c1054
 L  c1055
 L  c1056
 L  c1057
 L  c1058
 L  c1059
 L  c1060
 L  c1061
 L  c1062
 L  c1063
 L  c1064
 L  c1065
 L  c1066
 L  c1067
 L  c1068
 L  c1069
 L  c1070
 L  c1071
 L  c1072
 L  c1073
 L  c1074
 L  c1075
 L  c1076
 L  c1077
 L  c1078
 L  c1079
 L  c1080
 L  c1081
 L  c1082
 L  c1083
 L  c1084
 L  c1085
 L  c1086
 L  c1087
 L  c1088
 L  c1089
 L  c1090
 L  c1091
 L  c1092
 L  c1093
 L  c1094
 L  c1095
 L  c1096
 L  c1097
 L  c1098
 L  c1099
 L  c1100
 L  c1101
 L  c1102
 L  c1103
 L  c1104
 L  c1105
 L  c1106
 L  c1107
 L  c1108
 L  c1109
 L  c1110
 L  c1111
 L  c1112
 L  c1113
 L  c1114
 L  c1115
 L  c1116
 L  c1117
 L  c1118
 L  c1119
 L  c1120
 L  c1121
 L  c1122
 L  c1123
 L  c1124
 L  c1125
 L  c1126
 L  c1127
 L  c1128
 L  c1129
 L  c1130
 L  c1131
 L  c1132
 L  c1133
 L  c1134
 L  c1135
 L  c1136
 L  c1137
 L  c1138
 L  c1139
 L  c1140
 L  c1141
 L  c1142
 L  c1143
 L  c1144
 L  c1145
 L  c1146
 L  c1147
 L  c1148
 L  c1149
 L  c1150
 L  c1151
 L  c1152
 L  c1153
 L  c1154
 L  c1155
 L  c1156
 L  c1157
 L  c1158
 L  c1159
 L  c1160
 L  c1161
 L  c1162
 L  c1163
 L  c1164
 L  c1165
 L  c1166
 L  c1167
 L  c1168
 L  c1169
 L  c1170
 L  c1171
 L  c1172
 L  c1173
 L  c1174
 L  c1175
 L  c1176
 L  c1177
 L  c1178
 L  c1179
 L  c1180
 L  c1181
 L  c1182
 L  c1183
 L  c1184
 L  c1185
 L  c1186
 L  c1187
 L  c1188
 L  c1189
 L  c1190
 L  c1191
 L  c1192
 L  c1193
 L  c1194
 L  c1195
 L  c1196
 L  c1197
 L  c1198
 L  c1199
 L  c1200
 L  c1201
 L  c1202
 L  c1203
 L  c1204
 L  c1205
 L  c1206
 L  c1207
 L  c1208
 L  c1209
 L  c1210
 L  c1211
 L  c1212
 L  c1213
 L  c1214
 L  c1215
 L  c1216
 L  c1217
 L  c1218
 L  c1219
 L  c1220
 L  c1221
 L  c1222
 L  c1223
 L  c1224
 L  c1225
 L  c1226
 L  c1227
 L  c1228
 L  c1229
 L  c1230
 L  c1231
 L  c1232
 L  c1233
 L  c1234
 L  c1235
 L  c1236
 L  c1237
 L  c1238
 L  c1239
 L  c1240
 L  c1241
 L  c1242
 L  c1243
 L  c1244
 L  c1245
 L  c1246
 L  c1247
 L  c1248
 L  c1249
 L  c1250
 L  c1251
 L  c1252
 L  c1253
 L  c1254
 L  c1255
 L  c1256
 L  c1257
 L  c1258
 L  c1259
 L  c1260
 L  c1261
 L  c1262
 L  c1263
 L  c1264
 L  c1265
 L  c1266
 L  c1267
 L  c1268
 L  c1269
 L  c1270
 L  c1271
 L  c1272
 L  c1273
 L  c1274
 L  c1275
 L  c1276
 L  c1277
 L  c1278
 L  c1279
 L  c1280
 L  c1281
 L  c1282
 L  c1283
 L  c1284
 L  c1285
 L  c1286
 L  c1287
 L  c1288
 L  c1289
 L  c1290
 L  c1291
 L  c1292
 L  c1293
 L  c1294
 L  c1295
 L  c1296
 L  c1297
 L  c1298
 L  c1299
 L  c1300
 L  c1301
 L  c1302
 L  c1303
 L  c1304
 L  c1305
 L  c1306
 L  c1307
 L  c1308
 L  c1309
 L  c1310
 L  c1311
 L  c1312
 L  c1313
 L  c1314
 L  c1315
 L  c1316
 L  c1317
 L  c1318
 L  c1319
 L  c1320
 L  c1321
 L  c1322
 L  c1323
 L  c1324
 L  c1325
 L  c1326
 L  c1327
 L  c1328
 L  c1329
 L  c1330
 L  c1331
 L  c1332
 L  c1333
 L  c1334
 L  c1335
 L  c1336
 L  c1337
 L  c1338
 L  c1339
 L  c1340
 L  c1341
 L  c1342
 L  c1343
 L  c1344
 L  c1345
 L  c1346
 L  c1347
 L  c1348
 L  c1349
 L  c1350
 L  c1351
 L  c1352
 L  c1353
 L  c1354
 L  c1355
 L  c1356
 L  c1357
 L  c1358
 L  c1359
 L  c1360
 L  c1361
 L  c1362
 L  c1363
 L  c1364
 L  c1365
 L  c1366
 L  c1367
 L  c1368
 L  c1369
 L  c1370
 L  c1371
 L  c1372
 L  c1373
 L  c1374
 L  c1375
 L  c1376
 L  c1377
 L  c1378
 L  c1379
 L  c1380
 L  c1381
 L  c1382
 L  c1383
 L  c1384
 L  c1385
 L  c1386
 L  c1387
 L  c1388
 L  c1389
 L  c1390
 L  c1391
 L  c1392
 L  c1393
 L  c1394
 L  c1395
 L  c1396
 L  c1397
 L  c1398
 L  c1399
 L  c1400
 L  c1401
 L  c1402
 L  c1403
 L  c1404
 L  c1405
 L  c1406
 L  c1407
 L  c1408
 L  c1409
 L  c1410
 L  c1411
 L  c1412
 L  c1413
 L  c1414
 L  c1415
 L  c1416
 L  c1417
 L  c1418
 L  c1419
 L  c1420
 L  c1421
 L  c1422
 L  c1423
 L  c1424
 L  c1425
 L  c1426
 L  c1427
 L  c1428
 L  c1429
 L  c1430
 L  c1431
 L  c1432
 L  c1433
 L  c1434
 L  c1435
 L  c1436
 L  c1437
 L  c1438
 L  c1439
 L  c1440
 L  c1441
 L  c1442
 L  c1443
 L  c1444
 L  c1445
 L  c1446
 L  c1447
 L  c1448
 L  c1449
 L  c1450
 L  c1451
 L  c1452
 L  c1453
 L  c1454
 L  c1455
 L  c1456
 L  c1457
 L  c1458
 L  c1459
 L  c1460
 L  c1461
 L  c1462
 L  c1463
 L  c1464
 L  c1465
 L  c1466
 L  c1467
 L  c1468
 L  c1469
 L  c1470
 L  c1471
 L  c1472
 L  c1473
 L  c1474
 L  c1475
 L  c1476
 L  c1477
 L  c1478
 L  c1479
 L  c1480
 L  c1481
 L  c1482
 L  c1483
 L  c1484
 L  c1485
 L  c1486
 L  c1487
 L  c1488
 L  c1489
 L  c1490
 L  c1491
 L  c1492
 L  c1493
 L  c1494
 L  c1495
 L  c1496
 L  c1497
 L  c1498
 L  c1499
 L  c1500
 L  c1501
 L  c1502
 L  c1503
 L  c1504
 L  c1505
 L  c1506
 L  c1507
 L  c1508
 L  c1509
 L  c1510
 L  c1511
 L  c1512
 L  c1513
 L  c1514
 L  c1515
 L  c1516
 L  c1517
 L  c1518
 L  c1519
 L  c1520
 L  c1521
 L  c1522
 L  c1523
 L  c1524
 L  c1525
 L  c1526
 L  c1527
 L  c1528
 L  c1529
 L  c1530
 L  c1531
 L  c1532
 L  c1533
 L  c1534
 L  c1535
 L  c1536
 L  c1537
 L  c1538
 L  c1539
 L  c1540
 L  c1541
 L  c1542
 L  c1543
 L  c1544
 L  c1545
 L  c1546
 L  c1547
 L  c1548
 L  c1549
 L  c1550
 L  c1551
 L  c1552
 L  c1553
 L  c1554
 L  c1555
 L  c1556
 L  c1557
 L  c1558
 L  c1559
 L  c1560
 L  c1561
 L  c1562
 L  c1563
 L  c1564
 L  c1565
 L  c1566
 L  c1567
 L  c1568
 L  c1569
 L  c1570
 L  c1571
 L  c1572
 L  c1573
 L  c1574
 L  c1575
 L  c1576
 L  c1577
 L  c1578
 L  c1579
 L  c1580
 L  c1581
 L  c1582
 L  c1583
 L  c1584
 L  c1585
 L  c1586
 L  c1587
 L  c1588
 L  c1589
 L  c1590
 L  c1591
 L  c1592
 L  c1593
 L  c1594
 L  c1595
 L  c1596
 L  c1597
 L  c1598
 L  c1599
 L  c1600
 L  c1601
 L  c1602
 L  c1603
 L  c1604
 L  c1605
 L  c1606
 L  c1607
 L  c1608
 L  c1609
 L  c1610
 L  c1611
 L  c1612
 L  c1613
 L  c1614
 L  c1615
 L  c1616
 L  c1617
 L  c1618
 L  c1619
 L  c1620
 L  c1621
 L  c1622
 L  c1623
 L  c1624
 L  c1625
 L  c1626
 L  c1627
 L  c1628
 L  c1629
 L  c1630
 L  c1631
 L  c1632
 L  c1633
 L  c1634
 L  c1635
 L  c1636
 L  c1637
 L  c1638
 L  c1639
 L  c1640
 L  c1641
 L  c1642
 L  c1643
 L  c1644
 L  c1645
 L  c1646
 L  c1647
 L  c1648
 L  c1649
 L  c1650
 L  c1651
 L  c1652
 L  c1653
 L  c1654
 L  c1655
 L  c1656
 L  c1657
 L  c1658
 L  c1659
 L  c1660
 L  c1661
 L  c1662
 L  c1663
 L  c1664
 L  c1665
 L  c1666
 L  c1667
 L  c1668
 L  c1669
 L  c1670
 L  c1671
 L  c1672
 L  c1673
 L  c1674
 L  c1675
 L  c1676
 L  c1677
 L  c1678
 L  c1679
 L  c1680
 L  c1681
 L  c1682
 L  c1683
 L  c1684
 L  c1685
 L  c1686
 L  c1687
 L  c1688
 L  c1689
 L  c1690
 L  c1691
 L  c1692
 L  c1693
 L  c1694
 L  c1695
 L  c1696
 L  c1697
 L  c1698
 L  c1699
 L  c1700
 L  c1701
 L  c1702
 L  c1703
 L  c1704
 L  c1705
 L  c1706
 L  c1707
 L  c1708
 L  c1709
 L  c1710
 L  c1711
 L  c1712
 L  c1713
 L  c1714
 L  c1715
 L  c1716
 L  c1717
 L  c1718
 L  c1719
 L  c1720
 L  c1721
 L  c1722
 L  c1723
 L  c1724
 L  c1725
 L  c1726
 L  c1727
 L  c1728
 L  c1729
 L  c1730
 L  c1731
 L  c1732
 L  c1733
 L  c1734
 L  c1735
 L  c1736
 L  c1737
 L  c1738
 L  c1739
 L  c1740
 L  c1741
 L  c1742
 L  c1743
 L  c1744
 L  c1745
 L  c1746
 L  c1747
 L  c1748
 L  c1749
 L  c1750
 L  c1751
 L  c1752
 L  c1753
 L  c1754
 L  c1755
 L  c1756
 L  c1757
 L  c1758
 L  c1759
 L  c1760
 L  c1761
 L  c1762
 L  c1763
 L  c1764
 L  c1765
 L  c1766
 L  c1767
 L  c1768
 L  c1769
 L  c1770
 L  c1771
 L  c1772
 L  c1773
 L  c1774
 L  c1775
 L  c1776
 L  c1777
 L  c1778
 L  c1779
 L  c1780
 L  c1781
 L  c1782
 L  c1783
 L  c1784
 L  c1785
 L  c1786
 L  c1787
 L  c1788
 L  c1789
 L  c1790
 L  c1791
 L  c1792
 L  c1793
 L  c1794
 L  c1795
 L  c1796
 L  c1797
 L  c1798
 L  c1799
 L  c1800
 L  c1801
 L  c1802
 L  c1803
 L  c1804
 L  c1805
 L  c1806
 L  c1807
 L  c1808
 L  c1809
 L  c1810
 L  c1811
 L  c1812
 L  c1813
 L  c1814
 L  c1815
 L  c1816
 L  c1817
 L  c1818
 L  c1819
 L  c1820
 L  c1821
 L  c1822
 L  c1823
 L  c1824
 L  c1825
 L  c1826
 L  c1827
 L  c1828
 L  c1829
 L  c1830
 L  c1831
 L  c1832
 L  c1833
 L  c1834
 L  c1835
 L  c1836
 L  c1837
 L  c1838
 L  c1839
 L  c1840
 L  c1841
 L  c1842
 L  c1843
 L  c1844
 L  c1845
 L  c1846
 L  c1847
 L  c1848
 L  c1849
 L  c1850
 L  c1851
 L  c1852
 L  c1853
 L  c1854
 L  c1855
 L  c1856
 L  c1857
 L  c1858
 L  c1859
 L  c1860
 L  c1861
 L  c1862
 L  c1863
 L  c1864
 L  c1865
 L  c1866
 L  c1867
 L  c1868
 L  c1869
 L  c1870
 L  c1871
 L  c1872
 L  c1873
 L  c1874
 L  c1875
 L  c1876
 L  c1877
 L  c1878
 L  c1879
 L  c1880
 L  c1881
 L  c1882
 L  c1883
 L  c1884
 L  c1885
 L  c1886
 L  c1887
 L  c1888
 L  c1889
 L  c1890
 L  c1891
 L  c1892
 L  c1893
 L  c1894
 L  c1895
 L  c1896
 L  c1897
 L  c1898
 L  c1899
 L  c1900
 L  c1901
 L  c1902
 L  c1903
 L  c1904
 L  c1905
 L  c1906
 L  c1907
 L  c1908
 L  c1909
 L  c1910
 L  c1911
 L  c1912
 L  c1913
 L  c1914
 L  c1915
 L  c1916
 L  c1917
 L  c1918
 L  c1919
 L  c1920
 L  c1921
 L  c1922
 L  c1923
 L  c1924
 L  c1925
 L  c1926
 L  c1927
 L  c1928
 L  c1929
 L  c1930
 L  c1931
 L  c1932
 L  c1933
 L  c1934
 L  c1935
 L  c1936
 L  c1937
 L  c1938
 L  c1939
 L  c1940
 L  c1941
 L  c1942
 L  c1943
 L  c1944
 L  c1945
 L  c1946
 L  c1947
 L  c1948
 L  c1949
 L  c1950
 L  c1951
 L  c1952
 L  c1953
 L  c1954
 L  c1955
 L  c1956
 L  c1957
 L  c1958
 L  c1959
 L  c1960
 L  c1961
 L  c1962
 L  c1963
 L  c1964
 L  c1965
 L  c1966
 L  c1967
 L  c1968
 L  c1969
 L  c1970
 L  c1971
 L  c1972
 L  c1973
 L  c1974
 L  c1975
 L  c1976
 L  c1977
 L  c1978
 L  c1979
 L  c1980
 L  c1981
 L  c1982
 L  c1983
 L  c1984
 L  c1985
 L  c1986
 L  c1987
 L  c1988
 L  c1989
 L  c1990
 L  c1991
 L  c1992
 L  c1993
 L  c1994
 L  c1995
 L  c1996
 L  c1997
 L  c1998
 L  c1999
 L  c2000
 L  c2001
 L  c2002
 L  c2003
 L  c2004
 L  c2005
 L  c2006
 L  c2007
 L  c2008
 L  c2009
 L  c2010
 L  c2011
 L  c2012
 L  c2013
 L  c2014
 L  c2015
 L  c2016
 L  c2017
 L  c2018
 L  c2019
 L  c2020
 L  c2021
 L  c2022
 L  c2023
 L  c2024
 L  c2025
 L  c2026
 L  c2027
 L  c2028
 L  c2029
 L  c2030
 L  c2031
 L  c2032
 L  c2033
 L  c2034
 L  c2035
 L  c2036
 L  c2037
 L  c2038
 L  c2039
 L  c2040
 L  c2041
 L  c2042
 L  c2043
 L  c2044
 L  c2045
 L  c2046
 L  c2047
 L  c2048
 L  c2049
 L  c2050
 L  c2051
 L  c2052
 L  c2053
 L  c2054
 L  c2055
 L  c2056
 L  c2057
 L  c2058
 L  c2059
 L  c2060
 L  c2061
 L  c2062
 L  c2063
 L  c2064
 L  c2065
 L  c2066
 L  c2067
 L  c2068
 L  c2069
 L  c2070
 L  c2071
 L  c2072
 L  c2073
 L  c2074
 L  c2075
 L  c2076
 L  c2077
 L  c2078
 L  c2079
 L  c2080
 L  c2081
 L  c2082
 L  c2083
 L  c2084
 L  c2085
 L  c2086
 L  c2087
 L  c2088
 L  c2089
 L  c2090
 L  c2091
 L  c2092
 L  c2093
 L  c2094
 L  c2095
 L  c2096
 L  c2097
 L  c2098
 L  c2099
 L  c2100
 L  c2101
 L  c2102
 L  c2103
 L  c2104
 L  c2105
 L  c2106
 L  c2107
 L  c2108
 L  c2109
 L  c2110
 L  c2111
 L  c2112
 L  c2113
 L  c2114
 L  c2115
 L  c2116
 L  c2117
 L  c2118
 L  c2119
 L  c2120
 L  c2121
 L  c2122
 L  c2123
 L  c2124
 L  c2125
 L  c2126
 L  c2127
 L  c2128
 L  c2129
 L  c2130
 L  c2131
 L  c2132
 L  c2133
 L  c2134
 L  c2135
 L  c2136
 L  c2137
 L  c2138
 L  c2139
 L  c2140
 L  c2141
 L  c2142
 L  c2143
 L  c2144
 L  c2145
 L  c2146
 L  c2147
 L  c2148
 L  c2149
 L  c2150
 L  c2151
 L  c2152
 L  c2153
 L  c2154
 L  c2155
 L  c2156
 L  c2157
 L  c2158
 L  c2159
 L  c2160
 L  c2161
 L  c2162
 L  c2163
 L  c2164
 L  c2165
 L  c2166
 L  c2167
 L  c2168
 L  c2169
 L  c2170
 L  c2171
 L  c2172
 L  c2173
 L  c2174
 L  c2175
 L  c2176
 L  c2177
 L  c2178
 L  c2179
 L  c2180
 L  c2181
 L  c2182
 L  c2183
 L  c2184
 L  c2185
 L  c2186
 L  c2187
 L  c2188
 L  c2189
 L  c2190
 L  c2191
 L  c2192
 L  c2193
 L  c2194
 L  c2195
 L  c2196
 L  c2197
 L  c2198
 L  c2199
 L  c2200
 L  c2201
 L  c2202
 L  c2203
 L  c2204
 L  c2205
 L  c2206
 L  c2207
 L  c2208
 L  c2209
 L  c2210
 L  c2211
 L  c2212
 L  c2213
 L  c2214
 L  c2215
 L  c2216
 L  c2217
 L  c2218
 L  c2219
 L  c2220
 L  c2221
 L  c2222
 L  c2223
 L  c2224
 L  c2225
 L  c2226
 L  c2227
 L  c2228
 L  c2229
 L  c2230
 L  c2231
 L  c2232
 L  c2233
 L  c2234
 L  c2235
 L  c2236
 L  c2237
 L  c2238
 L  c2239
 L  c2240
 L  c2241
 L  c2242
 L  c2243
 L  c2244
 L  c2245
 L  c2246
 L  c2247
 L  c2248
 L  c2249
 L  c2250
 L  c2251
 L  c2252
 L  c2253
 L  c2254
 L  c2255
 L  c2256
 L  c2257
 L  c2258
 L  c2259
 L  c2260
 L  c2261
 L  c2262
 L  c2263
 L  c2264
 L  c2265
 L  c2266
 L  c2267
 L  c2268
 L  c2269
 L  c2270
 L  c2271
 L  c2272
 L  c2273
 L  c2274
 L  c2275
 L  c2276
 L  c2277
 L  c2278
 L  c2279
 L  c2280
 L  c2281
 L  c2282
 L  c2283
 L  c2284
 L  c2285
 L  c2286
 L  c2287
 L  c2288
 L  c2289
 L  c2290
 L  c2291
 L  c2292
 L  c2293
 L  c2294
 L  c2295
 L  c2296
 L  c2297
 L  c2298
 L  c2299
 L  c2300
 L  c2301
 L  c2302
 L  c2303
 L  c2304
 L  c2305
 L  c2306
 L  c2307
 L  c2308
 L  c2309
 L  c2310
 L  c2311
 L  c2312
 L  c2313
 L  c2314
 L  c2315
 L  c2316
 L  c2317
 L  c2318
 L  c2319
 L  c2320
 L  c2321
 L  c2322
 L  c2323
 L  c2324
 L  c2325
 L  c2326
 L  c2327
 L  c2328
 L  c2329
 L  c2330
 L  c2331
 L  c2332
 L  c2333
 L  c2334
 L  c2335
 L  c2336
 L  c2337
 L  c2338
 L  c2339
 L  c2340
 L  c2341
 L  c2342
 L  c2343
 L  c2344
 L  c2345
 L  c2346
 L  c2347
 L  c2348
 L  c2349
 L  c2350
 L  c2351
 L  c2352
 L  c2353
 L  c2354
 L  c2355
 L  c2356
 L  c2357
 L  c2358
 L  c2359
 L  c2360
 L  c2361
 L  c2362
 L  c2363
 L  c2364
 L  c2365
 L  c2366
 L  c2367
 L  c2368
 L  c2369
 L  c2370
 L  c2371
 L  c2372
 L  c2373
 L  c2374
 L  c2375
 L  c2376
 L  c2377
 L  c2378
 L  c2379
 L  c2380
 L  c2381
 L  c2382
 L  c2383
 L  c2384
 L  c2385
 L  c2386
 L  c2387
 L  c2388
 L  c2389
 L  c2390
 L  c2391
 L  c2392
 L  c2393
 L  c2394
 L  c2395
 L  c2396
 L  c2397
 L  c2398
 L  c2399
 L  c2400
 L  c2401
 L  c2402
 L  c2403
 L  c2404
 L  c2405
 L  c2406
 L  c2407
 L  c2408
 L  c2409
 L  c2410
 L  c2411
 L  c2412
 L  c2413
 L  c2414
 L  c2415
 L  c2416
 L  c2417
 L  c2418
 L  c2419
 L  c2420
 L  c2421
 L  c2422
 L  c2423
 L  c2424
 L  c2425
 L  c2426
 L  c2427
 L  c2428
 L  c2429
 L  c2430
 L  c2431
 L  c2432
 L  c2433
 L  c2434
 L  c2435
 L  c2436
 L  c2437
 L  c2438
 L  c2439
 L  c2440
 L  c2441
 L  c2442
 L  c2443
 L  c2444
 L  c2445
 L  c2446
 L  c2447
 L  c2448
 L  c2449
 L  c2450
 L  c2451
 L  c2452
 L  c2453
 L  c2454
 L  c2455
 L  c2456
 L  c2457
 L  c2458
 L  c2459
 L  c2460
 L  c2461
 L  c2462
 L  c2463
 L  c2464
 L  c2465
 L  c2466
 L  c2467
 L  c2468
 L  c2469
 L  c2470
 L  c2471
 L  c2472
 L  c2473
 L  c2474
 L  c2475
 L  c2476
 L  c2477
 L  c2478
 L  c2479
 L  c2480
 L  c2481
 L  c2482
 L  c2483
 L  c2484
 L  c2485
 L  c2486
 L  c2487
 L  c2488
 L  c2489
 L  c2490
 L  c2491
 L  c2492
 L  c2493
 L  c2494
 L  c2495
 L  c2496
 L  c2497
 L  c2498
 L  c2499
 L  c2500
 L  c2501
 L  c2502
 L  c2503
 L  c2504
 L  c2505
 L  c2506
 L  c2507
 L  c2508
 L  c2509
 L  c2510
 L  c2511
 L  c2512
 L  c2513
 L  c2514
 L  c2515
 L  c2516
 L  c2517
 L  c2518
 L  c2519
 L  c2520
 L  c2521
 L  c2522
 L  c2523
 L  c2524
 L  c2525
 L  c2526
 L  c2527
 L  c2528
 L  c2529
 L  c2530
 L  c2531
 L  c2532
 L  c2533
 L  c2534
 L  c2535
 L  c2536
 L  c2537
 L  c2538
 L  c2539
 L  c2540
 L  c2541
 L  c2542
 L  c2543
 L  c2544
 L  c2545
 L  c2546
 L  c2547
 L  c2548
 L  c2549
 L  c2550
 L  c2551
 L  c2552
 L  c2553
 L  c2554
 L  c2555
 L  c2556
 L  c2557
 L  c2558
 L  c2559
 L  c2560
 L  c2561
 L  c2562
 L  c2563
 L  c2564
 L  c2565
 L  c2566
 L  c2567
 L  c2568
 L  c2569
 L  c2570
 L  c2571
 L  c2572
 L  c2573
 L  c2574
 L  c2575
 L  c2576
 L  c2577
 L  c2578
 L  c2579
 L  c2580
 L  c2581
 L  c2582
 L  c2583
 L  c2584
 L  c2585
 L  c2586
 L  c2587
 L  c2588
 L  c2589
 L  c2590
 L  c2591
 L  c2592
 L  c2593
 L  c2594
 L  c2595
 L  c2596
 L  c2597
 L  c2598
 L  c2599
 L  c2600
 L  c2601
 L  c2602
 L  c2603
 L  c2604
 L  c2605
 L  c2606
 L  c2607
 L  c2608
 L  c2609
 L  c2610
 L  c2611
 L  c2612
 L  c2613
 L  c2614
 L  c2615
 L  c2616
 L  c2617
 L  c2618
 L  c2619
 L  c2620
 L  c2621
 L  c2622
 L  c2623
 L  c2624
 L  c2625
 L  c2626
 L  c2627
 L  c2628
 L  c2629
 L  c2630
 L  c2631
 L  c2632
 L  c2633
 L  c2634
 L  c2635
 L  c2636
 L  c2637
 L  c2638
 L  c2639
 L  c2640
 L  c2641
 L  c2642
 L  c2643
 L  c2644
 L  c2645
 L  c2646
 L  c2647
 L  c2648
 L  c2649
 L  c2650
 L  c2651
 L  c2652
 L  c2653
 L  c2654
 L  c2655
 L  c2656
 L  c2657
 L  c2658
 L  c2659
 L  c2660
 L  c2661
 L  c2662
 L  c2663
 L  c2664
 L  c2665
 L  c2666
 L  c2667
 L  c2668
 L  c2669
 L  c2670
 L  c2671
 L  c2672
 L  c2673
 L  c2674
 L  c2675
 L  c2676
 L  c2677
 L  c2678
 L  c2679
 L  c2680
 L  c2681
 L  c2682
 L  c2683
 L  c2684
 L  c2685
 L  c2686
 L  c2687
 L  c2688
 L  c2689
 L  c2690
 L  c2691
 L  c2692
 L  c2693
 L  c2694
 L  c2695
 L  c2696
 L  c2697
 L  c2698
 L  c2699
 L  c2700
 L  c2701
 L  c2702
 L  c2703
 L  c2704
 L  c2705
 L  c2706
 L  c2707
 L  c2708
 L  c2709
 L  c2710
 L  c2711
 L  c2712
 L  c2713
 L  c2714
 L  c2715
 L  c2716
 L  c2717
 L  c2718
 L  c2719
 L  c2720
 L  c2721
 L  c2722
 L  c2723
 L  c2724
 L  c2725
 L  c2726
 L  c2727
 L  c2728
 L  c2729
 L  c2730
 L  c2731
 L  c2732
 L  c2733
 L  c2734
 L  c2735
 L  c2736
 L  c2737
 L  c2738
 L  c2739
 L  c2740
 L  c2741
 L  c2742
 L  c2743
 L  c2744
 L  c2745
 L  c2746
 L  c2747
 L  c2748
 L  c2749
 L  c2750
 L  c2751
 L  c2752
 L  c2753
 L  c2754
 L  c2755
 L  c2756
 L  c2757
 L  c2758
 L  c2759
 L  c2760
 L  c2761
 L  c2762
 L  c2763
 L  c2764
 L  c2765
 L  c2766
 L  c2767
 L  c2768
 L  c2769
 L  c2770
 L  c2771
 L  c2772
 L  c2773
 L  c2774
 L  c2775
 L  c2776
 L  c2777
 L  c2778
 L  c2779
 L  c2780
 L  c2781
 L  c2782
 L  c2783
 L  c2784
 L  c2785
 L  c2786
 L  c2787
 L  c2788
 L  c2789
 L  c2790
 L  c2791
 L  c2792
 L  c2793
 L  c2794
 L  c2795
 L  c2796
 L  c2797
 L  c2798
 L  c2799
 L  c2800
 L  c2801
 L  c2802
 L  c2803
 L  c2804
 L  c2805
 L  c2806
 L  c2807
 L  c2808
 L  c2809
 L  c2810
 L  c2811
 L  c2812
 L  c2813
 L  c2814
 L  c2815
 L  c2816
 L  c2817
 L  c2818
 L  c2819
 L  c2820
 L  c2821
 L  c2822
 L  c2823
 L  c2824
 L  c2825
 L  c2826
 L  c2827
 L  c2828
 L  c2829
 L  c2830
 L  c2831
 L  c2832
 L  c2833
 L  c2834
 L  c2835
 L  c2836
 L  c2837
 L  c2838
 L  c2839
 L  c2840
 L  c2841
 L  c2842
 L  c2843
 L  c2844
 L  c2845
 L  c2846
 L  c2847
 L  c2848
 L  c2849
 L  c2850
 L  c2851
 L  c2852
 L  c2853
 L  c2854
 L  c2855
 L  c2856
 L  c2857
 L  c2858
 L  c2859
 L  c2860
 L  c2861
 L  c2862
 L  c2863
 L  c2864
 L  c2865
 L  c2866
 L  c2867
 L  c2868
 L  c2869
 L  c2870
 L  c2871
 L  c2872
 L  c2873
 L  c2874
 L  c2875
 L  c2876
 L  c2877
 L  c2878
 L  c2879
 L  c2880
 L  c2881
 L  c2882
 L  c2883
 L  c2884
 L  c2885
 L  c2886
 L  c2887
 L  c2888
 L  c2889
 L  c2890
 L  c2891
 L  c2892
 L  c2893
 L  c2894
 L  c2895
 L  c2896
 L  c2897
 L  c2898
 L  c2899
 L  c2900
 L  c2901
 L  c2902
 L  c2903
 L  c2904
 L  c2905
 L  c2906
 L  c2907
 L  c2908
 L  c2909
 L  c2910
 L  c2911
 L  c2912
 L  c2913
 L  c2914
 L  c2915
 L  c2916
 L  c2917
 L  c2918
 L  c2919
 L  c2920
 L  c2921
 L  c2922
 L  c2923
 L  c2924
 L  c2925
 L  c2926
 L  c2927
 L  c2928
 L  c2929
 L  c2930
 L  c2931
 L  c2932
 L  c2933
 L  c2934
 L  c2935
 L  c2936
 L  c2937
 L  c2938
 L  c2939
 L  c2940
 L  c2941
 L  c2942
 L  c2943
 L  c2944
 L  c2945
 L  c2946
 L  c2947
 L  c2948
 L  c2949
 L  c2950
 L  c2951
 L  c2952
 L  c2953
 L  c2954
 L  c2955
 L  c2956
 L  c2957
 L  c2958
 L  c2959
 L  c2960
 L  c2961
 L  c2962
 L  c2963
 L  c2964
 L  c2965
 L  c2966
 L  c2967
 L  c2968
 L  c2969
 L  c2970
 L  c2971
 L  c2972
 L  c2973
 L  c2974
 L  c2975
 L  c2976
 L  c2977
 L  c2978
 L  c2979
 L  c2980
 L  c2981
 L  c2982
 L  c2983
 L  c2984
 L  c2985
 L  c2986
 L  c2987
 L  c2988
 L  c2989
 L  c2990
 L  c2991
 L  c2992
 L  c2993
 L  c2994
 L  c2995
 L  c2996
 L  c2997
 L  c2998
 L  c2999
 L  c3000
 L  c3001
 L  c3002
 L  c3003
 L  c3004
 L  c3005
 L  c3006
 L  c3007
 L  c3008
 L  c3009
 L  c3010
 L  c3011
 L  c3012
 L  c3013
 L  c3014
 L  c3015
 L  c3016
 L  c3017
 L  c3018
 L  c3019
 L  c3020
 L  c3021
 L  c3022
 L  c3023
 L  c3024
 L  c3025
 L  c3026
 L  c3027
 L  c3028
 L  c3029
 L  c3030
 L  c3031
 L  c3032
 L  c3033
 L  c3034
 L  c3035
 L  c3036
 L  c3037
 L  c3038
 L  c3039
 L  c3040
 L  c3041
 L  c3042
 L  c3043
 L  c3044
 L  c3045
 L  c3046
 L  c3047
 L  c3048
 L  c3049
 L  c3050
 L  c3051
 L  c3052
 L  c3053
 L  c3054
 L  c3055
 L  c3056
 L  c3057
 L  c3058
 L  c3059
 L  c3060
 L  c3061
 L  c3062
 L  c3063
 L  c3064
 L  c3065
 L  c3066
 L  c3067
 L  c3068
 L  c3069
 L  c3070
 L  c3071
 L  c3072
 L  c3073
 L  c3074
 L  c3075
 L  c3076
 L  c3077
 L  c3078
 L  c3079
 L  c3080
 L  c3081
 L  c3082
 L  c3083
 L  c3084
 L  c3085
 L  c3086
 L  c3087
 L  c3088
 L  c3089
 L  c3090
 L  c3091
 L  c3092
 L  c3093
 L  c3094
 L  c3095
 L  c3096
 L  c3097
 L  c3098
 L  c3099
 L  c3100
 L  c3101
 L  c3102
 L  c3103
 L  c3104
 L  c3105
 L  c3106
 L  c3107
 L  c3108
 L  c3109
 L  c3110
 L  c3111
 L  c3112
 L  c3113
 L  c3114
 L  c3115
 L  c3116
 L  c3117
 L  c3118
 L  c3119
 L  c3120
 L  c3121
 L  c3122
 L  c3123
 L  c3124
 L  c3125
 L  c3126
 L  c3127
 L  c3128
 L  c3129
 L  c3130
 L  c3131
 L  c3132
 L  c3133
 L  c3134
 L  c3135
 L  c3136
 L  c3137
 L  c3138
 L  c3139
 L  c3140
 L  c3141
 L  c3142
 L  c3143
 L  c3144
 L  c3145
 L  c3146
 L  c3147
 L  c3148
 L  c3149
 L  c3150
 L  c3151
 L  c3152
 L  c3153
 L  c3154
 L  c3155
 L  c3156
 L  c3157
 L  c3158
 L  c3159
 L  c3160
 L  c3161
 L  c3162
 L  c3163
 L  c3164
 L  c3165
 L  c3166
 L  c3167
 L  c3168
 L  c3169
 L  c3170
 L  c3171
 L  c3172
 L  c3173
 L  c3174
 L  c3175
 L  c3176
 L  c3177
 L  c3178
 L  c3179
 L  c3180
 L  c3181
 L  c3182
 L  c3183
 L  c3184
 L  c3185
 L  c3186
 L  c3187
 L  c3188
 L  c3189
 L  c3190
 L  c3191
 L  c3192
 L  c3193
 L  c3194
 L  c3195
 L  c3196
 L  c3197
 L  c3198
 L  c3199
 L  c3200
 L  c3201
 L  c3202
 L  c3203
 L  c3204
 L  c3205
 L  c3206
 L  c3207
 L  c3208
 L  c3209
 L  c3210
 L  c3211
 L  c3212
 L  c3213
 L  c3214
 L  c3215
 L  c3216
 L  c3217
 L  c3218
 L  c3219
 L  c3220
 L  c3221
 L  c3222
 L  c3223
 L  c3224
 L  c3225
 L  c3226
 L  c3227
 L  c3228
 L  c3229
 L  c3230
 L  c3231
 L  c3232
 L  c3233
 L  c3234
 L  c3235
 L  c3236
 L  c3237
 L  c3238
 L  c3239
 L  c3240
 L  c3241
 L  c3242
 L  c3243
 L  c3244
 L  c3245
 L  c3246
 L  c3247
 L  c3248
 L  c3249
 L  c3250
 L  c3251
 L  c3252
 L  c3253
 L  c3254
 L  c3255
 L  c3256
 L  c3257
 L  c3258
 L  c3259
 L  c3260
 L  c3261
 L  c3262
 L  c3263
 L  c3264
 L  c3265
 L  c3266
 L  c3267
 L  c3268
 L  c3269
 L  c3270
 L  c3271
 L  c3272
 L  c3273
 L  c3274
 L  c3275
 L  c3276
 L  c3277
 L  c3278
 L  c3279
 L  c3280
 L  c3281
 L  c3282
 L  c3283
 L  c3284
 L  c3285
 L  c3286
 L  c3287
 L  c3288
 L  c3289
 L  c3290
 L  c3291
 L  c3292
 L  c3293
 L  c3294
 L  c3295
 L  c3296
 L  c3297
 L  c3298
 L  c3299
 L  c3300
 L  c3301
 L  c3302
 L  c3303
 L  c3304
 L  c3305
 L  c3306
 L  c3307
 L  c3308
 L  c3309
 L  c3310
 L  c3311
 L  c3312
 L  c3313
 L  c3314
 L  c3315
 L  c3316
 L  c3317
 L  c3318
 L  c3319
 L  c3320
 L  c3321
 L  c3322
 L  c3323
 L  c3324
 L  c3325
 L  c3326
 L  c3327
 L  c3328
 L  c3329
 L  c3330
 L  c3331
 L  c3332
 L  c3333
 L  c3334
 L  c3335
 L  c3336
 L  c3337
 L  c3338
 L  c3339
 L  c3340
 L  c3341
 L  c3342
 L  c3343
 L  c3344
 L  c3345
 L  c3346
 L  c3347
 L  c3348
 L  c3349
 L  c3350
 L  c3351
 L  c3352
 L  c3353
 L  c3354
 L  c3355
 L  c3356
 L  c3357
 L  c3358
 L  c3359
 L  c3360
 L  c3361
 L  c3362
 L  c3363
 L  c3364
 L  c3365
 L  c3366
 L  c3367
 L  c3368
 L  c3369
 L  c3370
 L  c3371
 L  c3372
 L  c3373
 L  c3374
 L  c3375
 L  c3376
 L  c3377
 L  c3378
 L  c3379
 L  c3380
 L  c3381
 L  c3382
 L  c3383
 L  c3384
 L  c3385
 L  c3386
 L  c3387
 L  c3388
 L  c3389
 L  c3390
 L  c3391
 L  c3392
 L  c3393
 L  c3394
 L  c3395
 L  c3396
 L  c3397
 L  c3398
 L  c3399
 L  c3400
 L  c3401
 L  c3402
 L  c3403
 L  c3404
 L  c3405
 L  c3406
 L  c3407
 L  c3408
 L  c3409
 L  c3410
 L  c3411
 L  c3412
 L  c3413
 L  c3414
 L  c3415
 L  c3416
 L  c3417
 L  c3418
 L  c3419
 L  c3420
 L  c3421
 L  c3422
 L  c3423
 L  c3424
 L  c3425
 L  c3426
 L  c3427
 L  c3428
 L  c3429
 L  c3430
 L  c3431
 L  c3432
 L  c3433
 L  c3434
 L  c3435
 L  c3436
 L  c3437
 L  c3438
 L  c3439
 L  c3440
 L  c3441
 L  c3442
 L  c3443
 L  c3444
 L  c3445
 L  c3446
 L  c3447
 L  c3448
 L  c3449
 L  c3450
 L  c3451
 L  c3452
 L  c3453
 L  c3454
 L  c3455
 L  c3456
 L  c3457
 L  c3458
 L  c3459
 L  c3460
 L  c3461
 L  c3462
 L  c3463
 L  c3464
 L  c3465
 L  c3466
 L  c3467
 L  c3468
 L  c3469
 L  c3470
 L  c3471
 L  c3472
 L  c3473
 L  c3474
 L  c3475
 L  c3476
 L  c3477
 L  c3478
 L  c3479
 L  c3480
 L  c3481
 L  c3482
 L  c3483
 L  c3484
 L  c3485
 L  c3486
 L  c3487
 L  c3488
 L  c3489
 L  c3490
 L  c3491
 L  c3492
 L  c3493
 L  c3494
 L  c3495
 L  c3496
 L  c3497
 L  c3498
 L  c3499
 L  c3500
 L  c3501
 L  c3502
 L  c3503
 L  c3504
 L  c3505
 L  c3506
 L  c3507
 L  c3508
 L  c3509
 L  c3510
 L  c3511
 L  c3512
 L  c3513
 L  c3514
 L  c3515
 L  c3516
 L  c3517
 L  c3518
 L  c3519
 L  c3520
 L  c3521
 L  c3522
 L  c3523
 L  c3524
 L  c3525
 L  c3526
 L  c3527
 L  c3528
 L  c3529
 L  c3530
 L  c3531
 L  c3532
 L  c3533
 L  c3534
 L  c3535
 L  c3536
 L  c3537
 L  c3538
 L  c3539
 L  c3540
 L  c3541
 L  c3542
 L  c3543
 L  c3544
 L  c3545
 L  c3546
 L  c3547
 L  c3548
 L  c3549
 L  c3550
 L  c3551
 L  c3552
 L  c3553
 L  c3554
 L  c3555
 L  c3556
 L  c3557
 L  c3558
 L  c3559
 L  c3560
 L  c3561
 L  c3562
 L  c3563
 L  c3564
 L  c3565
 L  c3566
 L  c3567
 L  c3568
 L  c3569
 L  c3570
 L  c3571
 L  c3572
 L  c3573
 L  c3574
 L  c3575
 L  c3576
 L  c3577
 L  c3578
 L  c3579
 L  c3580
 L  c3581
 L  c3582
 L  c3583
 L  c3584
 L  c3585
 L  c3586
 L  c3587
 L  c3588
 L  c3589
 L  c3590
 L  c3591
 L  c3592
 L  c3593
 L  c3594
 L  c3595
 L  c3596
 L  c3597
 L  c3598
 L  c3599
 L  c3600
 L  c3601
 L  c3602
 L  c3603
 L  c3604
 L  c3605
 L  c3606
 L  c3607
 L  c3608
 L  c3609
 L  c3610
 L  c3611
 L  c3612
 L  c3613
 L  c3614
 L  c3615
 L  c3616
 L  c3617
 L  c3618
 L  c3619
 L  c3620
 L  c3621
 L  c3622
 L  c3623
 L  c3624
 L  c3625
 L  c3626
 L  c3627
 L  c3628
 L  c3629
 L  c3630
 L  c3631
 L  c3632
 L  c3633
 L  c3634
 L  c3635
 L  c3636
 L  c3637
 L  c3638
 L  c3639
 L  c3640
 L  c3641
 L  c3642
 L  c3643
 L  c3644
 L  c3645
 L  c3646
 L  c3647
 L  c3648
 L  c3649
 L  c3650
 L  c3651
 L  c3652
 L  c3653
 L  c3654
 L  c3655
 L  c3656
 L  c3657
 L  c3658
 L  c3659
 L  c3660
 L  c3661
 L  c3662
 L  c3663
 L  c3664
 L  c3665
 L  c3666
 L  c3667
 L  c3668
 L  c3669
 L  c3670
 L  c3671
 L  c3672
 L  c3673
 L  c3674
 L  c3675
 L  c3676
 L  c3677
 L  c3678
 L  c3679
 L  c3680
 L  c3681
 L  c3682
 L  c3683
 L  c3684
 L  c3685
 L  c3686
 L  c3687
 L  c3688
 L  c3689
 L  c3690
 L  c3691
 L  c3692
 L  c3693
 L  c3694
 L  c3695
 L  c3696
 L  c3697
 L  c3698
 L  c3699
 L  c3700
 L  c3701
 L  c3702
 L  c3703
 L  c3704
 L  c3705
 L  c3706
 L  c3707
 L  c3708
 L  c3709
 L  c3710
 L  c3711
 L  c3712
 L  c3713
 L  c3714
 L  c3715
 L  c3716
 L  c3717
 L  c3718
 L  c3719
 L  c3720
 L  c3721
 L  c3722
 L  c3723
 L  c3724
 L  c3725
 L  c3726
 L  c3727
 L  c3728
 L  c3729
 L  c3730
 L  c3731
 L  c3732
 L  c3733
 L  c3734
 L  c3735
 L  c3736
 L  c3737
 L  c3738
 L  c3739
 L  c3740
 L  c3741
 L  c3742
 L  c3743
 L  c3744
 L  c3745
 L  c3746
 L  c3747
 L  c3748
 L  c3749
 L  c3750
 L  c3751
 L  c3752
 L  c3753
 L  c3754
 L  c3755
 L  c3756
 L  c3757
 L  c3758
 L  c3759
 L  c3760
 L  c3761
 L  c3762
 L  c3763
 L  c3764
 L  c3765
 L  c3766
 L  c3767
 L  c3768
 L  c3769
 L  c3770
 L  c3771
 L  c3772
 L  c3773
 L  c3774
 L  c3775
 L  c3776
 L  c3777
 L  c3778
 L  c3779
 L  c3780
 L  c3781
 L  c3782
 L  c3783
 L  c3784
 L  c3785
 L  c3786
 L  c3787
 L  c3788
 L  c3789
 L  c3790
 L  c3791
 L  c3792
 L  c3793
 L  c3794
 L  c3795
 L  c3796
 L  c3797
 L  c3798
 L  c3799
 L  c3800
 L  c3801
 L  c3802
 L  c3803
 L  c3804
 L  c3805
 L  c3806
 L  c3807
 L  c3808
 L  c3809
 L  c3810
 L  c3811
 L  c3812
 L  c3813
 L  c3814
 L  c3815
 L  c3816
 L  c3817
 L  c3818
 L  c3819
 L  c3820
 L  c3821
 L  c3822
 L  c3823
 L  c3824
 L  c3825
 L  c3826
 L  c3827
 L  c3828
 L  c3829
 L  c3830
 L  c3831
 L  c3832
 L  c3833
 L  c3834
 L  c3835
 L  c3836
 L  c3837
 L  c3838
 L  c3839
 L  c3840
 L  c3841
 L  c3842
 L  c3843
 L  c3844
 L  c3845
 L  c3846
 L  c3847
 L  c3848
 L  c3849
 L  c3850
 L  c3851
 L  c3852
 L  c3853
 L  c3854
 L  c3855
 L  c3856
 L  c3857
 L  c3858
 L  c3859
 L  c3860
 L  c3861
 L  c3862
 L  c3863
 L  c3864
 L  c3865
 L  c3866
 L  c3867
 L  c3868
 L  c3869
 L  c3870
 L  c3871
 L  c3872
 L  c3873
 L  c3874
 L  c3875
 L  c3876
 L  c3877
 L  c3878
 L  c3879
 L  c3880
 L  c3881
 L  c3882
 L  c3883
 L  c3884
 L  c3885
 L  c3886
 L  c3887
 L  c3888
 L  c3889
 L  c3890
 L  c3891
 L  c3892
 L  c3893
 L  c3894
 L  c3895
 L  c3896
 L  c3897
 L  c3898
 L  c3899
 L  c3900
 L  c3901
 L  c3902
 L  c3903
 L  c3904
 L  c3905
 L  c3906
 L  c3907
 L  c3908
 L  c3909
 L  c3910
 L  c3911
 L  c3912
 L  c3913
 L  c3914
 L  c3915
 L  c3916
 L  c3917
 L  c3918
 L  c3919
 L  c3920
 L  c3921
 L  c3922
 L  c3923
 L  c3924
 L  c3925
 L  c3926
 L  c3927
 L  c3928
 L  c3929
 L  c3930
 L  c3931
 L  c3932
 L  c3933
 L  c3934
 L  c3935
 L  c3936
 L  c3937
 L  c3938
 L  c3939
 L  c3940
 L  c3941
 L  c3942
 L  c3943
 L  c3944
 L  c3945
 L  c3946
 L  c3947
 L  c3948
 L  c3949
 L  c3950
 L  c3951
 L  c3952
 L  c3953
 L  c3954
 L  c3955
 L  c3956
 L  c3957
 L  c3958
 L  c3959
 L  c3960
 L  c3961
 L  c3962
 L  c3963
 L  c3964
 L  c3965
 L  c3966
 L  c3967
 L  c3968
 L  c3969
 L  c3970
 L  c3971
 L  c3972
 L  c3973
 L  c3974
 L  c3975
 L  c3976
 L  c3977
 L  c3978
 L  c3979
 L  c3980
 L  c3981
 L  c3982
 L  c3983
 L  c3984
 L  c3985
 L  c3986
 L  c3987
 L  c3988
 L  c3989
 L  c3990
 L  c3991
 L  c3992
 L  c3993
 L  c3994
 L  c3995
 L  c3996
 L  c3997
 L  c3998
 L  c3999
 L  c4000
 L  c4001
 L  c4002
 L  c4003
 L  c4004
 L  c4005
 L  c4006
 L  c4007
 L  c4008
 L  c4009
 L  c4010
 L  c4011
 L  c4012
 L  c4013
 L  c4014
 L  c4015
 L  c4016
 L  c4017
 L  c4018
 L  c4019
 L  c4020
 L  c4021
 L  c4022
 L  c4023
 L  c4024
 L  c4025
 L  c4026
 L  c4027
 L  c4028
 L  c4029
 L  c4030
 L  c4031
 L  c4032
 L  c4033
 L  c4034
 L  c4035
 L  c4036
 L  c4037
 L  c4038
 L  c4039
 L  c4040
 L  c4041
 L  c4042
 L  c4043
 L  c4044
 L  c4045
 L  c4046
 L  c4047
 L  c4048
 L  c4049
 L  c4050
 L  c4051
 L  c4052
 L  c4053
 L  c4054
 L  c4055
 L  c4056
 L  c4057
 L  c4058
 L  c4059
 L  c4060
 L  c4061
 L  c4062
 L  c4063
 L  c4064
 L  c4065
 L  c4066
 L  c4067
 L  c4068
 L  c4069
 L  c4070
 L  c4071
 L  c4072
 L  c4073
 L  c4074
 L  c4075
 L  c4076
 L  c4077
 L  c4078
 L  c4079
 L  c4080
 L  c4081
 L  c4082
 L  c4083
 L  c4084
 L  c4085
 L  c4086
 L  c4087
 L  c4088
 L  c4089
 L  c4090
 L  c4091
 L  c4092
 L  c4093
 L  c4094
 L  c4095
 L  c4096
 L  c4097
 L  c4098
 L  c4099
 L  c4100
 L  c4101
 L  c4102
 L  c4103
 L  c4104
 L  c4105
 L  c4106
 L  c4107
 L  c4108
 L  c4109
 L  c4110
 L  c4111
 L  c4112
 L  c4113
 L  c4114
 L  c4115
 L  c4116
 L  c4117
 L  c4118
 L  c4119
 L  c4120
 L  c4121
 L  c4122
 L  c4123
 L  c4124
 L  c4125
 L  c4126
 L  c4127
 L  c4128
 L  c4129
 L  c4130
 L  c4131
 L  c4132
 L  c4133
 L  c4134
 L  c4135
 L  c4136
 L  c4137
 L  c4138
 L  c4139
 L  c4140
 L  c4141
 L  c4142
 L  c4143
 L  c4144
 L  c4145
 L  c4146
 L  c4147
 L  c4148
 L  c4149
 L  c4150
 L  c4151
 L  c4152
 L  c4153
 L  c4154
 L  c4155
 L  c4156
 L  c4157
 L  c4158
 L  c4159
 L  c4160
 L  c4161
 L  c4162
 L  c4163
 L  c4164
 L  c4165
 L  c4166
 L  c4167
 L  c4168
 L  c4169
 L  c4170
 L  c4171
 L  c4172
 L  c4173
 L  c4174
 L  c4175
 L  c4176
 L  c4177
 L  c4178
 L  c4179
 L  c4180
 L  c4181
 L  c4182
 L  c4183
 L  c4184
 L  c4185
 L  c4186
 L  c4187
 L  c4188
 L  c4189
 L  c4190
 L  c4191
 L  c4192
 L  c4193
 L  c4194
 L  c4195
 L  c4196
 L  c4197
 L  c4198
 L  c4199
 L  c4200
 L  c4201
 L  c4202
 L  c4203
 L  c4204
 L  c4205
 L  c4206
 L  c4207
 L  c4208
 L  c4209
 L  c4210
 L  c4211
 L  c4212
 L  c4213
 L  c4214
 L  c4215
 L  c4216
 L  c4217
 L  c4218
 L  c4219
 L  c4220
 L  c4221
 L  c4222
 L  c4223
 L  c4224
 L  c4225
 L  c4226
 L  c4227
 L  c4228
 L  c4229
 L  c4230
 L  c4231
 L  c4232
 L  c4233
 L  c4234
 L  c4235
 L  c4236
 L  c4237
 L  c4238
 L  c4239
 L  c4240
 L  c4241
 L  c4242
 L  c4243
 L  c4244
 L  c4245
 L  c4246
 L  c4247
 L  c4248
 L  c4249
 L  c4250
 L  c4251
 L  c4252
 L  c4253
 L  c4254
 L  c4255
 L  c4256
 L  c4257
 L  c4258
 L  c4259
 L  c4260
 L  c4261
 L  c4262
 L  c4263
 L  c4264
 L  c4265
 L  c4266
 L  c4267
 L  c4268
 L  c4269
 L  c4270
 L  c4271
 L  c4272
 L  c4273
 L  c4274
 L  c4275
 L  c4276
 L  c4277
 L  c4278
 L  c4279
 L  c4280
 L  c4281
 L  c4282
 L  c4283
 L  c4284
 L  c4285
 L  c4286
 L  c4287
 L  c4288
 L  c4289
 L  c4290
 L  c4291
 L  c4292
 L  c4293
 L  c4294
 L  c4295
 L  c4296
 L  c4297
 L  c4298
 L  c4299
 L  c4300
 L  c4301
 L  c4302
 L  c4303
 L  c4304
 L  c4305
 L  c4306
 L  c4307
 L  c4308
 L  c4309
 L  c4310
 L  c4311
 L  c4312
 L  c4313
 L  c4314
 L  c4315
 L  c4316
 L  c4317
 L  c4318
 L  c4319
 L  c4320
 L  c4321
 L  c4322
 L  c4323
 L  c4324
 L  c4325
 L  c4326
 L  c4327
 L  c4328
 L  c4329
 L  c4330
 L  c4331
 L  c4332
 L  c4333
 L  c4334
 L  c4335
 L  c4336
 L  c4337
 L  c4338
 L  c4339
 L  c4340
 L  c4341
 L  c4342
 L  c4343
 L  c4344
 L  c4345
 L  c4346
 L  c4347
 L  c4348
 L  c4349
 L  c4350
 L  c4351
 L  c4352
 L  c4353
 L  c4354
 L  c4355
 L  c4356
 L  c4357
 L  c4358
 L  c4359
 L  c4360
 L  c4361
 L  c4362
 L  c4363
 L  c4364
 L  c4365
 L  c4366
 L  c4367
 L  c4368
 L  c4369
 L  c4370
 L  c4371
 L  c4372
 L  c4373
 L  c4374
 L  c4375
 L  c4376
 L  c4377
 L  c4378
 L  c4379
 L  c4380
 L  c4381
 L  c4382
 L  c4383
 L  c4384
 L  c4385
 L  c4386
 L  c4387
 L  c4388
 L  c4389
 L  c4390
 L  c4391
 L  c4392
 L  c4393
 L  c4394
 L  c4395
 L  c4396
 L  c4397
 L  c4398
 L  c4399
 L  c4400
 L  c4401
 L  c4402
 L  c4403
 L  c4404
 L  c4405
 L  c4406
 L  c4407
 L  c4408
 L  c4409
 L  c4410
 L  c4411
 L  c4412
 L  c4413
 L  c4414
 L  c4415
 L  c4416
 L  c4417
 L  c4418
 L  c4419
 L  c4420
 L  c4421
 L  c4422
 L  c4423
 L  c4424
 L  c4425
 L  c4426
 L  c4427
 L  c4428
 L  c4429
 L  c4430
 L  c4431
 L  c4432
 L  c4433
 L  c4434
 L  c4435
 L  c4436
 L  c4437
 L  c4438
 L  c4439
 L  c4440
 L  c4441
 L  c4442
 L  c4443
 L  c4444
 L  c4445
 L  c4446
 L  c4447
 L  c4448
 L  c4449
 L  c4450
 L  c4451
 L  c4452
 L  c4453
 L  c4454
 L  c4455
 L  c4456
 L  c4457
 L  c4458
 L  c4459
 L  c4460
 L  c4461
 L  c4462
 L  c4463
 L  c4464
 L  c4465
 L  c4466
 L  c4467
 L  c4468
 L  c4469
 L  c4470
 L  c4471
 L  c4472
 L  c4473
 L  c4474
 L  c4475
 L  c4476
 L  c4477
 L  c4478
 L  c4479
 L  c4480
 L  c4481
 L  c4482
 L  c4483
 L  c4484
 L  c4485
 L  c4486
 L  c4487
 L  c4488
 L  c4489
 L  c4490
 L  c4491
 L  c4492
 L  c4493
 L  c4494
 L  c4495
 L  c4496
 L  c4497
 L  c4498
 L  c4499
 L  c4500
 L  c4501
 L  c4502
 L  c4503
 L  c4504
 L  c4505
 L  c4506
 L  c4507
 L  c4508
 L  c4509
 L  c4510
 L  c4511
 L  c4512
 L  c4513
 L  c4514
 L  c4515
 L  c4516
 L  c4517
 L  c4518
 L  c4519
 L  c4520
 L  c4521
 L  c4522
 L  c4523
 L  c4524
 L  c4525
 L  c4526
 L  c4527
 L  c4528
 L  c4529
 L  c4530
 L  c4531
 L  c4532
 L  c4533
 L  c4534
 L  c4535
 L  c4536
 L  c4537
 L  c4538
 L  c4539
 L  c4540
 L  c4541
 L  c4542
 L  c4543
 L  c4544
 L  c4545
 L  c4546
 L  c4547
 L  c4548
 L  c4549
 L  c4550
 L  c4551
 L  c4552
 L  c4553
 L  c4554
 L  c4555
 L  c4556
 L  c4557
 L  c4558
 L  c4559
 L  c4560
 L  c4561
 L  c4562
 L  c4563
 L  c4564
 L  c4565
 L  c4566
 L  c4567
 L  c4568
 L  c4569
 L  c4570
 L  c4571
 L  c4572
 L  c4573
 L  c4574
 L  c4575
 L  c4576
 L  c4577
 L  c4578
 L  c4579
 L  c4580
 L  c4581
 L  c4582
 L  c4583
 L  c4584
 L  c4585
 L  c4586
 L  c4587
 L  c4588
 L  c4589
 L  c4590
 L  c4591
 L  c4592
 L  c4593
 L  c4594
 L  c4595
 L  c4596
 L  c4597
 L  c4598
 L  c4599
 L  c4600
 L  c4601
 L  c4602
 L  c4603
 L  c4604
 L  c4605
 L  c4606
 L  c4607
 L  c4608
 L  c4609
 L  c4610
 L  c4611
 L  c4612
 L  c4613
 L  c4614
 L  c4615
 L  c4616
 L  c4617
 L  c4618
 L  c4619
 L  c4620
 L  c4621
 L  c4622
 L  c4623
 L  c4624
 L  c4625
 L  c4626
 L  c4627
 L  c4628
 L  c4629
 L  c4630
 L  c4631
 L  c4632
 L  c4633
 L  c4634
 L  c4635
 L  c4636
 L  c4637
 L  c4638
 L  c4639
 L  c4640
 L  c4641
 L  c4642
 L  c4643
 L  c4644
 L  c4645
 L  c4646
 L  c4647
 L  c4648
 L  c4649
 L  c4650
 L  c4651
 L  c4652
 L  c4653
 L  c4654
 L  c4655
 L  c4656
 L  c4657
 L  c4658
 L  c4659
 L  c4660
 L  c4661
 L  c4662
 L  c4663
 L  c4664
 L  c4665
 L  c4666
 L  c4667
 L  c4668
 L  c4669
 L  c4670
 L  c4671
 L  c4672
 L  c4673
 L  c4674
 L  c4675
 L  c4676
 L  c4677
 L  c4678
 L  c4679
 L  c4680
 L  c4681
 L  c4682
 L  c4683
 L  c4684
 L  c4685
 L  c4686
 L  c4687
 L  c4688
 L  c4689
 L  c4690
 L  c4691
 L  c4692
 L  c4693
 L  c4694
 L  c4695
 L  c4696
 L  c4697
 L  c4698
 L  c4699
 L  c4700
 L  c4701
 L  c4702
 L  c4703
 L  c4704
 L  c4705
 L  c4706
 L  c4707
 L  c4708
 L  c4709
 L  c4710
 L  c4711
 L  c4712
 L  c4713
 L  c4714
 L  c4715
 L  c4716
 L  c4717
 L  c4718
 L  c4719
 L  c4720
 L  c4721
 L  c4722
 L  c4723
 L  c4724
 L  c4725
 L  c4726
 L  c4727
 L  c4728
 L  c4729
 L  c4730
 L  c4731
 L  c4732
 L  c4733
 L  c4734
 L  c4735
 L  c4736
 L  c4737
 L  c4738
 L  c4739
 L  c4740
 L  c4741
 L  c4742
 L  c4743
 L  c4744
 L  c4745
 L  c4746
 L  c4747
 L  c4748
 L  c4749
 L  c4750
 L  c4751
 L  c4752
 L  c4753
 L  c4754
 L  c4755
 L  c4756
 L  c4757
 L  c4758
 L  c4759
 L  c4760
 L  c4761
 L  c4762
 L  c4763
 L  c4764
 L  c4765
 L  c4766
 L  c4767
 L  c4768
 L  c4769
 L  c4770
 L  c4771
 L  c4772
 L  c4773
 L  c4774
 L  c4775
 L  c4776
 L  c4777
 L  c4778
 L  c4779
 L  c4780
 L  c4781
 L  c4782
 L  c4783
 L  c4784
 L  c4785
 L  c4786
 L  c4787
 L  c4788
 L  c4789
 L  c4790
 L  c4791
 L  c4792
 L  c4793
 L  c4794
 L  c4795
 L  c4796
 L  c4797
 L  c4798
 L  c4799
 L  c4800
 L  c4801
 L  c4802
 L  c4803
 L  c4804
 L  c4805
 L  c4806
 L  c4807
 L  c4808
 L  c4809
 L  c4810
 L  c4811
 L  c4812
 L  c4813
 L  c4814
 L  c4815
 L  c4816
 L  c4817
 L  c4818
 L  c4819
 L  c4820
 L  c4821
 L  c4822
 L  c4823
 L  c4824
 L  c4825
 L  c4826
 L  c4827
 L  c4828
 L  c4829
 L  c4830
 L  c4831
 L  c4832
 L  c4833
 L  c4834
 L  c4835
 L  c4836
 L  c4837
 L  c4838
 L  c4839
 L  c4840
 L  c4841
 L  c4842
 L  c4843
 L  c4844
 L  c4845
 L  c4846
 L  c4847
 L  c4848
 L  c4849
 L  c4850
 L  c4851
 L  c4852
 L  c4853
 L  c4854
 L  c4855
 L  c4856
 L  c4857
 L  c4858
 L  c4859
 L  c4860
 L  c4861
 L  c4862
 L  c4863
 L  c4864
 L  c4865
 L  c4866
 L  c4867
 L  c4868
 L  c4869
 L  c4870
 L  c4871
 L  c4872
 L  c4873
 L  c4874
 L  c4875
 L  c4876
 L  c4877
 L  c4878
 L  c4879
 L  c4880
 L  c4881
 L  c4882
 L  c4883
 L  c4884
 L  c4885
 L  c4886
 L  c4887
 L  c4888
 L  c4889
 L  c4890
 L  c4891
 L  c4892
 L  c4893
 L  c4894
 L  c4895
 L  c4896
 L  c4897
 L  c4898
 L  c4899
 L  c4900
 L  c4901
 L  c4902
 L  c4903
 L  c4904
 L  c4905
 L  c4906
 L  c4907
 L  c4908
 L  c4909
 L  c4910
 L  c4911
 L  c4912
 L  c4913
 L  c4914
 L  c4915
 L  c4916
 L  c4917
 L  c4918
 L  c4919
 L  c4920
 L  c4921
 L  c4922
 L  c4923
 L  c4924
 L  c4925
 L  c4926
 L  c4927
 L  c4928
 L  c4929
 L  c4930
 L  c4931
 L  c4932
 L  c4933
 L  c4934
 L  c4935
 L  c4936
 L  c4937
 L  c4938
 L  c4939
 L  c4940
 L  c4941
 L  c4942
 L  c4943
 L  c4944
 L  c4945
 L  c4946
 L  c4947
 L  c4948
 L  c4949
 L  c4950
 L  c4951
 L  c4952
 L  c4953
 L  c4954
 L  c4955
 L  c4956
 L  c4957
 L  c4958
 L  c4959
 L  c4960
 L  c4961
 L  c4962
 L  c4963
 L  c4964
 L  c4965
 L  c4966
 L  c4967
 L  c4968
 L  c4969
 L  c4970
 L  c4971
 L  c4972
 L  c4973
 L  c4974
 L  c4975
 L  c4976
 L  c4977
 L  c4978
 L  c4979
 L  c4980
 L  c4981
 L  c4982
 L  c4983
 L  c4984
 L  c4985
 L  c4986
 L  c4987
 L  c4988
 L  c4989
 L  c4990
 L  c4991
 L  c4992
 L  c4993
 L  c4994
 L  c4995
 L  c4996
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c1        1
    x[1]      c2386     -1
    x[1]      c4716     219
    x[1]      c4717     -219
    x[1]      c4726     75
    x[1]      c4727     -75
    x[1]      OBJ       -2528.7788298086
    x[2]      c10       1
    x[2]      c1336     -1
    x[2]      c4716     328
    x[2]      c4717     -328
    x[2]      c4726     215
    x[2]      c4727     -215
    x[2]      OBJ       -5161.48007728057
    x[3]      c19       1
    x[3]      c1506     -1
    x[3]      c3666     -1
    x[3]      c4716     545
    x[3]      c4717     -545
    x[3]      c4726     368
    x[3]      c4727     -368
    x[3]      OBJ       -11789.4209371442
    x[4]      c28       1
    x[4]      c1066     -1
    x[4]      c1676     -1
    x[4]      c4716     435
    x[4]      c4717     -435
    x[4]      c4726     400
    x[4]      c4727     -400
    x[4]      OBJ       -17978.5782557625
    x[5]      c37       1
    x[5]      c1116     -1
    x[5]      c4716     247
    x[5]      c4717     -247
    x[5]      c4726     216
    x[5]      c4727     -216
    x[5]      OBJ       -8013.57309537519
    x[6]      c46       1
    x[6]      c1966     -1
    x[6]      c4716     82
    x[6]      c4717     -82
    x[6]      c4726     27
    x[6]      c4727     -27
    x[6]      OBJ       -841.771583073273
    x[7]      c55       1
    x[7]      c1076     -1
    x[7]      c1236     -1
    x[7]      c2506     -1
    x[7]      c4716     526
    x[7]      c4717     -526
    x[7]      c4726     314
    x[7]      c4727     -314
    x[7]      OBJ       -7799.95479240049
    x[8]      c64       1
    x[8]      c1036     1
    x[8]      c1046     1
    x[8]      c1056     1
    x[8]      c1286     -1
    x[8]      c4716     693
    x[8]      c4717     -693
    x[8]      c4726     693
    x[8]      c4727     -693
    x[8]      OBJ       -59697.6554799564
    x[9]      c73       1
    x[9]      c1036     -1
    x[9]      c1066     1
    x[9]      c1076     1
    x[9]      c1086     1
    x[9]      c1096     1
    x[9]      c1106     1
    x[9]      c1366     -1
    x[9]      c2696     -1
    x[9]      c4716     1944
    x[9]      c4717     -1944
    x[9]      c4726     1944
    x[9]      c4727     -1944
    x[9]      OBJ       -89257.8098375363
    x[10]     c82       1
    x[10]     c1086     -1
    x[10]     c1126     -1
    x[10]     c1416     -1
    x[10]     c2776     -1
    x[10]     c4716     907
    x[10]     c4717     -907
    x[10]     c4726     574
    x[10]     c4727     -574
    x[10]     OBJ       -25842.0411922906
    x[11]     c91       1
    x[11]     c1046     -1
    x[11]     c1116     1
    x[11]     c1126     1
    x[11]     c1136     1
    x[11]     c1146     1
    x[11]     c1156     1
    x[11]     c1536     -1
    x[11]     c4716     1296
    x[11]     c4717     -1296
    x[11]     c4726     1128
    x[11]     c4727     -1128
    x[11]     OBJ       -28456.2673432891
    x[12]     c100      1
    x[12]     c1096     -1
    x[12]     c1136     -1
    x[12]     c1166     -1
    x[12]     c1586     -1
    x[12]     c1976     -1
    x[12]     c2946     -1
    x[12]     c4716     1043
    x[12]     c4717     -1043
    x[12]     c4726     864
    x[12]     c4727     -864
    x[12]     OBJ       -23629.6483895905
    x[13]     c109      1
    x[13]     c1166     1
    x[13]     c1176     1
    x[13]     c1186     1
    x[13]     c1196     1
    x[13]     c1706     -1
    x[13]     c2146     -1
    x[13]     c4716     1332
    x[13]     c4717     -1332
    x[13]     c4726     1330
    x[13]     c4727     -1330
    x[13]     OBJ       -54155.1265379101
    x[14]     c118      1
    x[14]     c1146     -1
    x[14]     c1176     -1
    x[14]     c1756     -1
    x[14]     c2216     -1
    x[14]     c4716     1186
    x[14]     c4717     -1186
    x[14]     c4726     864
    x[14]     c4727     -864
    x[14]     OBJ       -32770.2023698484
    x[15]     c127      1
    x[15]     c1186     -1
    x[15]     c1836     -1
    x[15]     c2516     -1
    x[15]     c4716     984
    x[15]     c4717     -984
    x[15]     c4726     723
    x[15]     c4727     -723
    x[15]     OBJ       -16269.6318319649
    x[16]     c136      1
    x[16]     c1246     -1
    x[16]     c1886     -1
    x[16]     c3246     -1
    x[16]     c4716     225
    x[16]     c4717     -225
    x[16]     c4726     20
    x[16]     c4727     -20
    x[16]     OBJ       65.8175311867991
    x[17]     c145      1
    x[17]     c1206     1
    x[17]     c1216     1
    x[17]     c1226     1
    x[17]     c1296     -1
    x[17]     c1926     -1
    x[17]     c4716     724
    x[17]     c4717     -724
    x[17]     c4726     724
    x[17]     c4727     -724
    x[17]     OBJ       -44455.7008893292
    x[18]     c154      1
    x[18]     c1206     -1
    x[18]     c1236     1
    x[18]     c1246     1
    x[18]     c1256     1
    x[18]     c1266     1
    x[18]     c1276     1
    x[18]     c1376     -1
    x[18]     c1996     -1
    x[18]     c3416     -1
    x[18]     c4716     1989
    x[18]     c4717     -1989
    x[18]     c4726     1989
    x[18]     c4727     -1989
    x[18]     OBJ       -38543.6700178132
    x[19]     c163      1
    x[19]     c1256     -1
    x[19]     c1426     -1
    x[19]     c2046     -1
    x[19]     c3496     -1
    x[19]     c4716     710
    x[19]     c4717     -710
    x[19]     c4726     382
    x[19]     c4727     -382
    x[19]     OBJ       -10784.8375663983
    x[20]     c172      1
    x[20]     c1286     1
    x[20]     c1296     1
    x[20]     c1306     1
    x[20]     c1316     1
    x[20]     c1326     1
    x[20]     c1336     1
    x[20]     c1346     1
    x[20]     c1356     1
    x[20]     c2096     -1
    x[20]     c4716     716
    x[20]     c4717     -716
    x[20]     c4726     716
    x[20]     c4727     -716
    x[20]     OBJ       -67318.63277527
    x[21]     c181      1
    x[21]     c1306     -1
    x[21]     c1366     1
    x[21]     c1376     1
    x[21]     c1386     1
    x[21]     c1396     1
    x[21]     c1406     1
    x[21]     c1466     -1
    x[21]     c2166     -1
    x[21]     c3656     -1
    x[21]     c4716     2876
    x[21]     c4717     -2876
    x[21]     c4726     2876
    x[21]     c4727     -2876
    x[21]     OBJ       -212925.486856943
    x[22]     c190      1
    x[22]     c1056     -1
    x[22]     c1216     -1
    x[22]     c1386     -1
    x[22]     c1416     1
    x[22]     c1426     1
    x[22]     c1436     1
    x[22]     c1446     1
    x[22]     c1456     1
    x[22]     c1546     -1
    x[22]     c2236     -1
    x[22]     c3726     -1
    x[22]     c4716     2595
    x[22]     c4717     -2595
    x[22]     c4726     2595
    x[22]     c4727     -2595
    x[22]     OBJ       -45552.6597424425
    x[23]     c199      1
    x[23]     c1106     -1
    x[23]     c1266     -1
    x[23]     c1436     -1
    x[23]     c1596     -1
    x[23]     c2286     -1
    x[23]     c3786     -1
    x[23]     c4716     1030
    x[23]     c4717     -1030
    x[23]     c4726     552
    x[23]     c4727     -552
    x[23]     OBJ       -6096.78183625087
    x[24]     c208      1
    x[24]     c1466     1
    x[24]     c1476     1
    x[24]     c1486     1
    x[24]     c1496     1
    x[24]     c1506     1
    x[24]     c1516     1
    x[24]     c1526     1
    x[24]     c2396     -1
    x[24]     c4716     1432
    x[24]     c4717     -1432
    x[24]     c4726     1432
    x[24]     c4727     -1432
    x[24]     OBJ       -124822.370549
    x[25]     c217      1
    x[25]     c1316     -1
    x[25]     c1476     -1
    x[25]     c1536     1
    x[25]     c1546     1
    x[25]     c1556     1
    x[25]     c1566     1
    x[25]     c1576     1
    x[25]     c1636     -1
    x[25]     c2456     -1
    x[25]     c4716     2864
    x[25]     c4717     -2864
    x[25]     c4726     2864
    x[25]     c4727     -2864
    x[25]     OBJ       -171010.111732719
    x[26]     c226      1
    x[26]     c1396     -1
    x[26]     c1556     -1
    x[26]     c1586     1
    x[26]     c1596     1
    x[26]     c1606     1
    x[26]     c1616     1
    x[26]     c1626     1
    x[26]     c1716     -1
    x[26]     c2546     -1
    x[26]     c4716     2600
    x[26]     c4717     -2600
    x[26]     c4726     2336
    x[26]     c4727     -2336
    x[26]     OBJ       -65286.3721631864
    x[27]     c235      1
    x[27]     c1156     -1
    x[27]     c1446     -1
    x[27]     c1606     -1
    x[27]     c1766     -1
    x[27]     c2596     -1
    x[27]     c3966     -1
    x[27]     c4716     1156
    x[27]     c4717     -1156
    x[27]     c4726     696
    x[27]     c4727     -696
    x[27]     OBJ       -15138.0321729638
    x[28]     c244      1
    x[28]     c1636     1
    x[28]     c1646     1
    x[28]     c1656     1
    x[28]     c1666     1
    x[28]     c1676     1
    x[28]     c1686     1
    x[28]     c1696     1
    x[28]     c2646     -1
    x[28]     c4716     716
    x[28]     c4717     -716
    x[28]     c4726     716
    x[28]     c4727     -716
    x[28]     OBJ       -62468.9199509795
    x[29]     c253      1
    x[29]     c1486     -1
    x[29]     c1646     -1
    x[29]     c1706     1
    x[29]     c1716     1
    x[29]     c1726     1
    x[29]     c1736     1
    x[29]     c1746     1
    x[29]     c2726     -1
    x[29]     c4716     2864
    x[29]     c4717     -2864
    x[29]     c4726     2864
    x[29]     c4727     -2864
    x[29]     OBJ       -193873.043618659
    x[30]     c262      1
    x[30]     c1566     -1
    x[30]     c1726     -1
    x[30]     c1756     1
    x[30]     c1766     1
    x[30]     c1776     1
    x[30]     c1786     1
    x[30]     c1796     1
    x[30]     c1806     -1
    x[30]     c2806     -1
    x[30]     c4716     2681
    x[30]     c4717     -2681
    x[30]     c4726     2678
    x[30]     c4727     -2678
    x[30]     OBJ       -180594.06802834
    x[31]     c271      1
    x[31]     c1196     -1
    x[31]     c1616     -1
    x[31]     c1776     -1
    x[31]     c1846     -1
    x[31]     c2856     -1
    x[31]     c3256     -1
    x[31]     c4716     1263
    x[31]     c4717     -1263
    x[31]     c4726     864
    x[31]     c4727     -864
    x[31]     OBJ       -65240.1844220027
    x[32]     c280      1
    x[32]     c1656     -1
    x[32]     c1806     1
    x[32]     c1816     1
    x[32]     c1826     1
    x[32]     c2906     -1
    x[32]     c4716     716
    x[32]     c4717     -716
    x[32]     c4726     716
    x[32]     c4727     -716
    x[32]     OBJ       -42261.7831831026
    x[33]     c289      1
    x[33]     c1736     -1
    x[33]     c1816     -1
    x[33]     c1836     1
    x[33]     c1846     1
    x[33]     c1856     1
    x[33]     c1866     1
    x[33]     c1876     1
    x[33]     c2976     -1
    x[33]     c3426     -1
    x[33]     c4716     1965
    x[33]     c4717     -1965
    x[33]     c4726     1964
    x[33]     c4727     -1964
    x[33]     OBJ       -75286.0181294614
    x[34]     c298      1
    x[34]     c1786     -1
    x[34]     c1856     -1
    x[34]     c3026     -1
    x[34]     c3506     -1
    x[34]     c4716     1245
    x[34]     c4717     -1245
    x[34]     c4726     889
    x[34]     c4727     -889
    x[34]     OBJ       -36569.1440822093
    x[35]     c307      1
    x[35]     c1866     -1
    x[35]     c3076     -1
    x[35]     c3796     -1
    x[35]     c4716     832
    x[35]     c4717     -832
    x[35]     c4726     647
    x[35]     c4727     -647
    x[35]     OBJ       -10962.6603699556
    x[36]     c316      1
    x[36]     c4716     339
    x[36]     c4717     -339
    x[36]     c4726     283
    x[36]     c4727     -283
    x[36]     OBJ       -6454.73683042469
    x[37]     c325      1
    x[37]     c1886     1
    x[37]     c1896     1
    x[37]     c1906     1
    x[37]     c1916     1
    x[37]     c2006     -1
    x[37]     c4716     1346
    x[37]     c4717     -1346
    x[37]     c4726     1346
    x[37]     c4727     -1346
    x[37]     OBJ       -53000.4330083172
    x[38]     c334      1
    x[38]     c1896     -1
    x[38]     c2056     -1
    x[38]     c4716     243
    x[38]     c4717     -243
    x[38]     OBJ       839.231257308169
    x[39]     c343      1
    x[39]     c1926     1
    x[39]     c1936     1
    x[39]     c1946     1
    x[39]     c1956     1
    x[39]     c1966     1
    x[39]     c1976     1
    x[39]     c1986     1
    x[39]     c2106     -1
    x[39]     c4716     724
    x[39]     c4717     -724
    x[39]     c4726     724
    x[39]     c4727     -724
    x[39]     OBJ       -60852.3490095494
    x[40]     c352      1
    x[40]     c1936     -1
    x[40]     c1996     1
    x[40]     c2006     1
    x[40]     c2016     1
    x[40]     c2026     1
    x[40]     c2036     1
    x[40]     c2176     -1
    x[40]     c4716     2896
    x[40]     c4717     -2896
    x[40]     c4726     2896
    x[40]     c4727     -2896
    x[40]     OBJ       -188215.045323654
    x[41]     c361      1
    x[41]     c1226     -1
    x[41]     c2016     -1
    x[41]     c2046     1
    x[41]     c2056     1
    x[41]     c2066     1
    x[41]     c2076     1
    x[41]     c2086     1
    x[41]     c2246     -1
    x[41]     c3126     -1
    x[41]     c4716     2692
    x[41]     c4717     -2692
    x[41]     c4726     2692
    x[41]     c4727     -2692
    x[41]     OBJ       -94107.5226618268
    x[42]     c370      1
    x[42]     c1276     -1
    x[42]     c1906     -1
    x[42]     c2066     -1
    x[42]     c2296     -1
    x[42]     c3156     -1
    x[42]     c4716     755
    x[42]     c4717     -755
    x[42]     c4726     323
    x[42]     c4727     -323
    x[42]     OBJ       -7940.82740301084
    x[43]     c379      1
    x[43]     c2096     1
    x[43]     c2106     1
    x[43]     c2116     1
    x[43]     c2126     1
    x[43]     c2136     1
    x[43]     c2146     1
    x[43]     c2156     1
    x[43]     c2336     -1
    x[43]     c4716     1432
    x[43]     c4717     -1432
    x[43]     c4726     1432
    x[43]     c4727     -1432
    x[43]     OBJ       -128517.389843697
    x[44]     c388      1
    x[44]     c2116     -1
    x[44]     c2166     1
    x[44]     c2176     1
    x[44]     c2186     1
    x[44]     c2196     1
    x[44]     c2206     1
    x[44]     c2216     1
    x[44]     c2226     1
    x[44]     c2406     -1
    x[44]     c4716     2886
    x[44]     c4717     -2886
    x[44]     c4726     2886
    x[44]     c4727     -2886
    x[44]     OBJ       -242139.233155645
    x[45]     c397      1
    x[45]     c1326     -1
    x[45]     c1946     -1
    x[45]     c2186     -1
    x[45]     c2236     1
    x[45]     c2246     1
    x[45]     c2256     1
    x[45]     c2266     1
    x[45]     c2276     1
    x[45]     c2466     -1
    x[45]     c3206     -1
    x[45]     c4716     2895
    x[45]     c4717     -2895
    x[45]     c4726     2895
    x[45]     c4727     -2895
    x[45]     OBJ       -201494.020913973
    x[46]     c406      1
    x[46]     c1406     -1
    x[46]     c2026     -1
    x[46]     c2256     -1
    x[46]     c2286     1
    x[46]     c2296     1
    x[46]     c2306     1
    x[46]     c2316     1
    x[46]     c2326     1
    x[46]     c2556     -1
    x[46]     c3276     -1
    x[46]     c4716     2692
    x[46]     c4717     -2692
    x[46]     c4726     2668
    x[46]     c4727     -2668
    x[46]     OBJ       -79096.5067771183
    x[47]     c415      1
    x[47]     c1456     -1
    x[47]     c2076     -1
    x[47]     c2306     -1
    x[47]     c2606     -1
    x[47]     c3326     -1
    x[47]     c4316     -1
    x[47]     c4716     1115
    x[47]     c4717     -1115
    x[47]     c4726     408
    x[47]     c4727     -408
    x[47]     OBJ       -5823.11946973734
    x[48]     c424      1
    x[48]     c2336     1
    x[48]     c2346     1
    x[48]     c2356     1
    x[48]     c2366     1
    x[48]     c2376     1
    x[48]     c2386     1
    x[48]     c4716     1432
    x[48]     c4717     -1432
    x[48]     c4726     1432
    x[48]     c4727     -1432
    x[48]     OBJ       -146646.078258307
    x[49]     c433      1
    x[49]     c2346     -1
    x[49]     c2396     1
    x[49]     c2406     1
    x[49]     c2416     1
    x[49]     c2426     1
    x[49]     c2436     1
    x[49]     c2446     1
    x[49]     c4716     2864
    x[49]     c4717     -2864
    x[49]     c4726     2864
    x[49]     c4727     -2864
    x[49]     OBJ       -268350.776277405
    x[50]     c442      1
    x[50]     c2126     -1
    x[50]     c2416     -1
    x[50]     c2456     1
    x[50]     c2466     1
    x[50]     c2476     1
    x[50]     c2486     1
    x[50]     c2496     1
    x[50]     c2506     1
    x[50]     c2516     1
    x[50]     c2526     1
    x[50]     c2536     1
    x[50]     c2656     -1
    x[50]     c3376     -1
    x[50]     c4716     2864
    x[50]     c4717     -2864
    x[50]     c4726     2864
    x[50]     c4727     -2864
    x[50]     OBJ       -253455.229745656
    x[51]     c451      1
    x[51]     c1496     -1
    x[51]     c2196     -1
    x[51]     c2476     -1
    x[51]     c2546     1
    x[51]     c2556     1
    x[51]     c2566     1
    x[51]     c2576     1
    x[51]     c2586     1
    x[51]     c2736     -1
    x[51]     c3446     -1
    x[51]     c4716     2873
    x[51]     c4717     -2873
    x[51]     c4726     2873
    x[51]     c4727     -2873
    x[51]     OBJ       -194912.267795293
    x[52]     c460      1
    x[52]     c1576     -1
    x[52]     c2266     -1
    x[52]     c2566     -1
    x[52]     c2596     1
    x[52]     c2606     1
    x[52]     c2616     1
    x[52]     c2626     1
    x[52]     c2636     1
    x[52]     c2816     -1
    x[52]     c3526     -1
    x[52]     c4716     2679
    x[52]     c4717     -2679
    x[52]     c4726     2604
    x[52]     c4727     -2604
    x[52]     OBJ       -67699.6816400357
    x[53]     c469      1
    x[53]     c1626     -1
    x[53]     c2316     -1
    x[53]     c2616     -1
    x[53]     c2866     -1
    x[53]     c3576     -1
    x[53]     c4466     -1
    x[53]     c4716     1252
    x[53]     c4717     -1252
    x[53]     c4726     552
    x[53]     c4727     -552
    x[53]     OBJ       -13340.1743473876
    x[54]     c478      1
    x[54]     c2356     -1
    x[54]     c2646     1
    x[54]     c2656     1
    x[54]     c2666     1
    x[54]     c2676     1
    x[54]     c2686     1
    x[54]     c2696     1
    x[54]     c2706     1
    x[54]     c2716     1
    x[54]     c3626     -1
    x[54]     c4716     2148
    x[54]     c4717     -2148
    x[54]     c4726     2148
    x[54]     c4727     -2148
    x[54]     OBJ       -177938.272910276
    x[55]     c487      1
    x[55]     c2426     -1
    x[55]     c2666     -1
    x[55]     c2726     1
    x[55]     c2736     1
    x[55]     c2746     1
    x[55]     c2756     1
    x[55]     c2766     1
    x[55]     c2776     1
    x[55]     c2786     1
    x[55]     c2796     1
    x[55]     c3676     -1
    x[55]     c4716     2864
    x[55]     c4717     -2864
    x[55]     c4726     2864
    x[55]     c4727     -2864
    x[55]     OBJ       -232208.868801146
    x[56]     c496      1
    x[56]     c1666     -1
    x[56]     c2486     -1
    x[56]     c2746     -1
    x[56]     c2806     1
    x[56]     c2816     1
    x[56]     c2826     1
    x[56]     c2836     1
    x[56]     c2846     1
    x[56]     c2916     -1
    x[56]     c3736     -1
    x[56]     c4716     2864
    x[56]     c4717     -2864
    x[56]     c4726     2864
    x[56]     c4727     -2864
    x[56]     OBJ       -212463.609445106
    x[57]     c505      1
    x[57]     c1746     -1
    x[57]     c2576     -1
    x[57]     c2826     -1
    x[57]     c2856     1
    x[57]     c2866     1
    x[57]     c2876     1
    x[57]     c2886     1
    x[57]     c2896     1
    x[57]     c2986     -1
    x[57]     c3826     -1
    x[57]     c4716     2684
    x[57]     c4717     -2684
    x[57]     c4726     2680
    x[57]     c4727     -2680
    x[57]     OBJ       -180594.06802834
    x[58]     c514      1
    x[58]     c1796     -1
    x[58]     c2626     -1
    x[58]     c2876     -1
    x[58]     c3036     -1
    x[58]     c3876     -1
    x[58]     c4716     1253
    x[58]     c4717     -1253
    x[58]     c4726     840
    x[58]     c4727     -840
    x[58]     OBJ       -49882.7604784162
    x[59]     c523      1
    x[59]     c2676     -1
    x[59]     c2906     1
    x[59]     c2916     1
    x[59]     c2926     1
    x[59]     c2936     1
    x[59]     c2946     1
    x[59]     c2956     1
    x[59]     c2966     1
    x[59]     c4716     716
    x[59]     c4717     -716
    x[59]     c4726     716
    x[59]     c4727     -716
    x[59]     OBJ       -66972.2247163921
    x[60]     c532      1
    x[60]     c2756     -1
    x[60]     c2926     -1
    x[60]     c2976     1
    x[60]     c2986     1
    x[60]     c2996     1
    x[60]     c3006     1
    x[60]     c3016     1
    x[60]     c3926     -1
    x[60]     c4716     2864
    x[60]     c4717     -2864
    x[60]     c4726     2864
    x[60]     c4727     -2864
    x[60]     OBJ       -186598.474382224
    x[61]     c541      1
    x[61]     c1826     -1
    x[61]     c2836     -1
    x[61]     c2996     -1
    x[61]     c3026     1
    x[61]     c3036     1
    x[61]     c3046     1
    x[61]     c3056     1
    x[61]     c3066     1
    x[61]     c3986     -1
    x[61]     c4716     2651
    x[61]     c4717     -2651
    x[61]     c4726     2650
    x[61]     c4727     -2650
    x[61]     OBJ       -143643.875081365
    x[62]     c550      1
    x[62]     c1876     -1
    x[62]     c2886     -1
    x[62]     c3046     -1
    x[62]     c3086     -1
    x[62]     c4036     -1
    x[62]     c4716     1175
    x[62]     c4717     -1175
    x[62]     c4726     768
    x[62]     c4727     -768
    x[62]     OBJ       -44040.0112186758
    x[63]     c559      1
    x[63]     c3006     -1
    x[63]     c3076     1
    x[63]     c3086     1
    x[63]     c3096     1
    x[63]     c3106     1
    x[63]     c3116     1
    x[63]     c4716     1333
    x[63]     c4717     -1333
    x[63]     c4726     1332
    x[63]     c4727     -1332
    x[63]     OBJ       -50460.1072432127
    x[64]     c568      1
    x[64]     c3056     -1
    x[64]     c3096     -1
    x[64]     c4086     -1
    x[64]     c4326     -1
    x[64]     c4716     940
    x[64]     c4717     -940
    x[64]     c4726     728
    x[64]     c4727     -728
    x[64]     OBJ       -34594.6181466053
    x[65]     c577      1
    x[65]     c3106     -1
    x[65]     c4476     -1
    x[65]     c4716     342
    x[65]     c4717     -342
    x[65]     c4726     317
    x[65]     c4727     -317
    x[65]     OBJ       -8544.73211898796
    x[66]     c586      1
    x[66]     c1346     -1
    x[66]     c1916     -1
    x[66]     c3166     -1
    x[66]     c4716     187
    x[66]     c4717     -187
    x[66]     OBJ       637.04442027644
    x[67]     c595      1
    x[67]     c1956     -1
    x[67]     c3126     1
    x[67]     c3136     1
    x[67]     c3146     1
    x[67]     c3216     -1
    x[67]     c4716     724
    x[67]     c4717     -724
    x[67]     c4726     724
    x[67]     c4727     -724
    x[67]     OBJ       -34178.9284759518
    x[68]     c604      1
    x[68]     c2036     -1
    x[68]     c3136     -1
    x[68]     c3156     1
    x[68]     c3166     1
    x[68]     c3176     1
    x[68]     c3186     1
    x[68]     c3196     1
    x[68]     c3286     -1
    x[68]     c4716     2019
    x[68]     c4717     -2019
    x[68]     c4726     1995
    x[68]     c4727     -1995
    x[68]     OBJ       -40044.7716062841
    x[69]     c613      1
    x[69]     c1516     -1
    x[69]     c2086     -1
    x[69]     c3176     -1
    x[69]     c3336     -1
    x[69]     c4716     660
    x[69]     c4717     -660
    x[69]     c4726     174
    x[69]     c4727     -174
    x[69]     OBJ       -4625.70227954943
    x[70]     c622      1
    x[70]     c2136     -1
    x[70]     c3206     1
    x[70]     c3216     1
    x[70]     c3226     1
    x[70]     c3236     1
    x[70]     c3246     1
    x[70]     c3256     1
    x[70]     c3266     1
    x[70]     c3386     -1
    x[70]     c4716     1447
    x[70]     c4717     -1447
    x[70]     c4726     1447
    x[70]     c4727     -1447
    x[70]     OBJ       -101843.9693101
    x[71]     c631      1
    x[71]     c2206     -1
    x[71]     c3226     -1
    x[71]     c3276     1
    x[71]     c3286     1
    x[71]     c3296     1
    x[71]     c3306     1
    x[71]     c3316     1
    x[71]     c3456     -1
    x[71]     c4716     2896
    x[71]     c4717     -2896
    x[71]     c4726     2896
    x[71]     c4727     -2896
    x[71]     OBJ       -137408.530021563
    x[72]     c640      1
    x[72]     c2276     -1
    x[72]     c3146     -1
    x[72]     c3296     -1
    x[72]     c3326     1
    x[72]     c3336     1
    x[72]     c3346     1
    x[72]     c3356     1
    x[72]     c3366     1
    x[72]     c3536     -1
    x[72]     c4716     2692
    x[72]     c4717     -2692
    x[72]     c4726     2692
    x[72]     c4727     -2692
    x[72]     OBJ       -56048.8239264426
    x[73]     c649      1
    x[73]     c1686     -1
    x[73]     c2326     -1
    x[73]     c3186     -1
    x[73]     c3346     -1
    x[73]     c3586     -1
    x[73]     c4136     -1
    x[73]     c4716     964
    x[73]     c4717     -964
    x[73]     c4726     288
    x[73]     c4727     -288
    x[73]     OBJ       -4509.07823306053
    x[74]     c658      1
    x[74]     c2366     -1
    x[74]     c3376     1
    x[74]     c3386     1
    x[74]     c3396     1
    x[74]     c3406     1
    x[74]     c3416     1
    x[74]     c3426     1
    x[74]     c3436     1
    x[74]     c3636     -1
    x[74]     c4716     1432
    x[74]     c4717     -1432
    x[74]     c4726     1432
    x[74]     c4727     -1432
    x[74]     OBJ       -130249.430138087
    x[75]     c667      1
    x[75]     c2436     -1
    x[75]     c3396     -1
    x[75]     c3446     1
    x[75]     c3456     1
    x[75]     c3466     1
    x[75]     c3476     1
    x[75]     c3486     1
    x[75]     c3496     1
    x[75]     c3506     1
    x[75]     c3516     1
    x[75]     c3686     -1
    x[75]     c4716     2872
    x[75]     c4717     -2872
    x[75]     c4726     2872
    x[75]     c4727     -2872
    x[75]     OBJ       -214657.527151333
    x[76]     c676      1
    x[76]     c2496     -1
    x[76]     c3236     -1
    x[76]     c3466     -1
    x[76]     c3526     1
    x[76]     c3536     1
    x[76]     c3546     1
    x[76]     c3556     1
    x[76]     c3566     1
    x[76]     c3746     -1
    x[76]     c4716     2888
    x[76]     c4717     -2888
    x[76]     c4726     2888
    x[76]     c4727     -2888
    x[76]     OBJ       -165813.99084955
    x[77]     c685      1
    x[77]     c2586     -1
    x[77]     c3306     -1
    x[77]     c3546     -1
    x[77]     c3576     1
    x[77]     c3586     1
    x[77]     c3596     1
    x[77]     c3606     1
    x[77]     c3616     1
    x[77]     c3836     -1
    x[77]     c4186     -1
    x[77]     c4716     2692
    x[77]     c4717     -2692
    x[77]     c4726     2692
    x[77]     c4727     -2692
    x[77]     OBJ       -78288.2213064032
    x[78]     c694      1
    x[78]     c2636     -1
    x[78]     c3356     -1
    x[78]     c3596     -1
    x[78]     c3886     -1
    x[78]     c4226     -1
    x[78]     c4716     1168
    x[78]     c4717     -1168
    x[78]     c4726     528
    x[78]     c4727     -528
    x[78]     OBJ       -14964.8281435249
    x[79]     c703      1
    x[79]     c3626     1
    x[79]     c3636     1
    x[79]     c3646     1
    x[79]     c3656     1
    x[79]     c3666     1
    x[79]     c4716     716
    x[79]     c4717     -716
    x[79]     c4726     716
    x[79]     c4727     -716
    x[79]     OBJ       -77133.5277768102
    x[80]     c712      1
    x[80]     c3646     -1
    x[80]     c3676     1
    x[80]     c3686     1
    x[80]     c3696     1
    x[80]     c3706     1
    x[80]     c3716     1
    x[80]     c3726     1
    x[80]     c4716     2864
    x[80]     c4717     -2864
    x[80]     c4726     2864
    x[80]     c4727     -2864
    x[80]     OBJ       -266965.144041894
    x[81]     c721      1
    x[81]     c2686     -1
    x[81]     c3406     -1
    x[81]     c3696     -1
    x[81]     c3736     1
    x[81]     c3746     1
    x[81]     c3756     1
    x[81]     c3766     1
    x[81]     c3776     1
    x[81]     c3786     1
    x[81]     c3796     1
    x[81]     c3806     1
    x[81]     c3816     1
    x[81]     c4716     2864
    x[81]     c4717     -2864
    x[81]     c4726     2864
    x[81]     c4727     -2864
    x[81]     OBJ       -270891.10204251
    x[82]     c730      1
    x[82]     c2766     -1
    x[82]     c3476     -1
    x[82]     c3756     -1
    x[82]     c3826     1
    x[82]     c3836     1
    x[82]     c3846     1
    x[82]     c3856     1
    x[82]     c3866     1
    x[82]     c3936     -1
    x[82]     c4276     -1
    x[82]     c4716     2865
    x[82]     c4717     -2865
    x[82]     c4726     2865
    x[82]     c4727     -2865
    x[82]     OBJ       -259344.166746581
    x[83]     c739      1
    x[83]     c2846     -1
    x[83]     c3556     -1
    x[83]     c3846     -1
    x[83]     c3876     1
    x[83]     c3886     1
    x[83]     c3896     1
    x[83]     c3906     1
    x[83]     c3916     1
    x[83]     c3996     -1
    x[83]     c4336     -1
    x[83]     c4716     2686
    x[83]     c4717     -2686
    x[83]     c4726     2684
    x[83]     c4727     -2684
    x[83]     OBJ       -152650.48461219
    x[84]     c748      1
    x[84]     c1356     -1
    x[84]     c2896     -1
    x[84]     c3606     -1
    x[84]     c3896     -1
    x[84]     c4046     -1
    x[84]     c4386     -1
    x[84]     c4716     1152
    x[84]     c4717     -1152
    x[84]     c4726     624
    x[84]     c4727     -624
    x[84]     OBJ       -29895.0154811619
    x[85]     c757      1
    x[85]     c3706     -1
    x[85]     c3926     1
    x[85]     c3936     1
    x[85]     c3946     1
    x[85]     c3956     1
    x[85]     c3966     1
    x[85]     c3976     1
    x[85]     c4716     1432
    x[85]     c4717     -1432
    x[85]     c4726     1432
    x[85]     c4727     -1432
    x[85]     OBJ       -137177.591315645
    x[86]     c766      1
    x[86]     c2936     -1
    x[86]     c3766     -1
    x[86]     c3946     -1
    x[86]     c3986     1
    x[86]     c3996     1
    x[86]     c4006     1
    x[86]     c4016     1
    x[86]     c4026     1
    x[86]     c4436     -1
    x[86]     c4716     2864
    x[86]     c4717     -2864
    x[86]     c4726     2864
    x[86]     c4727     -2864
    x[86]     OBJ       -196875.246795601
    x[87]     c775      1
    x[87]     c3016     -1
    x[87]     c3856     -1
    x[87]     c4006     -1
    x[87]     c4036     1
    x[87]     c4046     1
    x[87]     c4056     1
    x[87]     c4066     1
    x[87]     c4076     1
    x[87]     c4486     -1
    x[87]     c4716     2684
    x[87]     c4717     -2684
    x[87]     c4726     2680
    x[87]     c4727     -2680
    x[87]     OBJ       -137523.999374522
    x[88]     c784      1
    x[88]     c1526     -1
    x[88]     c3066     -1
    x[88]     c3906     -1
    x[88]     c4056     -1
    x[88]     c4096     -1
    x[88]     c4536     -1
    x[88]     c4716     1099
    x[88]     c4717     -1099
    x[88]     c4726     672
    x[88]     c4727     -672
    x[88]     OBJ       -42758.3014008276
    x[89]     c793      1
    x[89]     c4016     -1
    x[89]     c4086     1
    x[89]     c4096     1
    x[89]     c4106     1
    x[89]     c4116     1
    x[89]     c4126     1
    x[89]     c4716     1342
    x[89]     c4717     -1342
    x[89]     c4726     1340
    x[89]     c4727     -1340
    x[89]     OBJ       -32562.3575345217
    x[90]     c802      1
    x[90]     c1696     -1
    x[90]     c3116     -1
    x[90]     c4066     -1
    x[90]     c4106     -1
    x[90]     c4586     -1
    x[90]     c4716     880
    x[90]     c4717     -880
    x[90]     c4726     629
    x[90]     c4727     -629
    x[90]     OBJ       -25022.2087862796
    x[91]     c811      1
    x[91]     c4116     -1
    x[91]     c4716     326
    x[91]     c4717     -326
    x[91]     c4726     256
    x[91]     c4727     -256
    x[91]     OBJ       -9249.09517203966
    x[92]     c820      1
    x[92]     c2526     -1
    x[92]     c3196     -1
    x[92]     c4146     -1
    x[92]     c4716     360
    x[92]     c4717     -360
    x[92]     OBJ       1244.75962490122
    x[93]     c829      1
    x[93]     c2706     -1
    x[93]     c3316     -1
    x[93]     c4136     1
    x[93]     c4146     1
    x[93]     c4156     1
    x[93]     c4166     1
    x[93]     c4176     1
    x[93]     c4196     -1
    x[93]     c4716     1346
    x[93]     c4717     -1346
    x[93]     c4726     1322
    x[93]     c4727     -1322
    x[93]     OBJ       -14837.8118552696
    x[94]     c838      1
    x[94]     c2786     -1
    x[94]     c3366     -1
    x[94]     c4156     -1
    x[94]     c4236     -1
    x[94]     c4716     689
    x[94]     c4717     -689
    x[94]     c4726     241
    x[94]     c4727     -241
    x[94]     OBJ       -6029.80961153447
    x[95]     c847      1
    x[95]     c3486     -1
    x[95]     c4186     1
    x[95]     c4196     1
    x[95]     c4206     1
    x[95]     c4216     1
    x[95]     c4286     -1
    x[95]     c4716     1448
    x[95]     c4717     -1448
    x[95]     c4726     1448
    x[95]     c4727     -1448
    x[95]     OBJ       -56695.4523030147
    x[96]     c856      1
    x[96]     c3566     -1
    x[96]     c4206     -1
    x[96]     c4226     1
    x[96]     c4236     1
    x[96]     c4246     1
    x[96]     c4256     1
    x[96]     c4266     1
    x[96]     c4346     -1
    x[96]     c4716     2692
    x[96]     c4717     -2692
    x[96]     c4726     2668
    x[96]     c4727     -2668
    x[96]     OBJ       -32839.483981624
    x[97]     c865      1
    x[97]     c1986     -1
    x[97]     c2956     -1
    x[97]     c3616     -1
    x[97]     c4166     -1
    x[97]     c4246     -1
    x[97]     c4396     -1
    x[97]     c4716     828
    x[97]     c4717     -828
    x[97]     c4726     291
    x[97]     c4727     -291
    x[97]     OBJ       -5050.62949843964
    x[98]     c874      1
    x[98]     c3716     -1
    x[98]     c4276     1
    x[98]     c4286     1
    x[98]     c4296     1
    x[98]     c4306     1
    x[98]     c4316     1
    x[98]     c4326     1
    x[98]     c4716     1432
    x[98]     c4717     -1432
    x[98]     c4726     1432
    x[98]     c4727     -1432
    x[98]     OBJ       -134290.857491662
    x[99]     c883      1
    x[99]     c3776     -1
    x[99]     c4296     -1
    x[99]     c4336     1
    x[99]     c4346     1
    x[99]     c4356     1
    x[99]     c4366     1
    x[99]     c4376     1
    x[99]     c4446     -1
    x[99]     c4716     2880
    x[99]     c4717     -2880
    x[99]     c4726     2880
    x[99]     c4727     -2880
    x[99]     OBJ       -203918.877326118
    x[100]    c892      1
    x[100]    c2156     -1
    x[100]    c3866     -1
    x[100]    c4216     -1
    x[100]    c4356     -1
    x[100]    c4386     1
    x[100]    c4396     1
    x[100]    c4406     1
    x[100]    c4416     1
    x[100]    c4426     1
    x[100]    c4496     -1
    x[100]    c4716     2691
    x[100]    c4717     -2691
    x[100]    c4726     2691
    x[100]    c4727     -2691
    x[100]    OBJ       -69397.0811285373
    x[101]    c901      1
    x[101]    c2226     -1
    x[101]    c3916     -1
    x[101]    c4256     -1
    x[101]    c4406     -1
    x[101]    c4546     -1
    x[101]    c4636     -1
    x[101]    c4716     840
    x[101]    c4717     -840
    x[101]    c4726     543
    x[101]    c4727     -543
    x[101]    OBJ       -20253.3245090607
    x[102]    c910      1
    x[102]    c4436     1
    x[102]    c4446     1
    x[102]    c4456     1
    x[102]    c4466     1
    x[102]    c4476     1
    x[102]    c4716     716
    x[102]    c4717     -716
    x[102]    c4726     716
    x[102]    c4727     -716
    x[102]    OBJ       -68242.3875989444
    x[103]    c919      1
    x[103]    c2376     -1
    x[103]    c3956     -1
    x[103]    c4306     -1
    x[103]    c4456     -1
    x[103]    c4486     1
    x[103]    c4496     1
    x[103]    c4506     1
    x[103]    c4516     1
    x[103]    c4526     1
    x[103]    c4716     2148
    x[103]    c4717     -2148
    x[103]    c4726     2148
    x[103]    c4727     -2148
    x[103]    OBJ       -173204.029438945
    x[104]    c928      1
    x[104]    c2446     -1
    x[104]    c4026     -1
    x[104]    c4366     -1
    x[104]    c4506     -1
    x[104]    c4536     1
    x[104]    c4546     1
    x[104]    c4556     1
    x[104]    c4566     1
    x[104]    c4576     1
    x[104]    c4716     2684
    x[104]    c4717     -2684
    x[104]    c4726     2680
    x[104]    c4727     -2680
    x[104]    OBJ       -152650.48461219
    x[105]    c937      1
    x[105]    c2536     -1
    x[105]    c4076     -1
    x[105]    c4416     -1
    x[105]    c4556     -1
    x[105]    c4596     -1
    x[105]    c4676     -1
    x[105]    c4716     841
    x[105]    c4717     -841
    x[105]    c4726     480
    x[105]    c4727     -480
    x[105]    OBJ       -35922.5157056372
    x[106]    c946      1
    x[106]    c2716     -1
    x[106]    c4516     -1
    x[106]    c4586     1
    x[106]    c4596     1
    x[106]    c4606     1
    x[106]    c4616     1
    x[106]    c4626     1
    x[106]    c4716     671
    x[106]    c4717     -671
    x[106]    c4726     670
    x[106]    c4727     -670
    x[106]    OBJ       -27250.767298394
    x[107]    c955      1
    x[107]    c2796     -1
    x[107]    c4126     -1
    x[107]    c4566     -1
    x[107]    c4606     -1
    x[107]    c4716     754
    x[107]    c4717     -754
    x[107]    c4726     450
    x[107]    c4727     -450
    x[107]    OBJ       -31788.7128696944
    x[108]    c964      1
    x[108]    c2966     -1
    x[108]    c4616     -1
    x[108]    c4716     289
    x[108]    c4717     -289
    x[108]    c4726     186
    x[108]    c4727     -186
    x[108]    OBJ       -8463.90357191645
    x[109]    c973      1
    x[109]    c3806     -1
    x[109]    c4176     -1
    x[109]    c4716     150
    x[109]    c4717     -150
    x[109]    OBJ       519.612088316836
    x[110]    c982      1
    x[110]    c3976     -1
    x[110]    c4266     -1
    x[110]    c4646     -1
    x[110]    c4716     315
    x[110]    c4717     -315
    x[110]    c4726     52
    x[110]    c4727     -52
    x[110]    OBJ       -204.380754737955
    x[111]    c991      1
    x[111]    c4376     -1
    x[111]    c4636     1
    x[111]    c4646     1
    x[111]    c4656     1
    x[111]    c4666     1
    x[111]    c4716     1346
    x[111]    c4717     -1346
    x[111]    c4726     1322
    x[111]    c4727     -1322
    x[111]    OBJ       -22031.5525446338
    x[112]    c1000     1
    x[112]    c3266     -1
    x[112]    c4426     -1
    x[112]    c4656     -1
    x[112]    c4686     -1
    x[112]    c4716     548
    x[112]    c4717     -548
    x[112]    c4726     133
    x[112]    c4727     -133
    x[112]    OBJ       -3305.88757522467
    x[113]    c1009     1
    x[113]    c3436     -1
    x[113]    c4526     -1
    x[113]    c4676     1
    x[113]    c4686     1
    x[113]    c4696     1
    x[113]    c4706     1
    x[113]    c4716     672
    x[113]    c4717     -672
    x[113]    c4726     672
    x[113]    c4727     -672
    x[113]    OBJ       -19398.8512971618
    x[114]    c1018     1
    x[114]    c3516     -1
    x[114]    c4576     -1
    x[114]    c4666     -1
    x[114]    c4696     -1
    x[114]    c4716     429
    x[114]    c4717     -429
    x[114]    c4726     142
    x[114]    c4727     -142
    x[114]    OBJ       -6997.44278933339
    x[115]    c1027     1
    x[115]    c3816     -1
    x[115]    c4626     -1
    x[115]    c4706     -1
    x[115]    c4716     273
    x[115]    c4717     -273
    x[115]    c4726     94
    x[115]    c4727     -94
    x[115]    OBJ       -6512.47150690434
    x[116]    c1        -1
    x[116]    c2        1
    x[116]    c2387     -1
    x[116]    c4717     219
    x[116]    c4718     -219
    x[116]    c4727     75
    x[116]    c4728     -75
    x[116]    OBJ       -2191.9055269442
    x[117]    c10       -1
    x[117]    c11       1
    x[117]    c1337     -1
    x[117]    c4717     328
    x[117]    c4718     -328
    x[117]    c4727     215
    x[117]    c4728     -215
    x[117]    OBJ       -4473.88936321488
    x[118]    c19       -1
    x[118]    c20       1
    x[118]    c1507     -1
    x[118]    c3667     -1
    x[118]    c4717     545
    x[118]    c4718     -545
    x[118]    c4727     368
    x[118]    c4728     -368
    x[118]    OBJ       -10218.8837580367
    x[119]    c28       -1
    x[119]    c29       1
    x[119]    c1067     -1
    x[119]    c1677     -1
    x[119]    c4717     435
    x[119]    c4718     -435
    x[119]    c4727     400
    x[119]    c4728     -400
    x[119]    OBJ       -15583.54751348
    x[120]    c37       -1
    x[120]    c38       1
    x[120]    c1117     -1
    x[120]    c4717     247
    x[120]    c4718     -247
    x[120]    c4727     216
    x[120]    c4728     -216
    x[120]    OBJ       -6946.03851917478
    x[121]    c46       -1
    x[121]    c47       1
    x[121]    c1967     -1
    x[121]    c4717     82
    x[121]    c4718     -82
    x[121]    c4727     27
    x[121]    c4728     -27
    x[121]    OBJ       -729.634305544439
    x[122]    c55       -1
    x[122]    c56       1
    x[122]    c1077     -1
    x[122]    c1237     -1
    x[122]    c2507     -1
    x[122]    c4717     526
    x[122]    c4718     -526
    x[122]    c4727     314
    x[122]    c4728     -314
    x[122]    OBJ       -6760.87755000369
    x[123]    c64       -1
    x[123]    c65       1
    x[123]    c1037     1
    x[123]    c1047     1
    x[123]    c1057     1
    x[123]    c1287     -1
    x[123]    c4717     693
    x[123]    c4718     -693
    x[123]    c4727     693
    x[123]    c4728     -693
    x[123]    OBJ       -51744.9843575412
    x[124]    c73       -1
    x[124]    c74       1
    x[124]    c1037     -1
    x[124]    c1067     1
    x[124]    c1077     1
    x[124]    c1087     1
    x[124]    c1097     1
    x[124]    c1107     1
    x[124]    c1367     -1
    x[124]    c2697     -1
    x[124]    c4717     1944
    x[124]    c4718     -1944
    x[124]    c4727     1944
    x[124]    c4728     -1944
    x[124]    OBJ       -77367.2590104049
    x[125]    c82       -1
    x[125]    c83       1
    x[125]    c1087     -1
    x[125]    c1127     -1
    x[125]    c1417     -1
    x[125]    c2777     -1
    x[125]    c4717     907
    x[125]    c4718     -907
    x[125]    c4727     574
    x[125]    c4728     -574
    x[125]    c4877     -1
    x[125]    OBJ       -22399.4729191832
    x[126]    c91       -1
    x[126]    c92       1
    x[126]    c1047     -1
    x[126]    c1117     1
    x[126]    c1127     1
    x[126]    c1137     1
    x[126]    c1147     1
    x[126]    c1157     1
    x[126]    c1537     -1
    x[126]    c4717     1296
    x[126]    c4718     -1296
    x[126]    c4727     1128
    x[126]    c4728     -1128
    x[126]    OBJ       -24665.4428337959
    x[127]    c100      -1
    x[127]    c101      1
    x[127]    c1097     -1
    x[127]    c1137     -1
    x[127]    c1167     -1
    x[127]    c1587     -1
    x[127]    c1977     -1
    x[127]    c2947     -1
    x[127]    c4717     1043
    x[127]    c4718     -1043
    x[127]    c4727     864
    x[127]    c4728     -864
    x[127]    OBJ       -20481.805800633
    x[128]    c109      -1
    x[128]    c110      1
    x[128]    c1167     1
    x[128]    c1177     1
    x[128]    c1187     1
    x[128]    c1197     1
    x[128]    c1707     -1
    x[128]    c2147     -1
    x[128]    c4717     1332
    x[128]    c4718     -1332
    x[128]    c4727     1330
    x[128]    c4728     -1330
    x[128]    OBJ       -46940.8078601292
    x[129]    c118      -1
    x[129]    c119      1
    x[129]    c1147     -1
    x[129]    c1177     -1
    x[129]    c1757     -1
    x[129]    c2217     -1
    x[129]    c4717     1186
    x[129]    c4718     -1186
    x[129]    c4727     864
    x[129]    c4728     -864
    x[129]    OBJ       -28404.6935409482
    x[130]    c127      -1
    x[130]    c128      1
    x[130]    c1187     -1
    x[130]    c1837     -1
    x[130]    c2517     -1
    x[130]    c4717     984
    x[130]    c4718     -984
    x[130]    c4727     723
    x[130]    c4728     -723
    x[130]    c4916     -1
    x[130]    OBJ       -14102.2597601113
    x[131]    c136      -1
    x[131]    c137      1
    x[131]    c1247     -1
    x[131]    c1887     -1
    x[131]    c3247     -1
    x[131]    c4717     225
    x[131]    c4718     -225
    x[131]    c4727     20
    x[131]    c4728     -20
    x[131]    OBJ       57.0495959067669
    x[132]    c145      -1
    x[132]    c146      1
    x[132]    c1207     1
    x[132]    c1217     1
    x[132]    c1227     1
    x[132]    c1297     -1
    x[132]    c1927     -1
    x[132]    c4717     724
    x[132]    c4718     -724
    x[132]    c4727     724
    x[132]    c4728     -724
    x[132]    OBJ       -38533.4989896583
    x[133]    c154      -1
    x[133]    c155      1
    x[133]    c1207     -1
    x[133]    c1237     1
    x[133]    c1247     1
    x[133]    c1257     1
    x[133]    c1267     1
    x[133]    c1277     1
    x[133]    c1377     -1
    x[133]    c1997     -1
    x[133]    c3417     -1
    x[133]    c4717     1989
    x[133]    c4718     -1989
    x[133]    c4727     1989
    x[133]    c4728     -1989
    x[133]    OBJ       -33409.0440590856
    x[134]    c163      -1
    x[134]    c164      1
    x[134]    c1257     -1
    x[134]    c1427     -1
    x[134]    c2047     -1
    x[134]    c3497     -1
    x[134]    c4717     710
    x[134]    c4718     -710
    x[134]    c4727     382
    x[134]    c4728     -382
    x[134]    OBJ       -9348.12676788076
    x[135]    c172      -1
    x[135]    c173      1
    x[135]    c1287     1
    x[135]    c1297     1
    x[135]    c1307     1
    x[135]    c1317     1
    x[135]    c1327     1
    x[135]    c1337     1
    x[135]    c1347     1
    x[135]    c1357     1
    x[135]    c2097     -1
    x[135]    c4717     716
    x[135]    c4718     -716
    x[135]    c4727     716
    x[135]    c4728     -716
    x[135]    c4940     1
    x[135]    OBJ       -58350.7270414826
    x[136]    c181      -1
    x[136]    c182      1
    x[136]    c1307     -1
    x[136]    c1367     1
    x[136]    c1377     1
    x[136]    c1387     1
    x[136]    c1397     1
    x[136]    c1407     1
    x[136]    c1467     -1
    x[136]    c2167     -1
    x[136]    c3657     -1
    x[136]    c4717     2876
    x[136]    c4718     -2876
    x[136]    c4727     2876
    x[136]    c4728     -2876
    x[136]    OBJ       -184560.447108909
    x[137]    c190      -1
    x[137]    c191      1
    x[137]    c1057     -1
    x[137]    c1217     -1
    x[137]    c1387     -1
    x[137]    c1417     1
    x[137]    c1427     1
    x[137]    c1437     1
    x[137]    c1447     1
    x[137]    c1457     1
    x[137]    c1547     -1
    x[137]    c2237     -1
    x[137]    c3727     -1
    x[137]    c4717     2595
    x[137]    c4718     -2595
    x[137]    c4727     2595
    x[137]    c4728     -2595
    x[137]    c4759     -1
    x[137]    c4760     -1
    x[137]    OBJ       -39484.3255881045
    x[138]    c199      -1
    x[138]    c200      1
    x[138]    c1107     -1
    x[138]    c1267     -1
    x[138]    c1437     -1
    x[138]    c1597     -1
    x[138]    c2287     -1
    x[138]    c3787     -1
    x[138]    c4717     1030
    x[138]    c4718     -1030
    x[138]    c4727     552
    x[138]    c4728     -552
    x[138]    c4908     -1
    x[138]    OBJ       -5284.59414715314
    x[139]    c208      -1
    x[139]    c209      1
    x[139]    c1467     1
    x[139]    c1477     1
    x[139]    c1487     1
    x[139]    c1497     1
    x[139]    c1507     1
    x[139]    c1517     1
    x[139]    c1527     1
    x[139]    c2397     -1
    x[139]    c4717     1432
    x[139]    c4718     -1432
    x[139]    c4727     1432
    x[139]    c4728     -1432
    x[139]    OBJ       -108194.058202132
    x[140]    c217      -1
    x[140]    c218      1
    x[140]    c1317     -1
    x[140]    c1477     -1
    x[140]    c1537     1
    x[140]    c1547     1
    x[140]    c1557     1
    x[140]    c1567     1
    x[140]    c1577     1
    x[140]    c1637     -1
    x[140]    c2457     -1
    x[140]    c4717     2864
    x[140]    c4718     -2864
    x[140]    c4727     2864
    x[140]    c4728     -2864
    x[140]    OBJ       -148228.862347231
    x[141]    c226      -1
    x[141]    c227      1
    x[141]    c1397     -1
    x[141]    c1557     -1
    x[141]    c1587     1
    x[141]    c1597     1
    x[141]    c1607     1
    x[141]    c1617     1
    x[141]    c1627     1
    x[141]    c1717     -1
    x[141]    c2547     -1
    x[141]    c4717     2600
    x[141]    c4718     -2600
    x[141]    c4727     2336
    x[141]    c4728     -2336
    x[141]    c4871     -1
    x[141]    OBJ       -56589.1956590983
    x[142]    c235      -1
    x[142]    c236      1
    x[142]    c1157     -1
    x[142]    c1447     -1
    x[142]    c1607     -1
    x[142]    c1767     -1
    x[142]    c2597     -1
    x[142]    c3967     -1
    x[142]    c4717     1156
    x[142]    c4718     -1156
    x[142]    c4727     696
    x[142]    c4728     -696
    x[142]    c4802     -1
    x[142]    OBJ       -13121.4070585564
    x[143]    c244      -1
    x[143]    c245      1
    x[143]    c1637     1
    x[143]    c1647     1
    x[143]    c1657     1
    x[143]    c1667     1
    x[143]    c1677     1
    x[143]    c1687     1
    x[143]    c1697     1
    x[143]    c2647     -1
    x[143]    c4717     716
    x[143]    c4718     -716
    x[143]    c4727     716
    x[143]    c4728     -716
    x[143]    c4943     1
    x[143]    OBJ       -54147.0726062472
    x[144]    c253      -1
    x[144]    c254      1
    x[144]    c1487     -1
    x[144]    c1647     -1
    x[144]    c1707     1
    x[144]    c1717     1
    x[144]    c1727     1
    x[144]    c1737     1
    x[144]    c1747     1
    x[144]    c2727     -1
    x[144]    c4717     2864
    x[144]    c4718     -2864
    x[144]    c4727     2864
    x[144]    c4728     -2864
    x[144]    OBJ       -168046.090399055
    x[145]    c262      -1
    x[145]    c263      1
    x[145]    c1567     -1
    x[145]    c1727     -1
    x[145]    c1757     1
    x[145]    c1767     1
    x[145]    c1777     1
    x[145]    c1787     1
    x[145]    c1797     1
    x[145]    c1807     -1
    x[145]    c2807     -1
    x[145]    c4717     2681
    x[145]    c4718     -2681
    x[145]    c4727     2678
    x[145]    c4728     -2678
    x[145]    OBJ       -156536.084207339
    x[146]    c271      -1
    x[146]    c272      1
    x[146]    c1197     -1
    x[146]    c1617     -1
    x[146]    c1777     -1
    x[146]    c1847     -1
    x[146]    c2857     -1
    x[146]    c3257     -1
    x[146]    c4717     1263
    x[146]    c4718     -1263
    x[146]    c4727     864
    x[146]    c4728     -864
    x[146]    c4910     -1
    x[146]    OBJ       -56549.1608549531
    x[147]    c280      -1
    x[147]    c281      1
    x[147]    c1657     -1
    x[147]    c1807     1
    x[147]    c1817     1
    x[147]    c1827     1
    x[147]    c2907     -1
    x[147]    c4717     716
    x[147]    c4718     -716
    x[147]    c4727     716
    x[147]    c4728     -716
    x[147]    OBJ       -36631.8457927661
    x[148]    c289      -1
    x[148]    c290      1
    x[148]    c1737     -1
    x[148]    c1817     -1
    x[148]    c1837     1
    x[148]    c1847     1
    x[148]    c1857     1
    x[148]    c1867     1
    x[148]    c1877     1
    x[148]    c2977     -1
    x[148]    c3427     -1
    x[148]    c4717     1965
    x[148]    c4718     -1965
    x[148]    c4727     1964
    x[148]    c4728     -1964
    x[148]    OBJ       -65256.7307565123
    x[149]    c298      -1
    x[149]    c299      1
    x[149]    c1787     -1
    x[149]    c1857     -1
    x[149]    c3027     -1
    x[149]    c3507     -1
    x[149]    c4717     1245
    x[149]    c4718     -1245
    x[149]    c4727     889
    x[149]    c4728     -889
    x[149]    c4878     -1
    x[149]    OBJ       -31697.5561818826
    x[150]    c307      -1
    x[150]    c308      1
    x[150]    c1867     -1
    x[150]    c3077     -1
    x[150]    c3797     -1
    x[150]    c4717     832
    x[150]    c4718     -832
    x[150]    c4727     647
    x[150]    c4728     -647
    x[150]    OBJ       -9502.26076383938
    x[151]    c316      -1
    x[151]    c317      1
    x[151]    c4717     339
    x[151]    c4718     -339
    x[151]    c4727     283
    x[151]    c4728     -283
    x[151]    OBJ       -5594.86387927766
    x[152]    c325      -1
    x[152]    c326      1
    x[152]    c1887     1
    x[152]    c1897     1
    x[152]    c1907     1
    x[152]    c1917     1
    x[152]    c2007     -1
    x[152]    c4717     1346
    x[152]    c4718     -1346
    x[152]    c4727     1346
    x[152]    c4728     -1346
    x[152]    OBJ       -45939.9377565018
    x[153]    c334      -1
    x[153]    c335      1
    x[153]    c1897     -1
    x[153]    c2057     -1
    x[153]    c4717     243
    x[153]    c4718     -243
    x[153]    OBJ       727.432391316459
    x[154]    c343      -1
    x[154]    c344      1
    x[154]    c1927     1
    x[154]    c1937     1
    x[154]    c1947     1
    x[154]    c1957     1
    x[154]    c1967     1
    x[154]    c1977     1
    x[154]    c1987     1
    x[154]    c2107     -1
    x[154]    c4717     724
    x[154]    c4718     -724
    x[154]    c4727     724
    x[154]    c4728     -724
    x[154]    OBJ       -52745.8544611687
    x[155]    c352      -1
    x[155]    c353      1
    x[155]    c1937     -1
    x[155]    c1997     1
    x[155]    c2007     1
    x[155]    c2017     1
    x[155]    c2027     1
    x[155]    c2037     1
    x[155]    c2177     -1
    x[155]    c4717     2896
    x[155]    c4718     -2896
    x[155]    c4727     2896
    x[155]    c4728     -2896
    x[155]    OBJ       -163141.826891281
    x[156]    c361      -1
    x[156]    c362      1
    x[156]    c1227     -1
    x[156]    c2017     -1
    x[156]    c2047     1
    x[156]    c2057     1
    x[156]    c2067     1
    x[156]    c2077     1
    x[156]    c2087     1
    x[156]    c2247     -1
    x[156]    c3127     -1
    x[156]    c4717     2692
    x[156]    c4718     -2692
    x[156]    c4727     2692
    x[156]    c4728     -2692
    x[156]    OBJ       -81570.9134456404
    x[157]    c370      -1
    x[157]    c371      1
    x[157]    c1277     -1
    x[157]    c1907     -1
    x[157]    c2067     -1
    x[157]    c2297     -1
    x[157]    c3157     -1
    x[157]    c4717     755
    x[157]    c4718     -755
    x[157]    c4727     323
    x[157]    c4728     -323
    x[157]    c4875     -1
    x[157]    OBJ       -6882.98370264624
    x[158]    c379      -1
    x[158]    c380      1
    x[158]    c2097     1
    x[158]    c2107     1
    x[158]    c2117     1
    x[158]    c2127     1
    x[158]    c2137     1
    x[158]    c2147     1
    x[158]    c2157     1
    x[158]    c2337     -1
    x[158]    c4717     1432
    x[158]    c4718     -1432
    x[158]    c4727     1432
    x[158]    c4728     -1432
    x[158]    OBJ       -111396.84253374
    x[159]    c388      -1
    x[159]    c389      1
    x[159]    c2117     -1
    x[159]    c2167     1
    x[159]    c2177     1
    x[159]    c2187     1
    x[159]    c2197     1
    x[159]    c2207     1
    x[159]    c2217     1
    x[159]    c2227     1
    x[159]    c2407     -1
    x[159]    c4717     2886
    x[159]    c4718     -2886
    x[159]    c4727     2886
    x[159]    c4728     -2886
    x[159]    c4941     1
    x[159]    OBJ       -209882.460730684
    x[160]    c397      -1
    x[160]    c398      1
    x[160]    c1327     -1
    x[160]    c1947     -1
    x[160]    c2187     -1
    x[160]    c2237     1
    x[160]    c2247     1
    x[160]    c2257     1
    x[160]    c2267     1
    x[160]    c2277     1
    x[160]    c2467     -1
    x[160]    c3207     -1
    x[160]    c4717     2895
    x[160]    c4718     -2895
    x[160]    c4727     2895
    x[160]    c4728     -2895
    x[160]    c4855     1
    x[160]    c4858     1
    x[160]    OBJ       -174651.833082997
    x[161]    c406      -1
    x[161]    c407      1
    x[161]    c1407     -1
    x[161]    c2027     -1
    x[161]    c2257     -1
    x[161]    c2287     1
    x[161]    c2297     1
    x[161]    c2307     1
    x[161]    c2317     1
    x[161]    c2327     1
    x[161]    c2557     -1
    x[161]    c3277     -1
    x[161]    c4717     2692
    x[161]    c4718     -2692
    x[161]    c4727     2668
    x[161]    c4728     -2668
    x[161]    OBJ       -68559.602098483
    x[162]    c415      -1
    x[162]    c416      1
    x[162]    c1457     -1
    x[162]    c2077     -1
    x[162]    c2307     -1
    x[162]    c2607     -1
    x[162]    c3327     -1
    x[162]    c4317     -1
    x[162]    c4717     1115
    x[162]    c4718     -1115
    x[162]    c4727     408
    x[162]    c4728     -408
    x[162]    c4912     -1
    x[162]    OBJ       -5047.38793259343
    x[163]    c424      -1
    x[163]    c425      1
    x[163]    c2337     1
    x[163]    c2347     1
    x[163]    c2357     1
    x[163]    c2367     1
    x[163]    c2377     1
    x[163]    c2387     1
    x[163]    c4717     1432
    x[163]    c4718     -1432
    x[163]    c4727     1432
    x[163]    c4728     -1432
    x[163]    c4829     1
    x[163]    OBJ       -127110.503160691
    x[164]    c433      -1
    x[164]    c434      1
    x[164]    c2347     -1
    x[164]    c2397     1
    x[164]    c2407     1
    x[164]    c2417     1
    x[164]    c2427     1
    x[164]    c2437     1
    x[164]    c2447     1
    x[164]    c4717     2864
    x[164]    c4718     -2864
    x[164]    c4727     2864
    x[164]    c4728     -2864
    x[164]    OBJ       -232602.212083029
    x[165]    c442      -1
    x[165]    c443      1
    x[165]    c2127     -1
    x[165]    c2417     -1
    x[165]    c2457     1
    x[165]    c2467     1
    x[165]    c2477     1
    x[165]    c2487     1
    x[165]    c2497     1
    x[165]    c2507     1
    x[165]    c2517     1
    x[165]    c2527     1
    x[165]    c2537     1
    x[165]    c2657     -1
    x[165]    c3377     -1
    x[165]    c4717     2864
    x[165]    c4718     -2864
    x[165]    c4727     2864
    x[165]    c4728     -2864
    x[165]    c4871     1
    x[165]    c4875     1
    x[165]    c4876     1
    x[165]    c4877     1
    x[165]    c4878     1
    x[165]    OBJ       -219690.987746234
    x[166]    c451      -1
    x[166]    c452      1
    x[166]    c1497     -1
    x[166]    c2197     -1
    x[166]    c2477     -1
    x[166]    c2547     1
    x[166]    c2557     1
    x[166]    c2567     1
    x[166]    c2577     1
    x[166]    c2587     1
    x[166]    c2737     -1
    x[166]    c3447     -1
    x[166]    c4717     2873
    x[166]    c4718     -2873
    x[166]    c4727     2873
    x[166]    c4728     -2873
    x[166]    OBJ       -168946.87349232
    x[167]    c460      -1
    x[167]    c461      1
    x[167]    c1577     -1
    x[167]    c2267     -1
    x[167]    c2567     -1
    x[167]    c2597     1
    x[167]    c2607     1
    x[167]    c2617     1
    x[167]    c2627     1
    x[167]    c2637     1
    x[167]    c2817     -1
    x[167]    c3527     -1
    x[167]    c4717     2679
    x[167]    c4718     -2679
    x[167]    c4727     2604
    x[167]    c4728     -2604
    x[167]    c4940     -1
    x[167]    c4941     -1
    x[167]    c4943     -1
    x[167]    OBJ       -58681.0141756797
    x[168]    c469      -1
    x[168]    c470      1
    x[168]    c1627     -1
    x[168]    c2317     -1
    x[168]    c2617     -1
    x[168]    c2867     -1
    x[168]    c3577     -1
    x[168]    c4467     -1
    x[168]    c4717     1252
    x[168]    c4718     -1252
    x[168]    c4727     552
    x[168]    c4728     -552
    x[168]    c4855     -1
    x[168]    OBJ       -11563.0523072084
    x[169]    c478      -1
    x[169]    c479      1
    x[169]    c2357     -1
    x[169]    c2647     1
    x[169]    c2657     1
    x[169]    c2667     1
    x[169]    c2677     1
    x[169]    c2687     1
    x[169]    c2697     1
    x[169]    c2707     1
    x[169]    c2717     1
    x[169]    c3627     -1
    x[169]    c4717     2148
    x[169]    c4718     -2148
    x[169]    c4727     2148
    x[169]    c4728     -2148
    x[169]    c4759     1
    x[169]    OBJ       -154234.082968996
    x[170]    c487      -1
    x[170]    c488      1
    x[170]    c2427     -1
    x[170]    c2667     -1
    x[170]    c2727     1
    x[170]    c2737     1
    x[170]    c2747     1
    x[170]    c2757     1
    x[170]    c2767     1
    x[170]    c2777     1
    x[170]    c2787     1
    x[170]    c2797     1
    x[170]    c3677     -1
    x[170]    c4717     2864
    x[170]    c4718     -2864
    x[170]    c4727     2864
    x[170]    c4728     -2864
    x[170]    c4903     1
    x[170]    c4908     1
    x[170]    c4910     1
    x[170]    c4912     1
    x[170]    c4913     1
    x[170]    c4915     -1
    x[170]    c4916     1
    x[170]    OBJ       -201274.977839488
    x[171]    c496      -1
    x[171]    c497      1
    x[171]    c1667     -1
    x[171]    c2487     -1
    x[171]    c2747     -1
    x[171]    c2807     1
    x[171]    c2817     1
    x[171]    c2827     1
    x[171]    c2837     1
    x[171]    c2847     1
    x[171]    c2917     -1
    x[171]    c3737     -1
    x[171]    c4717     2864
    x[171]    c4718     -2864
    x[171]    c4727     2864
    x[171]    c4728     -2864
    x[171]    c4828     -1
    x[171]    c4829     -1
    x[171]    c4830     1
    x[171]    c4831     1
    x[171]    OBJ       -184160.099067458
    x[172]    c505      -1
    x[172]    c506      1
    x[172]    c1747     -1
    x[172]    c2577     -1
    x[172]    c2827     -1
    x[172]    c2857     1
    x[172]    c2867     1
    x[172]    c2877     1
    x[172]    c2887     1
    x[172]    c2897     1
    x[172]    c2987     -1
    x[172]    c3827     -1
    x[172]    c4717     2684
    x[172]    c4718     -2684
    x[172]    c4727     2680
    x[172]    c4728     -2680
    x[172]    c4980     -1
    x[172]    OBJ       -156536.084207339
    x[173]    c514      -1
    x[173]    c515      1
    x[173]    c1797     -1
    x[173]    c2627     -1
    x[173]    c2877     -1
    x[173]    c3037     -1
    x[173]    c3877     -1
    x[173]    c4717     1253
    x[173]    c4718     -1253
    x[173]    c4727     840
    x[173]    c4728     -840
    x[173]    c4876     -1
    x[173]    OBJ       -43237.5884767075
    x[174]    c523      -1
    x[174]    c524      1
    x[174]    c2677     -1
    x[174]    c2907     1
    x[174]    c2917     1
    x[174]    c2927     1
    x[174]    c2937     1
    x[174]    c2947     1
    x[174]    c2957     1
    x[174]    c2967     1
    x[174]    c4717     716
    x[174]    c4718     -716
    x[174]    c4727     716
    x[174]    c4728     -716
    x[174]    OBJ       -58050.4660103944
    x[175]    c532      -1
    x[175]    c533      1
    x[175]    c2757     -1
    x[175]    c2927     -1
    x[175]    c2977     1
    x[175]    c2987     1
    x[175]    c2997     1
    x[175]    c3007     1
    x[175]    c3017     1
    x[175]    c3927     -1
    x[175]    c4717     2864
    x[175]    c4718     -2864
    x[175]    c4727     2864
    x[175]    c4728     -2864
    x[175]    OBJ       -161740.608746202
    x[176]    c541      -1
    x[176]    c542      1
    x[176]    c1827     -1
    x[176]    c2837     -1
    x[176]    c2997     -1
    x[176]    c3027     1
    x[176]    c3037     1
    x[176]    c3047     1
    x[176]    c3057     1
    x[176]    c3067     1
    x[176]    c3987     -1
    x[176]    c4717     2651
    x[176]    c4718     -2651
    x[176]    c4727     2650
    x[176]    c4728     -2650
    x[176]    OBJ       -124508.24089126
    x[177]    c550      -1
    x[177]    c551      1
    x[177]    c1877     -1
    x[177]    c2887     -1
    x[177]    c3047     -1
    x[177]    c3087     -1
    x[177]    c4037     -1
    x[177]    c4717     1175
    x[177]    c4718     -1175
    x[177]    c4727     768
    x[177]    c4728     -768
    x[177]    OBJ       -38173.1857523524
    x[178]    c559      -1
    x[178]    c560      1
    x[178]    c3007     -1
    x[178]    c3077     1
    x[178]    c3087     1
    x[178]    c3097     1
    x[178]    c3107     1
    x[178]    c3117     1
    x[178]    c4717     1333
    x[178]    c4718     -1333
    x[178]    c4727     1332
    x[178]    c4728     -1332
    x[178]    c4913     -1
    x[178]    OBJ       -43738.0235285212
    x[179]    c568      -1
    x[179]    c569      1
    x[179]    c3057     -1
    x[179]    c3097     -1
    x[179]    c4087     -1
    x[179]    c4327     -1
    x[179]    c4717     940
    x[179]    c4718     -940
    x[179]    c4727     728
    x[179]    c4728     -728
    x[179]    c4831     -1
    x[179]    OBJ       -29986.0683046796
    x[180]    c577      -1
    x[180]    c578      1
    x[180]    c3107     -1
    x[180]    c4477     -1
    x[180]    c4717     342
    x[180]    c4718     -342
    x[180]    c4727     317
    x[180]    c4728     -317
    x[180]    OBJ       -7406.43876684341
    x[181]    c586      -1
    x[181]    c587      1
    x[181]    c1347     -1
    x[181]    c1917     -1
    x[181]    c3167     -1
    x[181]    c4717     187
    x[181]    c4718     -187
    x[181]    OBJ       552.180036171286
    x[182]    c595      -1
    x[182]    c596      1
    x[182]    c1957     -1
    x[182]    c3127     1
    x[182]    c3137     1
    x[182]    c3147     1
    x[182]    c3217     -1
    x[182]    c4717     724
    x[182]    c4718     -724
    x[182]    c4727     724
    x[182]    c4728     -724
    x[182]    OBJ       -29625.7550673737
    x[183]    c604      -1
    x[183]    c605      1
    x[183]    c2037     -1
    x[183]    c3137     -1
    x[183]    c3157     1
    x[183]    c3167     1
    x[183]    c3177     1
    x[183]    c3187     1
    x[183]    c3197     1
    x[183]    c3287     -1
    x[183]    c4717     2019
    x[183]    c4718     -2019
    x[183]    c4727     1995
    x[183]    c4728     -1995
    x[183]    OBJ       -34710.1751938013
    x[184]    c613      -1
    x[184]    c614      1
    x[184]    c1517     -1
    x[184]    c2087     -1
    x[184]    c3177     -1
    x[184]    c3337     -1
    x[184]    c4717     660
    x[184]    c4718     -660
    x[184]    c4727     174
    x[184]    c4728     -174
    x[184]    c4858     -1
    x[184]    OBJ       -4009.48563513172
    x[185]    c622      -1
    x[185]    c623      1
    x[185]    c2137     -1
    x[185]    c3207     1
    x[185]    c3217     1
    x[185]    c3227     1
    x[185]    c3237     1
    x[185]    c3247     1
    x[185]    c3257     1
    x[185]    c3267     1
    x[185]    c3387     -1
    x[185]    c4717     1447
    x[185]    c4718     -1447
    x[185]    c4727     1447
    x[185]    c4728     -1447
    x[185]    c4760     1
    x[185]    OBJ       -88276.7431399445
    x[186]    c631      -1
    x[186]    c632      1
    x[186]    c2207     -1
    x[186]    c3227     -1
    x[186]    c3277     1
    x[186]    c3287     1
    x[186]    c3297     1
    x[186]    c3307     1
    x[186]    c3317     1
    x[186]    c3457     -1
    x[186]    c4717     2896
    x[186]    c4718     -2896
    x[186]    c4727     2896
    x[186]    c4728     -2896
    x[186]    OBJ       -119103.542331671
    x[187]    c640      -1
    x[187]    c641      1
    x[187]    c2277     -1
    x[187]    c3147     -1
    x[187]    c3297     -1
    x[187]    c3327     1
    x[187]    c3337     1
    x[187]    c3347     1
    x[187]    c3357     1
    x[187]    c3367     1
    x[187]    c3537     -1
    x[187]    c4717     2692
    x[187]    c4718     -2692
    x[187]    c4727     2692
    x[187]    c4728     -2692
    x[187]    OBJ       -48582.2348300783
    x[188]    c649      -1
    x[188]    c650      1
    x[188]    c1687     -1
    x[188]    c2327     -1
    x[188]    c3187     -1
    x[188]    c3347     -1
    x[188]    c3587     -1
    x[188]    c4137     -1
    x[188]    c4717     964
    x[188]    c4718     -964
    x[188]    c4727     288
    x[188]    c4728     -288
    x[188]    c4985     -1
    x[188]    OBJ       -3908.39775466535
    x[189]    c658      -1
    x[189]    c659      1
    x[189]    c2367     -1
    x[189]    c3377     1
    x[189]    c3387     1
    x[189]    c3397     1
    x[189]    c3407     1
    x[189]    c3417     1
    x[189]    c3427     1
    x[189]    c3437     1
    x[189]    c3637     -1
    x[189]    c4717     1432
    x[189]    c4718     -1432
    x[189]    c4727     1432
    x[189]    c4728     -1432
    x[189]    c4874     1
    x[189]    OBJ       -112898.147689181
    x[190]    c667      -1
    x[190]    c668      1
    x[190]    c2437     -1
    x[190]    c3397     -1
    x[190]    c3447     1
    x[190]    c3457     1
    x[190]    c3467     1
    x[190]    c3477     1
    x[190]    c3487     1
    x[190]    c3497     1
    x[190]    c3507     1
    x[190]    c3517     1
    x[190]    c3687     -1
    x[190]    c4717     2872
    x[190]    c4718     -2872
    x[190]    c4727     2872
    x[190]    c4728     -2872
    x[190]    c4794     1
    x[190]    c4802     1
    x[190]    OBJ       -186061.75226435
    x[191]    c676      -1
    x[191]    c677      1
    x[191]    c2497     -1
    x[191]    c3237     -1
    x[191]    c3467     -1
    x[191]    c3527     1
    x[191]    c3537     1
    x[191]    c3547     1
    x[191]    c3557     1
    x[191]    c3567     1
    x[191]    c3747     -1
    x[191]    c4717     2888
    x[191]    c4718     -2888
    x[191]    c4727     2888
    x[191]    c4728     -2888
    x[191]    OBJ       -143724.946880907
    x[192]    c685      -1
    x[192]    c686      1
    x[192]    c2587     -1
    x[192]    c3307     -1
    x[192]    c3547     -1
    x[192]    c3577     1
    x[192]    c3587     1
    x[192]    c3597     1
    x[192]    c3607     1
    x[192]    c3617     1
    x[192]    c3837     -1
    x[192]    c4187     -1
    x[192]    c4717     2692
    x[192]    c4718     -2692
    x[192]    c4727     2692
    x[192]    c4728     -2692
    x[192]    OBJ       -67858.9930259438
    x[193]    c694      -1
    x[193]    c695      1
    x[193]    c2637     -1
    x[193]    c3357     -1
    x[193]    c3597     -1
    x[193]    c3887     -1
    x[193]    c4227     -1
    x[193]    c4717     1168
    x[193]    c4718     -1168
    x[193]    c4727     528
    x[193]    c4728     -528
    x[193]    OBJ       -12971.2765430123
    x[194]    c703      -1
    x[194]    c704      1
    x[194]    c3627     1
    x[194]    c3637     1
    x[194]    c3647     1
    x[194]    c3657     1
    x[194]    c3667     1
    x[194]    c4717     716
    x[194]    c4718     -716
    x[194]    c4727     716
    x[194]    c4728     -716
    x[194]    c4915     1
    x[194]    OBJ       -66858.1229223163
    x[195]    c712      -1
    x[195]    c713      1
    x[195]    c3647     -1
    x[195]    c3677     1
    x[195]    c3687     1
    x[195]    c3697     1
    x[195]    c3707     1
    x[195]    c3717     1
    x[195]    c3727     1
    x[195]    c4717     2864
    x[195]    c4718     -2864
    x[195]    c4727     2864
    x[195]    c4728     -2864
    x[195]    c4828     1
    x[195]    OBJ       -231401.167958675
    x[196]    c721      -1
    x[196]    c722      1
    x[196]    c2687     -1
    x[196]    c3407     -1
    x[196]    c3697     -1
    x[196]    c3737     1
    x[196]    c3747     1
    x[196]    c3757     1
    x[196]    c3767     1
    x[196]    c3777     1
    x[196]    c3787     1
    x[196]    c3797     1
    x[196]    c3807     1
    x[196]    c3817     1
    x[196]    c4717     2864
    x[196]    c4718     -2864
    x[196]    c4727     2864
    x[196]    c4728     -2864
    x[196]    c4980     1
    x[196]    c4985     1
    x[196]    c4986     1
    x[196]    c4987     1
    x[196]    c4988     1
    x[196]    OBJ       -234804.126311009
    x[197]    c730      -1
    x[197]    c731      1
    x[197]    c2767     -1
    x[197]    c3477     -1
    x[197]    c3757     -1
    x[197]    c3827     1
    x[197]    c3837     1
    x[197]    c3847     1
    x[197]    c3857     1
    x[197]    c3867     1
    x[197]    c3937     -1
    x[197]    c4277     -1
    x[197]    c4717     2865
    x[197]    c4718     -2865
    x[197]    c4727     2865
    x[197]    c4728     -2865
    x[197]    c4874     -1
    x[197]    OBJ       -224795.425274734
    x[198]    c739      -1
    x[198]    c740      1
    x[198]    c2847     -1
    x[198]    c3557     -1
    x[198]    c3847     -1
    x[198]    c3877     1
    x[198]    c3887     1
    x[198]    c3897     1
    x[198]    c3907     1
    x[198]    c3917     1
    x[198]    c3997     -1
    x[198]    c4337     -1
    x[198]    c4717     2686
    x[198]    c4718     -2686
    x[198]    c4727     2684
    x[198]    c4728     -2684
    x[198]    c4794     -1
    x[198]    OBJ       -132315.027699554
    x[199]    c748      -1
    x[199]    c749      1
    x[199]    c1357     -1
    x[199]    c2897     -1
    x[199]    c3607     -1
    x[199]    c3897     -1
    x[199]    c4047     -1
    x[199]    c4387     -1
    x[199]    c4717     1152
    x[199]    c4718     -1152
    x[199]    c4727     624
    x[199]    c4728     -624
    x[199]    OBJ       -25912.5269829157
    x[200]    c757      -1
    x[200]    c758      1
    x[200]    c3707     -1
    x[200]    c3927     1
    x[200]    c3937     1
    x[200]    c3947     1
    x[200]    c3957     1
    x[200]    c3967     1
    x[200]    c3977     1
    x[200]    c4717     1432
    x[200]    c4718     -1432
    x[200]    c4727     1432
    x[200]    c4728     -1432
    x[200]    OBJ       -118903.368310946
    x[201]    c766      -1
    x[201]    c767      1
    x[201]    c2937     -1
    x[201]    c3767     -1
    x[201]    c3947     -1
    x[201]    c3987     1
    x[201]    c3997     1
    x[201]    c4007     1
    x[201]    c4017     1
    x[201]    c4027     1
    x[201]    c4437     -1
    x[201]    c4717     2864
    x[201]    c4718     -2864
    x[201]    c4727     2864
    x[201]    c4728     -2864
    x[201]    OBJ       -170648.352668487
    x[202]    c775      -1
    x[202]    c776      1
    x[202]    c3017     -1
    x[202]    c3857     -1
    x[202]    c4007     -1
    x[202]    c4037     1
    x[202]    c4047     1
    x[202]    c4057     1
    x[202]    c4067     1
    x[202]    c4077     1
    x[202]    c4487     -1
    x[202]    c4717     2684
    x[202]    c4718     -2684
    x[202]    c4727     2680
    x[202]    c4728     -2680
    x[202]    c4903     -1
    x[202]    OBJ       -119203.629342034
    x[203]    c784      -1
    x[203]    c785      1
    x[203]    c1527     -1
    x[203]    c3067     -1
    x[203]    c3907     -1
    x[203]    c4057     -1
    x[203]    c4097     -1
    x[203]    c4537     -1
    x[203]    c4717     1099
    x[203]    c4718     -1099
    x[203]    c4727     672
    x[203]    c4728     -672
    x[203]    c4830     -1
    x[203]    OBJ       -37062.2199373259
    x[204]    c793      -1
    x[204]    c794      1
    x[204]    c4017     -1
    x[204]    c4087     1
    x[204]    c4097     1
    x[204]    c4107     1
    x[204]    c4117     1
    x[204]    c4127     1
    x[204]    c4717     1342
    x[204]    c4718     -1342
    x[204]    c4727     1340
    x[204]    c4728     -1340
    x[204]    c4986     -1
    x[204]    OBJ       -28224.5369222952
    x[205]    c802      -1
    x[205]    c803      1
    x[205]    c1697     -1
    x[205]    c3117     -1
    x[205]    c4067     -1
    x[205]    c4107     -1
    x[205]    c4587     -1
    x[205]    c4717     880
    x[205]    c4718     -880
    x[205]    c4727     629
    x[205]    c4728     -629
    x[205]    OBJ       -21688.8551456077
    x[206]    c811      -1
    x[206]    c812      1
    x[206]    c4117     -1
    x[206]    c4717     326
    x[206]    c4718     -326
    x[206]    c4727     256
    x[206]    c4728     -256
    x[206]    OBJ       -8016.96953005619
    x[207]    c820      -1
    x[207]    c821      1
    x[207]    c2527     -1
    x[207]    c3197     -1
    x[207]    c4147     -1
    x[207]    c4717     360
    x[207]    c4718     -360
    x[207]    OBJ       1078.93797171043
    x[208]    c829      -1
    x[208]    c830      1
    x[208]    c2707     -1
    x[208]    c3317     -1
    x[208]    c4137     1
    x[208]    c4147     1
    x[208]    c4157     1
    x[208]    c4167     1
    x[208]    c4177     1
    x[208]    c4197     -1
    x[208]    c4717     1346
    x[208]    c4718     -1346
    x[208]    c4727     1322
    x[208]    c4728     -1322
    x[208]    OBJ       -12861.1808316132
    x[209]    c838      -1
    x[209]    c839      1
    x[209]    c2787     -1
    x[209]    c3367     -1
    x[209]    c4157     -1
    x[209]    c4237     -1
    x[209]    c4717     689
    x[209]    c4718     -689
    x[209]    c4727     241
    x[209]    c4728     -241
    x[209]    OBJ       -5226.54368114274
    x[210]    c847      -1
    x[210]    c848      1
    x[210]    c3487     -1
    x[210]    c4187     1
    x[210]    c4197     1
    x[210]    c4207     1
    x[210]    c4217     1
    x[210]    c4287     -1
    x[210]    c4717     1448
    x[210]    c4718     -1448
    x[210]    c4727     1448
    x[210]    c4728     -1448
    x[210]    OBJ       -49142.7220881097
    x[211]    c856      -1
    x[211]    c857      1
    x[211]    c3567     -1
    x[211]    c4207     -1
    x[211]    c4227     1
    x[211]    c4237     1
    x[211]    c4247     1
    x[211]    c4257     1
    x[211]    c4267     1
    x[211]    c4347     -1
    x[211]    c4717     2692
    x[211]    c4718     -2692
    x[211]    c4727     2668
    x[211]    c4728     -2668
    x[211]    OBJ       -28464.7457471658
    x[212]    c865      -1
    x[212]    c866      1
    x[212]    c1987     -1
    x[212]    c2957     -1
    x[212]    c3617     -1
    x[212]    c4167     -1
    x[212]    c4247     -1
    x[212]    c4397     -1
    x[212]    c4717     828
    x[212]    c4718     -828
    x[212]    c4727     291
    x[212]    c4728     -291
    x[212]    c4987     -1
    x[212]    OBJ       -4377.80583326663
    x[213]    c874      -1
    x[213]    c875      1
    x[213]    c3717     -1
    x[213]    c4277     1
    x[213]    c4287     1
    x[213]    c4297     1
    x[213]    c4307     1
    x[213]    c4317     1
    x[213]    c4327     1
    x[213]    c4717     1432
    x[213]    c4718     -1432
    x[213]    c4727     1432
    x[213]    c4728     -1432
    x[213]    OBJ       -116401.193051877
    x[214]    c883      -1
    x[214]    c884      1
    x[214]    c3777     -1
    x[214]    c4297     -1
    x[214]    c4337     1
    x[214]    c4347     1
    x[214]    c4357     1
    x[214]    c4367     1
    x[214]    c4377     1
    x[214]    c4447     -1
    x[214]    c4717     2880
    x[214]    c4718     -2880
    x[214]    c4727     2880
    x[214]    c4728     -2880
    x[214]    OBJ       -176753.660300615
    x[215]    c892      -1
    x[215]    c893      1
    x[215]    c2157     -1
    x[215]    c3867     -1
    x[215]    c4217     -1
    x[215]    c4357     -1
    x[215]    c4387     1
    x[215]    c4397     1
    x[215]    c4407     1
    x[215]    c4417     1
    x[215]    c4427     1
    x[215]    c4497     -1
    x[215]    c4717     2691
    x[215]    c4718     -2691
    x[215]    c4727     2691
    x[215]    c4728     -2691
    x[215]    OBJ       -60152.2932280121
    x[216]    c901      -1
    x[216]    c902      1
    x[216]    c2227     -1
    x[216]    c3917     -1
    x[216]    c4257     -1
    x[216]    c4407     -1
    x[216]    c4547     -1
    x[216]    c4637     -1
    x[216]    c4717     840
    x[216]    c4718     -840
    x[216]    c4727     543
    x[216]    c4728     -543
    x[216]    OBJ       -17555.2616176262
    x[217]    c910      -1
    x[217]    c911      1
    x[217]    c4437     1
    x[217]    c4447     1
    x[217]    c4457     1
    x[217]    c4467     1
    x[217]    c4477     1
    x[217]    c4717     716
    x[217]    c4718     -716
    x[217]    c4727     716
    x[217]    c4728     -716
    x[217]    OBJ       -59151.4231243846
    x[218]    c919      -1
    x[218]    c920      1
    x[218]    c2377     -1
    x[218]    c3957     -1
    x[218]    c4307     -1
    x[218]    c4457     -1
    x[218]    c4487     1
    x[218]    c4497     1
    x[218]    c4507     1
    x[218]    c4517     1
    x[218]    c4527     1
    x[218]    c4717     2148
    x[218]    c4718     -2148
    x[218]    c4727     2148
    x[218]    c4728     -2148
    x[218]    OBJ       -150130.515544123
    x[219]    c928      -1
    x[219]    c929      1
    x[219]    c2447     -1
    x[219]    c4027     -1
    x[219]    c4367     -1
    x[219]    c4507     -1
    x[219]    c4537     1
    x[219]    c4547     1
    x[219]    c4557     1
    x[219]    c4567     1
    x[219]    c4577     1
    x[219]    c4717     2684
    x[219]    c4718     -2684
    x[219]    c4727     2680
    x[219]    c4728     -2680
    x[219]    OBJ       -132315.027699554
    x[220]    c937      -1
    x[220]    c938      1
    x[220]    c2537     -1
    x[220]    c4077     -1
    x[220]    c4417     -1
    x[220]    c4557     -1
    x[220]    c4597     -1
    x[220]    c4677     -1
    x[220]    c4717     841
    x[220]    c4718     -841
    x[220]    c4727     480
    x[220]    c4728     -480
    x[220]    c4988     -1
    x[220]    OBJ       -31137.0689238512
    x[221]    c946      -1
    x[221]    c947      1
    x[221]    c2717     -1
    x[221]    c4517     -1
    x[221]    c4587     1
    x[221]    c4597     1
    x[221]    c4607     1
    x[221]    c4617     1
    x[221]    c4627     1
    x[221]    c4717     671
    x[221]    c4718     -671
    x[221]    c4727     670
    x[221]    c4728     -670
    x[221]    OBJ       -23620.5344456087
    x[222]    c955      -1
    x[222]    c956      1
    x[222]    c2797     -1
    x[222]    c4127     -1
    x[222]    c4567     -1
    x[222]    c4607     -1
    x[222]    c4717     754
    x[222]    c4718     -754
    x[222]    c4727     450
    x[222]    c4728     -450
    x[222]    OBJ       -27553.9539528648
    x[223]    c964      -1
    x[223]    c965      1
    x[223]    c2967     -1
    x[223]    c4617     -1
    x[223]    c4717     289
    x[223]    c4718     -289
    x[223]    c4727     186
    x[223]    c4728     -186
    x[223]    OBJ       -7336.3778595895
    x[224]    c973      -1
    x[224]    c974      1
    x[224]    c3807     -1
    x[224]    c4177     -1
    x[224]    c4717     150
    x[224]    c4718     -150
    x[224]    OBJ       450.39154663237
    x[225]    c982      -1
    x[225]    c983      1
    x[225]    c3977     -1
    x[225]    c4267     -1
    x[225]    c4647     -1
    x[225]    c4717     315
    x[225]    c4718     -315
    x[225]    c4727     52
    x[225]    c4728     -52
    x[225]    OBJ       -177.154008342065
    x[226]    c991      -1
    x[226]    c992      1
    x[226]    c4377     -1
    x[226]    c4637     1
    x[226]    c4647     1
    x[226]    c4657     1
    x[226]    c4667     1
    x[226]    c4717     1346
    x[226]    c4718     -1346
    x[226]    c4727     1322
    x[226]    c4728     -1322
    x[226]    OBJ       -19096.6015772125
    x[227]    c1000     -1
    x[227]    c1001     1
    x[227]    c3267     -1
    x[227]    c4427     -1
    x[227]    c4657     -1
    x[227]    c4687     -1
    x[227]    c4717     548
    x[227]    c4718     -548
    x[227]    c4727     133
    x[227]    c4728     -133
    x[227]    OBJ       -2865.4911066855
    x[228]    c1009     -1
    x[228]    c1010     1
    x[228]    c3437     -1
    x[228]    c4527     -1
    x[228]    c4677     1
    x[228]    c4687     1
    x[228]    c4697     1
    x[228]    c4707     1
    x[228]    c4717     672
    x[228]    c4718     -672
    x[228]    c4727     672
    x[228]    c4728     -672
    x[228]    OBJ       -16814.6177409418
    x[229]    c1018     -1
    x[229]    c1019     1
    x[229]    c3517     -1
    x[229]    c4577     -1
    x[229]    c4667     -1
    x[229]    c4697     -1
    x[229]    c4717     429
    x[229]    c4718     -429
    x[229]    c4727     142
    x[229]    c4728     -142
    x[229]    OBJ       -6065.27282798258
    x[230]    c1027     -1
    x[230]    c1028     1
    x[230]    c3817     -1
    x[230]    c4627     -1
    x[230]    c4707     -1
    x[230]    c4717     273
    x[230]    c4718     -273
    x[230]    c4727     94
    x[230]    c4728     -94
    x[230]    OBJ       -5644.90738445904
    x[231]    c2        -1
    x[231]    c3        1
    x[231]    c2388     -1
    x[231]    c4718     219
    x[231]    c4719     -219
    x[231]    c4728     75
    x[231]    c4729     -75
    x[231]    OBJ       -1899.90907168904
    x[232]    c11       -1
    x[232]    c12       1
    x[232]    c1338     -1
    x[232]    c4718     328
    x[232]    c4719     -328
    x[232]    c4728     215
    x[232]    c4729     -215
    x[232]    OBJ       -3877.89659837899
    x[233]    c20       -1
    x[233]    c21       1
    x[233]    c1508     -1
    x[233]    c3668     -1
    x[233]    c4718     545
    x[233]    c4719     -545
    x[233]    c4728     368
    x[233]    c4729     -368
    x[233]    OBJ       -8857.56695065984
    x[234]    c29       -1
    x[234]    c30       1
    x[234]    c1068     -1
    x[234]    c1678     -1
    x[234]    c4718     435
    x[234]    c4719     -435
    x[234]    c4728     400
    x[234]    c4729     -400
    x[234]    OBJ       -13507.572715159
    x[235]    c38       -1
    x[235]    c39       1
    x[235]    c1118     -1
    x[235]    c4718     247
    x[235]    c4719     -247
    x[235]    c4728     216
    x[235]    c4729     -216
    x[235]    OBJ       -6020.71641895977
    x[236]    c47       -1
    x[236]    c48       1
    x[236]    c1968     -1
    x[236]    c4718     82
    x[236]    c4719     -82
    x[236]    c4728     27
    x[236]    c4729     -27
    x[236]    OBJ       -632.435485507446
    x[237]    c56       -1
    x[237]    c57       1
    x[237]    c1078     -1
    x[237]    c1238     -1
    x[237]    c2508     -1
    x[237]    c4718     526
    x[237]    c4719     -526
    x[237]    c4728     314
    x[237]    c4729     -314
    x[237]    OBJ       -5860.22181701344
    x[238]    c65       -1
    x[238]    c66       1
    x[238]    c1038     1
    x[238]    c1048     1
    x[238]    c1058     1
    x[238]    c1288     -1
    x[238]    c4718     693
    x[238]    c4719     -693
    x[238]    c4728     693
    x[238]    c4729     -693
    x[238]    OBJ       -44851.7347060836
    x[239]    c74       -1
    x[239]    c75       1
    x[239]    c1038     -1
    x[239]    c1068     1
    x[239]    c1078     1
    x[239]    c1088     1
    x[239]    c1098     1
    x[239]    c1108     1
    x[239]    c1368     -1
    x[239]    c2698     -1
    x[239]    c4718     1944
    x[239]    c4719     -1944
    x[239]    c4728     1944
    x[239]    c4729     -1944
    x[239]    OBJ       -67060.7174619007
    x[240]    c83       -1
    x[240]    c84       1
    x[240]    c1088     -1
    x[240]    c1128     -1
    x[240]    c1418     -1
    x[240]    c2778     -1
    x[240]    c4718     907
    x[240]    c4719     -907
    x[240]    c4728     574
    x[240]    c4729     -574
    x[240]    c4890     -1
    x[240]    OBJ       -19415.5091435619
    x[241]    c92       -1
    x[241]    c93       1
    x[241]    c1048     -1
    x[241]    c1118     1
    x[241]    c1128     1
    x[241]    c1138     1
    x[241]    c1148     1
    x[241]    c1158     1
    x[241]    c1538     -1
    x[241]    c4718     1296
    x[241]    c4719     -1296
    x[241]    c4728     1128
    x[241]    c4729     -1128
    x[241]    OBJ       -21379.6160560295
    x[242]    c101      -1
    x[242]    c102      1
    x[242]    c1098     -1
    x[242]    c1138     -1
    x[242]    c1168     -1
    x[242]    c1588     -1
    x[242]    c1978     -1
    x[242]    c2948     -1
    x[242]    c4718     1043
    x[242]    c4719     -1043
    x[242]    c4728     864
    x[242]    c4729     -864
    x[242]    OBJ       -17753.3055904312
    x[243]    c110      -1
    x[243]    c111      1
    x[243]    c1168     1
    x[243]    c1178     1
    x[243]    c1188     1
    x[243]    c1198     1
    x[243]    c1708     -1
    x[243]    c2148     -1
    x[243]    c4718     1332
    x[243]    c4719     -1332
    x[243]    c4728     1330
    x[243]    c4729     -1330
    x[243]    OBJ       -40687.5504393679
    x[244]    c119      -1
    x[244]    c120      1
    x[244]    c1148     -1
    x[244]    c1178     -1
    x[244]    c1758     -1
    x[244]    c2218     -1
    x[244]    c4718     1186
    x[244]    c4719     -1186
    x[244]    c4728     864
    x[244]    c4729     -864
    x[244]    OBJ       -24620.7394769565
    x[245]    c128      -1
    x[245]    c129      1
    x[245]    c1188     -1
    x[245]    c1838     -1
    x[245]    c2518     -1
    x[245]    c4718     984
    x[245]    c4719     -984
    x[245]    c4728     723
    x[245]    c4729     -723
    x[245]    c4935     -1
    x[245]    OBJ       -12223.6158995884
    x[246]    c137      -1
    x[246]    c138      1
    x[246]    c1248     -1
    x[246]    c1888     -1
    x[246]    c3248     -1
    x[246]    c4718     225
    x[246]    c4719     -225
    x[246]    c4728     20
    x[246]    c4729     -20
    x[246]    OBJ       49.4496881672488
    x[247]    c146      -1
    x[247]    c147      1
    x[247]    c1208     1
    x[247]    c1218     1
    x[247]    c1228     1
    x[247]    c1298     -1
    x[247]    c1928     -1
    x[247]    c4718     724
    x[247]    c4719     -724
    x[247]    c4728     724
    x[247]    c4729     -724
    x[247]    OBJ       -33400.2279726155
    x[248]    c155      -1
    x[248]    c156      1
    x[248]    c1208     -1
    x[248]    c1238     1
    x[248]    c1248     1
    x[248]    c1258     1
    x[248]    c1268     1
    x[248]    c1278     1
    x[248]    c1378     -1
    x[248]    c1998     -1
    x[248]    c3418     -1
    x[248]    c4718     1989
    x[248]    c4719     -1989
    x[248]    c4728     1989
    x[248]    c4729     -1989
    x[248]    OBJ       -28958.4314214521
    x[249]    c164      -1
    x[249]    c165      1
    x[249]    c1258     -1
    x[249]    c1428     -1
    x[249]    c2048     -1
    x[249]    c3498     -1
    x[249]    c4718     710
    x[249]    c4719     -710
    x[249]    c4728     382
    x[249]    c4729     -382
    x[249]    OBJ       -8102.80855231762
    x[250]    c173      -1
    x[250]    c174      1
    x[250]    c1288     1
    x[250]    c1298     1
    x[250]    c1308     1
    x[250]    c1318     1
    x[250]    c1328     1
    x[250]    c1338     1
    x[250]    c1348     1
    x[250]    c1358     1
    x[250]    c2098     -1
    x[250]    c4718     716
    x[250]    c4719     -716
    x[250]    c4728     716
    x[250]    c4729     -716
    x[250]    c4963     1
    x[250]    OBJ       -50577.4880728177
    x[251]    c182      -1
    x[251]    c183      1
    x[251]    c1308     -1
    x[251]    c1368     1
    x[251]    c1378     1
    x[251]    c1388     1
    x[251]    c1398     1
    x[251]    c1408     1
    x[251]    c1468     -1
    x[251]    c2168     -1
    x[251]    c3658     -1
    x[251]    c4718     2876
    x[251]    c4719     -2876
    x[251]    c4728     2876
    x[251]    c4729     -2876
    x[251]    OBJ       -159974.078912995
    x[252]    c191      -1
    x[252]    c192      1
    x[252]    c1058     -1
    x[252]    c1218     -1
    x[252]    c1388     -1
    x[252]    c1418     1
    x[252]    c1428     1
    x[252]    c1438     1
    x[252]    c1448     1
    x[252]    c1458     1
    x[252]    c1548     -1
    x[252]    c2238     -1
    x[252]    c3728     -1
    x[252]    c4718     2595
    x[252]    c4719     -2595
    x[252]    c4728     2595
    x[252]    c4729     -2595
    x[252]    c4774     -1
    x[252]    c4775     -1
    x[252]    OBJ       -34224.3894420696
    x[253]    c200      -1
    x[253]    c201      1
    x[253]    c1108     -1
    x[253]    c1268     -1
    x[253]    c1438     -1
    x[253]    c1598     -1
    x[253]    c2288     -1
    x[253]    c3788     -1
    x[253]    c4718     1030
    x[253]    c4719     -1030
    x[253]    c4728     552
    x[253]    c4729     -552
    x[253]    c4924     -1
    x[253]    OBJ       -4580.60269338726
    x[254]    c209      -1
    x[254]    c210      1
    x[254]    c1468     1
    x[254]    c1478     1
    x[254]    c1488     1
    x[254]    c1498     1
    x[254]    c1508     1
    x[254]    c1518     1
    x[254]    c1528     1
    x[254]    c2398     -1
    x[254]    c4718     1432
    x[254]    c4719     -1432
    x[254]    c4728     1432
    x[254]    c4729     -1432
    x[254]    OBJ       -93780.899839993
    x[255]    c218      -1
    x[255]    c219      1
    x[255]    c1318     -1
    x[255]    c1478     -1
    x[255]    c1538     1
    x[255]    c1548     1
    x[255]    c1558     1
    x[255]    c1568     1
    x[255]    c1578     1
    x[255]    c1638     -1
    x[255]    c2458     -1
    x[255]    c4718     2864
    x[255]    c4719     -2864
    x[255]    c4728     2864
    x[255]    c4729     -2864
    x[255]    OBJ       -128482.435395957
    x[256]    c227      -1
    x[256]    c228      1
    x[256]    c1398     -1
    x[256]    c1558     -1
    x[256]    c1588     1
    x[256]    c1598     1
    x[256]    c1608     1
    x[256]    c1618     1
    x[256]    c1628     1
    x[256]    c1718     -1
    x[256]    c2548     -1
    x[256]    c4718     2600
    x[256]    c4719     -2600
    x[256]    c4728     2336
    x[256]    c4729     -2336
    x[256]    c4885     -1
    x[256]    OBJ       -49050.6205083553
    x[257]    c236      -1
    x[257]    c237      1
    x[257]    c1158     -1
    x[257]    c1448     -1
    x[257]    c1608     -1
    x[257]    c1768     -1
    x[257]    c2598     -1
    x[257]    c3968     -1
    x[257]    c4718     1156
    x[257]    c4719     -1156
    x[257]    c4728     696
    x[257]    c4729     -696
    x[257]    c4819     -1
    x[257]    OBJ       -11373.4282784672
    x[258]    c245      -1
    x[258]    c246      1
    x[258]    c1638     1
    x[258]    c1648     1
    x[258]    c1658     1
    x[258]    c1668     1
    x[258]    c1678     1
    x[258]    c1688     1
    x[258]    c1698     1
    x[258]    c2648     -1
    x[258]    c4718     716
    x[258]    c4719     -716
    x[258]    c4728     716
    x[258]    c4729     -716
    x[258]    c4966     1
    x[258]    OBJ       -46933.8268394415
    x[259]    c254      -1
    x[259]    c255      1
    x[259]    c1488     -1
    x[259]    c1648     -1
    x[259]    c1708     1
    x[259]    c1718     1
    x[259]    c1728     1
    x[259]    c1738     1
    x[259]    c1748     1
    x[259]    c2728     -1
    x[259]    c4718     2864
    x[259]    c4719     -2864
    x[259]    c4728     2864
    x[259]    c4729     -2864
    x[259]    OBJ       -145659.695496159
    x[260]    c263      -1
    x[260]    c264      1
    x[260]    c1568     -1
    x[260]    c1728     -1
    x[260]    c1758     1
    x[260]    c1768     1
    x[260]    c1778     1
    x[260]    c1788     1
    x[260]    c1798     1
    x[260]    c1808     -1
    x[260]    c2808     -1
    x[260]    c4718     2681
    x[260]    c4719     -2681
    x[260]    c4728     2678
    x[260]    c4729     -2678
    x[260]    OBJ       -135683.00402382
    x[261]    c272      -1
    x[261]    c273      1
    x[261]    c1198     -1
    x[261]    c1618     -1
    x[261]    c1778     -1
    x[261]    c1848     -1
    x[261]    c2858     -1
    x[261]    c3258     -1
    x[261]    c4718     1263
    x[261]    c4719     -1263
    x[261]    c4728     864
    x[261]    c4729     -864
    x[261]    c4925     -1
    x[261]    OBJ       -49015.9189727993
    x[262]    c281      -1
    x[262]    c282      1
    x[262]    c1658     -1
    x[262]    c1808     1
    x[262]    c1818     1
    x[262]    c1828     1
    x[262]    c2908     -1
    x[262]    c4718     716
    x[262]    c4719     -716
    x[262]    c4728     716
    x[262]    c4729     -716
    x[262]    OBJ       -31751.9050337072
    x[263]    c290      -1
    x[263]    c291      1
    x[263]    c1738     -1
    x[263]    c1818     -1
    x[263]    c1838     1
    x[263]    c1848     1
    x[263]    c1858     1
    x[263]    c1868     1
    x[263]    c1878     1
    x[263]    c2978     -1
    x[263]    c3428     -1
    x[263]    c4718     1965
    x[263]    c4719     -1965
    x[263]    c4728     1964
    x[263]    c4729     -1964
    x[263]    OBJ       -56563.5029562215
    x[264]    c299      -1
    x[264]    c300      1
    x[264]    c1788     -1
    x[264]    c1858     -1
    x[264]    c3028     -1
    x[264]    c3508     -1
    x[264]    c4718     1245
    x[264]    c4719     -1245
    x[264]    c4728     889
    x[264]    c4729     -889
    x[264]    c4892     -1
    x[264]    OBJ       -27474.9407764346
    x[265]    c308      -1
    x[265]    c309      1
    x[265]    c1868     -1
    x[265]    c3078     -1
    x[265]    c3798     -1
    x[265]    c4718     832
    x[265]    c4719     -832
    x[265]    c4728     647
    x[265]    c4729     -647
    x[265]    OBJ       -8236.40946420809
    x[266]    c317      -1
    x[266]    c318      1
    x[266]    c4718     339
    x[266]    c4719     -339
    x[266]    c4728     283
    x[266]    c4729     -283
    x[266]    OBJ       -4849.53959394598
    x[267]    c326      -1
    x[267]    c327      1
    x[267]    c1888     1
    x[267]    c1898     1
    x[267]    c1908     1
    x[267]    c1918     1
    x[267]    c2008     -1
    x[267]    c4718     1346
    x[267]    c4719     -1346
    x[267]    c4728     1346
    x[267]    c4729     -1346
    x[267]    OBJ       -39820.0120504688
    x[268]    c335      -1
    x[268]    c336      1
    x[268]    c1898     -1
    x[268]    c2058     -1
    x[268]    c4718     243
    x[268]    c4719     -243
    x[268]    OBJ       630.526901051868
    x[269]    c344      -1
    x[269]    c345      1
    x[269]    c1928     1
    x[269]    c1938     1
    x[269]    c1948     1
    x[269]    c1958     1
    x[269]    c1968     1
    x[269]    c1978     1
    x[269]    c1988     1
    x[269]    c2108     -1
    x[269]    c4718     724
    x[269]    c4719     -724
    x[269]    c4728     724
    x[269]    c4729     -724
    x[269]    OBJ       -45719.2730949827
    x[270]    c353      -1
    x[270]    c354      1
    x[270]    c1938     -1
    x[270]    c1998     1
    x[270]    c2008     1
    x[270]    c2018     1
    x[270]    c2028     1
    x[270]    c2038     1
    x[270]    c2178     -1
    x[270]    c4718     2896
    x[270]    c4719     -2896
    x[270]    c4728     2896
    x[270]    c4729     -2896
    x[270]    OBJ       -141408.757390554
    x[271]    c362      -1
    x[271]    c363      1
    x[271]    c1228     -1
    x[271]    c2018     -1
    x[271]    c2048     1
    x[271]    c2058     1
    x[271]    c2068     1
    x[271]    c2078     1
    x[271]    c2088     1
    x[271]    c2248     -1
    x[271]    c3128     -1
    x[271]    c4718     2692
    x[271]    c4719     -2692
    x[271]    c4728     2692
    x[271]    c4729     -2692
    x[271]    OBJ       -70704.3786952769
    x[272]    c371      -1
    x[272]    c372      1
    x[272]    c1278     -1
    x[272]    c1908     -1
    x[272]    c2068     -1
    x[272]    c2298     -1
    x[272]    c3158     -1
    x[272]    c4718     755
    x[272]    c4719     -755
    x[272]    c4728     323
    x[272]    c4729     -323
    x[272]    c4888     -1
    x[272]    OBJ       -5966.06150045913
    x[273]    c380      -1
    x[273]    c381      1
    x[273]    c2098     1
    x[273]    c2108     1
    x[273]    c2118     1
    x[273]    c2128     1
    x[273]    c2138     1
    x[273]    c2148     1
    x[273]    c2158     1
    x[273]    c2338     -1
    x[273]    c4718     1432
    x[273]    c4719     -1432
    x[273]    c4728     1432
    x[273]    c4729     -1432
    x[273]    OBJ       -96557.0226844701
    x[274]    c389      -1
    x[274]    c390      1
    x[274]    c2118     -1
    x[274]    c2168     1
    x[274]    c2178     1
    x[274]    c2188     1
    x[274]    c2198     1
    x[274]    c2208     1
    x[274]    c2218     1
    x[274]    c2228     1
    x[274]    c2408     -1
    x[274]    c4718     2886
    x[274]    c4719     -2886
    x[274]    c4728     2886
    x[274]    c4729     -2886
    x[274]    c4964     1
    x[274]    OBJ       -181922.800152142
    x[275]    c398      -1
    x[275]    c399      1
    x[275]    c1328     -1
    x[275]    c1948     -1
    x[275]    c2188     -1
    x[275]    c2238     1
    x[275]    c2248     1
    x[275]    c2258     1
    x[275]    c2268     1
    x[275]    c2278     1
    x[275]    c2468     -1
    x[275]    c3208     -1
    x[275]    c4718     2895
    x[275]    c4719     -2895
    x[275]    c4728     2895
    x[275]    c4729     -2895
    x[275]    c4866     1
    x[275]    c4869     1
    x[275]    OBJ       -151385.448862894
    x[276]    c407      -1
    x[276]    c408      1
    x[276]    c1408     -1
    x[276]    c2028     -1
    x[276]    c2258     -1
    x[276]    c2288     1
    x[276]    c2298     1
    x[276]    c2308     1
    x[276]    c2318     1
    x[276]    c2328     1
    x[276]    c2558     -1
    x[276]    c3278     -1
    x[276]    c4718     2692
    x[276]    c4719     -2692
    x[276]    c4728     2668
    x[276]    c4729     -2668
    x[276]    OBJ       -59426.3796395885
    x[277]    c416      -1
    x[277]    c417      1
    x[277]    c1458     -1
    x[277]    c2078     -1
    x[277]    c2308     -1
    x[277]    c2608     -1
    x[277]    c3328     -1
    x[277]    c4318     -1
    x[277]    c4718     1115
    x[277]    c4719     -1115
    x[277]    c4728     408
    x[277]    c4729     -408
    x[277]    c4927     -1
    x[277]    OBJ       -4374.99609521817
    x[278]    c425      -1
    x[278]    c426      1
    x[278]    c2338     1
    x[278]    c2348     1
    x[278]    c2358     1
    x[278]    c2368     1
    x[278]    c2378     1
    x[278]    c2388     1
    x[278]    c4718     1432
    x[278]    c4719     -1432
    x[278]    c4728     1432
    x[278]    c4729     -1432
    x[278]    c4842     1
    x[278]    OBJ       -110177.375390186
    x[279]    c434      -1
    x[279]    c435      1
    x[279]    c2348     -1
    x[279]    c2398     1
    x[279]    c2408     1
    x[279]    c2418     1
    x[279]    c2428     1
    x[279]    c2438     1
    x[279]    c2448     1
    x[279]    c4718     2864
    x[279]    c4719     -2864
    x[279]    c4728     2864
    x[279]    c4729     -2864
    x[279]    OBJ       -201615.921580151
    x[280]    c443      -1
    x[280]    c444      1
    x[280]    c2128     -1
    x[280]    c2418     -1
    x[280]    c2458     1
    x[280]    c2468     1
    x[280]    c2478     1
    x[280]    c2488     1
    x[280]    c2498     1
    x[280]    c2508     1
    x[280]    c2518     1
    x[280]    c2528     1
    x[280]    c2538     1
    x[280]    c2658     -1
    x[280]    c3378     -1
    x[280]    c4718     2864
    x[280]    c4719     -2864
    x[280]    c4728     2864
    x[280]    c4729     -2864
    x[280]    c4885     1
    x[280]    c4888     1
    x[280]    c4889     1
    x[280]    c4890     1
    x[280]    c4892     1
    x[280]    OBJ       -190424.676363353
    x[281]    c452      -1
    x[281]    c453      1
    x[281]    c1498     -1
    x[281]    c2198     -1
    x[281]    c2478     -1
    x[281]    c2548     1
    x[281]    c2558     1
    x[281]    c2568     1
    x[281]    c2578     1
    x[281]    c2588     1
    x[281]    c2738     -1
    x[281]    c3448     -1
    x[281]    c4718     2873
    x[281]    c4719     -2873
    x[281]    c4728     2873
    x[281]    c4729     -2873
    x[281]    OBJ       -146440.480046169
    x[282]    c461      -1
    x[282]    c462      1
    x[282]    c1578     -1
    x[282]    c2268     -1
    x[282]    c2568     -1
    x[282]    c2598     1
    x[282]    c2608     1
    x[282]    c2618     1
    x[282]    c2628     1
    x[282]    c2638     1
    x[282]    c2818     -1
    x[282]    c3528     -1
    x[282]    c4718     2679
    x[282]    c4719     -2679
    x[282]    c4728     2604
    x[282]    c4729     -2604
    x[282]    c4963     -1
    x[282]    c4964     -1
    x[282]    c4966     -1
    x[282]    OBJ       -50863.7757411544
    x[283]    c470      -1
    x[283]    c471      1
    x[283]    c1628     -1
    x[283]    c2318     -1
    x[283]    c2618     -1
    x[283]    c2868     -1
    x[283]    c3578     -1
    x[283]    c4468     -1
    x[283]    c4718     1252
    x[283]    c4719     -1252
    x[283]    c4728     552
    x[283]    c4729     -552
    x[283]    c4866     -1
    x[283]    OBJ       -10022.6710069513
    x[284]    c479      -1
    x[284]    c480      1
    x[284]    c2358     -1
    x[284]    c2648     1
    x[284]    c2658     1
    x[284]    c2668     1
    x[284]    c2678     1
    x[284]    c2688     1
    x[284]    c2698     1
    x[284]    c2708     1
    x[284]    c2718     1
    x[284]    c3628     -1
    x[284]    c4718     2148
    x[284]    c4719     -2148
    x[284]    c4728     2148
    x[284]    c4729     -2148
    x[284]    c4774     1
    x[284]    OBJ       -133687.665729352
    x[285]    c488      -1
    x[285]    c489      1
    x[285]    c2428     -1
    x[285]    c2668     -1
    x[285]    c2728     1
    x[285]    c2738     1
    x[285]    c2748     1
    x[285]    c2758     1
    x[285]    c2768     1
    x[285]    c2778     1
    x[285]    c2788     1
    x[285]    c2798     1
    x[285]    c3678     -1
    x[285]    c4718     2864
    x[285]    c4719     -2864
    x[285]    c4728     2864
    x[285]    c4729     -2864
    x[285]    c4919     1
    x[285]    c4924     1
    x[285]    c4925     1
    x[285]    c4927     1
    x[285]    c4928     1
    x[285]    c4932     -1
    x[285]    c4935     1
    x[285]    OBJ       -174461.97000761
    x[286]    c497      -1
    x[286]    c498      1
    x[286]    c1668     -1
    x[286]    c2488     -1
    x[286]    c2748     -1
    x[286]    c2808     1
    x[286]    c2818     1
    x[286]    c2828     1
    x[286]    c2838     1
    x[286]    c2848     1
    x[286]    c2918     -1
    x[286]    c3738     -1
    x[286]    c4718     2864
    x[286]    c4719     -2864
    x[286]    c4728     2864
    x[286]    c4729     -2864
    x[286]    c4841     -1
    x[286]    c4842     -1
    x[286]    c4843     1
    x[286]    c4844     1
    x[286]    OBJ       -159627.063557435
    x[287]    c506      -1
    x[287]    c507      1
    x[287]    c1748     -1
    x[287]    c2578     -1
    x[287]    c2828     -1
    x[287]    c2858     1
    x[287]    c2868     1
    x[287]    c2878     1
    x[287]    c2888     1
    x[287]    c2898     1
    x[287]    c2988     -1
    x[287]    c3828     -1
    x[287]    c4718     2684
    x[287]    c4719     -2684
    x[287]    c4728     2680
    x[287]    c4729     -2680
    x[287]    c4737     -1
    x[287]    OBJ       -135683.00402382
    x[288]    c515      -1
    x[288]    c516      1
    x[288]    c1798     -1
    x[288]    c2628     -1
    x[288]    c2878     -1
    x[288]    c3038     -1
    x[288]    c3878     -1
    x[288]    c4718     1253
    x[288]    c4719     -1253
    x[288]    c4728     840
    x[288]    c4729     -840
    x[288]    c4889     -1
    x[288]    OBJ       -37477.6584004413
    x[289]    c524      -1
    x[289]    c525      1
    x[289]    c2678     -1
    x[289]    c2908     1
    x[289]    c2918     1
    x[289]    c2928     1
    x[289]    c2938     1
    x[289]    c2948     1
    x[289]    c2958     1
    x[289]    c2968     1
    x[289]    c4718     716
    x[289]    c4719     -716
    x[289]    c4728     716
    x[289]    c4729     -716
    x[289]    OBJ       -50317.2265561479
    x[290]    c533      -1
    x[290]    c534      1
    x[290]    c2758     -1
    x[290]    c2928     -1
    x[290]    c2978     1
    x[290]    c2988     1
    x[290]    c2998     1
    x[290]    c3008     1
    x[290]    c3018     1
    x[290]    c3928     -1
    x[290]    c4718     2864
    x[290]    c4719     -2864
    x[290]    c4728     2864
    x[290]    c4729     -2864
    x[290]    OBJ       -140194.203646095
    x[291]    c542      -1
    x[291]    c543      1
    x[291]    c1828     -1
    x[291]    c2838     -1
    x[291]    c2998     -1
    x[291]    c3028     1
    x[291]    c3038     1
    x[291]    c3048     1
    x[291]    c3058     1
    x[291]    c3068     1
    x[291]    c3988     -1
    x[291]    c4718     2651
    x[291]    c4719     -2651
    x[291]    c4728     2650
    x[291]    c4729     -2650
    x[291]    OBJ       -107921.775579048
    x[292]    c551      -1
    x[292]    c552      1
    x[292]    c1878     -1
    x[292]    c2888     -1
    x[292]    c3048     -1
    x[292]    c3088     -1
    x[292]    c4038     -1
    x[292]    c4718     1175
    x[292]    c4719     -1175
    x[292]    c4728     768
    x[292]    c4729     -768
    x[292]    OBJ       -33087.9141526118
    x[293]    c560      -1
    x[293]    c561      1
    x[293]    c3008     -1
    x[293]    c3078     1
    x[293]    c3088     1
    x[293]    c3098     1
    x[293]    c3108     1
    x[293]    c3118     1
    x[293]    c4718     1333
    x[293]    c4719     -1333
    x[293]    c4728     1332
    x[293]    c4729     -1332
    x[293]    c4928     -1
    x[293]    OBJ       -37911.4275948908
    x[294]    c569      -1
    x[294]    c570      1
    x[294]    c3058     -1
    x[294]    c3098     -1
    x[294]    c4088     -1
    x[294]    c4328     -1
    x[294]    c4718     940
    x[294]    c4719     -940
    x[294]    c4728     728
    x[294]    c4729     -728
    x[294]    c4844     -1
    x[294]    OBJ       -25991.4501314171
    x[295]    c578      -1
    x[295]    c579      1
    x[295]    c3108     -1
    x[295]    c4478     -1
    x[295]    c4718     342
    x[295]    c4719     -342
    x[295]    c4728     317
    x[295]    c4729     -317
    x[295]    OBJ       -6419.78407785336
    x[296]    c587      -1
    x[296]    c588      1
    x[296]    c1348     -1
    x[296]    c1918     -1
    x[296]    c3168     -1
    x[296]    c4718     187
    x[296]    c4719     -187
    x[296]    OBJ       478.620929155635
    x[297]    c596      -1
    x[297]    c597      1
    x[297]    c1958     -1
    x[297]    c3128     1
    x[297]    c3138     1
    x[297]    c3148     1
    x[297]    c3218     -1
    x[297]    c4718     724
    x[297]    c4719     -724
    x[297]    c4728     724
    x[297]    c4729     -724
    x[297]    OBJ       -25679.1363114135
    x[298]    c605      -1
    x[298]    c606      1
    x[298]    c2038     -1
    x[298]    c3138     -1
    x[298]    c3158     1
    x[298]    c3168     1
    x[298]    c3178     1
    x[298]    c3188     1
    x[298]    c3198     1
    x[298]    c3288     -1
    x[298]    c4718     2019
    x[298]    c4719     -2019
    x[298]    c4728     1995
    x[298]    c4729     -1995
    x[298]    OBJ       -30086.2313270209
    x[299]    c614      -1
    x[299]    c615      1
    x[299]    c1518     -1
    x[299]    c2088     -1
    x[299]    c3178     -1
    x[299]    c3338     -1
    x[299]    c4718     660
    x[299]    c4719     -660
    x[299]    c4728     174
    x[299]    c4729     -174
    x[299]    c4869     -1
    x[299]    OBJ       -3475.35878592981
    x[300]    c623      -1
    x[300]    c624      1
    x[300]    c2138     -1
    x[300]    c3208     1
    x[300]    c3218     1
    x[300]    c3228     1
    x[300]    c3238     1
    x[300]    c3248     1
    x[300]    c3258     1
    x[300]    c3268     1
    x[300]    c3388     -1
    x[300]    c4718     1447
    x[300]    c4719     -1447
    x[300]    c4728     1447
    x[300]    c4729     -1447
    x[300]    c4775     1
    x[300]    OBJ       -76516.8859009009
    x[301]    c632      -1
    x[301]    c633      1
    x[301]    c2208     -1
    x[301]    c3228     -1
    x[301]    c3278     1
    x[301]    c3288     1
    x[301]    c3298     1
    x[301]    c3308     1
    x[301]    c3318     1
    x[301]    c3458     -1
    x[301]    c4718     2896
    x[301]    c4719     -2896
    x[301]    c4728     2896
    x[301]    c4729     -2896
    x[301]    OBJ       -103237.068278993
    x[302]    c641      -1
    x[302]    c642      1
    x[302]    c2278     -1
    x[302]    c3148     -1
    x[302]    c3298     -1
    x[302]    c3328     1
    x[302]    c3338     1
    x[302]    c3348     1
    x[302]    c3358     1
    x[302]    c3368     1
    x[302]    c3538     -1
    x[302]    c4718     2692
    x[302]    c4719     -2692
    x[302]    c4728     2692
    x[302]    c4729     -2692
    x[302]    OBJ       -42110.3133971625
    x[303]    c650      -1
    x[303]    c651      1
    x[303]    c1688     -1
    x[303]    c2328     -1
    x[303]    c3188     -1
    x[303]    c3348     -1
    x[303]    c3588     -1
    x[303]    c4138     -1
    x[303]    c4718     964
    x[303]    c4719     -964
    x[303]    c4728     288
    x[303]    c4729     -288
    x[303]    c4745     -1
    x[303]    OBJ       -3387.737408651
    x[304]    c659      -1
    x[304]    c660      1
    x[304]    c2368     -1
    x[304]    c3378     1
    x[304]    c3388     1
    x[304]    c3398     1
    x[304]    c3408     1
    x[304]    c3418     1
    x[304]    c3428     1
    x[304]    c3438     1
    x[304]    c3638     -1
    x[304]    c4718     1432
    x[304]    c4719     -1432
    x[304]    c4728     1432
    x[304]    c4729     -1432
    x[304]    c4887     1
    x[304]    OBJ       -97858.3302678188
    x[305]    c668      -1
    x[305]    c669      1
    x[305]    c2438     -1
    x[305]    c3398     -1
    x[305]    c3448     1
    x[305]    c3458     1
    x[305]    c3468     1
    x[305]    c3478     1
    x[305]    c3488     1
    x[305]    c3498     1
    x[305]    c3508     1
    x[305]    c3518     1
    x[305]    c3688     -1
    x[305]    c4718     2872
    x[305]    c4719     -2872
    x[305]    c4728     2872
    x[305]    c4729     -2872
    x[305]    c4810     1
    x[305]    c4819     1
    x[305]    OBJ       -161275.386496343
    x[306]    c677      -1
    x[306]    c678      1
    x[306]    c2498     -1
    x[306]    c3238     -1
    x[306]    c3468     -1
    x[306]    c3528     1
    x[306]    c3538     1
    x[306]    c3548     1
    x[306]    c3558     1
    x[306]    c3568     1
    x[306]    c3748     -1
    x[306]    c4718     2888
    x[306]    c4719     -2888
    x[306]    c4728     2888
    x[306]    c4729     -2888
    x[306]    OBJ       -124578.512645911
    x[307]    c686      -1
    x[307]    c687      1
    x[307]    c2588     -1
    x[307]    c3308     -1
    x[307]    c3548     -1
    x[307]    c3578     1
    x[307]    c3588     1
    x[307]    c3598     1
    x[307]    c3608     1
    x[307]    c3618     1
    x[307]    c3838     -1
    x[307]    c4188     -1
    x[307]    c4718     2692
    x[307]    c4719     -2692
    x[307]    c4728     2692
    x[307]    c4729     -2692
    x[307]    OBJ       -58819.1027673592
    x[308]    c695      -1
    x[308]    c696      1
    x[308]    c2638     -1
    x[308]    c3358     -1
    x[308]    c3598     -1
    x[308]    c3888     -1
    x[308]    c4228     -1
    x[308]    c4718     1168
    x[308]    c4719     -1168
    x[308]    c4728     528
    x[308]    c4729     -528
    x[308]    OBJ       -11243.2975201324
    x[309]    c704      -1
    x[309]    c705      1
    x[309]    c3628     1
    x[309]    c3638     1
    x[309]    c3648     1
    x[309]    c3658     1
    x[309]    c3668     1
    x[309]    c4718     716
    x[309]    c4719     -716
    x[309]    c4728     716
    x[309]    c4729     -716
    x[309]    c4932     1
    x[309]    OBJ       -57951.5643784601
    x[310]    c713      -1
    x[310]    c714      1
    x[310]    c3648     -1
    x[310]    c3678     1
    x[310]    c3688     1
    x[310]    c3698     1
    x[310]    c3708     1
    x[310]    c3718     1
    x[310]    c3728     1
    x[310]    c4718     2864
    x[310]    c4719     -2864
    x[310]    c4728     2864
    x[310]    c4729     -2864
    x[310]    c4841     1
    x[310]    OBJ       -200574.875513473
    x[311]    c722      -1
    x[311]    c723      1
    x[311]    c2688     -1
    x[311]    c3408     -1
    x[311]    c3698     -1
    x[311]    c3738     1
    x[311]    c3748     1
    x[311]    c3758     1
    x[311]    c3768     1
    x[311]    c3778     1
    x[311]    c3788     1
    x[311]    c3798     1
    x[311]    c3808     1
    x[311]    c3818     1
    x[311]    c4718     2864
    x[311]    c4719     -2864
    x[311]    c4728     2864
    x[311]    c4729     -2864
    x[311]    c4737     1
    x[311]    c4745     1
    x[311]    c4746     1
    x[311]    c4747     1
    x[311]    c4748     1
    x[311]    OBJ       -203524.506035729
    x[312]    c731      -1
    x[312]    c732      1
    x[312]    c2768     -1
    x[312]    c3478     -1
    x[312]    c3758     -1
    x[312]    c3828     1
    x[312]    c3838     1
    x[312]    c3848     1
    x[312]    c3858     1
    x[312]    c3868     1
    x[312]    c3938     -1
    x[312]    c4278     -1
    x[312]    c4718     2865
    x[312]    c4719     -2865
    x[312]    c4728     2865
    x[312]    c4729     -2865
    x[312]    c4887     -1
    x[312]    OBJ       -194849.122146739
    x[313]    c740      -1
    x[313]    c741      1
    x[313]    c2848     -1
    x[313]    c3558     -1
    x[313]    c3848     -1
    x[313]    c3878     1
    x[313]    c3888     1
    x[313]    c3898     1
    x[313]    c3908     1
    x[313]    c3918     1
    x[313]    c3998     -1
    x[313]    c4338     -1
    x[313]    c4718     2686
    x[313]    c4719     -2686
    x[313]    c4728     2684
    x[313]    c4729     -2684
    x[313]    c4810     -1
    x[313]    OBJ       -114688.575012461
    x[314]    c749      -1
    x[314]    c750      1
    x[314]    c1358     -1
    x[314]    c2898     -1
    x[314]    c3608     -1
    x[314]    c3898     -1
    x[314]    c4048     -1
    x[314]    c4388     -1
    x[314]    c4718     1152
    x[314]    c4719     -1152
    x[314]    c4728     624
    x[314]    c4729     -624
    x[314]    OBJ       -22460.5688885978
    x[315]    c758      -1
    x[315]    c759      1
    x[315]    c3708     -1
    x[315]    c3928     1
    x[315]    c3938     1
    x[315]    c3948     1
    x[315]    c3958     1
    x[315]    c3968     1
    x[315]    c3978     1
    x[315]    c4718     1432
    x[315]    c4719     -1432
    x[315]    c4728     1432
    x[315]    c4729     -1432
    x[315]    OBJ       -103063.560601213
    x[316]    c767      -1
    x[316]    c768      1
    x[316]    c2938     -1
    x[316]    c3768     -1
    x[316]    c3948     -1
    x[316]    c3988     1
    x[316]    c3998     1
    x[316]    c4008     1
    x[316]    c4018     1
    x[316]    c4028     1
    x[316]    c4438     -1
    x[316]    c4718     2864
    x[316]    c4719     -2864
    x[316]    c4728     2864
    x[316]    c4729     -2864
    x[316]    OBJ       -147915.295307297
    x[317]    c776      -1
    x[317]    c777      1
    x[317]    c3018     -1
    x[317]    c3858     -1
    x[317]    c4008     -1
    x[317]    c4038     1
    x[317]    c4048     1
    x[317]    c4058     1
    x[317]    c4068     1
    x[317]    c4078     1
    x[317]    c4488     -1
    x[317]    c4718     2684
    x[317]    c4719     -2684
    x[317]    c4728     2680
    x[317]    c4729     -2680
    x[317]    c4919     -1
    x[317]    OBJ       -103323.822117883
    x[318]    c785      -1
    x[318]    c786      1
    x[318]    c1528     -1
    x[318]    c3068     -1
    x[318]    c3908     -1
    x[318]    c4058     -1
    x[318]    c4098     -1
    x[318]    c4538     -1
    x[318]    c4718     1099
    x[318]    c4719     -1099
    x[318]    c4728     672
    x[318]    c4729     -672
    x[318]    c4843     -1
    x[318]    OBJ       -32124.9465409338
    x[319]    c794      -1
    x[319]    c795      1
    x[319]    c4018     -1
    x[319]    c4088     1
    x[319]    c4098     1
    x[319]    c4108     1
    x[319]    c4118     1
    x[319]    c4128     1
    x[319]    c4718     1342
    x[319]    c4719     -1342
    x[319]    c4728     1340
    x[319]    c4729     -1340
    x[319]    c4746     -1
    x[319]    OBJ       -24464.5825669547
    x[320]    c803      -1
    x[320]    c804      1
    x[320]    c1698     -1
    x[320]    c3118     -1
    x[320]    c4068     -1
    x[320]    c4108     -1
    x[320]    c4588     -1
    x[320]    c4718     880
    x[320]    c4719     -880
    x[320]    c4728     629
    x[320]    c4729     -629
    x[320]    OBJ       -18799.5568874436
    x[321]    c812      -1
    x[321]    c813      1
    x[321]    c4118     -1
    x[321]    c4718     326
    x[321]    c4719     -326
    x[321]    c4728     256
    x[321]    c4729     -256
    x[321]    OBJ       -6948.98249508181
    x[322]    c821      -1
    x[322]    c822      1
    x[322]    c2528     -1
    x[322]    c3198     -1
    x[322]    c4148     -1
    x[322]    c4718     360
    x[322]    c4719     -360
    x[322]    OBJ       935.206383233232
    x[323]    c830      -1
    x[323]    c831      1
    x[323]    c2708     -1
    x[323]    c3318     -1
    x[323]    c4138     1
    x[323]    c4148     1
    x[323]    c4158     1
    x[323]    c4168     1
    x[323]    c4178     1
    x[323]    c4198     -1
    x[323]    c4718     1346
    x[323]    c4719     -1346
    x[323]    c4728     1322
    x[323]    c4729     -1322
    x[323]    OBJ       -11147.8682973535
    x[324]    c839      -1
    x[324]    c840      1
    x[324]    c2788     -1
    x[324]    c3368     -1
    x[324]    c4158     -1
    x[324]    c4238     -1
    x[324]    c4718     689
    x[324]    c4719     -689
    x[324]    c4728     241
    x[324]    c4729     -241
    x[324]    OBJ       -4530.28546683112
    x[325]    c848      -1
    x[325]    c849      1
    x[325]    c3488     -1
    x[325]    c4188     1
    x[325]    c4198     1
    x[325]    c4208     1
    x[325]    c4218     1
    x[325]    c4288     -1
    x[325]    c4718     1448
    x[325]    c4719     -1448
    x[325]    c4728     1448
    x[325]    c4729     -1448
    x[325]    OBJ       -42596.1348949459
    x[326]    c857      -1
    x[326]    c858      1
    x[326]    c3568     -1
    x[326]    c4208     -1
    x[326]    c4228     1
    x[326]    c4238     1
    x[326]    c4248     1
    x[326]    c4258     1
    x[326]    c4268     1
    x[326]    c4348     -1
    x[326]    c4718     2692
    x[326]    c4719     -2692
    x[326]    c4728     2668
    x[326]    c4729     -2668
    x[326]    OBJ       -24672.7917802905
    x[327]    c866      -1
    x[327]    c867      1
    x[327]    c1988     -1
    x[327]    c2958     -1
    x[327]    c3618     -1
    x[327]    c4168     -1
    x[327]    c4248     -1
    x[327]    c4398     -1
    x[327]    c4718     828
    x[327]    c4719     -828
    x[327]    c4728     291
    x[327]    c4729     -291
    x[327]    c4747     -1
    x[327]    OBJ       -3794.61291304468
    x[328]    c875      -1
    x[328]    c876      1
    x[328]    c3718     -1
    x[328]    c4278     1
    x[328]    c4288     1
    x[328]    c4298     1
    x[328]    c4308     1
    x[328]    c4318     1
    x[328]    c4328     1
    x[328]    c4718     1432
    x[328]    c4719     -1432
    x[328]    c4728     1432
    x[328]    c4729     -1432
    x[328]    OBJ       -100894.714628966
    x[329]    c884      -1
    x[329]    c885      1
    x[329]    c3778     -1
    x[329]    c4298     -1
    x[329]    c4338     1
    x[329]    c4348     1
    x[329]    c4358     1
    x[329]    c4368     1
    x[329]    c4378     1
    x[329]    c4448     -1
    x[329]    c4718     2880
    x[329]    c4719     -2880
    x[329]    c4728     2880
    x[329]    c4729     -2880
    x[329]    OBJ       -153207.279479582
    x[330]    c893      -1
    x[330]    c894      1
    x[330]    c2158     -1
    x[330]    c3868     -1
    x[330]    c4218     -1
    x[330]    c4358     -1
    x[330]    c4388     1
    x[330]    c4398     1
    x[330]    c4408     1
    x[330]    c4418     1
    x[330]    c4428     1
    x[330]    c4498     -1
    x[330]    c4718     2691
    x[330]    c4719     -2691
    x[330]    c4728     2691
    x[330]    c4729     -2691
    x[330]    OBJ       -52139.0571728361
    x[331]    c902      -1
    x[331]    c903      1
    x[331]    c2228     -1
    x[331]    c3918     -1
    x[331]    c4258     -1
    x[331]    c4408     -1
    x[331]    c4548     -1
    x[331]    c4638     -1
    x[331]    c4718     840
    x[331]    c4719     -840
    x[331]    c4728     543
    x[331]    c4729     -543
    x[331]    OBJ       -15216.6233412903
    x[332]    c911      -1
    x[332]    c912      1
    x[332]    c4438     1
    x[332]    c4448     1
    x[332]    c4458     1
    x[332]    c4468     1
    x[332]    c4478     1
    x[332]    c4718     716
    x[332]    c4719     -716
    x[332]    c4728     716
    x[332]    c4729     -716
    x[332]    OBJ       -51271.518783937
    x[333]    c920      -1
    x[333]    c921      1
    x[333]    c2378     -1
    x[333]    c3958     -1
    x[333]    c4308     -1
    x[333]    c4458     -1
    x[333]    c4488     1
    x[333]    c4498     1
    x[333]    c4508     1
    x[333]    c4518     1
    x[333]    c4528     1
    x[333]    c4718     2148
    x[333]    c4719     -2148
    x[333]    c4728     2148
    x[333]    c4729     -2148
    x[333]    OBJ       -130130.758334865
    x[334]    c929      -1
    x[334]    c930      1
    x[334]    c2448     -1
    x[334]    c4028     -1
    x[334]    c4368     -1
    x[334]    c4508     -1
    x[334]    c4538     1
    x[334]    c4548     1
    x[334]    c4558     1
    x[334]    c4568     1
    x[334]    c4578     1
    x[334]    c4718     2684
    x[334]    c4719     -2684
    x[334]    c4728     2680
    x[334]    c4729     -2680
    x[334]    OBJ       -114688.575012461
    x[335]    c938      -1
    x[335]    c939      1
    x[335]    c2538     -1
    x[335]    c4078     -1
    x[335]    c4418     -1
    x[335]    c4558     -1
    x[335]    c4598     -1
    x[335]    c4678     -1
    x[335]    c4718     841
    x[335]    c4719     -841
    x[335]    c4728     480
    x[335]    c4729     -480
    x[335]    c4748     -1
    x[335]    OBJ       -26989.1192786511
    x[336]    c947      -1
    x[336]    c948      1
    x[336]    c2718     -1
    x[336]    c4518     -1
    x[336]    c4588     1
    x[336]    c4598     1
    x[336]    c4608     1
    x[336]    c4618     1
    x[336]    c4628     1
    x[336]    c4718     671
    x[336]    c4719     -671
    x[336]    c4728     670
    x[336]    c4729     -670
    x[336]    OBJ       -20473.9059780188
    x[337]    c956      -1
    x[337]    c957      1
    x[337]    c2798     -1
    x[337]    c4128     -1
    x[337]    c4568     -1
    x[337]    c4608     -1
    x[337]    c4718     754
    x[337]    c4719     -754
    x[337]    c4728     450
    x[337]    c4729     -450
    x[337]    OBJ       -23883.3318463923
    x[338]    c965      -1
    x[338]    c966      1
    x[338]    c2968     -1
    x[338]    c4618     -1
    x[338]    c4718     289
    x[338]    c4719     -289
    x[338]    c4728     186
    x[338]    c4729     -186
    x[338]    OBJ       -6359.05639063042
    x[339]    c974      -1
    x[339]    c975      1
    x[339]    c3808     -1
    x[339]    c4178     -1
    x[339]    c4718     150
    x[339]    c4719     -150
    x[339]    OBJ       390.392275004596
    x[340]    c983      -1
    x[340]    c984      1
    x[340]    c3978     -1
    x[340]    c4268     -1
    x[340]    c4648     -1
    x[340]    c4718     315
    x[340]    c4719     -315
    x[340]    c4728     52
    x[340]    c4729     -52
    x[340]    OBJ       -153.554294835141
    x[341]    c992      -1
    x[341]    c993      1
    x[341]    c4378     -1
    x[341]    c4638     1
    x[341]    c4648     1
    x[341]    c4658     1
    x[341]    c4668     1
    x[341]    c4718     1346
    x[341]    c4719     -1346
    x[341]    c4728     1322
    x[341]    c4729     -1322
    x[341]    OBJ       -16552.6324601949
    x[342]    c1001     -1
    x[342]    c1002     1
    x[342]    c3268     -1
    x[342]    c4428     -1
    x[342]    c4658     -1
    x[342]    c4688     -1
    x[342]    c4718     548
    x[342]    c4719     -548
    x[342]    c4728     133
    x[342]    c4729     -133
    x[342]    OBJ       -2483.76240741813
    x[343]    c1010     -1
    x[343]    c1011     1
    x[343]    c3438     -1
    x[343]    c4528     -1
    x[343]    c4678     1
    x[343]    c4688     1
    x[343]    c4698     1
    x[343]    c4708     1
    x[343]    c4718     672
    x[343]    c4719     -672
    x[343]    c4728     672
    x[343]    c4729     -672
    x[343]    OBJ       -14574.6449335049
    x[344]    c1019     -1
    x[344]    c1020     1
    x[344]    c3518     -1
    x[344]    c4578     -1
    x[344]    c4668     -1
    x[344]    c4698     -1
    x[344]    c4718     429
    x[344]    c4719     -429
    x[344]    c4728     142
    x[344]    c4729     -142
    x[344]    OBJ       -5257.28263672856
    x[345]    c1028     -1
    x[345]    c1029     1
    x[345]    c3818     -1
    x[345]    c4628     -1
    x[345]    c4708     -1
    x[345]    c4718     273
    x[345]    c4719     -273
    x[345]    c4728     94
    x[345]    c4729     -94
    x[345]    OBJ       -4892.91651339094
    x[346]    c3        -1
    x[346]    c4        1
    x[346]    c2389     -1
    x[346]    c4719     219
    x[346]    c4720     -219
    x[346]    c4729     75
    x[346]    c4730     -75
    x[346]    OBJ       -1646.81115874488
    x[347]    c12       -1
    x[347]    c13       1
    x[347]    c1339     -1
    x[347]    c4719     328
    x[347]    c4720     -328
    x[347]    c4729     215
    x[347]    c4730     -215
    x[347]    OBJ       -3361.29948839709
    x[348]    c21       -1
    x[348]    c22       1
    x[348]    c1509     -1
    x[348]    c3669     -1
    x[348]    c4719     545
    x[348]    c4720     -545
    x[348]    c4729     368
    x[348]    c4730     -368
    x[348]    OBJ       -7677.59905515308
    x[349]    c30       -1
    x[349]    c31       1
    x[349]    c1069     -1
    x[349]    c1679     -1
    x[349]    c4719     435
    x[349]    c4720     -435
    x[349]    c4729     400
    x[349]    c4730     -400
    x[349]    OBJ       -11708.150566967
    x[350]    c39       -1
    x[350]    c40       1
    x[350]    c1119     -1
    x[350]    c4719     247
    x[350]    c4720     -247
    x[350]    c4729     216
    x[350]    c4730     -216
    x[350]    OBJ       -5218.66184552031
    x[351]    c48       -1
    x[351]    c49       1
    x[351]    c1969     -1
    x[351]    c4719     82
    x[351]    c4720     -82
    x[351]    c4729     27
    x[351]    c4730     -27
    x[351]    OBJ       -548.185084349323
    x[352]    c57       -1
    x[352]    c58       1
    x[352]    c1079     -1
    x[352]    c1239     -1
    x[352]    c2509     -1
    x[352]    c4719     526
    x[352]    c4720     -526
    x[352]    c4729     314
    x[352]    c4730     -314
    x[352]    OBJ       -5079.54766087748
    x[353]    c66       -1
    x[353]    c67       1
    x[353]    c1039     1
    x[353]    c1049     1
    x[353]    c1059     1
    x[353]    c1289     -1
    x[353]    c4719     693
    x[353]    c4720     -693
    x[353]    c4729     693
    x[353]    c4730     -693
    x[353]    OBJ       -38876.7748434294
    x[354]    c75       -1
    x[354]    c76       1
    x[354]    c1039     -1
    x[354]    c1069     1
    x[354]    c1079     1
    x[354]    c1089     1
    x[354]    c1099     1
    x[354]    c1109     1
    x[354]    c1369     -1
    x[354]    c2699     -1
    x[354]    c4719     1944
    x[354]    c4720     -1944
    x[354]    c4729     1944
    x[354]    c4730     -1944
    x[354]    OBJ       -58127.1701237349
    x[355]    c84       -1
    x[355]    c85       1
    x[355]    c1089     -1
    x[355]    c1129     -1
    x[355]    c1419     -1
    x[355]    c2779     -1
    x[355]    c4719     907
    x[355]    c4720     -907
    x[355]    c4729     574
    x[355]    c4730     -574
    x[355]    c4907     -1
    x[355]    OBJ       -16829.0564989545
    x[356]    c93       -1
    x[356]    c94       1
    x[356]    c1049     -1
    x[356]    c1119     1
    x[356]    c1129     1
    x[356]    c1139     1
    x[356]    c1149     1
    x[356]    c1159     1
    x[356]    c1539     -1
    x[356]    c4719     1296
    x[356]    c4720     -1296
    x[356]    c4729     1128
    x[356]    c4730     -1128
    x[356]    OBJ       -18531.5133315566
    x[357]    c102      -1
    x[357]    c103      1
    x[357]    c1099     -1
    x[357]    c1139     -1
    x[357]    c1169     -1
    x[357]    c1589     -1
    x[357]    c1979     -1
    x[357]    c2949     -1
    x[357]    c4719     1043
    x[357]    c4720     -1043
    x[357]    c4729     864
    x[357]    c4730     -864
    x[357]    OBJ       -15388.2847271942
    x[358]    c111      -1
    x[358]    c112      1
    x[358]    c1169     1
    x[358]    c1179     1
    x[358]    c1189     1
    x[358]    c1199     1
    x[358]    c1709     -1
    x[358]    c2149     -1
    x[358]    c4719     1332
    x[358]    c4720     -1332
    x[358]    c4729     1330
    x[358]    c4730     -1330
    x[358]    OBJ       -35267.3257283721
    x[359]    c120      -1
    x[359]    c121      1
    x[359]    c1149     -1
    x[359]    c1179     -1
    x[359]    c1759     -1
    x[359]    c2219     -1
    x[359]    c4719     1186
    x[359]    c4720     -1186
    x[359]    c4729     864
    x[359]    c4730     -864
    x[359]    OBJ       -21340.8678927762
    x[360]    c129      -1
    x[360]    c130      1
    x[360]    c1189     -1
    x[360]    c1839     -1
    x[360]    c2519     -1
    x[360]    c4719     984
    x[360]    c4720     -984
    x[360]    c4729     723
    x[360]    c4730     -723
    x[360]    c4956     -1
    x[360]    OBJ       -10595.2370898244
    x[361]    c138      -1
    x[361]    c139      1
    x[361]    c1249     -1
    x[361]    c1889     -1
    x[361]    c3249     -1
    x[361]    c4719     225
    x[361]    c4720     -225
    x[361]    c4729     20
    x[361]    c4730     -20
    x[361]    OBJ       42.8622082413052
    x[362]    c147      -1
    x[362]    c148      1
    x[362]    c1209     1
    x[362]    c1219     1
    x[362]    c1229     1
    x[362]    c1299     -1
    x[362]    c1929     -1
    x[362]    c4719     724
    x[362]    c4720     -724
    x[362]    c4729     724
    x[362]    c4730     -724
    x[362]    OBJ       -28950.7897770219
    x[363]    c156      -1
    x[363]    c157      1
    x[363]    c1209     -1
    x[363]    c1239     1
    x[363]    c1249     1
    x[363]    c1259     1
    x[363]    c1269     1
    x[363]    c1279     1
    x[363]    c1379     -1
    x[363]    c1999     -1
    x[363]    c3419     -1
    x[363]    c4719     1989
    x[363]    c4720     -1989
    x[363]    c4729     1989
    x[363]    c4730     -1989
    x[363]    OBJ       -25100.7107209608
    x[364]    c165      -1
    x[364]    c166      1
    x[364]    c1259     -1
    x[364]    c1429     -1
    x[364]    c2049     -1
    x[364]    c3499     -1
    x[364]    c4719     710
    x[364]    c4720     -710
    x[364]    c4729     382
    x[364]    c4730     -382
    x[364]    OBJ       -7023.38640304895
    x[365]    c174      -1
    x[365]    c175      1
    x[365]    c1289     1
    x[365]    c1299     1
    x[365]    c1309     1
    x[365]    c1319     1
    x[365]    c1329     1
    x[365]    c1339     1
    x[365]    c1349     1
    x[365]    c1359     1
    x[365]    c2099     -1
    x[365]    c4719     716
    x[365]    c4720     -716
    x[365]    c4729     716
    x[365]    c4730     -716
    x[365]    c4982     1
    x[365]    OBJ       -43839.7673766332
    x[366]    c183      -1
    x[366]    c184      1
    x[366]    c1309     -1
    x[366]    c1369     1
    x[366]    c1379     1
    x[366]    c1389     1
    x[366]    c1399     1
    x[366]    c1409     1
    x[366]    c1469     -1
    x[366]    c2169     -1
    x[366]    c3659     -1
    x[366]    c4719     2876
    x[366]    c4720     -2876
    x[366]    c4729     2876
    x[366]    c4730     -2876
    x[366]    OBJ       -138663.00350345
    x[367]    c192      -1
    x[367]    c193      1
    x[367]    c1059     -1
    x[367]    c1219     -1
    x[367]    c1389     -1
    x[367]    c1419     1
    x[367]    c1429     1
    x[367]    c1439     1
    x[367]    c1449     1
    x[367]    c1459     1
    x[367]    c1549     -1
    x[367]    c2239     -1
    x[367]    c3729     -1
    x[367]    c4719     2595
    x[367]    c4720     -2595
    x[367]    c4729     2595
    x[367]    c4730     -2595
    x[367]    c4793     -1
    x[367]    c4795     -1
    x[367]    OBJ       -29665.159914377
    x[368]    c201      -1
    x[368]    c202      1
    x[368]    c1109     -1
    x[368]    c1269     -1
    x[368]    c1439     -1
    x[368]    c1599     -1
    x[368]    c2289     -1
    x[368]    c3789     -1
    x[368]    c4719     1030
    x[368]    c4720     -1030
    x[368]    c4729     552
    x[368]    c4730     -552
    x[368]    c4947     -1
    x[368]    OBJ       -3970.394026563
    x[369]    c210      -1
    x[369]    c211      1
    x[369]    c1469     1
    x[369]    c1479     1
    x[369]    c1489     1
    x[369]    c1499     1
    x[369]    c1509     1
    x[369]    c1519     1
    x[369]    c1529     1
    x[369]    c2399     -1
    x[369]    c4719     1432
    x[369]    c4720     -1432
    x[369]    c4729     1432
    x[369]    c4730     -1432
    x[369]    OBJ       -81287.8019453525
    x[370]    c219      -1
    x[370]    c220      1
    x[370]    c1319     -1
    x[370]    c1479     -1
    x[370]    c1539     1
    x[370]    c1549     1
    x[370]    c1559     1
    x[370]    c1569     1
    x[370]    c1579     1
    x[370]    c1639     -1
    x[370]    c2459     -1
    x[370]    c4719     2864
    x[370]    c4720     -2864
    x[370]    c4729     2864
    x[370]    c4730     -2864
    x[370]    OBJ       -111366.54457083
    x[371]    c228      -1
    x[371]    c229      1
    x[371]    c1399     -1
    x[371]    c1559     -1
    x[371]    c1589     1
    x[371]    c1599     1
    x[371]    c1609     1
    x[371]    c1619     1
    x[371]    c1629     1
    x[371]    c1719     -1
    x[371]    c2549     -1
    x[371]    c4719     2600
    x[371]    c4720     -2600
    x[371]    c4729     2336
    x[371]    c4730     -2336
    x[371]    c4901     -1
    x[371]    OBJ       -42516.3027011121
    x[372]    c237      -1
    x[372]    c238      1
    x[372]    c1159     -1
    x[372]    c1449     -1
    x[372]    c1609     -1
    x[372]    c1769     -1
    x[372]    c2599     -1
    x[372]    c3969     -1
    x[372]    c4719     1156
    x[372]    c4720     -1156
    x[372]    c4729     696
    x[372]    c4730     -696
    x[372]    c4827     -1
    x[372]    OBJ       -9858.30789550018
    x[373]    c246      -1
    x[373]    c247      1
    x[373]    c1639     1
    x[373]    c1649     1
    x[373]    c1659     1
    x[373]    c1669     1
    x[373]    c1679     1
    x[373]    c1689     1
    x[373]    c1699     1
    x[373]    c2649     -1
    x[373]    c4719     716
    x[373]    c4720     -716
    x[373]    c4729     716
    x[373]    c4730     -716
    x[373]    c4984     1
    x[373]    OBJ       -40681.499400958
    x[374]    c255      -1
    x[374]    c256      1
    x[374]    c1489     -1
    x[374]    c1649     -1
    x[374]    c1709     1
    x[374]    c1719     1
    x[374]    c1729     1
    x[374]    c1739     1
    x[374]    c1749     1
    x[374]    c2729     -1
    x[374]    c4719     2864
    x[374]    c4720     -2864
    x[374]    c4729     2864
    x[374]    c4730     -2864
    x[374]    OBJ       -126255.522170441
    x[375]    c264      -1
    x[375]    c265      1
    x[375]    c1569     -1
    x[375]    c1729     -1
    x[375]    c1759     1
    x[375]    c1769     1
    x[375]    c1779     1
    x[375]    c1789     1
    x[375]    c1799     1
    x[375]    c1809     -1
    x[375]    c2809     -1
    x[375]    c4719     2681
    x[375]    c4720     -2681
    x[375]    c4729     2678
    x[375]    c4730     -2678
    x[375]    OBJ       -117607.883665616
    x[376]    c273      -1
    x[376]    c274      1
    x[376]    c1199     -1
    x[376]    c1619     -1
    x[376]    c1779     -1
    x[376]    c1849     -1
    x[376]    c2859     -1
    x[376]    c3259     -1
    x[376]    c4719     1263
    x[376]    c4720     -1263
    x[376]    c4729     864
    x[376]    c4730     -864
    x[376]    c4948     -1
    x[376]    OBJ       -42486.2239584867
    x[377]    c282      -1
    x[377]    c283      1
    x[377]    c1659     -1
    x[377]    c1809     1
    x[377]    c1819     1
    x[377]    c1829     1
    x[377]    c2909     -1
    x[377]    c4719     716
    x[377]    c4720     -716
    x[377]    c4729     716
    x[377]    c4730     -716
    x[377]    OBJ       -27522.0495023117
    x[378]    c291      -1
    x[378]    c292      1
    x[378]    c1739     -1
    x[378]    c1819     -1
    x[378]    c1839     1
    x[378]    c1849     1
    x[378]    c1859     1
    x[378]    c1869     1
    x[378]    c1879     1
    x[378]    c2979     -1
    x[378]    c3429     -1
    x[378]    c4719     1965
    x[378]    c4720     -1965
    x[378]    c4729     1964
    x[378]    c4730     -1964
    x[378]    OBJ       -49028.350479528
    x[379]    c300      -1
    x[379]    c301      1
    x[379]    c1789     -1
    x[379]    c1859     -1
    x[379]    c3029     -1
    x[379]    c3509     -1
    x[379]    c4719     1245
    x[379]    c4720     -1245
    x[379]    c4729     889
    x[379]    c4730     -889
    x[379]    c4911     -1
    x[379]    OBJ       -23814.8444737216
    x[380]    c309      -1
    x[380]    c310      1
    x[380]    c1869     -1
    x[380]    c3079     -1
    x[380]    c3799     -1
    x[380]    c4719     832
    x[380]    c4720     -832
    x[380]    c4729     647
    x[380]    c4730     -647
    x[380]    OBJ       -7139.18956215703
    x[381]    c318      -1
    x[381]    c319      1
    x[381]    c4719     339
    x[381]    c4720     -339
    x[381]    c4729     283
    x[381]    c4730     -283
    x[381]    OBJ       -4203.50428191045
    x[382]    c327      -1
    x[382]    c328      1
    x[382]    c1889     1
    x[382]    c1899     1
    x[382]    c1909     1
    x[382]    c1919     1
    x[382]    c2009     -1
    x[382]    c4719     1346
    x[382]    c4720     -1346
    x[382]    c4729     1346
    x[382]    c4730     -1346
    x[382]    OBJ       -34515.3571627352
    x[383]    c336      -1
    x[383]    c337      1
    x[383]    c1899     -1
    x[383]    c2059     -1
    x[383]    c4719     243
    x[383]    c4720     -243
    x[383]    OBJ       546.530753504923
    x[384]    c345      -1
    x[384]    c346      1
    x[384]    c1929     1
    x[384]    c1939     1
    x[384]    c1949     1
    x[384]    c1959     1
    x[384]    c1969     1
    x[384]    c1979     1
    x[384]    c1989     1
    x[384]    c2109     -1
    x[384]    c4719     724
    x[384]    c4720     -724
    x[384]    c4729     724
    x[384]    c4730     -724
    x[384]    OBJ       -39628.7434090663
    x[385]    c354      -1
    x[385]    c355      1
    x[385]    c1939     -1
    x[385]    c1999     1
    x[385]    c2009     1
    x[385]    c2019     1
    x[385]    c2029     1
    x[385]    c2039     1
    x[385]    c2179     -1
    x[385]    c4719     2896
    x[385]    c4720     -2896
    x[385]    c4729     2896
    x[385]    c4730     -2896
    x[385]    OBJ       -122570.87619882
    x[386]    c363      -1
    x[386]    c364      1
    x[386]    c1229     -1
    x[386]    c2019     -1
    x[386]    c2049     1
    x[386]    c2059     1
    x[386]    c2069     1
    x[386]    c2079     1
    x[386]    c2089     1
    x[386]    c2249     -1
    x[386]    c3129     -1
    x[386]    c4719     2692
    x[386]    c4720     -2692
    x[386]    c4729     2692
    x[386]    c4730     -2692
    x[386]    OBJ       -61285.43809941
    x[387]    c372      -1
    x[387]    c373      1
    x[387]    c1279     -1
    x[387]    c1909     -1
    x[387]    c2069     -1
    x[387]    c2299     -1
    x[387]    c3159     -1
    x[387]    c4719     755
    x[387]    c4720     -755
    x[387]    c4729     323
    x[387]    c4730     -323
    x[387]    c4905     -1
    x[387]    OBJ       -5171.28782588519
    x[388]    c381      -1
    x[388]    c382      1
    x[388]    c2099     1
    x[388]    c2109     1
    x[388]    c2119     1
    x[388]    c2129     1
    x[388]    c2139     1
    x[388]    c2149     1
    x[388]    c2159     1
    x[388]    c2339     -1
    x[388]    c4719     1432
    x[388]    c4720     -1432
    x[388]    c4729     1432
    x[388]    c4730     -1432
    x[388]    OBJ       -83694.1013553906
    x[389]    c390      -1
    x[389]    c391      1
    x[389]    c2119     -1
    x[389]    c2169     1
    x[389]    c2179     1
    x[389]    c2189     1
    x[389]    c2199     1
    x[389]    c2209     1
    x[389]    c2219     1
    x[389]    c2229     1
    x[389]    c2409     -1
    x[389]    c4719     2886
    x[389]    c4720     -2886
    x[389]    c4729     2886
    x[389]    c4730     -2886
    x[389]    c4983     1
    x[389]    OBJ       -157687.808214065
    x[390]    c399      -1
    x[390]    c400      1
    x[390]    c1329     -1
    x[390]    c1949     -1
    x[390]    c2189     -1
    x[390]    c2239     1
    x[390]    c2249     1
    x[390]    c2259     1
    x[390]    c2269     1
    x[390]    c2279     1
    x[390]    c2469     -1
    x[390]    c3209     -1
    x[390]    c4719     2895
    x[390]    c4720     -2895
    x[390]    c4729     2895
    x[390]    c4730     -2895
    x[390]    c4880     1
    x[390]    c4883     1
    x[390]    OBJ       -131218.514703645
    x[391]    c408      -1
    x[391]    c409      1
    x[391]    c1409     -1
    x[391]    c2029     -1
    x[391]    c2259     -1
    x[391]    c2289     1
    x[391]    c2299     1
    x[391]    c2309     1
    x[391]    c2319     1
    x[391]    c2329     1
    x[391]    c2559     -1
    x[391]    c3279     -1
    x[391]    c4719     2692
    x[391]    c4720     -2692
    x[391]    c4729     2668
    x[391]    c4730     -2668
    x[391]    OBJ       -51509.8467461299
    x[392]    c417      -1
    x[392]    c418      1
    x[392]    c1459     -1
    x[392]    c2079     -1
    x[392]    c2309     -1
    x[392]    c2609     -1
    x[392]    c3329     -1
    x[392]    c4319     -1
    x[392]    c4719     1115
    x[392]    c4720     -1115
    x[392]    c4729     408
    x[392]    c4730     -408
    x[392]    c4950     -1
    x[392]    OBJ       -3792.17747650705
    x[393]    c426      -1
    x[393]    c427      1
    x[393]    c2339     1
    x[393]    c2349     1
    x[393]    c2359     1
    x[393]    c2369     1
    x[393]    c2379     1
    x[393]    c2389     1
    x[393]    c4719     1432
    x[393]    c4720     -1432
    x[393]    c4729     1432
    x[393]    c4730     -1432
    x[393]    c4856     1
    x[393]    OBJ       -95500.0078358904
    x[394]    c435      -1
    x[394]    c436      1
    x[394]    c2349     -1
    x[394]    c2399     1
    x[394]    c2409     1
    x[394]    c2419     1
    x[394]    c2429     1
    x[394]    c2439     1
    x[394]    c2449     1
    x[394]    c4719     2864
    x[394]    c4720     -2864
    x[394]    c4729     2864
    x[394]    c4730     -2864
    x[394]    OBJ       -174757.494654023
    x[395]    c444      -1
    x[395]    c445      1
    x[395]    c2129     -1
    x[395]    c2419     -1
    x[395]    c2459     1
    x[395]    c2469     1
    x[395]    c2479     1
    x[395]    c2489     1
    x[395]    c2499     1
    x[395]    c2509     1
    x[395]    c2519     1
    x[395]    c2529     1
    x[395]    c2539     1
    x[395]    c2659     -1
    x[395]    c3379     -1
    x[395]    c4719     2864
    x[395]    c4720     -2864
    x[395]    c4729     2864
    x[395]    c4730     -2864
    x[395]    c4901     1
    x[395]    c4905     1
    x[395]    c4906     1
    x[395]    c4907     1
    x[395]    c4911     1
    x[395]    OBJ       -165057.100157307
    x[396]    c453      -1
    x[396]    c454      1
    x[396]    c1499     -1
    x[396]    c2199     -1
    x[396]    c2479     -1
    x[396]    c2549     1
    x[396]    c2559     1
    x[396]    c2569     1
    x[396]    c2579     1
    x[396]    c2589     1
    x[396]    c2739     -1
    x[396]    c3449     -1
    x[396]    c4719     2873
    x[396]    c4720     -2873
    x[396]    c4729     2873
    x[396]    c4730     -2873
    x[396]    OBJ       -126932.293879514
    x[397]    c462      -1
    x[397]    c463      1
    x[397]    c1579     -1
    x[397]    c2269     -1
    x[397]    c2569     -1
    x[397]    c2599     1
    x[397]    c2609     1
    x[397]    c2619     1
    x[397]    c2629     1
    x[397]    c2639     1
    x[397]    c2819     -1
    x[397]    c3529     -1
    x[397]    c4719     2679
    x[397]    c4720     -2679
    x[397]    c4729     2604
    x[397]    c4730     -2604
    x[397]    c4982     -1
    x[397]    c4983     -1
    x[397]    c4984     -1
    x[397]    OBJ       -44087.9170032933
    x[398]    c471      -1
    x[398]    c472      1
    x[398]    c1629     -1
    x[398]    c2319     -1
    x[398]    c2619     -1
    x[398]    c2869     -1
    x[398]    c3579     -1
    x[398]    c4469     -1
    x[398]    c4719     1252
    x[398]    c4720     -1252
    x[398]    c4729     552
    x[398]    c4730     -552
    x[398]    c4880     -1
    x[398]    OBJ       -8687.49283880348
    x[399]    c480      -1
    x[399]    c481      1
    x[399]    c2359     -1
    x[399]    c2649     1
    x[399]    c2659     1
    x[399]    c2669     1
    x[399]    c2679     1
    x[399]    c2689     1
    x[399]    c2699     1
    x[399]    c2709     1
    x[399]    c2719     1
    x[399]    c3629     -1
    x[399]    c4719     2148
    x[399]    c4720     -2148
    x[399]    c4729     2148
    x[399]    c4730     -2148
    x[399]    c4793     1
    x[399]    OBJ       -115878.355964651
    x[400]    c489      -1
    x[400]    c490      1
    x[400]    c2429     -1
    x[400]    c2669     -1
    x[400]    c2729     1
    x[400]    c2739     1
    x[400]    c2749     1
    x[400]    c2759     1
    x[400]    c2769     1
    x[400]    c2779     1
    x[400]    c2789     1
    x[400]    c2799     1
    x[400]    c3679     -1
    x[400]    c4719     2864
    x[400]    c4720     -2864
    x[400]    c4729     2864
    x[400]    c4730     -2864
    x[400]    c4939     1
    x[400]    c4947     1
    x[400]    c4948     1
    x[400]    c4950     1
    x[400]    c4951     1
    x[400]    c4954     -1
    x[400]    c4956     1
    x[400]    OBJ       -151220.878549587
    x[401]    c498      -1
    x[401]    c499      1
    x[401]    c1669     -1
    x[401]    c2489     -1
    x[401]    c2749     -1
    x[401]    c2809     1
    x[401]    c2819     1
    x[401]    c2829     1
    x[401]    c2839     1
    x[401]    c2849     1
    x[401]    c2919     -1
    x[401]    c3739     -1
    x[401]    c4719     2864
    x[401]    c4720     -2864
    x[401]    c4729     2864
    x[401]    c4730     -2864
    x[401]    c4854     -1
    x[401]    c4856     -1
    x[401]    c4857     1
    x[401]    c4859     1
    x[401]    OBJ       -138362.216077195
    x[402]    c507      -1
    x[402]    c508      1
    x[402]    c1749     -1
    x[402]    c2579     -1
    x[402]    c2829     -1
    x[402]    c2859     1
    x[402]    c2869     1
    x[402]    c2879     1
    x[402]    c2889     1
    x[402]    c2899     1
    x[402]    c2989     -1
    x[402]    c3829     -1
    x[402]    c4719     2684
    x[402]    c4720     -2684
    x[402]    c4729     2680
    x[402]    c4730     -2680
    x[402]    c4758     -1
    x[402]    OBJ       -117607.883665616
    x[403]    c516      -1
    x[403]    c517      1
    x[403]    c1799     -1
    x[403]    c2629     -1
    x[403]    c2879     -1
    x[403]    c3039     -1
    x[403]    c3879     -1
    x[403]    c4719     1253
    x[403]    c4720     -1253
    x[403]    c4729     840
    x[403]    c4730     -840
    x[403]    c4906     -1
    x[403]    OBJ       -32485.0420355155
    x[404]    c525      -1
    x[404]    c526      1
    x[404]    c2679     -1
    x[404]    c2909     1
    x[404]    c2919     1
    x[404]    c2929     1
    x[404]    c2939     1
    x[404]    c2949     1
    x[404]    c2959     1
    x[404]    c2969     1
    x[404]    c4719     716
    x[404]    c4720     -716
    x[404]    c4729     716
    x[404]    c4730     -716
    x[404]    OBJ       -43614.1768069421
    x[405]    c534      -1
    x[405]    c535      1
    x[405]    c2759     -1
    x[405]    c2929     -1
    x[405]    c2979     1
    x[405]    c2989     1
    x[405]    c2999     1
    x[405]    c3009     1
    x[405]    c3019     1
    x[405]    c3929     -1
    x[405]    c4719     2864
    x[405]    c4720     -2864
    x[405]    c4729     2864
    x[405]    c4730     -2864
    x[405]    OBJ       -121518.120206928
    x[406]    c543      -1
    x[406]    c544      1
    x[406]    c1829     -1
    x[406]    c2839     -1
    x[406]    c2999     -1
    x[406]    c3029     1
    x[406]    c3039     1
    x[406]    c3049     1
    x[406]    c3059     1
    x[406]    c3069     1
    x[406]    c3989     -1
    x[406]    c4719     2651
    x[406]    c4720     -2651
    x[406]    c4729     2650
    x[406]    c4730     -2650
    x[406]    OBJ       -93544.8895652344
    x[407]    c552      -1
    x[407]    c553      1
    x[407]    c1879     -1
    x[407]    c2889     -1
    x[407]    c3049     -1
    x[407]    c3089     -1
    x[407]    c4039     -1
    x[407]    c4719     1175
    x[407]    c4720     -1175
    x[407]    c4729     768
    x[407]    c4730     -768
    x[407]    OBJ       -28680.0810933926
    x[408]    c561      -1
    x[408]    c562      1
    x[408]    c3009     -1
    x[408]    c3079     1
    x[408]    c3089     1
    x[408]    c3099     1
    x[408]    c3109     1
    x[408]    c3119     1
    x[408]    c4719     1333
    x[408]    c4720     -1333
    x[408]    c4729     1332
    x[408]    c4730     -1332
    x[408]    c4951     -1
    x[408]    OBJ       -32861.0263183339
    x[409]    c570      -1
    x[409]    c571      1
    x[409]    c3059     -1
    x[409]    c3099     -1
    x[409]    c4089     -1
    x[409]    c4329     -1
    x[409]    c4719     940
    x[409]    c4720     -940
    x[409]    c4729     728
    x[409]    c4730     -728
    x[409]    c4859     -1
    x[409]    OBJ       -22528.9782264825
    x[410]    c579      -1
    x[410]    c580      1
    x[410]    c3109     -1
    x[410]    c4479     -1
    x[410]    c4719     342
    x[410]    c4720     -342
    x[410]    c4729     317
    x[410]    c4730     -317
    x[410]    OBJ       -5564.5673857133
    x[411]    c588      -1
    x[411]    c589      1
    x[411]    c1349     -1
    x[411]    c1919     -1
    x[411]    c3169     -1
    x[411]    c4719     187
    x[411]    c4720     -187
    x[411]    OBJ       414.861057661895
    x[412]    c597      -1
    x[412]    c598      1
    x[412]    c1959     -1
    x[412]    c3129     1
    x[412]    c3139     1
    x[412]    c3149     1
    x[412]    c3219     -1
    x[412]    c4719     724
    x[412]    c4720     -724
    x[412]    c4729     724
    x[412]    c4730     -724
    x[412]    OBJ       -22258.2695428532
    x[413]    c606      -1
    x[413]    c607      1
    x[413]    c2039     -1
    x[413]    c3139     -1
    x[413]    c3159     1
    x[413]    c3169     1
    x[413]    c3179     1
    x[413]    c3189     1
    x[413]    c3199     1
    x[413]    c3289     -1
    x[413]    c4719     2019
    x[413]    c4720     -2019
    x[413]    c4729     1995
    x[413]    c4730     -1995
    x[413]    OBJ       -26078.2698562888
    x[414]    c615      -1
    x[414]    c616      1
    x[414]    c1519     -1
    x[414]    c2089     -1
    x[414]    c3179     -1
    x[414]    c3339     -1
    x[414]    c4719     660
    x[414]    c4720     -660
    x[414]    c4729     174
    x[414]    c4730     -174
    x[414]    c4883     -1
    x[414]    OBJ       -3012.38607394155
    x[415]    c624      -1
    x[415]    c625      1
    x[415]    c2139     -1
    x[415]    c3209     1
    x[415]    c3219     1
    x[415]    c3229     1
    x[415]    c3239     1
    x[415]    c3249     1
    x[415]    c3259     1
    x[415]    c3269     1
    x[415]    c3389     -1
    x[415]    c4719     1447
    x[415]    c4720     -1447
    x[415]    c4729     1447
    x[415]    c4730     -1447
    x[415]    c4795     1
    x[415]    OBJ       -66323.6274891774
    x[416]    c633      -1
    x[416]    c634      1
    x[416]    c2209     -1
    x[416]    c3229     -1
    x[416]    c3279     1
    x[416]    c3289     1
    x[416]    c3299     1
    x[416]    c3309     1
    x[416]    c3319     1
    x[416]    c3459     -1
    x[416]    c4719     2896
    x[416]    c4720     -2896
    x[416]    c4729     2896
    x[416]    c4730     -2896
    x[416]    OBJ       -89484.259310795
    x[417]    c642      -1
    x[417]    c643      1
    x[417]    c2279     -1
    x[417]    c3149     -1
    x[417]    c3299     -1
    x[417]    c3329     1
    x[417]    c3339     1
    x[417]    c3349     1
    x[417]    c3359     1
    x[417]    c3369     1
    x[417]    c3539     -1
    x[417]    c4719     2692
    x[417]    c4720     -2692
    x[417]    c4729     2692
    x[417]    c4730     -2692
    x[417]    OBJ       -36500.5541760167
    x[418]    c651      -1
    x[418]    c652      1
    x[418]    c1689     -1
    x[418]    c2329     -1
    x[418]    c3189     -1
    x[418]    c3349     -1
    x[418]    c3589     -1
    x[418]    c4139     -1
    x[418]    c4719     964
    x[418]    c4720     -964
    x[418]    c4729     288
    x[418]    c4730     -288
    x[418]    c4767     -1
    x[418]    OBJ       -2936.43724881222
    x[419]    c660      -1
    x[419]    c661      1
    x[419]    c2369     -1
    x[419]    c3379     1
    x[419]    c3389     1
    x[419]    c3399     1
    x[419]    c3409     1
    x[419]    c3419     1
    x[419]    c3429     1
    x[419]    c3439     1
    x[419]    c3639     -1
    x[419]    c4719     1432
    x[419]    c4720     -1432
    x[419]    c4729     1432
    x[419]    c4730     -1432
    x[419]    c4904     1
    x[419]    OBJ       -84822.054203846
    x[420]    c669      -1
    x[420]    c670      1
    x[420]    c2439     -1
    x[420]    c3399     -1
    x[420]    c3449     1
    x[420]    c3459     1
    x[420]    c3469     1
    x[420]    c3479     1
    x[420]    c3489     1
    x[420]    c3499     1
    x[420]    c3509     1
    x[420]    c3519     1
    x[420]    c3689     -1
    x[420]    c4719     2872
    x[420]    c4720     -2872
    x[420]    c4729     2872
    x[420]    c4730     -2872
    x[420]    c4822     1
    x[420]    c4827     1
    x[420]    OBJ       -139790.956351906
    x[421]    c678      -1
    x[421]    c679      1
    x[421]    c2499     -1
    x[421]    c3239     -1
    x[421]    c3469     -1
    x[421]    c3529     1
    x[421]    c3539     1
    x[421]    c3549     1
    x[421]    c3559     1
    x[421]    c3569     1
    x[421]    c3749     -1
    x[421]    c4719     2888
    x[421]    c4720     -2888
    x[421]    c4729     2888
    x[421]    c4730     -2888
    x[421]    OBJ       -107982.686025464
    x[422]    c687      -1
    x[422]    c688      1
    x[422]    c2589     -1
    x[422]    c3309     -1
    x[422]    c3549     -1
    x[422]    c3579     1
    x[422]    c3589     1
    x[422]    c3599     1
    x[422]    c3609     1
    x[422]    c3619     1
    x[422]    c3839     -1
    x[422]    c4189     -1
    x[422]    c4719     2692
    x[422]    c4720     -2692
    x[422]    c4729     2692
    x[422]    c4730     -2692
    x[422]    OBJ       -50983.4687501841
    x[423]    c696      -1
    x[423]    c697      1
    x[423]    c2639     -1
    x[423]    c3359     -1
    x[423]    c3599     -1
    x[423]    c3889     -1
    x[423]    c4229     -1
    x[423]    c4719     1168
    x[423]    c4720     -1168
    x[423]    c4729     528
    x[423]    c4730     -528
    x[423]    OBJ       -9745.51261065464
    x[424]    c705      -1
    x[424]    c706      1
    x[424]    c3629     1
    x[424]    c3639     1
    x[424]    c3649     1
    x[424]    c3659     1
    x[424]    c3669     1
    x[424]    c4719     716
    x[424]    c4720     -716
    x[424]    c4729     716
    x[424]    c4730     -716
    x[424]    c4954     1
    x[424]    OBJ       -50231.5001845471
    x[425]    c714      -1
    x[425]    c715      1
    x[425]    c3649     -1
    x[425]    c3679     1
    x[425]    c3689     1
    x[425]    c3699     1
    x[425]    c3709     1
    x[425]    c3719     1
    x[425]    c3729     1
    x[425]    c4719     2864
    x[425]    c4720     -2864
    x[425]    c4729     2864
    x[425]    c4730     -2864
    x[425]    c4854     1
    x[425]    OBJ       -173855.132375259
    x[426]    c723      -1
    x[426]    c724      1
    x[426]    c2689     -1
    x[426]    c3409     -1
    x[426]    c3699     -1
    x[426]    c3739     1
    x[426]    c3749     1
    x[426]    c3759     1
    x[426]    c3769     1
    x[426]    c3779     1
    x[426]    c3789     1
    x[426]    c3799     1
    x[426]    c3809     1
    x[426]    c3819     1
    x[426]    c4719     2864
    x[426]    c4720     -2864
    x[426]    c4729     2864
    x[426]    c4730     -2864
    x[426]    c4758     1
    x[426]    c4767     1
    x[426]    c4768     1
    x[426]    c4769     1
    x[426]    c4770     1
    x[426]    OBJ       -176411.825498424
    x[427]    c732      -1
    x[427]    c733      1
    x[427]    c2769     -1
    x[427]    c3479     -1
    x[427]    c3759     -1
    x[427]    c3829     1
    x[427]    c3839     1
    x[427]    c3849     1
    x[427]    c3859     1
    x[427]    c3869     1
    x[427]    c3939     -1
    x[427]    c4279     -1
    x[427]    c4719     2865
    x[427]    c4720     -2865
    x[427]    c4729     2865
    x[427]    c4730     -2865
    x[427]    c4904     -1
    x[427]    OBJ       -168892.139842055
    x[428]    c741      -1
    x[428]    c742      1
    x[428]    c2849     -1
    x[428]    c3559     -1
    x[428]    c3849     -1
    x[428]    c3879     1
    x[428]    c3889     1
    x[428]    c3899     1
    x[428]    c3909     1
    x[428]    c3919     1
    x[428]    c3999     -1
    x[428]    c4339     -1
    x[428]    c4719     2686
    x[428]    c4720     -2686
    x[428]    c4729     2684
    x[428]    c4730     -2684
    x[428]    c4822     -1
    x[428]    OBJ       -99410.2443772025
    x[429]    c750      -1
    x[429]    c751      1
    x[429]    c1359     -1
    x[429]    c2899     -1
    x[429]    c3609     -1
    x[429]    c3899     -1
    x[429]    c4049     -1
    x[429]    c4389     -1
    x[429]    c4719     1152
    x[429]    c4720     -1152
    x[429]    c4729     624
    x[429]    c4730     -624
    x[429]    OBJ       -19468.4661643402
    x[430]    c759      -1
    x[430]    c760      1
    x[430]    c3709     -1
    x[430]    c3929     1
    x[430]    c3939     1
    x[430]    c3949     1
    x[430]    c3959     1
    x[430]    c3969     1
    x[430]    c3979     1
    x[430]    c4719     1432
    x[430]    c4720     -1432
    x[430]    c4729     1432
    x[430]    c4730     -1432
    x[430]    OBJ       -89333.8655976676
    x[431]    c768      -1
    x[431]    c769      1
    x[431]    c2939     -1
    x[431]    c3769     -1
    x[431]    c3949     -1
    x[431]    c3989     1
    x[431]    c3999     1
    x[431]    c4009     1
    x[431]    c4019     1
    x[431]    c4029     1
    x[431]    c4439     -1
    x[431]    c4719     2864
    x[431]    c4720     -2864
    x[431]    c4729     2864
    x[431]    c4730     -2864
    x[431]    OBJ       -128210.640441097
    x[432]    c777      -1
    x[432]    c778      1
    x[432]    c3019     -1
    x[432]    c3859     -1
    x[432]    c4009     -1
    x[432]    c4039     1
    x[432]    c4049     1
    x[432]    c4059     1
    x[432]    c4069     1
    x[432]    c4079     1
    x[432]    c4489     -1
    x[432]    c4719     2684
    x[432]    c4720     -2684
    x[432]    c4729     2680
    x[432]    c4730     -2680
    x[432]    c4939     -1
    x[432]    OBJ       -89559.4561673587
    x[433]    c786      -1
    x[433]    c787      1
    x[433]    c1529     -1
    x[433]    c3069     -1
    x[433]    c3909     -1
    x[433]    c4059     -1
    x[433]    c4099     -1
    x[433]    c4539     -1
    x[433]    c4719     1099
    x[433]    c4720     -1099
    x[433]    c4729     672
    x[433]    c4730     -672
    x[433]    c4857     -1
    x[433]    OBJ       -27845.3959855356
    x[434]    c795      -1
    x[434]    c796      1
    x[434]    c4019     -1
    x[434]    c4089     1
    x[434]    c4099     1
    x[434]    c4109     1
    x[434]    c4119     1
    x[434]    c4129     1
    x[434]    c4719     1342
    x[434]    c4720     -1342
    x[434]    c4729     1340
    x[434]    c4730     -1340
    x[434]    c4768     -1
    x[434]    OBJ       -21205.5135509615
    x[435]    c804      -1
    x[435]    c805      1
    x[435]    c1699     -1
    x[435]    c3119     -1
    x[435]    c4069     -1
    x[435]    c4109     -1
    x[435]    c4589     -1
    x[435]    c4719     880
    x[435]    c4720     -880
    x[435]    c4729     629
    x[435]    c4730     -629
    x[435]    OBJ       -16295.1588173523
    x[436]    c813      -1
    x[436]    c814      1
    x[436]    c4119     -1
    x[436]    c4719     326
    x[436]    c4720     -326
    x[436]    c4729     256
    x[436]    c4730     -256
    x[436]    OBJ       -6023.26821075183
    x[437]    c822      -1
    x[437]    c823      1
    x[437]    c2529     -1
    x[437]    c3199     -1
    x[437]    c4149     -1
    x[437]    c4719     360
    x[437]    c4720     -360
    x[437]    OBJ       810.622113756614
    x[438]    c831      -1
    x[438]    c832      1
    x[438]    c2709     -1
    x[438]    c3319     -1
    x[438]    c4139     1
    x[438]    c4149     1
    x[438]    c4159     1
    x[438]    c4169     1
    x[438]    c4179     1
    x[438]    c4199     -1
    x[438]    c4719     1346
    x[438]    c4720     -1346
    x[438]    c4729     1322
    x[438]    c4730     -1322
    x[438]    OBJ       -9662.79606843457
    x[439]    c840      -1
    x[439]    c841      1
    x[439]    c2789     -1
    x[439]    c3369     -1
    x[439]    c4159     -1
    x[439]    c4239     -1
    x[439]    c4719     689
    x[439]    c4720     -689
    x[439]    c4729     241
    x[439]    c4730     -241
    x[439]    OBJ       -3926.77984975606
    x[440]    c849      -1
    x[440]    c850      1
    x[440]    c3489     -1
    x[440]    c4189     1
    x[440]    c4199     1
    x[440]    c4209     1
    x[440]    c4219     1
    x[440]    c4289     -1
    x[440]    c4719     1448
    x[440]    c4720     -1448
    x[440]    c4729     1448
    x[440]    c4730     -1448
    x[440]    OBJ       -36921.6565727734
    x[441]    c858      -1
    x[441]    c859      1
    x[441]    c3569     -1
    x[441]    c4209     -1
    x[441]    c4229     1
    x[441]    c4239     1
    x[441]    c4249     1
    x[441]    c4259     1
    x[441]    c4269     1
    x[441]    c4349     -1
    x[441]    c4719     2692
    x[441]    c4720     -2692
    x[441]    c4729     2668
    x[441]    c4730     -2668
    x[441]    OBJ       -21385.9860067144
    x[442]    c867      -1
    x[442]    c868      1
    x[442]    c1989     -1
    x[442]    c2959     -1
    x[442]    c3619     -1
    x[442]    c4169     -1
    x[442]    c4249     -1
    x[442]    c4399     -1
    x[442]    c4719     828
    x[442]    c4720     -828
    x[442]    c4729     291
    x[442]    c4730     -291
    x[442]    c4769     -1
    x[442]    OBJ       -3289.11050609595
    x[443]    c876      -1
    x[443]    c877      1
    x[443]    c3719     -1
    x[443]    c4279     1
    x[443]    c4289     1
    x[443]    c4299     1
    x[443]    c4309     1
    x[443]    c4319     1
    x[443]    c4329     1
    x[443]    c4719     1432
    x[443]    c4720     -1432
    x[443]    c4729     1432
    x[443]    c4730     -1432
    x[443]    OBJ       -87453.9441835752
    x[444]    c885      -1
    x[444]    c886      1
    x[444]    c3779     -1
    x[444]    c4299     -1
    x[444]    c4339     1
    x[444]    c4349     1
    x[444]    c4359     1
    x[444]    c4369     1
    x[444]    c4379     1
    x[444]    c4449     -1
    x[444]    c4719     2880
    x[444]    c4720     -2880
    x[444]    c4729     2880
    x[444]    c4730     -2880
    x[444]    OBJ       -132797.648691482
    x[445]    c894      -1
    x[445]    c895      1
    x[445]    c2159     -1
    x[445]    c3869     -1
    x[445]    c4219     -1
    x[445]    c4359     -1
    x[445]    c4389     1
    x[445]    c4399     1
    x[445]    c4409     1
    x[445]    c4419     1
    x[445]    c4429     1
    x[445]    c4499     -1
    x[445]    c4719     2691
    x[445]    c4720     -2691
    x[445]    c4729     2691
    x[445]    c4730     -2691
    x[445]    OBJ       -45193.3107947796
    x[446]    c903      -1
    x[446]    c904      1
    x[446]    c2229     -1
    x[446]    c3919     -1
    x[446]    c4259     -1
    x[446]    c4409     -1
    x[446]    c4549     -1
    x[446]    c4639     -1
    x[446]    c4719     840
    x[446]    c4720     -840
    x[446]    c4729     543
    x[446]    c4730     -543
    x[446]    OBJ       -13189.5286412718
    x[447]    c912      -1
    x[447]    c913      1
    x[447]    c4439     1
    x[447]    c4449     1
    x[447]    c4459     1
    x[447]    c4469     1
    x[447]    c4479     1
    x[447]    c4719     716
    x[447]    c4720     -716
    x[447]    c4729     716
    x[447]    c4730     -716
    x[447]    OBJ       -44441.3422291427
    x[448]    c921      -1
    x[448]    c922      1
    x[448]    c2379     -1
    x[448]    c3959     -1
    x[448]    c4309     -1
    x[448]    c4459     -1
    x[448]    c4489     1
    x[448]    c4499     1
    x[448]    c4509     1
    x[448]    c4519     1
    x[448]    c4529     1
    x[448]    c4719     2148
    x[448]    c4720     -2148
    x[448]    c4729     2148
    x[448]    c4730     -2148
    x[448]    OBJ       -112795.28484554
    x[449]    c930      -1
    x[449]    c931      1
    x[449]    c2449     -1
    x[449]    c4029     -1
    x[449]    c4369     -1
    x[449]    c4509     -1
    x[449]    c4539     1
    x[449]    c4549     1
    x[449]    c4559     1
    x[449]    c4569     1
    x[449]    c4579     1
    x[449]    c4719     2684
    x[449]    c4720     -2684
    x[449]    c4729     2680
    x[449]    c4730     -2680
    x[449]    OBJ       -99410.2443772025
    x[450]    c939      -1
    x[450]    c940      1
    x[450]    c2539     -1
    x[450]    c4079     -1
    x[450]    c4419     -1
    x[450]    c4559     -1
    x[450]    c4599     -1
    x[450]    c4679     -1
    x[450]    c4719     841
    x[450]    c4720     -841
    x[450]    c4729     480
    x[450]    c4730     -480
    x[450]    c4770     -1
    x[450]    OBJ       -23393.742076965
    x[451]    c948      -1
    x[451]    c949      1
    x[451]    c2719     -1
    x[451]    c4519     -1
    x[451]    c4589     1
    x[451]    c4599     1
    x[451]    c4609     1
    x[451]    c4619     1
    x[451]    c4629     1
    x[451]    c4719     671
    x[451]    c4720     -671
    x[451]    c4729     670
    x[451]    c4730     -670
    x[451]    OBJ       -17746.4581490316
    x[452]    c957      -1
    x[452]    c958      1
    x[452]    c2799     -1
    x[452]    c4129     -1
    x[452]    c4569     -1
    x[452]    c4609     -1
    x[452]    c4719     754
    x[452]    c4720     -754
    x[452]    c4729     450
    x[452]    c4730     -450
    x[452]    OBJ       -20701.6946119847
    x[453]    c966      -1
    x[453]    c967      1
    x[453]    c2969     -1
    x[453]    c4619     -1
    x[453]    c4719     289
    x[453]    c4720     -289
    x[453]    c4729     186
    x[453]    c4730     -186
    x[453]    OBJ       -5511.92958611871
    x[454]    c975      -1
    x[454]    c976      1
    x[454]    c3809     -1
    x[454]    c4179     -1
    x[454]    c4719     150
    x[454]    c4720     -150
    x[454]    OBJ       338.38585453662
    x[455]    c984      -1
    x[455]    c985      1
    x[455]    c3979     -1
    x[455]    c4269     -1
    x[455]    c4649     -1
    x[455]    c4719     315
    x[455]    c4720     -315
    x[455]    c4729     52
    x[455]    c4730     -52
    x[455]    OBJ       -133.098436117737
    x[456]    c993      -1
    x[456]    c994      1
    x[456]    c4379     -1
    x[456]    c4639     1
    x[456]    c4649     1
    x[456]    c4659     1
    x[456]    c4669     1
    x[456]    c4719     1346
    x[456]    c4720     -1346
    x[456]    c4729     1322
    x[456]    c4730     -1322
    x[456]    OBJ       -14347.5602323527
    x[457]    c1002     -1
    x[457]    c1003     1
    x[457]    c3269     -1
    x[457]    c4429     -1
    x[457]    c4659     -1
    x[457]    c4689     -1
    x[457]    c4719     548
    x[457]    c4720     -548
    x[457]    c4729     133
    x[457]    c4730     -133
    x[457]    OBJ       -2152.88600341854
    x[458]    c1011     -1
    x[458]    c1012     1
    x[458]    c3439     -1
    x[458]    c4529     -1
    x[458]    c4679     1
    x[458]    c4689     1
    x[458]    c4699     1
    x[458]    c4709     1
    x[458]    c4719     672
    x[458]    c4720     -672
    x[458]    c4729     672
    x[458]    c4730     -672
    x[458]    OBJ       -12633.0719027005
    x[459]    c1020     -1
    x[459]    c1021     1
    x[459]    c3519     -1
    x[459]    c4579     -1
    x[459]    c4669     -1
    x[459]    c4699     -1
    x[459]    c4719     429
    x[459]    c4720     -429
    x[459]    c4729     142
    x[459]    c4730     -142
    x[459]    OBJ       -4556.92950775981
    x[460]    c1029     -1
    x[460]    c1030     1
    x[460]    c3819     -1
    x[460]    c4629     -1
    x[460]    c4709     -1
    x[460]    c4719     273
    x[460]    c4720     -273
    x[460]    c4729     94
    x[460]    c4730     -94
    x[460]    OBJ       -4241.1027101923
    x[461]    c4        -1
    x[461]    c5        1
    x[461]    c2390     -1
    x[461]    c4720     219
    x[461]    c4721     -219
    x[461]    c4730     75
    x[461]    c4731     -75
    x[461]    OBJ       -1427.42988755545
    x[462]    c13       -1
    x[462]    c14       1
    x[462]    c1340     -1
    x[462]    c4720     328
    x[462]    c4721     -328
    x[462]    c4730     215
    x[462]    c4731     -215
    x[462]    OBJ       -2913.52127733921
    x[463]    c22       -1
    x[463]    c23       1
    x[463]    c1510     -1
    x[463]    c3670     -1
    x[463]    c4720     545
    x[463]    c4721     -545
    x[463]    c4730     368
    x[463]    c4731     -368
    x[463]    OBJ       -6654.82153056673
    x[464]    c31       -1
    x[464]    c32       1
    x[464]    c1070     -1
    x[464]    c1680     -1
    x[464]    c4720     435
    x[464]    c4721     -435
    x[464]    c4730     400
    x[464]    c4731     -400
    x[464]    OBJ       -10148.439885497
    x[465]    c40       -1
    x[465]    c41       1
    x[465]    c1120     -1
    x[465]    c4720     247
    x[465]    c4721     -247
    x[465]    c4730     216
    x[465]    c4731     -216
    x[465]    OBJ       -4523.45361627161
    x[466]    c49       -1
    x[466]    c50       1
    x[466]    c1970     -1
    x[466]    c4720     82
    x[466]    c4721     -82
    x[466]    c4730     27
    x[466]    c4731     -27
    x[466]    OBJ       -475.15816804928
    x[467]    c58       -1
    x[467]    c59       1
    x[467]    c1080     -1
    x[467]    c1240     -1
    x[467]    c2510     -1
    x[467]    c4720     526
    x[467]    c4721     -526
    x[467]    c4730     314
    x[467]    c4731     -314
    x[467]    OBJ       -4402.87163946898
    x[468]    c67       -1
    x[468]    c68       1
    x[468]    c1040     1
    x[468]    c1050     1
    x[468]    c1060     1
    x[468]    c1290     -1
    x[468]    c4720     693
    x[468]    c4721     -693
    x[468]    c4730     693
    x[468]    c4731     -693
    x[468]    OBJ       -33697.7740578159
    x[469]    c76       -1
    x[469]    c77       1
    x[469]    c1040     -1
    x[469]    c1070     1
    x[469]    c1080     1
    x[469]    c1090     1
    x[469]    c1100     1
    x[469]    c1110     1
    x[469]    c1370     -1
    x[469]    c2700     -1
    x[469]    c4720     1944
    x[469]    c4721     -1944
    x[469]    c4730     1944
    x[469]    c4731     -1944
    x[469]    OBJ       -50383.712469423
    x[470]    c85       -1
    x[470]    c86       1
    x[470]    c1090     -1
    x[470]    c1130     -1
    x[470]    c1420     -1
    x[470]    c2780     -1
    x[470]    c4720     907
    x[470]    c4721     -907
    x[470]    c4730     574
    x[470]    c4731     -574
    x[470]    c4923     -1
    x[470]    OBJ       -14587.1602207721
    x[471]    c94       -1
    x[471]    c95       1
    x[471]    c1050     -1
    x[471]    c1120     1
    x[471]    c1130     1
    x[471]    c1140     1
    x[471]    c1150     1
    x[471]    c1160     1
    x[471]    c1540     -1
    x[471]    c4720     1296
    x[471]    c4721     -1296
    x[471]    c4730     1128
    x[471]    c4731     -1128
    x[471]    OBJ       -16062.8228990486
    x[472]    c103      -1
    x[472]    c104      1
    x[472]    c1100     -1
    x[472]    c1140     -1
    x[472]    c1170     -1
    x[472]    c1590     -1
    x[472]    c1980     -1
    x[472]    c2950     -1
    x[472]    c4720     1043
    x[472]    c4721     -1043
    x[472]    c4730     864
    x[472]    c4731     -864
    x[472]    OBJ       -13338.3220177784
    x[473]    c112      -1
    x[473]    c113      1
    x[473]    c1170     1
    x[473]    c1180     1
    x[473]    c1190     1
    x[473]    c1200     1
    x[473]    c1710     -1
    x[473]    c2150     -1
    x[473]    c4720     1332
    x[473]    c4721     -1332
    x[473]    c4730     1330
    x[473]    c4731     -1330
    x[473]    OBJ       -30569.1606056396
    x[474]    c121      -1
    x[474]    c122      1
    x[474]    c1150     -1
    x[474]    c1180     -1
    x[474]    c1760     -1
    x[474]    c2220     -1
    x[474]    c4720     1186
    x[474]    c4721     -1186
    x[474]    c4730     864
    x[474]    c4731     -864
    x[474]    OBJ       -18497.9270359925
    x[475]    c130      -1
    x[475]    c131      1
    x[475]    c1190     -1
    x[475]    c1840     -1
    x[475]    c2520     -1
    x[475]    c4720     984
    x[475]    c4721     -984
    x[475]    c4730     723
    x[475]    c4731     -723
    x[475]    c4979     -1
    x[475]    OBJ       -9183.78407107594
    x[476]    c139      -1
    x[476]    c140      1
    x[476]    c1250     -1
    x[476]    c1890     -1
    x[476]    c3250     -1
    x[476]    c4720     225
    x[476]    c4721     -225
    x[476]    c4730     20
    x[476]    c4731     -20
    x[476]    OBJ       37.1522847445939
    x[477]    c148      -1
    x[477]    c149      1
    x[477]    c1210     1
    x[477]    c1220     1
    x[477]    c1230     1
    x[477]    c1300     -1
    x[477]    c1930     -1
    x[477]    c4720     724
    x[477]    c4721     -724
    x[477]    c4730     724
    x[477]    c4731     -724
    x[477]    OBJ       -25094.087064331
    x[478]    c157      -1
    x[478]    c158      1
    x[478]    c1210     -1
    x[478]    c1240     1
    x[478]    c1250     1
    x[478]    c1260     1
    x[478]    c1270     1
    x[478]    c1280     1
    x[478]    c1380     -1
    x[478]    c2000     -1
    x[478]    c3420     -1
    x[478]    c4720     1989
    x[478]    c4721     -1989
    x[478]    c4730     1989
    x[478]    c4731     -1989
    x[478]    OBJ       -21756.8993820096
    x[479]    c166      -1
    x[479]    c167      1
    x[479]    c1260     -1
    x[479]    c1430     -1
    x[479]    c2050     -1
    x[479]    c3500     -1
    x[479]    c4720     710
    x[479]    c4721     -710
    x[479]    c4730     382
    x[479]    c4731     -382
    x[479]    OBJ       -6087.76034235978
    x[480]    c175      -1
    x[480]    c176      1
    x[480]    c1290     1
    x[480]    c1300     1
    x[480]    c1310     1
    x[480]    c1320     1
    x[480]    c1330     1
    x[480]    c1340     1
    x[480]    c1350     1
    x[480]    c1360     1
    x[480]    c2100     -1
    x[480]    c4720     716
    x[480]    c4721     -716
    x[480]    c4730     716
    x[480]    c4731     -716
    x[480]    c4739     1
    x[480]    OBJ       -37999.6175545583
    x[481]    c184      -1
    x[481]    c185      1
    x[481]    c1310     -1
    x[481]    c1370     1
    x[481]    c1380     1
    x[481]    c1390     1
    x[481]    c1400     1
    x[481]    c1410     1
    x[481]    c1470     -1
    x[481]    c2170     -1
    x[481]    c3660     -1
    x[481]    c4720     2876
    x[481]    c4721     -2876
    x[481]    c4730     2876
    x[481]    c4731     -2876
    x[481]    OBJ       -120190.900121107
    x[482]    c193      -1
    x[482]    c194      1
    x[482]    c1060     -1
    x[482]    c1220     -1
    x[482]    c1390     -1
    x[482]    c1420     1
    x[482]    c1430     1
    x[482]    c1440     1
    x[482]    c1450     1
    x[482]    c1460     1
    x[482]    c1550     -1
    x[482]    c2240     -1
    x[482]    c3730     -1
    x[482]    c4720     2595
    x[482]    c4721     -2595
    x[482]    c4730     2595
    x[482]    c4731     -2595
    x[482]    c4809     -1
    x[482]    c4811     -1
    x[482]    OBJ       -25713.2918100742
    x[483]    c202      -1
    x[483]    c203      1
    x[483]    c1110     -1
    x[483]    c1270     -1
    x[483]    c1440     -1
    x[483]    c1600     -1
    x[483]    c2290     -1
    x[483]    c3790     -1
    x[483]    c4720     1030
    x[483]    c4721     -1030
    x[483]    c4730     552
    x[483]    c4731     -552
    x[483]    c4970     -1
    x[483]    OBJ       -3441.47479739396
    x[484]    c211      -1
    x[484]    c212      1
    x[484]    c1470     1
    x[484]    c1480     1
    x[484]    c1490     1
    x[484]    c1500     1
    x[484]    c1510     1
    x[484]    c1520     1
    x[484]    c1530     1
    x[484]    c2400     -1
    x[484]    c4720     1432
    x[484]    c4721     -1432
    x[484]    c4730     1432
    x[484]    c4731     -1432
    x[484]    OBJ       -70458.9821208877
    x[485]    c220      -1
    x[485]    c221      1
    x[485]    c1320     -1
    x[485]    c1480     -1
    x[485]    c1540     1
    x[485]    c1550     1
    x[485]    c1560     1
    x[485]    c1570     1
    x[485]    c1580     1
    x[485]    c1640     -1
    x[485]    c2460     -1
    x[485]    c4720     2864
    x[485]    c4721     -2864
    x[485]    c4730     2864
    x[485]    c4731     -2864
    x[485]    OBJ       -96530.7608890239
    x[486]    c229      -1
    x[486]    c230      1
    x[486]    c1400     -1
    x[486]    c1560     -1
    x[486]    c1590     1
    x[486]    c1600     1
    x[486]    c1610     1
    x[486]    c1620     1
    x[486]    c1630     1
    x[486]    c1720     -1
    x[486]    c2550     -1
    x[486]    c4720     2600
    x[486]    c4721     -2600
    x[486]    c4730     2336
    x[486]    c4731     -2336
    x[486]    c4918     -1
    x[486]    OBJ       -36852.4592887604
    x[487]    c238      -1
    x[487]    c239      1
    x[487]    c1160     -1
    x[487]    c1450     -1
    x[487]    c1610     -1
    x[487]    c1770     -1
    x[487]    c2600     -1
    x[487]    c3970     -1
    x[487]    c4720     1156
    x[487]    c4721     -1156
    x[487]    c4730     696
    x[487]    c4731     -696
    x[487]    c4840     -1
    x[487]    OBJ       -8545.02549125661
    x[488]    c247      -1
    x[488]    c248      1
    x[488]    c1640     1
    x[488]    c1650     1
    x[488]    c1660     1
    x[488]    c1670     1
    x[488]    c1680     1
    x[488]    c1690     1
    x[488]    c1700     1
    x[488]    c2650     -1
    x[488]    c4720     716
    x[488]    c4721     -716
    x[488]    c4730     716
    x[488]    c4731     -716
    x[488]    c4742     1
    x[488]    OBJ       -35262.0807839041
    x[489]    c256      -1
    x[489]    c257      1
    x[489]    c1490     -1
    x[489]    c1650     -1
    x[489]    c1710     1
    x[489]    c1720     1
    x[489]    c1730     1
    x[489]    c1740     1
    x[489]    c1750     1
    x[489]    c2730     -1
    x[489]    c4720     2864
    x[489]    c4721     -2864
    x[489]    c4730     2864
    x[489]    c4731     -2864
    x[489]    OBJ       -109436.291379251
    x[490]    c265      -1
    x[490]    c266      1
    x[490]    c1570     -1
    x[490]    c1730     -1
    x[490]    c1760     1
    x[490]    c1770     1
    x[490]    c1780     1
    x[490]    c1790     1
    x[490]    c1800     1
    x[490]    c1810     -1
    x[490]    c2810     -1
    x[490]    c4720     2681
    x[490]    c4721     -2681
    x[490]    c4730     2678
    x[490]    c4731     -2678
    x[490]    OBJ       -101940.654983412
    x[491]    c274      -1
    x[491]    c275      1
    x[491]    c1200     -1
    x[491]    c1620     -1
    x[491]    c1780     -1
    x[491]    c1850     -1
    x[491]    c2860     -1
    x[491]    c3260     -1
    x[491]    c4720     1263
    x[491]    c4721     -1263
    x[491]    c4730     864
    x[491]    c4731     -864
    x[491]    c4971     -1
    x[491]    OBJ       -36826.3875099922
    x[492]    c283      -1
    x[492]    c284      1
    x[492]    c1660     -1
    x[492]    c1810     1
    x[492]    c1820     1
    x[492]    c1830     1
    x[492]    c2910     -1
    x[492]    c4720     716
    x[492]    c4721     -716
    x[492]    c4730     716
    x[492]    c4731     -716
    x[492]    OBJ       -23855.6775728445
    x[493]    c292      -1
    x[493]    c293      1
    x[493]    c1740     -1
    x[493]    c1820     -1
    x[493]    c1840     1
    x[493]    c1850     1
    x[493]    c1860     1
    x[493]    c1870     1
    x[493]    c1880     1
    x[493]    c2980     -1
    x[493]    c3430     -1
    x[493]    c4720     1965
    x[493]    c4721     -1965
    x[493]    c4730     1964
    x[493]    c4731     -1964
    x[493]    OBJ       -42496.9993920618
    x[494]    c301      -1
    x[494]    c302      1
    x[494]    c1790     -1
    x[494]    c1860     -1
    x[494]    c3030     -1
    x[494]    c3510     -1
    x[494]    c4720     1245
    x[494]    c4721     -1245
    x[494]    c4730     889
    x[494]    c4731     -889
    x[494]    c4926     -1
    x[494]    OBJ       -20642.3308396717
    x[495]    c310      -1
    x[495]    c311      1
    x[495]    c1870     -1
    x[495]    c3080     -1
    x[495]    c3800     -1
    x[495]    c4720     832
    x[495]    c4721     -832
    x[495]    c4730     647
    x[495]    c4731     -647
    x[495]    OBJ       -6188.1366906171
    x[496]    c319      -1
    x[496]    c320      1
    x[496]    c4720     339
    x[496]    c4721     -339
    x[496]    c4730     283
    x[496]    c4731     -283
    x[496]    OBJ       -3643.53108284702
    x[497]    c328      -1
    x[497]    c329      1
    x[497]    c1890     1
    x[497]    c1900     1
    x[497]    c1910     1
    x[497]    c1920     1
    x[497]    c2010     -1
    x[497]    c4720     1346
    x[497]    c4721     -1346
    x[497]    c4730     1346
    x[497]    c4731     -1346
    x[497]    OBJ       -29917.3661364361
    x[498]    c337      -1
    x[498]    c338      1
    x[498]    c1900     -1
    x[498]    c2060     -1
    x[498]    c4720     243
    x[498]    c4721     -243
    x[498]    OBJ       473.724220217033
    x[499]    c346      -1
    x[499]    c347      1
    x[499]    c1930     1
    x[499]    c1940     1
    x[499]    c1950     1
    x[499]    c1960     1
    x[499]    c1970     1
    x[499]    c1980     1
    x[499]    c1990     1
    x[499]    c2110     -1
    x[499]    c4720     724
    x[499]    c4721     -724
    x[499]    c4730     724
    x[499]    c4731     -724
    x[499]    OBJ       -34349.5685270193
    x[500]    c355      -1
    x[500]    c356      1
    x[500]    c1940     -1
    x[500]    c2000     1
    x[500]    c2010     1
    x[500]    c2020     1
    x[500]    c2030     1
    x[500]    c2040     1
    x[500]    c2180     -1
    x[500]    c4720     2896
    x[500]    c4721     -2896
    x[500]    c4730     2896
    x[500]    c4731     -2896
    x[500]    OBJ       -106242.498480155
    x[501]    c364      -1
    x[501]    c365      1
    x[501]    c1230     -1
    x[501]    c2020     -1
    x[501]    c2050     1
    x[501]    c2060     1
    x[501]    c2070     1
    x[501]    c2080     1
    x[501]    c2090     1
    x[501]    c2250     -1
    x[501]    c3130     -1
    x[501]    c4720     2692
    x[501]    c4721     -2692
    x[501]    c4730     2692
    x[501]    c4731     -2692
    x[501]    OBJ       -53121.2492400773
    x[502]    c373      -1
    x[502]    c374      1
    x[502]    c1280     -1
    x[502]    c1910     -1
    x[502]    c2070     -1
    x[502]    c2300     -1
    x[502]    c3160     -1
    x[502]    c4720     755
    x[502]    c4721     -755
    x[502]    c4730     323
    x[502]    c4731     -323
    x[502]    c4921     -1
    x[502]    OBJ       -4482.3905647118
    x[503]    c382      -1
    x[503]    c383      1
    x[503]    c2100     1
    x[503]    c2110     1
    x[503]    c2120     1
    x[503]    c2130     1
    x[503]    c2140     1
    x[503]    c2150     1
    x[503]    c2160     1
    x[503]    c2340     -1
    x[503]    c4720     1432
    x[503]    c4721     -1432
    x[503]    c4730     1432
    x[503]    c4731     -1432
    x[503]    OBJ       -72544.7244223387
    x[504]    c391      -1
    x[504]    c392      1
    x[504]    c2120     -1
    x[504]    c2170     1
    x[504]    c2180     1
    x[504]    c2190     1
    x[504]    c2200     1
    x[504]    c2210     1
    x[504]    c2220     1
    x[504]    c2230     1
    x[504]    c2410     -1
    x[504]    c4720     2886
    x[504]    c4721     -2886
    x[504]    c4730     2886
    x[504]    c4731     -2886
    x[504]    c4740     1
    x[504]    OBJ       -136681.300191954
    x[505]    c400      -1
    x[505]    c401      1
    x[505]    c1330     -1
    x[505]    c1950     -1
    x[505]    c2190     -1
    x[505]    c2240     1
    x[505]    c2250     1
    x[505]    c2260     1
    x[505]    c2270     1
    x[505]    c2280     1
    x[505]    c2470     -1
    x[505]    c3210     -1
    x[505]    c4720     2895
    x[505]    c4721     -2895
    x[505]    c4730     2895
    x[505]    c4731     -2895
    x[505]    c4894     1
    x[505]    c4899     1
    x[505]    OBJ       -113738.134875994
    x[506]    c409      -1
    x[506]    c410      1
    x[506]    c1410     -1
    x[506]    c2030     -1
    x[506]    c2260     -1
    x[506]    c2290     1
    x[506]    c2300     1
    x[506]    c2310     1
    x[506]    c2320     1
    x[506]    c2330     1
    x[506]    c2560     -1
    x[506]    c3280     -1
    x[506]    c4720     2692
    x[506]    c4721     -2692
    x[506]    c4730     2668
    x[506]    c4731     -2668
    x[506]    OBJ       -44647.9211404331
    x[507]    c418      -1
    x[507]    c419      1
    x[507]    c1460     -1
    x[507]    c2080     -1
    x[507]    c2310     -1
    x[507]    c2610     -1
    x[507]    c3330     -1
    x[507]    c4320     -1
    x[507]    c4720     1115
    x[507]    c4721     -1115
    x[507]    c4730     408
    x[507]    c4731     -408
    x[507]    c4973     -1
    x[507]    OBJ       -3286.99950819276
    x[508]    c427      -1
    x[508]    c428      1
    x[508]    c2340     1
    x[508]    c2350     1
    x[508]    c2360     1
    x[508]    c2370     1
    x[508]    c2380     1
    x[508]    c2390     1
    x[508]    c4720     1432
    x[508]    c4721     -1432
    x[508]    c4730     1432
    x[508]    c4731     -1432
    x[508]    c4867     1
    x[508]    OBJ       -82777.8975888321
    x[509]    c436      -1
    x[509]    c437      1
    x[509]    c2350     -1
    x[509]    c2400     1
    x[509]    c2410     1
    x[509]    c2420     1
    x[509]    c2430     1
    x[509]    c2440     1
    x[509]    c2450     1
    x[509]    c4720     2864
    x[509]    c4721     -2864
    x[509]    c4730     2864
    x[509]    c4731     -2864
    x[509]    OBJ       -151477.034642871
    x[510]    c445      -1
    x[510]    c446      1
    x[510]    c2130     -1
    x[510]    c2420     -1
    x[510]    c2460     1
    x[510]    c2470     1
    x[510]    c2480     1
    x[510]    c2490     1
    x[510]    c2500     1
    x[510]    c2510     1
    x[510]    c2520     1
    x[510]    c2530     1
    x[510]    c2540     1
    x[510]    c2660     -1
    x[510]    c3380     -1
    x[510]    c4720     2864
    x[510]    c4721     -2864
    x[510]    c4730     2864
    x[510]    c4731     -2864
    x[510]    c4918     1
    x[510]    c4921     1
    x[510]    c4922     1
    x[510]    c4923     1
    x[510]    c4926     1
    x[510]    OBJ       -143068.885990147
    x[511]    c454      -1
    x[511]    c455      1
    x[511]    c1500     -1
    x[511]    c2200     -1
    x[511]    c2480     -1
    x[511]    c2550     1
    x[511]    c2560     1
    x[511]    c2570     1
    x[511]    c2580     1
    x[511]    c2590     1
    x[511]    c2740     -1
    x[511]    c3450     -1
    x[511]    c4720     2873
    x[511]    c4721     -2873
    x[511]    c4730     2873
    x[511]    c4731     -2873
    x[511]    OBJ       -110022.906401534
    x[512]    c463      -1
    x[512]    c464      1
    x[512]    c1580     -1
    x[512]    c2270     -1
    x[512]    c2570     -1
    x[512]    c2600     1
    x[512]    c2610     1
    x[512]    c2620     1
    x[512]    c2630     1
    x[512]    c2640     1
    x[512]    c2820     -1
    x[512]    c3530     -1
    x[512]    c4720     2679
    x[512]    c4721     -2679
    x[512]    c4730     2604
    x[512]    c4731     -2604
    x[512]    c4739     -1
    x[512]    c4740     -1
    x[512]    c4742     -1
    x[512]    OBJ       -38214.7097293955
    x[513]    c472      -1
    x[513]    c473      1
    x[513]    c1630     -1
    x[513]    c2320     -1
    x[513]    c2620     -1
    x[513]    c2870     -1
    x[513]    c3580     -1
    x[513]    c4470     -1
    x[513]    c4720     1252
    x[513]    c4721     -1252
    x[513]    c4730     552
    x[513]    c4731     -552
    x[513]    c4894     -1
    x[513]    OBJ       -7530.1815027069
    x[514]    c481      -1
    x[514]    c482      1
    x[514]    c2360     -1
    x[514]    c2650     1
    x[514]    c2660     1
    x[514]    c2670     1
    x[514]    c2680     1
    x[514]    c2690     1
    x[514]    c2700     1
    x[514]    c2710     1
    x[514]    c2720     1
    x[514]    c3630     -1
    x[514]    c4720     2148
    x[514]    c4721     -2148
    x[514]    c4730     2148
    x[514]    c4731     -2148
    x[514]    c4809     1
    x[514]    OBJ       -100441.527704244
    x[515]    c490      -1
    x[515]    c491      1
    x[515]    c2430     -1
    x[515]    c2670     -1
    x[515]    c2730     1
    x[515]    c2740     1
    x[515]    c2750     1
    x[515]    c2760     1
    x[515]    c2770     1
    x[515]    c2780     1
    x[515]    c2790     1
    x[515]    c2800     1
    x[515]    c3680     -1
    x[515]    c4720     2864
    x[515]    c4721     -2864
    x[515]    c4730     2864
    x[515]    c4731     -2864
    x[515]    c4961     1
    x[515]    c4970     1
    x[515]    c4971     1
    x[515]    c4973     1
    x[515]    c4974     1
    x[515]    c4977     -1
    x[515]    c4979     1
    x[515]    OBJ       -131075.867756804
    x[516]    c499      -1
    x[516]    c500      1
    x[516]    c1670     -1
    x[516]    c2490     -1
    x[516]    c2750     -1
    x[516]    c2810     1
    x[516]    c2820     1
    x[516]    c2830     1
    x[516]    c2840     1
    x[516]    c2850     1
    x[516]    c2920     -1
    x[516]    c3740     -1
    x[516]    c4720     2864
    x[516]    c4721     -2864
    x[516]    c4730     2864
    x[516]    c4731     -2864
    x[516]    c4864     -1
    x[516]    c4867     -1
    x[516]    c4868     1
    x[516]    c4870     1
    x[516]    OBJ       -119930.182333426
    x[517]    c508      -1
    x[517]    c509      1
    x[517]    c1750     -1
    x[517]    c2580     -1
    x[517]    c2830     -1
    x[517]    c2860     1
    x[517]    c2870     1
    x[517]    c2880     1
    x[517]    c2890     1
    x[517]    c2900     1
    x[517]    c2990     -1
    x[517]    c3830     -1
    x[517]    c4720     2684
    x[517]    c4721     -2684
    x[517]    c4730     2680
    x[517]    c4731     -2680
    x[517]    c4773     -1
    x[517]    OBJ       -101940.654983412
    x[518]    c517      -1
    x[518]    c518      1
    x[518]    c1800     -1
    x[518]    c2630     -1
    x[518]    c2880     -1
    x[518]    c3040     -1
    x[518]    c3880     -1
    x[518]    c4720     1253
    x[518]    c4721     -1253
    x[518]    c4730     840
    x[518]    c4731     -840
    x[518]    c4922     -1
    x[518]    OBJ       -28157.521069587
    x[519]    c526      -1
    x[519]    c527      1
    x[519]    c2680     -1
    x[519]    c2910     1
    x[519]    c2920     1
    x[519]    c2930     1
    x[519]    c2940     1
    x[519]    c2950     1
    x[519]    c2960     1
    x[519]    c2970     1
    x[519]    c4720     716
    x[519]    c4721     -716
    x[519]    c4730     716
    x[519]    c4731     -716
    x[519]    OBJ       -37804.0792137973
    x[520]    c535      -1
    x[520]    c536      1
    x[520]    c2760     -1
    x[520]    c2930     -1
    x[520]    c2980     1
    x[520]    c2990     1
    x[520]    c3000     1
    x[520]    c3010     1
    x[520]    c3020     1
    x[520]    c3930     -1
    x[520]    c4720     2864
    x[520]    c4721     -2864
    x[520]    c4730     2864
    x[520]    c4731     -2864
    x[520]    OBJ       -105329.98622327
    x[521]    c544      -1
    x[521]    c545      1
    x[521]    c1830     -1
    x[521]    c2840     -1
    x[521]    c3000     -1
    x[521]    c3030     1
    x[521]    c3040     1
    x[521]    c3050     1
    x[521]    c3060     1
    x[521]    c3070     1
    x[521]    c3990     -1
    x[521]    c4720     2651
    x[521]    c4721     -2651
    x[521]    c4730     2650
    x[521]    c4731     -2650
    x[521]    OBJ       -81083.2319689032
    x[522]    c553      -1
    x[522]    c554      1
    x[522]    c1880     -1
    x[522]    c2890     -1
    x[522]    c3050     -1
    x[522]    c3090     -1
    x[522]    c4040     -1
    x[522]    c4720     1175
    x[522]    c4721     -1175
    x[522]    c4730     768
    x[522]    c4731     -768
    x[522]    OBJ       -24859.4410554178
    x[523]    c562      -1
    x[523]    c563      1
    x[523]    c3010     -1
    x[523]    c3080     1
    x[523]    c3090     1
    x[523]    c3100     1
    x[523]    c3110     1
    x[523]    c3120     1
    x[523]    c4720     1333
    x[523]    c4721     -1333
    x[523]    c4730     1332
    x[523]    c4731     -1332
    x[523]    c4974     -1
    x[523]    OBJ       -28483.4183041887
    x[524]    c571      -1
    x[524]    c572      1
    x[524]    c3060     -1
    x[524]    c3100     -1
    x[524]    c4090     -1
    x[524]    c4330     -1
    x[524]    c4720     940
    x[524]    c4721     -940
    x[524]    c4730     728
    x[524]    c4731     -728
    x[524]    c4870     -1
    x[524]    OBJ       -19527.7622973339
    x[525]    c580      -1
    x[525]    c581      1
    x[525]    c3110     -1
    x[525]    c4480     -1
    x[525]    c4720     342
    x[525]    c4721     -342
    x[525]    c4730     317
    x[525]    c4731     -317
    x[525]    OBJ       -4823.27907210518
    x[526]    c589      -1
    x[526]    c590      1
    x[526]    c1350     -1
    x[526]    c1920     -1
    x[526]    c3170     -1
    x[526]    c4720     187
    x[526]    c4721     -187
    x[526]    OBJ       359.595008659517
    x[527]    c598      -1
    x[527]    c599      1
    x[527]    c1960     -1
    x[527]    c3130     1
    x[527]    c3140     1
    x[527]    c3150     1
    x[527]    c3220     -1
    x[527]    c4720     724
    x[527]    c4721     -724
    x[527]    c4730     724
    x[527]    c4731     -724
    x[527]    OBJ       -19293.1162884207
    x[528]    c607      -1
    x[528]    c608      1
    x[528]    c2040     -1
    x[528]    c3140     -1
    x[528]    c3160     1
    x[528]    c3170     1
    x[528]    c3180     1
    x[528]    c3190     1
    x[528]    c3200     1
    x[528]    c3290     -1
    x[528]    c4720     2019
    x[528]    c4721     -2019
    x[528]    c4730     1995
    x[528]    c4731     -1995
    x[528]    OBJ       -22604.232191974
    x[529]    c616      -1
    x[529]    c617      1
    x[529]    c1520     -1
    x[529]    c2090     -1
    x[529]    c3180     -1
    x[529]    c3340     -1
    x[529]    c4720     660
    x[529]    c4721     -660
    x[529]    c4730     174
    x[529]    c4731     -174
    x[529]    c4899     -1
    x[529]    OBJ       -2611.08864362883
    x[530]    c625      -1
    x[530]    c626      1
    x[530]    c2140     -1
    x[530]    c3210     1
    x[530]    c3220     1
    x[530]    c3230     1
    x[530]    c3240     1
    x[530]    c3250     1
    x[530]    c3260     1
    x[530]    c3270     1
    x[530]    c3390     -1
    x[530]    c4720     1447
    x[530]    c4721     -1447
    x[530]    c4730     1447
    x[530]    c4731     -1447
    x[530]    c4811     1
    x[530]    OBJ       -57488.2721837401
    x[531]    c634      -1
    x[531]    c635      1
    x[531]    c2210     -1
    x[531]    c3230     -1
    x[531]    c3280     1
    x[531]    c3290     1
    x[531]    c3300     1
    x[531]    c3310     1
    x[531]    c3320     1
    x[531]    c3460     -1
    x[531]    c4720     2896
    x[531]    c4721     -2896
    x[531]    c4730     2896
    x[531]    c4731     -2896
    x[531]    OBJ       -77563.5418352048
    x[532]    c643      -1
    x[532]    c644      1
    x[532]    c2280     -1
    x[532]    c3150     -1
    x[532]    c3300     -1
    x[532]    c3330     1
    x[532]    c3340     1
    x[532]    c3350     1
    x[532]    c3360     1
    x[532]    c3370     1
    x[532]    c3540     -1
    x[532]    c4720     2692
    x[532]    c4721     -2692
    x[532]    c4730     2692
    x[532]    c4731     -2692
    x[532]    OBJ       -31638.1035351331
    x[533]    c652      -1
    x[533]    c653      1
    x[533]    c1690     -1
    x[533]    c2330     -1
    x[533]    c3190     -1
    x[533]    c3350     -1
    x[533]    c3590     -1
    x[533]    c4140     -1
    x[533]    c4720     964
    x[533]    c4721     -964
    x[533]    c4730     288
    x[533]    c4731     -288
    x[533]    c4780     -1
    x[533]    OBJ       -2545.25740223929
    x[534]    c661      -1
    x[534]    c662      1
    x[534]    c2370     -1
    x[534]    c3380     1
    x[534]    c3390     1
    x[534]    c3400     1
    x[534]    c3410     1
    x[534]    c3420     1
    x[534]    c3430     1
    x[534]    c3440     1
    x[534]    c3640     -1
    x[534]    c4720     1432
    x[534]    c4721     -1432
    x[534]    c4730     1432
    x[534]    c4731     -1432
    x[534]    c4920     1
    x[534]    OBJ       -73522.4161261438
    x[535]    c670      -1
    x[535]    c671      1
    x[535]    c2440     -1
    x[535]    c3400     -1
    x[535]    c3450     1
    x[535]    c3460     1
    x[535]    c3470     1
    x[535]    c3480     1
    x[535]    c3490     1
    x[535]    c3500     1
    x[535]    c3510     1
    x[535]    c3520     1
    x[535]    c3690     -1
    x[535]    c4720     2872
    x[535]    c4721     -2872
    x[535]    c4730     2872
    x[535]    c4731     -2872
    x[535]    c4834     1
    x[535]    c4840     1
    x[535]    OBJ       -121168.591824912
    x[536]    c679      -1
    x[536]    c680      1
    x[536]    c2500     -1
    x[536]    c3240     -1
    x[536]    c3470     -1
    x[536]    c3530     1
    x[536]    c3540     1
    x[536]    c3550     1
    x[536]    c3560     1
    x[536]    c3570     1
    x[536]    c3750     -1
    x[536]    c4720     2888
    x[536]    c4721     -2888
    x[536]    c4730     2888
    x[536]    c4731     -2888
    x[536]    OBJ       -93597.6857776085
    x[537]    c688      -1
    x[537]    c689      1
    x[537]    c2590     -1
    x[537]    c3310     -1
    x[537]    c3550     -1
    x[537]    c3580     1
    x[537]    c3590     1
    x[537]    c3600     1
    x[537]    c3610     1
    x[537]    c3620     1
    x[537]    c3840     -1
    x[537]    c4190     -1
    x[537]    c4720     2692
    x[537]    c4721     -2692
    x[537]    c4730     2692
    x[537]    c4731     -2692
    x[537]    OBJ       -44191.6650119906
    x[538]    c697      -1
    x[538]    c698      1
    x[538]    c2640     -1
    x[538]    c3360     -1
    x[538]    c3600     -1
    x[538]    c3890     -1
    x[538]    c4230     -1
    x[538]    c4720     1168
    x[538]    c4721     -1168
    x[538]    c4730     528
    x[538]    c4731     -528
    x[538]    OBJ       -8447.25632087609
    x[539]    c706      -1
    x[539]    c707      1
    x[539]    c3630     1
    x[539]    c3640     1
    x[539]    c3650     1
    x[539]    c3660     1
    x[539]    c3670     1
    x[539]    c4720     716
    x[539]    c4721     -716
    x[539]    c4730     716
    x[539]    c4731     -716
    x[539]    c4977     1
    x[539]    OBJ       -43539.8705427872
    x[540]    c715      -1
    x[540]    c716      1
    x[540]    c3650     -1
    x[540]    c3680     1
    x[540]    c3690     1
    x[540]    c3700     1
    x[540]    c3710     1
    x[540]    c3720     1
    x[540]    c3730     1
    x[540]    c4720     2864
    x[540]    c4721     -2864
    x[540]    c4730     2864
    x[540]    c4731     -2864
    x[540]    c4864     1
    x[540]    OBJ       -150694.881279827
    x[541]    c724      -1
    x[541]    c725      1
    x[541]    c2690     -1
    x[541]    c3410     -1
    x[541]    c3700     -1
    x[541]    c3740     1
    x[541]    c3750     1
    x[541]    c3760     1
    x[541]    c3770     1
    x[541]    c3780     1
    x[541]    c3790     1
    x[541]    c3800     1
    x[541]    c3810     1
    x[541]    c3820     1
    x[541]    c4720     2864
    x[541]    c4721     -2864
    x[541]    c4730     2864
    x[541]    c4731     -2864
    x[541]    c4773     1
    x[541]    c4780     1
    x[541]    c4781     1
    x[541]    c4782     1
    x[541]    c4783     1
    x[541]    OBJ       -152910.982475118
    x[542]    c733      -1
    x[542]    c734      1
    x[542]    c2770     -1
    x[542]    c3480     -1
    x[542]    c3760     -1
    x[542]    c3830     1
    x[542]    c3840     1
    x[542]    c3850     1
    x[542]    c3860     1
    x[542]    c3870     1
    x[542]    c3940     -1
    x[542]    c4280     -1
    x[542]    c4720     2865
    x[542]    c4721     -2865
    x[542]    c4730     2865
    x[542]    c4731     -2865
    x[542]    c4920     -1
    x[542]    OBJ       -146393.037783084
    x[543]    c742      -1
    x[543]    c743      1
    x[543]    c2850     -1
    x[543]    c3560     -1
    x[543]    c3850     -1
    x[543]    c3880     1
    x[543]    c3890     1
    x[543]    c3900     1
    x[543]    c3910     1
    x[543]    c3920     1
    x[543]    c4000     -1
    x[543]    c4340     -1
    x[543]    c4720     2686
    x[543]    c4721     -2686
    x[543]    c4730     2684
    x[543]    c4731     -2684
    x[543]    c4834     -1
    x[543]    OBJ       -86167.2288286898
    x[544]    c751      -1
    x[544]    c752      1
    x[544]    c1360     -1
    x[544]    c2900     -1
    x[544]    c3610     -1
    x[544]    c3900     -1
    x[544]    c4050     -1
    x[544]    c4390     -1
    x[544]    c4720     1152
    x[544]    c4721     -1152
    x[544]    c4730     624
    x[544]    c4731     -624
    x[544]    OBJ       -16874.9588076761
    x[545]    c760      -1
    x[545]    c761      1
    x[545]    c3710     -1
    x[545]    c3930     1
    x[545]    c3940     1
    x[545]    c3950     1
    x[545]    c3960     1
    x[545]    c3970     1
    x[545]    c3980     1
    x[545]    c4720     1432
    x[545]    c4721     -1432
    x[545]    c4730     1432
    x[545]    c4731     -1432
    x[545]    OBJ       -77433.1829413641
    x[546]    c769      -1
    x[546]    c770      1
    x[546]    c2940     -1
    x[546]    c3770     -1
    x[546]    c3950     -1
    x[546]    c3990     1
    x[546]    c4000     1
    x[546]    c4010     1
    x[546]    c4020     1
    x[546]    c4030     1
    x[546]    c4440     -1
    x[546]    c4720     2864
    x[546]    c4721     -2864
    x[546]    c4730     2864
    x[546]    c4731     -2864
    x[546]    OBJ       -111130.95699918
    x[547]    c778      -1
    x[547]    c779      1
    x[547]    c3020     -1
    x[547]    c3860     -1
    x[547]    c4010     -1
    x[547]    c4040     1
    x[547]    c4050     1
    x[547]    c4060     1
    x[547]    c4070     1
    x[547]    c4080     1
    x[547]    c4490     -1
    x[547]    c4720     2684
    x[547]    c4721     -2684
    x[547]    c4730     2680
    x[547]    c4731     -2680
    x[547]    c4961     -1
    x[547]    OBJ       -77628.7212821252
    x[548]    c787      -1
    x[548]    c788      1
    x[548]    c1530     -1
    x[548]    c3070     -1
    x[548]    c3910     -1
    x[548]    c4060     -1
    x[548]    c4100     -1
    x[548]    c4540     -1
    x[548]    c4720     1099
    x[548]    c4721     -1099
    x[548]    c4730     672
    x[548]    c4731     -672
    x[548]    c4868     -1
    x[548]    OBJ       -24135.949194602
    x[549]    c796      -1
    x[549]    c797      1
    x[549]    c4020     -1
    x[549]    c4090     1
    x[549]    c4100     1
    x[549]    c4110     1
    x[549]    c4120     1
    x[549]    c4130     1
    x[549]    c4720     1342
    x[549]    c4721     -1342
    x[549]    c4730     1340
    x[549]    c4731     -1340
    x[549]    c4781     -1
    x[549]    OBJ       -18380.6040315359
    x[550]    c805      -1
    x[550]    c806      1
    x[550]    c1700     -1
    x[550]    c3120     -1
    x[550]    c4070     -1
    x[550]    c4110     -1
    x[550]    c4590     -1
    x[550]    c4720     880
    x[550]    c4721     -880
    x[550]    c4730     629
    x[550]    c4731     -629
    x[550]    OBJ       -14124.3861476377
    x[551]    c814      -1
    x[551]    c815      1
    x[551]    c4120     -1
    x[551]    c4720     326
    x[551]    c4721     -326
    x[551]    c4730     256
    x[551]    c4731     -256
    x[551]    OBJ       -5220.87369831926
    x[552]    c823      -1
    x[552]    c824      1
    x[552]    c2530     -1
    x[552]    c3200     -1
    x[552]    c4150     -1
    x[552]    c4720     360
    x[552]    c4721     -360
    x[552]    OBJ       702.634437801267
    x[553]    c832      -1
    x[553]    c833      1
    x[553]    c2710     -1
    x[553]    c3320     -1
    x[553]    c4140     1
    x[553]    c4150     1
    x[553]    c4160     1
    x[553]    c4170     1
    x[553]    c4180     1
    x[553]    c4200     -1
    x[553]    c4720     1346
    x[553]    c4721     -1346
    x[553]    c4730     1322
    x[553]    c4731     -1322
    x[553]    OBJ       -8375.55892926372
    x[554]    c841      -1
    x[554]    c842      1
    x[554]    c2790     -1
    x[554]    c3370     -1
    x[554]    c4160     -1
    x[554]    c4240     -1
    x[554]    c4720     689
    x[554]    c4721     -689
    x[554]    c4730     241
    x[554]    c4731     -241
    x[554]    OBJ       -3403.67071818016
    x[555]    c850      -1
    x[555]    c851      1
    x[555]    c3490     -1
    x[555]    c4190     1
    x[555]    c4200     1
    x[555]    c4210     1
    x[555]    c4220     1
    x[555]    c4290     -1
    x[555]    c4720     1448
    x[555]    c4721     -1448
    x[555]    c4730     1448
    x[555]    c4731     -1448
    x[555]    OBJ       -32003.108437887
    x[556]    c859      -1
    x[556]    c860      1
    x[556]    c3570     -1
    x[556]    c4210     -1
    x[556]    c4230     1
    x[556]    c4240     1
    x[556]    c4250     1
    x[556]    c4260     1
    x[556]    c4270     1
    x[556]    c4350     -1
    x[556]    c4720     2692
    x[556]    c4721     -2692
    x[556]    c4730     2668
    x[556]    c4731     -2668
    x[556]    OBJ       -18537.0347041448
    x[557]    c868      -1
    x[557]    c869      1
    x[557]    c1990     -1
    x[557]    c2960     -1
    x[557]    c3620     -1
    x[557]    c4170     -1
    x[557]    c4250     -1
    x[557]    c4400     -1
    x[557]    c4720     828
    x[557]    c4721     -828
    x[557]    c4730     291
    x[557]    c4731     -291
    x[557]    c4782     -1
    x[557]    OBJ       -2850.94900829568
    x[558]    c877      -1
    x[558]    c878      1
    x[558]    c3720     -1
    x[558]    c4280     1
    x[558]    c4290     1
    x[558]    c4300     1
    x[558]    c4310     1
    x[558]    c4320     1
    x[558]    c4330     1
    x[558]    c4720     1432
    x[558]    c4721     -1432
    x[558]    c4730     1432
    x[558]    c4731     -1432
    x[558]    OBJ       -75803.6967683557
    x[559]    c886      -1
    x[559]    c887      1
    x[559]    c3780     -1
    x[559]    c4300     -1
    x[559]    c4340     1
    x[559]    c4350     1
    x[559]    c4360     1
    x[559]    c4370     1
    x[559]    c4380     1
    x[559]    c4450     -1
    x[559]    c4720     2880
    x[559]    c4721     -2880
    x[559]    c4730     2880
    x[559]    c4731     -2880
    x[559]    OBJ       -115106.903261321
    x[560]    c895      -1
    x[560]    c896      1
    x[560]    c2160     -1
    x[560]    c3870     -1
    x[560]    c4220     -1
    x[560]    c4360     -1
    x[560]    c4390     1
    x[560]    c4400     1
    x[560]    c4410     1
    x[560]    c4420     1
    x[560]    c4430     1
    x[560]    c4500     -1
    x[560]    c4720     2691
    x[560]    c4721     -2691
    x[560]    c4730     2691
    x[560]    c4731     -2691
    x[560]    OBJ       -39172.8475991245
    x[561]    c904      -1
    x[561]    c905      1
    x[561]    c2230     -1
    x[561]    c3920     -1
    x[561]    c4260     -1
    x[561]    c4410     -1
    x[561]    c4550     -1
    x[561]    c4640     -1
    x[561]    c4720     840
    x[561]    c4721     -840
    x[561]    c4730     543
    x[561]    c4731     -543
    x[561]    OBJ       -11432.4749898277
    x[562]    c913      -1
    x[562]    c914      1
    x[562]    c4440     1
    x[562]    c4450     1
    x[562]    c4460     1
    x[562]    c4470     1
    x[562]    c4480     1
    x[562]    c4720     716
    x[562]    c4721     -716
    x[562]    c4730     716
    x[562]    c4731     -716
    x[562]    OBJ       -38521.0531299211
    x[563]    c922      -1
    x[563]    c923      1
    x[563]    c2380     -1
    x[563]    c3960     -1
    x[563]    c4310     -1
    x[563]    c4460     -1
    x[563]    c4490     1
    x[563]    c4500     1
    x[563]    c4510     1
    x[563]    c4520     1
    x[563]    c4530     1
    x[563]    c4720     2148
    x[563]    c4721     -2148
    x[563]    c4730     2148
    x[563]    c4731     -2148
    x[563]    OBJ       -97769.1703805104
    x[564]    c931      -1
    x[564]    c932      1
    x[564]    c2450     -1
    x[564]    c4030     -1
    x[564]    c4370     -1
    x[564]    c4510     -1
    x[564]    c4540     1
    x[564]    c4550     1
    x[564]    c4560     1
    x[564]    c4570     1
    x[564]    c4580     1
    x[564]    c4720     2684
    x[564]    c4721     -2684
    x[564]    c4730     2680
    x[564]    c4731     -2680
    x[564]    OBJ       -86167.2288286898
    x[565]    c940      -1
    x[565]    c941      1
    x[565]    c2540     -1
    x[565]    c4080     -1
    x[565]    c4420     -1
    x[565]    c4560     -1
    x[565]    c4600     -1
    x[565]    c4680     -1
    x[565]    c4720     841
    x[565]    c4721     -841
    x[565]    c4730     480
    x[565]    c4731     -480
    x[565]    c4783     -1
    x[565]    OBJ       -20277.3259369179
    x[566]    c949      -1
    x[566]    c950      1
    x[566]    c2720     -1
    x[566]    c4520     -1
    x[566]    c4590     1
    x[566]    c4600     1
    x[566]    c4610     1
    x[566]    c4620     1
    x[566]    c4630     1
    x[566]    c4720     671
    x[566]    c4721     -671
    x[566]    c4730     670
    x[566]    c4731     -670
    x[566]    OBJ       -15382.3494732003
    x[567]    c958      -1
    x[567]    c959      1
    x[567]    c2800     -1
    x[567]    c4130     -1
    x[567]    c4570     -1
    x[567]    c4610     -1
    x[567]    c4720     754
    x[567]    c4721     -754
    x[567]    c4730     450
    x[567]    c4731     -450
    x[567]    OBJ       -17943.9017371697
    x[568]    c967      -1
    x[568]    c968      1
    x[568]    c2970     -1
    x[568]    c4620     -1
    x[568]    c4720     289
    x[568]    c4721     -289
    x[568]    c4730     186
    x[568]    c4731     -186
    x[568]    OBJ       -4777.65345926094
    x[569]    c976      -1
    x[569]    c977      1
    x[569]    c3810     -1
    x[569]    c4180     -1
    x[569]    c4720     150
    x[569]    c4721     -150
    x[569]    OBJ       293.307511141531
    x[570]    c985      -1
    x[570]    c986      1
    x[570]    c3980     -1
    x[570]    c4270     -1
    x[570]    c4650     -1
    x[570]    c4720     315
    x[570]    c4721     -315
    x[570]    c4730     52
    x[570]    c4731     -52
    x[570]    OBJ       -115.367621049002
    x[571]    c994      -1
    x[571]    c995      1
    x[571]    c4380     -1
    x[571]    c4640     1
    x[571]    c4650     1
    x[571]    c4660     1
    x[571]    c4670     1
    x[571]    c4720     1346
    x[571]    c4721     -1346
    x[571]    c4730     1322
    x[571]    c4731     -1322
    x[571]    OBJ       -12436.2384724009
    x[572]    c1003     -1
    x[572]    c1004     1
    x[572]    c3270     -1
    x[572]    c4430     -1
    x[572]    c4660     -1
    x[572]    c4690     -1
    x[572]    c4720     548
    x[572]    c4721     -548
    x[572]    c4730     133
    x[572]    c4731     -133
    x[572]    OBJ       -1866.08756532934
    x[573]    c1012     -1
    x[573]    c1013     1
    x[573]    c3440     -1
    x[573]    c4530     -1
    x[573]    c4680     1
    x[573]    c4690     1
    x[573]    c4700     1
    x[573]    c4710     1
    x[573]    c4720     672
    x[573]    c4721     -672
    x[573]    c4730     672
    x[573]    c4731     -672
    x[573]    OBJ       -10950.1470826172
    x[574]    c1021     -1
    x[574]    c1022     1
    x[574]    c3520     -1
    x[574]    c4580     -1
    x[574]    c4670     -1
    x[574]    c4700     -1
    x[574]    c4720     429
    x[574]    c4721     -429
    x[574]    c4730     142
    x[574]    c4731     -142
    x[574]    OBJ       -3949.87448337262
    x[575]    c1030     -1
    x[575]    c1031     1
    x[575]    c3820     -1
    x[575]    c4630     -1
    x[575]    c4710     -1
    x[575]    c4720     273
    x[575]    c4721     -273
    x[575]    c4730     94
    x[575]    c4731     -94
    x[575]    OBJ       -3676.12080630719
    x[576]    c5        -1
    x[576]    c6        1
    x[576]    c2391     -1
    x[576]    c4721     219
    x[576]    c4722     -219
    x[576]    c4731     75
    x[576]    c4732     -75
    x[576]    OBJ       -1237.27366860903
    x[577]    c14       -1
    x[577]    c15       1
    x[577]    c1341     -1
    x[577]    c4721     328
    x[577]    c4722     -328
    x[577]    c4731     215
    x[577]    c4732     -215
    x[577]    OBJ       -2525.39420031158
    x[578]    c23       -1
    x[578]    c24       1
    x[578]    c1511     -1
    x[578]    c3671     -1
    x[578]    c4721     545
    x[578]    c4722     -545
    x[578]    c4731     368
    x[578]    c4732     -368
    x[578]    OBJ       -5768.2941353873
    x[579]    c32       -1
    x[579]    c33       1
    x[579]    c1071     -1
    x[579]    c1681     -1
    x[579]    c4721     435
    x[579]    c4722     -435
    x[579]    c4731     400
    x[579]    c4732     -400
    x[579]    OBJ       -8796.50731517927
    x[580]    c41       -1
    x[580]    c42       1
    x[580]    c1121     -1
    x[580]    c4721     247
    x[580]    c4722     -247
    x[580]    c4731     216
    x[580]    c4732     -216
    x[580]    OBJ       -3920.85810965602
    x[581]    c50       -1
    x[581]    c51       1
    x[581]    c1971     -1
    x[581]    c4721     82
    x[581]    c4722     -82
    x[581]    c4731     27
    x[581]    c4732     -27
    x[581]    OBJ       -411.859591057526
    x[582]    c59       -1
    x[582]    c60       1
    x[582]    c1081     -1
    x[582]    c1241     -1
    x[582]    c2511     -1
    x[582]    c4721     526
    x[582]    c4722     -526
    x[582]    c4731     314
    x[582]    c4732     -314
    x[582]    OBJ       -3816.33955774155
    x[583]    c68       -1
    x[583]    c69       1
    x[583]    c1041     1
    x[583]    c1051     1
    x[583]    c1061     1
    x[583]    c1291     -1
    x[583]    c4721     693
    x[583]    c4722     -693
    x[583]    c4731     693
    x[583]    c4732     -693
    x[583]    OBJ       -29208.6980215008
    x[584]    c77       -1
    x[584]    c78       1
    x[584]    c1041     -1
    x[584]    c1071     1
    x[584]    c1081     1
    x[584]    c1091     1
    x[584]    c1101     1
    x[584]    c1111     1
    x[584]    c1371     -1
    x[584]    c2701     -1
    x[584]    c4721     1944
    x[584]    c4722     -1944
    x[584]    c4731     1944
    x[584]    c4732     -1944
    x[584]    OBJ       -43671.8057458804
    x[585]    c86       -1
    x[585]    c87       1
    x[585]    c1091     -1
    x[585]    c1131     -1
    x[585]    c1421     -1
    x[585]    c2781     -1
    x[585]    c4721     907
    x[585]    c4722     -907
    x[585]    c4731     574
    x[585]    c4732     -574
    x[585]    c4946     -1
    x[585]    OBJ       -12643.9199559224
    x[586]    c95       -1
    x[586]    c96       1
    x[586]    c1051     -1
    x[586]    c1121     1
    x[586]    c1131     1
    x[586]    c1141     1
    x[586]    c1151     1
    x[586]    c1161     1
    x[586]    c1541     -1
    x[586]    c4721     1296
    x[586]    c4722     -1296
    x[586]    c4731     1128
    x[586]    c4732     -1128
    x[586]    OBJ       -13923.0010452972
    x[587]    c104      -1
    x[587]    c105      1
    x[587]    c1101     -1
    x[587]    c1141     -1
    x[587]    c1171     -1
    x[587]    c1591     -1
    x[587]    c1981     -1
    x[587]    c2951     -1
    x[587]    c4721     1043
    x[587]    c4722     -1043
    x[587]    c4731     864
    x[587]    c4732     -864
    x[587]    OBJ       -11561.4467371759
    x[588]    c113      -1
    x[588]    c114      1
    x[588]    c1171     1
    x[588]    c1181     1
    x[588]    c1191     1
    x[588]    c1201     1
    x[588]    c1711     -1
    x[588]    c2151     -1
    x[588]    c4721     1332
    x[588]    c4722     -1332
    x[588]    c4731     1330
    x[588]    c4732     -1330
    x[588]    OBJ       -26496.8653231797
    x[589]    c122      -1
    x[589]    c123      1
    x[589]    c1151     -1
    x[589]    c1181     -1
    x[589]    c1761     -1
    x[589]    c2221     -1
    x[589]    c4721     1186
    x[589]    c4722     -1186
    x[589]    c4731     864
    x[589]    c4732     -864
    x[589]    OBJ       -16033.7108288239
    x[590]    c131      -1
    x[590]    c132      1
    x[590]    c1191     -1
    x[590]    c1841     -1
    x[590]    c2521     -1
    x[590]    c4721     984
    x[590]    c4722     -984
    x[590]    c4731     723
    x[590]    c4732     -723
    x[590]    c4995     -1
    x[590]    OBJ       -7960.35889986358
    x[591]    c140      -1
    x[591]    c141      1
    x[591]    c1251     -1
    x[591]    c1891     -1
    x[591]    c3251     -1
    x[591]    c4721     225
    x[591]    c4722     -225
    x[591]    c4731     20
    x[591]    c4732     -20
    x[591]    OBJ       32.2030132925638
    x[592]    c149      -1
    x[592]    c150      1
    x[592]    c1211     1
    x[592]    c1221     1
    x[592]    c1231     1
    x[592]    c1301     -1
    x[592]    c1931     -1
    x[592]    c4721     724
    x[592]    c4722     -724
    x[592]    c4731     724
    x[592]    c4732     -724
    x[592]    OBJ       -21751.1581011176
    x[593]    c158      -1
    x[593]    c159      1
    x[593]    c1211     -1
    x[593]    c1241     1
    x[593]    c1251     1
    x[593]    c1261     1
    x[593]    c1271     1
    x[593]    c1281     1
    x[593]    c1381     -1
    x[593]    c2001     -1
    x[593]    c3421     -1
    x[593]    c4721     1989
    x[593]    c4722     -1989
    x[593]    c4731     1989
    x[593]    c4732     -1989
    x[593]    OBJ       -18858.5365562417
    x[594]    c167      -1
    x[594]    c168      1
    x[594]    c1261     -1
    x[594]    c1431     -1
    x[594]    c2051     -1
    x[594]    c3501     -1
    x[594]    c4721     710
    x[594]    c4722     -710
    x[594]    c4731     382
    x[594]    c4732     -382
    x[594]    OBJ       -5276.7744588166
    x[595]    c176      -1
    x[595]    c177      1
    x[595]    c1291     1
    x[595]    c1301     1
    x[595]    c1311     1
    x[595]    c1321     1
    x[595]    c1331     1
    x[595]    c1341     1
    x[595]    c1351     1
    x[595]    c1361     1
    x[595]    c2101     -1
    x[595]    c4721     716
    x[595]    c4722     -716
    x[595]    c4731     716
    x[595]    c4732     -716
    x[595]    c4761     1
    x[595]    OBJ       -32937.4679816925
    x[596]    c185      -1
    x[596]    c186      1
    x[596]    c1311     -1
    x[596]    c1371     1
    x[596]    c1381     1
    x[596]    c1391     1
    x[596]    c1401     1
    x[596]    c1411     1
    x[596]    c1471     -1
    x[596]    c2171     -1
    x[596]    c3661     -1
    x[596]    c4721     2876
    x[596]    c4722     -2876
    x[596]    c4731     2876
    x[596]    c4732     -2876
    x[596]    OBJ       -104179.572827171
    x[597]    c194      -1
    x[597]    c195      1
    x[597]    c1061     -1
    x[597]    c1221     -1
    x[597]    c1391     -1
    x[597]    c1421     1
    x[597]    c1431     1
    x[597]    c1441     1
    x[597]    c1451     1
    x[597]    c1461     1
    x[597]    c1551     -1
    x[597]    c2241     -1
    x[597]    c3731     -1
    x[597]    c4721     2595
    x[597]    c4722     -2595
    x[597]    c4731     2595
    x[597]    c4732     -2595
    x[597]    c4821     -1
    x[597]    c4823     -1
    x[597]    OBJ       -22287.874989327
    x[598]    c203      -1
    x[598]    c204      1
    x[598]    c1111     -1
    x[598]    c1271     -1
    x[598]    c1441     -1
    x[598]    c1601     -1
    x[598]    c2291     -1
    x[598]    c3791     -1
    x[598]    c4721     1030
    x[598]    c4722     -1030
    x[598]    c4731     552
    x[598]    c4732     -552
    x[598]    c4989     -1
    x[598]    OBJ       -2983.01596815328
    x[599]    c212      -1
    x[599]    c213      1
    x[599]    c1471     1
    x[599]    c1481     1
    x[599]    c1491     1
    x[599]    c1501     1
    x[599]    c1511     1
    x[599]    c1521     1
    x[599]    c1531     1
    x[599]    c2401     -1
    x[599]    c4721     1432
    x[599]    c4722     -1432
    x[599]    c4731     1432
    x[599]    c4732     -1432
    x[599]    OBJ       -61072.7322267745
    x[600]    c221      -1
    x[600]    c222      1
    x[600]    c1321     -1
    x[600]    c1481     -1
    x[600]    c1541     1
    x[600]    c1551     1
    x[600]    c1561     1
    x[600]    c1571     1
    x[600]    c1581     1
    x[600]    c1641     -1
    x[600]    c2461     -1
    x[600]    c4721     2864
    x[600]    c4722     -2864
    x[600]    c4731     2864
    x[600]    c4732     -2864
    x[600]    OBJ       -83671.3380461175
    x[601]    c230      -1
    x[601]    c231      1
    x[601]    c1401     -1
    x[601]    c1561     -1
    x[601]    c1591     1
    x[601]    c1601     1
    x[601]    c1611     1
    x[601]    c1621     1
    x[601]    c1631     1
    x[601]    c1721     -1
    x[601]    c2551     -1
    x[601]    c4721     2600
    x[601]    c4722     -2600
    x[601]    c4731     2336
    x[601]    c4732     -2336
    x[601]    c4938     -1
    x[601]    OBJ       -31943.1293256413
    x[602]    c239      -1
    x[602]    c240      1
    x[602]    c1161     -1
    x[602]    c1451     -1
    x[602]    c1611     -1
    x[602]    c1771     -1
    x[602]    c2601     -1
    x[602]    c3971     -1
    x[602]    c4721     1156
    x[602]    c4722     -1156
    x[602]    c4731     696
    x[602]    c4732     -696
    x[602]    c4853     -1
    x[602]    OBJ       -7406.69305728967
    x[603]    c248      -1
    x[603]    c249      1
    x[603]    c1641     1
    x[603]    c1651     1
    x[603]    c1661     1
    x[603]    c1671     1
    x[603]    c1681     1
    x[603]    c1691     1
    x[603]    c1701     1
    x[603]    c2651     -1
    x[603]    c4721     716
    x[603]    c4722     -716
    x[603]    c4731     716
    x[603]    c4732     -716
    x[603]    c4764     1
    x[603]    OBJ       -30564.6143706614
    x[604]    c257      -1
    x[604]    c258      1
    x[604]    c1491     -1
    x[604]    c1651     -1
    x[604]    c1711     1
    x[604]    c1721     1
    x[604]    c1731     1
    x[604]    c1741     1
    x[604]    c1751     1
    x[604]    c2731     -1
    x[604]    c4721     2864
    x[604]    c4722     -2864
    x[604]    c4731     2864
    x[604]    c4732     -2864
    x[604]    OBJ       -94857.6479266923
    x[605]    c266      -1
    x[605]    c267      1
    x[605]    c1571     -1
    x[605]    c1731     -1
    x[605]    c1761     1
    x[605]    c1771     1
    x[605]    c1781     1
    x[605]    c1791     1
    x[605]    c1801     1
    x[605]    c1811     -1
    x[605]    c2811     -1
    x[605]    c4721     2681
    x[605]    c4722     -2681
    x[605]    c4731     2678
    x[605]    c4732     -2678
    x[605]    OBJ       -88360.5487536312
    x[606]    c275      -1
    x[606]    c276      1
    x[606]    c1201     -1
    x[606]    c1621     -1
    x[606]    c1781     -1
    x[606]    c1851     -1
    x[606]    c2861     -1
    x[606]    c3261     -1
    x[606]    c4721     1263
    x[606]    c4722     -1263
    x[606]    c4731     864
    x[606]    c4732     -864
    x[606]    c4990     -1
    x[606]    OBJ       -31920.530719822
    x[607]    c284      -1
    x[607]    c285      1
    x[607]    c1661     -1
    x[607]    c1811     1
    x[607]    c1821     1
    x[607]    c1831     1
    x[607]    c2911     -1
    x[607]    c4721     716
    x[607]    c4722     -716
    x[607]    c4731     716
    x[607]    c4732     -716
    x[607]    OBJ       -20677.7243246989
    x[608]    c293      -1
    x[608]    c294      1
    x[608]    c1741     -1
    x[608]    c1821     -1
    x[608]    c1841     1
    x[608]    c1851     1
    x[608]    c1861     1
    x[608]    c1871     1
    x[608]    c1881     1
    x[608]    c2981     -1
    x[608]    c3431     -1
    x[608]    c4721     1965
    x[608]    c4722     -1965
    x[608]    c4731     1964
    x[608]    c4732     -1964
    x[608]    OBJ       -36835.7274855291
    x[609]    c302      -1
    x[609]    c303      1
    x[609]    c1791     -1
    x[609]    c1861     -1
    x[609]    c3031     -1
    x[609]    c3511     -1
    x[609]    c4721     1245
    x[609]    c4722     -1245
    x[609]    c4731     889
    x[609]    c4732     -889
    x[609]    c4949     -1
    x[609]    OBJ       -17892.4461574648
    x[610]    c311      -1
    x[610]    c312      1
    x[610]    c1871     -1
    x[610]    c3081     -1
    x[610]    c3801     -1
    x[610]    c4721     832
    x[610]    c4722     -832
    x[610]    c4731     647
    x[610]    c4732     -647
    x[610]    OBJ       -5363.77909122106
    x[611]    c320      -1
    x[611]    c321      1
    x[611]    c4721     339
    x[611]    c4722     -339
    x[611]    c4731     283
    x[611]    c4732     -283
    x[611]    OBJ       -3158.15516325318
    x[612]    c329      -1
    x[612]    c330      1
    x[612]    c1891     1
    x[612]    c1901     1
    x[612]    c1911     1
    x[612]    c1921     1
    x[612]    c2011     -1
    x[612]    c4721     1346
    x[612]    c4722     -1346
    x[612]    c4731     1346
    x[612]    c4732     -1346
    x[612]    OBJ       -25931.9001776961
    x[613]    c338      -1
    x[613]    c339      1
    x[613]    c1901     -1
    x[613]    c2061     -1
    x[613]    c4721     243
    x[613]    c4722     -243
    x[613]    OBJ       410.616667737462
    x[614]    c347      -1
    x[614]    c348      1
    x[614]    c1931     1
    x[614]    c1941     1
    x[614]    c1951     1
    x[614]    c1961     1
    x[614]    c1971     1
    x[614]    c1981     1
    x[614]    c1991     1
    x[614]    c2111     -1
    x[614]    c4721     724
    x[614]    c4722     -724
    x[614]    c4731     724
    x[614]    c4732     -724
    x[614]    OBJ       -29773.6631669844
    x[615]    c356      -1
    x[615]    c357      1
    x[615]    c1941     -1
    x[615]    c2001     1
    x[615]    c2011     1
    x[615]    c2021     1
    x[615]    c2031     1
    x[615]    c2041     1
    x[615]    c2181     -1
    x[615]    c4721     2896
    x[615]    c4722     -2896
    x[615]    c4731     2896
    x[615]    c4732     -2896
    x[615]    OBJ       -92089.3187138228
    x[616]    c365      -1
    x[616]    c366      1
    x[616]    c1231     -1
    x[616]    c2021     -1
    x[616]    c2051     1
    x[616]    c2061     1
    x[616]    c2071     1
    x[616]    c2081     1
    x[616]    c2091     1
    x[616]    c2251     -1
    x[616]    c3131     -1
    x[616]    c4721     2692
    x[616]    c4722     -2692
    x[616]    c4731     2692
    x[616]    c4732     -2692
    x[616]    OBJ       -46044.6593569114
    x[617]    c374      -1
    x[617]    c375      1
    x[617]    c1281     -1
    x[617]    c1911     -1
    x[617]    c2071     -1
    x[617]    c2301     -1
    x[617]    c3161     -1
    x[617]    c4721     755
    x[617]    c4722     -755
    x[617]    c4731     323
    x[617]    c4732     -323
    x[617]    c4944     -1
    x[617]    OBJ       -3885.26530549055
    x[618]    c383      -1
    x[618]    c384      1
    x[618]    c2101     1
    x[618]    c2111     1
    x[618]    c2121     1
    x[618]    c2131     1
    x[618]    c2141     1
    x[618]    c2151     1
    x[618]    c2161     1
    x[618]    c2341     -1
    x[618]    c4721     1432
    x[618]    c4722     -1432
    x[618]    c4731     1432
    x[618]    c4732     -1432
    x[618]    OBJ       -62880.620692322
    x[619]    c392      -1
    x[619]    c393      1
    x[619]    c2121     -1
    x[619]    c2171     1
    x[619]    c2181     1
    x[619]    c2191     1
    x[619]    c2201     1
    x[619]    c2211     1
    x[619]    c2221     1
    x[619]    c2231     1
    x[619]    c2411     -1
    x[619]    c4721     2886
    x[619]    c4722     -2886
    x[619]    c4731     2886
    x[619]    c4732     -2886
    x[619]    c4762     1
    x[619]    OBJ       -118473.191007906
    x[620]    c401      -1
    x[620]    c402      1
    x[620]    c1331     -1
    x[620]    c1951     -1
    x[620]    c2191     -1
    x[620]    c2241     1
    x[620]    c2251     1
    x[620]    c2261     1
    x[620]    c2271     1
    x[620]    c2281     1
    x[620]    c2471     -1
    x[620]    c3211     -1
    x[620]    c4721     2895
    x[620]    c4722     -2895
    x[620]    c4731     2895
    x[620]    c4732     -2895
    x[620]    c4914     1
    x[620]    c4917     1
    x[620]    OBJ       -98586.4178868838
    x[621]    c410      -1
    x[621]    c411      1
    x[621]    c1411     -1
    x[621]    c2031     -1
    x[621]    c2261     -1
    x[621]    c2291     1
    x[621]    c2301     1
    x[621]    c2311     1
    x[621]    c2321     1
    x[621]    c2331     1
    x[621]    c2561     -1
    x[621]    c3281     -1
    x[621]    c4721     2692
    x[621]    c4722     -2692
    x[621]    c4731     2668
    x[621]    c4732     -2668
    x[621]    OBJ       -38700.1124656249
    x[622]    c419      -1
    x[622]    c420      1
    x[622]    c1461     -1
    x[622]    c2081     -1
    x[622]    c2311     -1
    x[622]    c2611     -1
    x[622]    c3331     -1
    x[622]    c4321     -1
    x[622]    c4721     1115
    x[622]    c4722     -1115
    x[622]    c4731     408
    x[622]    c4732     -408
    x[622]    c4991     -1
    x[622]    OBJ       -2849.11922867367
    x[623]    c428      -1
    x[623]    c429      1
    x[623]    c2341     1
    x[623]    c2351     1
    x[623]    c2361     1
    x[623]    c2371     1
    x[623]    c2381     1
    x[623]    c2391     1
    x[623]    c4721     1432
    x[623]    c4722     -1432
    x[623]    c4731     1432
    x[623]    c4732     -1432
    x[623]    c4881     1
    x[623]    OBJ       -71750.5734764141
    x[624]    c437      -1
    x[624]    c438      1
    x[624]    c2351     -1
    x[624]    c2401     1
    x[624]    c2411     1
    x[624]    c2421     1
    x[624]    c2431     1
    x[624]    c2441     1
    x[624]    c2451     1
    x[624]    c4721     2864
    x[624]    c4722     -2864
    x[624]    c4731     2864
    x[624]    c4732     -2864
    x[624]    OBJ       -131297.899810383
    x[625]    c446      -1
    x[625]    c447      1
    x[625]    c2131     -1
    x[625]    c2421     -1
    x[625]    c2461     1
    x[625]    c2471     1
    x[625]    c2481     1
    x[625]    c2491     1
    x[625]    c2501     1
    x[625]    c2511     1
    x[625]    c2521     1
    x[625]    c2531     1
    x[625]    c2541     1
    x[625]    c2661     -1
    x[625]    c3381     -1
    x[625]    c4721     2864
    x[625]    c4722     -2864
    x[625]    c4731     2864
    x[625]    c4732     -2864
    x[625]    c4938     1
    x[625]    c4944     1
    x[625]    c4945     1
    x[625]    c4946     1
    x[625]    c4949     1
    x[625]    OBJ       -124009.849433645
    x[626]    c455      -1
    x[626]    c456      1
    x[626]    c1501     -1
    x[626]    c2201     -1
    x[626]    c2481     -1
    x[626]    c2551     1
    x[626]    c2561     1
    x[626]    c2571     1
    x[626]    c2581     1
    x[626]    c2591     1
    x[626]    c2741     -1
    x[626]    c3451     -1
    x[626]    c4721     2873
    x[626]    c4722     -2873
    x[626]    c4731     2873
    x[626]    c4732     -2873
    x[626]    OBJ       -95366.1165576275
    x[627]    c464      -1
    x[627]    c465      1
    x[627]    c1581     -1
    x[627]    c2271     -1
    x[627]    c2571     -1
    x[627]    c2601     1
    x[627]    c2611     1
    x[627]    c2621     1
    x[627]    c2631     1
    x[627]    c2641     1
    x[627]    c2821     -1
    x[627]    c3531     -1
    x[627]    c4721     2679
    x[627]    c4722     -2679
    x[627]    c4731     2604
    x[627]    c4732     -2604
    x[627]    c4761     -1
    x[627]    c4762     -1
    x[627]    c4764     -1
    x[627]    OBJ       -33123.906479702
    x[628]    c473      -1
    x[628]    c474      1
    x[628]    c1631     -1
    x[628]    c2321     -1
    x[628]    c2621     -1
    x[628]    c2871     -1
    x[628]    c3581     -1
    x[628]    c4471     -1
    x[628]    c4721     1252
    x[628]    c4722     -1252
    x[628]    c4731     552
    x[628]    c4732     -552
    x[628]    c4914     -1
    x[628]    OBJ       -6527.04232577175
    x[629]    c482      -1
    x[629]    c483      1
    x[629]    c2361     -1
    x[629]    c2651     1
    x[629]    c2661     1
    x[629]    c2671     1
    x[629]    c2681     1
    x[629]    c2691     1
    x[629]    c2701     1
    x[629]    c2711     1
    x[629]    c2721     1
    x[629]    c3631     -1
    x[629]    c4721     2148
    x[629]    c4722     -2148
    x[629]    c4731     2148
    x[629]    c4732     -2148
    x[629]    c4821     1
    x[629]    OBJ       -87061.1289190189
    x[630]    c491      -1
    x[630]    c492      1
    x[630]    c2431     -1
    x[630]    c2671     -1
    x[630]    c2731     1
    x[630]    c2741     1
    x[630]    c2751     1
    x[630]    c2761     1
    x[630]    c2771     1
    x[630]    c2781     1
    x[630]    c2791     1
    x[630]    c2801     1
    x[630]    c3681     -1
    x[630]    c4721     2864
    x[630]    c4722     -2864
    x[630]    c4731     2864
    x[630]    c4732     -2864
    x[630]    c4981     1
    x[630]    c4989     1
    x[630]    c4990     1
    x[630]    c4991     1
    x[630]    c4992     1
    x[630]    c4994     -1
    x[630]    c4995     1
    x[630]    OBJ       -113614.490756747
    x[631]    c500      -1
    x[631]    c501      1
    x[631]    c1671     -1
    x[631]    c2491     -1
    x[631]    c2751     -1
    x[631]    c2811     1
    x[631]    c2821     1
    x[631]    c2831     1
    x[631]    c2841     1
    x[631]    c2851     1
    x[631]    c2921     -1
    x[631]    c3741     -1
    x[631]    c4721     2864
    x[631]    c4722     -2864
    x[631]    c4731     2864
    x[631]    c4732     -2864
    x[631]    c4879     -1
    x[631]    c4881     -1
    x[631]    c4882     1
    x[631]    c4884     1
    x[631]    OBJ       -103953.586768978
    x[632]    c509      -1
    x[632]    c510      1
    x[632]    c1751     -1
    x[632]    c2581     -1
    x[632]    c2831     -1
    x[632]    c2861     1
    x[632]    c2871     1
    x[632]    c2881     1
    x[632]    c2891     1
    x[632]    c2901     1
    x[632]    c2991     -1
    x[632]    c3831     -1
    x[632]    c4721     2684
    x[632]    c4722     -2684
    x[632]    c4731     2680
    x[632]    c4732     -2680
    x[632]    c4792     -1
    x[632]    OBJ       -88360.5487536312
    x[633]    c518      -1
    x[633]    c519      1
    x[633]    c1801     -1
    x[633]    c2631     -1
    x[633]    c2881     -1
    x[633]    c3041     -1
    x[633]    c3881     -1
    x[633]    c4721     1253
    x[633]    c4722     -1253
    x[633]    c4731     840
    x[633]    c4732     -840
    x[633]    c4945     -1
    x[633]    OBJ       -24406.4942848904
    x[634]    c527      -1
    x[634]    c528      1
    x[634]    c2681     -1
    x[634]    c2911     1
    x[634]    c2921     1
    x[634]    c2931     1
    x[634]    c2941     1
    x[634]    c2951     1
    x[634]    c2961     1
    x[634]    c2971     1
    x[634]    c4721     716
    x[634]    c4722     -716
    x[634]    c4731     716
    x[634]    c4732     -716
    x[634]    OBJ       -32767.9784380473
    x[635]    c536      -1
    x[635]    c537      1
    x[635]    c2761     -1
    x[635]    c2931     -1
    x[635]    c2981     1
    x[635]    c2991     1
    x[635]    c3001     1
    x[635]    c3011     1
    x[635]    c3021     1
    x[635]    c3931     -1
    x[635]    c4721     2864
    x[635]    c4722     -2864
    x[635]    c4731     2864
    x[635]    c4732     -2864
    x[635]    OBJ       -91298.3675101458
    x[636]    c545      -1
    x[636]    c546      1
    x[636]    c1831     -1
    x[636]    c2841     -1
    x[636]    c3001     -1
    x[636]    c3031     1
    x[636]    c3041     1
    x[636]    c3051     1
    x[636]    c3061     1
    x[636]    c3071     1
    x[636]    c3991     -1
    x[636]    c4721     2651
    x[636]    c4722     -2651
    x[636]    c4731     2650
    x[636]    c4732     -2650
    x[636]    OBJ       -70281.6640981567
    x[637]    c554      -1
    x[637]    c555      1
    x[637]    c1881     -1
    x[637]    c2891     -1
    x[637]    c3051     -1
    x[637]    c3091     -1
    x[637]    c4041     -1
    x[637]    c4721     1175
    x[637]    c4722     -1175
    x[637]    c4731     768
    x[637]    c4732     -768
    x[637]    OBJ       -21547.7706487435
    x[638]    c563      -1
    x[638]    c564      1
    x[638]    c3011     -1
    x[638]    c3081     1
    x[638]    c3091     1
    x[638]    c3101     1
    x[638]    c3111     1
    x[638]    c3121     1
    x[638]    c4721     1333
    x[638]    c4722     -1333
    x[638]    c4731     1332
    x[638]    c4732     -1332
    x[638]    c4992     -1
    x[638]    OBJ       -24688.9768576323
    x[639]    c572      -1
    x[639]    c573      1
    x[639]    c3061     -1
    x[639]    c3101     -1
    x[639]    c4091     -1
    x[639]    c4331     -1
    x[639]    c4721     940
    x[639]    c4722     -940
    x[639]    c4731     728
    x[639]    c4732     -728
    x[639]    c4884     -1
    x[639]    OBJ       -16926.3557586879
    x[640]    c581      -1
    x[640]    c582      1
    x[640]    c3111     -1
    x[640]    c4481     -1
    x[640]    c4721     342
    x[640]    c4722     -342
    x[640]    c4731     317
    x[640]    c4732     -317
    x[640]    OBJ       -4180.74207657846
    x[641]    c590      -1
    x[641]    c591      1
    x[641]    c1351     -1
    x[641]    c1921     -1
    x[641]    c3171     -1
    x[641]    c4721     187
    x[641]    c4722     -187
    x[641]    OBJ       311.691270763288
    x[642]    c599      -1
    x[642]    c600      1
    x[642]    c1961     -1
    x[642]    c3131     1
    x[642]    c3141     1
    x[642]    c3151     1
    x[642]    c3221     -1
    x[642]    c4721     724
    x[642]    c4722     -724
    x[642]    c4731     724
    x[642]    c4732     -724
    x[642]    OBJ       -16722.9683063138
    x[643]    c608      -1
    x[643]    c609      1
    x[643]    c2041     -1
    x[643]    c3141     -1
    x[643]    c3161     1
    x[643]    c3171     1
    x[643]    c3181     1
    x[643]    c3191     1
    x[643]    c3201     1
    x[643]    c3291     -1
    x[643]    c4721     2019
    x[643]    c4722     -2019
    x[643]    c4731     1995
    x[643]    c4732     -1995
    x[643]    OBJ       -19592.9912453704
    x[644]    c617      -1
    x[644]    c618      1
    x[644]    c1521     -1
    x[644]    c2091     -1
    x[644]    c3181     -1
    x[644]    c3341     -1
    x[644]    c4721     660
    x[644]    c4722     -660
    x[644]    c4731     174
    x[644]    c4732     -174
    x[644]    c4917     -1
    x[644]    OBJ       -2263.2503728072
    x[645]    c626      -1
    x[645]    c627      1
    x[645]    c2141     -1
    x[645]    c3211     1
    x[645]    c3221     1
    x[645]    c3231     1
    x[645]    c3241     1
    x[645]    c3251     1
    x[645]    c3261     1
    x[645]    c3271     1
    x[645]    c3391     -1
    x[645]    c4721     1447
    x[645]    c4722     -1447
    x[645]    c4731     1447
    x[645]    c4732     -1447
    x[645]    c4823     1
    x[645]    OBJ       -49829.9258316513
    x[646]    c635      -1
    x[646]    c636      1
    x[646]    c2211     -1
    x[646]    c3231     -1
    x[646]    c3281     1
    x[646]    c3291     1
    x[646]    c3301     1
    x[646]    c3311     1
    x[646]    c3321     1
    x[646]    c3461     -1
    x[646]    c4721     2896
    x[646]    c4722     -2896
    x[646]    c4731     2896
    x[646]    c4732     -2896
    x[646]    OBJ       -67230.8523125455
    x[647]    c644      -1
    x[647]    c645      1
    x[647]    c2281     -1
    x[647]    c3151     -1
    x[647]    c3301     -1
    x[647]    c3331     1
    x[647]    c3341     1
    x[647]    c3351     1
    x[647]    c3361     1
    x[647]    c3371     1
    x[647]    c3541     -1
    x[647]    c4721     2692
    x[647]    c4722     -2692
    x[647]    c4731     2692
    x[647]    c4732     -2692
    x[647]    OBJ       -27423.4081617728
    x[648]    c653      -1
    x[648]    c654      1
    x[648]    c1691     -1
    x[648]    c2331     -1
    x[648]    c3191     -1
    x[648]    c3351     -1
    x[648]    c3591     -1
    x[648]    c4141     -1
    x[648]    c4721     964
    x[648]    c4722     -964
    x[648]    c4731     288
    x[648]    c4732     -288
    x[648]    c4797     -1
    x[648]    OBJ       -2206.18889311336
    x[649]    c662      -1
    x[649]    c663      1
    x[649]    c2371     -1
    x[649]    c3381     1
    x[649]    c3391     1
    x[649]    c3401     1
    x[649]    c3411     1
    x[649]    c3421     1
    x[649]    c3431     1
    x[649]    c3441     1
    x[649]    c3641     -1
    x[649]    c4721     1432
    x[649]    c4722     -1432
    x[649]    c4731     1432
    x[649]    c4732     -1432
    x[649]    c4942     1
    x[649]    OBJ       -63728.0684105473
    x[650]    c671      -1
    x[650]    c672      1
    x[650]    c2441     -1
    x[650]    c3401     -1
    x[650]    c3451     1
    x[650]    c3461     1
    x[650]    c3471     1
    x[650]    c3481     1
    x[650]    c3491     1
    x[650]    c3501     1
    x[650]    c3511     1
    x[650]    c3521     1
    x[650]    c3691     -1
    x[650]    c4721     2872
    x[650]    c4722     -2872
    x[650]    c4731     2872
    x[650]    c4732     -2872
    x[650]    c4848     1
    x[650]    c4853     1
    x[650]    OBJ       -105027.020545397
    x[651]    c680      -1
    x[651]    c681      1
    x[651]    c2501     -1
    x[651]    c3241     -1
    x[651]    c3471     -1
    x[651]    c3531     1
    x[651]    c3541     1
    x[651]    c3551     1
    x[651]    c3561     1
    x[651]    c3571     1
    x[651]    c3751     -1
    x[651]    c4721     2888
    x[651]    c4722     -2888
    x[651]    c4731     2888
    x[651]    c4732     -2888
    x[651]    OBJ       -81128.9948914414
    x[652]    c689      -1
    x[652]    c690      1
    x[652]    c2591     -1
    x[652]    c3311     -1
    x[652]    c3551     -1
    x[652]    c3581     1
    x[652]    c3591     1
    x[652]    c3601     1
    x[652]    c3611     1
    x[652]    c3621     1
    x[652]    c3841     -1
    x[652]    c4191     -1
    x[652]    c4721     2692
    x[652]    c4722     -2692
    x[652]    c4731     2692
    x[652]    c4732     -2692
    x[652]    OBJ       -38304.6368637864
    x[653]    c698      -1
    x[653]    c699      1
    x[653]    c2641     -1
    x[653]    c3361     -1
    x[653]    c3601     -1
    x[653]    c3891     -1
    x[653]    c4231     -1
    x[653]    c4721     1168
    x[653]    c4722     -1168
    x[653]    c4731     528
    x[653]    c4732     -528
    x[653]    OBJ       -7321.94828546714
    x[654]    c707      -1
    x[654]    c708      1
    x[654]    c3631     1
    x[654]    c3641     1
    x[654]    c3651     1
    x[654]    c3661     1
    x[654]    c3671     1
    x[654]    c4721     716
    x[654]    c4722     -716
    x[654]    c4731     716
    x[654]    c4732     -716
    x[654]    c4994     1
    x[654]    OBJ       -37739.6717183029
    x[655]    c716      -1
    x[655]    c717      1
    x[655]    c3651     -1
    x[655]    c3681     1
    x[655]    c3691     1
    x[655]    c3701     1
    x[655]    c3711     1
    x[655]    c3721     1
    x[655]    c3731     1
    x[655]    c4721     2864
    x[655]    c4722     -2864
    x[655]    c4731     2864
    x[655]    c4732     -2864
    x[655]    c4879     1
    x[655]    OBJ       -130619.941635803
    x[656]    c725      -1
    x[656]    c726      1
    x[656]    c2691     -1
    x[656]    c3411     -1
    x[656]    c3701     -1
    x[656]    c3741     1
    x[656]    c3751     1
    x[656]    c3761     1
    x[656]    c3771     1
    x[656]    c3781     1
    x[656]    c3791     1
    x[656]    c3801     1
    x[656]    c3811     1
    x[656]    c3821     1
    x[656]    c4721     2864
    x[656]    c4722     -2864
    x[656]    c4731     2864
    x[656]    c4732     -2864
    x[656]    c4792     1
    x[656]    c4797     1
    x[656]    c4798     1
    x[656]    c4799     1
    x[656]    c4800     1
    x[656]    OBJ       -132540.823130447
    x[657]    c734      -1
    x[657]    c735      1
    x[657]    c2771     -1
    x[657]    c3481     -1
    x[657]    c3761     -1
    x[657]    c3831     1
    x[657]    c3841     1
    x[657]    c3851     1
    x[657]    c3861     1
    x[657]    c3871     1
    x[657]    c3941     -1
    x[657]    c4281     -1
    x[657]    c4721     2865
    x[657]    c4722     -2865
    x[657]    c4731     2865
    x[657]    c4732     -2865
    x[657]    c4942     -1
    x[657]    OBJ       -126891.171675611
    x[658]    c743      -1
    x[658]    c744      1
    x[658]    c2851     -1
    x[658]    c3561     -1
    x[658]    c3851     -1
    x[658]    c3881     1
    x[658]    c3891     1
    x[658]    c3901     1
    x[658]    c3911     1
    x[658]    c3921     1
    x[658]    c4001     -1
    x[658]    c4341     -1
    x[658]    c4721     2686
    x[658]    c4722     -2686
    x[658]    c4731     2684
    x[658]    c4732     -2684
    x[658]    c4848     -1
    x[658]    OBJ       -74688.3922329286
    x[659]    c752      -1
    x[659]    c753      1
    x[659]    c1361     -1
    x[659]    c2901     -1
    x[659]    c3611     -1
    x[659]    c3901     -1
    x[659]    c4051     -1
    x[659]    c4391     -1
    x[659]    c4721     1152
    x[659]    c4722     -1152
    x[659]    c4731     624
    x[659]    c4732     -624
    x[659]    OBJ       -14626.9476165698
    x[660]    c761      -1
    x[660]    c762      1
    x[660]    c3711     -1
    x[660]    c3931     1
    x[660]    c3941     1
    x[660]    c3951     1
    x[660]    c3961     1
    x[660]    c3971     1
    x[660]    c3981     1
    x[660]    c4721     1432
    x[660]    c4722     -1432
    x[660]    c4731     1432
    x[660]    c4732     -1432
    x[660]    OBJ       -67117.8592834488
    x[661]    c770      -1
    x[661]    c771      1
    x[661]    c2941     -1
    x[661]    c3771     -1
    x[661]    c3951     -1
    x[661]    c3991     1
    x[661]    c4001     1
    x[661]    c4011     1
    x[661]    c4021     1
    x[661]    c4031     1
    x[661]    c4441     -1
    x[661]    c4721     2864
    x[661]    c4722     -2864
    x[661]    c4731     2864
    x[661]    c4732     -2864
    x[661]    OBJ       -96326.5573049496
    x[662]    c779      -1
    x[662]    c780      1
    x[662]    c3021     -1
    x[662]    c3861     -1
    x[662]    c4011     -1
    x[662]    c4041     1
    x[662]    c4051     1
    x[662]    c4061     1
    x[662]    c4071     1
    x[662]    c4081     1
    x[662]    c4491     -1
    x[662]    c4721     2684
    x[662]    c4722     -2684
    x[662]    c4731     2680
    x[662]    c4732     -2680
    x[662]    c4981     -1
    x[662]    OBJ       -67287.3488270938
    x[663]    c788      -1
    x[663]    c789      1
    x[663]    c1531     -1
    x[663]    c3071     -1
    x[663]    c3911     -1
    x[663]    c4061     -1
    x[663]    c4101     -1
    x[663]    c4541     -1
    x[663]    c4721     1099
    x[663]    c4722     -1099
    x[663]    c4731     672
    x[663]    c4732     -672
    x[663]    c4882     -1
    x[663]    OBJ       -20920.6593372568
    x[664]    c797      -1
    x[664]    c798      1
    x[664]    c4021     -1
    x[664]    c4091     1
    x[664]    c4101     1
    x[664]    c4111     1
    x[664]    c4121     1
    x[664]    c4131     1
    x[664]    c4721     1342
    x[664]    c4722     -1342
    x[664]    c4731     1340
    x[664]    c4732     -1340
    x[664]    c4798     -1
    x[664]    OBJ       -15932.0171026368
    x[665]    c806      -1
    x[665]    c807      1
    x[665]    c1701     -1
    x[665]    c3121     -1
    x[665]    c4071     -1
    x[665]    c4111     -1
    x[665]    c4591     -1
    x[665]    c4721     880
    x[665]    c4722     -880
    x[665]    c4731     629
    x[665]    c4732     -629
    x[665]    OBJ       -12242.7947026291
    x[666]    c815      -1
    x[666]    c816      1
    x[666]    c4121     -1
    x[666]    c4721     326
    x[666]    c4722     -326
    x[666]    c4731     256
    x[666]    c4732     -256
    x[666]    OBJ       -4525.37081532343
    x[667]    c824      -1
    x[667]    c825      1
    x[667]    c2531     -1
    x[667]    c3201     -1
    x[667]    c4151     -1
    x[667]    c4721     360
    x[667]    c4722     -360
    x[667]    OBJ       609.032426831294
    x[668]    c833      -1
    x[668]    c834      1
    x[668]    c2711     -1
    x[668]    c3321     -1
    x[668]    c4141     1
    x[668]    c4151     1
    x[668]    c4161     1
    x[668]    c4171     1
    x[668]    c4181     1
    x[668]    c4201     -1
    x[668]    c4721     1346
    x[668]    c4722     -1346
    x[668]    c4731     1322
    x[668]    c4732     -1322
    x[668]    OBJ       -7259.80211946394
    x[669]    c842      -1
    x[669]    c843      1
    x[669]    c2791     -1
    x[669]    c3371     -1
    x[669]    c4161     -1
    x[669]    c4241     -1
    x[669]    c4721     689
    x[669]    c4722     -689
    x[669]    c4731     241
    x[669]    c4732     -241
    x[669]    OBJ       -2950.24798971523
    x[670]    c851      -1
    x[670]    c852      1
    x[670]    c3491     -1
    x[670]    c4191     1
    x[670]    c4201     1
    x[670]    c4211     1
    x[670]    c4221     1
    x[670]    c4291     -1
    x[670]    c4721     1448
    x[670]    c4722     -1448
    x[670]    c4731     1448
    x[670]    c4732     -1448
    x[670]    OBJ       -27739.7886432435
    x[671]    c860      -1
    x[671]    c861      1
    x[671]    c3571     -1
    x[671]    c4211     -1
    x[671]    c4231     1
    x[671]    c4241     1
    x[671]    c4251     1
    x[671]    c4261     1
    x[671]    c4271     1
    x[671]    c4351     -1
    x[671]    c4721     2692
    x[671]    c4722     -2692
    x[671]    c4731     2668
    x[671]    c4732     -2668
    x[671]    OBJ       -16067.6087375529
    x[672]    c869      -1
    x[672]    c870      1
    x[672]    c1991     -1
    x[672]    c2961     -1
    x[672]    c3621     -1
    x[672]    c4171     -1
    x[672]    c4251     -1
    x[672]    c4401     -1
    x[672]    c4721     828
    x[672]    c4722     -828
    x[672]    c4731     291
    x[672]    c4732     -291
    x[672]    c4799     -1
    x[672]    OBJ       -2471.15754634516
    x[673]    c878      -1
    x[673]    c879      1
    x[673]    c3721     -1
    x[673]    c4281     1
    x[673]    c4291     1
    x[673]    c4301     1
    x[673]    c4311     1
    x[673]    c4321     1
    x[673]    c4331     1
    x[673]    c4721     1432
    x[673]    c4722     -1432
    x[673]    c4731     1432
    x[673]    c4732     -1432
    x[673]    OBJ       -65705.4464197398
    x[674]    c887      -1
    x[674]    c888      1
    x[674]    c3781     -1
    x[674]    c4301     -1
    x[674]    c4341     1
    x[674]    c4351     1
    x[674]    c4361     1
    x[674]    c4371     1
    x[674]    c4381     1
    x[674]    c4451     -1
    x[674]    c4721     2880
    x[674]    c4722     -2880
    x[674]    c4731     2880
    x[674]    c4732     -2880
    x[674]    OBJ       -99772.8446923994
    x[675]    c896      -1
    x[675]    c897      1
    x[675]    c2161     -1
    x[675]    c3871     -1
    x[675]    c4221     -1
    x[675]    c4361     -1
    x[675]    c4391     1
    x[675]    c4401     1
    x[675]    c4411     1
    x[675]    c4421     1
    x[675]    c4431     1
    x[675]    c4501     -1
    x[675]    c4721     2691
    x[675]    c4722     -2691
    x[675]    c4731     2691
    x[675]    c4732     -2691
    x[675]    OBJ       -33954.4052435629
    x[676]    c905      -1
    x[676]    c906      1
    x[676]    c2231     -1
    x[676]    c3921     -1
    x[676]    c4261     -1
    x[676]    c4411     -1
    x[676]    c4551     -1
    x[676]    c4641     -1
    x[676]    c4721     840
    x[676]    c4722     -840
    x[676]    c4731     543
    x[676]    c4732     -543
    x[676]    OBJ       -9909.48865178191
    x[677]    c914      -1
    x[677]    c915      1
    x[677]    c4441     1
    x[677]    c4451     1
    x[677]    c4461     1
    x[677]    c4471     1
    x[677]    c4481     1
    x[677]    c4721     716
    x[677]    c4722     -716
    x[677]    c4731     716
    x[677]    c4732     -716
    x[677]    OBJ       -33389.4400980793
    x[678]    c923      -1
    x[678]    c924      1
    x[678]    c2381     -1
    x[678]    c3961     -1
    x[678]    c4311     -1
    x[678]    c4461     -1
    x[678]    c4491     1
    x[678]    c4501     1
    x[678]    c4511     1
    x[678]    c4521     1
    x[678]    c4531     1
    x[678]    c4721     2148
    x[678]    c4722     -2148
    x[678]    c4731     2148
    x[678]    c4732     -2148
    x[678]    OBJ       -84744.7718225362
    x[679]    c932      -1
    x[679]    c933      1
    x[679]    c2451     -1
    x[679]    c4031     -1
    x[679]    c4371     -1
    x[679]    c4511     -1
    x[679]    c4541     1
    x[679]    c4551     1
    x[679]    c4561     1
    x[679]    c4571     1
    x[679]    c4581     1
    x[679]    c4721     2684
    x[679]    c4722     -2684
    x[679]    c4731     2680
    x[679]    c4732     -2680
    x[679]    OBJ       -74688.3922329286
    x[680]    c941      -1
    x[680]    c942      1
    x[680]    c2541     -1
    x[680]    c4081     -1
    x[680]    c4421     -1
    x[680]    c4561     -1
    x[680]    c4601     -1
    x[680]    c4681     -1
    x[680]    c4721     841
    x[680]    c4722     -841
    x[680]    c4731     480
    x[680]    c4732     -480
    x[680]    c4800     -1
    x[680]    OBJ       -17576.065675994
    x[681]    c950      -1
    x[681]    c951      1
    x[681]    c2721     -1
    x[681]    c4521     -1
    x[681]    c4591     1
    x[681]    c4601     1
    x[681]    c4611     1
    x[681]    c4621     1
    x[681]    c4631     1
    x[681]    c4721     671
    x[681]    c4722     -671
    x[681]    c4731     670
    x[681]    c4732     -670
    x[681]    OBJ       -13333.1774334124
    x[682]    c959      -1
    x[682]    c960      1
    x[682]    c2801     -1
    x[682]    c4131     -1
    x[682]    c4571     -1
    x[682]    c4611     -1
    x[682]    c4721     754
    x[682]    c4722     -754
    x[682]    c4731     450
    x[682]    c4732     -450
    x[682]    OBJ       -15553.4904551628
    x[683]    c968      -1
    x[683]    c969      1
    x[683]    c2971     -1
    x[683]    c4621     -1
    x[683]    c4721     289
    x[683]    c4722     -289
    x[683]    c4731     186
    x[683]    c4732     -186
    x[683]    OBJ       -4141.19451639461
    x[684]    c977      -1
    x[684]    c978      1
    x[684]    c3811     -1
    x[684]    c4181     -1
    x[684]    c4721     150
    x[684]    c4722     -150
    x[684]    OBJ       254.234315467609
    x[685]    c986      -1
    x[685]    c987      1
    x[685]    c3981     -1
    x[685]    c4271     -1
    x[685]    c4651     -1
    x[685]    c4721     315
    x[685]    c4722     -315
    x[685]    c4731     52
    x[685]    c4732     -52
    x[685]    OBJ       -99.9988307505928
    x[686]    c995      -1
    x[686]    c996      1
    x[686]    c4381     -1
    x[686]    c4641     1
    x[686]    c4651     1
    x[686]    c4661     1
    x[686]    c4671     1
    x[686]    c4721     1346
    x[686]    c4722     -1346
    x[686]    c4731     1322
    x[686]    c4732     -1322
    x[686]    OBJ       -10779.5349758266
    x[687]    c1004     -1
    x[687]    c1005     1
    x[687]    c3271     -1
    x[687]    c4431     -1
    x[687]    c4661     -1
    x[687]    c4691     -1
    x[687]    c4721     548
    x[687]    c4722     -548
    x[687]    c4731     133
    x[687]    c4732     -133
    x[687]    OBJ       -1617.49521151948
    x[688]    c1013     -1
    x[688]    c1014     1
    x[688]    c3441     -1
    x[688]    c4531     -1
    x[688]    c4681     1
    x[688]    c4691     1
    x[688]    c4701     1
    x[688]    c4711     1
    x[688]    c4721     672
    x[688]    c4722     -672
    x[688]    c4731     672
    x[688]    c4732     -672
    x[688]    OBJ       -9491.41444412407
    x[689]    c1022     -1
    x[689]    c1023     1
    x[689]    c3521     -1
    x[689]    c4581     -1
    x[689]    c4671     -1
    x[689]    c4701     -1
    x[689]    c4721     429
    x[689]    c4722     -429
    x[689]    c4731     142
    x[689]    c4732     -142
    x[689]    OBJ       -3423.68878163047
    x[690]    c1031     -1
    x[690]    c1032     1
    x[690]    c3821     -1
    x[690]    c4631     -1
    x[690]    c4711     -1
    x[690]    c4721     273
    x[690]    c4722     -273
    x[690]    c4731     94
    x[690]    c4732     -94
    x[690]    OBJ       -3186.40342052736
    x[691]    c6        -1
    x[691]    c7        1
    x[691]    c2392     -1
    x[691]    c4722     219
    x[691]    c4723     -219
    x[691]    c4732     75
    x[691]    c4733     -75
    x[691]    OBJ       -1072.44926309824
    x[692]    c15       -1
    x[692]    c16       1
    x[692]    c1342     -1
    x[692]    c4722     328
    x[692]    c4723     -328
    x[692]    c4732     215
    x[692]    c4733     -215
    x[692]    OBJ       -2188.97178358408
    x[693]    c24       -1
    x[693]    c25       1
    x[693]    c1512     -1
    x[693]    c3672     -1
    x[693]    c4722     545
    x[693]    c4723     -545
    x[693]    c4732     368
    x[693]    c4733     -368
    x[693]    OBJ       -4999.86619919317
    x[694]    c33       -1
    x[694]    c34       1
    x[694]    c1072     -1
    x[694]    c1682     -1
    x[694]    c4722     435
    x[694]    c4723     -435
    x[694]    c4732     400
    x[694]    c4733     -400
    x[694]    OBJ       -7624.67352805461
    x[695]    c42       -1
    x[695]    c43       1
    x[695]    c1122     -1
    x[695]    c4722     247
    x[695]    c4723     -247
    x[695]    c4732     216
    x[695]    c4733     -216
    x[695]    OBJ       -3398.53784744373
    x[696]    c51       -1
    x[696]    c52       1
    x[696]    c1972     -1
    x[696]    c4722     82
    x[696]    c4723     -82
    x[696]    c4732     27
    x[696]    c4733     -27
    x[696]    OBJ       -356.993384839551
    x[697]    c60       -1
    x[697]    c61       1
    x[697]    c1082     -1
    x[697]    c1242     -1
    x[697]    c2512     -1
    x[697]    c4722     526
    x[697]    c4723     -526
    x[697]    c4732     314
    x[697]    c4733     -314
    x[697]    OBJ       -3307.94281836923
    x[698]    c69       -1
    x[698]    c70       1
    x[698]    c1042     1
    x[698]    c1052     1
    x[698]    c1062     1
    x[698]    c1292     -1
    x[698]    c4722     693
    x[698]    c4723     -693
    x[698]    c4732     693
    x[698]    c4733     -693
    x[698]    OBJ       -25317.6378548763
    x[699]    c78       -1
    x[699]    c79       1
    x[699]    c1042     -1
    x[699]    c1072     1
    x[699]    c1082     1
    x[699]    c1092     1
    x[699]    c1102     1
    x[699]    c1112     1
    x[699]    c1372     -1
    x[699]    c2702     -1
    x[699]    c4722     1944
    x[699]    c4723     -1944
    x[699]    c4732     1944
    x[699]    c4733     -1944
    x[699]    OBJ       -37854.0310673488
    x[700]    c87       -1
    x[700]    c88       1
    x[700]    c1092     -1
    x[700]    c1132     -1
    x[700]    c1422     -1
    x[700]    c2782     -1
    x[700]    c4722     907
    x[700]    c4723     -907
    x[700]    c4732     574
    x[700]    c4733     -574
    x[700]    c4969     -1
    x[700]    OBJ       -10959.5500037163
    x[701]    c96       -1
    x[701]    c97       1
    x[701]    c1052     -1
    x[701]    c1122     1
    x[701]    c1132     1
    x[701]    c1142     1
    x[701]    c1152     1
    x[701]    c1162     1
    x[701]    c1542     -1
    x[701]    c4722     1296
    x[701]    c4723     -1296
    x[701]    c4732     1128
    x[701]    c4733     -1128
    x[701]    OBJ       -12068.2372784443
    x[702]    c105      -1
    x[702]    c106      1
    x[702]    c1102     -1
    x[702]    c1142     -1
    x[702]    c1172     -1
    x[702]    c1592     -1
    x[702]    c1982     -1
    x[702]    c2952     -1
    x[702]    c4722     1043
    x[702]    c4723     -1043
    x[702]    c4732     864
    x[702]    c4733     -864
    x[702]    OBJ       -10021.2793242203
    x[703]    c114      -1
    x[703]    c115      1
    x[703]    c1172     1
    x[703]    c1182     1
    x[703]    c1192     1
    x[703]    c1202     1
    x[703]    c1712     -1
    x[703]    c2152     -1
    x[703]    c4722     1332
    x[703]    c4723     -1332
    x[703]    c4732     1330
    x[703]    c4733     -1330
    x[703]    OBJ       -22967.0641275377
    x[704]    c123      -1
    x[704]    c124      1
    x[704]    c1152     -1
    x[704]    c1182     -1
    x[704]    c1762     -1
    x[704]    c2222     -1
    x[704]    c4722     1186
    x[704]    c4723     -1186
    x[704]    c4732     864
    x[704]    c4733     -864
    x[704]    OBJ       -13897.7671628895
    x[705]    c132      -1
    x[705]    c133      1
    x[705]    c1192     -1
    x[705]    c1842     -1
    x[705]    c2522     -1
    x[705]    c4722     984
    x[705]    c4723     -984
    x[705]    c4732     723
    x[705]    c4733     -723
    x[705]    c4756     -1
    x[705]    OBJ       -6899.91329545854
    x[706]    c141      -1
    x[706]    c142      1
    x[706]    c1252     -1
    x[706]    c1892     -1
    x[706]    c3252     -1
    x[706]    c4722     225
    x[706]    c4723     -225
    x[706]    c4732     20
    x[706]    c4733     -20
    x[706]    OBJ       27.913063012146
    x[707]    c150      -1
    x[707]    c151      1
    x[707]    c1212     1
    x[707]    c1222     1
    x[707]    c1232     1
    x[707]    c1302     -1
    x[707]    c1932     -1
    x[707]    c4722     724
    x[707]    c4723     -724
    x[707]    c4732     724
    x[707]    c4733     -724
    x[707]    OBJ       -18853.5601046951
    x[708]    c159      -1
    x[708]    c160      1
    x[708]    c1212     -1
    x[708]    c1242     1
    x[708]    c1252     1
    x[708]    c1262     1
    x[708]    c1272     1
    x[708]    c1282     1
    x[708]    c1382     -1
    x[708]    c2002     -1
    x[708]    c3422     -1
    x[708]    c4722     1989
    x[708]    c4723     -1989
    x[708]    c4732     1989
    x[708]    c4733     -1989
    x[708]    OBJ       -16346.2814622006
    x[709]    c168      -1
    x[709]    c169      1
    x[709]    c1262     -1
    x[709]    c1432     -1
    x[709]    c2052     -1
    x[709]    c3502     -1
    x[709]    c4722     710
    x[709]    c4723     -710
    x[709]    c4732     382
    x[709]    c4733     -382
    x[709]    OBJ       -4573.82471111304
    x[710]    c177      -1
    x[710]    c178      1
    x[710]    c1292     1
    x[710]    c1302     1
    x[710]    c1312     1
    x[710]    c1322     1
    x[710]    c1332     1
    x[710]    c1342     1
    x[710]    c1352     1
    x[710]    c1362     1
    x[710]    c2102     -1
    x[710]    c4722     716
    x[710]    c4723     -716
    x[710]    c4732     716
    x[710]    c4733     -716
    x[710]    c4777     1
    x[710]    OBJ       -28549.6767299668
    x[711]    c186      -1
    x[711]    c187      1
    x[711]    c1312     -1
    x[711]    c1372     1
    x[711]    c1382     1
    x[711]    c1392     1
    x[711]    c1402     1
    x[711]    c1412     1
    x[711]    c1472     -1
    x[711]    c2172     -1
    x[711]    c3662     -1
    x[711]    c4722     2876
    x[711]    c4723     -2876
    x[711]    c4732     2876
    x[711]    c4733     -2876
    x[711]    OBJ       -90301.2073585915
    x[712]    c195      -1
    x[712]    c196      1
    x[712]    c1062     -1
    x[712]    c1222     -1
    x[712]    c1392     -1
    x[712]    c1422     1
    x[712]    c1432     1
    x[712]    c1442     1
    x[712]    c1452     1
    x[712]    c1462     1
    x[712]    c1552     -1
    x[712]    c2242     -1
    x[712]    c3732     -1
    x[712]    c4722     2595
    x[712]    c4723     -2595
    x[712]    c4732     2595
    x[712]    c4733     -2595
    x[712]    c4833     -1
    x[712]    c4835     -1
    x[712]    OBJ       -19318.7778215642
    x[713]    c204      -1
    x[713]    c205      1
    x[713]    c1112     -1
    x[713]    c1272     -1
    x[713]    c1442     -1
    x[713]    c1602     -1
    x[713]    c2292     -1
    x[713]    c3792     -1
    x[713]    c4722     1030
    x[713]    c4723     -1030
    x[713]    c4732     552
    x[713]    c4733     -552
    x[713]    c4750     -1
    x[713]    OBJ       -2585.63110007247
    x[714]    c213      -1
    x[714]    c214      1
    x[714]    c1472     1
    x[714]    c1482     1
    x[714]    c1492     1
    x[714]    c1502     1
    x[714]    c1512     1
    x[714]    c1522     1
    x[714]    c1532     1
    x[714]    c2402     -1
    x[714]    c4722     1432
    x[714]    c4723     -1432
    x[714]    c4732     1432
    x[714]    c4733     -1432
    x[714]    OBJ       -52936.8791511049
    x[715]    c222      -1
    x[715]    c223      1
    x[715]    c1322     -1
    x[715]    c1482     -1
    x[715]    c1542     1
    x[715]    c1552     1
    x[715]    c1562     1
    x[715]    c1572     1
    x[715]    c1582     1
    x[715]    c1642     -1
    x[715]    c2462     -1
    x[715]    c4722     2864
    x[715]    c4723     -2864
    x[715]    c4732     2864
    x[715]    c4733     -2864
    x[715]    OBJ       -72524.9935455933
    x[716]    c231      -1
    x[716]    c232      1
    x[716]    c1402     -1
    x[716]    c1562     -1
    x[716]    c1592     1
    x[716]    c1602     1
    x[716]    c1612     1
    x[716]    c1622     1
    x[716]    c1632     1
    x[716]    c1722     -1
    x[716]    c2552     -1
    x[716]    c4722     2600
    x[716]    c4723     -2600
    x[716]    c4732     2336
    x[716]    c4733     -2336
    x[716]    c4958     -1
    x[716]    OBJ       -27687.7996966093
    x[717]    c240      -1
    x[717]    c241      1
    x[717]    c1162     -1
    x[717]    c1452     -1
    x[717]    c1612     -1
    x[717]    c1772     -1
    x[717]    c2602     -1
    x[717]    c3972     -1
    x[717]    c4722     1156
    x[717]    c4723     -1156
    x[717]    c4732     696
    x[717]    c4733     -696
    x[717]    c4863     -1
    x[717]    OBJ       -6420.00449279357
    x[718]    c249      -1
    x[718]    c250      1
    x[718]    c1642     1
    x[718]    c1652     1
    x[718]    c1662     1
    x[718]    c1672     1
    x[718]    c1682     1
    x[718]    c1692     1
    x[718]    c1702     1
    x[718]    c2652     -1
    x[718]    c4722     716
    x[718]    c4723     -716
    x[718]    c4732     716
    x[718]    c4733     -716
    x[718]    c4779     1
    x[718]    OBJ       -26492.9247185455
    x[719]    c258      -1
    x[719]    c259      1
    x[719]    c1492     -1
    x[719]    c1652     -1
    x[719]    c1712     1
    x[719]    c1722     1
    x[719]    c1732     1
    x[719]    c1742     1
    x[719]    c1752     1
    x[719]    c2732     -1
    x[719]    c4722     2864
    x[719]    c4723     -2864
    x[719]    c4732     2864
    x[719]    c4733     -2864
    x[719]    OBJ       -82221.1101708651
    x[720]    c267      -1
    x[720]    c268      1
    x[720]    c1572     -1
    x[720]    c1732     -1
    x[720]    c1762     1
    x[720]    c1772     1
    x[720]    c1782     1
    x[720]    c1792     1
    x[720]    c1802     1
    x[720]    c1812     -1
    x[720]    c2812     -1
    x[720]    c4722     2681
    x[720]    c4723     -2681
    x[720]    c4732     2678
    x[720]    c4733     -2678
    x[720]    OBJ       -76589.5272824496
    x[721]    c276      -1
    x[721]    c277      1
    x[721]    c1202     -1
    x[721]    c1622     -1
    x[721]    c1782     -1
    x[721]    c1852     -1
    x[721]    c2862     -1
    x[721]    c3262     -1
    x[721]    c4722     1263
    x[721]    c4723     -1263
    x[721]    c4732     864
    x[721]    c4733     -864
    x[721]    c4751     -1
    x[721]    OBJ       -27668.2115822149
    x[722]    c285      -1
    x[722]    c286      1
    x[722]    c1662     -1
    x[722]    c1812     1
    x[722]    c1822     1
    x[722]    c1832     1
    x[722]    c2912     -1
    x[722]    c4722     716
    x[722]    c4723     -716
    x[722]    c4732     716
    x[722]    c4733     -716
    x[722]    OBJ       -17923.1246709569
    x[723]    c294      -1
    x[723]    c295      1
    x[723]    c1742     -1
    x[723]    c1822     -1
    x[723]    c1842     1
    x[723]    c1852     1
    x[723]    c1862     1
    x[723]    c1872     1
    x[723]    c1882     1
    x[723]    c2982     -1
    x[723]    c3432     -1
    x[723]    c4722     1965
    x[723]    c4723     -1965
    x[723]    c4732     1964
    x[723]    c4733     -1964
    x[723]    OBJ       -31928.6264630161
    x[724]    c303      -1
    x[724]    c304      1
    x[724]    c1792     -1
    x[724]    c1862     -1
    x[724]    c3032     -1
    x[724]    c3512     -1
    x[724]    c4722     1245
    x[724]    c4723     -1245
    x[724]    c4732     889
    x[724]    c4733     -889
    x[724]    c4972     -1
    x[724]    OBJ       -15508.8895718362
    x[725]    c312      -1
    x[725]    c313      1
    x[725]    c1872     -1
    x[725]    c3082     -1
    x[725]    c3802     -1
    x[725]    c4722     832
    x[725]    c4723     -832
    x[725]    c4732     647
    x[725]    c4733     -647
    x[725]    OBJ       -4649.23895153182
    x[726]    c321      -1
    x[726]    c322      1
    x[726]    c4722     339
    x[726]    c4723     -339
    x[726]    c4732     283
    x[726]    c4733     -283
    x[726]    OBJ       -2737.43898662976
    x[727]    c330      -1
    x[727]    c331      1
    x[727]    c1892     1
    x[727]    c1902     1
    x[727]    c1912     1
    x[727]    c1922     1
    x[727]    c2012     -1
    x[727]    c4722     1346
    x[727]    c4723     -1346
    x[727]    c4732     1346
    x[727]    c4733     -1346
    x[727]    OBJ       -22477.3612676754
    x[728]    c339      -1
    x[728]    c340      1
    x[728]    c1902     -1
    x[728]    c2062     -1
    x[728]    c4722     243
    x[728]    c4723     -243
    x[728]    OBJ       355.916038547854
    x[729]    c348      -1
    x[729]    c349      1
    x[729]    c1932     1
    x[729]    c1942     1
    x[729]    c1952     1
    x[729]    c1962     1
    x[729]    c1972     1
    x[729]    c1982     1
    x[729]    c1992     1
    x[729]    c2112     -1
    x[729]    c4722     724
    x[729]    c4723     -724
    x[729]    c4732     724
    x[729]    c4733     -724
    x[729]    OBJ       -25807.3407147385
    x[730]    c357      -1
    x[730]    c358      1
    x[730]    c1942     -1
    x[730]    c2002     1
    x[730]    c2012     1
    x[730]    c2022     1
    x[730]    c2032     1
    x[730]    c2042     1
    x[730]    c2182     -1
    x[730]    c4722     2896
    x[730]    c4723     -2896
    x[730]    c4732     2896
    x[730]    c4733     -2896
    x[730]    OBJ       -79821.5661575402
    x[731]    c366      -1
    x[731]    c367      1
    x[731]    c1232     -1
    x[731]    c2022     -1
    x[731]    c2052     1
    x[731]    c2062     1
    x[731]    c2072     1
    x[731]    c2082     1
    x[731]    c2092     1
    x[731]    c2252     -1
    x[731]    c3132     -1
    x[731]    c4722     2692
    x[731]    c4723     -2692
    x[731]    c4732     2692
    x[731]    c4733     -2692
    x[731]    OBJ       -39910.7830787701
    x[732]    c375      -1
    x[732]    c376      1
    x[732]    c1282     -1
    x[732]    c1912     -1
    x[732]    c2072     -1
    x[732]    c2302     -1
    x[732]    c3162     -1
    x[732]    c4722     755
    x[732]    c4723     -755
    x[732]    c4732     323
    x[732]    c4733     -323
    x[732]    c4967     -1
    x[732]    OBJ       -3367.68656727242
    x[733]    c384      -1
    x[733]    c385      1
    x[733]    c2102     1
    x[733]    c2112     1
    x[733]    c2122     1
    x[733]    c2132     1
    x[733]    c2142     1
    x[733]    c2152     1
    x[733]    c2162     1
    x[733]    c2342     -1
    x[733]    c4722     1432
    x[733]    c4723     -1432
    x[733]    c4732     1432
    x[733]    c4733     -1432
    x[733]    OBJ       -54503.928302664
    x[734]    c393      -1
    x[734]    c394      1
    x[734]    c2122     -1
    x[734]    c2172     1
    x[734]    c2182     1
    x[734]    c2192     1
    x[734]    c2202     1
    x[734]    c2212     1
    x[734]    c2222     1
    x[734]    c2232     1
    x[734]    c2412     -1
    x[734]    c4722     2886
    x[734]    c4723     -2886
    x[734]    c4732     2886
    x[734]    c4733     -2886
    x[734]    c4778     1
    x[734]    OBJ       -102690.689713105
    x[735]    c402      -1
    x[735]    c403      1
    x[735]    c1332     -1
    x[735]    c1952     -1
    x[735]    c2192     -1
    x[735]    c2242     1
    x[735]    c2252     1
    x[735]    c2262     1
    x[735]    c2272     1
    x[735]    c2282     1
    x[735]    c2472     -1
    x[735]    c3212     -1
    x[735]    c4722     2895
    x[735]    c4723     -2895
    x[735]    c4732     2895
    x[735]    c4733     -2895
    x[735]    c4930     1
    x[735]    c4936     1
    x[735]    OBJ       -85453.1490459556
    x[736]    c411      -1
    x[736]    c412      1
    x[736]    c1412     -1
    x[736]    c2032     -1
    x[736]    c2262     -1
    x[736]    c2292     1
    x[736]    c2302     1
    x[736]    c2312     1
    x[736]    c2322     1
    x[736]    c2332     1
    x[736]    c2562     -1
    x[736]    c3282     -1
    x[736]    c4722     2692
    x[736]    c4723     -2692
    x[736]    c4732     2668
    x[736]    c4733     -2668
    x[736]    OBJ       -33544.6459005614
    x[737]    c420      -1
    x[737]    c421      1
    x[737]    c1462     -1
    x[737]    c2082     -1
    x[737]    c2312     -1
    x[737]    c2612     -1
    x[737]    c3332     -1
    x[737]    c4322     -1
    x[737]    c4722     1115
    x[737]    c4723     -1115
    x[737]    c4732     408
    x[737]    c4733     -408
    x[737]    c4753     -1
    x[737]    OBJ       -2469.57152228513
    x[738]    c429      -1
    x[738]    c430      1
    x[738]    c2342     1
    x[738]    c2352     1
    x[738]    c2362     1
    x[738]    c2372     1
    x[738]    c2382     1
    x[738]    c2392     1
    x[738]    c4722     1432
    x[738]    c4723     -1432
    x[738]    c4732     1432
    x[738]    c4733     -1432
    x[738]    c4895     1
    x[738]    OBJ       -62192.2632025007
    x[739]    c438      -1
    x[739]    c439      1
    x[739]    c2352     -1
    x[739]    c2402     1
    x[739]    c2412     1
    x[739]    c2422     1
    x[739]    c2432     1
    x[739]    c2442     1
    x[739]    c2452     1
    x[739]    c4722     2864
    x[739]    c4723     -2864
    x[739]    c4732     2864
    x[739]    c4733     -2864
    x[739]    OBJ       -113806.944631978
    x[740]    c447      -1
    x[740]    c448      1
    x[740]    c2132     -1
    x[740]    c2422     -1
    x[740]    c2462     1
    x[740]    c2472     1
    x[740]    c2482     1
    x[740]    c2492     1
    x[740]    c2502     1
    x[740]    c2512     1
    x[740]    c2522     1
    x[740]    c2532     1
    x[740]    c2542     1
    x[740]    c2662     -1
    x[740]    c3382     -1
    x[740]    c4722     2864
    x[740]    c4723     -2864
    x[740]    c4732     2864
    x[740]    c4733     -2864
    x[740]    c4958     1
    x[740]    c4959     1
    x[740]    c4960     1
    x[740]    c4962     1
    x[740]    c4967     1
    x[740]    c4968     1
    x[740]    c4969     1
    x[740]    c4972     1
    x[740]    c4975     1
    x[740]    c4976     1
    x[740]    c4978     1
    x[740]    OBJ       -107489.777739755
    x[741]    c456      -1
    x[741]    c457      1
    x[741]    c1502     -1
    x[741]    c2202     -1
    x[741]    c2482     -1
    x[741]    c2552     1
    x[741]    c2562     1
    x[741]    c2572     1
    x[741]    c2582     1
    x[741]    c2592     1
    x[741]    c2742     -1
    x[741]    c3452     -1
    x[741]    c4722     2873
    x[741]    c4723     -2873
    x[741]    c4732     2873
    x[741]    c4733     -2873
    x[741]    OBJ       -82661.8427447411
    x[742]    c465      -1
    x[742]    c466      1
    x[742]    c1582     -1
    x[742]    c2272     -1
    x[742]    c2572     -1
    x[742]    c2602     1
    x[742]    c2612     1
    x[742]    c2622     1
    x[742]    c2632     1
    x[742]    c2642     1
    x[742]    c2822     -1
    x[742]    c3532     -1
    x[742]    c4722     2679
    x[742]    c4723     -2679
    x[742]    c4732     2604
    x[742]    c4733     -2604
    x[742]    c4777     -1
    x[742]    c4778     -1
    x[742]    c4779     -1
    x[742]    OBJ       -28711.2786737214
    x[743]    c474      -1
    x[743]    c475      1
    x[743]    c1632     -1
    x[743]    c2322     -1
    x[743]    c2622     -1
    x[743]    c2872     -1
    x[743]    c3582     -1
    x[743]    c4472     -1
    x[743]    c4722     1252
    x[743]    c4723     -1252
    x[743]    c4732     552
    x[743]    c4733     -552
    x[743]    c4930     -1
    x[743]    OBJ       -5657.53713998811
    x[744]    c483      -1
    x[744]    c484      1
    x[744]    c2362     -1
    x[744]    c2652     1
    x[744]    c2662     1
    x[744]    c2672     1
    x[744]    c2682     1
    x[744]    c2692     1
    x[744]    c2702     1
    x[744]    c2712     1
    x[744]    c2722     1
    x[744]    c3632     -1
    x[744]    c4722     2148
    x[744]    c4723     -2148
    x[744]    c4732     2148
    x[744]    c4733     -2148
    x[744]    c4833     1
    x[744]    OBJ       -75463.2107047666
    x[745]    c492      -1
    x[745]    c493      1
    x[745]    c2432     -1
    x[745]    c2672     -1
    x[745]    c2732     1
    x[745]    c2742     1
    x[745]    c2752     1
    x[745]    c2762     1
    x[745]    c2772     1
    x[745]    c2782     1
    x[745]    c2792     1
    x[745]    c2802     1
    x[745]    c3682     -1
    x[745]    c4722     2864
    x[745]    c4723     -2864
    x[745]    c4732     2864
    x[745]    c4733     -2864
    x[745]    c4738     1
    x[745]    c4750     1
    x[745]    c4751     1
    x[745]    c4753     1
    x[745]    c4754     1
    x[745]    c4755     -1
    x[745]    c4756     1
    x[745]    OBJ       -98479.2451182904
    x[746]    c501      -1
    x[746]    c502      1
    x[746]    c1672     -1
    x[746]    c2492     -1
    x[746]    c2752     -1
    x[746]    c2812     1
    x[746]    c2822     1
    x[746]    c2832     1
    x[746]    c2842     1
    x[746]    c2852     1
    x[746]    c2922     -1
    x[746]    c3742     -1
    x[746]    c4722     2864
    x[746]    c4723     -2864
    x[746]    c4732     2864
    x[746]    c4733     -2864
    x[746]    c4893     -1
    x[746]    c4895     -1
    x[746]    c4896     1
    x[746]    c4900     1
    x[746]    OBJ       -90105.3262146467
    x[747]    c510      -1
    x[747]    c511      1
    x[747]    c1752     -1
    x[747]    c2582     -1
    x[747]    c2832     -1
    x[747]    c2862     1
    x[747]    c2872     1
    x[747]    c2882     1
    x[747]    c2892     1
    x[747]    c2902     1
    x[747]    c2992     -1
    x[747]    c3832     -1
    x[747]    c4722     2684
    x[747]    c4723     -2684
    x[747]    c4732     2680
    x[747]    c4733     -2680
    x[747]    c4808     -1
    x[747]    OBJ       -76589.5272824496
    x[748]    c519      -1
    x[748]    c520      1
    x[748]    c1802     -1
    x[748]    c2632     -1
    x[748]    c2882     -1
    x[748]    c3042     -1
    x[748]    c3882     -1
    x[748]    c4722     1253
    x[748]    c4723     -1253
    x[748]    c4732     840
    x[748]    c4733     -840
    x[748]    c4968     -1
    x[748]    OBJ       -21155.1635460475
    x[749]    c528      -1
    x[749]    c529      1
    x[749]    c2682     -1
    x[749]    c2912     1
    x[749]    c2922     1
    x[749]    c2932     1
    x[749]    c2942     1
    x[749]    c2952     1
    x[749]    c2962     1
    x[749]    c2972     1
    x[749]    c4722     716
    x[749]    c4723     -716
    x[749]    c4732     716
    x[749]    c4733     -716
    x[749]    OBJ       -28402.7658720082
    x[750]    c537      -1
    x[750]    c538      1
    x[750]    c2762     -1
    x[750]    c2932     -1
    x[750]    c2982     1
    x[750]    c2992     1
    x[750]    c3002     1
    x[750]    c3012     1
    x[750]    c3022     1
    x[750]    c3932     -1
    x[750]    c4722     2864
    x[750]    c4723     -2864
    x[750]    c4732     2864
    x[750]    c4733     -2864
    x[750]    OBJ       -79135.9821537331
    x[751]    c546      -1
    x[751]    c547      1
    x[751]    c1832     -1
    x[751]    c2842     -1
    x[751]    c3002     -1
    x[751]    c3032     1
    x[751]    c3042     1
    x[751]    c3052     1
    x[751]    c3062     1
    x[751]    c3072     1
    x[751]    c3992     -1
    x[751]    c4722     2651
    x[751]    c4723     -2651
    x[751]    c4732     2650
    x[751]    c4733     -2650
    x[751]    OBJ       -60919.035766859
    x[752]    c555      -1
    x[752]    c556      1
    x[752]    c1882     -1
    x[752]    c2892     -1
    x[752]    c3052     -1
    x[752]    c3092     -1
    x[752]    c4042     -1
    x[752]    c4722     1175
    x[752]    c4723     -1175
    x[752]    c4732     768
    x[752]    c4733     -768
    x[752]    OBJ       -18677.2670751447
    x[753]    c564      -1
    x[753]    c565      1
    x[753]    c3012     -1
    x[753]    c3082     1
    x[753]    c3092     1
    x[753]    c3102     1
    x[753]    c3112     1
    x[753]    c3122     1
    x[753]    c4722     1333
    x[753]    c4723     -1333
    x[753]    c4732     1332
    x[753]    c4733     -1332
    x[753]    c4754     -1
    x[753]    OBJ       -21400.0149759786
    x[754]    c573      -1
    x[754]    c574      1
    x[754]    c3062     -1
    x[754]    c3102     -1
    x[754]    c4092     -1
    x[754]    c4332     -1
    x[754]    c4722     940
    x[754]    c4723     -940
    x[754]    c4732     728
    x[754]    c4733     -728
    x[754]    c4900     -1
    x[754]    OBJ       -14671.4976814718
    x[755]    c582      -1
    x[755]    c583      1
    x[755]    c3112     -1
    x[755]    c4482     -1
    x[755]    c4722     342
    x[755]    c4723     -342
    x[755]    c4732     317
    x[755]    c4733     -317
    x[755]    OBJ       -3623.80116298036
    x[756]    c591      -1
    x[756]    c592      1
    x[756]    c1352     -1
    x[756]    c1922     -1
    x[756]    c3172     -1
    x[756]    c4722     187
    x[756]    c4723     -187
    x[756]    OBJ       270.169067785981
    x[757]    c600      -1
    x[757]    c601      1
    x[757]    c1962     -1
    x[757]    c3132     1
    x[757]    c3142     1
    x[757]    c3152     1
    x[757]    c3222     -1
    x[757]    c4722     724
    x[757]    c4723     -724
    x[757]    c4732     724
    x[757]    c4733     -724
    x[757]    OBJ       -14495.2046519214
    x[758]    c609      -1
    x[758]    c610      1
    x[758]    c2042     -1
    x[758]    c3142     -1
    x[758]    c3162     1
    x[758]    c3172     1
    x[758]    c3182     1
    x[758]    c3192     1
    x[758]    c3202     1
    x[758]    c3292     -1
    x[758]    c4722     2019
    x[758]    c4723     -2019
    x[758]    c4732     1995
    x[758]    c4733     -1995
    x[758]    OBJ       -16982.8951800214
    x[759]    c618      -1
    x[759]    c619      1
    x[759]    c1522     -1
    x[759]    c2092     -1
    x[759]    c3182     -1
    x[759]    c3342     -1
    x[759]    c4722     660
    x[759]    c4723     -660
    x[759]    c4732     174
    x[759]    c4733     -174
    x[759]    c4936     -1
    x[759]    OBJ       -1961.74965660801
    x[760]    c627      -1
    x[760]    c628      1
    x[760]    c2142     -1
    x[760]    c3212     1
    x[760]    c3222     1
    x[760]    c3232     1
    x[760]    c3242     1
    x[760]    c3252     1
    x[760]    c3262     1
    x[760]    c3272     1
    x[760]    c3392     -1
    x[760]    c4722     1447
    x[760]    c4723     -1447
    x[760]    c4732     1447
    x[760]    c4733     -1447
    x[760]    c4835     1
    x[760]    OBJ       -43191.792239847
    x[761]    c636      -1
    x[761]    c637      1
    x[761]    c2212     -1
    x[761]    c3232     -1
    x[761]    c3282     1
    x[761]    c3292     1
    x[761]    c3302     1
    x[761]    c3312     1
    x[761]    c3322     1
    x[761]    c3462     -1
    x[761]    c4722     2896
    x[761]    c4723     -2896
    x[761]    c4732     2896
    x[761]    c4733     -2896
    x[761]    OBJ       -58274.6403236029
    x[762]    c645      -1
    x[762]    c646      1
    x[762]    c2282     -1
    x[762]    c3152     -1
    x[762]    c3302     -1
    x[762]    c3332     1
    x[762]    c3342     1
    x[762]    c3352     1
    x[762]    c3362     1
    x[762]    c3372     1
    x[762]    c3542     -1
    x[762]    c4722     2692
    x[762]    c4723     -2692
    x[762]    c4732     2692
    x[762]    c4733     -2692
    x[762]    OBJ       -23770.1768177116
    x[763]    c654      -1
    x[763]    c655      1
    x[763]    c1692     -1
    x[763]    c2332     -1
    x[763]    c3192     -1
    x[763]    c3352     -1
    x[763]    c3592     -1
    x[763]    c4142     -1
    x[763]    c4722     964
    x[763]    c4723     -964
    x[763]    c4732     288
    x[763]    c4733     -288
    x[763]    c4815     -1
    x[763]    OBJ       -1912.28966776193
    x[764]    c663      -1
    x[764]    c664      1
    x[764]    c2372     -1
    x[764]    c3382     1
    x[764]    c3392     1
    x[764]    c3402     1
    x[764]    c3412     1
    x[764]    c3422     1
    x[764]    c3432     1
    x[764]    c3442     1
    x[764]    c3642     -1
    x[764]    c4722     1432
    x[764]    c4723     -1432
    x[764]    c4732     1432
    x[764]    c4733     -1432
    x[764]    c4965     1
    x[764]    OBJ       -55238.4825924573
    x[765]    c672      -1
    x[765]    c673      1
    x[765]    c2442     -1
    x[765]    c3402     -1
    x[765]    c3452     1
    x[765]    c3462     1
    x[765]    c3472     1
    x[765]    c3482     1
    x[765]    c3492     1
    x[765]    c3502     1
    x[765]    c3512     1
    x[765]    c3522     1
    x[765]    c3692     -1
    x[765]    c4722     2872
    x[765]    c4723     -2872
    x[765]    c4732     2872
    x[765]    c4733     -2872
    x[765]    c4861     1
    x[765]    c4863     1
    x[765]    OBJ       -91035.7616483849
    x[766]    c681      -1
    x[766]    c682      1
    x[766]    c2502     -1
    x[766]    c3242     -1
    x[766]    c3472     -1
    x[766]    c3532     1
    x[766]    c3542     1
    x[766]    c3552     1
    x[766]    c3562     1
    x[766]    c3572     1
    x[766]    c3752     -1
    x[766]    c4722     2888
    x[766]    c4723     -2888
    x[766]    c4732     2888
    x[766]    c4733     -2888
    x[766]    OBJ       -70321.3306762133
    x[767]    c690      -1
    x[767]    c691      1
    x[767]    c2592     -1
    x[767]    c3312     -1
    x[767]    c3552     -1
    x[767]    c3582     1
    x[767]    c3592     1
    x[767]    c3602     1
    x[767]    c3612     1
    x[767]    c3622     1
    x[767]    c3842     -1
    x[767]    c4192     -1
    x[767]    c4722     2692
    x[767]    c4723     -2692
    x[767]    c4732     2692
    x[767]    c4733     -2692
    x[767]    OBJ       -33201.8538986578
    x[768]    c699      -1
    x[768]    c700      1
    x[768]    c2642     -1
    x[768]    c3362     -1
    x[768]    c3602     -1
    x[768]    c3892     -1
    x[768]    c4232     -1
    x[768]    c4722     1168
    x[768]    c4723     -1168
    x[768]    c4732     528
    x[768]    c4733     -528
    x[768]    OBJ       -6346.54906381424
    x[769]    c708      -1
    x[769]    c709      1
    x[769]    c3632     1
    x[769]    c3642     1
    x[769]    c3652     1
    x[769]    c3662     1
    x[769]    c3672     1
    x[769]    c4722     716
    x[769]    c4723     -716
    x[769]    c4732     716
    x[769]    c4733     -716
    x[769]    c4755     1
    x[769]    OBJ       -32712.1510387956
    x[770]    c717      -1
    x[770]    c718      1
    x[770]    c3652     -1
    x[770]    c3682     1
    x[770]    c3692     1
    x[770]    c3702     1
    x[770]    c3712     1
    x[770]    c3722     1
    x[770]    c3732     1
    x[770]    c4722     2864
    x[770]    c4723     -2864
    x[770]    c4732     2864
    x[770]    c4733     -2864
    x[770]    c4893     1
    x[770]    OBJ       -113219.301200143
    x[771]    c726      -1
    x[771]    c727      1
    x[771]    c2692     -1
    x[771]    c3412     -1
    x[771]    c3702     -1
    x[771]    c3742     1
    x[771]    c3752     1
    x[771]    c3762     1
    x[771]    c3772     1
    x[771]    c3782     1
    x[771]    c3792     1
    x[771]    c3802     1
    x[771]    c3812     1
    x[771]    c3822     1
    x[771]    c4722     2864
    x[771]    c4723     -2864
    x[771]    c4732     2864
    x[771]    c4733     -2864
    x[771]    c4808     1
    x[771]    c4815     1
    x[771]    c4816     1
    x[771]    c4817     1
    x[771]    c4818     1
    x[771]    OBJ       -114884.290923674
    x[772]    c735      -1
    x[772]    c736      1
    x[772]    c2772     -1
    x[772]    c3482     -1
    x[772]    c3762     -1
    x[772]    c3832     1
    x[772]    c3842     1
    x[772]    c3852     1
    x[772]    c3862     1
    x[772]    c3872     1
    x[772]    c3942     -1
    x[772]    c4282     -1
    x[772]    c4722     2865
    x[772]    c4723     -2865
    x[772]    c4732     2865
    x[772]    c4733     -2865
    x[772]    c4965     -1
    x[772]    OBJ       -109987.262325052
    x[773]    c744      -1
    x[773]    c745      1
    x[773]    c2852     -1
    x[773]    c3562     -1
    x[773]    c3852     -1
    x[773]    c3882     1
    x[773]    c3892     1
    x[773]    c3902     1
    x[773]    c3912     1
    x[773]    c3922     1
    x[773]    c4002     -1
    x[773]    c4342     -1
    x[773]    c4722     2686
    x[773]    c4723     -2686
    x[773]    c4732     2684
    x[773]    c4733     -2684
    x[773]    c4861     -1
    x[773]    OBJ       -64738.7180737841
    x[774]    c753      -1
    x[774]    c754      1
    x[774]    c1362     -1
    x[774]    c2902     -1
    x[774]    c3612     -1
    x[774]    c3902     -1
    x[774]    c4052     -1
    x[774]    c4392     -1
    x[774]    c4722     1152
    x[774]    c4723     -1152
    x[774]    c4732     624
    x[774]    c4733     -624
    x[774]    OBJ       -12678.4070418326
    x[775]    c762      -1
    x[775]    c763      1
    x[775]    c3712     -1
    x[775]    c3932     1
    x[775]    c3942     1
    x[775]    c3952     1
    x[775]    c3962     1
    x[775]    c3972     1
    x[775]    c3982     1
    x[775]    c4722     1432
    x[775]    c4723     -1432
    x[775]    c4732     1432
    x[775]    c4733     -1432
    x[775]    OBJ       -58176.6997516305
    x[776]    c771      -1
    x[776]    c772      1
    x[776]    c2942     -1
    x[776]    c3772     -1
    x[776]    c3952     -1
    x[776]    c3992     1
    x[776]    c4002     1
    x[776]    c4012     1
    x[776]    c4022     1
    x[776]    c4032     1
    x[776]    c4442     -1
    x[776]    c4722     2864
    x[776]    c4723     -2864
    x[776]    c4732     2864
    x[776]    c4733     -2864
    x[776]    OBJ       -83494.3376065068
    x[777]    c780      -1
    x[777]    c781      1
    x[777]    c3022     -1
    x[777]    c3862     -1
    x[777]    c4012     -1
    x[777]    c4042     1
    x[777]    c4052     1
    x[777]    c4062     1
    x[777]    c4072     1
    x[777]    c4082     1
    x[777]    c4492     -1
    x[777]    c4722     2684
    x[777]    c4723     -2684
    x[777]    c4732     2680
    x[777]    c4733     -2680
    x[777]    c4738     -1
    x[777]    OBJ       -58323.6106095892
    x[778]    c789      -1
    x[778]    c790      1
    x[778]    c1532     -1
    x[778]    c3072     -1
    x[778]    c3912     -1
    x[778]    c4062     -1
    x[778]    c4102     -1
    x[778]    c4542     -1
    x[778]    c4722     1099
    x[778]    c4723     -1099
    x[778]    c4732     672
    x[778]    c4733     -672
    x[778]    c4896     -1
    x[778]    OBJ       -18133.6969006976
    x[779]    c798      -1
    x[779]    c799      1
    x[779]    c4022     -1
    x[779]    c4092     1
    x[779]    c4102     1
    x[779]    c4112     1
    x[779]    c4122     1
    x[779]    c4132     1
    x[779]    c4722     1342
    x[779]    c4723     -1342
    x[779]    c4732     1340
    x[779]    c4733     -1340
    x[779]    c4816     -1
    x[779]    OBJ       -13809.6206481143
    x[780]    c807      -1
    x[780]    c808      1
    x[780]    c1702     -1
    x[780]    c3122     -1
    x[780]    c4072     -1
    x[780]    c4112     -1
    x[780]    c4592     -1
    x[780]    c4722     880
    x[780]    c4723     -880
    x[780]    c4732     629
    x[780]    c4733     -629
    x[780]    OBJ       -10611.8609732141
    x[781]    c816      -1
    x[781]    c817      1
    x[781]    c4122     -1
    x[781]    c4722     326
    x[781]    c4723     -326
    x[781]    c4732     256
    x[781]    c4733     -256
    x[781]    OBJ       -3922.5199074963
    x[782]    c825      -1
    x[782]    c826      1
    x[782]    c2532     -1
    x[782]    c3202     -1
    x[782]    c4152     -1
    x[782]    c4722     360
    x[782]    c4723     -360
    x[782]    OBJ       527.899682931462
    x[783]    c834      -1
    x[783]    c835      1
    x[783]    c2712     -1
    x[783]    c3322     -1
    x[783]    c4142     1
    x[783]    c4152     1
    x[783]    c4162     1
    x[783]    c4172     1
    x[783]    c4182     1
    x[783]    c4202     -1
    x[783]    c4722     1346
    x[783]    c4723     -1346
    x[783]    c4732     1322
    x[783]    c4733     -1322
    x[783]    OBJ       -6292.6817492294
    x[784]    c843      -1
    x[784]    c844      1
    x[784]    c2792     -1
    x[784]    c3372     -1
    x[784]    c4162     -1
    x[784]    c4242     -1
    x[784]    c4722     689
    x[784]    c4723     -689
    x[784]    c4732     241
    x[784]    c4733     -241
    x[784]    OBJ       -2557.22833420046
    x[785]    c852      -1
    x[785]    c853      1
    x[785]    c3492     -1
    x[785]    c4192     1
    x[785]    c4202     1
    x[785]    c4212     1
    x[785]    c4222     1
    x[785]    c4292     -1
    x[785]    c4722     1448
    x[785]    c4723     -1448
    x[785]    c4732     1448
    x[785]    c4733     -1448
    x[785]    OBJ       -24044.4104192345
    x[786]    c861      -1
    x[786]    c862      1
    x[786]    c3572     -1
    x[786]    c4212     -1
    x[786]    c4232     1
    x[786]    c4242     1
    x[786]    c4252     1
    x[786]    c4262     1
    x[786]    c4272     1
    x[786]    c4352     -1
    x[786]    c4722     2692
    x[786]    c4723     -2692
    x[786]    c4732     2668
    x[786]    c4733     -2668
    x[786]    OBJ       -13927.1493344812
    x[787]    c870      -1
    x[787]    c871      1
    x[787]    c1992     -1
    x[787]    c2962     -1
    x[787]    c3622     -1
    x[787]    c4172     -1
    x[787]    c4252     -1
    x[787]    c4402     -1
    x[787]    c4722     828
    x[787]    c4723     -828
    x[787]    c4732     291
    x[787]    c4733     -291
    x[787]    c4817     -1
    x[787]    OBJ       -2141.96030903731
    x[788]    c879      -1
    x[788]    c880      1
    x[788]    c3722     -1
    x[788]    c4282     1
    x[788]    c4292     1
    x[788]    c4302     1
    x[788]    c4312     1
    x[788]    c4322     1
    x[788]    c4332     1
    x[788]    c4722     1432
    x[788]    c4723     -1432
    x[788]    c4732     1432
    x[788]    c4733     -1432
    x[788]    OBJ       -56952.442601975
    x[789]    c888      -1
    x[789]    c889      1
    x[789]    c3782     -1
    x[789]    c4302     -1
    x[789]    c4342     1
    x[789]    c4352     1
    x[789]    c4362     1
    x[789]    c4372     1
    x[789]    c4382     1
    x[789]    c4452     -1
    x[789]    c4722     2880
    x[789]    c4723     -2880
    x[789]    c4732     2880
    x[789]    c4733     -2880
    x[789]    OBJ       -86481.5250516663
    x[790]    c897      -1
    x[790]    c898      1
    x[790]    c2162     -1
    x[790]    c3872     -1
    x[790]    c4222     -1
    x[790]    c4362     -1
    x[790]    c4392     1
    x[790]    c4402     1
    x[790]    c4412     1
    x[790]    c4422     1
    x[790]    c4432     1
    x[790]    c4502     -1
    x[790]    c4722     2691
    x[790]    c4723     -2691
    x[790]    c4732     2691
    x[790]    c4733     -2691
    x[790]    OBJ       -29431.1418777188
    x[791]    c906      -1
    x[791]    c907      1
    x[791]    c2232     -1
    x[791]    c3922     -1
    x[791]    c4262     -1
    x[791]    c4412     -1
    x[791]    c4552     -1
    x[791]    c4642     -1
    x[791]    c4722     840
    x[791]    c4723     -840
    x[791]    c4732     543
    x[791]    c4733     -543
    x[791]    OBJ       -8589.38816198317
    x[792]    c915      -1
    x[792]    c916      1
    x[792]    c4442     1
    x[792]    c4452     1
    x[792]    c4462     1
    x[792]    c4472     1
    x[792]    c4482     1
    x[792]    c4722     716
    x[792]    c4723     -716
    x[792]    c4732     716
    x[792]    c4733     -716
    x[792]    OBJ       -28941.4390178566
    x[793]    c924      -1
    x[793]    c925      1
    x[793]    c2382     -1
    x[793]    c3962     -1
    x[793]    c4312     -1
    x[793]    c4462     -1
    x[793]    c4492     1
    x[793]    c4502     1
    x[793]    c4512     1
    x[793]    c4522     1
    x[793]    c4532     1
    x[793]    c4722     2148
    x[793]    c4723     -2148
    x[793]    c4732     2148
    x[793]    c4733     -2148
    x[793]    OBJ       -73455.4289793315
    x[794]    c933      -1
    x[794]    c934      1
    x[794]    c2452     -1
    x[794]    c4032     -1
    x[794]    c4372     -1
    x[794]    c4512     -1
    x[794]    c4542     1
    x[794]    c4552     1
    x[794]    c4562     1
    x[794]    c4572     1
    x[794]    c4582     1
    x[794]    c4722     2684
    x[794]    c4723     -2684
    x[794]    c4732     2680
    x[794]    c4733     -2680
    x[794]    OBJ       -64738.7180737841
    x[795]    c942      -1
    x[795]    c943      1
    x[795]    c2542     -1
    x[795]    c4082     -1
    x[795]    c4422     -1
    x[795]    c4562     -1
    x[795]    c4602     -1
    x[795]    c4682     -1
    x[795]    c4722     841
    x[795]    c4723     -841
    x[795]    c4732     480
    x[795]    c4733     -480
    x[795]    c4818     -1
    x[795]    OBJ       -15234.6559703134
    x[796]    c951      -1
    x[796]    c952      1
    x[796]    c2722     -1
    x[796]    c4522     -1
    x[796]    c4592     1
    x[796]    c4602     1
    x[796]    c4612     1
    x[796]    c4622     1
    x[796]    c4632     1
    x[796]    c4722     671
    x[796]    c4723     -671
    x[796]    c4732     670
    x[796]    c4733     -670
    x[796]    OBJ       -11556.9874927482
    x[797]    c960      -1
    x[797]    c961      1
    x[797]    c2802     -1
    x[797]    c4132     -1
    x[797]    c4572     -1
    x[797]    c4612     -1
    x[797]    c4722     754
    x[797]    c4723     -754
    x[797]    c4732     450
    x[797]    c4733     -450
    x[797]    OBJ       -13481.5197320067
    x[798]    c969      -1
    x[798]    c970      1
    x[798]    c2972     -1
    x[798]    c4622     -1
    x[798]    c4722     289
    x[798]    c4723     -289
    x[798]    c4732     186
    x[798]    c4733     -186
    x[798]    OBJ       -3589.52196279
    x[799]    c978      -1
    x[799]    c979      1
    x[799]    c3812     -1
    x[799]    c4182     -1
    x[799]    c4722     150
    x[799]    c4723     -150
    x[799]    OBJ       220.366286937994
    x[800]    c987      -1
    x[800]    c988      1
    x[800]    c3982     -1
    x[800]    c4272     -1
    x[800]    c4652     -1
    x[800]    c4722     315
    x[800]    c4723     -315
    x[800]    c4732     52
    x[800]    c4733     -52
    x[800]    OBJ       -86.6774061956112
    x[801]    c996      -1
    x[801]    c997      1
    x[801]    c4382     -1
    x[801]    c4642     1
    x[801]    c4652     1
    x[801]    c4662     1
    x[801]    c4672     1
    x[801]    c4722     1346
    x[801]    c4723     -1346
    x[801]    c4732     1322
    x[801]    c4733     -1322
    x[801]    OBJ       -9343.53056617096
    x[802]    c1005     -1
    x[802]    c1006     1
    x[802]    c3272     -1
    x[802]    c4432     -1
    x[802]    c4662     -1
    x[802]    c4692     -1
    x[802]    c4722     548
    x[802]    c4723     -548
    x[802]    c4732     133
    x[802]    c4733     -133
    x[802]    OBJ       -1402.01928778551
    x[803]    c1014     -1
    x[803]    c1015     1
    x[803]    c3442     -1
    x[803]    c4532     -1
    x[803]    c4682     1
    x[803]    c4692     1
    x[803]    c4702     1
    x[803]    c4712     1
    x[803]    c4722     672
    x[803]    c4723     -672
    x[803]    c4732     672
    x[803]    c4733     -672
    x[803]    OBJ       -8227.00804568513
    x[804]    c1023     -1
    x[804]    c1024     1
    x[804]    c3522     -1
    x[804]    c4582     -1
    x[804]    c4672     -1
    x[804]    c4702     -1
    x[804]    c4722     429
    x[804]    c4723     -429
    x[804]    c4732     142
    x[804]    c4733     -142
    x[804]    OBJ       -2967.59933076499
    x[805]    c1032     -1
    x[805]    c1033     1
    x[805]    c3822     -1
    x[805]    c4632     -1
    x[805]    c4712     -1
    x[805]    c4722     273
    x[805]    c4723     -273
    x[805]    c4732     94
    x[805]    c4733     -94
    x[805]    OBJ       -2761.92412962286
    x[806]    c7        -1
    x[806]    c8        1
    x[806]    c2393     -1
    x[806]    c4723     219
    x[806]    c4724     -219
    x[806]    c4733     75
    x[806]    c4734     -75
    x[806]    OBJ       -929.582073150381
    x[807]    c16       -1
    x[807]    c17       1
    x[807]    c1343     -1
    x[807]    c4723     328
    x[807]    c4724     -328
    x[807]    c4733     215
    x[807]    c4734     -215
    x[807]    OBJ       -1897.36614930694
    x[808]    c25       -1
    x[808]    c26       1
    x[808]    c1513     -1
    x[808]    c3673     -1
    x[808]    c4723     545
    x[808]    c4724     -545
    x[808]    c4733     368
    x[808]    c4734     -368
    x[808]    OBJ       -4333.80500770109
    x[809]    c34       -1
    x[809]    c35       1
    x[809]    c1073     -1
    x[809]    c1683     -1
    x[809]    c4723     435
    x[809]    c4724     -435
    x[809]    c4733     400
    x[809]    c4734     -400
    x[809]    OBJ       -6608.94652006915
    x[810]    c43       -1
    x[810]    c44       1
    x[810]    c1123     -1
    x[810]    c4723     247
    x[810]    c4724     -247
    x[810]    c4733     216
    x[810]    c4734     -216
    x[810]    OBJ       -2945.79889847655
    x[811]    c52       -1
    x[811]    c53       1
    x[811]    c1973     -1
    x[811]    c4723     82
    x[811]    c4724     -82
    x[811]    c4733     27
    x[811]    c4734     -27
    x[811]    OBJ       -309.436224350058
    x[812]    c61       -1
    x[812]    c62       1
    x[812]    c1083     -1
    x[812]    c1243     -1
    x[812]    c2513     -1
    x[812]    c4723     526
    x[812]    c4724     -526
    x[812]    c4733     314
    x[812]    c4734     -314
    x[812]    OBJ       -2867.27255896384
    x[813]    c70       -1
    x[813]    c71       1
    x[813]    c1043     1
    x[813]    c1053     1
    x[813]    c1063     1
    x[813]    c1293     -1
    x[813]    c4723     693
    x[813]    c4724     -693
    x[813]    c4733     693
    x[813]    c4734     -693
    x[813]    OBJ       -21944.9283935501
    x[814]    c79       -1
    x[814]    c80       1
    x[814]    c1043     -1
    x[814]    c1073     1
    x[814]    c1083     1
    x[814]    c1093     1
    x[814]    c1103     1
    x[814]    c1113     1
    x[814]    c1373     -1
    x[814]    c2703     -1
    x[814]    c4723     1944
    x[814]    c4724     -1944
    x[814]    c4733     1944
    x[814]    c4734     -1944
    x[814]    OBJ       -32811.275915308
    x[815]    c88       -1
    x[815]    c89       1
    x[815]    c1093     -1
    x[815]    c1133     -1
    x[815]    c1423     -1
    x[815]    c2783     -1
    x[815]    c4723     907
    x[815]    c4724     -907
    x[815]    c4733     574
    x[815]    c4734     -574
    x[815]    c4749     -1
    x[815]    OBJ       -9499.56474753677
    x[816]    c97       -1
    x[816]    c98       1
    x[816]    c1053     -1
    x[816]    c1123     1
    x[816]    c1133     1
    x[816]    c1143     1
    x[816]    c1153     1
    x[816]    c1163     1
    x[816]    c1543     -1
    x[816]    c4723     1296
    x[816]    c4724     -1296
    x[816]    c4733     1128
    x[816]    c4734     -1128
    x[816]    OBJ       -10460.5573564922
    x[817]    c106      -1
    x[817]    c107      1
    x[817]    c1103     -1
    x[817]    c1143     -1
    x[817]    c1173     -1
    x[817]    c1593     -1
    x[817]    c1983     -1
    x[817]    c2953     -1
    x[817]    c4723     1043
    x[817]    c4724     -1043
    x[817]    c4733     864
    x[817]    c4734     -864
    x[817]    OBJ       -8686.2865502052
    x[818]    c115      -1
    x[818]    c116      1
    x[818]    c1173     1
    x[818]    c1183     1
    x[818]    c1193     1
    x[818]    c1203     1
    x[818]    c1713     -1
    x[818]    c2153     -1
    x[818]    c4723     1332
    x[818]    c4724     -1332
    x[818]    c4733     1330
    x[818]    c4734     -1330
    x[818]    OBJ       -19907.4882332205
    x[819]    c124      -1
    x[819]    c125      1
    x[819]    c1153     -1
    x[819]    c1183     -1
    x[819]    c1763     -1
    x[819]    c2223     -1
    x[819]    c4723     1186
    x[819]    c4724     -1186
    x[819]    c4733     864
    x[819]    c4734     -864
    x[819]    OBJ       -12046.3649479488
    x[820]    c133      -1
    x[820]    c134      1
    x[820]    c1193     -1
    x[820]    c1843     -1
    x[820]    c2523     -1
    x[820]    c4723     984
    x[820]    c4724     -984
    x[820]    c4733     723
    x[820]    c4734     -723
    x[820]    c4790     -1
    x[820]    OBJ       -5980.73580396752
    x[821]    c142      -1
    x[821]    c143      1
    x[821]    c1253     -1
    x[821]    c1893     -1
    x[821]    c3253     -1
    x[821]    c4723     225
    x[821]    c4724     -225
    x[821]    c4733     20
    x[821]    c4734     -20
    x[821]    OBJ       24.194601903914
    x[822]    c151      -1
    x[822]    c152      1
    x[822]    c1213     1
    x[822]    c1223     1
    x[822]    c1233     1
    x[822]    c1303     -1
    x[822]    c1933     -1
    x[822]    c4723     724
    x[822]    c4724     -724
    x[822]    c4733     724
    x[822]    c4734     -724
    x[822]    OBJ       -16341.9679526437
    x[823]    c160      -1
    x[823]    c161      1
    x[823]    c1213     -1
    x[823]    c1243     1
    x[823]    c1253     1
    x[823]    c1263     1
    x[823]    c1273     1
    x[823]    c1283     1
    x[823]    c1383     -1
    x[823]    c2003     -1
    x[823]    c3423     -1
    x[823]    c4723     1989
    x[823]    c4724     -1989
    x[823]    c4733     1989
    x[823]    c4734     -1989
    x[823]    OBJ       -14168.6984482921
    x[824]    c169      -1
    x[824]    c170      1
    x[824]    c1263     -1
    x[824]    c1433     -1
    x[824]    c2053     -1
    x[824]    c3503     -1
    x[824]    c4723     710
    x[824]    c4724     -710
    x[824]    c4733     382
    x[824]    c4734     -382
    x[824]    OBJ       -3964.51897864135
    x[825]    c178      -1
    x[825]    c179      1
    x[825]    c1293     1
    x[825]    c1303     1
    x[825]    c1313     1
    x[825]    c1323     1
    x[825]    c1333     1
    x[825]    c1343     1
    x[825]    c1353     1
    x[825]    c1363     1
    x[825]    c2103     -1
    x[825]    c4723     716
    x[825]    c4724     -716
    x[825]    c4733     716
    x[825]    c4734     -716
    x[825]    c4812     1
    x[825]    OBJ       -24746.4086140033
    x[826]    c187      -1
    x[826]    c188      1
    x[826]    c1313     -1
    x[826]    c1373     1
    x[826]    c1383     1
    x[826]    c1393     1
    x[826]    c1403     1
    x[826]    c1413     1
    x[826]    c1473     -1
    x[826]    c2173     -1
    x[826]    c3663     -1
    x[826]    c4723     2876
    x[826]    c4724     -2876
    x[826]    c4733     2876
    x[826]    c4734     -2876
    x[826]    OBJ       -78271.6594926622
    x[827]    c196      -1
    x[827]    c197      1
    x[827]    c1063     -1
    x[827]    c1223     -1
    x[827]    c1393     -1
    x[827]    c1423     1
    x[827]    c1433     1
    x[827]    c1443     1
    x[827]    c1453     1
    x[827]    c1463     1
    x[827]    c1553     -1
    x[827]    c2243     -1
    x[827]    c3733     -1
    x[827]    c4723     2595
    x[827]    c4724     -2595
    x[827]    c4733     2595
    x[827]    c4734     -2595
    x[827]    c4860     -1
    x[827]    c4862     -1
    x[827]    OBJ       -16745.2113177089
    x[828]    c205      -1
    x[828]    c206      1
    x[828]    c1113     -1
    x[828]    c1273     -1
    x[828]    c1443     -1
    x[828]    c1603     -1
    x[828]    c2293     -1
    x[828]    c3793     -1
    x[828]    c4723     1030
    x[828]    c4724     -1030
    x[828]    c4733     552
    x[828]    c4734     -552
    x[828]    c4784     -1
    x[828]    OBJ       -2241.18417636256
    x[829]    c214      -1
    x[829]    c215      1
    x[829]    c1473     1
    x[829]    c1483     1
    x[829]    c1493     1
    x[829]    c1503     1
    x[829]    c1513     1
    x[829]    c1523     1
    x[829]    c1533     1
    x[829]    c2403     -1
    x[829]    c4723     1432
    x[829]    c4724     -1432
    x[829]    c4733     1432
    x[829]    c4734     -1432
    x[829]    OBJ       -45884.8502774229
    x[830]    c223      -1
    x[830]    c224      1
    x[830]    c1323     -1
    x[830]    c1483     -1
    x[830]    c1543     1
    x[830]    c1553     1
    x[830]    c1563     1
    x[830]    c1573     1
    x[830]    c1583     1
    x[830]    c1643     -1
    x[830]    c2463     -1
    x[830]    c4723     2864
    x[830]    c4724     -2864
    x[830]    c4733     2864
    x[830]    c4734     -2864
    x[830]    OBJ       -62863.5182801696
    x[831]    c232      -1
    x[831]    c233      1
    x[831]    c1403     -1
    x[831]    c1563     -1
    x[831]    c1593     1
    x[831]    c1603     1
    x[831]    c1613     1
    x[831]    c1623     1
    x[831]    c1633     1
    x[831]    c1723     -1
    x[831]    c2553     -1
    x[831]    c4723     2600
    x[831]    c4724     -2600
    x[831]    c4733     2336
    x[831]    c4734     -2336
    x[831]    c4736     -1
    x[831]    OBJ       -23999.3472218824
    x[832]    c241      -1
    x[832]    c242      1
    x[832]    c1163     -1
    x[832]    c1453     -1
    x[832]    c1613     -1
    x[832]    c1773     -1
    x[832]    c2603     -1
    x[832]    c3973     -1
    x[832]    c4723     1156
    x[832]    c4724     -1156
    x[832]    c4733     696
    x[832]    c4734     -696
    x[832]    c4891     -1
    x[832]    OBJ       -5564.75843790022
    x[833]    c250      -1
    x[833]    c251      1
    x[833]    c1643     1
    x[833]    c1653     1
    x[833]    c1663     1
    x[833]    c1673     1
    x[833]    c1683     1
    x[833]    c1693     1
    x[833]    c1703     1
    x[833]    c2653     -1
    x[833]    c4723     716
    x[833]    c4724     -716
    x[833]    c4733     716
    x[833]    c4734     -716
    x[833]    c4814     1
    x[833]    OBJ       -22963.6484737149
    x[834]    c259      -1
    x[834]    c260      1
    x[834]    c1493     -1
    x[834]    c1653     -1
    x[834]    c1713     1
    x[834]    c1723     1
    x[834]    c1733     1
    x[834]    c1743     1
    x[834]    c1753     1
    x[834]    c2733     -1
    x[834]    c4723     2864
    x[834]    c4724     -2864
    x[834]    c4733     2864
    x[834]    c4734     -2864
    x[834]    OBJ       -71267.9589415292
    x[835]    c268      -1
    x[835]    c269      1
    x[835]    c1573     -1
    x[835]    c1733     -1
    x[835]    c1763     1
    x[835]    c1773     1
    x[835]    c1783     1
    x[835]    c1793     1
    x[835]    c1803     1
    x[835]    c1813     -1
    x[835]    c2813     -1
    x[835]    c4723     2681
    x[835]    c4724     -2681
    x[835]    c4733     2678
    x[835]    c4734     -2678
    x[835]    OBJ       -66386.5918907395
    x[836]    c277      -1
    x[836]    c278      1
    x[836]    c1203     -1
    x[836]    c1623     -1
    x[836]    c1783     -1
    x[836]    c1853     -1
    x[836]    c2863     -1
    x[836]    c3263     -1
    x[836]    c4723     1263
    x[836]    c4724     -1263
    x[836]    c4733     864
    x[836]    c4734     -864
    x[836]    c4785     -1
    x[836]    OBJ       -23982.3685538797
    x[837]    c286      -1
    x[837]    c287      1
    x[837]    c1663     -1
    x[837]    c1813     1
    x[837]    c1823     1
    x[837]    c1833     1
    x[837]    c2913     -1
    x[837]    c4723     716
    x[837]    c4724     -716
    x[837]    c4733     716
    x[837]    c4734     -716
    x[837]    OBJ       -15535.4812225132
    x[838]    c295      -1
    x[838]    c296      1
    x[838]    c1743     -1
    x[838]    c1823     -1
    x[838]    c1843     1
    x[838]    c1853     1
    x[838]    c1863     1
    x[838]    c1873     1
    x[838]    c1883     1
    x[838]    c2983     -1
    x[838]    c3433     -1
    x[838]    c4723     1965
    x[838]    c4724     -1965
    x[838]    c4733     1964
    x[838]    c4734     -1964
    x[838]    OBJ       -27675.2288444771
    x[839]    c304      -1
    x[839]    c305      1
    x[839]    c1793     -1
    x[839]    c1863     -1
    x[839]    c3033     -1
    x[839]    c3513     -1
    x[839]    c4723     1245
    x[839]    c4724     -1245
    x[839]    c4733     889
    x[839]    c4734     -889
    x[839]    c4752     -1
    x[839]    OBJ       -13442.8603911747
    x[840]    c313      -1
    x[840]    c314      1
    x[840]    c1873     -1
    x[840]    c3083     -1
    x[840]    c3803     -1
    x[840]    c4723     832
    x[840]    c4724     -832
    x[840]    c4733     647
    x[840]    c4734     -647
    x[840]    OBJ       -4029.88685045192
    x[841]    c322      -1
    x[841]    c323      1
    x[841]    c4723     339
    x[841]    c4724     -339
    x[841]    c4733     283
    x[841]    c4734     -283
    x[841]    OBJ       -2372.76885338385
    x[842]    c331      -1
    x[842]    c332      1
    x[842]    c1893     1
    x[842]    c1903     1
    x[842]    c1913     1
    x[842]    c1923     1
    x[842]    c2013     -1
    x[842]    c4723     1346
    x[842]    c4724     -1346
    x[842]    c4733     1346
    x[842]    c4734     -1346
    x[842]    OBJ       -19483.0215331518
    x[843]    c340      -1
    x[843]    c341      1
    x[843]    c1903     -1
    x[843]    c2063     -1
    x[843]    c4723     243
    x[843]    c4724     -243
    x[843]    OBJ       308.502397609907
    x[844]    c349      -1
    x[844]    c350      1
    x[844]    c1933     1
    x[844]    c1943     1
    x[844]    c1953     1
    x[844]    c1963     1
    x[844]    c1973     1
    x[844]    c1983     1
    x[844]    c1993     1
    x[844]    c2113     -1
    x[844]    c4723     724
    x[844]    c4724     -724
    x[844]    c4733     724
    x[844]    c4734     -724
    x[844]    OBJ       -22369.3950936187
    x[845]    c358      -1
    x[845]    c359      1
    x[845]    c1943     -1
    x[845]    c2003     1
    x[845]    c2013     1
    x[845]    c2023     1
    x[845]    c2033     1
    x[845]    c2043     1
    x[845]    c2183     -1
    x[845]    c4723     2896
    x[845]    c4724     -2896
    x[845]    c4733     2896
    x[845]    c4734     -2896
    x[845]    OBJ       -69188.0721111927
    x[846]    c367      -1
    x[846]    c368      1
    x[846]    c1233     -1
    x[846]    c2023     -1
    x[846]    c2053     1
    x[846]    c2063     1
    x[846]    c2073     1
    x[846]    c2083     1
    x[846]    c2093     1
    x[846]    c2253     -1
    x[846]    c3133     -1
    x[846]    c4723     2692
    x[846]    c4724     -2692
    x[846]    c4733     2692
    x[846]    c4734     -2692
    x[846]    OBJ       -34594.0360555963
    x[847]    c376      -1
    x[847]    c377      1
    x[847]    c1283     -1
    x[847]    c1913     -1
    x[847]    c2073     -1
    x[847]    c2303     -1
    x[847]    c3163     -1
    x[847]    c4723     755
    x[847]    c4724     -755
    x[847]    c4733     323
    x[847]    c4734     -323
    x[847]    c4743     -1
    x[847]    OBJ       -2919.05749637222
    x[848]    c385      -1
    x[848]    c386      1
    x[848]    c2103     1
    x[848]    c2113     1
    x[848]    c2123     1
    x[848]    c2133     1
    x[848]    c2143     1
    x[848]    c2153     1
    x[848]    c2163     1
    x[848]    c2343     -1
    x[848]    c4723     1432
    x[848]    c4724     -1432
    x[848]    c4733     1432
    x[848]    c4734     -1432
    x[848]    OBJ       -47243.1437176426
    x[849]    c394      -1
    x[849]    c395      1
    x[849]    c2123     -1
    x[849]    c2173     1
    x[849]    c2183     1
    x[849]    c2193     1
    x[849]    c2203     1
    x[849]    c2213     1
    x[849]    c2223     1
    x[849]    c2233     1
    x[849]    c2413     -1
    x[849]    c4723     2886
    x[849]    c4724     -2886
    x[849]    c4733     2886
    x[849]    c4734     -2886
    x[849]    c4813     1
    x[849]    OBJ       -89010.6670043995
    x[850]    c403      -1
    x[850]    c404      1
    x[850]    c1333     -1
    x[850]    c1953     -1
    x[850]    c2193     -1
    x[850]    c2243     1
    x[850]    c2253     1
    x[850]    c2263     1
    x[850]    c2273     1
    x[850]    c2283     1
    x[850]    c2473     -1
    x[850]    c3213     -1
    x[850]    c4723     2895
    x[850]    c4724     -2895
    x[850]    c4733     2895
    x[850]    c4734     -2895
    x[850]    c4959     -1
    x[850]    OBJ       -74069.4391619824
    x[851]    c412      -1
    x[851]    c413      1
    x[851]    c1413     -1
    x[851]    c2033     -1
    x[851]    c2263     -1
    x[851]    c2293     1
    x[851]    c2303     1
    x[851]    c2313     1
    x[851]    c2323     1
    x[851]    c2333     1
    x[851]    c2563     -1
    x[851]    c3283     -1
    x[851]    c4723     2692
    x[851]    c4724     -2692
    x[851]    c4733     2668
    x[851]    c4734     -2668
    x[851]    OBJ       -29075.9689547037
    x[852]    c421      -1
    x[852]    c422      1
    x[852]    c1463     -1
    x[852]    c2083     -1
    x[852]    c2313     -1
    x[852]    c2613     -1
    x[852]    c3333     -1
    x[852]    c4323     -1
    x[852]    c4723     1115
    x[852]    c4724     -1115
    x[852]    c4733     408
    x[852]    c4734     -408
    x[852]    c4786     -1
    x[852]    OBJ       -2140.58556844629
    x[853]    c430      -1
    x[853]    c431      1
    x[853]    c2343     1
    x[853]    c2353     1
    x[853]    c2363     1
    x[853]    c2373     1
    x[853]    c2383     1
    x[853]    c2393     1
    x[853]    c4723     1432
    x[853]    c4724     -1432
    x[853]    c4733     1432
    x[853]    c4734     -1432
    x[853]    c4931     1
    x[853]    OBJ       -53907.2709087207
    x[854]    c439      -1
    x[854]    c440      1
    x[854]    c2353     -1
    x[854]    c2403     1
    x[854]    c2413     1
    x[854]    c2423     1
    x[854]    c2433     1
    x[854]    c2443     1
    x[854]    c2453     1
    x[854]    c4723     2864
    x[854]    c4724     -2864
    x[854]    c4733     2864
    x[854]    c4734     -2864
    x[854]    OBJ       -98646.0610959582
    x[855]    c448      -1
    x[855]    c449      1
    x[855]    c2133     -1
    x[855]    c2423     -1
    x[855]    c2463     1
    x[855]    c2473     1
    x[855]    c2483     1
    x[855]    c2493     1
    x[855]    c2503     1
    x[855]    c2513     1
    x[855]    c2523     1
    x[855]    c2533     1
    x[855]    c2543     1
    x[855]    c2663     -1
    x[855]    c3383     -1
    x[855]    c4723     2864
    x[855]    c4724     -2864
    x[855]    c4733     2864
    x[855]    c4734     -2864
    x[855]    c4736     1
    x[855]    c4743     1
    x[855]    c4744     1
    x[855]    c4749     1
    x[855]    c4752     1
    x[855]    OBJ       -93170.4406650724
    x[856]    c457      -1
    x[856]    c458      1
    x[856]    c1503     -1
    x[856]    c2203     -1
    x[856]    c2483     -1
    x[856]    c2553     1
    x[856]    c2563     1
    x[856]    c2573     1
    x[856]    c2583     1
    x[856]    c2593     1
    x[856]    c2743     -1
    x[856]    c3453     -1
    x[856]    c4723     2873
    x[856]    c4724     -2873
    x[856]    c4733     2873
    x[856]    c4734     -2873
    x[856]    OBJ       -71649.9789715909
    x[857]    c466      -1
    x[857]    c467      1
    x[857]    c1583     -1
    x[857]    c2273     -1
    x[857]    c2573     -1
    x[857]    c2603     1
    x[857]    c2613     1
    x[857]    c2623     1
    x[857]    c2633     1
    x[857]    c2643     1
    x[857]    c2823     -1
    x[857]    c3533     -1
    x[857]    c4723     2679
    x[857]    c4724     -2679
    x[857]    c4733     2604
    x[857]    c4734     -2604
    x[857]    c4812     -1
    x[857]    c4813     -1
    x[857]    c4814     -1
    x[857]    OBJ       -24886.4826250259
    x[858]    c475      -1
    x[858]    c476      1
    x[858]    c1633     -1
    x[858]    c2323     -1
    x[858]    c2623     -1
    x[858]    c2873     -1
    x[858]    c3583     -1
    x[858]    c4473     -1
    x[858]    c4723     1252
    x[858]    c4724     -1252
    x[858]    c4733     552
    x[858]    c4734     -552
    x[858]    c4975     -1
    x[858]    OBJ       -4903.86378589331
    x[859]    c484      -1
    x[859]    c485      1
    x[859]    c2363     -1
    x[859]    c2653     1
    x[859]    c2663     1
    x[859]    c2673     1
    x[859]    c2683     1
    x[859]    c2693     1
    x[859]    c2703     1
    x[859]    c2713     1
    x[859]    c2723     1
    x[859]    c3633     -1
    x[859]    c4723     2148
    x[859]    c4724     -2148
    x[859]    c4733     2148
    x[859]    c4734     -2148
    x[859]    c4860     1
    x[859]    OBJ       -65410.3184805816
    x[860]    c493      -1
    x[860]    c494      1
    x[860]    c2433     -1
    x[860]    c2673     -1
    x[860]    c2733     1
    x[860]    c2743     1
    x[860]    c2753     1
    x[860]    c2763     1
    x[860]    c2773     1
    x[860]    c2783     1
    x[860]    c2793     1
    x[860]    c2803     1
    x[860]    c3683     -1
    x[860]    c4723     2864
    x[860]    c4724     -2864
    x[860]    c4733     2864
    x[860]    c4734     -2864
    x[860]    c4776     1
    x[860]    c4784     1
    x[860]    c4785     1
    x[860]    c4786     1
    x[860]    c4787     1
    x[860]    c4789     -1
    x[860]    c4790     1
    x[860]    OBJ       -85360.2533838089
    x[861]    c502      -1
    x[861]    c503      1
    x[861]    c1673     -1
    x[861]    c2493     -1
    x[861]    c2753     -1
    x[861]    c2813     1
    x[861]    c2823     1
    x[861]    c2833     1
    x[861]    c2843     1
    x[861]    c2853     1
    x[861]    c2923     -1
    x[861]    c3743     -1
    x[861]    c4723     2864
    x[861]    c4724     -2864
    x[861]    c4733     2864
    x[861]    c4734     -2864
    x[861]    c4929     -1
    x[861]    c4931     -1
    x[861]    c4933     1
    x[861]    c4937     1
    x[861]    OBJ       -78101.8728126347
    x[862]    c511      -1
    x[862]    c512      1
    x[862]    c1753     -1
    x[862]    c2583     -1
    x[862]    c2833     -1
    x[862]    c2863     1
    x[862]    c2873     1
    x[862]    c2883     1
    x[862]    c2893     1
    x[862]    c2903     1
    x[862]    c2993     -1
    x[862]    c3833     -1
    x[862]    c4723     2684
    x[862]    c4724     -2684
    x[862]    c4733     2680
    x[862]    c4734     -2680
    x[862]    c4832     -1
    x[862]    OBJ       -66386.5918907395
    x[863]    c520      -1
    x[863]    c521      1
    x[863]    c1803     -1
    x[863]    c2633     -1
    x[863]    c2883     -1
    x[863]    c3043     -1
    x[863]    c3883     -1
    x[863]    c4723     1253
    x[863]    c4724     -1253
    x[863]    c4733     840
    x[863]    c4734     -840
    x[863]    c4744     -1
    x[863]    OBJ       -18336.9614429664
    x[864]    c529      -1
    x[864]    c530      1
    x[864]    c2683     -1
    x[864]    c2913     1
    x[864]    c2923     1
    x[864]    c2933     1
    x[864]    c2943     1
    x[864]    c2953     1
    x[864]    c2963     1
    x[864]    c2973     1
    x[864]    c4723     716
    x[864]    c4724     -716
    x[864]    c4733     716
    x[864]    c4734     -716
    x[864]    OBJ       -24619.0686039827
    x[865]    c538      -1
    x[865]    c539      1
    x[865]    c2763     -1
    x[865]    c2933     -1
    x[865]    c2983     1
    x[865]    c2993     1
    x[865]    c3003     1
    x[865]    c3013     1
    x[865]    c3023     1
    x[865]    c3933     -1
    x[865]    c4723     2864
    x[865]    c4724     -2864
    x[865]    c4733     2864
    x[865]    c4734     -2864
    x[865]    OBJ       -68593.8187310966
    x[866]    c547      -1
    x[866]    c548      1
    x[866]    c1833     -1
    x[866]    c2843     -1
    x[866]    c3003     -1
    x[866]    c3033     1
    x[866]    c3043     1
    x[866]    c3053     1
    x[866]    c3063     1
    x[866]    c3073     1
    x[866]    c3993     -1
    x[866]    c4723     2651
    x[866]    c4724     -2651
    x[866]    c4733     2650
    x[866]    c4734     -2650
    x[866]    c4962     -1
    x[866]    OBJ       -52803.6574885421
    x[867]    c556      -1
    x[867]    c557      1
    x[867]    c1883     -1
    x[867]    c2893     -1
    x[867]    c3053     -1
    x[867]    c3093     -1
    x[867]    c4043     -1
    x[867]    c4723     1175
    x[867]    c4724     -1175
    x[867]    c4733     768
    x[867]    c4734     -768
    x[867]    OBJ       -16189.1599406189
    x[868]    c565      -1
    x[868]    c566      1
    x[868]    c3013     -1
    x[868]    c3083     1
    x[868]    c3093     1
    x[868]    c3103     1
    x[868]    c3113     1
    x[868]    c3123     1
    x[868]    c4723     1333
    x[868]    c4724     -1333
    x[868]    c4733     1332
    x[868]    c4734     -1332
    x[868]    c4787     -1
    x[868]    OBJ       -18549.1947930007
    x[869]    c574      -1
    x[869]    c575      1
    x[869]    c3063     -1
    x[869]    c3103     -1
    x[869]    c4093     -1
    x[869]    c4333     -1
    x[869]    c4723     940
    x[869]    c4724     -940
    x[869]    c4733     728
    x[869]    c4734     -728
    x[869]    c4937     -1
    x[869]    OBJ       -12717.0223340573
    x[870]    c583      -1
    x[870]    c584      1
    x[870]    c3113     -1
    x[870]    c4483     -1
    x[870]    c4723     342
    x[870]    c4724     -342
    x[870]    c4733     317
    x[870]    c4734     -317
    x[870]    OBJ       -3141.05358050813
    x[871]    c592      -1
    x[871]    c593      1
    x[871]    c1353     -1
    x[871]    c1923     -1
    x[871]    c3173     -1
    x[871]    c4723     187
    x[871]    c4724     -187
    x[871]    OBJ       234.178278427883
    x[872]    c601      -1
    x[872]    c602      1
    x[872]    c1963     -1
    x[872]    c3133     1
    x[872]    c3143     1
    x[872]    c3153     1
    x[872]    c3223     -1
    x[872]    c4723     724
    x[872]    c4724     -724
    x[872]    c4733     724
    x[872]    c4734     -724
    x[872]    OBJ       -12564.2143220325
    x[873]    c610      -1
    x[873]    c611      1
    x[873]    c2043     -1
    x[873]    c3143     -1
    x[873]    c3163     1
    x[873]    c3173     1
    x[873]    c3183     1
    x[873]    c3193     1
    x[873]    c3203     1
    x[873]    c3293     -1
    x[873]    c4723     2019
    x[873]    c4724     -2019
    x[873]    c4733     1995
    x[873]    c4734     -1995
    x[873]    OBJ       -14720.5051583814
    x[874]    c619      -1
    x[874]    c620      1
    x[874]    c1523     -1
    x[874]    c2093     -1
    x[874]    c3183     -1
    x[874]    c3343     -1
    x[874]    c4723     660
    x[874]    c4724     -660
    x[874]    c4733     174
    x[874]    c4734     -174
    x[874]    c4978     -1
    x[874]    OBJ       -1700.41360047508
    x[875]    c628      -1
    x[875]    c629      1
    x[875]    c2143     -1
    x[875]    c3213     1
    x[875]    c3223     1
    x[875]    c3233     1
    x[875]    c3243     1
    x[875]    c3253     1
    x[875]    c3263     1
    x[875]    c3273     1
    x[875]    c3393     -1
    x[875]    c4723     1447
    x[875]    c4724     -1447
    x[875]    c4733     1447
    x[875]    c4734     -1447
    x[875]    c4862     1
    x[875]    OBJ       -37437.9629460564
    x[876]    c637      -1
    x[876]    c638      1
    x[876]    c2213     -1
    x[876]    c3233     -1
    x[876]    c3283     1
    x[876]    c3293     1
    x[876]    c3303     1
    x[876]    c3313     1
    x[876]    c3323     1
    x[876]    c3463     -1
    x[876]    c4723     2896
    x[876]    c4724     -2896
    x[876]    c4733     2896
    x[876]    c4734     -2896
    x[876]    OBJ       -50511.5373081714
    x[877]    c646      -1
    x[877]    c647      1
    x[877]    c2283     -1
    x[877]    c3153     -1
    x[877]    c3303     -1
    x[877]    c3333     1
    x[877]    c3343     1
    x[877]    c3353     1
    x[877]    c3363     1
    x[877]    c3373     1
    x[877]    c3543     -1
    x[877]    c4723     2692
    x[877]    c4724     -2692
    x[877]    c4733     2692
    x[877]    c4734     -2692
    x[877]    OBJ       -20603.6136213331
    x[878]    c655      -1
    x[878]    c656      1
    x[878]    c1693     -1
    x[878]    c2333     -1
    x[878]    c3193     -1
    x[878]    c3353     -1
    x[878]    c3593     -1
    x[878]    c4143     -1
    x[878]    c4723     964
    x[878]    c4724     -964
    x[878]    c4733     288
    x[878]    c4734     -288
    x[878]    c4836     -1
    x[878]    OBJ       -1657.54246376814
    x[879]    c664      -1
    x[879]    c665      1
    x[879]    c2373     -1
    x[879]    c3383     1
    x[879]    c3393     1
    x[879]    c3403     1
    x[879]    c3413     1
    x[879]    c3423     1
    x[879]    c3433     1
    x[879]    c3443     1
    x[879]    c3643     -1
    x[879]    c4723     1432
    x[879]    c4724     -1432
    x[879]    c4733     1432
    x[879]    c4734     -1432
    x[879]    c4741     1
    x[879]    OBJ       -47879.8437677457
    x[880]    c673      -1
    x[880]    c674      1
    x[880]    c2443     -1
    x[880]    c3403     -1
    x[880]    c3453     1
    x[880]    c3463     1
    x[880]    c3473     1
    x[880]    c3483     1
    x[880]    c3493     1
    x[880]    c3503     1
    x[880]    c3513     1
    x[880]    c3523     1
    x[880]    c3693     -1
    x[880]    c4723     2872
    x[880]    c4724     -2872
    x[880]    c4733     2872
    x[880]    c4734     -2872
    x[880]    c4886     1
    x[880]    c4891     1
    x[880]    OBJ       -78908.3595427652
    x[881]    c682      -1
    x[881]    c683      1
    x[881]    c2503     -1
    x[881]    c3243     -1
    x[881]    c3473     -1
    x[881]    c3533     1
    x[881]    c3543     1
    x[881]    c3553     1
    x[881]    c3563     1
    x[881]    c3573     1
    x[881]    c3753     -1
    x[881]    c4723     2888
    x[881]    c4724     -2888
    x[881]    c4733     2888
    x[881]    c4734     -2888
    x[881]    OBJ       -60953.4181298605
    x[882]    c691      -1
    x[882]    c692      1
    x[882]    c2593     -1
    x[882]    c3313     -1
    x[882]    c3553     -1
    x[882]    c3583     1
    x[882]    c3593     1
    x[882]    c3603     1
    x[882]    c3613     1
    x[882]    c3623     1
    x[882]    c3843     -1
    x[882]    c4193     -1
    x[882]    c4723     2692
    x[882]    c4724     -2692
    x[882]    c4733     2692
    x[882]    c4734     -2692
    x[882]    c4960     -1
    x[882]    OBJ       -28778.8422646556
    x[883]    c700      -1
    x[883]    c701      1
    x[883]    c2643     -1
    x[883]    c3363     -1
    x[883]    c3603     -1
    x[883]    c3893     -1
    x[883]    c4233     -1
    x[883]    c4723     1168
    x[883]    c4724     -1168
    x[883]    c4733     528
    x[883]    c4734     -528
    x[883]    OBJ       -5501.08843288993
    x[884]    c709      -1
    x[884]    c710      1
    x[884]    c3633     1
    x[884]    c3643     1
    x[884]    c3653     1
    x[884]    c3663     1
    x[884]    c3673     1
    x[884]    c4723     716
    x[884]    c4724     -716
    x[884]    c4733     716
    x[884]    c4734     -716
    x[884]    c4789     1
    x[884]    OBJ       -28354.375564587
    x[885]    c718      -1
    x[885]    c719      1
    x[885]    c3653     -1
    x[885]    c3683     1
    x[885]    c3693     1
    x[885]    c3703     1
    x[885]    c3713     1
    x[885]    c3723     1
    x[885]    c3733     1
    x[885]    c4723     2864
    x[885]    c4724     -2864
    x[885]    c4733     2864
    x[885]    c4734     -2864
    x[885]    c4929     1
    x[885]    OBJ       -98136.7010558757
    x[886]    c727      -1
    x[886]    c728      1
    x[886]    c2693     -1
    x[886]    c3413     -1
    x[886]    c3703     -1
    x[886]    c3743     1
    x[886]    c3753     1
    x[886]    c3763     1
    x[886]    c3773     1
    x[886]    c3783     1
    x[886]    c3793     1
    x[886]    c3803     1
    x[886]    c3813     1
    x[886]    c3823     1
    x[886]    c4723     2864
    x[886]    c4724     -2864
    x[886]    c4733     2864
    x[886]    c4734     -2864
    x[886]    c4832     1
    x[886]    c4836     1
    x[886]    c4837     1
    x[886]    c4838     1
    x[886]    c4839     1
    x[886]    OBJ       -99579.8878361093
    x[887]    c736      -1
    x[887]    c737      1
    x[887]    c2773     -1
    x[887]    c3483     -1
    x[887]    c3763     -1
    x[887]    c3833     1
    x[887]    c3843     1
    x[887]    c3853     1
    x[887]    c3863     1
    x[887]    c3873     1
    x[887]    c3943     -1
    x[887]    c4283     -1
    x[887]    c4723     2865
    x[887]    c4724     -2865
    x[887]    c4733     2865
    x[887]    c4734     -2865
    x[887]    c4741     -1
    x[887]    OBJ       -95335.2208354225
    x[888]    c745      -1
    x[888]    c746      1
    x[888]    c2853     -1
    x[888]    c3563     -1
    x[888]    c3853     -1
    x[888]    c3883     1
    x[888]    c3893     1
    x[888]    c3903     1
    x[888]    c3913     1
    x[888]    c3923     1
    x[888]    c4003     -1
    x[888]    c4343     -1
    x[888]    c4723     2686
    x[888]    c4724     -2686
    x[888]    c4733     2684
    x[888]    c4734     -2684
    x[888]    c4886     -1
    x[888]    OBJ       -56114.4977490778
    x[889]    c754      -1
    x[889]    c755      1
    x[889]    c1363     -1
    x[889]    c2903     -1
    x[889]    c3613     -1
    x[889]    c3903     -1
    x[889]    c4053     -1
    x[889]    c4393     -1
    x[889]    c4723     1152
    x[889]    c4724     -1152
    x[889]    c4733     624
    x[889]    c4734     -624
    x[889]    OBJ       -10989.4428647778
    x[890]    c763      -1
    x[890]    c764      1
    x[890]    c3713     -1
    x[890]    c3933     1
    x[890]    c3943     1
    x[890]    c3953     1
    x[890]    c3963     1
    x[890]    c3973     1
    x[890]    c3983     1
    x[890]    c4723     1432
    x[890]    c4724     -1432
    x[890]    c4733     1432
    x[890]    c4734     -1432
    x[890]    OBJ       -50426.6439681576
    x[891]    c772      -1
    x[891]    c773      1
    x[891]    c2943     -1
    x[891]    c3773     -1
    x[891]    c3953     -1
    x[891]    c3993     1
    x[891]    c4003     1
    x[891]    c4013     1
    x[891]    c4023     1
    x[891]    c4033     1
    x[891]    c4443     -1
    x[891]    c4723     2864
    x[891]    c4724     -2864
    x[891]    c4733     2864
    x[891]    c4734     -2864
    x[891]    OBJ       -72371.5723617077
    x[892]    c781      -1
    x[892]    c782      1
    x[892]    c3023     -1
    x[892]    c3863     -1
    x[892]    c4013     -1
    x[892]    c4043     1
    x[892]    c4053     1
    x[892]    c4063     1
    x[892]    c4073     1
    x[892]    c4083     1
    x[892]    c4493     -1
    x[892]    c4723     2684
    x[892]    c4724     -2684
    x[892]    c4733     2680
    x[892]    c4734     -2680
    x[892]    c4776     -1
    x[892]    OBJ       -50553.9839781782
    x[893]    c790      -1
    x[893]    c791      1
    x[893]    c1533     -1
    x[893]    c3073     -1
    x[893]    c3913     -1
    x[893]    c4063     -1
    x[893]    c4103     -1
    x[893]    c4543     -1
    x[893]    c4723     1099
    x[893]    c4724     -1099
    x[893]    c4733     672
    x[893]    c4734     -672
    x[893]    c4933     -1
    x[893]    OBJ       -15718.0019035427
    x[894]    c799      -1
    x[894]    c800      1
    x[894]    c4023     -1
    x[894]    c4093     1
    x[894]    c4103     1
    x[894]    c4113     1
    x[894]    c4123     1
    x[894]    c4133     1
    x[894]    c4723     1342
    x[894]    c4724     -1342
    x[894]    c4733     1340
    x[894]    c4734     -1340
    x[894]    c4837     -1
    x[894]    OBJ       -11969.9609419364
    x[895]    c808      -1
    x[895]    c809      1
    x[895]    c1703     -1
    x[895]    c3123     -1
    x[895]    c4073     -1
    x[895]    c4113     -1
    x[895]    c4593     -1
    x[895]    c4723     880
    x[895]    c4724     -880
    x[895]    c4733     629
    x[895]    c4734     -629
    x[895]    OBJ       -9198.19339048801
    x[896]    c817      -1
    x[896]    c818      1
    x[896]    c4123     -1
    x[896]    c4723     326
    x[896]    c4724     -326
    x[896]    c4733     256
    x[896]    c4734     -256
    x[896]    OBJ       -3399.97826755002
    x[897]    c826      -1
    x[897]    c827      1
    x[897]    c2533     -1
    x[897]    c3203     -1
    x[897]    c4153     -1
    x[897]    c4723     360
    x[897]    c4724     -360
    x[897]    OBJ       457.575102674023
    x[898]    c835      -1
    x[898]    c836      1
    x[898]    c2713     -1
    x[898]    c3323     -1
    x[898]    c4143     1
    x[898]    c4153     1
    x[898]    c4163     1
    x[898]    c4173     1
    x[898]    c4183     1
    x[898]    c4203     -1
    x[898]    c4723     1346
    x[898]    c4724     -1346
    x[898]    c4733     1322
    x[898]    c4734     -1322
    x[898]    OBJ       -5454.39709588237
    x[899]    c844      -1
    x[899]    c845      1
    x[899]    c2793     -1
    x[899]    c3373     -1
    x[899]    c4163     -1
    x[899]    c4243     -1
    x[899]    c4723     689
    x[899]    c4724     -689
    x[899]    c4733     241
    x[899]    c4734     -241
    x[899]    OBJ       -2216.56510775858
    x[900]    c853      -1
    x[900]    c854      1
    x[900]    c3493     -1
    x[900]    c4193     1
    x[900]    c4203     1
    x[900]    c4213     1
    x[900]    c4223     1
    x[900]    c4293     -1
    x[900]    c4723     1448
    x[900]    c4724     -1448
    x[900]    c4733     1448
    x[900]    c4734     -1448
    x[900]    OBJ       -20841.3149733715
    x[901]    c862      -1
    x[901]    c863      1
    x[901]    c3573     -1
    x[901]    c4213     -1
    x[901]    c4233     1
    x[901]    c4243     1
    x[901]    c4253     1
    x[901]    c4263     1
    x[901]    c4273     1
    x[901]    c4353     -1
    x[901]    c4723     2692
    x[901]    c4724     -2692
    x[901]    c4733     2668
    x[901]    c4734     -2668
    x[901]    OBJ       -12071.8329499529
    x[902]    c871      -1
    x[902]    c872      1
    x[902]    c1993     -1
    x[902]    c2963     -1
    x[902]    c3623     -1
    x[902]    c4173     -1
    x[902]    c4253     -1
    x[902]    c4403     -1
    x[902]    c4723     828
    x[902]    c4724     -828
    x[902]    c4733     291
    x[902]    c4734     -291
    x[902]    c4838     -1
    x[902]    OBJ       -1856.61734610035
    x[903]    c880      -1
    x[903]    c881      1
    x[903]    c3723     -1
    x[903]    c4283     1
    x[903]    c4293     1
    x[903]    c4303     1
    x[903]    c4313     1
    x[903]    c4323     1
    x[903]    c4333     1
    x[903]    c4723     1432
    x[903]    c4724     -1432
    x[903]    c4733     1432
    x[903]    c4734     -1432
    x[903]    OBJ       -49365.477217986
    x[904]    c889      -1
    x[904]    c890      1
    x[904]    c3783     -1
    x[904]    c4303     -1
    x[904]    c4343     1
    x[904]    c4353     1
    x[904]    c4363     1
    x[904]    c4373     1
    x[904]    c4383     1
    x[904]    c4453     -1
    x[904]    c4723     2880
    x[904]    c4724     -2880
    x[904]    c4733     2880
    x[904]    c4734     -2880
    x[904]    OBJ       -74960.8192321265
    x[905]    c898      -1
    x[905]    c899      1
    x[905]    c2163     -1
    x[905]    c3873     -1
    x[905]    c4223     -1
    x[905]    c4363     -1
    x[905]    c4393     1
    x[905]    c4403     1
    x[905]    c4413     1
    x[905]    c4423     1
    x[905]    c4433     1
    x[905]    c4503     -1
    x[905]    c4723     2691
    x[905]    c4724     -2691
    x[905]    c4733     2691
    x[905]    c4734     -2691
    x[905]    OBJ       -25510.4486741269
    x[906]    c907      -1
    x[906]    c908      1
    x[906]    c2233     -1
    x[906]    c3923     -1
    x[906]    c4263     -1
    x[906]    c4413     -1
    x[906]    c4553     -1
    x[906]    c4643     -1
    x[906]    c4723     840
    x[906]    c4724     -840
    x[906]    c4733     543
    x[906]    c4734     -543
    x[906]    c4976     -1
    x[906]    OBJ       -7445.14591920442
    x[907]    c916      -1
    x[907]    c917      1
    x[907]    c4443     1
    x[907]    c4453     1
    x[907]    c4463     1
    x[907]    c4473     1
    x[907]    c4483     1
    x[907]    c4723     716
    x[907]    c4724     -716
    x[907]    c4733     716
    x[907]    c4734     -716
    x[907]    OBJ       -25085.9819740582
    x[908]    c925      -1
    x[908]    c926      1
    x[908]    c2383     -1
    x[908]    c3963     -1
    x[908]    c4313     -1
    x[908]    c4463     -1
    x[908]    c4493     1
    x[908]    c4503     1
    x[908]    c4513     1
    x[908]    c4523     1
    x[908]    c4533     1
    x[908]    c4723     2148
    x[908]    c4724     -2148
    x[908]    c4733     2148
    x[908]    c4734     -2148
    x[908]    OBJ       -63670.0050103
    x[909]    c934      -1
    x[909]    c935      1
    x[909]    c2453     -1
    x[909]    c4033     -1
    x[909]    c4373     -1
    x[909]    c4513     -1
    x[909]    c4543     1
    x[909]    c4553     1
    x[909]    c4563     1
    x[909]    c4573     1
    x[909]    c4583     1
    x[909]    c4723     2684
    x[909]    c4724     -2684
    x[909]    c4733     2680
    x[909]    c4734     -2680
    x[909]    OBJ       -56114.4977490778
    x[910]    c943      -1
    x[910]    c944      1
    x[910]    c2543     -1
    x[910]    c4083     -1
    x[910]    c4423     -1
    x[910]    c4563     -1
    x[910]    c4603     -1
    x[910]    c4683     -1
    x[910]    c4723     841
    x[910]    c4724     -841
    x[910]    c4733     480
    x[910]    c4734     -480
    x[910]    c4839     -1
    x[910]    OBJ       -13205.1590391362
    x[911]    c952      -1
    x[911]    c953      1
    x[911]    c2723     -1
    x[911]    c4523     -1
    x[911]    c4593     1
    x[911]    c4603     1
    x[911]    c4613     1
    x[911]    c4623     1
    x[911]    c4633     1
    x[911]    c4723     671
    x[911]    c4724     -671
    x[911]    c4733     670
    x[911]    c4734     -670
    x[911]    OBJ       -10017.4141216205
    x[912]    c961      -1
    x[912]    c962      1
    x[912]    c2803     -1
    x[912]    c4133     -1
    x[912]    c4573     -1
    x[912]    c4613     -1
    x[912]    c4723     754
    x[912]    c4724     -754
    x[912]    c4733     450
    x[912]    c4734     -450
    x[912]    OBJ       -11685.5682528904
    x[913]    c970      -1
    x[913]    c971      1
    x[913]    c2973     -1
    x[913]    c4623     -1
    x[913]    c4723     289
    x[913]    c4724     -289
    x[913]    c4733     186
    x[913]    c4734     -186
    x[913]    OBJ       -3111.34091150333
    x[914]    c979      -1
    x[914]    c980      1
    x[914]    c3813     -1
    x[914]    c4183     -1
    x[914]    c4723     150
    x[914]    c4724     -150
    x[914]    OBJ       191.0100150309
    x[915]    c988      -1
    x[915]    c989      1
    x[915]    c3983     -1
    x[915]    c4273     -1
    x[915]    c4653     -1
    x[915]    c4723     315
    x[915]    c4724     -315
    x[915]    c4733     52
    x[915]    c4734     -52
    x[915]    OBJ       -75.130605912154
    x[916]    c997      -1
    x[916]    c998      1
    x[916]    c4383     -1
    x[916]    c4643     1
    x[916]    c4653     1
    x[916]    c4663     1
    x[916]    c4673     1
    x[916]    c4723     1346
    x[916]    c4724     -1346
    x[916]    c4733     1322
    x[916]    c4734     -1322
    x[916]    OBJ       -8098.82463731016
    x[917]    c1006     -1
    x[917]    c1007     1
    x[917]    c3273     -1
    x[917]    c4433     -1
    x[917]    c4663     -1
    x[917]    c4693     -1
    x[917]    c4723     548
    x[917]    c4724     -548
    x[917]    c4733     133
    x[917]    c4734     -133
    x[917]    OBJ       -1215.24816229659
    x[918]    c1015     -1
    x[918]    c1016     1
    x[918]    c3443     -1
    x[918]    c4533     -1
    x[918]    c4683     1
    x[918]    c4693     1
    x[918]    c4703     1
    x[918]    c4713     1
    x[918]    c4723     672
    x[918]    c4724     -672
    x[918]    c4733     672
    x[918]    c4734     -672
    x[918]    OBJ       -7131.0405611536
    x[919]    c1024     -1
    x[919]    c1025     1
    x[919]    c3523     -1
    x[919]    c4583     -1
    x[919]    c4673     -1
    x[919]    c4703     -1
    x[919]    c4723     429
    x[919]    c4724     -429
    x[919]    c4733     142
    x[919]    c4734     -142
    x[919]    OBJ       -2572.26820241612
    x[920]    c1033     -1
    x[920]    c1034     1
    x[920]    c3823     -1
    x[920]    c4633     -1
    x[920]    c4713     -1
    x[920]    c4723     273
    x[920]    c4724     -273
    x[920]    c4733     94
    x[920]    c4734     -94
    x[920]    OBJ       -2393.99218838728
    x[921]    c8        -1
    x[921]    c9        1
    x[921]    c2394     -1
    x[921]    c4724     219
    x[921]    c4725     -219
    x[921]    c4734     75
    x[921]    c4735     -75
    x[921]    OBJ       -805.747050658752
    x[922]    c17       -1
    x[922]    c18       1
    x[922]    c1344     -1
    x[922]    c4724     328
    x[922]    c4725     -328
    x[922]    c4734     215
    x[922]    c4735     -215
    x[922]    OBJ       -1644.60699381033
    x[923]    c26       -1
    x[923]    c27       1
    x[923]    c1514     -1
    x[923]    c3674     -1
    x[923]    c4724     545
    x[923]    c4725     -545
    x[923]    c4734     368
    x[923]    c4735     -368
    x[923]    OBJ       -3756.4736927972
    x[924]    c35       -1
    x[924]    c36       1
    x[924]    c1074     -1
    x[924]    c1684     -1
    x[924]    c4724     435
    x[924]    c4725     -435
    x[924]    c4734     400
    x[924]    c4735     -400
    x[924]    OBJ       -5728.53040125879
    x[925]    c44       -1
    x[925]    c45       1
    x[925]    c1124     -1
    x[925]    c4724     247
    x[925]    c4725     -247
    x[925]    c4734     216
    x[925]    c4735     -216
    x[925]    OBJ       -2553.37193222454
    x[926]    c53       -1
    x[926]    c54       1
    x[926]    c1974     -1
    x[926]    c4724     82
    x[926]    c4725     -82
    x[926]    c4734     27
    x[926]    c4735     -27
    x[926]    OBJ       -268.214429191886
    x[927]    c62       -1
    x[927]    c63       1
    x[927]    c1084     -1
    x[927]    c1244     -1
    x[927]    c2514     -1
    x[927]    c4724     526
    x[927]    c4725     -526
    x[927]    c4734     314
    x[927]    c4735     -314
    x[927]    OBJ       -2485.3065421004
    x[928]    c71       -1
    x[928]    c72       1
    x[928]    c1044     1
    x[928]    c1054     1
    x[928]    c1064     1
    x[928]    c1294     -1
    x[928]    c4724     693
    x[928]    c4725     -693
    x[928]    c4734     693
    x[928]    c4735     -693
    x[928]    OBJ       -19021.5171319897
    x[929]    c80       -1
    x[929]    c81       1
    x[929]    c1044     -1
    x[929]    c1074     1
    x[929]    c1084     1
    x[929]    c1094     1
    x[929]    c1104     1
    x[929]    c1114     1
    x[929]    c1374     -1
    x[929]    c2704     -1
    x[929]    c4724     1944
    x[929]    c4725     -1944
    x[929]    c4734     1944
    x[929]    c4735     -1944
    x[929]    OBJ       -28440.2954410601
    x[930]    c89       -1
    x[930]    c90       1
    x[930]    c1094     -1
    x[930]    c1134     -1
    x[930]    c1424     -1
    x[930]    c2784     -1
    x[930]    c4724     907
    x[930]    c4725     -907
    x[930]    c4734     574
    x[930]    c4735     -574
    x[930]    c4771     -1
    x[930]    OBJ       -8234.07259988259
    x[931]    c98       -1
    x[931]    c99       1
    x[931]    c1054     -1
    x[931]    c1124     1
    x[931]    c1134     1
    x[931]    c1144     1
    x[931]    c1154     1
    x[931]    c1164     1
    x[931]    c1544     -1
    x[931]    c4724     1296
    x[931]    c4725     -1296
    x[931]    c4734     1128
    x[931]    c4735     -1128
    x[931]    OBJ       -9067.04580659101
    x[932]    c107      -1
    x[932]    c108      1
    x[932]    c1104     -1
    x[932]    c1144     -1
    x[932]    c1174     -1
    x[932]    c1594     -1
    x[932]    c1984     -1
    x[932]    c2954     -1
    x[932]    c4724     1043
    x[932]    c4725     -1043
    x[932]    c4734     864
    x[932]    c4735     -864
    x[932]    OBJ       -7529.13591081311
    x[933]    c116      -1
    x[933]    c117      1
    x[933]    c1174     1
    x[933]    c1184     1
    x[933]    c1194     1
    x[933]    c1204     1
    x[933]    c1714     -1
    x[933]    c2154     -1
    x[933]    c4724     1332
    x[933]    c4725     -1332
    x[933]    c4734     1330
    x[933]    c4735     -1330
    x[933]    OBJ       -17255.496199039
    x[934]    c125      -1
    x[934]    c126      1
    x[934]    c1154     -1
    x[934]    c1184     -1
    x[934]    c1764     -1
    x[934]    c2224     -1
    x[934]    c4724     1186
    x[934]    c4725     -1186
    x[934]    c4734     864
    x[934]    c4735     -864
    x[934]    OBJ       -10441.598766071
    x[935]    c134      -1
    x[935]    c135      1
    x[935]    c1194     -1
    x[935]    c1844     -1
    x[935]    c2524     -1
    x[935]    c4724     984
    x[935]    c4725     -984
    x[935]    c4734     723
    x[935]    c4735     -723
    x[935]    c4807     -1
    x[935]    OBJ       -5184.00728026567
    x[936]    c143      -1
    x[936]    c144      1
    x[936]    c1254     -1
    x[936]    c1894     -1
    x[936]    c3254     -1
    x[936]    c4724     225
    x[936]    c4725     -225
    x[936]    c4734     20
    x[936]    c4735     -20
    x[936]    OBJ       20.9714985787894
    x[937]    c152      -1
    x[937]    c153      1
    x[937]    c1214     1
    x[937]    c1224     1
    x[937]    c1234     1
    x[937]    c1304     -1
    x[937]    c1934     -1
    x[937]    c4724     724
    x[937]    c4725     -724
    x[937]    c4734     724
    x[937]    c4735     -724
    x[937]    OBJ       -14164.9595663753
    x[938]    c161      -1
    x[938]    c162      1
    x[938]    c1214     -1
    x[938]    c1244     1
    x[938]    c1254     1
    x[938]    c1264     1
    x[938]    c1274     1
    x[938]    c1284     1
    x[938]    c1384     -1
    x[938]    c2004     -1
    x[938]    c3424     -1
    x[938]    c4724     1989
    x[938]    c4725     -1989
    x[938]    c4734     1989
    x[938]    c4735     -1989
    x[938]    OBJ       -12281.2039045612
    x[939]    c170      -1
    x[939]    c171      1
    x[939]    c1264     -1
    x[939]    c1434     -1
    x[939]    c2054     -1
    x[939]    c3504     -1
    x[939]    c4724     710
    x[939]    c4725     -710
    x[939]    c4734     382
    x[939]    c4735     -382
    x[939]    OBJ       -3436.38239869989
    x[940]    c179      -1
    x[940]    c180      1
    x[940]    c1294     1
    x[940]    c1304     1
    x[940]    c1314     1
    x[940]    c1324     1
    x[940]    c1334     1
    x[940]    c1344     1
    x[940]    c1354     1
    x[940]    c1364     1
    x[940]    c2104     -1
    x[940]    c4724     716
    x[940]    c4725     -716
    x[940]    c4734     716
    x[940]    c4735     -716
    x[940]    c4824     1
    x[940]    OBJ       -21449.7959147969
    x[941]    c188      -1
    x[941]    c189      1
    x[941]    c1314     -1
    x[941]    c1374     1
    x[941]    c1384     1
    x[941]    c1394     1
    x[941]    c1404     1
    x[941]    c1414     1
    x[941]    c1474     -1
    x[941]    c2174     -1
    x[941]    c3664     -1
    x[941]    c4724     2876
    x[941]    c4725     -2876
    x[941]    c4734     2876
    x[941]    c4735     -2876
    x[941]    OBJ       -67844.6375075224
    x[942]    c197      -1
    x[942]    c198      1
    x[942]    c1064     -1
    x[942]    c1224     -1
    x[942]    c1394     -1
    x[942]    c1424     1
    x[942]    c1434     1
    x[942]    c1444     1
    x[942]    c1454     1
    x[942]    c1464     1
    x[942]    c1554     -1
    x[942]    c2244     -1
    x[942]    c3734     -1
    x[942]    c4724     2595
    x[942]    c4725     -2595
    x[942]    c4734     2595
    x[942]    c4735     -2595
    x[942]    c4872     -1
    x[942]    c4873     -1
    x[942]    OBJ       -14514.4845426885
    x[943]    c206      -1
    x[943]    c207      1
    x[943]    c1114     -1
    x[943]    c1274     -1
    x[943]    c1444     -1
    x[943]    c1604     -1
    x[943]    c2294     -1
    x[943]    c3794     -1
    x[943]    c4724     1030
    x[943]    c4725     -1030
    x[943]    c4734     552
    x[943]    c4735     -552
    x[943]    c4801     -1
    x[943]    OBJ       -1942.62302624576
    x[944]    c215      -1
    x[944]    c216      1
    x[944]    c1474     1
    x[944]    c1484     1
    x[944]    c1494     1
    x[944]    c1504     1
    x[944]    c1514     1
    x[944]    c1524     1
    x[944]    c1534     1
    x[944]    c2404     -1
    x[944]    c4724     1432
    x[944]    c4725     -1432
    x[944]    c4734     1432
    x[944]    c4735     -1432
    x[944]    OBJ       -39772.2630941603
    x[945]    c224      -1
    x[945]    c225      1
    x[945]    c1324     -1
    x[945]    c1484     -1
    x[945]    c1544     1
    x[945]    c1554     1
    x[945]    c1564     1
    x[945]    c1574     1
    x[945]    c1584     1
    x[945]    c1644     -1
    x[945]    c2464     -1
    x[945]    c4724     2864
    x[945]    c4725     -2864
    x[945]    c4734     2864
    x[945]    c4735     -2864
    x[945]    OBJ       -54489.1042020827
    x[946]    c233      -1
    x[946]    c234      1
    x[946]    c1404     -1
    x[946]    c1564     -1
    x[946]    c1594     1
    x[946]    c1604     1
    x[946]    c1614     1
    x[946]    c1624     1
    x[946]    c1634     1
    x[946]    c1724     -1
    x[946]    c2554     -1
    x[946]    c4724     2600
    x[946]    c4725     -2600
    x[946]    c4734     2336
    x[946]    c4735     -2336
    x[946]    c4757     -1
    x[946]    OBJ       -20802.2549060483
    x[947]    c242      -1
    x[947]    c243      1
    x[947]    c1164     -1
    x[947]    c1454     -1
    x[947]    c1614     -1
    x[947]    c1774     -1
    x[947]    c2604     -1
    x[947]    c3974     -1
    x[947]    c4724     1156
    x[947]    c4725     -1156
    x[947]    c4734     696
    x[947]    c4735     -696
    x[947]    c4909     -1
    x[947]    OBJ       -4823.44467312158
    x[948]    c251      -1
    x[948]    c252      1
    x[948]    c1644     1
    x[948]    c1654     1
    x[948]    c1664     1
    x[948]    c1674     1
    x[948]    c1684     1
    x[948]    c1694     1
    x[948]    c1704     1
    x[948]    c2654     -1
    x[948]    c4724     716
    x[948]    c4725     -716
    x[948]    c4734     716
    x[948]    c4735     -716
    x[948]    c4826     1
    x[948]    OBJ       -19904.5275984651
    x[949]    c260      -1
    x[949]    c261      1
    x[949]    c1494     -1
    x[949]    c1654     -1
    x[949]    c1714     1
    x[949]    c1724     1
    x[949]    c1734     1
    x[949]    c1744     1
    x[949]    c1754     1
    x[949]    c2734     -1
    x[949]    c4724     2864
    x[949]    c4725     -2864
    x[949]    c4734     2864
    x[949]    c4735     -2864
    x[949]    OBJ       -61773.9405505044
    x[950]    c269      -1
    x[950]    c270      1
    x[950]    c1574     -1
    x[950]    c1734     -1
    x[950]    c1764     1
    x[950]    c1774     1
    x[950]    c1784     1
    x[950]    c1794     1
    x[950]    c1804     1
    x[950]    c1814     -1
    x[950]    c2814     -1
    x[950]    c4724     2681
    x[950]    c4725     -2681
    x[950]    c4734     2678
    x[950]    c4735     -2678
    x[950]    OBJ       -57542.8487319766
    x[951]    c278      -1
    x[951]    c279      1
    x[951]    c1204     -1
    x[951]    c1624     -1
    x[951]    c1784     -1
    x[951]    c1854     -1
    x[951]    c2864     -1
    x[951]    c3264     -1
    x[951]    c4724     1263
    x[951]    c4725     -1263
    x[951]    c4734     864
    x[951]    c4735     -864
    x[951]    c4803     -1
    x[951]    OBJ       -20787.5380649404
    x[952]    c287      -1
    x[952]    c288      1
    x[952]    c1664     -1
    x[952]    c1814     1
    x[952]    c1824     1
    x[952]    c1834     1
    x[952]    c2914     -1
    x[952]    c4724     716
    x[952]    c4725     -716
    x[952]    c4734     716
    x[952]    c4735     -716
    x[952]    OBJ       -13465.909613749
    x[953]    c296      -1
    x[953]    c297      1
    x[953]    c1744     -1
    x[953]    c1824     -1
    x[953]    c1844     1
    x[953]    c1854     1
    x[953]    c1864     1
    x[953]    c1874     1
    x[953]    c1884     1
    x[953]    c2984     -1
    x[953]    c3434     -1
    x[953]    c4724     1965
    x[953]    c4725     -1965
    x[953]    c4734     1964
    x[953]    c4735     -1964
    x[953]    OBJ       -23988.4510059135
    x[954]    c305      -1
    x[954]    c306      1
    x[954]    c1794     -1
    x[954]    c1864     -1
    x[954]    c3034     -1
    x[954]    c3514     -1
    x[954]    c4724     1245
    x[954]    c4725     -1245
    x[954]    c4734     889
    x[954]    c4735     -889
    x[954]    c4772     -1
    x[954]    OBJ       -11652.0589471976
    x[955]    c314      -1
    x[955]    c315      1
    x[955]    c1874     -1
    x[955]    c3084     -1
    x[955]    c3804     -1
    x[955]    c4724     832
    x[955]    c4725     -832
    x[955]    c4734     647
    x[955]    c4735     -647
    x[955]    OBJ       -3493.04223696539
    x[956]    c323      -1
    x[956]    c324      1
    x[956]    c4724     339
    x[956]    c4725     -339
    x[956]    c4734     283
    x[956]    c4735     -283
    x[956]    OBJ       -2056.67854483216
    x[957]    c332      -1
    x[957]    c333      1
    x[957]    c1894     1
    x[957]    c1904     1
    x[957]    c1914     1
    x[957]    c1924     1
    x[957]    c2014     -1
    x[957]    c4724     1346
    x[957]    c4725     -1346
    x[957]    c4734     1346
    x[957]    c4735     -1346
    x[957]    OBJ       -16887.575171341
    x[958]    c341      -1
    x[958]    c342      1
    x[958]    c1904     -1
    x[958]    c2064     -1
    x[958]    c4724     243
    x[958]    c4725     -243
    x[958]    OBJ       267.40500293095
    x[959]    c350      -1
    x[959]    c351      1
    x[959]    c1934     1
    x[959]    c1944     1
    x[959]    c1954     1
    x[959]    c1964     1
    x[959]    c1974     1
    x[959]    c1984     1
    x[959]    c1994     1
    x[959]    c2114     -1
    x[959]    c4724     724
    x[959]    c4725     -724
    x[959]    c4734     724
    x[959]    c4735     -724
    x[959]    OBJ       -19389.4381596878
    x[960]    c359      -1
    x[960]    c360      1
    x[960]    c1944     -1
    x[960]    c2004     1
    x[960]    c2014     1
    x[960]    c2024     1
    x[960]    c2034     1
    x[960]    c2044     1
    x[960]    c2184     -1
    x[960]    c4724     2896
    x[960]    c4725     -2896
    x[960]    c4734     2896
    x[960]    c4735     -2896
    x[960]    OBJ       -59971.1275147839
    x[961]    c368      -1
    x[961]    c369      1
    x[961]    c1234     -1
    x[961]    c2024     -1
    x[961]    c2054     1
    x[961]    c2064     1
    x[961]    c2074     1
    x[961]    c2084     1
    x[961]    c2094     1
    x[961]    c2254     -1
    x[961]    c3134     -1
    x[961]    c4724     2692
    x[961]    c4725     -2692
    x[961]    c4734     2692
    x[961]    c4735     -2692
    x[961]    OBJ       -29985.5637573919
    x[962]    c377      -1
    x[962]    c378      1
    x[962]    c1284     -1
    x[962]    c1914     -1
    x[962]    c2074     -1
    x[962]    c2304     -1
    x[962]    c3164     -1
    x[962]    c4724     755
    x[962]    c4725     -755
    x[962]    c4734     323
    x[962]    c4735     -323
    x[962]    c4765     -1
    x[962]    OBJ       -2530.19290747956
    x[963]    c386      -1
    x[963]    c387      1
    x[963]    c2104     1
    x[963]    c2114     1
    x[963]    c2124     1
    x[963]    c2134     1
    x[963]    c2144     1
    x[963]    c2154     1
    x[963]    c2164     1
    x[963]    c2344     -1
    x[963]    c4724     1432
    x[963]    c4725     -1432
    x[963]    c4734     1432
    x[963]    c4735     -1432
    x[963]    OBJ       -40949.6103827941
    x[964]    c395      -1
    x[964]    c396      1
    x[964]    c2124     -1
    x[964]    c2174     1
    x[964]    c2184     1
    x[964]    c2194     1
    x[964]    c2204     1
    x[964]    c2214     1
    x[964]    c2224     1
    x[964]    c2234     1
    x[964]    c2414     -1
    x[964]    c4724     2886
    x[964]    c4725     -2886
    x[964]    c4734     2886
    x[964]    c4735     -2886
    x[964]    c4825     1
    x[964]    OBJ       -77153.0395082833
    x[965]    c404      -1
    x[965]    c405      1
    x[965]    c1334     -1
    x[965]    c1954     -1
    x[965]    c2194     -1
    x[965]    c2244     1
    x[965]    c2254     1
    x[965]    c2264     1
    x[965]    c2274     1
    x[965]    c2284     1
    x[965]    c2474     -1
    x[965]    c3214     -1
    x[965]    c4724     2895
    x[965]    c4725     -2895
    x[965]    c4734     2895
    x[965]    c4735     -2895
    x[965]    c4993     1
    x[965]    c4996     1
    x[965]    OBJ       -64202.2193333115
    x[966]    c413      -1
    x[966]    c414      1
    x[966]    c1414     -1
    x[966]    c2034     -1
    x[966]    c2264     -1
    x[966]    c2294     1
    x[966]    c2304     1
    x[966]    c2314     1
    x[966]    c2324     1
    x[966]    c2334     1
    x[966]    c2564     -1
    x[966]    c3284     -1
    x[966]    c4724     2692
    x[966]    c4725     -2692
    x[966]    c4734     2668
    x[966]    c4735     -2668
    x[966]    OBJ       -25202.5903973171
    x[967]    c422      -1
    x[967]    c423      1
    x[967]    c1464     -1
    x[967]    c2084     -1
    x[967]    c2314     -1
    x[967]    c2614     -1
    x[967]    c3334     -1
    x[967]    c4324     -1
    x[967]    c4724     1115
    x[967]    c4725     -1115
    x[967]    c4734     408
    x[967]    c4735     -408
    x[967]    c4804     -1
    x[967]    OBJ       -1855.42574268132
    x[968]    c431      -1
    x[968]    c432      1
    x[968]    c2344     1
    x[968]    c2354     1
    x[968]    c2364     1
    x[968]    c2374     1
    x[968]    c2384     1
    x[968]    c2394     1
    x[968]    c4724     1432
    x[968]    c4725     -1432
    x[968]    c4734     1432
    x[968]    c4735     -1432
    x[968]    c4953     1
    x[968]    OBJ       -46725.9705176537
    x[969]    c440      -1
    x[969]    c441      1
    x[969]    c2354     -1
    x[969]    c2404     1
    x[969]    c2414     1
    x[969]    c2424     1
    x[969]    c2434     1
    x[969]    c2444     1
    x[969]    c2454     1
    x[969]    c4724     2864
    x[969]    c4725     -2864
    x[969]    c4734     2864
    x[969]    c4735     -2864
    x[969]    OBJ       -85504.8468370292
    x[970]    c449      -1
    x[970]    c450      1
    x[970]    c2134     -1
    x[970]    c2424     -1
    x[970]    c2464     1
    x[970]    c2474     1
    x[970]    c2484     1
    x[970]    c2494     1
    x[970]    c2504     1
    x[970]    c2514     1
    x[970]    c2524     1
    x[970]    c2534     1
    x[970]    c2544     1
    x[970]    c2664     -1
    x[970]    c3384     -1
    x[970]    c4724     2864
    x[970]    c4725     -2864
    x[970]    c4734     2864
    x[970]    c4735     -2864
    x[970]    c4757     1
    x[970]    c4765     1
    x[970]    c4766     1
    x[970]    c4771     1
    x[970]    c4772     1
    x[970]    OBJ       -80758.6655797242
    x[971]    c458      -1
    x[971]    c459      1
    x[971]    c1504     -1
    x[971]    c2204     -1
    x[971]    c2484     -1
    x[971]    c2554     1
    x[971]    c2564     1
    x[971]    c2574     1
    x[971]    c2584     1
    x[971]    c2594     1
    x[971]    c2744     -1
    x[971]    c3454     -1
    x[971]    c4724     2873
    x[971]    c4725     -2873
    x[971]    c4734     2873
    x[971]    c4735     -2873
    x[971]    OBJ       -62105.0694754326
    x[972]    c467      -1
    x[972]    c468      1
    x[972]    c1584     -1
    x[972]    c2274     -1
    x[972]    c2574     -1
    x[972]    c2604     1
    x[972]    c2614     1
    x[972]    c2624     1
    x[972]    c2634     1
    x[972]    c2644     1
    x[972]    c2824     -1
    x[972]    c3534     -1
    x[972]    c4724     2679
    x[972]    c4725     -2679
    x[972]    c4734     2604
    x[972]    c4735     -2604
    x[972]    c4824     -1
    x[972]    c4825     -1
    x[972]    c4826     -1
    x[972]    OBJ       -21571.2098539373
    x[973]    c476      -1
    x[973]    c477      1
    x[973]    c1634     -1
    x[973]    c2324     -1
    x[973]    c2624     -1
    x[973]    c2874     -1
    x[973]    c3584     -1
    x[973]    c4474     -1
    x[973]    c4724     1252
    x[973]    c4725     -1252
    x[973]    c4734     552
    x[973]    c4735     -552
    x[973]    c4993     -1
    x[973]    OBJ       -4250.59163299569
    x[974]    c485      -1
    x[974]    c486      1
    x[974]    c2364     -1
    x[974]    c2654     1
    x[974]    c2664     1
    x[974]    c2674     1
    x[974]    c2684     1
    x[974]    c2694     1
    x[974]    c2704     1
    x[974]    c2714     1
    x[974]    c2724     1
    x[974]    c3634     -1
    x[974]    c4724     2148
    x[974]    c4725     -2148
    x[974]    c4734     2148
    x[974]    c4735     -2148
    x[974]    c4872     1
    x[974]    OBJ       -56696.6303682711
    x[975]    c494      -1
    x[975]    c495      1
    x[975]    c2434     -1
    x[975]    c2674     -1
    x[975]    c2734     1
    x[975]    c2744     1
    x[975]    c2754     1
    x[975]    c2764     1
    x[975]    c2774     1
    x[975]    c2784     1
    x[975]    c2794     1
    x[975]    c2804     1
    x[975]    c3684     -1
    x[975]    c4724     2864
    x[975]    c4725     -2864
    x[975]    c4734     2864
    x[975]    c4735     -2864
    x[975]    c4796     1
    x[975]    c4801     1
    x[975]    c4803     1
    x[975]    c4804     1
    x[975]    c4805     1
    x[975]    c4806     -1
    x[975]    c4807     1
    x[975]    OBJ       -73988.91867008
    x[976]    c503      -1
    x[976]    c504      1
    x[976]    c1674     -1
    x[976]    c2494     -1
    x[976]    c2754     -1
    x[976]    c2814     1
    x[976]    c2824     1
    x[976]    c2834     1
    x[976]    c2844     1
    x[976]    c2854     1
    x[976]    c2924     -1
    x[976]    c3744     -1
    x[976]    c4724     2864
    x[976]    c4725     -2864
    x[976]    c4734     2864
    x[976]    c4735     -2864
    x[976]    c4952     -1
    x[976]    c4953     -1
    x[976]    c4955     1
    x[976]    c4957     1
    x[976]    OBJ       -67697.4690964431
    x[977]    c512      -1
    x[977]    c513      1
    x[977]    c1754     -1
    x[977]    c2584     -1
    x[977]    c2834     -1
    x[977]    c2864     1
    x[977]    c2874     1
    x[977]    c2884     1
    x[977]    c2894     1
    x[977]    c2904     1
    x[977]    c2994     -1
    x[977]    c3834     -1
    x[977]    c4724     2684
    x[977]    c4725     -2684
    x[977]    c4734     2680
    x[977]    c4735     -2680
    x[977]    c4847     -1
    x[977]    OBJ       -57542.8487319766
    x[978]    c521      -1
    x[978]    c522      1
    x[978]    c1804     -1
    x[978]    c2634     -1
    x[978]    c2884     -1
    x[978]    c3044     -1
    x[978]    c3884     -1
    x[978]    c4724     1253
    x[978]    c4725     -1253
    x[978]    c4734     840
    x[978]    c4735     -840
    x[978]    c4766     -1
    x[978]    OBJ       -15894.1883965562
    x[979]    c530      -1
    x[979]    c531      1
    x[979]    c2684     -1
    x[979]    c2914     1
    x[979]    c2924     1
    x[979]    c2934     1
    x[979]    c2944     1
    x[979]    c2954     1
    x[979]    c2964     1
    x[979]    c2974     1
    x[979]    c4724     716
    x[979]    c4725     -716
    x[979]    c4734     716
    x[979]    c4735     -716
    x[979]    OBJ       -21339.4196064875
    x[980]    c539      -1
    x[980]    c540      1
    x[980]    c2764     -1
    x[980]    c2934     -1
    x[980]    c2984     1
    x[980]    c2994     1
    x[980]    c3004     1
    x[980]    c3014     1
    x[980]    c3024     1
    x[980]    c3934     -1
    x[980]    c4724     2864
    x[980]    c4725     -2864
    x[980]    c4734     2864
    x[980]    c4735     -2864
    x[980]    OBJ       -59456.0380760066
    x[981]    c548      -1
    x[981]    c549      1
    x[981]    c1834     -1
    x[981]    c2844     -1
    x[981]    c3004     -1
    x[981]    c3034     1
    x[981]    c3044     1
    x[981]    c3054     1
    x[981]    c3064     1
    x[981]    c3074     1
    x[981]    c3994     -1
    x[981]    c4724     2651
    x[981]    c4725     -2651
    x[981]    c4734     2650
    x[981]    c4735     -2650
    x[981]    OBJ       -45769.3758456387
    x[982]    c557      -1
    x[982]    c558      1
    x[982]    c1884     -1
    x[982]    c2894     -1
    x[982]    c3054     -1
    x[982]    c3094     -1
    x[982]    c4044     -1
    x[982]    c4724     1175
    x[982]    c4725     -1175
    x[982]    c4734     768
    x[982]    c4735     -768
    x[982]    OBJ       -14032.507996404
    x[983]    c566      -1
    x[983]    c567      1
    x[983]    c3014     -1
    x[983]    c3084     1
    x[983]    c3094     1
    x[983]    c3104     1
    x[983]    c3114     1
    x[983]    c3124     1
    x[983]    c4724     1333
    x[983]    c4725     -1333
    x[983]    c4734     1332
    x[983]    c4735     -1332
    x[983]    c4805     -1
    x[983]    OBJ       -16078.1489104052
    x[984]    c575      -1
    x[984]    c576      1
    x[984]    c3064     -1
    x[984]    c3104     -1
    x[984]    c4094     -1
    x[984]    c4334     -1
    x[984]    c4724     940
    x[984]    c4725     -940
    x[984]    c4734     728
    x[984]    c4735     -728
    x[984]    c4957     -1
    x[984]    OBJ       -11022.9139898339
    x[985]    c584      -1
    x[985]    c585      1
    x[985]    c3114     -1
    x[985]    c4484     -1
    x[985]    c4724     342
    x[985]    c4725     -342
    x[985]    c4734     317
    x[985]    c4735     -317
    x[985]    OBJ       -2722.61560496565
    x[986]    c593      -1
    x[986]    c594      1
    x[986]    c1354     -1
    x[986]    c1924     -1
    x[986]    c3174     -1
    x[986]    c4724     187
    x[986]    c4725     -187
    x[986]    OBJ       202.98203098102
    x[987]    c602      -1
    x[987]    c603      1
    x[987]    c1964     -1
    x[987]    c3134     1
    x[987]    c3144     1
    x[987]    c3154     1
    x[987]    c3224     -1
    x[987]    c4724     724
    x[987]    c4725     -724
    x[987]    c4734     724
    x[987]    c4735     -724
    x[987]    OBJ       -10890.4624198626
    x[988]    c611      -1
    x[988]    c612      1
    x[988]    c2044     -1
    x[988]    c3144     -1
    x[988]    c3164     1
    x[988]    c3174     1
    x[988]    c3184     1
    x[988]    c3194     1
    x[988]    c3204     1
    x[988]    c3294     -1
    x[988]    c4724     2019
    x[988]    c4725     -2019
    x[988]    c4734     1995
    x[988]    c4735     -1995
    x[988]    OBJ       -12759.5012405687
    x[989]    c620      -1
    x[989]    c621      1
    x[989]    c1524     -1
    x[989]    c2094     -1
    x[989]    c3184     -1
    x[989]    c3344     -1
    x[989]    c4724     660
    x[989]    c4725     -660
    x[989]    c4734     174
    x[989]    c4735     -174
    x[989]    c4996     -1
    x[989]    OBJ       -1473.89163695843
    x[990]    c629      -1
    x[990]    c630      1
    x[990]    c2144     -1
    x[990]    c3214     1
    x[990]    c3224     1
    x[990]    c3234     1
    x[990]    c3244     1
    x[990]    c3254     1
    x[990]    c3264     1
    x[990]    c3274     1
    x[990]    c3394     -1
    x[990]    c4724     1447
    x[990]    c4725     -1447
    x[990]    c4734     1447
    x[990]    c4735     -1447
    x[990]    c4873     1
    x[990]    OBJ       -32450.6346429689
    x[991]    c638      -1
    x[991]    c639      1
    x[991]    c2214     -1
    x[991]    c3234     -1
    x[991]    c3284     1
    x[991]    c3294     1
    x[991]    c3304     1
    x[991]    c3314     1
    x[991]    c3324     1
    x[991]    c3464     -1
    x[991]    c4724     2896
    x[991]    c4725     -2896
    x[991]    c4734     2896
    x[991]    c4735     -2896
    x[991]    OBJ       -43782.6022960692
    x[992]    c647      -1
    x[992]    c648      1
    x[992]    c2284     -1
    x[992]    c3154     -1
    x[992]    c3304     -1
    x[992]    c3334     1
    x[992]    c3344     1
    x[992]    c3354     1
    x[992]    c3364     1
    x[992]    c3374     1
    x[992]    c3544     -1
    x[992]    c4724     2692
    x[992]    c4725     -2692
    x[992]    c4734     2692
    x[992]    c4735     -2692
    x[992]    OBJ       -17858.8866844638
    x[993]    c656      -1
    x[993]    c657      1
    x[993]    c1694     -1
    x[993]    c2334     -1
    x[993]    c3194     -1
    x[993]    c3354     -1
    x[993]    c3594     -1
    x[993]    c4144     -1
    x[993]    c4724     964
    x[993]    c4725     -964
    x[993]    c4734     288
    x[993]    c4735     -288
    x[993]    c4849     -1
    x[993]    OBJ       -1436.73161316093
    x[994]    c665      -1
    x[994]    c666      1
    x[994]    c2374     -1
    x[994]    c3384     1
    x[994]    c3394     1
    x[994]    c3404     1
    x[994]    c3414     1
    x[994]    c3424     1
    x[994]    c3434     1
    x[994]    c3444     1
    x[994]    c3644     -1
    x[994]    c4724     1432
    x[994]    c4725     -1432
    x[994]    c4734     1432
    x[994]    c4735     -1432
    x[994]    c4763     1
    x[994]    OBJ       -41501.4919243412
    x[995]    c674      -1
    x[995]    c675      1
    x[995]    c2444     -1
    x[995]    c3404     -1
    x[995]    c3454     1
    x[995]    c3464     1
    x[995]    c3474     1
    x[995]    c3484     1
    x[995]    c3494     1
    x[995]    c3504     1
    x[995]    c3514     1
    x[995]    c3524     1
    x[995]    c3694     -1
    x[995]    c4724     2872
    x[995]    c4725     -2872
    x[995]    c4734     2872
    x[995]    c4735     -2872
    x[995]    c4902     1
    x[995]    c4909     1
    x[995]    OBJ       -68396.5190490694
    x[996]    c683      -1
    x[996]    c684      1
    x[996]    c2504     -1
    x[996]    c3244     -1
    x[996]    c3474     -1
    x[996]    c3534     1
    x[996]    c3544     1
    x[996]    c3554     1
    x[996]    c3564     1
    x[996]    c3574     1
    x[996]    c3754     -1
    x[996]    c4724     2888
    x[996]    c4725     -2888
    x[996]    c4734     2888
    x[996]    c4735     -2888
    x[996]    OBJ       -52833.4595774415
    x[997]    c692      -1
    x[997]    c693      1
    x[997]    c2594     -1
    x[997]    c3314     -1
    x[997]    c3554     -1
    x[997]    c3584     1
    x[997]    c3594     1
    x[997]    c3604     1
    x[997]    c3614     1
    x[997]    c3624     1
    x[997]    c3844     -1
    x[997]    c4194     -1
    x[997]    c4724     2692
    x[997]    c4725     -2692
    x[997]    c4734     2692
    x[997]    c4735     -2692
    x[997]    OBJ       -24945.0456779285
    x[998]    c701      -1
    x[998]    c702      1
    x[998]    c2644     -1
    x[998]    c3364     -1
    x[998]    c3604     -1
    x[998]    c3894     -1
    x[998]    c4234     -1
    x[998]    c4724     1168
    x[998]    c4725     -1168
    x[998]    c4734     528
    x[998]    c4735     -528
    x[998]    OBJ       -4768.25651896686
    x[999]    c710      -1
    x[999]    c711      1
    x[999]    c3634     1
    x[999]    c3644     1
    x[999]    c3654     1
    x[999]    c3664     1
    x[999]    c3674     1
    x[999]    c4724     716
    x[999]    c4725     -716
    x[999]    c4734     716
    x[999]    c4735     -716
    x[999]    c4806     1
    x[999]    OBJ       -24577.1246502304
    x[1000]   c719      -1
    x[1000]   c720      1
    x[1000]   c3654     -1
    x[1000]   c3684     1
    x[1000]   c3694     1
    x[1000]   c3704     1
    x[1000]   c3714     1
    x[1000]   c3724     1
    x[1000]   c3734     1
    x[1000]   c4724     2864
    x[1000]   c4725     -2864
    x[1000]   c4734     2864
    x[1000]   c4735     -2864
    x[1000]   c4952     1
    x[1000]   OBJ       -85063.3416037917
    x[1001]   c728      -1
    x[1001]   c729      1
    x[1001]   c2694     -1
    x[1001]   c3414     -1
    x[1001]   c3704     -1
    x[1001]   c3744     1
    x[1001]   c3754     1
    x[1001]   c3764     1
    x[1001]   c3774     1
    x[1001]   c3784     1
    x[1001]   c3794     1
    x[1001]   c3804     1
    x[1001]   c3814     1
    x[1001]   c3824     1
    x[1001]   c4724     2864
    x[1001]   c4725     -2864
    x[1001]   c4734     2864
    x[1001]   c4735     -2864
    x[1001]   c4847     1
    x[1001]   c4849     1
    x[1001]   c4850     1
    x[1001]   c4851     1
    x[1001]   c4852     1
    x[1001]   OBJ       -86314.2730979651
    x[1002]   c737      -1
    x[1002]   c738      1
    x[1002]   c2774     -1
    x[1002]   c3484     -1
    x[1002]   c3764     -1
    x[1002]   c3834     1
    x[1002]   c3844     1
    x[1002]   c3854     1
    x[1002]   c3864     1
    x[1002]   c3874     1
    x[1002]   c3944     -1
    x[1002]   c4284     -1
    x[1002]   c4724     2865
    x[1002]   c4725     -2865
    x[1002]   c4734     2865
    x[1002]   c4735     -2865
    x[1002]   c4763     -1
    x[1002]   OBJ       -82635.0628209844
    x[1003]   c746      -1
    x[1003]   c747      1
    x[1003]   c2854     -1
    x[1003]   c3564     -1
    x[1003]   c3854     -1
    x[1003]   c3884     1
    x[1003]   c3894     1
    x[1003]   c3904     1
    x[1003]   c3914     1
    x[1003]   c3924     1
    x[1003]   c4004     -1
    x[1003]   c4344     -1
    x[1003]   c4724     2686
    x[1003]   c4725     -2686
    x[1003]   c4734     2684
    x[1003]   c4735     -2684
    x[1003]   c4902     -1
    x[1003]   OBJ       -48639.1598616836
    x[1004]   c755      -1
    x[1004]   c756      1
    x[1004]   c1364     -1
    x[1004]   c2904     -1
    x[1004]   c3614     -1
    x[1004]   c3904     -1
    x[1004]   c4054     -1
    x[1004]   c4394     -1
    x[1004]   c4724     1152
    x[1004]   c4725     -1152
    x[1004]   c4734     624
    x[1004]   c4735     -624
    x[1004]   OBJ       -9525.47540710279
    x[1005]   c764      -1
    x[1005]   c765      1
    x[1005]   c3714     -1
    x[1005]   c3934     1
    x[1005]   c3944     1
    x[1005]   c3954     1
    x[1005]   c3964     1
    x[1005]   c3974     1
    x[1005]   c3984     1
    x[1005]   c4724     1432
    x[1005]   c4725     -1432
    x[1005]   c4734     1432
    x[1005]   c4735     -1432
    x[1005]   OBJ       -43709.0180905296
    x[1006]   c773      -1
    x[1006]   c774      1
    x[1006]   c2944     -1
    x[1006]   c3774     -1
    x[1006]   c3954     -1
    x[1006]   c3994     1
    x[1006]   c4004     1
    x[1006]   c4014     1
    x[1006]   c4024     1
    x[1006]   c4034     1
    x[1006]   c4444     -1
    x[1006]   c4724     2864
    x[1006]   c4725     -2864
    x[1006]   c4734     2864
    x[1006]   c4735     -2864
    x[1006]   OBJ       -62730.5352225193
    x[1007]   c782      -1
    x[1007]   c783      1
    x[1007]   c3024     -1
    x[1007]   c3864     -1
    x[1007]   c4014     -1
    x[1007]   c4044     1
    x[1007]   c4054     1
    x[1007]   c4064     1
    x[1007]   c4074     1
    x[1007]   c4084     1
    x[1007]   c4494     -1
    x[1007]   c4724     2684
    x[1007]   c4725     -2684
    x[1007]   c4734     2680
    x[1007]   c4735     -2680
    x[1007]   c4796     -1
    x[1007]   OBJ       -43819.394398839
    x[1008]   c791      -1
    x[1008]   c792      1
    x[1008]   c1534     -1
    x[1008]   c3074     -1
    x[1008]   c3914     -1
    x[1008]   c4064     -1
    x[1008]   c4104     -1
    x[1008]   c4544     -1
    x[1008]   c4724     1099
    x[1008]   c4725     -1099
    x[1008]   c4734     672
    x[1008]   c4735     -672
    x[1008]   c4955     -1
    x[1008]   OBJ       -13624.1156556592
    x[1009]   c800      -1
    x[1009]   c801      1
    x[1009]   c4024     -1
    x[1009]   c4094     1
    x[1009]   c4104     1
    x[1009]   c4114     1
    x[1009]   c4124     1
    x[1009]   c4134     1
    x[1009]   c4724     1342
    x[1009]   c4725     -1342
    x[1009]   c4734     1340
    x[1009]   c4735     -1340
    x[1009]   c4850     -1
    x[1009]   OBJ       -10375.3729810853
    x[1010]   c809      -1
    x[1010]   c810      1
    x[1010]   c1704     -1
    x[1010]   c3124     -1
    x[1010]   c4074     -1
    x[1010]   c4114     -1
    x[1010]   c4594     -1
    x[1010]   c4724     880
    x[1010]   c4725     -880
    x[1010]   c4734     629
    x[1010]   c4735     -629
    x[1010]   OBJ       -7972.84867021698
    x[1011]   c818      -1
    x[1011]   c819      1
    x[1011]   c4124     -1
    x[1011]   c4724     326
    x[1011]   c4725     -326
    x[1011]   c4734     256
    x[1011]   c4735     -256
    x[1011]   OBJ       -2947.04743186146
    x[1012]   c827      -1
    x[1012]   c828      1
    x[1012]   c2534     -1
    x[1012]   c3204     -1
    x[1012]   c4154     -1
    x[1012]   c4724     360
    x[1012]   c4725     -360
    x[1012]   OBJ       396.618867858509
    x[1013]   c836      -1
    x[1013]   c837      1
    x[1013]   c2714     -1
    x[1013]   c3324     -1
    x[1013]   c4144     1
    x[1013]   c4154     1
    x[1013]   c4164     1
    x[1013]   c4174     1
    x[1013]   c4184     1
    x[1013]   c4204     -1
    x[1013]   c4724     1346
    x[1013]   c4725     -1346
    x[1013]   c4734     1322
    x[1013]   c4735     -1322
    x[1013]   OBJ       -4727.78520592008
    x[1014]   c845      -1
    x[1014]   c846      1
    x[1014]   c2794     -1
    x[1014]   c3374     -1
    x[1014]   c4164     -1
    x[1014]   c4244     -1
    x[1014]   c4724     689
    x[1014]   c4725     -689
    x[1014]   c4734     241
    x[1014]   c4735     -241
    x[1014]   OBJ       -1921.28360663927
    x[1015]   c854      -1
    x[1015]   c855      1
    x[1015]   c3494     -1
    x[1015]   c4194     1
    x[1015]   c4204     1
    x[1015]   c4214     1
    x[1015]   c4224     1
    x[1015]   c4294     -1
    x[1015]   c4724     1448
    x[1015]   c4725     -1448
    x[1015]   c4734     1448
    x[1015]   c4735     -1448
    x[1015]   OBJ       -18064.9224599748
    x[1016]   c863      -1
    x[1016]   c864      1
    x[1016]   c3574     -1
    x[1016]   c4214     -1
    x[1016]   c4234     1
    x[1016]   c4244     1
    x[1016]   c4254     1
    x[1016]   c4264     1
    x[1016]   c4274     1
    x[1016]   c4354     -1
    x[1016]   c4724     2692
    x[1016]   c4725     -2692
    x[1016]   c4734     2668
    x[1016]   c4735     -2668
    x[1016]   OBJ       -10463.6740277328
    x[1017]   c872      -1
    x[1017]   c873      1
    x[1017]   c1994     -1
    x[1017]   c2964     -1
    x[1017]   c3624     -1
    x[1017]   c4174     -1
    x[1017]   c4254     -1
    x[1017]   c4404     -1
    x[1017]   c4724     828
    x[1017]   c4725     -828
    x[1017]   c4734     291
    x[1017]   c4735     -291
    x[1017]   c4851     -1
    x[1017]   OBJ       -1609.28657515132
    x[1018]   c881      -1
    x[1018]   c882      1
    x[1018]   c3724     -1
    x[1018]   c4284     1
    x[1018]   c4294     1
    x[1018]   c4304     1
    x[1018]   c4314     1
    x[1018]   c4324     1
    x[1018]   c4334     1
    x[1018]   c4724     1432
    x[1018]   c4725     -1432
    x[1018]   c4734     1432
    x[1018]   c4735     -1432
    x[1018]   OBJ       -42789.2155212844
    x[1019]   c890      -1
    x[1019]   c891      1
    x[1019]   c3784     -1
    x[1019]   c4304     -1
    x[1019]   c4344     1
    x[1019]   c4354     1
    x[1019]   c4364     1
    x[1019]   c4374     1
    x[1019]   c4384     1
    x[1019]   c4454     -1
    x[1019]   c4724     2880
    x[1019]   c4725     -2880
    x[1019]   c4734     2880
    x[1019]   c4735     -2880
    x[1019]   OBJ       -64974.8534914775
    x[1020]   c899      -1
    x[1020]   c900      1
    x[1020]   c2164     -1
    x[1020]   c3874     -1
    x[1020]   c4224     -1
    x[1020]   c4364     -1
    x[1020]   c4394     1
    x[1020]   c4404     1
    x[1020]   c4414     1
    x[1020]   c4424     1
    x[1020]   c4434     1
    x[1020]   c4504     -1
    x[1020]   c4724     2691
    x[1020]   c4725     -2691
    x[1020]   c4734     2691
    x[1020]   c4735     -2691
    x[1020]   OBJ       -22112.0537646535
    x[1021]   c908      -1
    x[1021]   c909      1
    x[1021]   c2234     -1
    x[1021]   c3924     -1
    x[1021]   c4264     -1
    x[1021]   c4414     -1
    x[1021]   c4554     -1
    x[1021]   c4644     -1
    x[1021]   c4724     840
    x[1021]   c4725     -840
    x[1021]   c4734     543
    x[1021]   c4735     -543
    x[1021]   OBJ       -6453.33482582398
    x[1022]   c917      -1
    x[1022]   c918      1
    x[1022]   c4444     1
    x[1022]   c4454     1
    x[1022]   c4464     1
    x[1022]   c4474     1
    x[1022]   c4484     1
    x[1022]   c4724     716
    x[1022]   c4725     -716
    x[1022]   c4734     716
    x[1022]   c4735     -716
    x[1022]   OBJ       -21744.1327369554
    x[1023]   c926      -1
    x[1023]   c927      1
    x[1023]   c2384     -1
    x[1023]   c3964     -1
    x[1023]   c4314     -1
    x[1023]   c4464     -1
    x[1023]   c4494     1
    x[1023]   c4504     1
    x[1023]   c4514     1
    x[1023]   c4524     1
    x[1023]   c4534     1
    x[1023]   c4724     2148
    x[1023]   c4725     -2148
    x[1023]   c4734     2148
    x[1023]   c4735     -2148
    x[1023]   OBJ       -55188.1541547091
    x[1024]   c935      -1
    x[1024]   c936      1
    x[1024]   c2454     -1
    x[1024]   c4034     -1
    x[1024]   c4374     -1
    x[1024]   c4514     -1
    x[1024]   c4544     1
    x[1024]   c4554     1
    x[1024]   c4564     1
    x[1024]   c4574     1
    x[1024]   c4584     1
    x[1024]   c4724     2684
    x[1024]   c4725     -2684
    x[1024]   c4734     2680
    x[1024]   c4735     -2680
    x[1024]   OBJ       -48639.1598616836
    x[1025]   c944      -1
    x[1025]   c945      1
    x[1025]   c2544     -1
    x[1025]   c4084     -1
    x[1025]   c4424     -1
    x[1025]   c4564     -1
    x[1025]   c4604     -1
    x[1025]   c4684     -1
    x[1025]   c4724     841
    x[1025]   c4725     -841
    x[1025]   c4734     480
    x[1025]   c4735     -480
    x[1025]   c4852     -1
    x[1025]   OBJ       -11446.0231716867
    x[1026]   c953      -1
    x[1026]   c954      1
    x[1026]   c2724     -1
    x[1026]   c4524     -1
    x[1026]   c4594     1
    x[1026]   c4604     1
    x[1026]   c4614     1
    x[1026]   c4624     1
    x[1026]   c4634     1
    x[1026]   c4724     671
    x[1026]   c4725     -671
    x[1026]   c4734     670
    x[1026]   c4735     -670
    x[1026]   OBJ       -8682.93625367423
    x[1027]   c962      -1
    x[1027]   c963      1
    x[1027]   c2804     -1
    x[1027]   c4134     -1
    x[1027]   c4574     -1
    x[1027]   c4614     -1
    x[1027]   c4724     754
    x[1027]   c4725     -754
    x[1027]   c4734     450
    x[1027]   c4735     -450
    x[1027]   OBJ       -10128.8658925276
    x[1028]   c971      -1
    x[1028]   c972      1
    x[1028]   c2974     -1
    x[1028]   c4624     -1
    x[1028]   c4724     289
    x[1028]   c4725     -289
    x[1028]   c4734     186
    x[1028]   c4735     -186
    x[1028]   OBJ       -2696.86113302678
    x[1029]   c980      -1
    x[1029]   c981      1
    x[1029]   c3814     -1
    x[1029]   c4184     -1
    x[1029]   c4724     150
    x[1029]   c4725     -150
    x[1029]   OBJ       165.564462464127
    x[1030]   c989      -1
    x[1030]   c990      1
    x[1030]   c3984     -1
    x[1030]   c4274     -1
    x[1030]   c4654     -1
    x[1030]   c4724     315
    x[1030]   c4725     -315
    x[1030]   c4734     52
    x[1030]   c4735     -52
    x[1030]   OBJ       -65.1220219025567
    x[1031]   c998      -1
    x[1031]   c999      1
    x[1031]   c4384     -1
    x[1031]   c4644     1
    x[1031]   c4654     1
    x[1031]   c4664     1
    x[1031]   c4674     1
    x[1031]   c4724     1346
    x[1031]   c4725     -1346
    x[1031]   c4734     1322
    x[1031]   c4735     -1322
    x[1031]   OBJ       -7019.93320847899
    x[1032]   c1007     -1
    x[1032]   c1008     1
    x[1032]   c3274     -1
    x[1032]   c4434     -1
    x[1032]   c4664     -1
    x[1032]   c4694     -1
    x[1032]   c4724     548
    x[1032]   c4725     -548
    x[1032]   c4734     133
    x[1032]   c4735     -133
    x[1032]   OBJ       -1053.35790229955
    x[1033]   c1016     -1
    x[1033]   c1017     1
    x[1033]   c3444     -1
    x[1033]   c4534     -1
    x[1033]   c4684     1
    x[1033]   c4694     1
    x[1033]   c4704     1
    x[1033]   c4714     1
    x[1033]   c4724     672
    x[1033]   c4725     -672
    x[1033]   c4734     672
    x[1033]   c4735     -672
    x[1033]   OBJ       -6181.07326532742
    x[1034]   c1025     -1
    x[1034]   c1026     1
    x[1034]   c3524     -1
    x[1034]   c4584     -1
    x[1034]   c4674     -1
    x[1034]   c4704     -1
    x[1034]   c4724     429
    x[1034]   c4725     -429
    x[1034]   c4734     142
    x[1034]   c4735     -142
    x[1034]   OBJ       -2229.60142785025
    x[1035]   c1034     -1
    x[1035]   c1035     1
    x[1035]   c3824     -1
    x[1035]   c4634     -1
    x[1035]   c4714     -1
    x[1035]   c4724     273
    x[1035]   c4725     -273
    x[1035]   c4734     94
    x[1035]   c4735     -94
    x[1035]   OBJ       -2075.07459621706
    x[1036]   c9        -1
    x[1036]   c2395     -1
    x[1036]   c4725     219
    x[1036]   c4735     75
    x[1036]   OBJ       -5242.6873802132
    x[1037]   c18       -1
    x[1037]   c1345     -1
    x[1037]   c4725     328
    x[1037]   c4735     215
    x[1037]   OBJ       -10700.8276664626
    x[1038]   c27       -1
    x[1038]   c1515     -1
    x[1038]   c3675     -1
    x[1038]   c4725     545
    x[1038]   c4735     368
    x[1038]   OBJ       -24441.9352292131
    x[1039]   c36       -1
    x[1039]   c1075     -1
    x[1039]   c1685     -1
    x[1039]   c4725     435
    x[1039]   c4735     400
    x[1039]   OBJ       -37273.3527442555
    x[1040]   c45       -1
    x[1040]   c1125     -1
    x[1040]   c4725     247
    x[1040]   c4735     216
    x[1040]   OBJ       -16613.812976566
    x[1041]   c54       -1
    x[1041]   c1975     -1
    x[1041]   c4725     82
    x[1041]   c4735     27
    x[1041]   OBJ       -1745.16853889289
    x[1042]   c63       -1
    x[1042]   c1085     -1
    x[1042]   c1245     -1
    x[1042]   c2515     -1
    x[1042]   c4725     526
    x[1042]   c4735     314
    x[1042]   OBJ       -16170.9375586028
    x[1043]   c72       -1
    x[1043]   c1045     1
    x[1043]   c1055     1
    x[1043]   c1065     1
    x[1043]   c1295     -1
    x[1043]   c4725     693
    x[1043]   c4735     693
    x[1043]   OBJ       -123765.724911882
    x[1044]   c81       -1
    x[1044]   c1045     -1
    x[1044]   c1075     1
    x[1044]   c1085     1
    x[1044]   c1095     1
    x[1044]   c1105     1
    x[1044]   c1115     1
    x[1044]   c1375     -1
    x[1044]   c2705     -1
    x[1044]   c4725     1944
    x[1044]   c4735     1944
    x[1044]   OBJ       -185050.107073279
    x[1045]   c90       -1
    x[1045]   c1095     -1
    x[1045]   c1135     -1
    x[1045]   c1425     -1
    x[1045]   c2785     -1
    x[1045]   c4725     907
    x[1045]   c4735     574
    x[1045]   OBJ       -53575.9559676582
    x[1046]   c99       -1
    x[1046]   c1055     -1
    x[1046]   c1125     1
    x[1046]   c1135     1
    x[1046]   c1145     1
    x[1046]   c1155     1
    x[1046]   c1165     1
    x[1046]   c1545     -1
    x[1046]   c4725     1296
    x[1046]   c4735     1128
    x[1046]   OBJ       -58995.7935150566
    x[1047]   c108      -1
    x[1047]   c1105     -1
    x[1047]   c1145     -1
    x[1047]   c1175     -1
    x[1047]   c1595     -1
    x[1047]   c1985     -1
    x[1047]   c2955     -1
    x[1047]   c4725     1043
    x[1047]   c4735     864
    x[1047]   OBJ       -48989.2029902662
    x[1048]   c117      -1
    x[1048]   c1175     1
    x[1048]   c1185     1
    x[1048]   c1195     1
    x[1048]   c1205     1
    x[1048]   c1715     -1
    x[1048]   c2155     -1
    x[1048]   c4725     1332
    x[1048]   c4735     1330
    x[1048]   OBJ       -112274.903256621
    x[1049]   c126      -1
    x[1049]   c1155     -1
    x[1049]   c1185     -1
    x[1049]   c1765     -1
    x[1049]   c2225     -1
    x[1049]   c4725     1186
    x[1049]   c4735     864
    x[1049]   OBJ       -67939.4830367354
    x[1050]   c135      -1
    x[1050]   c1195     -1
    x[1050]   c1845     -1
    x[1050]   c2525     -1
    x[1050]   c4725     984
    x[1050]   c4735     723
    x[1050]   OBJ       -33730.3494005498
    x[1051]   c144      -1
    x[1051]   c1255     -1
    x[1051]   c1895     -1
    x[1051]   c3255     -1
    x[1051]   c4725     225
    x[1051]   c4735     20
    x[1051]   OBJ       136.453507156234
    x[1052]   c153      -1
    x[1052]   c1215     1
    x[1052]   c1225     1
    x[1052]   c1235     1
    x[1052]   c1305     -1
    x[1052]   c1935     -1
    x[1052]   c4725     724
    x[1052]   c4735     724
    x[1052]   OBJ       -92165.9653599124
    x[1053]   c162      -1
    x[1053]   c1215     -1
    x[1053]   c1245     1
    x[1053]   c1255     1
    x[1053]   c1265     1
    x[1053]   c1275     1
    x[1053]   c1285     1
    x[1053]   c1385     -1
    x[1053]   c2005     -1
    x[1053]   c3425     -1
    x[1053]   c4725     1989
    x[1053]   c4735     1989
    x[1053]   OBJ       -79909.0889276331
    x[1054]   c171      -1
    x[1054]   c1265     -1
    x[1054]   c1435     -1
    x[1054]   c2055     -1
    x[1054]   c3505     -1
    x[1054]   c4725     710
    x[1054]   c4735     382
    x[1054]   OBJ       -22359.2238041969
    x[1055]   c180      -1
    x[1055]   c1295     1
    x[1055]   c1305     1
    x[1055]   c1315     1
    x[1055]   c1325     1
    x[1055]   c1335     1
    x[1055]   c1345     1
    x[1055]   c1355     1
    x[1055]   c1365     1
    x[1055]   c2105     -1
    x[1055]   c4725     716
    x[1055]   c4735     716
    x[1055]   c4845     1
    x[1055]   OBJ       -139565.604687867
    x[1056]   c189      -1
    x[1056]   c1315     -1
    x[1056]   c1375     1
    x[1056]   c1385     1
    x[1056]   c1395     1
    x[1056]   c1405     1
    x[1056]   c1415     1
    x[1056]   c1475     -1
    x[1056]   c2175     -1
    x[1056]   c3665     -1
    x[1056]   c4725     2876
    x[1056]   c4735     2876
    x[1056]   OBJ       -441439.065256308
    x[1057]   c198      -1
    x[1057]   c1065     -1
    x[1057]   c1225     -1
    x[1057]   c1395     -1
    x[1057]   c1425     1
    x[1057]   c1435     1
    x[1057]   c1445     1
    x[1057]   c1455     1
    x[1057]   c1465     1
    x[1057]   c1555     -1
    x[1057]   c2245     -1
    x[1057]   c3735     -1
    x[1057]   c4725     2595
    x[1057]   c4735     2595
    x[1057]   c4897     -1
    x[1057]   c4898     -1
    x[1057]   OBJ       -94440.190479183
    x[1058]   c207      -1
    x[1058]   c1115     -1
    x[1058]   c1275     -1
    x[1058]   c1445     -1
    x[1058]   c1605     -1
    x[1058]   c2295     -1
    x[1058]   c3795     -1
    x[1058]   c4725     1030
    x[1058]   c4735     552
    x[1058]   OBJ       -12639.903820788
    x[1059]   c216      -1
    x[1059]   c1475     1
    x[1059]   c1485     1
    x[1059]   c1495     1
    x[1059]   c1505     1
    x[1059]   c1515     1
    x[1059]   c1525     1
    x[1059]   c1535     1
    x[1059]   c2405     -1
    x[1059]   c4725     1432
    x[1059]   c4735     1432
    x[1059]   OBJ       -258782.879361209
    x[1060]   c225      -1
    x[1060]   c1325     -1
    x[1060]   c1485     -1
    x[1060]   c1545     1
    x[1060]   c1555     1
    x[1060]   c1565     1
    x[1060]   c1575     1
    x[1060]   c1585     1
    x[1060]   c1645     -1
    x[1060]   c2465     -1
    x[1060]   c4725     2864
    x[1060]   c4735     2864
    x[1060]   OBJ       -354539.72648839
    x[1061]   c234      -1
    x[1061]   c1405     -1
    x[1061]   c1565     -1
    x[1061]   c1595     1
    x[1061]   c1605     1
    x[1061]   c1615     1
    x[1061]   c1625     1
    x[1061]   c1635     1
    x[1061]   c1725     -1
    x[1061]   c2555     -1
    x[1061]   c4725     2600
    x[1061]   c4735     2336
    x[1061]   c4788     -1
    x[1061]   OBJ       -135352.303414271
    x[1062]   c243      -1
    x[1062]   c1165     -1
    x[1062]   c1455     -1
    x[1062]   c1615     -1
    x[1062]   c1775     -1
    x[1062]   c2605     -1
    x[1062]   c3975     -1
    x[1062]   c4725     1156
    x[1062]   c4735     696
    x[1062]   OBJ       -31384.3066459338
    x[1063]   c252      -1
    x[1063]   c1645     1
    x[1063]   c1655     1
    x[1063]   c1665     1
    x[1063]   c1675     1
    x[1063]   c1685     1
    x[1063]   c1695     1
    x[1063]   c1705     1
    x[1063]   c2655     -1
    x[1063]   c4725     716
    x[1063]   c4735     716
    x[1063]   OBJ       -129511.135739513
    x[1064]   c261      -1
    x[1064]   c1495     -1
    x[1064]   c1655     -1
    x[1064]   c1715     1
    x[1064]   c1725     1
    x[1064]   c1735     1
    x[1064]   c1745     1
    x[1064]   c1755     1
    x[1064]   c2735     -1
    x[1064]   c4725     2864
    x[1064]   c4735     2864
    x[1064]   OBJ       -401939.365816345
    x[1065]   c270      -1
    x[1065]   c1575     -1
    x[1065]   c1735     -1
    x[1065]   c1765     1
    x[1065]   c1775     1
    x[1065]   c1785     1
    x[1065]   c1795     1
    x[1065]   c1805     1
    x[1065]   c1815     -1
    x[1065]   c2815     -1
    x[1065]   c4725     2681
    x[1065]   c4735     2678
    x[1065]   OBJ       -374409.27226728
    x[1066]   c279      -1
    x[1066]   c1205     -1
    x[1066]   c1625     -1
    x[1066]   c1785     -1
    x[1066]   c1855     -1
    x[1066]   c2865     -1
    x[1066]   c3265     -1
    x[1066]   c4725     1263
    x[1066]   c4735     864
    x[1066]   OBJ       -135256.546567144
    x[1067]   c288      -1
    x[1067]   c1665     -1
    x[1067]   c1815     1
    x[1067]   c1825     1
    x[1067]   c1835     1
    x[1067]   c2915     -1
    x[1067]   c4725     716
    x[1067]   c4735     716
    x[1067]   OBJ       -87617.5151213713
    x[1068]   c297      -1
    x[1068]   c1745     -1
    x[1068]   c1825     -1
    x[1068]   c1845     1
    x[1068]   c1855     1
    x[1068]   c1865     1
    x[1068]   c1875     1
    x[1068]   c1885     1
    x[1068]   c2985     -1
    x[1068]   c3435     -1
    x[1068]   c4725     1965
    x[1068]   c4735     1964
    x[1068]   OBJ       -156083.660817306
    x[1069]   c306      -1
    x[1069]   c1795     -1
    x[1069]   c1865     -1
    x[1069]   c3035     -1
    x[1069]   c3515     -1
    x[1069]   c4725     1245
    x[1069]   c4735     889
    x[1069]   OBJ       -75815.4837129461
    x[1070]   c315      -1
    x[1070]   c1875     -1
    x[1070]   c3085     -1
    x[1070]   c3805     -1
    x[1070]   c4725     832
    x[1070]   c4735     647
    x[1070]   OBJ       -22727.8876656366
    x[1071]   c324      -1
    x[1071]   c4725     339
    x[1071]   c4735     283
    x[1071]   OBJ       -13382.0193860236
    x[1072]   c333      -1
    x[1072]   c1895     1
    x[1072]   c1905     1
    x[1072]   c1915     1
    x[1072]   c1925     1
    x[1072]   c2015     -1
    x[1072]   c4725     1346
    x[1072]   c4735     1346
    x[1072]   OBJ       -109880.982078441
    x[1073]   c342      -1
    x[1073]   c1905     -1
    x[1073]   c2065     -1
    x[1073]   c4725     243
    x[1073]   OBJ       1739.90191230089
    x[1074]   c351      -1
    x[1074]   c1935     1
    x[1074]   c1945     1
    x[1074]   c1955     1
    x[1074]   c1965     1
    x[1074]   c1975     1
    x[1074]   c1985     1
    x[1074]   c1995     1
    x[1074]   c2115     -1
    x[1074]   c4725     724
    x[1074]   c4735     724
    x[1074]   OBJ       -126159.646090062
    x[1075]   c360      -1
    x[1075]   c1945     -1
    x[1075]   c2005     1
    x[1075]   c2015     1
    x[1075]   c2025     1
    x[1075]   c2035     1
    x[1075]   c2045     1
    x[1075]   c2185     -1
    x[1075]   c4725     2896
    x[1075]   c4735     2896
    x[1075]   OBJ       -390209.152043265
    x[1076]   c369      -1
    x[1076]   c1235     -1
    x[1076]   c2025     -1
    x[1076]   c2055     1
    x[1076]   c2065     1
    x[1076]   c2075     1
    x[1076]   c2085     1
    x[1076]   c2095     1
    x[1076]   c2255     -1
    x[1076]   c3135     -1
    x[1076]   c4725     2692
    x[1076]   c4735     2692
    x[1076]   OBJ       -195104.576021633
    x[1077]   c378      -1
    x[1077]   c1285     -1
    x[1077]   c1915     -1
    x[1077]   c2075     -1
    x[1077]   c2305     -1
    x[1077]   c3165     -1
    x[1077]   c4725     755
    x[1077]   c4735     323
    x[1077]   OBJ       -16462.9959423407
    x[1078]   c387      -1
    x[1078]   c2105     1
    x[1078]   c2115     1
    x[1078]   c2125     1
    x[1078]   c2135     1
    x[1078]   c2145     1
    x[1078]   c2155     1
    x[1078]   c2165     1
    x[1078]   c2345     -1
    x[1078]   c4725     1432
    x[1078]   c4735     1432
    x[1078]   OBJ       -266443.427131383
    x[1079]   c396      -1
    x[1079]   c2125     -1
    x[1079]   c2175     1
    x[1079]   c2185     1
    x[1079]   c2195     1
    x[1079]   c2205     1
    x[1079]   c2215     1
    x[1079]   c2225     1
    x[1079]   c2235     1
    x[1079]   c2415     -1
    x[1079]   c4725     2886
    x[1079]   c4735     2886
    x[1079]   c4846     1
    x[1079]   OBJ       -502005.27106425
    x[1080]   c405      -1
    x[1080]   c1335     -1
    x[1080]   c1955     -1
    x[1080]   c2195     -1
    x[1080]   c2245     1
    x[1080]   c2255     1
    x[1080]   c2265     1
    x[1080]   c2275     1
    x[1080]   c2285     1
    x[1080]   c2475     -1
    x[1080]   c3215     -1
    x[1080]   c4725     2895
    x[1080]   c4735     2895
    x[1080]   OBJ       -417739.24559233
    x[1081]   c414      -1
    x[1081]   c1415     -1
    x[1081]   c2035     -1
    x[1081]   c2265     -1
    x[1081]   c2295     1
    x[1081]   c2305     1
    x[1081]   c2315     1
    x[1081]   c2325     1
    x[1081]   c2335     1
    x[1081]   c2565     -1
    x[1081]   c3285     -1
    x[1081]   c4725     2692
    x[1081]   c4735     2668
    x[1081]   OBJ       -163983.600705299
    x[1082]   c423      -1
    x[1082]   c1465     -1
    x[1082]   c2085     -1
    x[1082]   c2315     -1
    x[1082]   c2615     -1
    x[1082]   c3335     -1
    x[1082]   c4325     -1
    x[1082]   c4725     1115
    x[1082]   c4735     408
    x[1082]   OBJ       -12072.5445015594
    x[1083]   c432      -1
    x[1083]   c2345     1
    x[1083]   c2355     1
    x[1083]   c2365     1
    x[1083]   c2375     1
    x[1083]   c2385     1
    x[1083]   c2395     1
    x[1083]   c4725     1432
    x[1083]   c4735     1432
    x[1083]   OBJ       -304027.989628802
    x[1084]   c441      -1
    x[1084]   c2355     -1
    x[1084]   c2405     1
    x[1084]   c2415     1
    x[1084]   c2425     1
    x[1084]   c2435     1
    x[1084]   c2445     1
    x[1084]   c2455     1
    x[1084]   c4725     2864
    x[1084]   c4735     2864
    x[1084]   OBJ       -556347.281808926
    x[1085]   c450      -1
    x[1085]   c2135     -1
    x[1085]   c2425     -1
    x[1085]   c2465     1
    x[1085]   c2475     1
    x[1085]   c2485     1
    x[1085]   c2495     1
    x[1085]   c2505     1
    x[1085]   c2515     1
    x[1085]   c2525     1
    x[1085]   c2535     1
    x[1085]   c2545     1
    x[1085]   c2665     -1
    x[1085]   c3385     -1
    x[1085]   c4725     2864
    x[1085]   c4735     2864
    x[1085]   c4788     1
    x[1085]   OBJ       -525465.69861041
    x[1086]   c459      -1
    x[1086]   c1505     -1
    x[1086]   c2205     -1
    x[1086]   c2485     -1
    x[1086]   c2555     1
    x[1086]   c2565     1
    x[1086]   c2575     1
    x[1086]   c2585     1
    x[1086]   c2595     1
    x[1086]   c2745     -1
    x[1086]   c3455     -1
    x[1086]   c4725     2873
    x[1086]   c4735     2873
    x[1086]   OBJ       -404093.894876707
    x[1087]   c468      -1
    x[1087]   c1585     -1
    x[1087]   c2275     -1
    x[1087]   c2575     -1
    x[1087]   c2605     1
    x[1087]   c2615     1
    x[1087]   c2625     1
    x[1087]   c2635     1
    x[1087]   c2645     1
    x[1087]   c2825     -1
    x[1087]   c3535     -1
    x[1087]   c4725     2679
    x[1087]   c4735     2604
    x[1087]   c4845     -1
    x[1087]   c4846     -1
    x[1087]   OBJ       -140355.598676667
    x[1088]   c477      -1
    x[1088]   c1635     -1
    x[1088]   c2325     -1
    x[1088]   c2625     -1
    x[1088]   c2875     -1
    x[1088]   c3585     -1
    x[1088]   c4475     -1
    x[1088]   c4725     1252
    x[1088]   c4735     552
    x[1088]   OBJ       -27656.9713715083
    x[1089]   c486      -1
    x[1089]   c2365     -1
    x[1089]   c2655     1
    x[1089]   c2665     1
    x[1089]   c2675     1
    x[1089]   c2685     1
    x[1089]   c2695     1
    x[1089]   c2705     1
    x[1089]   c2715     1
    x[1089]   c2725     1
    x[1089]   c3635     -1
    x[1089]   c4725     2148
    x[1089]   c4735     2148
    x[1089]   c4897     1
    x[1089]   OBJ       -368903.253557468
    x[1090]   c495      -1
    x[1090]   c2435     -1
    x[1090]   c2675     -1
    x[1090]   c2735     1
    x[1090]   c2745     1
    x[1090]   c2755     1
    x[1090]   c2765     1
    x[1090]   c2775     1
    x[1090]   c2785     1
    x[1090]   c2795     1
    x[1090]   c2805     1
    x[1090]   c3685     -1
    x[1090]   c4725     2864
    x[1090]   c4735     2864
    x[1090]   c4820     1
    x[1090]   OBJ       -481417.548931906
    x[1091]   c504      -1
    x[1091]   c1675     -1
    x[1091]   c2495     -1
    x[1091]   c2755     -1
    x[1091]   c2815     1
    x[1091]   c2825     1
    x[1091]   c2835     1
    x[1091]   c2845     1
    x[1091]   c2855     1
    x[1091]   c2925     -1
    x[1091]   c3745     -1
    x[1091]   c4725     2864
    x[1091]   c4735     2864
    x[1091]   OBJ       -440481.496785036
    x[1092]   c513      -1
    x[1092]   c1755     -1
    x[1092]   c2585     -1
    x[1092]   c2835     -1
    x[1092]   c2865     1
    x[1092]   c2875     1
    x[1092]   c2885     1
    x[1092]   c2895     1
    x[1092]   c2905     1
    x[1092]   c2995     -1
    x[1092]   c3835     -1
    x[1092]   c4725     2684
    x[1092]   c4735     2680
    x[1092]   c4865     -1
    x[1092]   OBJ       -374409.27226728
    x[1093]   c522      -1
    x[1093]   c1805     -1
    x[1093]   c2635     -1
    x[1093]   c2885     -1
    x[1093]   c3045     -1
    x[1093]   c3885     -1
    x[1093]   c4725     1253
    x[1093]   c4735     840
    x[1093]   OBJ       -103417.394897356
    x[1094]   c531      -1
    x[1094]   c2685     -1
    x[1094]   c2915     1
    x[1094]   c2925     1
    x[1094]   c2935     1
    x[1094]   c2945     1
    x[1094]   c2955     1
    x[1094]   c2965     1
    x[1094]   c2975     1
    x[1094]   c4725     716
    x[1094]   c4735     716
    x[1094]   OBJ       -138847.428334413
    x[1095]   c540      -1
    x[1095]   c2765     -1
    x[1095]   c2935     -1
    x[1095]   c2985     1
    x[1095]   c2995     1
    x[1095]   c3005     1
    x[1095]   c3015     1
    x[1095]   c3025     1
    x[1095]   c3935     -1
    x[1095]   c4725     2864
    x[1095]   c4735     2864
    x[1095]   OBJ       -386857.662393814
    x[1096]   c549      -1
    x[1096]   c1835     -1
    x[1096]   c2845     -1
    x[1096]   c3005     -1
    x[1096]   c3035     1
    x[1096]   c3045     1
    x[1096]   c3055     1
    x[1096]   c3065     1
    x[1096]   c3075     1
    x[1096]   c3995     -1
    x[1096]   c4725     2651
    x[1096]   c4735     2650
    x[1096]   OBJ       -297803.794565535
    x[1097]   c558      -1
    x[1097]   c1885     -1
    x[1097]   c2895     -1
    x[1097]   c3055     -1
    x[1097]   c3095     -1
    x[1097]   c4045     -1
    x[1097]   c4725     1175
    x[1097]   c4735     768
    x[1097]   OBJ       -91304.1537357678
    x[1098]   c567      -1
    x[1098]   c3015     -1
    x[1098]   c3085     1
    x[1098]   c3095     1
    x[1098]   c3105     1
    x[1098]   c3115     1
    x[1098]   c3125     1
    x[1098]   c4725     1333
    x[1098]   c4735     1332
    x[1098]   OBJ       -104614.355486446
    x[1099]   c576      -1
    x[1099]   c3065     -1
    x[1099]   c3105     -1
    x[1099]   c4095     -1
    x[1099]   c4335     -1
    x[1099]   c4725     940
    x[1099]   c4735     728
    x[1099]   OBJ       -71721.8784982591
    x[1100]   c585      -1
    x[1100]   c3115     -1
    x[1100]   c4485     -1
    x[1100]   c4725     342
    x[1100]   c4735     317
    x[1100]   OBJ       -17715.0167185286
    x[1101]   c594      -1
    x[1101]   c1355     -1
    x[1101]   c1925     -1
    x[1101]   c3175     -1
    x[1101]   c4725     187
    x[1101]   OBJ       1320.72631400165
    x[1102]   c603      -1
    x[1102]   c1965     -1
    x[1102]   c3135     1
    x[1102]   c3145     1
    x[1102]   c3155     1
    x[1102]   c3225     -1
    x[1102]   c4725     724
    x[1102]   c4735     724
    x[1102]   OBJ       -70860.0668741145
    x[1103]   c612      -1
    x[1103]   c2045     -1
    x[1103]   c3145     -1
    x[1103]   c3165     1
    x[1103]   c3175     1
    x[1103]   c3185     1
    x[1103]   c3195     1
    x[1103]   c3205     1
    x[1103]   c3295     -1
    x[1103]   c4725     2019
    x[1103]   c4735     1995
    x[1103]   OBJ       -83021.1864592665
    x[1104]   c621      -1
    x[1104]   c1525     -1
    x[1104]   c2095     -1
    x[1104]   c3185     -1
    x[1104]   c3345     -1
    x[1104]   c4725     660
    x[1104]   c4735     174
    x[1104]   OBJ       -9590.04823978725
    x[1105]   c630      -1
    x[1105]   c2145     -1
    x[1105]   c3215     1
    x[1105]   c3225     1
    x[1105]   c3235     1
    x[1105]   c3245     1
    x[1105]   c3255     1
    x[1105]   c3265     1
    x[1105]   c3275     1
    x[1105]   c3395     -1
    x[1105]   c4725     1447
    x[1105]   c4735     1447
    x[1105]   c4898     1
    x[1105]   OBJ       -211143.847915436
    x[1106]   c639      -1
    x[1106]   c2215     -1
    x[1106]   c3235     -1
    x[1106]   c3285     1
    x[1106]   c3295     1
    x[1106]   c3305     1
    x[1106]   c3315     1
    x[1106]   c3325     1
    x[1106]   c3465     -1
    x[1106]   c4725     2896
    x[1106]   c4735     2896
    x[1106]   OBJ       -284876.620203366
    x[1107]   c648      -1
    x[1107]   c2285     -1
    x[1107]   c3155     -1
    x[1107]   c3305     -1
    x[1107]   c3335     1
    x[1107]   c3345     1
    x[1107]   c3355     1
    x[1107]   c3365     1
    x[1107]   c3375     1
    x[1107]   c3545     -1
    x[1107]   c4725     2692
    x[1107]   c4735     2692
    x[1107]   OBJ       -116200.933988835
    x[1108]   c657      -1
    x[1108]   c1695     -1
    x[1108]   c2335     -1
    x[1108]   c3195     -1
    x[1108]   c3355     -1
    x[1108]   c3595     -1
    x[1108]   c4145     -1
    x[1108]   c4725     964
    x[1108]   c4735     288
    x[1108]   OBJ       -9348.26220079111
    x[1109]   c666      -1
    x[1109]   c2375     -1
    x[1109]   c3385     1
    x[1109]   c3395     1
    x[1109]   c3405     1
    x[1109]   c3415     1
    x[1109]   c3425     1
    x[1109]   c3435     1
    x[1109]   c3445     1
    x[1109]   c3645     -1
    x[1109]   c4725     1432
    x[1109]   c4735     1432
    x[1109]   c4791     1
    x[1109]   OBJ       -270034.308898652
    x[1110]   c675      -1
    x[1110]   c2445     -1
    x[1110]   c3405     -1
    x[1110]   c3455     1
    x[1110]   c3465     1
    x[1110]   c3475     1
    x[1110]   c3485     1
    x[1110]   c3495     1
    x[1110]   c3505     1
    x[1110]   c3515     1
    x[1110]   c3525     1
    x[1110]   c3695     -1
    x[1110]   c4725     2872
    x[1110]   c4735     2872
    x[1110]   c4934     1
    x[1110]   OBJ       -445029.947023577
    x[1111]   c684      -1
    x[1111]   c2505     -1
    x[1111]   c3245     -1
    x[1111]   c3475     -1
    x[1111]   c3535     1
    x[1111]   c3545     1
    x[1111]   c3555     1
    x[1111]   c3565     1
    x[1111]   c3575     1
    x[1111]   c3755     -1
    x[1111]   c4725     2888
    x[1111]   c4735     2888
    x[1111]   OBJ       -343767.081186582
    x[1112]   c693      -1
    x[1112]   c2595     -1
    x[1112]   c3315     -1
    x[1112]   c3555     -1
    x[1112]   c3585     1
    x[1112]   c3595     1
    x[1112]   c3605     1
    x[1112]   c3615     1
    x[1112]   c3625     1
    x[1112]   c3845     -1
    x[1112]   c4195     -1
    x[1112]   c4725     2692
    x[1112]   c4735     2692
    x[1112]   OBJ       -162307.855880573
    x[1113]   c702      -1
    x[1113]   c2645     -1
    x[1113]   c3365     -1
    x[1113]   c3605     -1
    x[1113]   c3895     -1
    x[1113]   c4235     -1
    x[1113]   c4725     1168
    x[1113]   c4735     528
    x[1113]   OBJ       -31025.2184692069
    x[1114]   c711      -1
    x[1114]   c3635     1
    x[1114]   c3645     1
    x[1114]   c3655     1
    x[1114]   c3665     1
    x[1114]   c3675     1
    x[1114]   c4725     716
    x[1114]   c4735     716
    x[1114]   OBJ       -159913.934702393
    x[1115]   c720      -1
    x[1115]   c3655     -1
    x[1115]   c3685     1
    x[1115]   c3695     1
    x[1115]   c3705     1
    x[1115]   c3715     1
    x[1115]   c3725     1
    x[1115]   c3735     1
    x[1115]   c4725     2864
    x[1115]   c4735     2864
    x[1115]   OBJ       -553474.57639511
    x[1116]   c729      -1
    x[1116]   c2695     -1
    x[1116]   c3415     -1
    x[1116]   c3705     -1
    x[1116]   c3745     1
    x[1116]   c3755     1
    x[1116]   c3765     1
    x[1116]   c3775     1
    x[1116]   c3785     1
    x[1116]   c3795     1
    x[1116]   c3805     1
    x[1116]   c3815     1
    x[1116]   c3825     1
    x[1116]   c4725     2864
    x[1116]   c4735     2864
    x[1116]   c4865     1
    x[1116]   OBJ       -561613.908400921
    x[1117]   c738      -1
    x[1117]   c2775     -1
    x[1117]   c3485     -1
    x[1117]   c3765     -1
    x[1117]   c3835     1
    x[1117]   c3845     1
    x[1117]   c3855     1
    x[1117]   c3865     1
    x[1117]   c3875     1
    x[1117]   c3945     -1
    x[1117]   c4285     -1
    x[1117]   c4725     2865
    x[1117]   c4735     2865
    x[1117]   c4791     -1
    x[1117]   OBJ       -537674.696619125
    x[1118]   c747      -1
    x[1118]   c2855     -1
    x[1118]   c3565     -1
    x[1118]   c3855     -1
    x[1118]   c3885     1
    x[1118]   c3895     1
    x[1118]   c3905     1
    x[1118]   c3915     1
    x[1118]   c3925     1
    x[1118]   c4005     -1
    x[1118]   c4345     -1
    x[1118]   c4725     2686
    x[1118]   c4735     2684
    x[1118]   c4934     -1
    x[1118]   OBJ       -316476.379755336
    x[1119]   c756      -1
    x[1119]   c1365     -1
    x[1119]   c2905     -1
    x[1119]   c3615     -1
    x[1119]   c3905     -1
    x[1119]   c4055     -1
    x[1119]   c4395     -1
    x[1119]   c4725     1152
    x[1119]   c4735     624
    x[1119]   OBJ       -61978.6193030684
    x[1120]   c765      -1
    x[1120]   c3715     -1
    x[1120]   c3935     1
    x[1120]   c3945     1
    x[1120]   c3955     1
    x[1120]   c3965     1
    x[1120]   c3975     1
    x[1120]   c3985     1
    x[1120]   c4725     1432
    x[1120]   c4735     1432
    x[1120]   OBJ       -284397.83596773
    x[1121]   c774      -1
    x[1121]   c2945     -1
    x[1121]   c3775     -1
    x[1121]   c3955     -1
    x[1121]   c3995     1
    x[1121]   c4005     1
    x[1121]   c4015     1
    x[1121]   c4025     1
    x[1121]   c4035     1
    x[1121]   c4445     -1
    x[1121]   c4725     2864
    x[1121]   c4735     2864
    x[1121]   OBJ       -408163.560879612
    x[1122]   c783      -1
    x[1122]   c3025     -1
    x[1122]   c3865     -1
    x[1122]   c4015     -1
    x[1122]   c4045     1
    x[1122]   c4055     1
    x[1122]   c4065     1
    x[1122]   c4075     1
    x[1122]   c4085     1
    x[1122]   c4495     -1
    x[1122]   c4725     2684
    x[1122]   c4735     2680
    x[1122]   c4820     -1
    x[1122]   OBJ       -285116.012321184
    x[1123]   c792      -1
    x[1123]   c1535     -1
    x[1123]   c3075     -1
    x[1123]   c3915     -1
    x[1123]   c4065     -1
    x[1123]   c4105     -1
    x[1123]   c4545     -1
    x[1123]   c4725     1099
    x[1123]   c4735     672
    x[1123]   OBJ       -88646.9012279885
    x[1124]   c801      -1
    x[1124]   c4025     -1
    x[1124]   c4095     1
    x[1124]   c4105     1
    x[1124]   c4115     1
    x[1124]   c4125     1
    x[1124]   c4135     1
    x[1124]   c4725     1342
    x[1124]   c4735     1340
    x[1124]   OBJ       -67508.5772246631
    x[1125]   c810      -1
    x[1125]   c1705     -1
    x[1125]   c3125     -1
    x[1125]   c4075     -1
    x[1125]   c4115     -1
    x[1125]   c4595     -1
    x[1125]   c4725     880
    x[1125]   c4735     629
    x[1125]   OBJ       -51876.2719311507
    x[1126]   c819      -1
    x[1126]   c4125     -1
    x[1126]   c4725     326
    x[1126]   c4735     256
    x[1126]   OBJ       -19175.3086372181
    x[1127]   c828      -1
    x[1127]   c2535     -1
    x[1127]   c3205     -1
    x[1127]   c4155     -1
    x[1127]   c4725     360
    x[1127]   OBJ       2580.64703007755
    x[1128]   c837      -1
    x[1128]   c2715     -1
    x[1128]   c3325     -1
    x[1128]   c4145     1
    x[1128]   c4155     1
    x[1128]   c4165     1
    x[1128]   c4175     1
    x[1128]   c4185     1
    x[1128]   c4205     -1
    x[1128]   c4725     1346
    x[1128]   c4735     1322
    x[1128]   OBJ       -30761.8871396071
    x[1129]   c846      -1
    x[1129]   c2795     -1
    x[1129]   c3375     -1
    x[1129]   c4165     -1
    x[1129]   c4245     -1
    x[1129]   c4725     689
    x[1129]   c4735     241
    x[1129]   OBJ       -12501.0563924536
    x[1130]   c855      -1
    x[1130]   c3495     -1
    x[1130]   c4195     1
    x[1130]   c4205     1
    x[1130]   c4215     1
    x[1130]   c4225     1
    x[1130]   c4295     -1
    x[1130]   c4725     1448
    x[1130]   c4735     1448
    x[1130]   OBJ       -117541.529848616
    x[1131]   c864      -1
    x[1131]   c3575     -1
    x[1131]   c4215     -1
    x[1131]   c4235     1
    x[1131]   c4245     1
    x[1131]   c4255     1
    x[1131]   c4265     1
    x[1131]   c4275     1
    x[1131]   c4355     -1
    x[1131]   c4725     2692
    x[1131]   c4735     2668
    x[1131]   OBJ       -68083.1183074262
    x[1132]   c873      -1
    x[1132]   c1995     -1
    x[1132]   c2965     -1
    x[1132]   c3625     -1
    x[1132]   c4175     -1
    x[1132]   c4255     -1
    x[1132]   c4405     -1
    x[1132]   c4725     828
    x[1132]   c4735     291
    x[1132]   OBJ       -10471.0112333573
    x[1133]   c882      -1
    x[1133]   c3725     -1
    x[1133]   c4285     1
    x[1133]   c4295     1
    x[1133]   c4305     1
    x[1133]   c4315     1
    x[1133]   c4325     1
    x[1133]   c4335     1
    x[1133]   c4725     1432
    x[1133]   c4735     1432
    x[1133]   OBJ       -278413.033022281
    x[1134]   c891      -1
    x[1134]   c3785     -1
    x[1134]   c4305     -1
    x[1134]   c4345     1
    x[1134]   c4355     1
    x[1134]   c4365     1
    x[1134]   c4375     1
    x[1134]   c4385     1
    x[1134]   c4455     -1
    x[1134]   c4725     2880
    x[1134]   c4735     2880
    x[1134]   OBJ       -422766.480066507
    x[1135]   c900      -1
    x[1135]   c2165     -1
    x[1135]   c3875     -1
    x[1135]   c4225     -1
    x[1135]   c4365     -1
    x[1135]   c4395     1
    x[1135]   c4405     1
    x[1135]   c4415     1
    x[1135]   c4425     1
    x[1135]   c4435     1
    x[1135]   c4505     -1
    x[1135]   c4725     2691
    x[1135]   c4735     2691
    x[1135]   OBJ       -143874.662808591
    x[1136]   c909      -1
    x[1136]   c2235     -1
    x[1136]   c3925     -1
    x[1136]   c4265     -1
    x[1136]   c4415     -1
    x[1136]   c4555     -1
    x[1136]   c4645     -1
    x[1136]   c4725     840
    x[1136]   c4735     543
    x[1136]   OBJ       -41989.3774652692
    x[1137]   c918      -1
    x[1137]   c4445     1
    x[1137]   c4455     1
    x[1137]   c4465     1
    x[1137]   c4475     1
    x[1137]   c4485     1
    x[1137]   c4725     716
    x[1137]   c4735     716
    x[1137]   OBJ       -141480.741630411
    x[1138]   c927      -1
    x[1138]   c2385     -1
    x[1138]   c3965     -1
    x[1138]   c4315     -1
    x[1138]   c4465     -1
    x[1138]   c4495     1
    x[1138]   c4505     1
    x[1138]   c4515     1
    x[1138]   c4525     1
    x[1138]   c4535     1
    x[1138]   c4725     2148
    x[1138]   c4735     2148
    x[1138]   OBJ       -359088.176726931
    x[1139]   c936      -1
    x[1139]   c2455     -1
    x[1139]   c4035     -1
    x[1139]   c4375     -1
    x[1139]   c4515     -1
    x[1139]   c4545     1
    x[1139]   c4555     1
    x[1139]   c4565     1
    x[1139]   c4575     1
    x[1139]   c4585     1
    x[1139]   c4725     2684
    x[1139]   c4735     2680
    x[1139]   OBJ       -316476.379755336
    x[1140]   c945      -1
    x[1140]   c2545     -1
    x[1140]   c4085     -1
    x[1140]   c4425     -1
    x[1140]   c4565     -1
    x[1140]   c4605     -1
    x[1140]   c4685     -1
    x[1140]   c4725     841
    x[1140]   c4735     480
    x[1140]   OBJ       -74474.8878531656
    x[1141]   c954      -1
    x[1141]   c2725     -1
    x[1141]   c4525     -1
    x[1141]   c4595     1
    x[1141]   c4605     1
    x[1141]   c4615     1
    x[1141]   c4625     1
    x[1141]   c4635     1
    x[1141]   c4725     671
    x[1141]   c4735     670
    x[1141]   OBJ       -56496.5398050372
    x[1142]   c963      -1
    x[1142]   c2805     -1
    x[1142]   c4135     -1
    x[1142]   c4575     -1
    x[1142]   c4615     -1
    x[1142]   c4725     754
    x[1142]   c4735     450
    x[1142]   OBJ       -65904.6500352828
    x[1143]   c972      -1
    x[1143]   c2975     -1
    x[1143]   c4625     -1
    x[1143]   c4725     289
    x[1143]   c4735     186
    x[1143]   OBJ       -17547.442236056
    x[1144]   c981      -1
    x[1144]   c3815     -1
    x[1144]   c4185     -1
    x[1144]   c4725     150
    x[1144]   OBJ       1077.26453018079
    x[1145]   c990      -1
    x[1145]   c3985     -1
    x[1145]   c4275     -1
    x[1145]   c4655     -1
    x[1145]   c4725     315
    x[1145]   c4735     52
    x[1145]   OBJ       -423.724048537779
    x[1146]   c999      -1
    x[1146]   c4385     -1
    x[1146]   c4645     1
    x[1146]   c4655     1
    x[1146]   c4665     1
    x[1146]   c4675     1
    x[1146]   c4725     1346
    x[1146]   c4735     1322
    x[1146]   OBJ       -45676.0160796657
    x[1147]   c1008     -1
    x[1147]   c3275     -1
    x[1147]   c4435     -1
    x[1147]   c4665     -1
    x[1147]   c4695     -1
    x[1147]   c4725     548
    x[1147]   c4735     133
    x[1147]   OBJ       -6853.79633312803
    x[1148]   c1017     -1
    x[1148]   c3445     -1
    x[1148]   c4535     -1
    x[1148]   c4685     1
    x[1148]   c4695     1
    x[1148]   c4705     1
    x[1148]   c4715     1
    x[1148]   c4725     672
    x[1148]   c4735     672
    x[1148]   OBJ       -40217.8757934163
    x[1149]   c1026     -1
    x[1149]   c3525     -1
    x[1149]   c4585     -1
    x[1149]   c4675     -1
    x[1149]   c4705     -1
    x[1149]   c4725     429
    x[1149]   c4735     142
    x[1149]   OBJ       -14507.162339768
    x[1150]   c1035     -1
    x[1150]   c3825     -1
    x[1150]   c4635     -1
    x[1150]   c4715     -1
    x[1150]   c4725     273
    x[1150]   c4735     94
    x[1150]   OBJ       -13501.7154449326
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1        0
    rhs       c2        0
    rhs       c3        0
    rhs       c4        0
    rhs       c5        0
    rhs       c6        0
    rhs       c7        0
    rhs       c8        0
    rhs       c9        0
    rhs       c10       0
    rhs       c11       0
    rhs       c12       0
    rhs       c13       0
    rhs       c14       0
    rhs       c15       0
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
    rhs       c70       0
    rhs       c71       0
    rhs       c72       0
    rhs       c73       0
    rhs       c74       0
    rhs       c75       0
    rhs       c76       0
    rhs       c77       0
    rhs       c78       0
    rhs       c79       0
    rhs       c80       0
    rhs       c81       0
    rhs       c82       0
    rhs       c83       0
    rhs       c84       0
    rhs       c85       0
    rhs       c86       0
    rhs       c87       0
    rhs       c88       0
    rhs       c89       0
    rhs       c90       0
    rhs       c91       0
    rhs       c92       0
    rhs       c93       0
    rhs       c94       0
    rhs       c95       0
    rhs       c96       0
    rhs       c97       0
    rhs       c98       0
    rhs       c99       0
    rhs       c100      0
    rhs       c101      0
    rhs       c102      0
    rhs       c103      0
    rhs       c104      0
    rhs       c105      0
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      0
    rhs       c262      0
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      0
    rhs       c275      0
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      0
    rhs       c289      0
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      0
    rhs       c299      0
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      0
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      0
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      0
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     0
    rhs       c1207     0
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     0
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     0
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     0
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     0
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     0
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     0
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     0
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     0
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     0
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     0
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     0
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     0
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     0
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     0
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     0
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     0
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
    rhs       c1981     0
    rhs       c1982     0
    rhs       c1983     0
    rhs       c1984     0
    rhs       c1985     0
    rhs       c1986     0
    rhs       c1987     0
    rhs       c1988     0
    rhs       c1989     0
    rhs       c1990     0
    rhs       c1991     0
    rhs       c1992     0
    rhs       c1993     0
    rhs       c1994     0
    rhs       c1995     0
    rhs       c1996     0
    rhs       c1997     0
    rhs       c1998     0
    rhs       c1999     0
    rhs       c2000     0
    rhs       c2001     0
    rhs       c2002     0
    rhs       c2003     0
    rhs       c2004     0
    rhs       c2005     0
    rhs       c2006     0
    rhs       c2007     0
    rhs       c2008     0
    rhs       c2009     0
    rhs       c2010     0
    rhs       c2011     0
    rhs       c2012     0
    rhs       c2013     0
    rhs       c2014     0
    rhs       c2015     0
    rhs       c2016     0
    rhs       c2017     0
    rhs       c2018     0
    rhs       c2019     0
    rhs       c2020     0
    rhs       c2021     0
    rhs       c2022     0
    rhs       c2023     0
    rhs       c2024     0
    rhs       c2025     0
    rhs       c2026     0
    rhs       c2027     0
    rhs       c2028     0
    rhs       c2029     0
    rhs       c2030     0
    rhs       c2031     0
    rhs       c2032     0
    rhs       c2033     0
    rhs       c2034     0
    rhs       c2035     0
    rhs       c2036     0
    rhs       c2037     0
    rhs       c2038     0
    rhs       c2039     0
    rhs       c2040     0
    rhs       c2041     0
    rhs       c2042     0
    rhs       c2043     0
    rhs       c2044     0
    rhs       c2045     0
    rhs       c2046     0
    rhs       c2047     0
    rhs       c2048     0
    rhs       c2049     0
    rhs       c2050     0
    rhs       c2051     0
    rhs       c2052     0
    rhs       c2053     0
    rhs       c2054     0
    rhs       c2055     0
    rhs       c2056     0
    rhs       c2057     0
    rhs       c2058     0
    rhs       c2059     0
    rhs       c2060     0
    rhs       c2061     0
    rhs       c2062     0
    rhs       c2063     0
    rhs       c2064     0
    rhs       c2065     0
    rhs       c2066     0
    rhs       c2067     0
    rhs       c2068     0
    rhs       c2069     0
    rhs       c2070     0
    rhs       c2071     0
    rhs       c2072     0
    rhs       c2073     0
    rhs       c2074     0
    rhs       c2075     0
    rhs       c2076     0
    rhs       c2077     0
    rhs       c2078     0
    rhs       c2079     0
    rhs       c2080     0
    rhs       c2081     0
    rhs       c2082     0
    rhs       c2083     0
    rhs       c2084     0
    rhs       c2085     0
    rhs       c2086     0
    rhs       c2087     0
    rhs       c2088     0
    rhs       c2089     0
    rhs       c2090     0
    rhs       c2091     0
    rhs       c2092     0
    rhs       c2093     0
    rhs       c2094     0
    rhs       c2095     0
    rhs       c2096     0
    rhs       c2097     0
    rhs       c2098     0
    rhs       c2099     0
    rhs       c2100     0
    rhs       c2101     0
    rhs       c2102     0
    rhs       c2103     0
    rhs       c2104     0
    rhs       c2105     0
    rhs       c2106     0
    rhs       c2107     0
    rhs       c2108     0
    rhs       c2109     0
    rhs       c2110     0
    rhs       c2111     0
    rhs       c2112     0
    rhs       c2113     0
    rhs       c2114     0
    rhs       c2115     0
    rhs       c2116     0
    rhs       c2117     0
    rhs       c2118     0
    rhs       c2119     0
    rhs       c2120     0
    rhs       c2121     0
    rhs       c2122     0
    rhs       c2123     0
    rhs       c2124     0
    rhs       c2125     0
    rhs       c2126     0
    rhs       c2127     0
    rhs       c2128     0
    rhs       c2129     0
    rhs       c2130     0
    rhs       c2131     0
    rhs       c2132     0
    rhs       c2133     0
    rhs       c2134     0
    rhs       c2135     0
    rhs       c2136     0
    rhs       c2137     0
    rhs       c2138     0
    rhs       c2139     0
    rhs       c2140     0
    rhs       c2141     0
    rhs       c2142     0
    rhs       c2143     0
    rhs       c2144     0
    rhs       c2145     0
    rhs       c2146     0
    rhs       c2147     0
    rhs       c2148     0
    rhs       c2149     0
    rhs       c2150     0
    rhs       c2151     0
    rhs       c2152     0
    rhs       c2153     0
    rhs       c2154     0
    rhs       c2155     0
    rhs       c2156     0
    rhs       c2157     0
    rhs       c2158     0
    rhs       c2159     0
    rhs       c2160     0
    rhs       c2161     0
    rhs       c2162     0
    rhs       c2163     0
    rhs       c2164     0
    rhs       c2165     0
    rhs       c2166     0
    rhs       c2167     0
    rhs       c2168     0
    rhs       c2169     0
    rhs       c2170     0
    rhs       c2171     0
    rhs       c2172     0
    rhs       c2173     0
    rhs       c2174     0
    rhs       c2175     0
    rhs       c2176     0
    rhs       c2177     0
    rhs       c2178     0
    rhs       c2179     0
    rhs       c2180     0
    rhs       c2181     0
    rhs       c2182     0
    rhs       c2183     0
    rhs       c2184     0
    rhs       c2185     0
    rhs       c2186     0
    rhs       c2187     0
    rhs       c2188     0
    rhs       c2189     0
    rhs       c2190     0
    rhs       c2191     0
    rhs       c2192     0
    rhs       c2193     0
    rhs       c2194     0
    rhs       c2195     0
    rhs       c2196     0
    rhs       c2197     0
    rhs       c2198     0
    rhs       c2199     0
    rhs       c2200     0
    rhs       c2201     0
    rhs       c2202     0
    rhs       c2203     0
    rhs       c2204     0
    rhs       c2205     0
    rhs       c2206     0
    rhs       c2207     0
    rhs       c2208     0
    rhs       c2209     0
    rhs       c2210     0
    rhs       c2211     0
    rhs       c2212     0
    rhs       c2213     0
    rhs       c2214     0
    rhs       c2215     0
    rhs       c2216     0
    rhs       c2217     0
    rhs       c2218     0
    rhs       c2219     0
    rhs       c2220     0
    rhs       c2221     0
    rhs       c2222     0
    rhs       c2223     0
    rhs       c2224     0
    rhs       c2225     0
    rhs       c2226     0
    rhs       c2227     0
    rhs       c2228     0
    rhs       c2229     0
    rhs       c2230     0
    rhs       c2231     0
    rhs       c2232     0
    rhs       c2233     0
    rhs       c2234     0
    rhs       c2235     0
    rhs       c2236     0
    rhs       c2237     0
    rhs       c2238     0
    rhs       c2239     0
    rhs       c2240     0
    rhs       c2241     0
    rhs       c2242     0
    rhs       c2243     0
    rhs       c2244     0
    rhs       c2245     0
    rhs       c2246     0
    rhs       c2247     0
    rhs       c2248     0
    rhs       c2249     0
    rhs       c2250     0
    rhs       c2251     0
    rhs       c2252     0
    rhs       c2253     0
    rhs       c2254     0
    rhs       c2255     0
    rhs       c2256     0
    rhs       c2257     0
    rhs       c2258     0
    rhs       c2259     0
    rhs       c2260     0
    rhs       c2261     0
    rhs       c2262     0
    rhs       c2263     0
    rhs       c2264     0
    rhs       c2265     0
    rhs       c2266     0
    rhs       c2267     0
    rhs       c2268     0
    rhs       c2269     0
    rhs       c2270     0
    rhs       c2271     0
    rhs       c2272     0
    rhs       c2273     0
    rhs       c2274     0
    rhs       c2275     0
    rhs       c2276     0
    rhs       c2277     0
    rhs       c2278     0
    rhs       c2279     0
    rhs       c2280     0
    rhs       c2281     0
    rhs       c2282     0
    rhs       c2283     0
    rhs       c2284     0
    rhs       c2285     0
    rhs       c2286     0
    rhs       c2287     0
    rhs       c2288     0
    rhs       c2289     0
    rhs       c2290     0
    rhs       c2291     0
    rhs       c2292     0
    rhs       c2293     0
    rhs       c2294     0
    rhs       c2295     0
    rhs       c2296     0
    rhs       c2297     0
    rhs       c2298     0
    rhs       c2299     0
    rhs       c2300     0
    rhs       c2301     0
    rhs       c2302     0
    rhs       c2303     0
    rhs       c2304     0
    rhs       c2305     0
    rhs       c2306     0
    rhs       c2307     0
    rhs       c2308     0
    rhs       c2309     0
    rhs       c2310     0
    rhs       c2311     0
    rhs       c2312     0
    rhs       c2313     0
    rhs       c2314     0
    rhs       c2315     0
    rhs       c2316     0
    rhs       c2317     0
    rhs       c2318     0
    rhs       c2319     0
    rhs       c2320     0
    rhs       c2321     0
    rhs       c2322     0
    rhs       c2323     0
    rhs       c2324     0
    rhs       c2325     0
    rhs       c2326     0
    rhs       c2327     0
    rhs       c2328     0
    rhs       c2329     0
    rhs       c2330     0
    rhs       c2331     0
    rhs       c2332     0
    rhs       c2333     0
    rhs       c2334     0
    rhs       c2335     0
    rhs       c2336     0
    rhs       c2337     0
    rhs       c2338     0
    rhs       c2339     0
    rhs       c2340     0
    rhs       c2341     0
    rhs       c2342     0
    rhs       c2343     0
    rhs       c2344     0
    rhs       c2345     0
    rhs       c2346     0
    rhs       c2347     0
    rhs       c2348     0
    rhs       c2349     0
    rhs       c2350     0
    rhs       c2351     0
    rhs       c2352     0
    rhs       c2353     0
    rhs       c2354     0
    rhs       c2355     0
    rhs       c2356     0
    rhs       c2357     0
    rhs       c2358     0
    rhs       c2359     0
    rhs       c2360     0
    rhs       c2361     0
    rhs       c2362     0
    rhs       c2363     0
    rhs       c2364     0
    rhs       c2365     0
    rhs       c2366     0
    rhs       c2367     0
    rhs       c2368     0
    rhs       c2369     0
    rhs       c2370     0
    rhs       c2371     0
    rhs       c2372     0
    rhs       c2373     0
    rhs       c2374     0
    rhs       c2375     0
    rhs       c2376     0
    rhs       c2377     0
    rhs       c2378     0
    rhs       c2379     0
    rhs       c2380     0
    rhs       c2381     0
    rhs       c2382     0
    rhs       c2383     0
    rhs       c2384     0
    rhs       c2385     0
    rhs       c2386     0
    rhs       c2387     0
    rhs       c2388     0
    rhs       c2389     0
    rhs       c2390     0
    rhs       c2391     0
    rhs       c2392     0
    rhs       c2393     0
    rhs       c2394     0
    rhs       c2395     0
    rhs       c2396     0
    rhs       c2397     0
    rhs       c2398     0
    rhs       c2399     0
    rhs       c2400     0
    rhs       c2401     0
    rhs       c2402     0
    rhs       c2403     0
    rhs       c2404     0
    rhs       c2405     0
    rhs       c2406     0
    rhs       c2407     0
    rhs       c2408     0
    rhs       c2409     0
    rhs       c2410     0
    rhs       c2411     0
    rhs       c2412     0
    rhs       c2413     0
    rhs       c2414     0
    rhs       c2415     0
    rhs       c2416     0
    rhs       c2417     0
    rhs       c2418     0
    rhs       c2419     0
    rhs       c2420     0
    rhs       c2421     0
    rhs       c2422     0
    rhs       c2423     0
    rhs       c2424     0
    rhs       c2425     0
    rhs       c2426     0
    rhs       c2427     0
    rhs       c2428     0
    rhs       c2429     0
    rhs       c2430     0
    rhs       c2431     0
    rhs       c2432     0
    rhs       c2433     0
    rhs       c2434     0
    rhs       c2435     0
    rhs       c2436     0
    rhs       c2437     0
    rhs       c2438     0
    rhs       c2439     0
    rhs       c2440     0
    rhs       c2441     0
    rhs       c2442     0
    rhs       c2443     0
    rhs       c2444     0
    rhs       c2445     0
    rhs       c2446     0
    rhs       c2447     0
    rhs       c2448     0
    rhs       c2449     0
    rhs       c2450     0
    rhs       c2451     0
    rhs       c2452     0
    rhs       c2453     0
    rhs       c2454     0
    rhs       c2455     0
    rhs       c2456     0
    rhs       c2457     0
    rhs       c2458     0
    rhs       c2459     0
    rhs       c2460     0
    rhs       c2461     0
    rhs       c2462     0
    rhs       c2463     0
    rhs       c2464     0
    rhs       c2465     0
    rhs       c2466     0
    rhs       c2467     0
    rhs       c2468     0
    rhs       c2469     0
    rhs       c2470     0
    rhs       c2471     0
    rhs       c2472     0
    rhs       c2473     0
    rhs       c2474     0
    rhs       c2475     0
    rhs       c2476     0
    rhs       c2477     0
    rhs       c2478     0
    rhs       c2479     0
    rhs       c2480     0
    rhs       c2481     0
    rhs       c2482     0
    rhs       c2483     0
    rhs       c2484     0
    rhs       c2485     0
    rhs       c2486     0
    rhs       c2487     0
    rhs       c2488     0
    rhs       c2489     0
    rhs       c2490     0
    rhs       c2491     0
    rhs       c2492     0
    rhs       c2493     0
    rhs       c2494     0
    rhs       c2495     0
    rhs       c2496     0
    rhs       c2497     0
    rhs       c2498     0
    rhs       c2499     0
    rhs       c2500     0
    rhs       c2501     0
    rhs       c2502     0
    rhs       c2503     0
    rhs       c2504     0
    rhs       c2505     0
    rhs       c2506     0
    rhs       c2507     0
    rhs       c2508     0
    rhs       c2509     0
    rhs       c2510     0
    rhs       c2511     0
    rhs       c2512     0
    rhs       c2513     0
    rhs       c2514     0
    rhs       c2515     0
    rhs       c2516     0
    rhs       c2517     0
    rhs       c2518     0
    rhs       c2519     0
    rhs       c2520     0
    rhs       c2521     0
    rhs       c2522     0
    rhs       c2523     0
    rhs       c2524     0
    rhs       c2525     0
    rhs       c2526     0
    rhs       c2527     0
    rhs       c2528     0
    rhs       c2529     0
    rhs       c2530     0
    rhs       c2531     0
    rhs       c2532     0
    rhs       c2533     0
    rhs       c2534     0
    rhs       c2535     0
    rhs       c2536     0
    rhs       c2537     0
    rhs       c2538     0
    rhs       c2539     0
    rhs       c2540     0
    rhs       c2541     0
    rhs       c2542     0
    rhs       c2543     0
    rhs       c2544     0
    rhs       c2545     0
    rhs       c2546     0
    rhs       c2547     0
    rhs       c2548     0
    rhs       c2549     0
    rhs       c2550     0
    rhs       c2551     0
    rhs       c2552     0
    rhs       c2553     0
    rhs       c2554     0
    rhs       c2555     0
    rhs       c2556     0
    rhs       c2557     0
    rhs       c2558     0
    rhs       c2559     0
    rhs       c2560     0
    rhs       c2561     0
    rhs       c2562     0
    rhs       c2563     0
    rhs       c2564     0
    rhs       c2565     0
    rhs       c2566     0
    rhs       c2567     0
    rhs       c2568     0
    rhs       c2569     0
    rhs       c2570     0
    rhs       c2571     0
    rhs       c2572     0
    rhs       c2573     0
    rhs       c2574     0
    rhs       c2575     0
    rhs       c2576     0
    rhs       c2577     0
    rhs       c2578     0
    rhs       c2579     0
    rhs       c2580     0
    rhs       c2581     0
    rhs       c2582     0
    rhs       c2583     0
    rhs       c2584     0
    rhs       c2585     0
    rhs       c2586     0
    rhs       c2587     0
    rhs       c2588     0
    rhs       c2589     0
    rhs       c2590     0
    rhs       c2591     0
    rhs       c2592     0
    rhs       c2593     0
    rhs       c2594     0
    rhs       c2595     0
    rhs       c2596     0
    rhs       c2597     0
    rhs       c2598     0
    rhs       c2599     0
    rhs       c2600     0
    rhs       c2601     0
    rhs       c2602     0
    rhs       c2603     0
    rhs       c2604     0
    rhs       c2605     0
    rhs       c2606     0
    rhs       c2607     0
    rhs       c2608     0
    rhs       c2609     0
    rhs       c2610     0
    rhs       c2611     0
    rhs       c2612     0
    rhs       c2613     0
    rhs       c2614     0
    rhs       c2615     0
    rhs       c2616     0
    rhs       c2617     0
    rhs       c2618     0
    rhs       c2619     0
    rhs       c2620     0
    rhs       c2621     0
    rhs       c2622     0
    rhs       c2623     0
    rhs       c2624     0
    rhs       c2625     0
    rhs       c2626     0
    rhs       c2627     0
    rhs       c2628     0
    rhs       c2629     0
    rhs       c2630     0
    rhs       c2631     0
    rhs       c2632     0
    rhs       c2633     0
    rhs       c2634     0
    rhs       c2635     0
    rhs       c2636     0
    rhs       c2637     0
    rhs       c2638     0
    rhs       c2639     0
    rhs       c2640     0
    rhs       c2641     0
    rhs       c2642     0
    rhs       c2643     0
    rhs       c2644     0
    rhs       c2645     0
    rhs       c2646     0
    rhs       c2647     0
    rhs       c2648     0
    rhs       c2649     0
    rhs       c2650     0
    rhs       c2651     0
    rhs       c2652     0
    rhs       c2653     0
    rhs       c2654     0
    rhs       c2655     0
    rhs       c2656     0
    rhs       c2657     0
    rhs       c2658     0
    rhs       c2659     0
    rhs       c2660     0
    rhs       c2661     0
    rhs       c2662     0
    rhs       c2663     0
    rhs       c2664     0
    rhs       c2665     0
    rhs       c2666     0
    rhs       c2667     0
    rhs       c2668     0
    rhs       c2669     0
    rhs       c2670     0
    rhs       c2671     0
    rhs       c2672     0
    rhs       c2673     0
    rhs       c2674     0
    rhs       c2675     0
    rhs       c2676     0
    rhs       c2677     0
    rhs       c2678     0
    rhs       c2679     0
    rhs       c2680     0
    rhs       c2681     0
    rhs       c2682     0
    rhs       c2683     0
    rhs       c2684     0
    rhs       c2685     0
    rhs       c2686     0
    rhs       c2687     0
    rhs       c2688     0
    rhs       c2689     0
    rhs       c2690     0
    rhs       c2691     0
    rhs       c2692     0
    rhs       c2693     0
    rhs       c2694     0
    rhs       c2695     0
    rhs       c2696     0
    rhs       c2697     0
    rhs       c2698     0
    rhs       c2699     0
    rhs       c2700     0
    rhs       c2701     0
    rhs       c2702     0
    rhs       c2703     0
    rhs       c2704     0
    rhs       c2705     0
    rhs       c2706     0
    rhs       c2707     0
    rhs       c2708     0
    rhs       c2709     0
    rhs       c2710     0
    rhs       c2711     0
    rhs       c2712     0
    rhs       c2713     0
    rhs       c2714     0
    rhs       c2715     0
    rhs       c2716     0
    rhs       c2717     0
    rhs       c2718     0
    rhs       c2719     0
    rhs       c2720     0
    rhs       c2721     0
    rhs       c2722     0
    rhs       c2723     0
    rhs       c2724     0
    rhs       c2725     0
    rhs       c2726     0
    rhs       c2727     0
    rhs       c2728     0
    rhs       c2729     0
    rhs       c2730     0
    rhs       c2731     0
    rhs       c2732     0
    rhs       c2733     0
    rhs       c2734     0
    rhs       c2735     0
    rhs       c2736     0
    rhs       c2737     0
    rhs       c2738     0
    rhs       c2739     0
    rhs       c2740     0
    rhs       c2741     0
    rhs       c2742     0
    rhs       c2743     0
    rhs       c2744     0
    rhs       c2745     0
    rhs       c2746     0
    rhs       c2747     0
    rhs       c2748     0
    rhs       c2749     0
    rhs       c2750     0
    rhs       c2751     0
    rhs       c2752     0
    rhs       c2753     0
    rhs       c2754     0
    rhs       c2755     0
    rhs       c2756     0
    rhs       c2757     0
    rhs       c2758     0
    rhs       c2759     0
    rhs       c2760     0
    rhs       c2761     0
    rhs       c2762     0
    rhs       c2763     0
    rhs       c2764     0
    rhs       c2765     0
    rhs       c2766     0
    rhs       c2767     0
    rhs       c2768     0
    rhs       c2769     0
    rhs       c2770     0
    rhs       c2771     0
    rhs       c2772     0
    rhs       c2773     0
    rhs       c2774     0
    rhs       c2775     0
    rhs       c2776     0
    rhs       c2777     0
    rhs       c2778     0
    rhs       c2779     0
    rhs       c2780     0
    rhs       c2781     0
    rhs       c2782     0
    rhs       c2783     0
    rhs       c2784     0
    rhs       c2785     0
    rhs       c2786     0
    rhs       c2787     0
    rhs       c2788     0
    rhs       c2789     0
    rhs       c2790     0
    rhs       c2791     0
    rhs       c2792     0
    rhs       c2793     0
    rhs       c2794     0
    rhs       c2795     0
    rhs       c2796     0
    rhs       c2797     0
    rhs       c2798     0
    rhs       c2799     0
    rhs       c2800     0
    rhs       c2801     0
    rhs       c2802     0
    rhs       c2803     0
    rhs       c2804     0
    rhs       c2805     0
    rhs       c2806     0
    rhs       c2807     0
    rhs       c2808     0
    rhs       c2809     0
    rhs       c2810     0
    rhs       c2811     0
    rhs       c2812     0
    rhs       c2813     0
    rhs       c2814     0
    rhs       c2815     0
    rhs       c2816     0
    rhs       c2817     0
    rhs       c2818     0
    rhs       c2819     0
    rhs       c2820     0
    rhs       c2821     0
    rhs       c2822     0
    rhs       c2823     0
    rhs       c2824     0
    rhs       c2825     0
    rhs       c2826     0
    rhs       c2827     0
    rhs       c2828     0
    rhs       c2829     0
    rhs       c2830     0
    rhs       c2831     0
    rhs       c2832     0
    rhs       c2833     0
    rhs       c2834     0
    rhs       c2835     0
    rhs       c2836     0
    rhs       c2837     0
    rhs       c2838     0
    rhs       c2839     0
    rhs       c2840     0
    rhs       c2841     0
    rhs       c2842     0
    rhs       c2843     0
    rhs       c2844     0
    rhs       c2845     0
    rhs       c2846     0
    rhs       c2847     0
    rhs       c2848     0
    rhs       c2849     0
    rhs       c2850     0
    rhs       c2851     0
    rhs       c2852     0
    rhs       c2853     0
    rhs       c2854     0
    rhs       c2855     0
    rhs       c2856     0
    rhs       c2857     0
    rhs       c2858     0
    rhs       c2859     0
    rhs       c2860     0
    rhs       c2861     0
    rhs       c2862     0
    rhs       c2863     0
    rhs       c2864     0
    rhs       c2865     0
    rhs       c2866     0
    rhs       c2867     0
    rhs       c2868     0
    rhs       c2869     0
    rhs       c2870     0
    rhs       c2871     0
    rhs       c2872     0
    rhs       c2873     0
    rhs       c2874     0
    rhs       c2875     0
    rhs       c2876     0
    rhs       c2877     0
    rhs       c2878     0
    rhs       c2879     0
    rhs       c2880     0
    rhs       c2881     0
    rhs       c2882     0
    rhs       c2883     0
    rhs       c2884     0
    rhs       c2885     0
    rhs       c2886     0
    rhs       c2887     0
    rhs       c2888     0
    rhs       c2889     0
    rhs       c2890     0
    rhs       c2891     0
    rhs       c2892     0
    rhs       c2893     0
    rhs       c2894     0
    rhs       c2895     0
    rhs       c2896     0
    rhs       c2897     0
    rhs       c2898     0
    rhs       c2899     0
    rhs       c2900     0
    rhs       c2901     0
    rhs       c2902     0
    rhs       c2903     0
    rhs       c2904     0
    rhs       c2905     0
    rhs       c2906     0
    rhs       c2907     0
    rhs       c2908     0
    rhs       c2909     0
    rhs       c2910     0
    rhs       c2911     0
    rhs       c2912     0
    rhs       c2913     0
    rhs       c2914     0
    rhs       c2915     0
    rhs       c2916     0
    rhs       c2917     0
    rhs       c2918     0
    rhs       c2919     0
    rhs       c2920     0
    rhs       c2921     0
    rhs       c2922     0
    rhs       c2923     0
    rhs       c2924     0
    rhs       c2925     0
    rhs       c2926     0
    rhs       c2927     0
    rhs       c2928     0
    rhs       c2929     0
    rhs       c2930     0
    rhs       c2931     0
    rhs       c2932     0
    rhs       c2933     0
    rhs       c2934     0
    rhs       c2935     0
    rhs       c2936     0
    rhs       c2937     0
    rhs       c2938     0
    rhs       c2939     0
    rhs       c2940     0
    rhs       c2941     0
    rhs       c2942     0
    rhs       c2943     0
    rhs       c2944     0
    rhs       c2945     0
    rhs       c2946     0
    rhs       c2947     0
    rhs       c2948     0
    rhs       c2949     0
    rhs       c2950     0
    rhs       c2951     0
    rhs       c2952     0
    rhs       c2953     0
    rhs       c2954     0
    rhs       c2955     0
    rhs       c2956     0
    rhs       c2957     0
    rhs       c2958     0
    rhs       c2959     0
    rhs       c2960     0
    rhs       c2961     0
    rhs       c2962     0
    rhs       c2963     0
    rhs       c2964     0
    rhs       c2965     0
    rhs       c2966     0
    rhs       c2967     0
    rhs       c2968     0
    rhs       c2969     0
    rhs       c2970     0
    rhs       c2971     0
    rhs       c2972     0
    rhs       c2973     0
    rhs       c2974     0
    rhs       c2975     0
    rhs       c2976     0
    rhs       c2977     0
    rhs       c2978     0
    rhs       c2979     0
    rhs       c2980     0
    rhs       c2981     0
    rhs       c2982     0
    rhs       c2983     0
    rhs       c2984     0
    rhs       c2985     0
    rhs       c2986     0
    rhs       c2987     0
    rhs       c2988     0
    rhs       c2989     0
    rhs       c2990     0
    rhs       c2991     0
    rhs       c2992     0
    rhs       c2993     0
    rhs       c2994     0
    rhs       c2995     0
    rhs       c2996     0
    rhs       c2997     0
    rhs       c2998     0
    rhs       c2999     0
    rhs       c3000     0
    rhs       c3001     0
    rhs       c3002     0
    rhs       c3003     0
    rhs       c3004     0
    rhs       c3005     0
    rhs       c3006     0
    rhs       c3007     0
    rhs       c3008     0
    rhs       c3009     0
    rhs       c3010     0
    rhs       c3011     0
    rhs       c3012     0
    rhs       c3013     0
    rhs       c3014     0
    rhs       c3015     0
    rhs       c3016     0
    rhs       c3017     0
    rhs       c3018     0
    rhs       c3019     0
    rhs       c3020     0
    rhs       c3021     0
    rhs       c3022     0
    rhs       c3023     0
    rhs       c3024     0
    rhs       c3025     0
    rhs       c3026     0
    rhs       c3027     0
    rhs       c3028     0
    rhs       c3029     0
    rhs       c3030     0
    rhs       c3031     0
    rhs       c3032     0
    rhs       c3033     0
    rhs       c3034     0
    rhs       c3035     0
    rhs       c3036     0
    rhs       c3037     0
    rhs       c3038     0
    rhs       c3039     0
    rhs       c3040     0
    rhs       c3041     0
    rhs       c3042     0
    rhs       c3043     0
    rhs       c3044     0
    rhs       c3045     0
    rhs       c3046     0
    rhs       c3047     0
    rhs       c3048     0
    rhs       c3049     0
    rhs       c3050     0
    rhs       c3051     0
    rhs       c3052     0
    rhs       c3053     0
    rhs       c3054     0
    rhs       c3055     0
    rhs       c3056     0
    rhs       c3057     0
    rhs       c3058     0
    rhs       c3059     0
    rhs       c3060     0
    rhs       c3061     0
    rhs       c3062     0
    rhs       c3063     0
    rhs       c3064     0
    rhs       c3065     0
    rhs       c3066     0
    rhs       c3067     0
    rhs       c3068     0
    rhs       c3069     0
    rhs       c3070     0
    rhs       c3071     0
    rhs       c3072     0
    rhs       c3073     0
    rhs       c3074     0
    rhs       c3075     0
    rhs       c3076     0
    rhs       c3077     0
    rhs       c3078     0
    rhs       c3079     0
    rhs       c3080     0
    rhs       c3081     0
    rhs       c3082     0
    rhs       c3083     0
    rhs       c3084     0
    rhs       c3085     0
    rhs       c3086     0
    rhs       c3087     0
    rhs       c3088     0
    rhs       c3089     0
    rhs       c3090     0
    rhs       c3091     0
    rhs       c3092     0
    rhs       c3093     0
    rhs       c3094     0
    rhs       c3095     0
    rhs       c3096     0
    rhs       c3097     0
    rhs       c3098     0
    rhs       c3099     0
    rhs       c3100     0
    rhs       c3101     0
    rhs       c3102     0
    rhs       c3103     0
    rhs       c3104     0
    rhs       c3105     0
    rhs       c3106     0
    rhs       c3107     0
    rhs       c3108     0
    rhs       c3109     0
    rhs       c3110     0
    rhs       c3111     0
    rhs       c3112     0
    rhs       c3113     0
    rhs       c3114     0
    rhs       c3115     0
    rhs       c3116     0
    rhs       c3117     0
    rhs       c3118     0
    rhs       c3119     0
    rhs       c3120     0
    rhs       c3121     0
    rhs       c3122     0
    rhs       c3123     0
    rhs       c3124     0
    rhs       c3125     0
    rhs       c3126     0
    rhs       c3127     0
    rhs       c3128     0
    rhs       c3129     0
    rhs       c3130     0
    rhs       c3131     0
    rhs       c3132     0
    rhs       c3133     0
    rhs       c3134     0
    rhs       c3135     0
    rhs       c3136     0
    rhs       c3137     0
    rhs       c3138     0
    rhs       c3139     0
    rhs       c3140     0
    rhs       c3141     0
    rhs       c3142     0
    rhs       c3143     0
    rhs       c3144     0
    rhs       c3145     0
    rhs       c3146     0
    rhs       c3147     0
    rhs       c3148     0
    rhs       c3149     0
    rhs       c3150     0
    rhs       c3151     0
    rhs       c3152     0
    rhs       c3153     0
    rhs       c3154     0
    rhs       c3155     0
    rhs       c3156     0
    rhs       c3157     0
    rhs       c3158     0
    rhs       c3159     0
    rhs       c3160     0
    rhs       c3161     0
    rhs       c3162     0
    rhs       c3163     0
    rhs       c3164     0
    rhs       c3165     0
    rhs       c3166     0
    rhs       c3167     0
    rhs       c3168     0
    rhs       c3169     0
    rhs       c3170     0
    rhs       c3171     0
    rhs       c3172     0
    rhs       c3173     0
    rhs       c3174     0
    rhs       c3175     0
    rhs       c3176     0
    rhs       c3177     0
    rhs       c3178     0
    rhs       c3179     0
    rhs       c3180     0
    rhs       c3181     0
    rhs       c3182     0
    rhs       c3183     0
    rhs       c3184     0
    rhs       c3185     0
    rhs       c3186     0
    rhs       c3187     0
    rhs       c3188     0
    rhs       c3189     0
    rhs       c3190     0
    rhs       c3191     0
    rhs       c3192     0
    rhs       c3193     0
    rhs       c3194     0
    rhs       c3195     0
    rhs       c3196     0
    rhs       c3197     0
    rhs       c3198     0
    rhs       c3199     0
    rhs       c3200     0
    rhs       c3201     0
    rhs       c3202     0
    rhs       c3203     0
    rhs       c3204     0
    rhs       c3205     0
    rhs       c3206     0
    rhs       c3207     0
    rhs       c3208     0
    rhs       c3209     0
    rhs       c3210     0
    rhs       c3211     0
    rhs       c3212     0
    rhs       c3213     0
    rhs       c3214     0
    rhs       c3215     0
    rhs       c3216     0
    rhs       c3217     0
    rhs       c3218     0
    rhs       c3219     0
    rhs       c3220     0
    rhs       c3221     0
    rhs       c3222     0
    rhs       c3223     0
    rhs       c3224     0
    rhs       c3225     0
    rhs       c3226     0
    rhs       c3227     0
    rhs       c3228     0
    rhs       c3229     0
    rhs       c3230     0
    rhs       c3231     0
    rhs       c3232     0
    rhs       c3233     0
    rhs       c3234     0
    rhs       c3235     0
    rhs       c3236     0
    rhs       c3237     0
    rhs       c3238     0
    rhs       c3239     0
    rhs       c3240     0
    rhs       c3241     0
    rhs       c3242     0
    rhs       c3243     0
    rhs       c3244     0
    rhs       c3245     0
    rhs       c3246     0
    rhs       c3247     0
    rhs       c3248     0
    rhs       c3249     0
    rhs       c3250     0
    rhs       c3251     0
    rhs       c3252     0
    rhs       c3253     0
    rhs       c3254     0
    rhs       c3255     0
    rhs       c3256     0
    rhs       c3257     0
    rhs       c3258     0
    rhs       c3259     0
    rhs       c3260     0
    rhs       c3261     0
    rhs       c3262     0
    rhs       c3263     0
    rhs       c3264     0
    rhs       c3265     0
    rhs       c3266     0
    rhs       c3267     0
    rhs       c3268     0
    rhs       c3269     0
    rhs       c3270     0
    rhs       c3271     0
    rhs       c3272     0
    rhs       c3273     0
    rhs       c3274     0
    rhs       c3275     0
    rhs       c3276     0
    rhs       c3277     0
    rhs       c3278     0
    rhs       c3279     0
    rhs       c3280     0
    rhs       c3281     0
    rhs       c3282     0
    rhs       c3283     0
    rhs       c3284     0
    rhs       c3285     0
    rhs       c3286     0
    rhs       c3287     0
    rhs       c3288     0
    rhs       c3289     0
    rhs       c3290     0
    rhs       c3291     0
    rhs       c3292     0
    rhs       c3293     0
    rhs       c3294     0
    rhs       c3295     0
    rhs       c3296     0
    rhs       c3297     0
    rhs       c3298     0
    rhs       c3299     0
    rhs       c3300     0
    rhs       c3301     0
    rhs       c3302     0
    rhs       c3303     0
    rhs       c3304     0
    rhs       c3305     0
    rhs       c3306     0
    rhs       c3307     0
    rhs       c3308     0
    rhs       c3309     0
    rhs       c3310     0
    rhs       c3311     0
    rhs       c3312     0
    rhs       c3313     0
    rhs       c3314     0
    rhs       c3315     0
    rhs       c3316     0
    rhs       c3317     0
    rhs       c3318     0
    rhs       c3319     0
    rhs       c3320     0
    rhs       c3321     0
    rhs       c3322     0
    rhs       c3323     0
    rhs       c3324     0
    rhs       c3325     0
    rhs       c3326     0
    rhs       c3327     0
    rhs       c3328     0
    rhs       c3329     0
    rhs       c3330     0
    rhs       c3331     0
    rhs       c3332     0
    rhs       c3333     0
    rhs       c3334     0
    rhs       c3335     0
    rhs       c3336     0
    rhs       c3337     0
    rhs       c3338     0
    rhs       c3339     0
    rhs       c3340     0
    rhs       c3341     0
    rhs       c3342     0
    rhs       c3343     0
    rhs       c3344     0
    rhs       c3345     0
    rhs       c3346     0
    rhs       c3347     0
    rhs       c3348     0
    rhs       c3349     0
    rhs       c3350     0
    rhs       c3351     0
    rhs       c3352     0
    rhs       c3353     0
    rhs       c3354     0
    rhs       c3355     0
    rhs       c3356     0
    rhs       c3357     0
    rhs       c3358     0
    rhs       c3359     0
    rhs       c3360     0
    rhs       c3361     0
    rhs       c3362     0
    rhs       c3363     0
    rhs       c3364     0
    rhs       c3365     0
    rhs       c3366     0
    rhs       c3367     0
    rhs       c3368     0
    rhs       c3369     0
    rhs       c3370     0
    rhs       c3371     0
    rhs       c3372     0
    rhs       c3373     0
    rhs       c3374     0
    rhs       c3375     0
    rhs       c3376     0
    rhs       c3377     0
    rhs       c3378     0
    rhs       c3379     0
    rhs       c3380     0
    rhs       c3381     0
    rhs       c3382     0
    rhs       c3383     0
    rhs       c3384     0
    rhs       c3385     0
    rhs       c3386     0
    rhs       c3387     0
    rhs       c3388     0
    rhs       c3389     0
    rhs       c3390     0
    rhs       c3391     0
    rhs       c3392     0
    rhs       c3393     0
    rhs       c3394     0
    rhs       c3395     0
    rhs       c3396     0
    rhs       c3397     0
    rhs       c3398     0
    rhs       c3399     0
    rhs       c3400     0
    rhs       c3401     0
    rhs       c3402     0
    rhs       c3403     0
    rhs       c3404     0
    rhs       c3405     0
    rhs       c3406     0
    rhs       c3407     0
    rhs       c3408     0
    rhs       c3409     0
    rhs       c3410     0
    rhs       c3411     0
    rhs       c3412     0
    rhs       c3413     0
    rhs       c3414     0
    rhs       c3415     0
    rhs       c3416     0
    rhs       c3417     0
    rhs       c3418     0
    rhs       c3419     0
    rhs       c3420     0
    rhs       c3421     0
    rhs       c3422     0
    rhs       c3423     0
    rhs       c3424     0
    rhs       c3425     0
    rhs       c3426     0
    rhs       c3427     0
    rhs       c3428     0
    rhs       c3429     0
    rhs       c3430     0
    rhs       c3431     0
    rhs       c3432     0
    rhs       c3433     0
    rhs       c3434     0
    rhs       c3435     0
    rhs       c3436     0
    rhs       c3437     0
    rhs       c3438     0
    rhs       c3439     0
    rhs       c3440     0
    rhs       c3441     0
    rhs       c3442     0
    rhs       c3443     0
    rhs       c3444     0
    rhs       c3445     0
    rhs       c3446     0
    rhs       c3447     0
    rhs       c3448     0
    rhs       c3449     0
    rhs       c3450     0
    rhs       c3451     0
    rhs       c3452     0
    rhs       c3453     0
    rhs       c3454     0
    rhs       c3455     0
    rhs       c3456     0
    rhs       c3457     0
    rhs       c3458     0
    rhs       c3459     0
    rhs       c3460     0
    rhs       c3461     0
    rhs       c3462     0
    rhs       c3463     0
    rhs       c3464     0
    rhs       c3465     0
    rhs       c3466     0
    rhs       c3467     0
    rhs       c3468     0
    rhs       c3469     0
    rhs       c3470     0
    rhs       c3471     0
    rhs       c3472     0
    rhs       c3473     0
    rhs       c3474     0
    rhs       c3475     0
    rhs       c3476     0
    rhs       c3477     0
    rhs       c3478     0
    rhs       c3479     0
    rhs       c3480     0
    rhs       c3481     0
    rhs       c3482     0
    rhs       c3483     0
    rhs       c3484     0
    rhs       c3485     0
    rhs       c3486     0
    rhs       c3487     0
    rhs       c3488     0
    rhs       c3489     0
    rhs       c3490     0
    rhs       c3491     0
    rhs       c3492     0
    rhs       c3493     0
    rhs       c3494     0
    rhs       c3495     0
    rhs       c3496     0
    rhs       c3497     0
    rhs       c3498     0
    rhs       c3499     0
    rhs       c3500     0
    rhs       c3501     0
    rhs       c3502     0
    rhs       c3503     0
    rhs       c3504     0
    rhs       c3505     0
    rhs       c3506     0
    rhs       c3507     0
    rhs       c3508     0
    rhs       c3509     0
    rhs       c3510     0
    rhs       c3511     0
    rhs       c3512     0
    rhs       c3513     0
    rhs       c3514     0
    rhs       c3515     0
    rhs       c3516     0
    rhs       c3517     0
    rhs       c3518     0
    rhs       c3519     0
    rhs       c3520     0
    rhs       c3521     0
    rhs       c3522     0
    rhs       c3523     0
    rhs       c3524     0
    rhs       c3525     0
    rhs       c3526     0
    rhs       c3527     0
    rhs       c3528     0
    rhs       c3529     0
    rhs       c3530     0
    rhs       c3531     0
    rhs       c3532     0
    rhs       c3533     0
    rhs       c3534     0
    rhs       c3535     0
    rhs       c3536     0
    rhs       c3537     0
    rhs       c3538     0
    rhs       c3539     0
    rhs       c3540     0
    rhs       c3541     0
    rhs       c3542     0
    rhs       c3543     0
    rhs       c3544     0
    rhs       c3545     0
    rhs       c3546     0
    rhs       c3547     0
    rhs       c3548     0
    rhs       c3549     0
    rhs       c3550     0
    rhs       c3551     0
    rhs       c3552     0
    rhs       c3553     0
    rhs       c3554     0
    rhs       c3555     0
    rhs       c3556     0
    rhs       c3557     0
    rhs       c3558     0
    rhs       c3559     0
    rhs       c3560     0
    rhs       c3561     0
    rhs       c3562     0
    rhs       c3563     0
    rhs       c3564     0
    rhs       c3565     0
    rhs       c3566     0
    rhs       c3567     0
    rhs       c3568     0
    rhs       c3569     0
    rhs       c3570     0
    rhs       c3571     0
    rhs       c3572     0
    rhs       c3573     0
    rhs       c3574     0
    rhs       c3575     0
    rhs       c3576     0
    rhs       c3577     0
    rhs       c3578     0
    rhs       c3579     0
    rhs       c3580     0
    rhs       c3581     0
    rhs       c3582     0
    rhs       c3583     0
    rhs       c3584     0
    rhs       c3585     0
    rhs       c3586     0
    rhs       c3587     0
    rhs       c3588     0
    rhs       c3589     0
    rhs       c3590     0
    rhs       c3591     0
    rhs       c3592     0
    rhs       c3593     0
    rhs       c3594     0
    rhs       c3595     0
    rhs       c3596     0
    rhs       c3597     0
    rhs       c3598     0
    rhs       c3599     0
    rhs       c3600     0
    rhs       c3601     0
    rhs       c3602     0
    rhs       c3603     0
    rhs       c3604     0
    rhs       c3605     0
    rhs       c3606     0
    rhs       c3607     0
    rhs       c3608     0
    rhs       c3609     0
    rhs       c3610     0
    rhs       c3611     0
    rhs       c3612     0
    rhs       c3613     0
    rhs       c3614     0
    rhs       c3615     0
    rhs       c3616     0
    rhs       c3617     0
    rhs       c3618     0
    rhs       c3619     0
    rhs       c3620     0
    rhs       c3621     0
    rhs       c3622     0
    rhs       c3623     0
    rhs       c3624     0
    rhs       c3625     0
    rhs       c3626     0
    rhs       c3627     0
    rhs       c3628     0
    rhs       c3629     0
    rhs       c3630     0
    rhs       c3631     0
    rhs       c3632     0
    rhs       c3633     0
    rhs       c3634     0
    rhs       c3635     0
    rhs       c3636     0
    rhs       c3637     0
    rhs       c3638     0
    rhs       c3639     0
    rhs       c3640     0
    rhs       c3641     0
    rhs       c3642     0
    rhs       c3643     0
    rhs       c3644     0
    rhs       c3645     0
    rhs       c3646     0
    rhs       c3647     0
    rhs       c3648     0
    rhs       c3649     0
    rhs       c3650     0
    rhs       c3651     0
    rhs       c3652     0
    rhs       c3653     0
    rhs       c3654     0
    rhs       c3655     0
    rhs       c3656     0
    rhs       c3657     0
    rhs       c3658     0
    rhs       c3659     0
    rhs       c3660     0
    rhs       c3661     0
    rhs       c3662     0
    rhs       c3663     0
    rhs       c3664     0
    rhs       c3665     0
    rhs       c3666     0
    rhs       c3667     0
    rhs       c3668     0
    rhs       c3669     0
    rhs       c3670     0
    rhs       c3671     0
    rhs       c3672     0
    rhs       c3673     0
    rhs       c3674     0
    rhs       c3675     0
    rhs       c3676     0
    rhs       c3677     0
    rhs       c3678     0
    rhs       c3679     0
    rhs       c3680     0
    rhs       c3681     0
    rhs       c3682     0
    rhs       c3683     0
    rhs       c3684     0
    rhs       c3685     0
    rhs       c3686     0
    rhs       c3687     0
    rhs       c3688     0
    rhs       c3689     0
    rhs       c3690     0
    rhs       c3691     0
    rhs       c3692     0
    rhs       c3693     0
    rhs       c3694     0
    rhs       c3695     0
    rhs       c3696     0
    rhs       c3697     0
    rhs       c3698     0
    rhs       c3699     0
    rhs       c3700     0
    rhs       c3701     0
    rhs       c3702     0
    rhs       c3703     0
    rhs       c3704     0
    rhs       c3705     0
    rhs       c3706     0
    rhs       c3707     0
    rhs       c3708     0
    rhs       c3709     0
    rhs       c3710     0
    rhs       c3711     0
    rhs       c3712     0
    rhs       c3713     0
    rhs       c3714     0
    rhs       c3715     0
    rhs       c3716     0
    rhs       c3717     0
    rhs       c3718     0
    rhs       c3719     0
    rhs       c3720     0
    rhs       c3721     0
    rhs       c3722     0
    rhs       c3723     0
    rhs       c3724     0
    rhs       c3725     0
    rhs       c3726     0
    rhs       c3727     0
    rhs       c3728     0
    rhs       c3729     0
    rhs       c3730     0
    rhs       c3731     0
    rhs       c3732     0
    rhs       c3733     0
    rhs       c3734     0
    rhs       c3735     0
    rhs       c3736     0
    rhs       c3737     0
    rhs       c3738     0
    rhs       c3739     0
    rhs       c3740     0
    rhs       c3741     0
    rhs       c3742     0
    rhs       c3743     0
    rhs       c3744     0
    rhs       c3745     0
    rhs       c3746     0
    rhs       c3747     0
    rhs       c3748     0
    rhs       c3749     0
    rhs       c3750     0
    rhs       c3751     0
    rhs       c3752     0
    rhs       c3753     0
    rhs       c3754     0
    rhs       c3755     0
    rhs       c3756     0
    rhs       c3757     0
    rhs       c3758     0
    rhs       c3759     0
    rhs       c3760     0
    rhs       c3761     0
    rhs       c3762     0
    rhs       c3763     0
    rhs       c3764     0
    rhs       c3765     0
    rhs       c3766     0
    rhs       c3767     0
    rhs       c3768     0
    rhs       c3769     0
    rhs       c3770     0
    rhs       c3771     0
    rhs       c3772     0
    rhs       c3773     0
    rhs       c3774     0
    rhs       c3775     0
    rhs       c3776     0
    rhs       c3777     0
    rhs       c3778     0
    rhs       c3779     0
    rhs       c3780     0
    rhs       c3781     0
    rhs       c3782     0
    rhs       c3783     0
    rhs       c3784     0
    rhs       c3785     0
    rhs       c3786     0
    rhs       c3787     0
    rhs       c3788     0
    rhs       c3789     0
    rhs       c3790     0
    rhs       c3791     0
    rhs       c3792     0
    rhs       c3793     0
    rhs       c3794     0
    rhs       c3795     0
    rhs       c3796     0
    rhs       c3797     0
    rhs       c3798     0
    rhs       c3799     0
    rhs       c3800     0
    rhs       c3801     0
    rhs       c3802     0
    rhs       c3803     0
    rhs       c3804     0
    rhs       c3805     0
    rhs       c3806     0
    rhs       c3807     0
    rhs       c3808     0
    rhs       c3809     0
    rhs       c3810     0
    rhs       c3811     0
    rhs       c3812     0
    rhs       c3813     0
    rhs       c3814     0
    rhs       c3815     0
    rhs       c3816     0
    rhs       c3817     0
    rhs       c3818     0
    rhs       c3819     0
    rhs       c3820     0
    rhs       c3821     0
    rhs       c3822     0
    rhs       c3823     0
    rhs       c3824     0
    rhs       c3825     0
    rhs       c3826     0
    rhs       c3827     0
    rhs       c3828     0
    rhs       c3829     0
    rhs       c3830     0
    rhs       c3831     0
    rhs       c3832     0
    rhs       c3833     0
    rhs       c3834     0
    rhs       c3835     0
    rhs       c3836     0
    rhs       c3837     0
    rhs       c3838     0
    rhs       c3839     0
    rhs       c3840     0
    rhs       c3841     0
    rhs       c3842     0
    rhs       c3843     0
    rhs       c3844     0
    rhs       c3845     0
    rhs       c3846     0
    rhs       c3847     0
    rhs       c3848     0
    rhs       c3849     0
    rhs       c3850     0
    rhs       c3851     0
    rhs       c3852     0
    rhs       c3853     0
    rhs       c3854     0
    rhs       c3855     0
    rhs       c3856     0
    rhs       c3857     0
    rhs       c3858     0
    rhs       c3859     0
    rhs       c3860     0
    rhs       c3861     0
    rhs       c3862     0
    rhs       c3863     0
    rhs       c3864     0
    rhs       c3865     0
    rhs       c3866     0
    rhs       c3867     0
    rhs       c3868     0
    rhs       c3869     0
    rhs       c3870     0
    rhs       c3871     0
    rhs       c3872     0
    rhs       c3873     0
    rhs       c3874     0
    rhs       c3875     0
    rhs       c3876     0
    rhs       c3877     0
    rhs       c3878     0
    rhs       c3879     0
    rhs       c3880     0
    rhs       c3881     0
    rhs       c3882     0
    rhs       c3883     0
    rhs       c3884     0
    rhs       c3885     0
    rhs       c3886     0
    rhs       c3887     0
    rhs       c3888     0
    rhs       c3889     0
    rhs       c3890     0
    rhs       c3891     0
    rhs       c3892     0
    rhs       c3893     0
    rhs       c3894     0
    rhs       c3895     0
    rhs       c3896     0
    rhs       c3897     0
    rhs       c3898     0
    rhs       c3899     0
    rhs       c3900     0
    rhs       c3901     0
    rhs       c3902     0
    rhs       c3903     0
    rhs       c3904     0
    rhs       c3905     0
    rhs       c3906     0
    rhs       c3907     0
    rhs       c3908     0
    rhs       c3909     0
    rhs       c3910     0
    rhs       c3911     0
    rhs       c3912     0
    rhs       c3913     0
    rhs       c3914     0
    rhs       c3915     0
    rhs       c3916     0
    rhs       c3917     0
    rhs       c3918     0
    rhs       c3919     0
    rhs       c3920     0
    rhs       c3921     0
    rhs       c3922     0
    rhs       c3923     0
    rhs       c3924     0
    rhs       c3925     0
    rhs       c3926     0
    rhs       c3927     0
    rhs       c3928     0
    rhs       c3929     0
    rhs       c3930     0
    rhs       c3931     0
    rhs       c3932     0
    rhs       c3933     0
    rhs       c3934     0
    rhs       c3935     0
    rhs       c3936     0
    rhs       c3937     0
    rhs       c3938     0
    rhs       c3939     0
    rhs       c3940     0
    rhs       c3941     0
    rhs       c3942     0
    rhs       c3943     0
    rhs       c3944     0
    rhs       c3945     0
    rhs       c3946     0
    rhs       c3947     0
    rhs       c3948     0
    rhs       c3949     0
    rhs       c3950     0
    rhs       c3951     0
    rhs       c3952     0
    rhs       c3953     0
    rhs       c3954     0
    rhs       c3955     0
    rhs       c3956     0
    rhs       c3957     0
    rhs       c3958     0
    rhs       c3959     0
    rhs       c3960     0
    rhs       c3961     0
    rhs       c3962     0
    rhs       c3963     0
    rhs       c3964     0
    rhs       c3965     0
    rhs       c3966     0
    rhs       c3967     0
    rhs       c3968     0
    rhs       c3969     0
    rhs       c3970     0
    rhs       c3971     0
    rhs       c3972     0
    rhs       c3973     0
    rhs       c3974     0
    rhs       c3975     0
    rhs       c3976     0
    rhs       c3977     0
    rhs       c3978     0
    rhs       c3979     0
    rhs       c3980     0
    rhs       c3981     0
    rhs       c3982     0
    rhs       c3983     0
    rhs       c3984     0
    rhs       c3985     0
    rhs       c3986     0
    rhs       c3987     0
    rhs       c3988     0
    rhs       c3989     0
    rhs       c3990     0
    rhs       c3991     0
    rhs       c3992     0
    rhs       c3993     0
    rhs       c3994     0
    rhs       c3995     0
    rhs       c3996     0
    rhs       c3997     0
    rhs       c3998     0
    rhs       c3999     0
    rhs       c4000     0
    rhs       c4001     0
    rhs       c4002     0
    rhs       c4003     0
    rhs       c4004     0
    rhs       c4005     0
    rhs       c4006     0
    rhs       c4007     0
    rhs       c4008     0
    rhs       c4009     0
    rhs       c4010     0
    rhs       c4011     0
    rhs       c4012     0
    rhs       c4013     0
    rhs       c4014     0
    rhs       c4015     0
    rhs       c4016     0
    rhs       c4017     0
    rhs       c4018     0
    rhs       c4019     0
    rhs       c4020     0
    rhs       c4021     0
    rhs       c4022     0
    rhs       c4023     0
    rhs       c4024     0
    rhs       c4025     0
    rhs       c4026     0
    rhs       c4027     0
    rhs       c4028     0
    rhs       c4029     0
    rhs       c4030     0
    rhs       c4031     0
    rhs       c4032     0
    rhs       c4033     0
    rhs       c4034     0
    rhs       c4035     0
    rhs       c4036     0
    rhs       c4037     0
    rhs       c4038     0
    rhs       c4039     0
    rhs       c4040     0
    rhs       c4041     0
    rhs       c4042     0
    rhs       c4043     0
    rhs       c4044     0
    rhs       c4045     0
    rhs       c4046     0
    rhs       c4047     0
    rhs       c4048     0
    rhs       c4049     0
    rhs       c4050     0
    rhs       c4051     0
    rhs       c4052     0
    rhs       c4053     0
    rhs       c4054     0
    rhs       c4055     0
    rhs       c4056     0
    rhs       c4057     0
    rhs       c4058     0
    rhs       c4059     0
    rhs       c4060     0
    rhs       c4061     0
    rhs       c4062     0
    rhs       c4063     0
    rhs       c4064     0
    rhs       c4065     0
    rhs       c4066     0
    rhs       c4067     0
    rhs       c4068     0
    rhs       c4069     0
    rhs       c4070     0
    rhs       c4071     0
    rhs       c4072     0
    rhs       c4073     0
    rhs       c4074     0
    rhs       c4075     0
    rhs       c4076     0
    rhs       c4077     0
    rhs       c4078     0
    rhs       c4079     0
    rhs       c4080     0
    rhs       c4081     0
    rhs       c4082     0
    rhs       c4083     0
    rhs       c4084     0
    rhs       c4085     0
    rhs       c4086     0
    rhs       c4087     0
    rhs       c4088     0
    rhs       c4089     0
    rhs       c4090     0
    rhs       c4091     0
    rhs       c4092     0
    rhs       c4093     0
    rhs       c4094     0
    rhs       c4095     0
    rhs       c4096     0
    rhs       c4097     0
    rhs       c4098     0
    rhs       c4099     0
    rhs       c4100     0
    rhs       c4101     0
    rhs       c4102     0
    rhs       c4103     0
    rhs       c4104     0
    rhs       c4105     0
    rhs       c4106     0
    rhs       c4107     0
    rhs       c4108     0
    rhs       c4109     0
    rhs       c4110     0
    rhs       c4111     0
    rhs       c4112     0
    rhs       c4113     0
    rhs       c4114     0
    rhs       c4115     0
    rhs       c4116     0
    rhs       c4117     0
    rhs       c4118     0
    rhs       c4119     0
    rhs       c4120     0
    rhs       c4121     0
    rhs       c4122     0
    rhs       c4123     0
    rhs       c4124     0
    rhs       c4125     0
    rhs       c4126     0
    rhs       c4127     0
    rhs       c4128     0
    rhs       c4129     0
    rhs       c4130     0
    rhs       c4131     0
    rhs       c4132     0
    rhs       c4133     0
    rhs       c4134     0
    rhs       c4135     0
    rhs       c4136     0
    rhs       c4137     0
    rhs       c4138     0
    rhs       c4139     0
    rhs       c4140     0
    rhs       c4141     0
    rhs       c4142     0
    rhs       c4143     0
    rhs       c4144     0
    rhs       c4145     0
    rhs       c4146     0
    rhs       c4147     0
    rhs       c4148     0
    rhs       c4149     0
    rhs       c4150     0
    rhs       c4151     0
    rhs       c4152     0
    rhs       c4153     0
    rhs       c4154     0
    rhs       c4155     0
    rhs       c4156     0
    rhs       c4157     0
    rhs       c4158     0
    rhs       c4159     0
    rhs       c4160     0
    rhs       c4161     0
    rhs       c4162     0
    rhs       c4163     0
    rhs       c4164     0
    rhs       c4165     0
    rhs       c4166     0
    rhs       c4167     0
    rhs       c4168     0
    rhs       c4169     0
    rhs       c4170     0
    rhs       c4171     0
    rhs       c4172     0
    rhs       c4173     0
    rhs       c4174     0
    rhs       c4175     0
    rhs       c4176     0
    rhs       c4177     0
    rhs       c4178     0
    rhs       c4179     0
    rhs       c4180     0
    rhs       c4181     0
    rhs       c4182     0
    rhs       c4183     0
    rhs       c4184     0
    rhs       c4185     0
    rhs       c4186     0
    rhs       c4187     0
    rhs       c4188     0
    rhs       c4189     0
    rhs       c4190     0
    rhs       c4191     0
    rhs       c4192     0
    rhs       c4193     0
    rhs       c4194     0
    rhs       c4195     0
    rhs       c4196     0
    rhs       c4197     0
    rhs       c4198     0
    rhs       c4199     0
    rhs       c4200     0
    rhs       c4201     0
    rhs       c4202     0
    rhs       c4203     0
    rhs       c4204     0
    rhs       c4205     0
    rhs       c4206     0
    rhs       c4207     0
    rhs       c4208     0
    rhs       c4209     0
    rhs       c4210     0
    rhs       c4211     0
    rhs       c4212     0
    rhs       c4213     0
    rhs       c4214     0
    rhs       c4215     0
    rhs       c4216     0
    rhs       c4217     0
    rhs       c4218     0
    rhs       c4219     0
    rhs       c4220     0
    rhs       c4221     0
    rhs       c4222     0
    rhs       c4223     0
    rhs       c4224     0
    rhs       c4225     0
    rhs       c4226     0
    rhs       c4227     0
    rhs       c4228     0
    rhs       c4229     0
    rhs       c4230     0
    rhs       c4231     0
    rhs       c4232     0
    rhs       c4233     0
    rhs       c4234     0
    rhs       c4235     0
    rhs       c4236     0
    rhs       c4237     0
    rhs       c4238     0
    rhs       c4239     0
    rhs       c4240     0
    rhs       c4241     0
    rhs       c4242     0
    rhs       c4243     0
    rhs       c4244     0
    rhs       c4245     0
    rhs       c4246     0
    rhs       c4247     0
    rhs       c4248     0
    rhs       c4249     0
    rhs       c4250     0
    rhs       c4251     0
    rhs       c4252     0
    rhs       c4253     0
    rhs       c4254     0
    rhs       c4255     0
    rhs       c4256     0
    rhs       c4257     0
    rhs       c4258     0
    rhs       c4259     0
    rhs       c4260     0
    rhs       c4261     0
    rhs       c4262     0
    rhs       c4263     0
    rhs       c4264     0
    rhs       c4265     0
    rhs       c4266     0
    rhs       c4267     0
    rhs       c4268     0
    rhs       c4269     0
    rhs       c4270     0
    rhs       c4271     0
    rhs       c4272     0
    rhs       c4273     0
    rhs       c4274     0
    rhs       c4275     0
    rhs       c4276     0
    rhs       c4277     0
    rhs       c4278     0
    rhs       c4279     0
    rhs       c4280     0
    rhs       c4281     0
    rhs       c4282     0
    rhs       c4283     0
    rhs       c4284     0
    rhs       c4285     0
    rhs       c4286     0
    rhs       c4287     0
    rhs       c4288     0
    rhs       c4289     0
    rhs       c4290     0
    rhs       c4291     0
    rhs       c4292     0
    rhs       c4293     0
    rhs       c4294     0
    rhs       c4295     0
    rhs       c4296     0
    rhs       c4297     0
    rhs       c4298     0
    rhs       c4299     0
    rhs       c4300     0
    rhs       c4301     0
    rhs       c4302     0
    rhs       c4303     0
    rhs       c4304     0
    rhs       c4305     0
    rhs       c4306     0
    rhs       c4307     0
    rhs       c4308     0
    rhs       c4309     0
    rhs       c4310     0
    rhs       c4311     0
    rhs       c4312     0
    rhs       c4313     0
    rhs       c4314     0
    rhs       c4315     0
    rhs       c4316     0
    rhs       c4317     0
    rhs       c4318     0
    rhs       c4319     0
    rhs       c4320     0
    rhs       c4321     0
    rhs       c4322     0
    rhs       c4323     0
    rhs       c4324     0
    rhs       c4325     0
    rhs       c4326     0
    rhs       c4327     0
    rhs       c4328     0
    rhs       c4329     0
    rhs       c4330     0
    rhs       c4331     0
    rhs       c4332     0
    rhs       c4333     0
    rhs       c4334     0
    rhs       c4335     0
    rhs       c4336     0
    rhs       c4337     0
    rhs       c4338     0
    rhs       c4339     0
    rhs       c4340     0
    rhs       c4341     0
    rhs       c4342     0
    rhs       c4343     0
    rhs       c4344     0
    rhs       c4345     0
    rhs       c4346     0
    rhs       c4347     0
    rhs       c4348     0
    rhs       c4349     0
    rhs       c4350     0
    rhs       c4351     0
    rhs       c4352     0
    rhs       c4353     0
    rhs       c4354     0
    rhs       c4355     0
    rhs       c4356     0
    rhs       c4357     0
    rhs       c4358     0
    rhs       c4359     0
    rhs       c4360     0
    rhs       c4361     0
    rhs       c4362     0
    rhs       c4363     0
    rhs       c4364     0
    rhs       c4365     0
    rhs       c4366     0
    rhs       c4367     0
    rhs       c4368     0
    rhs       c4369     0
    rhs       c4370     0
    rhs       c4371     0
    rhs       c4372     0
    rhs       c4373     0
    rhs       c4374     0
    rhs       c4375     0
    rhs       c4376     0
    rhs       c4377     0
    rhs       c4378     0
    rhs       c4379     0
    rhs       c4380     0
    rhs       c4381     0
    rhs       c4382     0
    rhs       c4383     0
    rhs       c4384     0
    rhs       c4385     0
    rhs       c4386     0
    rhs       c4387     0
    rhs       c4388     0
    rhs       c4389     0
    rhs       c4390     0
    rhs       c4391     0
    rhs       c4392     0
    rhs       c4393     0
    rhs       c4394     0
    rhs       c4395     0
    rhs       c4396     0
    rhs       c4397     0
    rhs       c4398     0
    rhs       c4399     0
    rhs       c4400     0
    rhs       c4401     0
    rhs       c4402     0
    rhs       c4403     0
    rhs       c4404     0
    rhs       c4405     0
    rhs       c4406     0
    rhs       c4407     0
    rhs       c4408     0
    rhs       c4409     0
    rhs       c4410     0
    rhs       c4411     0
    rhs       c4412     0
    rhs       c4413     0
    rhs       c4414     0
    rhs       c4415     0
    rhs       c4416     0
    rhs       c4417     0
    rhs       c4418     0
    rhs       c4419     0
    rhs       c4420     0
    rhs       c4421     0
    rhs       c4422     0
    rhs       c4423     0
    rhs       c4424     0
    rhs       c4425     0
    rhs       c4426     0
    rhs       c4427     0
    rhs       c4428     0
    rhs       c4429     0
    rhs       c4430     0
    rhs       c4431     0
    rhs       c4432     0
    rhs       c4433     0
    rhs       c4434     0
    rhs       c4435     0
    rhs       c4436     0
    rhs       c4437     0
    rhs       c4438     0
    rhs       c4439     0
    rhs       c4440     0
    rhs       c4441     0
    rhs       c4442     0
    rhs       c4443     0
    rhs       c4444     0
    rhs       c4445     0
    rhs       c4446     0
    rhs       c4447     0
    rhs       c4448     0
    rhs       c4449     0
    rhs       c4450     0
    rhs       c4451     0
    rhs       c4452     0
    rhs       c4453     0
    rhs       c4454     0
    rhs       c4455     0
    rhs       c4456     0
    rhs       c4457     0
    rhs       c4458     0
    rhs       c4459     0
    rhs       c4460     0
    rhs       c4461     0
    rhs       c4462     0
    rhs       c4463     0
    rhs       c4464     0
    rhs       c4465     0
    rhs       c4466     0
    rhs       c4467     0
    rhs       c4468     0
    rhs       c4469     0
    rhs       c4470     0
    rhs       c4471     0
    rhs       c4472     0
    rhs       c4473     0
    rhs       c4474     0
    rhs       c4475     0
    rhs       c4476     0
    rhs       c4477     0
    rhs       c4478     0
    rhs       c4479     0
    rhs       c4480     0
    rhs       c4481     0
    rhs       c4482     0
    rhs       c4483     0
    rhs       c4484     0
    rhs       c4485     0
    rhs       c4486     0
    rhs       c4487     0
    rhs       c4488     0
    rhs       c4489     0
    rhs       c4490     0
    rhs       c4491     0
    rhs       c4492     0
    rhs       c4493     0
    rhs       c4494     0
    rhs       c4495     0
    rhs       c4496     0
    rhs       c4497     0
    rhs       c4498     0
    rhs       c4499     0
    rhs       c4500     0
    rhs       c4501     0
    rhs       c4502     0
    rhs       c4503     0
    rhs       c4504     0
    rhs       c4505     0
    rhs       c4506     0
    rhs       c4507     0
    rhs       c4508     0
    rhs       c4509     0
    rhs       c4510     0
    rhs       c4511     0
    rhs       c4512     0
    rhs       c4513     0
    rhs       c4514     0
    rhs       c4515     0
    rhs       c4516     0
    rhs       c4517     0
    rhs       c4518     0
    rhs       c4519     0
    rhs       c4520     0
    rhs       c4521     0
    rhs       c4522     0
    rhs       c4523     0
    rhs       c4524     0
    rhs       c4525     0
    rhs       c4526     0
    rhs       c4527     0
    rhs       c4528     0
    rhs       c4529     0
    rhs       c4530     0
    rhs       c4531     0
    rhs       c4532     0
    rhs       c4533     0
    rhs       c4534     0
    rhs       c4535     0
    rhs       c4536     0
    rhs       c4537     0
    rhs       c4538     0
    rhs       c4539     0
    rhs       c4540     0
    rhs       c4541     0
    rhs       c4542     0
    rhs       c4543     0
    rhs       c4544     0
    rhs       c4545     0
    rhs       c4546     0
    rhs       c4547     0
    rhs       c4548     0
    rhs       c4549     0
    rhs       c4550     0
    rhs       c4551     0
    rhs       c4552     0
    rhs       c4553     0
    rhs       c4554     0
    rhs       c4555     0
    rhs       c4556     0
    rhs       c4557     0
    rhs       c4558     0
    rhs       c4559     0
    rhs       c4560     0
    rhs       c4561     0
    rhs       c4562     0
    rhs       c4563     0
    rhs       c4564     0
    rhs       c4565     0
    rhs       c4566     0
    rhs       c4567     0
    rhs       c4568     0
    rhs       c4569     0
    rhs       c4570     0
    rhs       c4571     0
    rhs       c4572     0
    rhs       c4573     0
    rhs       c4574     0
    rhs       c4575     0
    rhs       c4576     0
    rhs       c4577     0
    rhs       c4578     0
    rhs       c4579     0
    rhs       c4580     0
    rhs       c4581     0
    rhs       c4582     0
    rhs       c4583     0
    rhs       c4584     0
    rhs       c4585     0
    rhs       c4586     0
    rhs       c4587     0
    rhs       c4588     0
    rhs       c4589     0
    rhs       c4590     0
    rhs       c4591     0
    rhs       c4592     0
    rhs       c4593     0
    rhs       c4594     0
    rhs       c4595     0
    rhs       c4596     0
    rhs       c4597     0
    rhs       c4598     0
    rhs       c4599     0
    rhs       c4600     0
    rhs       c4601     0
    rhs       c4602     0
    rhs       c4603     0
    rhs       c4604     0
    rhs       c4605     0
    rhs       c4606     0
    rhs       c4607     0
    rhs       c4608     0
    rhs       c4609     0
    rhs       c4610     0
    rhs       c4611     0
    rhs       c4612     0
    rhs       c4613     0
    rhs       c4614     0
    rhs       c4615     0
    rhs       c4616     0
    rhs       c4617     0
    rhs       c4618     0
    rhs       c4619     0
    rhs       c4620     0
    rhs       c4621     0
    rhs       c4622     0
    rhs       c4623     0
    rhs       c4624     0
    rhs       c4625     0
    rhs       c4626     0
    rhs       c4627     0
    rhs       c4628     0
    rhs       c4629     0
    rhs       c4630     0
    rhs       c4631     0
    rhs       c4632     0
    rhs       c4633     0
    rhs       c4634     0
    rhs       c4635     0
    rhs       c4636     0
    rhs       c4637     0
    rhs       c4638     0
    rhs       c4639     0
    rhs       c4640     0
    rhs       c4641     0
    rhs       c4642     0
    rhs       c4643     0
    rhs       c4644     0
    rhs       c4645     0
    rhs       c4646     0
    rhs       c4647     0
    rhs       c4648     0
    rhs       c4649     0
    rhs       c4650     0
    rhs       c4651     0
    rhs       c4652     0
    rhs       c4653     0
    rhs       c4654     0
    rhs       c4655     0
    rhs       c4656     0
    rhs       c4657     0
    rhs       c4658     0
    rhs       c4659     0
    rhs       c4660     0
    rhs       c4661     0
    rhs       c4662     0
    rhs       c4663     0
    rhs       c4664     0
    rhs       c4665     0
    rhs       c4666     0
    rhs       c4667     0
    rhs       c4668     0
    rhs       c4669     0
    rhs       c4670     0
    rhs       c4671     0
    rhs       c4672     0
    rhs       c4673     0
    rhs       c4674     0
    rhs       c4675     0
    rhs       c4676     0
    rhs       c4677     0
    rhs       c4678     0
    rhs       c4679     0
    rhs       c4680     0
    rhs       c4681     0
    rhs       c4682     0
    rhs       c4683     0
    rhs       c4684     0
    rhs       c4685     0
    rhs       c4686     0
    rhs       c4687     0
    rhs       c4688     0
    rhs       c4689     0
    rhs       c4690     0
    rhs       c4691     0
    rhs       c4692     0
    rhs       c4693     0
    rhs       c4694     0
    rhs       c4695     0
    rhs       c4696     0
    rhs       c4697     0
    rhs       c4698     0
    rhs       c4699     0
    rhs       c4700     0
    rhs       c4701     0
    rhs       c4702     0
    rhs       c4703     0
    rhs       c4704     0
    rhs       c4705     0
    rhs       c4706     0
    rhs       c4707     0
    rhs       c4708     0
    rhs       c4709     0
    rhs       c4710     0
    rhs       c4711     0
    rhs       c4712     0
    rhs       c4713     0
    rhs       c4714     0
    rhs       c4715     0
    rhs       c4716     18000
    rhs       c4717     18000
    rhs       c4718     18000
    rhs       c4719     18000
    rhs       c4720     18000
    rhs       c4721     18000
    rhs       c4722     18000
    rhs       c4723     18000
    rhs       c4724     18000
    rhs       c4725     18000
    rhs       c4726     16500
    rhs       c4727     16500
    rhs       c4728     16500
    rhs       c4729     16500
    rhs       c4730     16500
    rhs       c4731     16500
    rhs       c4732     16500
    rhs       c4733     16500
    rhs       c4734     16500
    rhs       c4735     16500
    rhs       c4736     0
    rhs       c4737     0
    rhs       c4738     0
    rhs       c4739     0
    rhs       c4740     0
    rhs       c4741     0
    rhs       c4742     0
    rhs       c4743     0
    rhs       c4744     0
    rhs       c4745     0
    rhs       c4746     0
    rhs       c4747     0
    rhs       c4748     0
    rhs       c4749     0
    rhs       c4750     0
    rhs       c4751     0
    rhs       c4752     0
    rhs       c4753     0
    rhs       c4754     0
    rhs       c4755     0
    rhs       c4756     0
    rhs       c4757     0
    rhs       c4758     0
    rhs       c4759     0
    rhs       c4760     0
    rhs       c4761     0
    rhs       c4762     0
    rhs       c4763     0
    rhs       c4764     0
    rhs       c4765     0
    rhs       c4766     0
    rhs       c4767     0
    rhs       c4768     0
    rhs       c4769     0
    rhs       c4770     0
    rhs       c4771     0
    rhs       c4772     0
    rhs       c4773     0
    rhs       c4774     0
    rhs       c4775     0
    rhs       c4776     0
    rhs       c4777     0
    rhs       c4778     0
    rhs       c4779     0
    rhs       c4780     0
    rhs       c4781     0
    rhs       c4782     0
    rhs       c4783     0
    rhs       c4784     0
    rhs       c4785     0
    rhs       c4786     0
    rhs       c4787     0
    rhs       c4788     0
    rhs       c4789     0
    rhs       c4790     0
    rhs       c4791     0
    rhs       c4792     0
    rhs       c4793     0
    rhs       c4794     0
    rhs       c4795     0
    rhs       c4796     0
    rhs       c4797     0
    rhs       c4798     0
    rhs       c4799     0
    rhs       c4800     0
    rhs       c4801     0
    rhs       c4802     0
    rhs       c4803     0
    rhs       c4804     0
    rhs       c4805     0
    rhs       c4806     0
    rhs       c4807     0
    rhs       c4808     0
    rhs       c4809     0
    rhs       c4810     0
    rhs       c4811     0
    rhs       c4812     0
    rhs       c4813     0
    rhs       c4814     0
    rhs       c4815     0
    rhs       c4816     0
    rhs       c4817     0
    rhs       c4818     0
    rhs       c4819     0
    rhs       c4820     0
    rhs       c4821     0
    rhs       c4822     0
    rhs       c4823     0
    rhs       c4824     0
    rhs       c4825     0
    rhs       c4826     0
    rhs       c4827     0
    rhs       c4828     0
    rhs       c4829     0
    rhs       c4830     0
    rhs       c4831     0
    rhs       c4832     0
    rhs       c4833     0
    rhs       c4834     0
    rhs       c4835     0
    rhs       c4836     0
    rhs       c4837     0
    rhs       c4838     0
    rhs       c4839     0
    rhs       c4840     0
    rhs       c4841     0
    rhs       c4842     0
    rhs       c4843     0
    rhs       c4844     0
    rhs       c4845     0
    rhs       c4846     0
    rhs       c4847     0
    rhs       c4848     0
    rhs       c4849     0
    rhs       c4850     0
    rhs       c4851     0
    rhs       c4852     0
    rhs       c4853     0
    rhs       c4854     0
    rhs       c4855     0
    rhs       c4856     0
    rhs       c4857     0
    rhs       c4858     0
    rhs       c4859     0
    rhs       c4860     0
    rhs       c4861     0
    rhs       c4862     0
    rhs       c4863     0
    rhs       c4864     0
    rhs       c4865     0
    rhs       c4866     0
    rhs       c4867     0
    rhs       c4868     0
    rhs       c4869     0
    rhs       c4870     0
    rhs       c4871     0
    rhs       c4872     0
    rhs       c4873     0
    rhs       c4874     0
    rhs       c4875     0
    rhs       c4876     0
    rhs       c4877     0
    rhs       c4878     0
    rhs       c4879     0
    rhs       c4880     0
    rhs       c4881     0
    rhs       c4882     0
    rhs       c4883     0
    rhs       c4884     0
    rhs       c4885     0
    rhs       c4886     0
    rhs       c4887     0
    rhs       c4888     0
    rhs       c4889     0
    rhs       c4890     0
    rhs       c4891     0
    rhs       c4892     0
    rhs       c4893     0
    rhs       c4894     0
    rhs       c4895     0
    rhs       c4896     0
    rhs       c4897     0
    rhs       c4898     0
    rhs       c4899     0
    rhs       c4900     0
    rhs       c4901     0
    rhs       c4902     0
    rhs       c4903     0
    rhs       c4904     0
    rhs       c4905     0
    rhs       c4906     0
    rhs       c4907     0
    rhs       c4908     0
    rhs       c4909     0
    rhs       c4910     0
    rhs       c4911     0
    rhs       c4912     0
    rhs       c4913     0
    rhs       c4914     0
    rhs       c4915     0
    rhs       c4916     0
    rhs       c4917     0
    rhs       c4918     0
    rhs       c4919     0
    rhs       c4920     0
    rhs       c4921     0
    rhs       c4922     0
    rhs       c4923     0
    rhs       c4924     0
    rhs       c4925     0
    rhs       c4926     0
    rhs       c4927     0
    rhs       c4928     0
    rhs       c4929     0
    rhs       c4930     0
    rhs       c4931     0
    rhs       c4932     0
    rhs       c4933     0
    rhs       c4934     0
    rhs       c4935     0
    rhs       c4936     0
    rhs       c4937     0
    rhs       c4938     0
    rhs       c4939     0
    rhs       c4940     0
    rhs       c4941     0
    rhs       c4942     0
    rhs       c4943     0
    rhs       c4944     0
    rhs       c4945     0
    rhs       c4946     0
    rhs       c4947     0
    rhs       c4948     0
    rhs       c4949     0
    rhs       c4950     0
    rhs       c4951     0
    rhs       c4952     0
    rhs       c4953     0
    rhs       c4954     0
    rhs       c4955     0
    rhs       c4956     0
    rhs       c4957     0
    rhs       c4958     0
    rhs       c4959     0
    rhs       c4960     0
    rhs       c4961     0
    rhs       c4962     0
    rhs       c4963     0
    rhs       c4964     0
    rhs       c4965     0
    rhs       c4966     0
    rhs       c4967     0
    rhs       c4968     0
    rhs       c4969     0
    rhs       c4970     0
    rhs       c4971     0
    rhs       c4972     0
    rhs       c4973     0
    rhs       c4974     0
    rhs       c4975     0
    rhs       c4976     0
    rhs       c4977     0
    rhs       c4978     0
    rhs       c4979     0
    rhs       c4980     0
    rhs       c4981     0
    rhs       c4982     0
    rhs       c4983     0
    rhs       c4984     0
    rhs       c4985     0
    rhs       c4986     0
    rhs       c4987     0
    rhs       c4988     0
    rhs       c4989     0
    rhs       c4990     0
    rhs       c4991     0
    rhs       c4992     0
    rhs       c4993     0
    rhs       c4994     0
    rhs       c4995     0
    rhs       c4996     0
RANGES
BOUNDS
 BV bounds    x[1]
 BV bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 FX bounds    x[20]     0
 FX bounds    x[21]     0
 BV bounds    x[22]
 BV bounds    x[23]
 FX bounds    x[24]     0
 FX bounds    x[25]     0
 BV bounds    x[26]
 BV bounds    x[27]
 FX bounds    x[28]     0
 FX bounds    x[29]     0
 BV bounds    x[30]
 BV bounds    x[31]
 FX bounds    x[32]     0
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 FX bounds    x[39]     0
 FX bounds    x[40]     0
 BV bounds    x[41]
 BV bounds    x[42]
 FX bounds    x[43]     0
 FX bounds    x[44]     0
 FX bounds    x[45]     0
 BV bounds    x[46]
 BV bounds    x[47]
 FX bounds    x[48]     0
 FX bounds    x[49]     0
 FX bounds    x[50]     0
 FX bounds    x[51]     0
 BV bounds    x[52]
 BV bounds    x[53]
 FX bounds    x[54]     0
 FX bounds    x[55]     0
 FX bounds    x[56]     0
 BV bounds    x[57]
 BV bounds    x[58]
 FX bounds    x[59]     0
 FX bounds    x[60]     0
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 FX bounds    x[70]     0
 FX bounds    x[71]     0
 BV bounds    x[72]
 BV bounds    x[73]
 FX bounds    x[74]     0
 FX bounds    x[75]     0
 FX bounds    x[76]     0
 BV bounds    x[77]
 BV bounds    x[78]
 FX bounds    x[79]     0
 FX bounds    x[80]     0
 FX bounds    x[81]     0
 FX bounds    x[82]     0
 BV bounds    x[83]
 BV bounds    x[84]
 FX bounds    x[85]     0
 FX bounds    x[86]     0
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 BV bounds    x[90]
 BV bounds    x[91]
 BV bounds    x[92]
 BV bounds    x[93]
 BV bounds    x[94]
 FX bounds    x[95]     0
 BV bounds    x[96]
 BV bounds    x[97]
 FX bounds    x[98]     0
 FX bounds    x[99]     0
 BV bounds    x[100]
 BV bounds    x[101]
 FX bounds    x[102]    0
 FX bounds    x[103]    0
 BV bounds    x[104]
 BV bounds    x[105]
 BV bounds    x[106]
 BV bounds    x[107]
 BV bounds    x[108]
 BV bounds    x[109]
 BV bounds    x[110]
 BV bounds    x[111]
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 BV bounds    x[119]
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 BV bounds    x[127]
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 BV bounds    x[135]
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 BV bounds    x[168]
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 BV bounds    x[178]
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 BV bounds    x[182]
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 BV bounds    x[188]
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 BV bounds    x[198]
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 BV bounds    x[248]
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 BV bounds    x[260]
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 BV bounds    x[272]
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 BV bounds    x[284]
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 BV bounds    x[332]
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 BV bounds    x[341]
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 BV bounds    x[369]
 BV bounds    x[370]
 BV bounds    x[371]
 BV bounds    x[372]
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 BV bounds    x[411]
 BV bounds    x[412]
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 BV bounds    x[422]
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 BV bounds    x[457]
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 BV bounds    x[461]
 BV bounds    x[462]
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 BV bounds    x[467]
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 BV bounds    x[499]
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 BV bounds    x[510]
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 BV bounds    x[552]
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 BV bounds    x[588]
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 BV bounds    x[640]
 BV bounds    x[641]
 BV bounds    x[642]
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 BV bounds    x[668]
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 BV bounds    x[712]
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 BV bounds    x[722]
 BV bounds    x[723]
 BV bounds    x[724]
 BV bounds    x[725]
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 BV bounds    x[736]
 BV bounds    x[737]
 BV bounds    x[738]
 BV bounds    x[739]
 BV bounds    x[740]
 BV bounds    x[741]
 BV bounds    x[742]
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 BV bounds    x[816]
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 BV bounds    x[822]
 BV bounds    x[823]
 BV bounds    x[824]
 BV bounds    x[825]
 BV bounds    x[826]
 BV bounds    x[827]
 BV bounds    x[828]
 BV bounds    x[829]
 BV bounds    x[830]
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 BV bounds    x[904]
 BV bounds    x[905]
 BV bounds    x[906]
 BV bounds    x[907]
 BV bounds    x[908]
 BV bounds    x[909]
 BV bounds    x[910]
 BV bounds    x[911]
 BV bounds    x[912]
 BV bounds    x[913]
 BV bounds    x[914]
 BV bounds    x[915]
 BV bounds    x[916]
 BV bounds    x[917]
 BV bounds    x[918]
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 BV bounds    x[989]
 BV bounds    x[990]
 BV bounds    x[991]
 BV bounds    x[992]
 BV bounds    x[993]
 BV bounds    x[994]
 BV bounds    x[995]
 BV bounds    x[996]
 BV bounds    x[997]
 BV bounds    x[998]
 BV bounds    x[999]
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 BV bounds    x[1003]
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 BV bounds    x[1017]
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 BV bounds    x[1071]
 BV bounds    x[1072]
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 BV bounds    x[1082]
 BV bounds    x[1083]
 BV bounds    x[1084]
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 BV bounds    x[1096]
 BV bounds    x[1097]
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 BV bounds    x[1101]
 BV bounds    x[1102]
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 BV bounds    x[1107]
 BV bounds    x[1108]
 BV bounds    x[1109]
 BV bounds    x[1110]
 BV bounds    x[1111]
 BV bounds    x[1112]
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 BV bounds    x[1150]
ENDATA
