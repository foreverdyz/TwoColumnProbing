NAME
ROWS
 N  OBJ
 G  c1_1
 G  c2_1
 G  c3_1
 G  c4_1
 G  c5_1
 G  c6_1
 G  c7_1
 G  c8_1
 G  c9_1
 G  c10_1
 G  c11_1
 G  c12_1
 G  c13_1
 G  c14_1
 G  c15_1
 G  c16_1
 G  c17_1
 G  c18_1
 G  c19_1
 G  c20_1
 G  c21_1
 G  c22_1
 G  c23_1
 G  c24_1
 G  c25_1
 G  c26_1
 G  c27_1
 G  c28_1
 G  c29_1
 G  c30_1
 E  c1
 E  c2
 E  c3
 E  c4
 E  c5
 E  c6
 E  c7
 E  c8
 E  c9
 E  c10
 E  c11
 E  c12
 E  c13
 E  c14
 E  c15
 E  c16
 E  c17
 E  c18
 E  c19
 E  c20
 E  c21
 E  c22
 E  c23
 E  c24
 E  c25
 E  c26
 E  c27
 E  c28
 E  c29
 E  c30
 E  c31
 E  c32
 E  c33
 E  c34
 E  c35
 E  c36
 E  c37
 E  c38
 E  c39
 E  c40
 E  c41
 E  c42
 E  c43
 E  c44
 E  c45
 E  c46
 E  c47
 E  c48
 E  c49
 E  c50
 E  c51
 E  c52
 E  c53
 E  c54
 E  c55
 E  c56
 E  c57
 E  c58
 E  c59
 E  c60
 E  c61
 E  c62
 E  c63
 E  c64
 E  c65
 E  c66
 E  c67
 E  c68
 E  c69
COLUMNS
    x[1]      c1_1      1
    x[1]      c2_1      1
    x[1]      c3_1      1
    x[1]      c4_1      1
    x[1]      c5_1      1
    x[1]      c6_1      1
    x[1]      c7_1      1
    x[1]      c8_1      1
    x[1]      c9_1      1
    x[1]      c10_1     1
    x[1]      c11_1     1
    x[1]      c12_1     1
    x[1]      c13_1     1
    x[1]      c14_1     1
    x[1]      c15_1     1
    x[1]      c16_1     1
    x[1]      c17_1     1
    x[1]      c18_1     1
    x[1]      c19_1     1
    x[1]      c20_1     1
    x[1]      c21_1     1
    x[1]      c22_1     1
    x[1]      c23_1     1
    x[1]      c24_1     1
    x[1]      c25_1     1
    x[1]      c26_1     1
    x[1]      c27_1     1
    x[1]      c28_1     1
    x[1]      c29_1     1
    x[1]      c30_1     1
    x[1]      OBJ       1
    MARKER    'MARKER'                 'INTORG'
    x[2]      c1        14
    x[2]      c2        53
    x[2]      c3        48
    x[2]      c4        33
    x[2]      c5        15
    x[2]      c6        43
    x[2]      c7        8
    x[2]      c8        38
    x[2]      c9        34
    x[2]      c10       37
    x[2]      c11       25
    x[2]      c12       42
    x[2]      c13       16
    x[2]      c14       10
    x[2]      c15       28
    x[3]      c1        36
    x[3]      c2        48
    x[3]      c3        34
    x[3]      c4        34
    x[3]      c5        9
    x[3]      c6        28
    x[3]      c7        30
    x[3]      c8        42
    x[3]      c9        13
    x[3]      c10       42
    x[3]      c11       47
    x[3]      c12       33
    x[3]      c13       6
    x[3]      c14       51
    x[3]      c15       47
    x[4]      c1        11
    x[4]      c2        48
    x[4]      c3        8
    x[4]      c4        36
    x[4]      c5        24
    x[4]      c6        30
    x[4]      c7        18
    x[4]      c8        24
    x[4]      c9        39
    x[4]      c10       23
    x[4]      c11       25
    x[4]      c12       45
    x[4]      c13       47
    x[4]      c14       33
    x[4]      c15       16
    x[5]      c1        27
    x[5]      c2        12
    x[5]      c3        5
    x[5]      c4        34
    x[5]      c5        43
    x[5]      c6        30
    x[5]      c7        16
    x[5]      c8        46
    x[5]      c9        19
    x[5]      c10       41
    x[5]      c11       29
    x[5]      c12       6
    x[5]      c13       30
    x[5]      c14       23
    x[5]      c15       32
    x[6]      c1        49
    x[6]      c2        43
    x[6]      c3        49
    x[6]      c4        19
    x[6]      c5        53
    x[6]      c6        10
    x[6]      c7        18
    x[6]      c8        20
    x[6]      c9        51
    x[6]      c10       33
    x[6]      c11       44
    x[6]      c12       33
    x[6]      c13       45
    x[6]      c14       31
    x[6]      c15       28
    x[7]      c1        26
    x[7]      c2        42
    x[7]      c3        21
    x[7]      c4        19
    x[7]      c5        54
    x[7]      c6        26
    x[7]      c7        21
    x[7]      c8        11
    x[7]      c9        13
    x[7]      c10       14
    x[7]      c11       22
    x[7]      c12       6
    x[7]      c13       37
    x[7]      c14       34
    x[7]      c15       16
    x[8]      c1        37
    x[8]      c2        14
    x[8]      c3        38
    x[8]      c4        30
    x[8]      c5        29
    x[8]      c6        32
    x[8]      c7        24
    x[8]      c8        32
    x[8]      c9        22
    x[8]      c10       40
    x[8]      c11       10
    x[8]      c12       24
    x[8]      c13       16
    x[8]      c14       32
    x[8]      c15       32
    x[9]      c1        45
    x[9]      c2        48
    x[9]      c3        11
    x[9]      c4        48
    x[9]      c5        24
    x[9]      c6        54
    x[9]      c7        46
    x[9]      c8        52
    x[9]      c9        20
    x[9]      c10       53
    x[9]      c11       21
    x[9]      c12       54
    x[9]      c13       19
    x[9]      c14       23
    x[9]      c15       15
    x[10]     c1        21
    x[10]     c2        16
    x[10]     c3        26
    x[10]     c4        32
    x[10]     c5        11
    x[10]     c6        26
    x[10]     c7        47
    x[10]     c8        24
    x[10]     c9        24
    x[10]     c10       14
    x[10]     c11       5
    x[10]     c12       9
    x[10]     c13       5
    x[10]     c14       38
    x[10]     c15       11
    x[11]     c1        6
    x[11]     c2        23
    x[11]     c3        12
    x[11]     c4        30
    x[11]     c5        47
    x[11]     c6        52
    x[11]     c7        6
    x[11]     c8        31
    x[11]     c9        45
    x[11]     c10       23
    x[11]     c11       10
    x[11]     c12       12
    x[11]     c13       44
    x[11]     c14       32
    x[11]     c15       8
    x[12]     c1        48
    x[12]     c2        25
    x[12]     c3        30
    x[12]     c4        26
    x[12]     c5        24
    x[12]     c6        34
    x[12]     c7        48
    x[12]     c8        45
    x[12]     c9        30
    x[12]     c10       37
    x[12]     c11       35
    x[12]     c12       48
    x[12]     c13       45
    x[12]     c14       40
    x[12]     c15       21
    x[13]     c1        38
    x[13]     c2        36
    x[13]     c3        18
    x[13]     c4        39
    x[13]     c5        34
    x[13]     c6        24
    x[13]     c7        27
    x[13]     c8        50
    x[13]     c9        51
    x[13]     c10       9
    x[13]     c11       17
    x[13]     c12       51
    x[13]     c13       53
    x[13]     c14       30
    x[13]     c15       33
    x[14]     c1        37
    x[14]     c2        54
    x[14]     c3        23
    x[14]     c4        47
    x[14]     c5        29
    x[14]     c6        21
    x[14]     c7        10
    x[14]     c8        47
    x[14]     c9        24
    x[14]     c10       14
    x[14]     c11       20
    x[14]     c12       16
    x[14]     c13       22
    x[14]     c14       14
    x[14]     c15       15
    x[15]     c1        10
    x[15]     c2        34
    x[15]     c3        8
    x[15]     c4        37
    x[15]     c5        49
    x[15]     c6        39
    x[15]     c7        26
    x[15]     c8        6
    x[15]     c9        17
    x[15]     c10       38
    x[15]     c11       33
    x[15]     c12       48
    x[15]     c13       40
    x[15]     c14       19
    x[15]     c15       54
    x[16]     c1        16
    x[16]     c2        45
    x[16]     c3        55
    x[16]     c4        52
    x[16]     c5        50
    x[16]     c6        41
    x[16]     c7        6
    x[16]     c8        15
    x[16]     c9        23
    x[16]     c10       19
    x[16]     c11       27
    x[16]     c12       8
    x[16]     c13       47
    x[16]     c14       37
    x[16]     c15       22
    x[17]     c1        35
    x[17]     c2        51
    x[17]     c3        46
    x[17]     c4        33
    x[17]     c5        39
    x[17]     c6        47
    x[17]     c7        36
    x[17]     c8        53
    x[17]     c9        22
    x[17]     c10       24
    x[17]     c11       39
    x[17]     c12       21
    x[17]     c13       55
    x[17]     c14       48
    x[17]     c15       55
    x[18]     c1        17
    x[18]     c2        45
    x[18]     c3        5
    x[18]     c4        5
    x[18]     c5        50
    x[18]     c6        36
    x[18]     c7        52
    x[18]     c8        20
    x[18]     c9        29
    x[18]     c10       29
    x[18]     c11       50
    x[18]     c12       54
    x[18]     c13       43
    x[18]     c14       36
    x[18]     c15       13
    x[19]     c1        7
    x[19]     c2        46
    x[19]     c3        10
    x[19]     c4        39
    x[19]     c5        36
    x[19]     c6        27
    x[19]     c7        14
    x[19]     c8        24
    x[19]     c9        36
    x[19]     c10       55
    x[19]     c11       17
    x[19]     c12       46
    x[19]     c13       34
    x[19]     c14       33
    x[19]     c15       47
    x[20]     c1        46
    x[20]     c2        30
    x[20]     c3        50
    x[20]     c4        34
    x[20]     c5        32
    x[20]     c6        52
    x[20]     c7        29
    x[20]     c8        31
    x[20]     c9        14
    x[20]     c10       29
    x[20]     c11       11
    x[20]     c12       39
    x[20]     c13       33
    x[20]     c14       27
    x[20]     c15       19
    x[21]     c1        26
    x[21]     c2        38
    x[21]     c3        52
    x[21]     c4        42
    x[21]     c5        42
    x[21]     c6        7
    x[21]     c7        43
    x[21]     c8        40
    x[21]     c9        33
    x[21]     c10       40
    x[21]     c11       25
    x[21]     c12       23
    x[21]     c13       6
    x[21]     c14       20
    x[21]     c15       33
    x[22]     c1        8
    x[22]     c2        52
    x[22]     c3        45
    x[22]     c4        30
    x[22]     c5        55
    x[22]     c6        6
    x[22]     c7        7
    x[22]     c8        54
    x[22]     c9        51
    x[22]     c10       52
    x[22]     c11       42
    x[22]     c12       11
    x[22]     c13       13
    x[22]     c14       14
    x[22]     c15       35
    x[23]     c1        40
    x[23]     c2        21
    x[23]     c3        42
    x[23]     c4        33
    x[23]     c5        21
    x[23]     c6        52
    x[23]     c7        8
    x[23]     c8        10
    x[23]     c9        17
    x[23]     c10       54
    x[23]     c11       50
    x[23]     c12       28
    x[23]     c13       15
    x[23]     c14       50
    x[23]     c15       15
    x[24]     c1        19
    x[24]     c2        9
    x[24]     c3        43
    x[24]     c4        19
    x[24]     c5        11
    x[24]     c6        13
    x[24]     c7        26
    x[24]     c8        40
    x[24]     c9        35
    x[24]     c10       16
    x[24]     c11       19
    x[24]     c12       27
    x[24]     c13       36
    x[24]     c14       54
    x[24]     c15       44
    x[25]     c1        33
    x[25]     c2        21
    x[25]     c3        19
    x[25]     c4        21
    x[25]     c5        24
    x[25]     c6        30
    x[25]     c7        31
    x[25]     c8        30
    x[25]     c9        31
    x[25]     c10       23
    x[25]     c11       40
    x[25]     c12       21
    x[25]     c13       41
    x[25]     c14       34
    x[25]     c15       55
    x[26]     c1        5
    x[26]     c2        15
    x[26]     c3        25
    x[26]     c4        38
    x[26]     c5        45
    x[26]     c6        32
    x[26]     c7        10
    x[26]     c8        50
    x[26]     c9        39
    x[26]     c10       8
    x[26]     c11       37
    x[26]     c12       30
    x[26]     c13       39
    x[26]     c14       50
    x[26]     c15       39
    x[27]     c1        42
    x[27]     c2        22
    x[27]     c3        8
    x[27]     c4        40
    x[27]     c5        10
    x[27]     c6        46
    x[27]     c7        6
    x[27]     c8        14
    x[27]     c9        12
    x[27]     c10       53
    x[27]     c11       38
    x[27]     c12       38
    x[27]     c13       50
    x[27]     c14       14
    x[27]     c15       28
    x[28]     c1        22
    x[28]     c2        12
    x[28]     c3        27
    x[28]     c4        9
    x[28]     c5        30
    x[28]     c6        41
    x[28]     c7        7
    x[28]     c8        44
    x[28]     c9        47
    x[28]     c10       23
    x[28]     c11       22
    x[28]     c12       52
    x[28]     c13       38
    x[28]     c14       54
    x[28]     c15       39
    x[29]     c1        14
    x[29]     c2        12
    x[29]     c3        5
    x[29]     c4        33
    x[29]     c5        42
    x[29]     c6        12
    x[29]     c7        12
    x[29]     c8        41
    x[29]     c9        9
    x[29]     c10       9
    x[29]     c11       20
    x[29]     c12       18
    x[29]     c13       18
    x[29]     c14       9
    x[29]     c15       23
    x[30]     c1        51
    x[30]     c2        19
    x[30]     c3        41
    x[30]     c4        48
    x[30]     c5        38
    x[30]     c6        44
    x[30]     c7        33
    x[30]     c8        42
    x[30]     c9        46
    x[30]     c10       52
    x[30]     c11       5
    x[30]     c12       43
    x[30]     c13       36
    x[30]     c14       37
    x[30]     c15       6
    x[31]     c1        49
    x[31]     c2        17
    x[31]     c3        39
    x[31]     c4        35
    x[31]     c5        51
    x[31]     c6        7
    x[31]     c7        42
    x[31]     c8        29
    x[31]     c9        46
    x[31]     c10       52
    x[31]     c11       16
    x[31]     c12       46
    x[31]     c13       6
    x[31]     c14       55
    x[31]     c15       20
    x[32]     c1        7
    x[32]     c2        38
    x[32]     c3        52
    x[32]     c4        42
    x[32]     c5        6
    x[32]     c6        12
    x[32]     c7        41
    x[32]     c8        8
    x[32]     c9        55
    x[32]     c10       37
    x[32]     c11       22
    x[32]     c12       42
    x[32]     c13       13
    x[32]     c14       55
    x[32]     c15       36
    x[33]     c1        10
    x[33]     c2        17
    x[33]     c3        33
    x[33]     c4        26
    x[33]     c5        48
    x[33]     c6        32
    x[33]     c7        37
    x[33]     c8        24
    x[33]     c9        25
    x[33]     c10       33
    x[33]     c11       25
    x[33]     c12       29
    x[33]     c13       47
    x[33]     c14       42
    x[33]     c15       29
    x[34]     c1        30
    x[34]     c2        9
    x[34]     c3        17
    x[34]     c4        13
    x[34]     c5        5
    x[34]     c6        30
    x[34]     c7        17
    x[34]     c8        16
    x[34]     c9        55
    x[34]     c10       39
    x[34]     c11       8
    x[34]     c12       23
    x[34]     c13       8
    x[34]     c14       51
    x[34]     c15       12
    x[35]     c1        14
    x[35]     c2        30
    x[35]     c3        5
    x[35]     c4        23
    x[35]     c5        25
    x[35]     c6        38
    x[35]     c7        55
    x[35]     c8        27
    x[35]     c9        38
    x[35]     c10       55
    x[35]     c11       43
    x[35]     c12       32
    x[35]     c13       5
    x[35]     c14       32
    x[35]     c15       48
    x[36]     c1        32
    x[36]     c2        24
    x[36]     c3        34
    x[36]     c4        55
    x[36]     c5        36
    x[36]     c6        6
    x[36]     c7        48
    x[36]     c8        15
    x[36]     c9        39
    x[36]     c10       18
    x[36]     c11       50
    x[36]     c12       31
    x[36]     c13       22
    x[36]     c14       10
    x[36]     c15       6
    x[37]     c1        24
    x[37]     c2        48
    x[37]     c3        11
    x[37]     c4        27
    x[37]     c5        53
    x[37]     c6        36
    x[37]     c7        31
    x[37]     c8        31
    x[37]     c9        51
    x[37]     c10       17
    x[37]     c11       47
    x[37]     c12       52
    x[37]     c13       48
    x[37]     c14       26
    x[37]     c15       35
    x[38]     c1        36
    x[38]     c2        16
    x[38]     c3        21
    x[38]     c4        37
    x[38]     c5        24
    x[38]     c6        8
    x[38]     c7        20
    x[38]     c8        34
    x[38]     c9        46
    x[38]     c10       14
    x[38]     c11       9
    x[38]     c12       33
    x[38]     c13       37
    x[38]     c14       11
    x[38]     c15       8
    x[39]     c1        14
    x[39]     c2        34
    x[39]     c3        16
    x[39]     c4        30
    x[39]     c5        10
    x[39]     c6        34
    x[39]     c7        17
    x[39]     c8        42
    x[39]     c9        6
    x[39]     c10       54
    x[39]     c11       5
    x[39]     c12       51
    x[39]     c13       34
    x[39]     c14       38
    x[39]     c15       33
    x[40]     c1        13
    x[40]     c2        41
    x[40]     c3        17
    x[40]     c4        20
    x[40]     c5        22
    x[40]     c6        34
    x[40]     c7        21
    x[40]     c8        28
    x[40]     c9        15
    x[40]     c10       14
    x[40]     c11       12
    x[40]     c12       50
    x[40]     c13       11
    x[40]     c14       45
    x[40]     c15       46
    x[41]     c1        52
    x[41]     c2        28
    x[41]     c3        42
    x[41]     c4        14
    x[41]     c5        31
    x[41]     c6        30
    x[41]     c7        11
    x[41]     c8        53
    x[41]     c9        15
    x[41]     c10       24
    x[41]     c11       10
    x[41]     c12       38
    x[41]     c13       38
    x[41]     c14       44
    x[41]     c15       15
    x[42]     c1        16
    x[42]     c2        52
    x[42]     c3        23
    x[42]     c4        5
    x[42]     c5        53
    x[42]     c6        31
    x[42]     c7        19
    x[42]     c8        17
    x[42]     c9        47
    x[42]     c10       21
    x[42]     c11       10
    x[42]     c12       7
    x[42]     c13       22
    x[42]     c14       14
    x[42]     c15       37
    x[43]     c1        5
    x[43]     c2        10
    x[43]     c3        43
    x[43]     c4        42
    x[43]     c5        41
    x[43]     c6        13
    x[43]     c7        13
    x[43]     c8        18
    x[43]     c9        40
    x[43]     c10       46
    x[43]     c11       42
    x[43]     c12       42
    x[43]     c13       52
    x[43]     c14       30
    x[43]     c15       11
    x[44]     c1        35
    x[44]     c2        8
    x[44]     c3        5
    x[44]     c4        49
    x[44]     c5        10
    x[44]     c6        49
    x[44]     c7        34
    x[44]     c8        48
    x[44]     c9        10
    x[44]     c10       28
    x[44]     c11       22
    x[44]     c12       34
    x[44]     c13       35
    x[44]     c14       19
    x[44]     c15       44
    x[45]     c1        48
    x[45]     c2        51
    x[45]     c3        42
    x[45]     c4        47
    x[45]     c5        26
    x[45]     c6        47
    x[45]     c7        24
    x[45]     c8        8
    x[45]     c9        15
    x[45]     c10       30
    x[45]     c11       25
    x[45]     c12       18
    x[45]     c13       39
    x[45]     c14       24
    x[45]     c15       48
    x[46]     c1        11
    x[46]     c2        40
    x[46]     c3        47
    x[46]     c4        24
    x[46]     c5        35
    x[46]     c6        48
    x[46]     c7        35
    x[46]     c8        19
    x[46]     c9        52
    x[46]     c10       29
    x[46]     c11       20
    x[46]     c12       35
    x[46]     c13       37
    x[46]     c14       44
    x[46]     c15       9
    x[47]     c1        47
    x[47]     c2        48
    x[47]     c3        55
    x[47]     c4        45
    x[47]     c5        55
    x[47]     c6        35
    x[47]     c7        35
    x[47]     c8        7
    x[47]     c9        29
    x[47]     c10       43
    x[47]     c11       45
    x[47]     c12       37
    x[47]     c13       27
    x[47]     c14       52
    x[47]     c15       11
    x[48]     c1        27
    x[48]     c2        46
    x[48]     c3        32
    x[48]     c4        25
    x[48]     c5        10
    x[48]     c6        39
    x[48]     c7        55
    x[48]     c8        6
    x[48]     c9        32
    x[48]     c10       50
    x[48]     c11       9
    x[48]     c12       35
    x[48]     c13       38
    x[48]     c14       16
    x[48]     c15       47
    x[49]     c1        24
    x[49]     c2        30
    x[49]     c3        47
    x[49]     c4        24
    x[49]     c5        29
    x[49]     c6        29
    x[49]     c7        31
    x[49]     c8        35
    x[49]     c9        26
    x[49]     c10       53
    x[49]     c11       15
    x[49]     c12       33
    x[49]     c13       24
    x[49]     c14       24
    x[49]     c15       18
    x[50]     c1        49
    x[50]     c2        38
    x[50]     c3        9
    x[50]     c4        28
    x[50]     c5        36
    x[50]     c6        6
    x[50]     c7        44
    x[50]     c8        27
    x[50]     c9        10
    x[50]     c10       43
    x[50]     c11       7
    x[50]     c12       28
    x[50]     c13       5
    x[50]     c14       29
    x[50]     c15       54
    x[51]     c1        17
    x[51]     c2        21
    x[51]     c3        26
    x[51]     c4        54
    x[51]     c5        37
    x[51]     c6        35
    x[51]     c7        29
    x[51]     c8        33
    x[51]     c9        42
    x[51]     c10       24
    x[51]     c11       15
    x[51]     c12       18
    x[51]     c13       16
    x[51]     c14       39
    x[51]     c15       10
    x[52]     c1        46
    x[52]     c2        12
    x[52]     c3        43
    x[52]     c4        11
    x[52]     c5        15
    x[52]     c6        32
    x[52]     c7        19
    x[52]     c8        20
    x[52]     c9        55
    x[52]     c10       38
    x[52]     c11       35
    x[52]     c12       52
    x[52]     c13       25
    x[52]     c14       39
    x[52]     c15       46
    x[53]     c1        53
    x[53]     c2        35
    x[53]     c3        50
    x[53]     c4        53
    x[53]     c5        36
    x[53]     c6        7
    x[53]     c7        46
    x[53]     c8        25
    x[53]     c9        6
    x[53]     c10       39
    x[53]     c11       44
    x[53]     c12       34
    x[53]     c13       14
    x[53]     c14       39
    x[53]     c15       34
    x[54]     c1        53
    x[54]     c2        38
    x[54]     c3        13
    x[54]     c4        32
    x[54]     c5        54
    x[54]     c6        32
    x[54]     c7        33
    x[54]     c8        39
    x[54]     c9        54
    x[54]     c10       22
    x[54]     c11       9
    x[54]     c12       42
    x[54]     c13       27
    x[54]     c14       33
    x[54]     c15       20
    x[55]     c1        10
    x[55]     c2        17
    x[55]     c3        30
    x[55]     c4        25
    x[55]     c5        22
    x[55]     c6        40
    x[55]     c7        41
    x[55]     c8        55
    x[55]     c9        34
    x[55]     c10       49
    x[55]     c11       50
    x[55]     c12       24
    x[55]     c13       6
    x[55]     c14       37
    x[55]     c15       35
    x[56]     c1        30
    x[56]     c2        52
    x[56]     c3        14
    x[56]     c4        19
    x[56]     c5        55
    x[56]     c6        33
    x[56]     c7        22
    x[56]     c8        51
    x[56]     c9        32
    x[56]     c10       7
    x[56]     c11       28
    x[56]     c12       51
    x[56]     c13       51
    x[56]     c14       17
    x[56]     c15       33
    MARKER    'MARKER'                 'INTEND'
    x[57]     c1_1      -1
    x[57]     c1        1
    x[58]     c2_1      -1
    x[58]     c1        -1
    x[59]     c3_1      -1
    x[59]     c2        1
    x[60]     c4_1      -1
    x[60]     c2        -1
    x[61]     c5_1      -1
    x[61]     c3        1
    x[62]     c6_1      -1
    x[62]     c3        -1
    x[63]     c7_1      -1
    x[63]     c4        1
    x[64]     c8_1      -1
    x[64]     c4        -1
    x[65]     c9_1      -1
    x[65]     c5        1
    x[66]     c10_1     -1
    x[66]     c5        -1
    x[67]     c11_1     -1
    x[67]     c6        1
    x[68]     c12_1     -1
    x[68]     c6        -1
    x[69]     c13_1     -1
    x[69]     c7        1
    x[70]     c14_1     -1
    x[70]     c7        -1
    x[71]     c15_1     -1
    x[71]     c8        1
    x[72]     c16_1     -1
    x[72]     c8        -1
    x[73]     c17_1     -1
    x[73]     c9        1
    x[74]     c18_1     -1
    x[74]     c9        -1
    x[75]     c19_1     -1
    x[75]     c10       1
    x[76]     c20_1     -1
    x[76]     c10       -1
    x[77]     c21_1     -1
    x[77]     c11       1
    x[78]     c22_1     -1
    x[78]     c11       -1
    x[79]     c23_1     -1
    x[79]     c12       1
    x[80]     c24_1     -1
    x[80]     c12       -1
    x[81]     c25_1     -1
    x[81]     c13       1
    x[82]     c26_1     -1
    x[82]     c13       -1
    x[83]     c27_1     -1
    x[83]     c14       1
    x[84]     c28_1     -1
    x[84]     c14       -1
    x[85]     c29_1     -1
    x[85]     c15       1
    x[86]     c30_1     -1
    x[86]     c15       -1
RHS
    rhs       c1_1      0
    rhs       c2_1      0
    rhs       c3_1      0
    rhs       c4_1      0
    rhs       c5_1      0
    rhs       c6_1      0
    rhs       c7_1      0
    rhs       c8_1      0
    rhs       c9_1      0
    rhs       c10_1     0
    rhs       c11_1     0
    rhs       c12_1     0
    rhs       c13_1     0
    rhs       c14_1     0
    rhs       c15_1     0
    rhs       c16_1     0
    rhs       c17_1     0
    rhs       c18_1     0
    rhs       c19_1     0
    rhs       c20_1     0
    rhs       c21_1     0
    rhs       c22_1     0
    rhs       c23_1     0
    rhs       c24_1     0
    rhs       c25_1     0
    rhs       c26_1     0
    rhs       c27_1     0
    rhs       c28_1     0
    rhs       c29_1     0
    rhs       c30_1     0
    rhs       c1        731
    rhs       c2        731
    rhs       c3        731
    rhs       c4        731
    rhs       c5        731
    rhs       c6        731
    rhs       c7        731
    rhs       c8        731
    rhs       c9        731
    rhs       c10       731
    rhs       c11       731
    rhs       c12       731
    rhs       c13       731
    rhs       c14       731
    rhs       c15       731
    rhs       c16       0
    rhs       c17       0
    rhs       c18       0
    rhs       c19       0
    rhs       c20       0
    rhs       c21       0
    rhs       c22       0
    rhs       c23       0
    rhs       c24       0
    rhs       c25       0
    rhs       c26       0
    rhs       c27       0
    rhs       c28       0
    rhs       c29       0
    rhs       c30       0
    rhs       c31       0
    rhs       c32       0
    rhs       c33       0
    rhs       c34       0
    rhs       c35       0
    rhs       c36       0
    rhs       c37       0
    rhs       c38       0
    rhs       c39       0
    rhs       c40       0
    rhs       c41       0
    rhs       c42       0
    rhs       c43       0
    rhs       c44       0
    rhs       c45       0
    rhs       c46       0
    rhs       c47       0
    rhs       c48       0
    rhs       c49       0
    rhs       c50       0
    rhs       c51       0
    rhs       c52       0
    rhs       c53       0
    rhs       c54       0
    rhs       c55       0
    rhs       c56       0
    rhs       c57       0
    rhs       c58       0
    rhs       c59       0
    rhs       c60       0
    rhs       c61       0
    rhs       c62       0
    rhs       c63       0
    rhs       c64       0
    rhs       c65       0
    rhs       c66       0
    rhs       c67       0
    rhs       c68       0
    rhs       c69       0
RANGES
BOUNDS
 LO bounds    x[1]      0
 PL bounds    x[1]
 BV bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 LO bounds    x[57]     0
 PL bounds    x[57]
 LO bounds    x[58]     0
 PL bounds    x[58]
 LO bounds    x[59]     0
 PL bounds    x[59]
 LO bounds    x[60]     0
 PL bounds    x[60]
 LO bounds    x[61]     0
 PL bounds    x[61]
 LO bounds    x[62]     0
 PL bounds    x[62]
 LO bounds    x[63]     0
 PL bounds    x[63]
 LO bounds    x[64]     0
 PL bounds    x[64]
 LO bounds    x[65]     0
 PL bounds    x[65]
 LO bounds    x[66]     0
 PL bounds    x[66]
 LO bounds    x[67]     0
 PL bounds    x[67]
 LO bounds    x[68]     0
 PL bounds    x[68]
 LO bounds    x[69]     0
 PL bounds    x[69]
 LO bounds    x[70]     0
 PL bounds    x[70]
 LO bounds    x[71]     0
 PL bounds    x[71]
 LO bounds    x[72]     0
 PL bounds    x[72]
 LO bounds    x[73]     0
 PL bounds    x[73]
 LO bounds    x[74]     0
 PL bounds    x[74]
 LO bounds    x[75]     0
 PL bounds    x[75]
 LO bounds    x[76]     0
 PL bounds    x[76]
 LO bounds    x[77]     0
 PL bounds    x[77]
 LO bounds    x[78]     0
 PL bounds    x[78]
 LO bounds    x[79]     0
 PL bounds    x[79]
 LO bounds    x[80]     0
 PL bounds    x[80]
 LO bounds    x[81]     0
 PL bounds    x[81]
 LO bounds    x[82]     0
 PL bounds    x[82]
 LO bounds    x[83]     0
 PL bounds    x[83]
 LO bounds    x[84]     0
 PL bounds    x[84]
 LO bounds    x[85]     0
 PL bounds    x[85]
 LO bounds    x[86]     0
 PL bounds    x[86]
ENDATA
