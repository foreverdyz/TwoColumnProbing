NAME
ROWS
 N  OBJ
 L  c1
 L  c2
 L  c3
 L  c4
 L  c5
 L  c6
 L  c7
 L  c8
 L  c9
 L  c10
 L  c11
 L  c12
 L  c13
 L  c14
 L  c15
 L  c16
 L  c17
 L  c18
 L  c19
 L  c20
 L  c21
 L  c22
 L  c23
 L  c24
 L  c25
 L  c26
 L  c27
 L  c28
 L  c29
 L  c30
 L  c31
 L  c32
 L  c33
 L  c34
 L  c35
 L  c36
 L  c37
 L  c38
 L  c39
 L  c40
 L  c41
 L  c42
 L  c43
 L  c44
 L  c45
 L  c46
 L  c47
 L  c48
 L  c49
 L  c50
 L  c51
 L  c52
 L  c53
 L  c54
 L  c55
 L  c56
 L  c57
 L  c58
 L  c59
 L  c60
 L  c61
 L  c62
 L  c63
 L  c64
 L  c65
 L  c66
 L  c67
 L  c68
 L  c69
 L  c70
 L  c71
 L  c72
 L  c73
 L  c74
 L  c75
 L  c76
 L  c77
 L  c78
 L  c79
 L  c80
 L  c81
 L  c82
 L  c83
 L  c84
 L  c85
 L  c86
 L  c87
 L  c88
 L  c89
 L  c90
 L  c91
 L  c92
 L  c93
 L  c94
 L  c95
 L  c96
 L  c97
 L  c98
 L  c99
 L  c100
 L  c101
 L  c102
 L  c103
 L  c104
 L  c105
 L  c106
 L  c107
 L  c108
 L  c109
 L  c110
 L  c111
 L  c112
 L  c113
 L  c114
 L  c115
 L  c116
 L  c117
 L  c118
 L  c119
 L  c120
 L  c121
 L  c122
 L  c123
 L  c124
 L  c125
 L  c126
 L  c127
 L  c128
 L  c129
 L  c130
 L  c131
 L  c132
 L  c133
 L  c134
 L  c135
 L  c136
 L  c137
 L  c138
 L  c139
 L  c140
 L  c141
 L  c142
 L  c143
 L  c144
 L  c145
 L  c146
 L  c147
 L  c148
 L  c149
 L  c150
 L  c151
 L  c152
 L  c153
 L  c154
 L  c155
 L  c156
 L  c157
 L  c158
 L  c159
 L  c160
 L  c161
 L  c162
 L  c163
 L  c164
 L  c165
 L  c166
 L  c167
 L  c168
 L  c169
 L  c170
 L  c171
 L  c172
 L  c173
 L  c174
 L  c175
 L  c176
 L  c177
 L  c178
 L  c179
 L  c180
 L  c181
 L  c182
 L  c183
 L  c184
 L  c185
 L  c186
 L  c187
 L  c188
 L  c189
 L  c190
 L  c191
 L  c192
 L  c193
 L  c194
 L  c195
 L  c196
 L  c197
 L  c198
 L  c199
 L  c200
 L  c201
 L  c202
 L  c203
 L  c204
 L  c205
 L  c206
 L  c207
 L  c208
 L  c209
 L  c210
 L  c211
 L  c212
 L  c213
 L  c214
 L  c215
 L  c216
 L  c217
 L  c218
 L  c219
 L  c220
 L  c221
 L  c222
 L  c223
 L  c224
 L  c225
 L  c226
 L  c227
 L  c228
 L  c229
 L  c230
 L  c231
 L  c232
 L  c233
 L  c234
 L  c235
 L  c236
 L  c237
 L  c238
 L  c239
 L  c240
 L  c241
 L  c242
 L  c243
 L  c244
 L  c245
 L  c246
 L  c247
 L  c248
 L  c249
 L  c250
 L  c251
 L  c252
 L  c253
 L  c254
 L  c255
 L  c256
 L  c257
 L  c258
 L  c259
 L  c260
 L  c261
 L  c262
 L  c263
 L  c264
 L  c265
 L  c266
 L  c267
 L  c268
 L  c269
 L  c270
 L  c271
 L  c272
 L  c273
 L  c274
 L  c275
 L  c276
 L  c277
 L  c278
 L  c279
 L  c280
 L  c281
 L  c282
 L  c283
 L  c284
 L  c285
 L  c286
 L  c287
 L  c288
 L  c289
 L  c290
 L  c291
 L  c292
 L  c293
 L  c294
 L  c295
 L  c296
 L  c297
 L  c298
 L  c299
 L  c300
 L  c301
 L  c302
 L  c303
 L  c304
 L  c305
 L  c306
 L  c307
 L  c308
 L  c309
 L  c310
 L  c311
 L  c312
 L  c313
 L  c314
 L  c315
 L  c316
 L  c317
 L  c318
 L  c319
 L  c320
 L  c321
 L  c322
 L  c323
 L  c324
 L  c325
 L  c326
 L  c327
 L  c328
 L  c329
 L  c330
 L  c331
 L  c332
 L  c333
 L  c334
 L  c335
 L  c336
 L  c337
 L  c338
 L  c339
 L  c340
 L  c341
 L  c342
 L  c343
 L  c344
 L  c345
 L  c346
 L  c347
 L  c348
 L  c349
 L  c350
 L  c351
 L  c352
 L  c353
 L  c354
 L  c355
 L  c356
 L  c357
 L  c358
 L  c359
 L  c360
 L  c361
 L  c362
 L  c363
 L  c364
 L  c365
 L  c366
 L  c367
 L  c368
 L  c369
 L  c370
 L  c371
 L  c372
 L  c373
 L  c374
 L  c375
 L  c376
 L  c377
 L  c378
 L  c379
 L  c380
 L  c381
 L  c382
 L  c383
 L  c384
 L  c385
 L  c386
 L  c387
 L  c388
 L  c389
 L  c390
 L  c391
 L  c392
 L  c393
 L  c394
 L  c395
 L  c396
 L  c397
 L  c398
 L  c399
 L  c400
 L  c401
 L  c402
 L  c403
 L  c404
 L  c405
 L  c406
 L  c407
 L  c408
 L  c409
 L  c410
 L  c411
 L  c412
 L  c413
 L  c414
 L  c415
 L  c416
 L  c417
 L  c418
 L  c419
 L  c420
 L  c421
 L  c422
 L  c423
 L  c424
 L  c425
 L  c426
 L  c427
 L  c428
 L  c429
 L  c430
 L  c431
 L  c432
 L  c433
 L  c434
 L  c435
 L  c436
 L  c437
 L  c438
 L  c439
 L  c440
 L  c441
 L  c442
 L  c443
 L  c444
 L  c445
 L  c446
 L  c447
 L  c448
 L  c449
 L  c450
 L  c451
 L  c452
 L  c453
 L  c454
 L  c455
 L  c456
 L  c457
 L  c458
 L  c459
 L  c460
 L  c461
 L  c462
 L  c463
 L  c464
 L  c465
 L  c466
 L  c467
 L  c468
 L  c469
 L  c470
 L  c471
 L  c472
 L  c473
 L  c474
 L  c475
 L  c476
 L  c477
 L  c478
 L  c479
 L  c480
 L  c481
 L  c482
 L  c483
 L  c484
 L  c485
 L  c486
 L  c487
 L  c488
 L  c489
 L  c490
 L  c491
 L  c492
 L  c493
 L  c494
 L  c495
 L  c496
 L  c497
 L  c498
 L  c499
 L  c500
 L  c501
 L  c502
 L  c503
 L  c504
 L  c505
 L  c506
 L  c507
 L  c508
 L  c509
 L  c510
 L  c511
 L  c512
 L  c513
 L  c514
 L  c515
 L  c516
 L  c517
 L  c518
 L  c519
 L  c520
 L  c521
 L  c522
 L  c523
 L  c524
 L  c525
 L  c526
 L  c527
 L  c528
 L  c529
 L  c530
 L  c531
 L  c532
 L  c533
 L  c534
 L  c535
 L  c536
 L  c537
 L  c538
 L  c539
 L  c540
 L  c541
 L  c542
 L  c543
 L  c544
 L  c545
 L  c546
 L  c547
 L  c548
 L  c549
 L  c550
 L  c551
 L  c552
 L  c553
 L  c554
 L  c555
 L  c556
 L  c557
 L  c558
 L  c559
 L  c560
 L  c561
 L  c562
 L  c563
 L  c564
 L  c565
 L  c566
 L  c567
 L  c568
 L  c569
 L  c570
 L  c571
 L  c572
 L  c573
 L  c574
 L  c575
 L  c576
 L  c577
 L  c578
 L  c579
 L  c580
 L  c581
 L  c582
 L  c583
 L  c584
 L  c585
 L  c586
 L  c587
 L  c588
 L  c589
 L  c590
 L  c591
 L  c592
 L  c593
 L  c594
 L  c595
 L  c596
 L  c597
 L  c598
 L  c599
 L  c600
 L  c601
 L  c602
 L  c603
 L  c604
 L  c605
 L  c606
 L  c607
 L  c608
 L  c609
 L  c610
 L  c611
 L  c612
 L  c613
 L  c614
 L  c615
 L  c616
 L  c617
 L  c618
 L  c619
 L  c620
 L  c621
 L  c622
 L  c623
 L  c624
 L  c625
 L  c626
 L  c627
 L  c628
 L  c629
 L  c630
 L  c631
 L  c632
 L  c633
 L  c634
 L  c635
 L  c636
 L  c637
 L  c638
 L  c639
 L  c640
 L  c641
 L  c642
 L  c643
 L  c644
 L  c645
 L  c646
 L  c647
 L  c648
 L  c649
 L  c650
 L  c651
 L  c652
 L  c653
 L  c654
 L  c655
 L  c656
 L  c657
 L  c658
 L  c659
 L  c660
 L  c661
 L  c662
 L  c663
 L  c664
 L  c665
 L  c666
 L  c667
 L  c668
 L  c669
 L  c670
 L  c671
 L  c672
 L  c673
 L  c674
 L  c675
 L  c676
 L  c677
 L  c678
 L  c679
 L  c680
 L  c681
 L  c682
 L  c683
 L  c684
 L  c685
 L  c686
 L  c687
 L  c688
 L  c689
 L  c690
 L  c691
 L  c692
 L  c693
 L  c694
 L  c695
 L  c696
 L  c697
 L  c698
 L  c699
 L  c700
 L  c701
 L  c702
 L  c703
 L  c704
 L  c705
 L  c706
 L  c707
 L  c708
 L  c709
 L  c710
 L  c711
 L  c712
 L  c713
 L  c714
 L  c715
 L  c716
 L  c717
 L  c718
 L  c719
 L  c720
 L  c721
 L  c722
 L  c723
 L  c724
 L  c725
 L  c726
 L  c727
 L  c728
 L  c729
 L  c730
 L  c731
 L  c732
 L  c733
 L  c734
 L  c735
 L  c736
 L  c737
 L  c738
 L  c739
 L  c740
 L  c741
 L  c742
 L  c743
 L  c744
 L  c745
 L  c746
 L  c747
 L  c748
 L  c749
 L  c750
 L  c751
 L  c752
 L  c753
 L  c754
 L  c755
 L  c756
 L  c757
 L  c758
 L  c759
 L  c760
 L  c761
 L  c762
 L  c763
 L  c764
 L  c765
 L  c766
 L  c767
 L  c768
 L  c769
 L  c770
 L  c771
 L  c772
 L  c773
 L  c774
 L  c775
 L  c776
 L  c777
 L  c778
 L  c779
 L  c780
 L  c781
 L  c782
 L  c783
 L  c784
 L  c785
 L  c786
 L  c787
 L  c788
 L  c789
 L  c790
 L  c791
 L  c792
 L  c793
 L  c794
 L  c795
 L  c796
 L  c797
 L  c798
 L  c799
 L  c800
 L  c801
 L  c802
 L  c803
 L  c804
 L  c805
 L  c806
 L  c807
 L  c808
 L  c809
 L  c810
 L  c811
 L  c812
 L  c813
 L  c814
 L  c815
 L  c816
 L  c817
 L  c818
 L  c819
 L  c820
 L  c821
 L  c822
 L  c823
 L  c824
 L  c825
 L  c826
 L  c827
 L  c828
 L  c829
 L  c830
 L  c831
 L  c832
 L  c833
 L  c834
 L  c835
 L  c836
 L  c837
 L  c838
 L  c839
 L  c840
 L  c841
 L  c842
 L  c843
 L  c844
 L  c845
 L  c846
 L  c847
 L  c848
 L  c849
 L  c850
 L  c851
 L  c852
 L  c853
 L  c854
 L  c855
 L  c856
 L  c857
 L  c858
 L  c859
 L  c860
 L  c861
 L  c862
 L  c863
 L  c864
 L  c865
 L  c866
 L  c867
 L  c868
 L  c869
 L  c870
 L  c871
 L  c872
 L  c873
 L  c874
 L  c875
 L  c876
 L  c877
 L  c878
 L  c879
 L  c880
 L  c881
 L  c882
 L  c883
 L  c884
 L  c885
 L  c886
 L  c887
 L  c888
 L  c889
 L  c890
 L  c891
 L  c892
 L  c893
 L  c894
 L  c895
 L  c896
 L  c897
 L  c898
 L  c899
 L  c900
 L  c901
 L  c902
 L  c903
 L  c904
 L  c905
 L  c906
 L  c907
 L  c908
 L  c909
 L  c910
 L  c911
 L  c912
 L  c913
 L  c914
 L  c915
 L  c916
 L  c917
 L  c918
 L  c919
 L  c920
 L  c921
 L  c922
 L  c923
 L  c924
 L  c925
 L  c926
 L  c927
 L  c928
 L  c929
 L  c930
 L  c931
 L  c932
 L  c933
 L  c934
 L  c935
 L  c936
 L  c937
 L  c938
 L  c939
 L  c940
 L  c941
 L  c942
 L  c943
 L  c944
 L  c945
 L  c946
 L  c947
 L  c948
 L  c949
 L  c950
 L  c951
 L  c952
 L  c953
 L  c954
 L  c955
 L  c956
 L  c957
 L  c958
 L  c959
 L  c960
 L  c961
 L  c962
 L  c963
 L  c964
 L  c965
 L  c966
 L  c967
 L  c968
 L  c969
 L  c970
 L  c971
 L  c972
 L  c973
 L  c974
 L  c975
 L  c976
 L  c977
 L  c978
 L  c979
 L  c980
 L  c981
 L  c982
 L  c983
 L  c984
 L  c985
 L  c986
 L  c987
 L  c988
 L  c989
 L  c990
 L  c991
 L  c992
 L  c993
 L  c994
 L  c995
 L  c996
 L  c997
 L  c998
 L  c999
 L  c1000
 L  c1001
 L  c1002
 L  c1003
 L  c1004
 L  c1005
 L  c1006
 L  c1007
 L  c1008
 L  c1009
 L  c1010
 L  c1011
 L  c1012
 L  c1013
 L  c1014
 L  c1015
 L  c1016
 L  c1017
 L  c1018
 L  c1019
 L  c1020
 L  c1021
 L  c1022
 L  c1023
 L  c1024
 L  c1025
 L  c1026
 L  c1027
 L  c1028
 L  c1029
 L  c1030
 L  c1031
 L  c1032
 L  c1033
 L  c1034
 L  c1035
 L  c1036
 L  c1037
 L  c1038
 L  c1039
 L  c1040
 L  c1041
 L  c1042
 L  c1043
 L  c1044
 L  c1045
 L  c1046
 L  c1047
 L  c1048
 L  c1049
 L  c1050
 L  c1051
 L  c1052
 L  c1053
 L  c1054
 L  c1055
 L  c1056
 L  c1057
 L  c1058
 L  c1059
 L  c1060
 L  c1061
 L  c1062
 L  c1063
 L  c1064
 L  c1065
 L  c1066
 L  c1067
 L  c1068
 L  c1069
 L  c1070
 L  c1071
 L  c1072
 L  c1073
 L  c1074
 L  c1075
 L  c1076
 L  c1077
 L  c1078
 L  c1079
 L  c1080
 L  c1081
 L  c1082
 L  c1083
 L  c1084
 L  c1085
 L  c1086
 L  c1087
 L  c1088
 L  c1089
 L  c1090
 L  c1091
 L  c1092
 L  c1093
 L  c1094
 L  c1095
 L  c1096
 L  c1097
 L  c1098
 L  c1099
 L  c1100
 L  c1101
 L  c1102
 L  c1103
 L  c1104
 L  c1105
 L  c1106
 L  c1107
 L  c1108
 L  c1109
 L  c1110
 L  c1111
 L  c1112
 L  c1113
 L  c1114
 L  c1115
 L  c1116
 L  c1117
 L  c1118
 L  c1119
 L  c1120
 L  c1121
 L  c1122
 L  c1123
 L  c1124
 L  c1125
 L  c1126
 L  c1127
 L  c1128
 L  c1129
 L  c1130
 L  c1131
 L  c1132
 L  c1133
 L  c1134
 L  c1135
 L  c1136
 L  c1137
 L  c1138
 L  c1139
 L  c1140
 L  c1141
 L  c1142
 L  c1143
 L  c1144
 L  c1145
 L  c1146
 L  c1147
 L  c1148
 L  c1149
 L  c1150
 L  c1151
 L  c1152
 L  c1153
 L  c1154
 L  c1155
 L  c1156
 L  c1157
 L  c1158
 L  c1159
 L  c1160
 L  c1161
 L  c1162
 L  c1163
 L  c1164
 L  c1165
 L  c1166
 L  c1167
 L  c1168
 L  c1169
 L  c1170
 L  c1171
 L  c1172
 L  c1173
 L  c1174
 L  c1175
 L  c1176
 L  c1177
 L  c1178
 L  c1179
 L  c1180
 L  c1181
 L  c1182
 L  c1183
 L  c1184
 L  c1185
 L  c1186
 L  c1187
 L  c1188
 L  c1189
 L  c1190
 L  c1191
 L  c1192
 L  c1193
 L  c1194
 L  c1195
 L  c1196
 L  c1197
 L  c1198
 L  c1199
 L  c1200
 L  c1201
 L  c1202
 L  c1203
 L  c1204
 L  c1205
 L  c1206
 L  c1207
 L  c1208
 L  c1209
 L  c1210
 L  c1211
 L  c1212
 L  c1213
 L  c1214
 L  c1215
 L  c1216
 L  c1217
 L  c1218
 L  c1219
 L  c1220
 L  c1221
 L  c1222
 L  c1223
 L  c1224
 L  c1225
 L  c1226
 L  c1227
 L  c1228
 L  c1229
 L  c1230
 L  c1231
 L  c1232
 L  c1233
 L  c1234
 L  c1235
 L  c1236
 L  c1237
 L  c1238
 L  c1239
 L  c1240
 L  c1241
 L  c1242
 L  c1243
 L  c1244
 L  c1245
 L  c1246
 L  c1247
 L  c1248
 L  c1249
 L  c1250
 L  c1251
 L  c1252
 L  c1253
 L  c1254
 L  c1255
 L  c1256
 L  c1257
 L  c1258
 L  c1259
 L  c1260
 L  c1261
 L  c1262
 L  c1263
 L  c1264
 L  c1265
 L  c1266
 L  c1267
 L  c1268
 L  c1269
 L  c1270
 L  c1271
 L  c1272
 L  c1273
 L  c1274
 L  c1275
 L  c1276
 L  c1277
 L  c1278
 L  c1279
 L  c1280
 L  c1281
 L  c1282
 L  c1283
 L  c1284
 L  c1285
 L  c1286
 L  c1287
 L  c1288
 L  c1289
 L  c1290
 L  c1291
 L  c1292
 L  c1293
 L  c1294
 L  c1295
 L  c1296
 L  c1297
 L  c1298
 L  c1299
 L  c1300
 L  c1301
 L  c1302
 L  c1303
 L  c1304
 L  c1305
 L  c1306
 L  c1307
 L  c1308
 L  c1309
 L  c1310
 L  c1311
 L  c1312
 L  c1313
 L  c1314
 L  c1315
 L  c1316
 L  c1317
 L  c1318
 L  c1319
 L  c1320
 L  c1321
 L  c1322
 L  c1323
 L  c1324
 L  c1325
 L  c1326
 L  c1327
 L  c1328
 L  c1329
 L  c1330
 L  c1331
 L  c1332
 L  c1333
 L  c1334
 L  c1335
 L  c1336
 L  c1337
 L  c1338
 L  c1339
 L  c1340
 L  c1341
 L  c1342
 L  c1343
 L  c1344
 L  c1345
 L  c1346
 L  c1347
 L  c1348
 L  c1349
 L  c1350
 L  c1351
 L  c1352
 L  c1353
 L  c1354
 L  c1355
 L  c1356
 L  c1357
 L  c1358
 L  c1359
 L  c1360
 L  c1361
 L  c1362
 L  c1363
 L  c1364
 L  c1365
 L  c1366
 L  c1367
 L  c1368
 L  c1369
 L  c1370
 L  c1371
 L  c1372
 L  c1373
 L  c1374
 L  c1375
 L  c1376
 L  c1377
 L  c1378
 L  c1379
 L  c1380
 L  c1381
 L  c1382
 L  c1383
 L  c1384
 L  c1385
 L  c1386
 L  c1387
 L  c1388
 L  c1389
 L  c1390
 L  c1391
 L  c1392
 L  c1393
 L  c1394
 L  c1395
 L  c1396
 L  c1397
 L  c1398
 L  c1399
 L  c1400
 L  c1401
 L  c1402
 L  c1403
 L  c1404
 L  c1405
 L  c1406
 L  c1407
 L  c1408
 L  c1409
 L  c1410
 L  c1411
 L  c1412
 L  c1413
 L  c1414
 L  c1415
 L  c1416
 L  c1417
 L  c1418
 L  c1419
 L  c1420
 L  c1421
 L  c1422
 L  c1423
 L  c1424
 L  c1425
 L  c1426
 L  c1427
 L  c1428
 L  c1429
 L  c1430
 L  c1431
 L  c1432
 L  c1433
 L  c1434
 L  c1435
 L  c1436
 L  c1437
 L  c1438
 L  c1439
 L  c1440
 L  c1441
 L  c1442
 L  c1443
 L  c1444
 L  c1445
 L  c1446
 L  c1447
 L  c1448
 L  c1449
 L  c1450
 L  c1451
 L  c1452
 L  c1453
 L  c1454
 L  c1455
 L  c1456
 L  c1457
 L  c1458
 L  c1459
 L  c1460
 L  c1461
 L  c1462
 L  c1463
 L  c1464
 L  c1465
 L  c1466
 L  c1467
 L  c1468
 L  c1469
 L  c1470
 L  c1471
 L  c1472
 L  c1473
 L  c1474
 L  c1475
 L  c1476
 L  c1477
 L  c1478
 L  c1479
 L  c1480
 L  c1481
 L  c1482
 L  c1483
 L  c1484
 L  c1485
 L  c1486
 L  c1487
 L  c1488
 L  c1489
 L  c1490
 L  c1491
 L  c1492
 L  c1493
 L  c1494
 L  c1495
 L  c1496
 L  c1497
 L  c1498
 L  c1499
 L  c1500
 L  c1501
 L  c1502
 L  c1503
 L  c1504
 L  c1505
 L  c1506
 L  c1507
 L  c1508
 L  c1509
 L  c1510
 L  c1511
 L  c1512
 L  c1513
 L  c1514
 L  c1515
 L  c1516
 L  c1517
 L  c1518
 L  c1519
 L  c1520
 L  c1521
 L  c1522
 L  c1523
 L  c1524
 L  c1525
 L  c1526
 L  c1527
 L  c1528
 L  c1529
 L  c1530
 L  c1531
 L  c1532
 L  c1533
 L  c1534
 L  c1535
 L  c1536
 L  c1537
 L  c1538
 L  c1539
 L  c1540
 L  c1541
 L  c1542
 L  c1543
 L  c1544
 L  c1545
 L  c1546
 L  c1547
 L  c1548
 L  c1549
 L  c1550
 L  c1551
 L  c1552
 L  c1553
 L  c1554
 L  c1555
 L  c1556
 L  c1557
 L  c1558
 L  c1559
 L  c1560
 L  c1561
 L  c1562
 L  c1563
 L  c1564
 L  c1565
 L  c1566
 L  c1567
 L  c1568
 L  c1569
 L  c1570
 L  c1571
 L  c1572
 L  c1573
 L  c1574
 L  c1575
 L  c1576
 L  c1577
 L  c1578
 L  c1579
 L  c1580
 L  c1581
 L  c1582
 L  c1583
 L  c1584
 L  c1585
 L  c1586
 L  c1587
 L  c1588
 L  c1589
 L  c1590
 L  c1591
 L  c1592
 L  c1593
 L  c1594
 L  c1595
 L  c1596
 L  c1597
 L  c1598
 L  c1599
 L  c1600
 L  c1601
 L  c1602
 L  c1603
 L  c1604
 L  c1605
 L  c1606
 L  c1607
 L  c1608
 L  c1609
 L  c1610
 L  c1611
 L  c1612
 L  c1613
 L  c1614
 L  c1615
 L  c1616
 L  c1617
 L  c1618
 L  c1619
 L  c1620
 L  c1621
 L  c1622
 L  c1623
 L  c1624
 L  c1625
 L  c1626
 L  c1627
 L  c1628
 L  c1629
 L  c1630
 L  c1631
 L  c1632
 L  c1633
 L  c1634
 L  c1635
 L  c1636
 L  c1637
 L  c1638
 L  c1639
 L  c1640
 L  c1641
 L  c1642
 L  c1643
 L  c1644
 L  c1645
 L  c1646
 L  c1647
 L  c1648
 L  c1649
 L  c1650
 L  c1651
 L  c1652
 L  c1653
 L  c1654
 L  c1655
 L  c1656
 L  c1657
 L  c1658
 L  c1659
 L  c1660
 L  c1661
 L  c1662
 L  c1663
 L  c1664
 L  c1665
 L  c1666
 L  c1667
 L  c1668
 L  c1669
 L  c1670
 L  c1671
 L  c1672
 L  c1673
 L  c1674
 L  c1675
 L  c1676
 L  c1677
 L  c1678
 L  c1679
 L  c1680
 L  c1681
 L  c1682
 L  c1683
 L  c1684
 L  c1685
 L  c1686
 L  c1687
 L  c1688
 L  c1689
 L  c1690
 L  c1691
 L  c1692
 L  c1693
 L  c1694
 L  c1695
 L  c1696
 L  c1697
 L  c1698
 L  c1699
 L  c1700
 L  c1701
 L  c1702
 L  c1703
 L  c1704
 L  c1705
 L  c1706
 L  c1707
 L  c1708
 L  c1709
 L  c1710
 L  c1711
 L  c1712
 L  c1713
 L  c1714
 L  c1715
 L  c1716
 L  c1717
 L  c1718
 L  c1719
 L  c1720
 L  c1721
 L  c1722
 L  c1723
 L  c1724
 L  c1725
 L  c1726
 L  c1727
 L  c1728
 L  c1729
 L  c1730
 L  c1731
 L  c1732
 L  c1733
 L  c1734
 L  c1735
 L  c1736
 L  c1737
 L  c1738
 L  c1739
 L  c1740
 L  c1741
 L  c1742
 L  c1743
 L  c1744
 L  c1745
 L  c1746
 L  c1747
 L  c1748
 L  c1749
 L  c1750
 L  c1751
 L  c1752
 L  c1753
 L  c1754
 L  c1755
 L  c1756
 L  c1757
 L  c1758
 L  c1759
 L  c1760
 L  c1761
 L  c1762
 L  c1763
 L  c1764
 L  c1765
 L  c1766
 L  c1767
 L  c1768
 L  c1769
 L  c1770
 L  c1771
 L  c1772
 L  c1773
 L  c1774
 L  c1775
 L  c1776
 L  c1777
 L  c1778
 L  c1779
 L  c1780
 L  c1781
 L  c1782
 L  c1783
 L  c1784
 L  c1785
 L  c1786
 L  c1787
 L  c1788
 L  c1789
 L  c1790
 L  c1791
 L  c1792
 L  c1793
 L  c1794
 L  c1795
 L  c1796
 L  c1797
 L  c1798
 L  c1799
 L  c1800
 L  c1801
 L  c1802
 L  c1803
 L  c1804
 L  c1805
 L  c1806
 L  c1807
 L  c1808
 L  c1809
 L  c1810
 L  c1811
 L  c1812
 L  c1813
 L  c1814
 L  c1815
 L  c1816
 L  c1817
 L  c1818
 L  c1819
 L  c1820
 L  c1821
 L  c1822
 L  c1823
 L  c1824
 L  c1825
 L  c1826
 L  c1827
 L  c1828
 L  c1829
 L  c1830
 L  c1831
 L  c1832
 L  c1833
 L  c1834
 L  c1835
 L  c1836
 L  c1837
 L  c1838
 L  c1839
 L  c1840
 L  c1841
 L  c1842
 L  c1843
 L  c1844
 L  c1845
 L  c1846
 L  c1847
 L  c1848
 L  c1849
 L  c1850
 L  c1851
 L  c1852
 L  c1853
 L  c1854
 L  c1855
 L  c1856
 L  c1857
 L  c1858
 L  c1859
 L  c1860
 L  c1861
 L  c1862
 L  c1863
 L  c1864
 L  c1865
 L  c1866
 L  c1867
 L  c1868
 L  c1869
 L  c1870
 L  c1871
 L  c1872
 L  c1873
 L  c1874
 L  c1875
 L  c1876
 L  c1877
 L  c1878
 L  c1879
 L  c1880
 L  c1881
 L  c1882
 L  c1883
 L  c1884
 L  c1885
 L  c1886
 L  c1887
 L  c1888
 L  c1889
 L  c1890
 L  c1891
 L  c1892
 L  c1893
 L  c1894
 L  c1895
 L  c1896
 L  c1897
 L  c1898
 L  c1899
 L  c1900
 L  c1901
 L  c1902
 L  c1903
 L  c1904
 L  c1905
 L  c1906
 L  c1907
 L  c1908
 L  c1909
 L  c1910
 L  c1911
 L  c1912
 L  c1913
 L  c1914
 L  c1915
 L  c1916
 L  c1917
 L  c1918
 L  c1919
 L  c1920
 L  c1921
 L  c1922
 L  c1923
 L  c1924
 L  c1925
 L  c1926
 L  c1927
 L  c1928
 L  c1929
 L  c1930
 L  c1931
 L  c1932
 L  c1933
 L  c1934
 L  c1935
 L  c1936
 L  c1937
 L  c1938
 L  c1939
 L  c1940
 L  c1941
 L  c1942
 L  c1943
 L  c1944
 L  c1945
 L  c1946
 L  c1947
 L  c1948
 L  c1949
 L  c1950
 L  c1951
 L  c1952
 L  c1953
 L  c1954
 L  c1955
 L  c1956
 L  c1957
 L  c1958
 L  c1959
 L  c1960
 L  c1961
 L  c1962
 L  c1963
 L  c1964
 L  c1965
 L  c1966
 L  c1967
 L  c1968
 L  c1969
 L  c1970
 L  c1971
 L  c1972
 L  c1973
 L  c1974
 L  c1975
 L  c1976
 L  c1977
 L  c1978
 L  c1979
 L  c1980
 L  c1981
 L  c1982
 L  c1983
 L  c1984
 L  c1985
 L  c1986
 L  c1987
 L  c1988
 L  c1989
 L  c1990
 L  c1991
 L  c1992
 L  c1993
 L  c1994
 L  c1995
 L  c1996
 L  c1997
 L  c1998
 L  c1999
 L  c2000
 L  c2001
 L  c2002
 L  c2003
 L  c2004
 L  c2005
 L  c2006
 L  c2007
 L  c2008
 L  c2009
 L  c2010
 L  c2011
 L  c2012
 L  c2013
 L  c2014
 L  c2015
 L  c2016
 L  c2017
 L  c2018
 L  c2019
 L  c2020
 L  c2021
 L  c2022
 L  c2023
 L  c2024
 L  c2025
 L  c2026
 L  c2027
 L  c2028
 L  c2029
 L  c2030
 L  c2031
 L  c2032
 L  c2033
 L  c2034
 L  c2035
 L  c2036
 L  c2037
 L  c2038
 L  c2039
 L  c2040
 L  c2041
 L  c2042
 L  c2043
 L  c2044
 L  c2045
 L  c2046
 L  c2047
 L  c2048
 L  c2049
 L  c2050
 L  c2051
 L  c2052
 L  c2053
 L  c2054
 L  c2055
 L  c2056
 L  c2057
 L  c2058
 L  c2059
 L  c2060
 L  c2061
 L  c2062
 L  c2063
 L  c2064
 L  c2065
 L  c2066
 L  c2067
 L  c2068
 L  c2069
 L  c2070
 L  c2071
 L  c2072
 L  c2073
 L  c2074
 L  c2075
 L  c2076
 L  c2077
 L  c2078
 L  c2079
 L  c2080
 L  c2081
 L  c2082
 L  c2083
 L  c2084
 L  c2085
 L  c2086
 L  c2087
 L  c2088
 L  c2089
 L  c2090
 L  c2091
 L  c2092
 L  c2093
 L  c2094
 L  c2095
 L  c2096
 L  c2097
 L  c2098
 L  c2099
 L  c2100
 L  c2101
 L  c2102
 L  c2103
 L  c2104
 L  c2105
 L  c2106
 L  c2107
 L  c2108
 L  c2109
 L  c2110
 L  c2111
 L  c2112
 L  c2113
 L  c2114
 L  c2115
 L  c2116
 L  c2117
 L  c2118
 L  c2119
 L  c2120
 L  c2121
 L  c2122
 L  c2123
 L  c2124
 L  c2125
 L  c2126
 L  c2127
 L  c2128
 L  c2129
 L  c2130
 L  c2131
 L  c2132
 L  c2133
 L  c2134
 L  c2135
 L  c2136
 L  c2137
 L  c2138
 L  c2139
 L  c2140
 L  c2141
 L  c2142
 L  c2143
 L  c2144
 L  c2145
 L  c2146
 L  c2147
 L  c2148
 L  c2149
 L  c2150
 L  c2151
 L  c2152
 L  c2153
 L  c2154
 L  c2155
 L  c2156
 L  c2157
 L  c2158
 L  c2159
 L  c2160
 L  c2161
 L  c2162
 L  c2163
 L  c2164
 L  c2165
 L  c2166
 L  c2167
 L  c2168
 L  c2169
 L  c2170
 L  c2171
 L  c2172
 L  c2173
 L  c2174
 L  c2175
 L  c2176
 L  c2177
 L  c2178
 L  c2179
 L  c2180
 L  c2181
 L  c2182
 L  c2183
 L  c2184
 L  c2185
 L  c2186
 L  c2187
 L  c2188
 L  c2189
 L  c2190
 L  c2191
 L  c2192
 L  c2193
 L  c2194
 L  c2195
 L  c2196
 L  c2197
 L  c2198
 L  c2199
 L  c2200
 L  c2201
 L  c2202
 L  c2203
 L  c2204
 L  c2205
 L  c2206
 L  c2207
 L  c2208
 L  c2209
 L  c2210
 L  c2211
 L  c2212
 L  c2213
 L  c2214
 L  c2215
 L  c2216
 L  c2217
 L  c2218
 L  c2219
 L  c2220
 L  c2221
 L  c2222
 L  c2223
 L  c2224
 L  c2225
 L  c2226
 L  c2227
 L  c2228
 L  c2229
 L  c2230
 L  c2231
 L  c2232
 L  c2233
 L  c2234
 L  c2235
 L  c2236
 L  c2237
 L  c2238
 L  c2239
 L  c2240
 L  c2241
 L  c2242
 L  c2243
 L  c2244
 L  c2245
 L  c2246
 L  c2247
 L  c2248
 L  c2249
 L  c2250
 L  c2251
 L  c2252
 L  c2253
 L  c2254
 L  c2255
 L  c2256
 L  c2257
 L  c2258
 L  c2259
 L  c2260
 L  c2261
 L  c2262
 L  c2263
 L  c2264
 L  c2265
 L  c2266
 L  c2267
 L  c2268
 L  c2269
 L  c2270
 L  c2271
 L  c2272
 L  c2273
 L  c2274
 L  c2275
 L  c2276
 L  c2277
 L  c2278
 L  c2279
 L  c2280
 L  c2281
 L  c2282
 L  c2283
 L  c2284
 L  c2285
 L  c2286
 L  c2287
 L  c2288
 L  c2289
 L  c2290
 L  c2291
 L  c2292
 L  c2293
 L  c2294
 L  c2295
 L  c2296
 L  c2297
 L  c2298
 L  c2299
 L  c2300
 L  c2301
 L  c2302
 L  c2303
 L  c2304
 L  c2305
 L  c2306
 L  c2307
 L  c2308
 L  c2309
 L  c2310
 L  c2311
 L  c2312
 L  c2313
 L  c2314
 L  c2315
 L  c2316
 L  c2317
 L  c2318
 L  c2319
 L  c2320
 L  c2321
 L  c2322
 L  c2323
 L  c2324
 L  c2325
 L  c2326
 L  c2327
 L  c2328
 L  c2329
 L  c2330
 L  c2331
 L  c2332
 L  c2333
 L  c2334
 L  c2335
 L  c2336
 L  c2337
 L  c2338
 L  c2339
 L  c2340
 L  c2341
 L  c2342
 L  c2343
 L  c2344
 L  c2345
 L  c2346
 L  c2347
 L  c2348
 L  c2349
 L  c2350
 L  c2351
 L  c2352
 L  c2353
 L  c2354
 L  c2355
 L  c2356
 L  c2357
 L  c2358
 L  c2359
 L  c2360
 L  c2361
 L  c2362
 L  c2363
 L  c2364
 L  c2365
 L  c2366
 L  c2367
 L  c2368
 L  c2369
 L  c2370
 L  c2371
 L  c2372
 L  c2373
 L  c2374
 L  c2375
 L  c2376
 L  c2377
 L  c2378
 L  c2379
 L  c2380
 L  c2381
 L  c2382
 L  c2383
 L  c2384
 L  c2385
 L  c2386
 L  c2387
 L  c2388
 L  c2389
 L  c2390
 L  c2391
 L  c2392
 L  c2393
 L  c2394
 L  c2395
 L  c2396
 L  c2397
 L  c2398
 L  c2399
 L  c2400
 L  c2401
 L  c2402
 L  c2403
 L  c2404
 L  c2405
 L  c2406
 L  c2407
 L  c2408
 L  c2409
 L  c2410
 L  c2411
 L  c2412
 L  c2413
 L  c2414
 L  c2415
 L  c2416
 L  c2417
 L  c2418
 L  c2419
 L  c2420
 L  c2421
 L  c2422
 L  c2423
 L  c2424
 L  c2425
 L  c2426
 L  c2427
 L  c2428
 L  c2429
 L  c2430
 L  c2431
 L  c2432
 L  c2433
 L  c2434
 L  c2435
 L  c2436
 L  c2437
 L  c2438
 L  c2439
 L  c2440
 L  c2441
 L  c2442
 L  c2443
 L  c2444
 L  c2445
 L  c2446
 L  c2447
 L  c2448
 L  c2449
 L  c2450
 L  c2451
 L  c2452
 L  c2453
 L  c2454
 L  c2455
 L  c2456
 L  c2457
 L  c2458
 L  c2459
 L  c2460
 L  c2461
 L  c2462
 L  c2463
 L  c2464
 L  c2465
 L  c2466
 L  c2467
 L  c2468
 L  c2469
 L  c2470
 L  c2471
 L  c2472
 L  c2473
 L  c2474
 L  c2475
 L  c2476
 L  c2477
 L  c2478
 L  c2479
 L  c2480
 L  c2481
 L  c2482
 L  c2483
 L  c2484
 L  c2485
 L  c2486
 L  c2487
 L  c2488
 L  c2489
 L  c2490
 L  c2491
 L  c2492
 L  c2493
 L  c2494
 L  c2495
 L  c2496
 L  c2497
 L  c2498
 L  c2499
 L  c2500
 L  c2501
 L  c2502
 L  c2503
 L  c2504
 L  c2505
 L  c2506
 L  c2507
 L  c2508
 L  c2509
 L  c2510
 L  c2511
 L  c2512
 L  c2513
 L  c2514
 L  c2515
 L  c2516
 L  c2517
 L  c2518
 L  c2519
 L  c2520
 L  c2521
 L  c2522
 L  c2523
 L  c2524
 L  c2525
 L  c2526
 L  c2527
 L  c2528
 L  c2529
 L  c2530
 L  c2531
 L  c2532
 L  c2533
 L  c2534
 L  c2535
 L  c2536
 L  c2537
 L  c2538
 L  c2539
 L  c2540
 L  c2541
 L  c2542
 L  c2543
 L  c2544
 L  c2545
 L  c2546
 L  c2547
 L  c2548
 L  c2549
 L  c2550
 L  c2551
 L  c2552
 L  c2553
 L  c2554
 L  c2555
 L  c2556
 L  c2557
 L  c2558
 L  c2559
 L  c2560
 L  c2561
 L  c2562
 L  c2563
 L  c2564
 L  c2565
 L  c2566
 L  c2567
 L  c2568
 L  c2569
 L  c2570
 L  c2571
 L  c2572
 L  c2573
 L  c2574
 L  c2575
 L  c2576
 L  c2577
 L  c2578
 L  c2579
 L  c2580
 L  c2581
 L  c2582
 L  c2583
 L  c2584
 L  c2585
 L  c2586
 L  c2587
 L  c2588
 L  c2589
 L  c2590
 L  c2591
 L  c2592
 L  c2593
 L  c2594
 L  c2595
 L  c2596
 L  c2597
 L  c2598
 L  c2599
 L  c2600
 L  c2601
 L  c2602
 L  c2603
 L  c2604
 L  c2605
 L  c2606
 L  c2607
 L  c2608
 L  c2609
 L  c2610
 L  c2611
 L  c2612
 L  c2613
 L  c2614
 L  c2615
 L  c2616
 L  c2617
 L  c2618
 L  c2619
 L  c2620
 L  c2621
 L  c2622
 L  c2623
 L  c2624
 L  c2625
 L  c2626
 L  c2627
 L  c2628
 L  c2629
 L  c2630
 L  c2631
 L  c2632
 L  c2633
 L  c2634
 L  c2635
 L  c2636
 L  c2637
 L  c2638
 L  c2639
 L  c2640
 L  c2641
 L  c2642
 L  c2643
 L  c2644
 L  c2645
 L  c2646
 L  c2647
 L  c2648
 L  c2649
 L  c2650
 L  c2651
 L  c2652
 L  c2653
 L  c2654
 L  c2655
 L  c2656
 L  c2657
 L  c2658
 L  c2659
 L  c2660
 L  c2661
 L  c2662
 L  c2663
 L  c2664
 L  c2665
 L  c2666
 L  c2667
 L  c2668
 L  c2669
 L  c2670
 L  c2671
 L  c2672
 L  c2673
 L  c2674
 L  c2675
 L  c2676
 L  c2677
 L  c2678
 L  c2679
 L  c2680
 L  c2681
 L  c2682
 L  c2683
 L  c2684
 L  c2685
 L  c2686
 L  c2687
 L  c2688
 L  c2689
 L  c2690
 L  c2691
 L  c2692
 L  c2693
 L  c2694
 L  c2695
 L  c2696
 L  c2697
 L  c2698
 L  c2699
 L  c2700
 L  c2701
 L  c2702
 L  c2703
 L  c2704
 L  c2705
 L  c2706
 L  c2707
 L  c2708
 L  c2709
 L  c2710
 L  c2711
 L  c2712
 L  c2713
 L  c2714
 L  c2715
 L  c2716
 L  c2717
 L  c2718
 L  c2719
 L  c2720
 L  c2721
 L  c2722
 L  c2723
 L  c2724
 L  c2725
 L  c2726
 L  c2727
 L  c2728
 L  c2729
 L  c2730
 L  c2731
 L  c2732
 L  c2733
 L  c2734
 L  c2735
 L  c2736
 L  c2737
 L  c2738
 L  c2739
 L  c2740
 L  c2741
 L  c2742
 L  c2743
 L  c2744
 L  c2745
 L  c2746
 L  c2747
 L  c2748
 L  c2749
 L  c2750
 L  c2751
 L  c2752
 L  c2753
 L  c2754
 L  c2755
 L  c2756
 L  c2757
 L  c2758
 L  c2759
 L  c2760
 L  c2761
 L  c2762
 L  c2763
 L  c2764
 L  c2765
 L  c2766
 L  c2767
 L  c2768
 L  c2769
 L  c2770
 L  c2771
 L  c2772
 L  c2773
 L  c2774
 L  c2775
 L  c2776
 L  c2777
 L  c2778
 L  c2779
 L  c2780
 L  c2781
 L  c2782
 L  c2783
 L  c2784
 L  c2785
 L  c2786
 L  c2787
 L  c2788
 L  c2789
 L  c2790
 L  c2791
 L  c2792
 L  c2793
 L  c2794
 L  c2795
 L  c2796
 L  c2797
 L  c2798
 L  c2799
 L  c2800
 L  c2801
 L  c2802
 L  c2803
 L  c2804
 L  c2805
 L  c2806
 L  c2807
 L  c2808
 L  c2809
 L  c2810
 L  c2811
 L  c2812
 L  c2813
 L  c2814
 L  c2815
 L  c2816
 L  c2817
 L  c2818
 L  c2819
 L  c2820
 L  c2821
 L  c2822
 L  c2823
 L  c2824
 L  c2825
 L  c2826
 L  c2827
 L  c2828
 L  c2829
 L  c2830
 L  c2831
 L  c2832
 L  c2833
 L  c2834
 L  c2835
 L  c2836
 L  c2837
 L  c2838
 L  c2839
 L  c2840
 L  c2841
 L  c2842
 L  c2843
 L  c2844
 L  c2845
 L  c2846
 L  c2847
 L  c2848
 L  c2849
 L  c2850
 L  c2851
 L  c2852
 L  c2853
 L  c2854
 L  c2855
 L  c2856
 L  c2857
 L  c2858
 L  c2859
 L  c2860
 L  c2861
 L  c2862
 L  c2863
 L  c2864
 L  c2865
 L  c2866
 L  c2867
 L  c2868
 L  c2869
 L  c2870
 L  c2871
 L  c2872
 L  c2873
 L  c2874
 L  c2875
 L  c2876
 L  c2877
 L  c2878
 L  c2879
 L  c2880
 L  c2881
 L  c2882
 L  c2883
 L  c2884
 L  c2885
 L  c2886
 L  c2887
 L  c2888
 L  c2889
 L  c2890
 L  c2891
 L  c2892
 L  c2893
 L  c2894
 L  c2895
 L  c2896
 L  c2897
 L  c2898
 L  c2899
 L  c2900
 L  c2901
 L  c2902
 L  c2903
 L  c2904
 L  c2905
 L  c2906
 L  c2907
 L  c2908
 L  c2909
 L  c2910
 L  c2911
 L  c2912
 L  c2913
 L  c2914
 L  c2915
 L  c2916
 L  c2917
 L  c2918
 L  c2919
 L  c2920
 L  c2921
 L  c2922
 L  c2923
 L  c2924
 L  c2925
 L  c2926
 L  c2927
 L  c2928
 L  c2929
 L  c2930
 L  c2931
 L  c2932
 L  c2933
 L  c2934
 L  c2935
 L  c2936
 L  c2937
 L  c2938
 L  c2939
 L  c2940
 L  c2941
 L  c2942
 L  c2943
 L  c2944
 L  c2945
 L  c2946
 L  c2947
 L  c2948
 L  c2949
 L  c2950
 L  c2951
 L  c2952
 L  c2953
 L  c2954
 L  c2955
 L  c2956
 L  c2957
 L  c2958
 L  c2959
 L  c2960
 L  c2961
 L  c2962
 L  c2963
 L  c2964
 L  c2965
 L  c2966
 L  c2967
 L  c2968
 L  c2969
 L  c2970
 L  c2971
 L  c2972
 L  c2973
 L  c2974
 L  c2975
 L  c2976
 L  c2977
 L  c2978
 L  c2979
 L  c2980
 L  c2981
 L  c2982
 L  c2983
 L  c2984
 L  c2985
 L  c2986
 L  c2987
 L  c2988
 L  c2989
 L  c2990
 L  c2991
 L  c2992
 L  c2993
 L  c2994
 L  c2995
 L  c2996
 L  c2997
 L  c2998
 L  c2999
 L  c3000
 L  c3001
 L  c3002
 L  c3003
 L  c3004
 L  c3005
 L  c3006
 L  c3007
 L  c3008
 L  c3009
 L  c3010
 L  c3011
 L  c3012
 L  c3013
 L  c3014
 L  c3015
 L  c3016
 L  c3017
 L  c3018
 L  c3019
 L  c3020
 L  c3021
 L  c3022
 L  c3023
 L  c3024
 L  c3025
 L  c3026
 L  c3027
 L  c3028
 L  c3029
 L  c3030
 L  c3031
 L  c3032
 L  c3033
 L  c3034
 L  c3035
 L  c3036
 L  c3037
 L  c3038
 L  c3039
 L  c3040
 L  c3041
 L  c3042
 L  c3043
 L  c3044
 L  c3045
 L  c3046
 L  c3047
 L  c3048
 L  c3049
 L  c3050
 L  c3051
 L  c3052
 L  c3053
 L  c3054
 L  c3055
 L  c3056
 L  c3057
 L  c3058
 L  c3059
 L  c3060
 L  c3061
 L  c3062
 L  c3063
 L  c3064
 L  c3065
 L  c3066
 L  c3067
 L  c3068
 L  c3069
 L  c3070
 L  c3071
 L  c3072
 L  c3073
 L  c3074
 L  c3075
 L  c3076
 L  c3077
 L  c3078
 L  c3079
 L  c3080
 L  c3081
 L  c3082
 L  c3083
 L  c3084
 L  c3085
 L  c3086
 L  c3087
 L  c3088
 L  c3089
 L  c3090
 L  c3091
 L  c3092
 L  c3093
 L  c3094
 L  c3095
 L  c3096
 L  c3097
 L  c3098
 L  c3099
 L  c3100
 L  c3101
 L  c3102
 L  c3103
 L  c3104
 L  c3105
 L  c3106
 L  c3107
 L  c3108
 L  c3109
 L  c3110
 L  c3111
 L  c3112
 L  c3113
 L  c3114
 L  c3115
 L  c3116
 L  c3117
 L  c3118
 L  c3119
 L  c3120
 L  c3121
 L  c3122
 L  c3123
 L  c3124
 L  c3125
 L  c3126
 L  c3127
 L  c3128
 L  c3129
 L  c3130
 L  c3131
 L  c3132
 L  c3133
 L  c3134
 L  c3135
 L  c3136
 L  c3137
 L  c3138
 L  c3139
 L  c3140
 L  c3141
 L  c3142
 L  c3143
 L  c3144
 L  c3145
 L  c3146
 L  c3147
 L  c3148
 L  c3149
 L  c3150
 L  c3151
 L  c3152
 L  c3153
 L  c3154
 L  c3155
 L  c3156
 L  c3157
 L  c3158
 L  c3159
 L  c3160
 L  c3161
 L  c3162
 L  c3163
 L  c3164
 L  c3165
 L  c3166
 L  c3167
 L  c3168
 L  c3169
 L  c3170
 L  c3171
 L  c3172
 L  c3173
 L  c3174
 L  c3175
 L  c3176
 L  c3177
 L  c3178
 L  c3179
 L  c3180
 L  c3181
 L  c3182
 L  c3183
 L  c3184
 L  c3185
 L  c3186
 L  c3187
 L  c3188
 L  c3189
 L  c3190
 L  c3191
 L  c3192
 L  c3193
 L  c3194
 L  c3195
 L  c3196
 L  c3197
 L  c3198
 L  c3199
 L  c3200
 L  c3201
 L  c3202
 L  c3203
 L  c3204
 L  c3205
 L  c3206
 L  c3207
 L  c3208
 L  c3209
 L  c3210
 L  c3211
 L  c3212
 L  c3213
 L  c3214
 L  c3215
 L  c3216
 L  c3217
 L  c3218
 L  c3219
 L  c3220
 L  c3221
 L  c3222
 L  c3223
 L  c3224
 L  c3225
 L  c3226
 L  c3227
 L  c3228
 L  c3229
 L  c3230
 L  c3231
 L  c3232
 L  c3233
 L  c3234
 L  c3235
 L  c3236
 L  c3237
 L  c3238
 L  c3239
 L  c3240
 L  c3241
 L  c3242
 L  c3243
 L  c3244
 L  c3245
 L  c3246
 L  c3247
 L  c3248
 L  c3249
 L  c3250
 L  c3251
 L  c3252
 L  c3253
 L  c3254
 L  c3255
 L  c3256
 L  c3257
 L  c3258
 L  c3259
 L  c3260
 L  c3261
 L  c3262
 L  c3263
 L  c3264
 L  c3265
 L  c3266
 L  c3267
 L  c3268
 L  c3269
 L  c3270
 L  c3271
 L  c3272
 L  c3273
 L  c3274
 L  c3275
 L  c3276
 L  c3277
 L  c3278
 L  c3279
 L  c3280
 L  c3281
 L  c3282
 L  c3283
 L  c3284
 L  c3285
 L  c3286
 L  c3287
 L  c3288
 L  c3289
 L  c3290
 L  c3291
 L  c3292
 L  c3293
 L  c3294
 L  c3295
 L  c3296
 L  c3297
 L  c3298
 L  c3299
 L  c3300
 L  c3301
 L  c3302
 L  c3303
 L  c3304
 L  c3305
 L  c3306
 L  c3307
 L  c3308
 L  c3309
 L  c3310
 L  c3311
 L  c3312
 L  c3313
 L  c3314
 L  c3315
 L  c3316
 L  c3317
 L  c3318
 L  c3319
 L  c3320
 L  c3321
 L  c3322
 L  c3323
 L  c3324
 L  c3325
 L  c3326
 L  c3327
 L  c3328
 L  c3329
 L  c3330
 L  c3331
 L  c3332
 L  c3333
 L  c3334
 L  c3335
 L  c3336
 L  c3337
 L  c3338
 L  c3339
 L  c3340
 L  c3341
 L  c3342
 L  c3343
 L  c3344
 L  c3345
 L  c3346
 L  c3347
 L  c3348
 L  c3349
 L  c3350
 L  c3351
 L  c3352
 L  c3353
 L  c3354
 L  c3355
 L  c3356
 L  c3357
 L  c3358
 L  c3359
 L  c3360
 L  c3361
 L  c3362
 L  c3363
 L  c3364
 L  c3365
 L  c3366
 L  c3367
 L  c3368
 L  c3369
 L  c3370
 L  c3371
 L  c3372
 L  c3373
 L  c3374
 L  c3375
 L  c3376
 L  c3377
 L  c3378
 L  c3379
 L  c3380
 L  c3381
 L  c3382
 L  c3383
 L  c3384
 L  c3385
 L  c3386
 L  c3387
 L  c3388
 L  c3389
 L  c3390
 L  c3391
 L  c3392
 L  c3393
 L  c3394
 L  c3395
 L  c3396
 L  c3397
 L  c3398
 L  c3399
 L  c3400
 L  c3401
 L  c3402
 L  c3403
 L  c3404
 L  c3405
 L  c3406
 L  c3407
 L  c3408
 L  c3409
 L  c3410
 L  c3411
 L  c3412
 L  c3413
 L  c3414
 L  c3415
 L  c3416
 L  c3417
 L  c3418
 L  c3419
 L  c3420
 L  c3421
 L  c3422
 L  c3423
 L  c3424
 L  c3425
 L  c3426
 L  c3427
 L  c3428
 L  c3429
 L  c3430
 L  c3431
 L  c3432
 L  c3433
 L  c3434
 L  c3435
 L  c3436
 L  c3437
 L  c3438
 L  c3439
 L  c3440
 L  c3441
 L  c3442
 L  c3443
 L  c3444
 L  c3445
 L  c3446
 L  c3447
 L  c3448
 L  c3449
 L  c3450
 L  c3451
 L  c3452
 L  c3453
 L  c3454
 L  c3455
 L  c3456
 L  c3457
 L  c3458
 L  c3459
 L  c3460
 L  c3461
 L  c3462
 L  c3463
 L  c3464
 L  c3465
 L  c3466
 L  c3467
 L  c3468
 L  c3469
 L  c3470
 L  c3471
 L  c3472
 L  c3473
 L  c3474
 L  c3475
 L  c3476
 L  c3477
 L  c3478
 L  c3479
 L  c3480
 L  c3481
 L  c3482
 L  c3483
 L  c3484
 L  c3485
 L  c3486
 L  c3487
 L  c3488
 L  c3489
 L  c3490
 L  c3491
 L  c3492
 L  c3493
 L  c3494
 L  c3495
 L  c3496
 L  c3497
 L  c3498
 L  c3499
 L  c3500
 L  c3501
 L  c3502
 L  c3503
 L  c3504
 L  c3505
 L  c3506
 L  c3507
 L  c3508
 L  c3509
 L  c3510
 L  c3511
 L  c3512
 L  c3513
 L  c3514
 L  c3515
 L  c3516
 L  c3517
 L  c3518
 L  c3519
 L  c3520
 L  c3521
 L  c3522
 L  c3523
 L  c3524
 L  c3525
 L  c3526
 L  c3527
 L  c3528
 L  c3529
 L  c3530
 L  c3531
 L  c3532
 L  c3533
 L  c3534
 L  c3535
 L  c3536
 L  c3537
 L  c3538
 L  c3539
 L  c3540
 L  c3541
 L  c3542
 L  c3543
 L  c3544
 L  c3545
 L  c3546
 L  c3547
 L  c3548
 L  c3549
 L  c3550
 L  c3551
 L  c3552
 L  c3553
 L  c3554
 L  c3555
 L  c3556
 L  c3557
 L  c3558
 L  c3559
 L  c3560
 L  c3561
 L  c3562
 L  c3563
 L  c3564
 L  c3565
 L  c3566
 L  c3567
 L  c3568
 L  c3569
 L  c3570
 L  c3571
 L  c3572
 L  c3573
 L  c3574
 L  c3575
 L  c3576
 L  c3577
 L  c3578
 L  c3579
 L  c3580
 L  c3581
 L  c3582
 L  c3583
 L  c3584
 L  c3585
 L  c3586
 L  c3587
 L  c3588
 L  c3589
 L  c3590
 L  c3591
 L  c3592
 L  c3593
 L  c3594
 L  c3595
 L  c3596
 L  c3597
 L  c3598
 L  c3599
 L  c3600
 L  c3601
 L  c3602
 L  c3603
 L  c3604
 L  c3605
 L  c3606
 L  c3607
 L  c3608
 L  c3609
 L  c3610
 L  c3611
 L  c3612
 L  c3613
 L  c3614
 L  c3615
 L  c3616
 L  c3617
 L  c3618
 L  c3619
 L  c3620
 L  c3621
 L  c3622
 L  c3623
 L  c3624
 L  c3625
 L  c3626
 L  c3627
 L  c3628
 L  c3629
 L  c3630
 L  c3631
 L  c3632
 L  c3633
 L  c3634
 L  c3635
 L  c3636
 L  c3637
 L  c3638
 L  c3639
 L  c3640
 L  c3641
 L  c3642
 L  c3643
 L  c3644
 L  c3645
 L  c3646
 L  c3647
 L  c3648
 L  c3649
 L  c3650
 L  c3651
 L  c3652
 L  c3653
 L  c3654
 L  c3655
 L  c3656
 L  c3657
 L  c3658
 L  c3659
 L  c3660
 L  c3661
 L  c3662
 L  c3663
 L  c3664
 L  c3665
 L  c3666
 L  c3667
 L  c3668
 L  c3669
 L  c3670
 L  c3671
 L  c3672
 L  c3673
 L  c3674
 L  c3675
 L  c3676
 L  c3677
 L  c3678
 L  c3679
 L  c3680
 L  c3681
 L  c3682
 L  c3683
 L  c3684
 L  c3685
 L  c3686
 L  c3687
 L  c3688
 L  c3689
 L  c3690
 L  c3691
 L  c3692
 L  c3693
 L  c3694
 L  c3695
 L  c3696
 L  c3697
 L  c3698
 L  c3699
 L  c3700
 L  c3701
 L  c3702
 L  c3703
 L  c3704
 L  c3705
 L  c3706
 L  c3707
 L  c3708
 L  c3709
 L  c3710
 L  c3711
 L  c3712
 L  c3713
 L  c3714
 L  c3715
 L  c3716
 L  c3717
 L  c3718
 L  c3719
 L  c3720
 L  c3721
 L  c3722
 L  c3723
 L  c3724
 L  c3725
 L  c3726
 L  c3727
 L  c3728
 L  c3729
 L  c3730
 L  c3731
 L  c3732
 L  c3733
 L  c3734
 L  c3735
 L  c3736
 L  c3737
 L  c3738
 L  c3739
 L  c3740
 L  c3741
 L  c3742
 L  c3743
 L  c3744
 L  c3745
 L  c3746
 L  c3747
 L  c3748
 L  c3749
 L  c3750
 L  c3751
 L  c3752
 L  c3753
 L  c3754
 L  c3755
 L  c3756
 L  c3757
 L  c3758
 L  c3759
 L  c3760
 L  c3761
 L  c3762
 L  c3763
 L  c3764
 L  c3765
 L  c3766
 L  c3767
 L  c3768
 L  c3769
 L  c3770
 L  c3771
 L  c3772
 L  c3773
 L  c3774
 L  c3775
 L  c3776
 L  c3777
 L  c3778
 L  c3779
 L  c3780
 L  c3781
 L  c3782
 L  c3783
 L  c3784
 L  c3785
 L  c3786
 L  c3787
 L  c3788
 L  c3789
 L  c3790
 L  c3791
 L  c3792
 L  c3793
 L  c3794
 L  c3795
 L  c3796
 L  c3797
 L  c3798
 L  c3799
 L  c3800
 L  c3801
 L  c3802
 L  c3803
 L  c3804
 L  c3805
 L  c3806
 L  c3807
 L  c3808
 L  c3809
 L  c3810
 L  c3811
 L  c3812
 L  c3813
 L  c3814
 L  c3815
 L  c3816
 L  c3817
 L  c3818
 L  c3819
 L  c3820
 L  c3821
 L  c3822
 L  c3823
 L  c3824
 L  c3825
 L  c3826
 L  c3827
 L  c3828
 L  c3829
 L  c3830
 L  c3831
 L  c3832
 L  c3833
 L  c3834
 L  c3835
 L  c3836
 L  c3837
 L  c3838
 L  c3839
 L  c3840
 L  c3841
 L  c3842
 L  c3843
 L  c3844
 L  c3845
 L  c3846
 L  c3847
 L  c3848
 L  c3849
 L  c3850
 L  c3851
 L  c3852
 L  c3853
 L  c3854
 L  c3855
 L  c3856
 L  c3857
 L  c3858
 L  c3859
 L  c3860
 L  c3861
 L  c3862
 L  c3863
 L  c3864
 L  c3865
 L  c3866
 L  c3867
 L  c3868
 L  c3869
 L  c3870
 L  c3871
 L  c3872
 L  c3873
 L  c3874
 L  c3875
 L  c3876
 L  c3877
 L  c3878
 L  c3879
 L  c3880
 L  c3881
 L  c3882
 L  c3883
 L  c3884
 L  c3885
 L  c3886
 L  c3887
 L  c3888
 L  c3889
 L  c3890
 L  c3891
 L  c3892
 L  c3893
 L  c3894
 L  c3895
 L  c3896
 L  c3897
 L  c3898
 L  c3899
 L  c3900
 L  c3901
 L  c3902
 L  c3903
 L  c3904
 L  c3905
 L  c3906
 L  c3907
 L  c3908
 L  c3909
 L  c3910
 L  c3911
 L  c3912
 L  c3913
 L  c3914
 L  c3915
 L  c3916
 L  c3917
 L  c3918
 L  c3919
 L  c3920
 L  c3921
 L  c3922
 L  c3923
 L  c3924
 L  c3925
 L  c3926
 L  c3927
 L  c3928
 L  c3929
 L  c3930
 L  c3931
 L  c3932
 L  c3933
 L  c3934
 L  c3935
 L  c3936
 L  c3937
 L  c3938
 L  c3939
 L  c3940
 L  c3941
 L  c3942
 L  c3943
 L  c3944
 L  c3945
 L  c3946
 L  c3947
 L  c3948
 L  c3949
 L  c3950
 L  c3951
 L  c3952
 L  c3953
 L  c3954
 L  c3955
 L  c3956
 L  c3957
 L  c3958
 L  c3959
 L  c3960
 L  c3961
 L  c3962
 L  c3963
 L  c3964
 L  c3965
 L  c3966
 L  c3967
 L  c3968
 L  c3969
 L  c3970
 L  c3971
 L  c3972
 L  c3973
 L  c3974
 L  c3975
 L  c3976
 L  c3977
 L  c3978
 L  c3979
 L  c3980
 L  c3981
 L  c3982
 L  c3983
 L  c3984
 L  c3985
 L  c3986
 L  c3987
 L  c3988
 L  c3989
 L  c3990
 L  c3991
 L  c3992
 L  c3993
 L  c3994
 L  c3995
 L  c3996
 L  c3997
 L  c3998
 L  c3999
 L  c4000
 L  c4001
 L  c4002
 L  c4003
 L  c4004
 L  c4005
 L  c4006
 L  c4007
 L  c4008
 L  c4009
 L  c4010
 L  c4011
 L  c4012
 L  c4013
 L  c4014
 L  c4015
 L  c4016
 L  c4017
 L  c4018
 L  c4019
 L  c4020
 L  c4021
 L  c4022
 L  c4023
 L  c4024
 L  c4025
 L  c4026
 L  c4027
 L  c4028
 L  c4029
 L  c4030
 L  c4031
 L  c4032
 L  c4033
 L  c4034
 L  c4035
 L  c4036
 L  c4037
 L  c4038
 L  c4039
 L  c4040
 L  c4041
 L  c4042
 L  c4043
 L  c4044
 L  c4045
 L  c4046
 L  c4047
 L  c4048
 L  c4049
 L  c4050
 L  c4051
 L  c4052
 L  c4053
 L  c4054
 L  c4055
 L  c4056
 L  c4057
 L  c4058
 L  c4059
 L  c4060
 L  c4061
 L  c4062
 L  c4063
 L  c4064
 L  c4065
 L  c4066
 L  c4067
 L  c4068
 L  c4069
 L  c4070
 L  c4071
 L  c4072
 L  c4073
 L  c4074
 L  c4075
 L  c4076
 L  c4077
 L  c4078
 L  c4079
 L  c4080
 L  c4081
 L  c4082
 L  c4083
 L  c4084
 L  c4085
 L  c4086
 L  c4087
 L  c4088
 L  c4089
 L  c4090
 L  c4091
 L  c4092
 L  c4093
 L  c4094
 L  c4095
 L  c4096
 L  c4097
 L  c4098
 L  c4099
 L  c4100
 L  c4101
 L  c4102
 L  c4103
 L  c4104
 L  c4105
 L  c4106
 L  c4107
 L  c4108
 L  c4109
 L  c4110
 L  c4111
 L  c4112
 L  c4113
 L  c4114
 L  c4115
 L  c4116
 L  c4117
 L  c4118
 L  c4119
 L  c4120
 L  c4121
 L  c4122
 L  c4123
 L  c4124
 L  c4125
 L  c4126
 L  c4127
 L  c4128
 L  c4129
 L  c4130
 L  c4131
 L  c4132
 L  c4133
 L  c4134
 L  c4135
 L  c4136
 L  c4137
 L  c4138
 L  c4139
 L  c4140
 L  c4141
 L  c4142
 L  c4143
 L  c4144
 L  c4145
 L  c4146
 L  c4147
 L  c4148
 L  c4149
 L  c4150
 L  c4151
 L  c4152
 L  c4153
 L  c4154
 L  c4155
 L  c4156
 L  c4157
 L  c4158
 L  c4159
 L  c4160
 L  c4161
 L  c4162
 L  c4163
 L  c4164
 L  c4165
 L  c4166
 L  c4167
 L  c4168
 L  c4169
 L  c4170
 L  c4171
 L  c4172
 L  c4173
 L  c4174
 L  c4175
 L  c4176
 L  c4177
 L  c4178
 L  c4179
 L  c4180
 L  c4181
 L  c4182
 L  c4183
 L  c4184
 L  c4185
 L  c4186
 L  c4187
 L  c4188
 L  c4189
 L  c4190
 L  c4191
 L  c4192
 L  c4193
 L  c4194
 L  c4195
 L  c4196
 L  c4197
 L  c4198
 L  c4199
 L  c4200
 L  c4201
 L  c4202
 L  c4203
 L  c4204
 L  c4205
 L  c4206
 L  c4207
 L  c4208
 L  c4209
 L  c4210
 L  c4211
 L  c4212
 L  c4213
 L  c4214
 L  c4215
 L  c4216
 L  c4217
 L  c4218
 L  c4219
 L  c4220
 L  c4221
 L  c4222
 L  c4223
 L  c4224
 L  c4225
 L  c4226
 L  c4227
 L  c4228
 L  c4229
 L  c4230
 L  c4231
 L  c4232
 L  c4233
 L  c4234
 L  c4235
 L  c4236
 L  c4237
 L  c4238
 L  c4239
 L  c4240
 L  c4241
 L  c4242
 L  c4243
 L  c4244
 L  c4245
 L  c4246
 L  c4247
 L  c4248
 L  c4249
 L  c4250
 L  c4251
 L  c4252
 L  c4253
 L  c4254
 L  c4255
 L  c4256
 L  c4257
 L  c4258
 L  c4259
 L  c4260
 L  c4261
 L  c4262
 L  c4263
 L  c4264
 L  c4265
 L  c4266
 L  c4267
 L  c4268
 L  c4269
 L  c4270
 L  c4271
 L  c4272
 L  c4273
 L  c4274
 L  c4275
 L  c4276
 L  c4277
 L  c4278
 L  c4279
 L  c4280
 L  c4281
 L  c4282
 L  c4283
 L  c4284
 L  c4285
 L  c4286
 L  c4287
 L  c4288
 L  c4289
 L  c4290
 L  c4291
 L  c4292
 L  c4293
 L  c4294
 L  c4295
 L  c4296
 L  c4297
 L  c4298
 L  c4299
 L  c4300
 L  c4301
 L  c4302
 L  c4303
 L  c4304
 L  c4305
 L  c4306
 L  c4307
 L  c4308
 L  c4309
 L  c4310
 L  c4311
 L  c4312
 L  c4313
 L  c4314
 L  c4315
 L  c4316
 L  c4317
 L  c4318
 L  c4319
 L  c4320
 L  c4321
 L  c4322
 L  c4323
 L  c4324
 L  c4325
 L  c4326
 L  c4327
 L  c4328
 L  c4329
 L  c4330
 L  c4331
 L  c4332
 L  c4333
 L  c4334
 L  c4335
 L  c4336
 L  c4337
 L  c4338
 L  c4339
 L  c4340
 L  c4341
 L  c4342
 L  c4343
 L  c4344
 L  c4345
 L  c4346
 L  c4347
 L  c4348
 L  c4349
 L  c4350
 L  c4351
 L  c4352
 L  c4353
 L  c4354
 L  c4355
 L  c4356
 L  c4357
 L  c4358
 L  c4359
 L  c4360
 L  c4361
 L  c4362
 L  c4363
 L  c4364
 L  c4365
 L  c4366
 L  c4367
 L  c4368
 L  c4369
 L  c4370
 L  c4371
 L  c4372
 L  c4373
 L  c4374
 L  c4375
 L  c4376
 L  c4377
 L  c4378
 L  c4379
 L  c4380
 L  c4381
 L  c4382
 L  c4383
 L  c4384
 L  c4385
 L  c4386
 L  c4387
 L  c4388
 L  c4389
 L  c4390
 L  c4391
 L  c4392
 L  c4393
 L  c4394
 L  c4395
 L  c4396
 L  c4397
 L  c4398
 L  c4399
 L  c4400
 L  c4401
 L  c4402
 L  c4403
 L  c4404
 L  c4405
 L  c4406
 L  c4407
 L  c4408
 L  c4409
 L  c4410
 L  c4411
 L  c4412
 L  c4413
 L  c4414
 L  c4415
 L  c4416
 L  c4417
 L  c4418
 L  c4419
 L  c4420
 L  c4421
 L  c4422
 L  c4423
 L  c4424
 L  c4425
 L  c4426
 L  c4427
 L  c4428
 L  c4429
 L  c4430
 L  c4431
 L  c4432
 L  c4433
 L  c4434
 L  c4435
 L  c4436
 L  c4437
 L  c4438
 L  c4439
 L  c4440
 L  c4441
 L  c4442
 L  c4443
 L  c4444
 L  c4445
 L  c4446
 L  c4447
 L  c4448
 L  c4449
 L  c4450
 L  c4451
 L  c4452
 L  c4453
 L  c4454
 L  c4455
 L  c4456
 L  c4457
 L  c4458
 L  c4459
 L  c4460
 L  c4461
 L  c4462
 L  c4463
 L  c4464
 L  c4465
 L  c4466
 L  c4467
 L  c4468
 L  c4469
 L  c4470
 L  c4471
 L  c4472
 L  c4473
 L  c4474
 L  c4475
 L  c4476
 L  c4477
 L  c4478
 L  c4479
 L  c4480
 L  c4481
 L  c4482
 L  c4483
 L  c4484
 L  c4485
 L  c4486
 L  c4487
 L  c4488
 L  c4489
 L  c4490
 L  c4491
 L  c4492
 L  c4493
 L  c4494
 L  c4495
 L  c4496
 L  c4497
 L  c4498
 L  c4499
 L  c4500
 L  c4501
 L  c4502
 L  c4503
 L  c4504
 L  c4505
 L  c4506
 L  c4507
 L  c4508
 L  c4509
 L  c4510
 L  c4511
 L  c4512
 L  c4513
 L  c4514
 L  c4515
 L  c4516
 L  c4517
 L  c4518
 L  c4519
 L  c4520
 L  c4521
 L  c4522
 L  c4523
 L  c4524
 L  c4525
 L  c4526
 L  c4527
 L  c4528
 L  c4529
 L  c4530
 L  c4531
 L  c4532
 L  c4533
 L  c4534
 L  c4535
 L  c4536
 L  c4537
 L  c4538
 L  c4539
 L  c4540
 L  c4541
 L  c4542
 L  c4543
 L  c4544
 L  c4545
 L  c4546
 L  c4547
 L  c4548
 L  c4549
 L  c4550
 L  c4551
 L  c4552
 L  c4553
 L  c4554
 L  c4555
 L  c4556
 L  c4557
 L  c4558
 L  c4559
 L  c4560
 L  c4561
 L  c4562
 L  c4563
 L  c4564
 L  c4565
 L  c4566
 L  c4567
 L  c4568
 L  c4569
 L  c4570
 L  c4571
 L  c4572
 L  c4573
 L  c4574
 L  c4575
 L  c4576
 L  c4577
 L  c4578
 L  c4579
 L  c4580
 L  c4581
 L  c4582
 L  c4583
 L  c4584
 L  c4585
 L  c4586
 L  c4587
 L  c4588
 L  c4589
 L  c4590
 L  c4591
 L  c4592
 L  c4593
 L  c4594
 L  c4595
 L  c4596
 L  c4597
 L  c4598
 L  c4599
 L  c4600
 L  c4601
 L  c4602
 L  c4603
 L  c4604
 L  c4605
 L  c4606
 L  c4607
 L  c4608
 L  c4609
 L  c4610
 L  c4611
 L  c4612
 L  c4613
 L  c4614
 L  c4615
 L  c4616
 L  c4617
 L  c4618
 L  c4619
 L  c4620
 L  c4621
 L  c4622
 L  c4623
 L  c4624
 L  c4625
 L  c4626
 L  c4627
 L  c4628
 L  c4629
 L  c4630
 L  c4631
 L  c4632
 L  c4633
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1]      c1        1
    x[1]      c106      1
    x[1]      c107      1
    x[1]      c108      1
    x[1]      OBJ       -1
    x[2]      c2        1
    x[2]      c389      1
    x[2]      c390      1
    x[2]      c391      1
    x[2]      OBJ       -1
    x[3]      c3        1
    x[3]      c672      1
    x[3]      c673      1
    x[3]      c674      1
    x[3]      OBJ       -1
    x[4]      c4        1
    x[4]      c955      1
    x[4]      c956      1
    x[4]      c957      1
    x[4]      OBJ       -1
    x[5]      c5        1
    x[5]      c1238     1
    x[5]      c1239     1
    x[5]      c1240     1
    x[5]      OBJ       -1
    x[6]      c6        1
    x[6]      c1521     1
    x[6]      c1522     1
    x[6]      c1523     1
    x[6]      OBJ       -1
    x[7]      c7        1
    x[7]      c1804     1
    x[7]      c1805     1
    x[7]      c1806     1
    x[7]      OBJ       -1
    x[8]      c8        1
    x[8]      c2087     1
    x[8]      c2088     1
    x[8]      c2089     1
    x[8]      OBJ       -1
    x[9]      c9        1
    x[9]      c2370     1
    x[9]      c2371     1
    x[9]      c2372     1
    x[9]      OBJ       -1
    x[10]     c10       1
    x[10]     c2653     1
    x[10]     c2654     1
    x[10]     c2655     1
    x[10]     OBJ       -1
    x[11]     c11       1
    x[11]     c2936     1
    x[11]     c2937     1
    x[11]     c2938     1
    x[11]     OBJ       -1
    x[12]     c12       1
    x[12]     c3219     1
    x[12]     c3220     1
    x[12]     c3221     1
    x[12]     OBJ       -1
    x[13]     c13       1
    x[13]     c3502     1
    x[13]     c3503     1
    x[13]     c3504     1
    x[13]     OBJ       -1
    x[14]     c14       1
    x[14]     c3785     1
    x[14]     c3786     1
    x[14]     c3787     1
    x[14]     OBJ       -1
    x[15]     c15       1
    x[15]     c4068     1
    x[15]     c4069     1
    x[15]     c4070     1
    x[15]     OBJ       -1
    x[16]     c16       1
    x[16]     c4351     1
    x[16]     c4352     1
    x[16]     c4353     1
    x[16]     OBJ       -1
    x[17]     c1        1
    x[17]     c109      1
    x[17]     c110      1
    x[17]     OBJ       -1
    x[18]     c2        1
    x[18]     c392      1
    x[18]     c393      1
    x[18]     OBJ       -1
    x[19]     c3        1
    x[19]     c675      1
    x[19]     c676      1
    x[19]     OBJ       -1
    x[20]     c4        1
    x[20]     c958      1
    x[20]     c959      1
    x[20]     OBJ       -1
    x[21]     c5        1
    x[21]     c1241     1
    x[21]     c1242     1
    x[21]     OBJ       -1
    x[22]     c6        1
    x[22]     c1524     1
    x[22]     c1525     1
    x[22]     OBJ       -1
    x[23]     c7        1
    x[23]     c1807     1
    x[23]     c1808     1
    x[23]     OBJ       -1
    x[24]     c8        1
    x[24]     c2090     1
    x[24]     c2091     1
    x[24]     OBJ       -1
    x[25]     c9        1
    x[25]     c2373     1
    x[25]     c2374     1
    x[25]     OBJ       -1
    x[26]     c10       1
    x[26]     c2656     1
    x[26]     c2657     1
    x[26]     OBJ       -1
    x[27]     c11       1
    x[27]     c2939     1
    x[27]     c2940     1
    x[27]     OBJ       -1
    x[28]     c12       1
    x[28]     c3222     1
    x[28]     c3223     1
    x[28]     OBJ       -1
    x[29]     c13       1
    x[29]     c3505     1
    x[29]     c3506     1
    x[29]     OBJ       -1
    x[30]     c14       1
    x[30]     c3788     1
    x[30]     c3789     1
    x[30]     OBJ       -1
    x[31]     c15       1
    x[31]     c4071     1
    x[31]     c4072     1
    x[31]     OBJ       -1
    x[32]     c16       1
    x[32]     c4354     1
    x[32]     c4355     1
    x[32]     OBJ       -1
    x[33]     c1        1
    x[33]     c111      1
    x[33]     OBJ       -1
    x[34]     c2        1
    x[34]     c394      1
    x[34]     OBJ       -1
    x[35]     c3        1
    x[35]     c677      1
    x[35]     OBJ       -1
    x[36]     c4        1
    x[36]     c960      1
    x[36]     OBJ       -1
    x[37]     c5        1
    x[37]     c1243     1
    x[37]     OBJ       -1
    x[38]     c6        1
    x[38]     c1526     1
    x[38]     OBJ       -1
    x[39]     c7        1
    x[39]     c1809     1
    x[39]     OBJ       -1
    x[40]     c8        1
    x[40]     c2092     1
    x[40]     OBJ       -1
    x[41]     c9        1
    x[41]     c2375     1
    x[41]     OBJ       -1
    x[42]     c10       1
    x[42]     c2658     1
    x[42]     OBJ       -1
    x[43]     c11       1
    x[43]     c2941     1
    x[43]     OBJ       -1
    x[44]     c12       1
    x[44]     c3224     1
    x[44]     OBJ       -1
    x[45]     c13       1
    x[45]     c3507     1
    x[45]     OBJ       -1
    x[46]     c14       1
    x[46]     c3790     1
    x[46]     OBJ       -1
    x[47]     c15       1
    x[47]     c4073     1
    x[47]     OBJ       -1
    x[48]     c16       1
    x[48]     c4356     1
    x[48]     OBJ       -1
    x[49]     c1        1
    x[49]     c112      1
    x[49]     c113      1
    x[49]     OBJ       -1
    x[50]     c2        1
    x[50]     c395      1
    x[50]     c396      1
    x[50]     OBJ       -1
    x[51]     c3        1
    x[51]     c678      1
    x[51]     c679      1
    x[51]     OBJ       -1
    x[52]     c4        1
    x[52]     c961      1
    x[52]     c962      1
    x[52]     OBJ       -1
    x[53]     c5        1
    x[53]     c1244     1
    x[53]     c1245     1
    x[53]     OBJ       -1
    x[54]     c6        1
    x[54]     c1527     1
    x[54]     c1528     1
    x[54]     OBJ       -1
    x[55]     c7        1
    x[55]     c1810     1
    x[55]     c1811     1
    x[55]     OBJ       -1
    x[56]     c8        1
    x[56]     c2093     1
    x[56]     c2094     1
    x[56]     OBJ       -1
    x[57]     c9        1
    x[57]     c2376     1
    x[57]     c2377     1
    x[57]     OBJ       -1
    x[58]     c10       1
    x[58]     c2659     1
    x[58]     c2660     1
    x[58]     OBJ       -1
    x[59]     c11       1
    x[59]     c2942     1
    x[59]     c2943     1
    x[59]     OBJ       -1
    x[60]     c12       1
    x[60]     c3225     1
    x[60]     c3226     1
    x[60]     OBJ       -1
    x[61]     c13       1
    x[61]     c3508     1
    x[61]     c3509     1
    x[61]     OBJ       -1
    x[62]     c14       1
    x[62]     c3791     1
    x[62]     c3792     1
    x[62]     OBJ       -1
    x[63]     c15       1
    x[63]     c4074     1
    x[63]     c4075     1
    x[63]     OBJ       -1
    x[64]     c16       1
    x[64]     c4357     1
    x[64]     c4358     1
    x[64]     OBJ       -1
    x[65]     c1        1
    x[65]     c114      1
    x[65]     OBJ       -1
    x[66]     c2        1
    x[66]     c397      1
    x[66]     OBJ       -1
    x[67]     c3        1
    x[67]     c680      1
    x[67]     OBJ       -1
    x[68]     c4        1
    x[68]     c963      1
    x[68]     OBJ       -1
    x[69]     c5        1
    x[69]     c1246     1
    x[69]     OBJ       -1
    x[70]     c6        1
    x[70]     c1529     1
    x[70]     OBJ       -1
    x[71]     c7        1
    x[71]     c1812     1
    x[71]     OBJ       -1
    x[72]     c8        1
    x[72]     c2095     1
    x[72]     OBJ       -1
    x[73]     c9        1
    x[73]     c2378     1
    x[73]     OBJ       -1
    x[74]     c10       1
    x[74]     c2661     1
    x[74]     OBJ       -1
    x[75]     c11       1
    x[75]     c2944     1
    x[75]     OBJ       -1
    x[76]     c12       1
    x[76]     c3227     1
    x[76]     OBJ       -1
    x[77]     c13       1
    x[77]     c3510     1
    x[77]     OBJ       -1
    x[78]     c14       1
    x[78]     c3793     1
    x[78]     OBJ       -1
    x[79]     c15       1
    x[79]     c4076     1
    x[79]     OBJ       -1
    x[80]     c16       1
    x[80]     c4359     1
    x[80]     OBJ       -1
    x[81]     c1        1
    x[81]     c115      1
    x[81]     c116      1
    x[81]     c117      1
    x[81]     OBJ       -1
    x[82]     c2        1
    x[82]     c398      1
    x[82]     c399      1
    x[82]     c400      1
    x[82]     OBJ       -1
    x[83]     c3        1
    x[83]     c681      1
    x[83]     c682      1
    x[83]     c683      1
    x[83]     OBJ       -1
    x[84]     c4        1
    x[84]     c964      1
    x[84]     c965      1
    x[84]     c966      1
    x[84]     OBJ       -1
    x[85]     c5        1
    x[85]     c1247     1
    x[85]     c1248     1
    x[85]     c1249     1
    x[85]     OBJ       -1
    x[86]     c6        1
    x[86]     c1530     1
    x[86]     c1531     1
    x[86]     c1532     1
    x[86]     OBJ       -1
    x[87]     c7        1
    x[87]     c1813     1
    x[87]     c1814     1
    x[87]     c1815     1
    x[87]     OBJ       -1
    x[88]     c8        1
    x[88]     c2096     1
    x[88]     c2097     1
    x[88]     c2098     1
    x[88]     OBJ       -1
    x[89]     c9        1
    x[89]     c2379     1
    x[89]     c2380     1
    x[89]     c2381     1
    x[89]     OBJ       -1
    x[90]     c10       1
    x[90]     c2662     1
    x[90]     c2663     1
    x[90]     c2664     1
    x[90]     OBJ       -1
    x[91]     c11       1
    x[91]     c2945     1
    x[91]     c2946     1
    x[91]     c2947     1
    x[91]     OBJ       -1
    x[92]     c12       1
    x[92]     c3228     1
    x[92]     c3229     1
    x[92]     c3230     1
    x[92]     OBJ       -1
    x[93]     c13       1
    x[93]     c3511     1
    x[93]     c3512     1
    x[93]     c3513     1
    x[93]     OBJ       -1
    x[94]     c14       1
    x[94]     c3794     1
    x[94]     c3795     1
    x[94]     c3796     1
    x[94]     OBJ       -1
    x[95]     c15       1
    x[95]     c4077     1
    x[95]     c4078     1
    x[95]     c4079     1
    x[95]     OBJ       -1
    x[96]     c16       1
    x[96]     c4360     1
    x[96]     c4361     1
    x[96]     c4362     1
    x[96]     OBJ       -1
    x[97]     c1        1
    x[97]     c118      1
    x[97]     c119      1
    x[97]     c120      1
    x[97]     OBJ       -1
    x[98]     c2        1
    x[98]     c401      1
    x[98]     c402      1
    x[98]     c403      1
    x[98]     OBJ       -1
    x[99]     c3        1
    x[99]     c684      1
    x[99]     c685      1
    x[99]     c686      1
    x[99]     OBJ       -1
    x[100]    c4        1
    x[100]    c967      1
    x[100]    c968      1
    x[100]    c969      1
    x[100]    OBJ       -1
    x[101]    c5        1
    x[101]    c1250     1
    x[101]    c1251     1
    x[101]    c1252     1
    x[101]    OBJ       -1
    x[102]    c6        1
    x[102]    c1533     1
    x[102]    c1534     1
    x[102]    c1535     1
    x[102]    OBJ       -1
    x[103]    c7        1
    x[103]    c1816     1
    x[103]    c1817     1
    x[103]    c1818     1
    x[103]    OBJ       -1
    x[104]    c8        1
    x[104]    c2099     1
    x[104]    c2100     1
    x[104]    c2101     1
    x[104]    OBJ       -1
    x[105]    c9        1
    x[105]    c2382     1
    x[105]    c2383     1
    x[105]    c2384     1
    x[105]    OBJ       -1
    x[106]    c10       1
    x[106]    c2665     1
    x[106]    c2666     1
    x[106]    c2667     1
    x[106]    OBJ       -1
    x[107]    c11       1
    x[107]    c2948     1
    x[107]    c2949     1
    x[107]    c2950     1
    x[107]    OBJ       -1
    x[108]    c12       1
    x[108]    c3231     1
    x[108]    c3232     1
    x[108]    c3233     1
    x[108]    OBJ       -1
    x[109]    c13       1
    x[109]    c3514     1
    x[109]    c3515     1
    x[109]    c3516     1
    x[109]    OBJ       -1
    x[110]    c14       1
    x[110]    c3797     1
    x[110]    c3798     1
    x[110]    c3799     1
    x[110]    OBJ       -1
    x[111]    c15       1
    x[111]    c4080     1
    x[111]    c4081     1
    x[111]    c4082     1
    x[111]    OBJ       -1
    x[112]    c16       1
    x[112]    c4363     1
    x[112]    c4364     1
    x[112]    c4365     1
    x[112]    OBJ       -1
    x[113]    c1        1
    x[113]    c121      1
    x[113]    c122      1
    x[113]    OBJ       -1
    x[114]    c2        1
    x[114]    c404      1
    x[114]    c405      1
    x[114]    OBJ       -1
    x[115]    c3        1
    x[115]    c687      1
    x[115]    c688      1
    x[115]    OBJ       -1
    x[116]    c4        1
    x[116]    c970      1
    x[116]    c971      1
    x[116]    OBJ       -1
    x[117]    c5        1
    x[117]    c1253     1
    x[117]    c1254     1
    x[117]    OBJ       -1
    x[118]    c6        1
    x[118]    c1536     1
    x[118]    c1537     1
    x[118]    OBJ       -1
    x[119]    c7        1
    x[119]    c1819     1
    x[119]    c1820     1
    x[119]    OBJ       -1
    x[120]    c8        1
    x[120]    c2102     1
    x[120]    c2103     1
    x[120]    OBJ       -1
    x[121]    c9        1
    x[121]    c2385     1
    x[121]    c2386     1
    x[121]    OBJ       -1
    x[122]    c10       1
    x[122]    c2668     1
    x[122]    c2669     1
    x[122]    OBJ       -1
    x[123]    c11       1
    x[123]    c2951     1
    x[123]    c2952     1
    x[123]    OBJ       -1
    x[124]    c12       1
    x[124]    c3234     1
    x[124]    c3235     1
    x[124]    OBJ       -1
    x[125]    c13       1
    x[125]    c3517     1
    x[125]    c3518     1
    x[125]    OBJ       -1
    x[126]    c14       1
    x[126]    c3800     1
    x[126]    c3801     1
    x[126]    OBJ       -1
    x[127]    c15       1
    x[127]    c4083     1
    x[127]    c4084     1
    x[127]    OBJ       -1
    x[128]    c16       1
    x[128]    c4366     1
    x[128]    c4367     1
    x[128]    OBJ       -1
    x[129]    c1        1
    x[129]    c123      1
    x[129]    c124      1
    x[129]    c125      1
    x[129]    OBJ       -1
    x[130]    c2        1
    x[130]    c406      1
    x[130]    c407      1
    x[130]    c408      1
    x[130]    OBJ       -1
    x[131]    c3        1
    x[131]    c689      1
    x[131]    c690      1
    x[131]    c691      1
    x[131]    OBJ       -1
    x[132]    c4        1
    x[132]    c972      1
    x[132]    c973      1
    x[132]    c974      1
    x[132]    OBJ       -1
    x[133]    c5        1
    x[133]    c1255     1
    x[133]    c1256     1
    x[133]    c1257     1
    x[133]    OBJ       -1
    x[134]    c6        1
    x[134]    c1538     1
    x[134]    c1539     1
    x[134]    c1540     1
    x[134]    OBJ       -1
    x[135]    c7        1
    x[135]    c1821     1
    x[135]    c1822     1
    x[135]    c1823     1
    x[135]    OBJ       -1
    x[136]    c8        1
    x[136]    c2104     1
    x[136]    c2105     1
    x[136]    c2106     1
    x[136]    OBJ       -1
    x[137]    c9        1
    x[137]    c2387     1
    x[137]    c2388     1
    x[137]    c2389     1
    x[137]    OBJ       -1
    x[138]    c10       1
    x[138]    c2670     1
    x[138]    c2671     1
    x[138]    c2672     1
    x[138]    OBJ       -1
    x[139]    c11       1
    x[139]    c2953     1
    x[139]    c2954     1
    x[139]    c2955     1
    x[139]    OBJ       -1
    x[140]    c12       1
    x[140]    c3236     1
    x[140]    c3237     1
    x[140]    c3238     1
    x[140]    OBJ       -1
    x[141]    c13       1
    x[141]    c3519     1
    x[141]    c3520     1
    x[141]    c3521     1
    x[141]    OBJ       -1
    x[142]    c14       1
    x[142]    c3802     1
    x[142]    c3803     1
    x[142]    c3804     1
    x[142]    OBJ       -1
    x[143]    c15       1
    x[143]    c4085     1
    x[143]    c4086     1
    x[143]    c4087     1
    x[143]    OBJ       -1
    x[144]    c16       1
    x[144]    c4368     1
    x[144]    c4369     1
    x[144]    c4370     1
    x[144]    OBJ       -1
    x[145]    c1        1
    x[145]    c126      1
    x[145]    c127      1
    x[145]    OBJ       -1
    x[146]    c2        1
    x[146]    c409      1
    x[146]    c410      1
    x[146]    OBJ       -1
    x[147]    c3        1
    x[147]    c692      1
    x[147]    c693      1
    x[147]    OBJ       -1
    x[148]    c4        1
    x[148]    c975      1
    x[148]    c976      1
    x[148]    OBJ       -1
    x[149]    c5        1
    x[149]    c1258     1
    x[149]    c1259     1
    x[149]    OBJ       -1
    x[150]    c6        1
    x[150]    c1541     1
    x[150]    c1542     1
    x[150]    OBJ       -1
    x[151]    c7        1
    x[151]    c1824     1
    x[151]    c1825     1
    x[151]    OBJ       -1
    x[152]    c8        1
    x[152]    c2107     1
    x[152]    c2108     1
    x[152]    OBJ       -1
    x[153]    c9        1
    x[153]    c2390     1
    x[153]    c2391     1
    x[153]    OBJ       -1
    x[154]    c10       1
    x[154]    c2673     1
    x[154]    c2674     1
    x[154]    OBJ       -1
    x[155]    c11       1
    x[155]    c2956     1
    x[155]    c2957     1
    x[155]    OBJ       -1
    x[156]    c12       1
    x[156]    c3239     1
    x[156]    c3240     1
    x[156]    OBJ       -1
    x[157]    c13       1
    x[157]    c3522     1
    x[157]    c3523     1
    x[157]    OBJ       -1
    x[158]    c14       1
    x[158]    c3805     1
    x[158]    c3806     1
    x[158]    OBJ       -1
    x[159]    c15       1
    x[159]    c4088     1
    x[159]    c4089     1
    x[159]    OBJ       -1
    x[160]    c16       1
    x[160]    c4371     1
    x[160]    c4372     1
    x[160]    OBJ       -1
    x[161]    c1        1
    x[161]    c128      1
    x[161]    OBJ       -1
    x[162]    c2        1
    x[162]    c411      1
    x[162]    OBJ       -1
    x[163]    c3        1
    x[163]    c694      1
    x[163]    OBJ       -1
    x[164]    c4        1
    x[164]    c977      1
    x[164]    OBJ       -1
    x[165]    c5        1
    x[165]    c1260     1
    x[165]    OBJ       -1
    x[166]    c6        1
    x[166]    c1543     1
    x[166]    OBJ       -1
    x[167]    c7        1
    x[167]    c1826     1
    x[167]    OBJ       -1
    x[168]    c8        1
    x[168]    c2109     1
    x[168]    OBJ       -1
    x[169]    c9        1
    x[169]    c2392     1
    x[169]    OBJ       -1
    x[170]    c10       1
    x[170]    c2675     1
    x[170]    OBJ       -1
    x[171]    c11       1
    x[171]    c2958     1
    x[171]    OBJ       -1
    x[172]    c12       1
    x[172]    c3241     1
    x[172]    OBJ       -1
    x[173]    c13       1
    x[173]    c3524     1
    x[173]    OBJ       -1
    x[174]    c14       1
    x[174]    c3807     1
    x[174]    OBJ       -1
    x[175]    c15       1
    x[175]    c4090     1
    x[175]    OBJ       -1
    x[176]    c16       1
    x[176]    c4373     1
    x[176]    OBJ       -1
    x[177]    c1        1
    x[177]    c129      1
    x[177]    c130      1
    x[177]    c131      1
    x[177]    OBJ       -1
    x[178]    c2        1
    x[178]    c412      1
    x[178]    c413      1
    x[178]    c414      1
    x[178]    OBJ       -1
    x[179]    c3        1
    x[179]    c695      1
    x[179]    c696      1
    x[179]    c697      1
    x[179]    OBJ       -1
    x[180]    c4        1
    x[180]    c978      1
    x[180]    c979      1
    x[180]    c980      1
    x[180]    OBJ       -1
    x[181]    c5        1
    x[181]    c1261     1
    x[181]    c1262     1
    x[181]    c1263     1
    x[181]    OBJ       -1
    x[182]    c6        1
    x[182]    c1544     1
    x[182]    c1545     1
    x[182]    c1546     1
    x[182]    OBJ       -1
    x[183]    c7        1
    x[183]    c1827     1
    x[183]    c1828     1
    x[183]    c1829     1
    x[183]    OBJ       -1
    x[184]    c8        1
    x[184]    c2110     1
    x[184]    c2111     1
    x[184]    c2112     1
    x[184]    OBJ       -1
    x[185]    c9        1
    x[185]    c2393     1
    x[185]    c2394     1
    x[185]    c2395     1
    x[185]    OBJ       -1
    x[186]    c10       1
    x[186]    c2676     1
    x[186]    c2677     1
    x[186]    c2678     1
    x[186]    OBJ       -1
    x[187]    c11       1
    x[187]    c2959     1
    x[187]    c2960     1
    x[187]    c2961     1
    x[187]    OBJ       -1
    x[188]    c12       1
    x[188]    c3242     1
    x[188]    c3243     1
    x[188]    c3244     1
    x[188]    OBJ       -1
    x[189]    c13       1
    x[189]    c3525     1
    x[189]    c3526     1
    x[189]    c3527     1
    x[189]    OBJ       -1
    x[190]    c14       1
    x[190]    c3808     1
    x[190]    c3809     1
    x[190]    c3810     1
    x[190]    OBJ       -1
    x[191]    c15       1
    x[191]    c4091     1
    x[191]    c4092     1
    x[191]    c4093     1
    x[191]    OBJ       -1
    x[192]    c16       1
    x[192]    c4374     1
    x[192]    c4375     1
    x[192]    c4376     1
    x[192]    OBJ       -1
    x[193]    c1        1
    x[193]    c132      1
    x[193]    c133      1
    x[193]    c134      1
    x[193]    OBJ       -1
    x[194]    c2        1
    x[194]    c415      1
    x[194]    c416      1
    x[194]    c417      1
    x[194]    OBJ       -1
    x[195]    c3        1
    x[195]    c698      1
    x[195]    c699      1
    x[195]    c700      1
    x[195]    OBJ       -1
    x[196]    c4        1
    x[196]    c981      1
    x[196]    c982      1
    x[196]    c983      1
    x[196]    OBJ       -1
    x[197]    c5        1
    x[197]    c1264     1
    x[197]    c1265     1
    x[197]    c1266     1
    x[197]    OBJ       -1
    x[198]    c6        1
    x[198]    c1547     1
    x[198]    c1548     1
    x[198]    c1549     1
    x[198]    OBJ       -1
    x[199]    c7        1
    x[199]    c1830     1
    x[199]    c1831     1
    x[199]    c1832     1
    x[199]    OBJ       -1
    x[200]    c8        1
    x[200]    c2113     1
    x[200]    c2114     1
    x[200]    c2115     1
    x[200]    OBJ       -1
    x[201]    c9        1
    x[201]    c2396     1
    x[201]    c2397     1
    x[201]    c2398     1
    x[201]    OBJ       -1
    x[202]    c10       1
    x[202]    c2679     1
    x[202]    c2680     1
    x[202]    c2681     1
    x[202]    OBJ       -1
    x[203]    c11       1
    x[203]    c2962     1
    x[203]    c2963     1
    x[203]    c2964     1
    x[203]    OBJ       -1
    x[204]    c12       1
    x[204]    c3245     1
    x[204]    c3246     1
    x[204]    c3247     1
    x[204]    OBJ       -1
    x[205]    c13       1
    x[205]    c3528     1
    x[205]    c3529     1
    x[205]    c3530     1
    x[205]    OBJ       -1
    x[206]    c14       1
    x[206]    c3811     1
    x[206]    c3812     1
    x[206]    c3813     1
    x[206]    OBJ       -1
    x[207]    c15       1
    x[207]    c4094     1
    x[207]    c4095     1
    x[207]    c4096     1
    x[207]    OBJ       -1
    x[208]    c16       1
    x[208]    c4377     1
    x[208]    c4378     1
    x[208]    c4379     1
    x[208]    OBJ       -1
    x[209]    c1        1
    x[209]    c135      1
    x[209]    OBJ       -1
    x[210]    c2        1
    x[210]    c418      1
    x[210]    OBJ       -1
    x[211]    c3        1
    x[211]    c701      1
    x[211]    OBJ       -1
    x[212]    c4        1
    x[212]    c984      1
    x[212]    OBJ       -1
    x[213]    c5        1
    x[213]    c1267     1
    x[213]    OBJ       -1
    x[214]    c6        1
    x[214]    c1550     1
    x[214]    OBJ       -1
    x[215]    c7        1
    x[215]    c1833     1
    x[215]    OBJ       -1
    x[216]    c8        1
    x[216]    c2116     1
    x[216]    OBJ       -1
    x[217]    c9        1
    x[217]    c2399     1
    x[217]    OBJ       -1
    x[218]    c10       1
    x[218]    c2682     1
    x[218]    OBJ       -1
    x[219]    c11       1
    x[219]    c2965     1
    x[219]    OBJ       -1
    x[220]    c12       1
    x[220]    c3248     1
    x[220]    OBJ       -1
    x[221]    c13       1
    x[221]    c3531     1
    x[221]    OBJ       -1
    x[222]    c14       1
    x[222]    c3814     1
    x[222]    OBJ       -1
    x[223]    c15       1
    x[223]    c4097     1
    x[223]    OBJ       -1
    x[224]    c16       1
    x[224]    c4380     1
    x[224]    OBJ       -1
    x[225]    c1        1
    x[225]    c136      1
    x[225]    OBJ       -1
    x[226]    c2        1
    x[226]    c419      1
    x[226]    OBJ       -1
    x[227]    c3        1
    x[227]    c702      1
    x[227]    OBJ       -1
    x[228]    c4        1
    x[228]    c985      1
    x[228]    OBJ       -1
    x[229]    c5        1
    x[229]    c1268     1
    x[229]    OBJ       -1
    x[230]    c6        1
    x[230]    c1551     1
    x[230]    OBJ       -1
    x[231]    c7        1
    x[231]    c1834     1
    x[231]    OBJ       -1
    x[232]    c8        1
    x[232]    c2117     1
    x[232]    OBJ       -1
    x[233]    c9        1
    x[233]    c2400     1
    x[233]    OBJ       -1
    x[234]    c10       1
    x[234]    c2683     1
    x[234]    OBJ       -1
    x[235]    c11       1
    x[235]    c2966     1
    x[235]    OBJ       -1
    x[236]    c12       1
    x[236]    c3249     1
    x[236]    OBJ       -1
    x[237]    c13       1
    x[237]    c3532     1
    x[237]    OBJ       -1
    x[238]    c14       1
    x[238]    c3815     1
    x[238]    OBJ       -1
    x[239]    c15       1
    x[239]    c4098     1
    x[239]    OBJ       -1
    x[240]    c16       1
    x[240]    c4381     1
    x[240]    OBJ       -1
    x[241]    c1        1
    x[241]    c137      1
    x[241]    OBJ       -1
    x[242]    c2        1
    x[242]    c420      1
    x[242]    OBJ       -1
    x[243]    c3        1
    x[243]    c703      1
    x[243]    OBJ       -1
    x[244]    c4        1
    x[244]    c986      1
    x[244]    OBJ       -1
    x[245]    c5        1
    x[245]    c1269     1
    x[245]    OBJ       -1
    x[246]    c6        1
    x[246]    c1552     1
    x[246]    OBJ       -1
    x[247]    c7        1
    x[247]    c1835     1
    x[247]    OBJ       -1
    x[248]    c8        1
    x[248]    c2118     1
    x[248]    OBJ       -1
    x[249]    c9        1
    x[249]    c2401     1
    x[249]    OBJ       -1
    x[250]    c10       1
    x[250]    c2684     1
    x[250]    OBJ       -1
    x[251]    c11       1
    x[251]    c2967     1
    x[251]    OBJ       -1
    x[252]    c12       1
    x[252]    c3250     1
    x[252]    OBJ       -1
    x[253]    c13       1
    x[253]    c3533     1
    x[253]    OBJ       -1
    x[254]    c14       1
    x[254]    c3816     1
    x[254]    OBJ       -1
    x[255]    c15       1
    x[255]    c4099     1
    x[255]    OBJ       -1
    x[256]    c16       1
    x[256]    c4382     1
    x[256]    OBJ       -1
    x[257]    c1        1
    x[257]    c138      1
    x[257]    OBJ       -1
    x[258]    c2        1
    x[258]    c421      1
    x[258]    OBJ       -1
    x[259]    c3        1
    x[259]    c704      1
    x[259]    OBJ       -1
    x[260]    c4        1
    x[260]    c987      1
    x[260]    OBJ       -1
    x[261]    c5        1
    x[261]    c1270     1
    x[261]    OBJ       -1
    x[262]    c6        1
    x[262]    c1553     1
    x[262]    OBJ       -1
    x[263]    c7        1
    x[263]    c1836     1
    x[263]    OBJ       -1
    x[264]    c8        1
    x[264]    c2119     1
    x[264]    OBJ       -1
    x[265]    c9        1
    x[265]    c2402     1
    x[265]    OBJ       -1
    x[266]    c10       1
    x[266]    c2685     1
    x[266]    OBJ       -1
    x[267]    c11       1
    x[267]    c2968     1
    x[267]    OBJ       -1
    x[268]    c12       1
    x[268]    c3251     1
    x[268]    OBJ       -1
    x[269]    c13       1
    x[269]    c3534     1
    x[269]    OBJ       -1
    x[270]    c14       1
    x[270]    c3817     1
    x[270]    OBJ       -1
    x[271]    c15       1
    x[271]    c4100     1
    x[271]    OBJ       -1
    x[272]    c16       1
    x[272]    c4383     1
    x[272]    OBJ       -1
    x[273]    c1        1
    x[273]    c139      1
    x[273]    c140      1
    x[273]    c141      1
    x[273]    c142      1
    x[273]    c143      1
    x[273]    c144      1
    x[273]    OBJ       -1
    x[274]    c2        1
    x[274]    c422      1
    x[274]    c423      1
    x[274]    c424      1
    x[274]    c425      1
    x[274]    c426      1
    x[274]    c427      1
    x[274]    OBJ       -1
    x[275]    c3        1
    x[275]    c705      1
    x[275]    c706      1
    x[275]    c707      1
    x[275]    c708      1
    x[275]    c709      1
    x[275]    c710      1
    x[275]    OBJ       -1
    x[276]    c4        1
    x[276]    c988      1
    x[276]    c989      1
    x[276]    c990      1
    x[276]    c991      1
    x[276]    c992      1
    x[276]    c993      1
    x[276]    OBJ       -1
    x[277]    c5        1
    x[277]    c1271     1
    x[277]    c1272     1
    x[277]    c1273     1
    x[277]    c1274     1
    x[277]    c1275     1
    x[277]    c1276     1
    x[277]    OBJ       -1
    x[278]    c6        1
    x[278]    c1554     1
    x[278]    c1555     1
    x[278]    c1556     1
    x[278]    c1557     1
    x[278]    c1558     1
    x[278]    c1559     1
    x[278]    OBJ       -1
    x[279]    c7        1
    x[279]    c1837     1
    x[279]    c1838     1
    x[279]    c1839     1
    x[279]    c1840     1
    x[279]    c1841     1
    x[279]    c1842     1
    x[279]    OBJ       -1
    x[280]    c8        1
    x[280]    c2120     1
    x[280]    c2121     1
    x[280]    c2122     1
    x[280]    c2123     1
    x[280]    c2124     1
    x[280]    c2125     1
    x[280]    OBJ       -1
    x[281]    c9        1
    x[281]    c2403     1
    x[281]    c2404     1
    x[281]    c2405     1
    x[281]    c2406     1
    x[281]    c2407     1
    x[281]    c2408     1
    x[281]    OBJ       -1
    x[282]    c10       1
    x[282]    c2686     1
    x[282]    c2687     1
    x[282]    c2688     1
    x[282]    c2689     1
    x[282]    c2690     1
    x[282]    c2691     1
    x[282]    OBJ       -1
    x[283]    c11       1
    x[283]    c2969     1
    x[283]    c2970     1
    x[283]    c2971     1
    x[283]    c2972     1
    x[283]    c2973     1
    x[283]    c2974     1
    x[283]    OBJ       -1
    x[284]    c12       1
    x[284]    c3252     1
    x[284]    c3253     1
    x[284]    c3254     1
    x[284]    c3255     1
    x[284]    c3256     1
    x[284]    c3257     1
    x[284]    OBJ       -1
    x[285]    c13       1
    x[285]    c3535     1
    x[285]    c3536     1
    x[285]    c3537     1
    x[285]    c3538     1
    x[285]    c3539     1
    x[285]    c3540     1
    x[285]    OBJ       -1
    x[286]    c14       1
    x[286]    c3818     1
    x[286]    c3819     1
    x[286]    c3820     1
    x[286]    c3821     1
    x[286]    c3822     1
    x[286]    c3823     1
    x[286]    OBJ       -1
    x[287]    c15       1
    x[287]    c4101     1
    x[287]    c4102     1
    x[287]    c4103     1
    x[287]    c4104     1
    x[287]    c4105     1
    x[287]    c4106     1
    x[287]    OBJ       -1
    x[288]    c16       1
    x[288]    c4384     1
    x[288]    c4385     1
    x[288]    c4386     1
    x[288]    c4387     1
    x[288]    c4388     1
    x[288]    c4389     1
    x[288]    OBJ       -1
    x[289]    c1        1
    x[289]    c145      1
    x[289]    c146      1
    x[289]    OBJ       -1
    x[290]    c2        1
    x[290]    c428      1
    x[290]    c429      1
    x[290]    OBJ       -1
    x[291]    c3        1
    x[291]    c711      1
    x[291]    c712      1
    x[291]    OBJ       -1
    x[292]    c4        1
    x[292]    c994      1
    x[292]    c995      1
    x[292]    OBJ       -1
    x[293]    c5        1
    x[293]    c1277     1
    x[293]    c1278     1
    x[293]    OBJ       -1
    x[294]    c6        1
    x[294]    c1560     1
    x[294]    c1561     1
    x[294]    OBJ       -1
    x[295]    c7        1
    x[295]    c1843     1
    x[295]    c1844     1
    x[295]    OBJ       -1
    x[296]    c8        1
    x[296]    c2126     1
    x[296]    c2127     1
    x[296]    OBJ       -1
    x[297]    c9        1
    x[297]    c2409     1
    x[297]    c2410     1
    x[297]    OBJ       -1
    x[298]    c10       1
    x[298]    c2692     1
    x[298]    c2693     1
    x[298]    OBJ       -1
    x[299]    c11       1
    x[299]    c2975     1
    x[299]    c2976     1
    x[299]    OBJ       -1
    x[300]    c12       1
    x[300]    c3258     1
    x[300]    c3259     1
    x[300]    OBJ       -1
    x[301]    c13       1
    x[301]    c3541     1
    x[301]    c3542     1
    x[301]    OBJ       -1
    x[302]    c14       1
    x[302]    c3824     1
    x[302]    c3825     1
    x[302]    OBJ       -1
    x[303]    c15       1
    x[303]    c4107     1
    x[303]    c4108     1
    x[303]    OBJ       -1
    x[304]    c16       1
    x[304]    c4390     1
    x[304]    c4391     1
    x[304]    OBJ       -1
    x[305]    c1        1
    x[305]    c147      1
    x[305]    c148      1
    x[305]    c149      1
    x[305]    OBJ       -1
    x[306]    c2        1
    x[306]    c430      1
    x[306]    c431      1
    x[306]    c432      1
    x[306]    OBJ       -1
    x[307]    c3        1
    x[307]    c713      1
    x[307]    c714      1
    x[307]    c715      1
    x[307]    OBJ       -1
    x[308]    c4        1
    x[308]    c996      1
    x[308]    c997      1
    x[308]    c998      1
    x[308]    OBJ       -1
    x[309]    c5        1
    x[309]    c1279     1
    x[309]    c1280     1
    x[309]    c1281     1
    x[309]    OBJ       -1
    x[310]    c6        1
    x[310]    c1562     1
    x[310]    c1563     1
    x[310]    c1564     1
    x[310]    OBJ       -1
    x[311]    c7        1
    x[311]    c1845     1
    x[311]    c1846     1
    x[311]    c1847     1
    x[311]    OBJ       -1
    x[312]    c8        1
    x[312]    c2128     1
    x[312]    c2129     1
    x[312]    c2130     1
    x[312]    OBJ       -1
    x[313]    c9        1
    x[313]    c2411     1
    x[313]    c2412     1
    x[313]    c2413     1
    x[313]    OBJ       -1
    x[314]    c10       1
    x[314]    c2694     1
    x[314]    c2695     1
    x[314]    c2696     1
    x[314]    OBJ       -1
    x[315]    c11       1
    x[315]    c2977     1
    x[315]    c2978     1
    x[315]    c2979     1
    x[315]    OBJ       -1
    x[316]    c12       1
    x[316]    c3260     1
    x[316]    c3261     1
    x[316]    c3262     1
    x[316]    OBJ       -1
    x[317]    c13       1
    x[317]    c3543     1
    x[317]    c3544     1
    x[317]    c3545     1
    x[317]    OBJ       -1
    x[318]    c14       1
    x[318]    c3826     1
    x[318]    c3827     1
    x[318]    c3828     1
    x[318]    OBJ       -1
    x[319]    c15       1
    x[319]    c4109     1
    x[319]    c4110     1
    x[319]    c4111     1
    x[319]    OBJ       -1
    x[320]    c16       1
    x[320]    c4392     1
    x[320]    c4393     1
    x[320]    c4394     1
    x[320]    OBJ       -1
    x[321]    c1        1
    x[321]    c150      1
    x[321]    c151      1
    x[321]    c152      1
    x[321]    OBJ       -1
    x[322]    c2        1
    x[322]    c433      1
    x[322]    c434      1
    x[322]    c435      1
    x[322]    OBJ       -1
    x[323]    c3        1
    x[323]    c716      1
    x[323]    c717      1
    x[323]    c718      1
    x[323]    OBJ       -1
    x[324]    c4        1
    x[324]    c999      1
    x[324]    c1000     1
    x[324]    c1001     1
    x[324]    OBJ       -1
    x[325]    c5        1
    x[325]    c1282     1
    x[325]    c1283     1
    x[325]    c1284     1
    x[325]    OBJ       -1
    x[326]    c6        1
    x[326]    c1565     1
    x[326]    c1566     1
    x[326]    c1567     1
    x[326]    OBJ       -1
    x[327]    c7        1
    x[327]    c1848     1
    x[327]    c1849     1
    x[327]    c1850     1
    x[327]    OBJ       -1
    x[328]    c8        1
    x[328]    c2131     1
    x[328]    c2132     1
    x[328]    c2133     1
    x[328]    OBJ       -1
    x[329]    c9        1
    x[329]    c2414     1
    x[329]    c2415     1
    x[329]    c2416     1
    x[329]    OBJ       -1
    x[330]    c10       1
    x[330]    c2697     1
    x[330]    c2698     1
    x[330]    c2699     1
    x[330]    OBJ       -1
    x[331]    c11       1
    x[331]    c2980     1
    x[331]    c2981     1
    x[331]    c2982     1
    x[331]    OBJ       -1
    x[332]    c12       1
    x[332]    c3263     1
    x[332]    c3264     1
    x[332]    c3265     1
    x[332]    OBJ       -1
    x[333]    c13       1
    x[333]    c3546     1
    x[333]    c3547     1
    x[333]    c3548     1
    x[333]    OBJ       -1
    x[334]    c14       1
    x[334]    c3829     1
    x[334]    c3830     1
    x[334]    c3831     1
    x[334]    OBJ       -1
    x[335]    c15       1
    x[335]    c4112     1
    x[335]    c4113     1
    x[335]    c4114     1
    x[335]    OBJ       -1
    x[336]    c16       1
    x[336]    c4395     1
    x[336]    c4396     1
    x[336]    c4397     1
    x[336]    OBJ       -1
    x[337]    c1        1
    x[337]    c153      1
    x[337]    c154      1
    x[337]    c155      1
    x[337]    OBJ       -1
    x[338]    c2        1
    x[338]    c436      1
    x[338]    c437      1
    x[338]    c438      1
    x[338]    OBJ       -1
    x[339]    c3        1
    x[339]    c719      1
    x[339]    c720      1
    x[339]    c721      1
    x[339]    OBJ       -1
    x[340]    c4        1
    x[340]    c1002     1
    x[340]    c1003     1
    x[340]    c1004     1
    x[340]    OBJ       -1
    x[341]    c5        1
    x[341]    c1285     1
    x[341]    c1286     1
    x[341]    c1287     1
    x[341]    OBJ       -1
    x[342]    c6        1
    x[342]    c1568     1
    x[342]    c1569     1
    x[342]    c1570     1
    x[342]    OBJ       -1
    x[343]    c7        1
    x[343]    c1851     1
    x[343]    c1852     1
    x[343]    c1853     1
    x[343]    OBJ       -1
    x[344]    c8        1
    x[344]    c2134     1
    x[344]    c2135     1
    x[344]    c2136     1
    x[344]    OBJ       -1
    x[345]    c9        1
    x[345]    c2417     1
    x[345]    c2418     1
    x[345]    c2419     1
    x[345]    OBJ       -1
    x[346]    c10       1
    x[346]    c2700     1
    x[346]    c2701     1
    x[346]    c2702     1
    x[346]    OBJ       -1
    x[347]    c11       1
    x[347]    c2983     1
    x[347]    c2984     1
    x[347]    c2985     1
    x[347]    OBJ       -1
    x[348]    c12       1
    x[348]    c3266     1
    x[348]    c3267     1
    x[348]    c3268     1
    x[348]    OBJ       -1
    x[349]    c13       1
    x[349]    c3549     1
    x[349]    c3550     1
    x[349]    c3551     1
    x[349]    OBJ       -1
    x[350]    c14       1
    x[350]    c3832     1
    x[350]    c3833     1
    x[350]    c3834     1
    x[350]    OBJ       -1
    x[351]    c15       1
    x[351]    c4115     1
    x[351]    c4116     1
    x[351]    c4117     1
    x[351]    OBJ       -1
    x[352]    c16       1
    x[352]    c4398     1
    x[352]    c4399     1
    x[352]    c4400     1
    x[352]    OBJ       -1
    x[353]    c1        1
    x[353]    c156      1
    x[353]    OBJ       -1
    x[354]    c2        1
    x[354]    c439      1
    x[354]    OBJ       -1
    x[355]    c3        1
    x[355]    c722      1
    x[355]    OBJ       -1
    x[356]    c4        1
    x[356]    c1005     1
    x[356]    OBJ       -1
    x[357]    c5        1
    x[357]    c1288     1
    x[357]    OBJ       -1
    x[358]    c6        1
    x[358]    c1571     1
    x[358]    OBJ       -1
    x[359]    c7        1
    x[359]    c1854     1
    x[359]    OBJ       -1
    x[360]    c8        1
    x[360]    c2137     1
    x[360]    OBJ       -1
    x[361]    c9        1
    x[361]    c2420     1
    x[361]    OBJ       -1
    x[362]    c10       1
    x[362]    c2703     1
    x[362]    OBJ       -1
    x[363]    c11       1
    x[363]    c2986     1
    x[363]    OBJ       -1
    x[364]    c12       1
    x[364]    c3269     1
    x[364]    OBJ       -1
    x[365]    c13       1
    x[365]    c3552     1
    x[365]    OBJ       -1
    x[366]    c14       1
    x[366]    c3835     1
    x[366]    OBJ       -1
    x[367]    c15       1
    x[367]    c4118     1
    x[367]    OBJ       -1
    x[368]    c16       1
    x[368]    c4401     1
    x[368]    OBJ       -1
    x[369]    c1        1
    x[369]    c157      1
    x[369]    OBJ       -1
    x[370]    c2        1
    x[370]    c440      1
    x[370]    OBJ       -1
    x[371]    c3        1
    x[371]    c723      1
    x[371]    OBJ       -1
    x[372]    c4        1
    x[372]    c1006     1
    x[372]    OBJ       -1
    x[373]    c5        1
    x[373]    c1289     1
    x[373]    OBJ       -1
    x[374]    c6        1
    x[374]    c1572     1
    x[374]    OBJ       -1
    x[375]    c7        1
    x[375]    c1855     1
    x[375]    OBJ       -1
    x[376]    c8        1
    x[376]    c2138     1
    x[376]    OBJ       -1
    x[377]    c9        1
    x[377]    c2421     1
    x[377]    OBJ       -1
    x[378]    c10       1
    x[378]    c2704     1
    x[378]    OBJ       -1
    x[379]    c11       1
    x[379]    c2987     1
    x[379]    OBJ       -1
    x[380]    c12       1
    x[380]    c3270     1
    x[380]    OBJ       -1
    x[381]    c13       1
    x[381]    c3553     1
    x[381]    OBJ       -1
    x[382]    c14       1
    x[382]    c3836     1
    x[382]    OBJ       -1
    x[383]    c15       1
    x[383]    c4119     1
    x[383]    OBJ       -1
    x[384]    c16       1
    x[384]    c4402     1
    x[384]    OBJ       -1
    x[385]    c1        1
    x[385]    c158      1
    x[385]    c159      1
    x[385]    c160      1
    x[385]    OBJ       -1
    x[386]    c2        1
    x[386]    c441      1
    x[386]    c442      1
    x[386]    c443      1
    x[386]    OBJ       -1
    x[387]    c3        1
    x[387]    c724      1
    x[387]    c725      1
    x[387]    c726      1
    x[387]    OBJ       -1
    x[388]    c4        1
    x[388]    c1007     1
    x[388]    c1008     1
    x[388]    c1009     1
    x[388]    OBJ       -1
    x[389]    c5        1
    x[389]    c1290     1
    x[389]    c1291     1
    x[389]    c1292     1
    x[389]    OBJ       -1
    x[390]    c6        1
    x[390]    c1573     1
    x[390]    c1574     1
    x[390]    c1575     1
    x[390]    OBJ       -1
    x[391]    c7        1
    x[391]    c1856     1
    x[391]    c1857     1
    x[391]    c1858     1
    x[391]    OBJ       -1
    x[392]    c8        1
    x[392]    c2139     1
    x[392]    c2140     1
    x[392]    c2141     1
    x[392]    OBJ       -1
    x[393]    c9        1
    x[393]    c2422     1
    x[393]    c2423     1
    x[393]    c2424     1
    x[393]    OBJ       -1
    x[394]    c10       1
    x[394]    c2705     1
    x[394]    c2706     1
    x[394]    c2707     1
    x[394]    OBJ       -1
    x[395]    c11       1
    x[395]    c2988     1
    x[395]    c2989     1
    x[395]    c2990     1
    x[395]    OBJ       -1
    x[396]    c12       1
    x[396]    c3271     1
    x[396]    c3272     1
    x[396]    c3273     1
    x[396]    OBJ       -1
    x[397]    c13       1
    x[397]    c3554     1
    x[397]    c3555     1
    x[397]    c3556     1
    x[397]    OBJ       -1
    x[398]    c14       1
    x[398]    c3837     1
    x[398]    c3838     1
    x[398]    c3839     1
    x[398]    OBJ       -1
    x[399]    c15       1
    x[399]    c4120     1
    x[399]    c4121     1
    x[399]    c4122     1
    x[399]    OBJ       -1
    x[400]    c16       1
    x[400]    c4403     1
    x[400]    c4404     1
    x[400]    c4405     1
    x[400]    OBJ       -1
    x[401]    c1        1
    x[401]    c161      1
    x[401]    c162      1
    x[401]    c163      1
    x[401]    OBJ       -1
    x[402]    c2        1
    x[402]    c444      1
    x[402]    c445      1
    x[402]    c446      1
    x[402]    OBJ       -1
    x[403]    c3        1
    x[403]    c727      1
    x[403]    c728      1
    x[403]    c729      1
    x[403]    OBJ       -1
    x[404]    c4        1
    x[404]    c1010     1
    x[404]    c1011     1
    x[404]    c1012     1
    x[404]    OBJ       -1
    x[405]    c5        1
    x[405]    c1293     1
    x[405]    c1294     1
    x[405]    c1295     1
    x[405]    OBJ       -1
    x[406]    c6        1
    x[406]    c1576     1
    x[406]    c1577     1
    x[406]    c1578     1
    x[406]    OBJ       -1
    x[407]    c7        1
    x[407]    c1859     1
    x[407]    c1860     1
    x[407]    c1861     1
    x[407]    OBJ       -1
    x[408]    c8        1
    x[408]    c2142     1
    x[408]    c2143     1
    x[408]    c2144     1
    x[408]    OBJ       -1
    x[409]    c9        1
    x[409]    c2425     1
    x[409]    c2426     1
    x[409]    c2427     1
    x[409]    OBJ       -1
    x[410]    c10       1
    x[410]    c2708     1
    x[410]    c2709     1
    x[410]    c2710     1
    x[410]    OBJ       -1
    x[411]    c11       1
    x[411]    c2991     1
    x[411]    c2992     1
    x[411]    c2993     1
    x[411]    OBJ       -1
    x[412]    c12       1
    x[412]    c3274     1
    x[412]    c3275     1
    x[412]    c3276     1
    x[412]    OBJ       -1
    x[413]    c13       1
    x[413]    c3557     1
    x[413]    c3558     1
    x[413]    c3559     1
    x[413]    OBJ       -1
    x[414]    c14       1
    x[414]    c3840     1
    x[414]    c3841     1
    x[414]    c3842     1
    x[414]    OBJ       -1
    x[415]    c15       1
    x[415]    c4123     1
    x[415]    c4124     1
    x[415]    c4125     1
    x[415]    OBJ       -1
    x[416]    c16       1
    x[416]    c4406     1
    x[416]    c4407     1
    x[416]    c4408     1
    x[416]    OBJ       -1
    x[417]    c1        1
    x[417]    c164      1
    x[417]    c165      1
    x[417]    OBJ       -1
    x[418]    c2        1
    x[418]    c447      1
    x[418]    c448      1
    x[418]    OBJ       -1
    x[419]    c3        1
    x[419]    c730      1
    x[419]    c731      1
    x[419]    OBJ       -1
    x[420]    c4        1
    x[420]    c1013     1
    x[420]    c1014     1
    x[420]    OBJ       -1
    x[421]    c5        1
    x[421]    c1296     1
    x[421]    c1297     1
    x[421]    OBJ       -1
    x[422]    c6        1
    x[422]    c1579     1
    x[422]    c1580     1
    x[422]    OBJ       -1
    x[423]    c7        1
    x[423]    c1862     1
    x[423]    c1863     1
    x[423]    OBJ       -1
    x[424]    c8        1
    x[424]    c2145     1
    x[424]    c2146     1
    x[424]    OBJ       -1
    x[425]    c9        1
    x[425]    c2428     1
    x[425]    c2429     1
    x[425]    OBJ       -1
    x[426]    c10       1
    x[426]    c2711     1
    x[426]    c2712     1
    x[426]    OBJ       -1
    x[427]    c11       1
    x[427]    c2994     1
    x[427]    c2995     1
    x[427]    OBJ       -1
    x[428]    c12       1
    x[428]    c3277     1
    x[428]    c3278     1
    x[428]    OBJ       -1
    x[429]    c13       1
    x[429]    c3560     1
    x[429]    c3561     1
    x[429]    OBJ       -1
    x[430]    c14       1
    x[430]    c3843     1
    x[430]    c3844     1
    x[430]    OBJ       -1
    x[431]    c15       1
    x[431]    c4126     1
    x[431]    c4127     1
    x[431]    OBJ       -1
    x[432]    c16       1
    x[432]    c4409     1
    x[432]    c4410     1
    x[432]    OBJ       -1
    x[433]    c1        1
    x[433]    c166      1
    x[433]    c167      1
    x[433]    OBJ       -1
    x[434]    c2        1
    x[434]    c449      1
    x[434]    c450      1
    x[434]    OBJ       -1
    x[435]    c3        1
    x[435]    c732      1
    x[435]    c733      1
    x[435]    OBJ       -1
    x[436]    c4        1
    x[436]    c1015     1
    x[436]    c1016     1
    x[436]    OBJ       -1
    x[437]    c5        1
    x[437]    c1298     1
    x[437]    c1299     1
    x[437]    OBJ       -1
    x[438]    c6        1
    x[438]    c1581     1
    x[438]    c1582     1
    x[438]    OBJ       -1
    x[439]    c7        1
    x[439]    c1864     1
    x[439]    c1865     1
    x[439]    OBJ       -1
    x[440]    c8        1
    x[440]    c2147     1
    x[440]    c2148     1
    x[440]    OBJ       -1
    x[441]    c9        1
    x[441]    c2430     1
    x[441]    c2431     1
    x[441]    OBJ       -1
    x[442]    c10       1
    x[442]    c2713     1
    x[442]    c2714     1
    x[442]    OBJ       -1
    x[443]    c11       1
    x[443]    c2996     1
    x[443]    c2997     1
    x[443]    OBJ       -1
    x[444]    c12       1
    x[444]    c3279     1
    x[444]    c3280     1
    x[444]    OBJ       -1
    x[445]    c13       1
    x[445]    c3562     1
    x[445]    c3563     1
    x[445]    OBJ       -1
    x[446]    c14       1
    x[446]    c3845     1
    x[446]    c3846     1
    x[446]    OBJ       -1
    x[447]    c15       1
    x[447]    c4128     1
    x[447]    c4129     1
    x[447]    OBJ       -1
    x[448]    c16       1
    x[448]    c4411     1
    x[448]    c4412     1
    x[448]    OBJ       -1
    x[449]    c1        1
    x[449]    c168      1
    x[449]    c169      1
    x[449]    c170      1
    x[449]    c171      1
    x[449]    OBJ       -1
    x[450]    c2        1
    x[450]    c451      1
    x[450]    c452      1
    x[450]    c453      1
    x[450]    c454      1
    x[450]    OBJ       -1
    x[451]    c3        1
    x[451]    c734      1
    x[451]    c735      1
    x[451]    c736      1
    x[451]    c737      1
    x[451]    OBJ       -1
    x[452]    c4        1
    x[452]    c1017     1
    x[452]    c1018     1
    x[452]    c1019     1
    x[452]    c1020     1
    x[452]    OBJ       -1
    x[453]    c5        1
    x[453]    c1300     1
    x[453]    c1301     1
    x[453]    c1302     1
    x[453]    c1303     1
    x[453]    OBJ       -1
    x[454]    c6        1
    x[454]    c1583     1
    x[454]    c1584     1
    x[454]    c1585     1
    x[454]    c1586     1
    x[454]    OBJ       -1
    x[455]    c7        1
    x[455]    c1866     1
    x[455]    c1867     1
    x[455]    c1868     1
    x[455]    c1869     1
    x[455]    OBJ       -1
    x[456]    c8        1
    x[456]    c2149     1
    x[456]    c2150     1
    x[456]    c2151     1
    x[456]    c2152     1
    x[456]    OBJ       -1
    x[457]    c9        1
    x[457]    c2432     1
    x[457]    c2433     1
    x[457]    c2434     1
    x[457]    c2435     1
    x[457]    OBJ       -1
    x[458]    c10       1
    x[458]    c2715     1
    x[458]    c2716     1
    x[458]    c2717     1
    x[458]    c2718     1
    x[458]    OBJ       -1
    x[459]    c11       1
    x[459]    c2998     1
    x[459]    c2999     1
    x[459]    c3000     1
    x[459]    c3001     1
    x[459]    OBJ       -1
    x[460]    c12       1
    x[460]    c3281     1
    x[460]    c3282     1
    x[460]    c3283     1
    x[460]    c3284     1
    x[460]    OBJ       -1
    x[461]    c13       1
    x[461]    c3564     1
    x[461]    c3565     1
    x[461]    c3566     1
    x[461]    c3567     1
    x[461]    OBJ       -1
    x[462]    c14       1
    x[462]    c3847     1
    x[462]    c3848     1
    x[462]    c3849     1
    x[462]    c3850     1
    x[462]    OBJ       -1
    x[463]    c15       1
    x[463]    c4130     1
    x[463]    c4131     1
    x[463]    c4132     1
    x[463]    c4133     1
    x[463]    OBJ       -1
    x[464]    c16       1
    x[464]    c4413     1
    x[464]    c4414     1
    x[464]    c4415     1
    x[464]    c4416     1
    x[464]    OBJ       -1
    x[465]    c1        1
    x[465]    c172      1
    x[465]    c173      1
    x[465]    c174      1
    x[465]    OBJ       -1
    x[466]    c2        1
    x[466]    c455      1
    x[466]    c456      1
    x[466]    c457      1
    x[466]    OBJ       -1
    x[467]    c3        1
    x[467]    c738      1
    x[467]    c739      1
    x[467]    c740      1
    x[467]    OBJ       -1
    x[468]    c4        1
    x[468]    c1021     1
    x[468]    c1022     1
    x[468]    c1023     1
    x[468]    OBJ       -1
    x[469]    c5        1
    x[469]    c1304     1
    x[469]    c1305     1
    x[469]    c1306     1
    x[469]    OBJ       -1
    x[470]    c6        1
    x[470]    c1587     1
    x[470]    c1588     1
    x[470]    c1589     1
    x[470]    OBJ       -1
    x[471]    c7        1
    x[471]    c1870     1
    x[471]    c1871     1
    x[471]    c1872     1
    x[471]    OBJ       -1
    x[472]    c8        1
    x[472]    c2153     1
    x[472]    c2154     1
    x[472]    c2155     1
    x[472]    OBJ       -1
    x[473]    c9        1
    x[473]    c2436     1
    x[473]    c2437     1
    x[473]    c2438     1
    x[473]    OBJ       -1
    x[474]    c10       1
    x[474]    c2719     1
    x[474]    c2720     1
    x[474]    c2721     1
    x[474]    OBJ       -1
    x[475]    c11       1
    x[475]    c3002     1
    x[475]    c3003     1
    x[475]    c3004     1
    x[475]    OBJ       -1
    x[476]    c12       1
    x[476]    c3285     1
    x[476]    c3286     1
    x[476]    c3287     1
    x[476]    OBJ       -1
    x[477]    c13       1
    x[477]    c3568     1
    x[477]    c3569     1
    x[477]    c3570     1
    x[477]    OBJ       -1
    x[478]    c14       1
    x[478]    c3851     1
    x[478]    c3852     1
    x[478]    c3853     1
    x[478]    OBJ       -1
    x[479]    c15       1
    x[479]    c4134     1
    x[479]    c4135     1
    x[479]    c4136     1
    x[479]    OBJ       -1
    x[480]    c16       1
    x[480]    c4417     1
    x[480]    c4418     1
    x[480]    c4419     1
    x[480]    OBJ       -1
    x[481]    c1        1
    x[481]    c175      1
    x[481]    c176      1
    x[481]    OBJ       -1
    x[482]    c2        1
    x[482]    c458      1
    x[482]    c459      1
    x[482]    OBJ       -1
    x[483]    c3        1
    x[483]    c741      1
    x[483]    c742      1
    x[483]    OBJ       -1
    x[484]    c4        1
    x[484]    c1024     1
    x[484]    c1025     1
    x[484]    OBJ       -1
    x[485]    c5        1
    x[485]    c1307     1
    x[485]    c1308     1
    x[485]    OBJ       -1
    x[486]    c6        1
    x[486]    c1590     1
    x[486]    c1591     1
    x[486]    OBJ       -1
    x[487]    c7        1
    x[487]    c1873     1
    x[487]    c1874     1
    x[487]    OBJ       -1
    x[488]    c8        1
    x[488]    c2156     1
    x[488]    c2157     1
    x[488]    OBJ       -1
    x[489]    c9        1
    x[489]    c2439     1
    x[489]    c2440     1
    x[489]    OBJ       -1
    x[490]    c10       1
    x[490]    c2722     1
    x[490]    c2723     1
    x[490]    OBJ       -1
    x[491]    c11       1
    x[491]    c3005     1
    x[491]    c3006     1
    x[491]    OBJ       -1
    x[492]    c12       1
    x[492]    c3288     1
    x[492]    c3289     1
    x[492]    OBJ       -1
    x[493]    c13       1
    x[493]    c3571     1
    x[493]    c3572     1
    x[493]    OBJ       -1
    x[494]    c14       1
    x[494]    c3854     1
    x[494]    c3855     1
    x[494]    OBJ       -1
    x[495]    c15       1
    x[495]    c4137     1
    x[495]    c4138     1
    x[495]    OBJ       -1
    x[496]    c16       1
    x[496]    c4420     1
    x[496]    c4421     1
    x[496]    OBJ       -1
    x[497]    c1        1
    x[497]    c177      1
    x[497]    OBJ       -1
    x[498]    c2        1
    x[498]    c460      1
    x[498]    OBJ       -1
    x[499]    c3        1
    x[499]    c743      1
    x[499]    OBJ       -1
    x[500]    c4        1
    x[500]    c1026     1
    x[500]    OBJ       -1
    x[501]    c5        1
    x[501]    c1309     1
    x[501]    OBJ       -1
    x[502]    c6        1
    x[502]    c1592     1
    x[502]    OBJ       -1
    x[503]    c7        1
    x[503]    c1875     1
    x[503]    OBJ       -1
    x[504]    c8        1
    x[504]    c2158     1
    x[504]    OBJ       -1
    x[505]    c9        1
    x[505]    c2441     1
    x[505]    OBJ       -1
    x[506]    c10       1
    x[506]    c2724     1
    x[506]    OBJ       -1
    x[507]    c11       1
    x[507]    c3007     1
    x[507]    OBJ       -1
    x[508]    c12       1
    x[508]    c3290     1
    x[508]    OBJ       -1
    x[509]    c13       1
    x[509]    c3573     1
    x[509]    OBJ       -1
    x[510]    c14       1
    x[510]    c3856     1
    x[510]    OBJ       -1
    x[511]    c15       1
    x[511]    c4139     1
    x[511]    OBJ       -1
    x[512]    c16       1
    x[512]    c4422     1
    x[512]    OBJ       -1
    x[513]    c1        1
    x[513]    c178      1
    x[513]    c179      1
    x[513]    OBJ       -1
    x[514]    c2        1
    x[514]    c461      1
    x[514]    c462      1
    x[514]    OBJ       -1
    x[515]    c3        1
    x[515]    c744      1
    x[515]    c745      1
    x[515]    OBJ       -1
    x[516]    c4        1
    x[516]    c1027     1
    x[516]    c1028     1
    x[516]    OBJ       -1
    x[517]    c5        1
    x[517]    c1310     1
    x[517]    c1311     1
    x[517]    OBJ       -1
    x[518]    c6        1
    x[518]    c1593     1
    x[518]    c1594     1
    x[518]    OBJ       -1
    x[519]    c7        1
    x[519]    c1876     1
    x[519]    c1877     1
    x[519]    OBJ       -1
    x[520]    c8        1
    x[520]    c2159     1
    x[520]    c2160     1
    x[520]    OBJ       -1
    x[521]    c9        1
    x[521]    c2442     1
    x[521]    c2443     1
    x[521]    OBJ       -1
    x[522]    c10       1
    x[522]    c2725     1
    x[522]    c2726     1
    x[522]    OBJ       -1
    x[523]    c11       1
    x[523]    c3008     1
    x[523]    c3009     1
    x[523]    OBJ       -1
    x[524]    c12       1
    x[524]    c3291     1
    x[524]    c3292     1
    x[524]    OBJ       -1
    x[525]    c13       1
    x[525]    c3574     1
    x[525]    c3575     1
    x[525]    OBJ       -1
    x[526]    c14       1
    x[526]    c3857     1
    x[526]    c3858     1
    x[526]    OBJ       -1
    x[527]    c15       1
    x[527]    c4140     1
    x[527]    c4141     1
    x[527]    OBJ       -1
    x[528]    c16       1
    x[528]    c4423     1
    x[528]    c4424     1
    x[528]    OBJ       -1
    x[529]    c1        1
    x[529]    c180      1
    x[529]    OBJ       -1
    x[530]    c2        1
    x[530]    c463      1
    x[530]    OBJ       -1
    x[531]    c3        1
    x[531]    c746      1
    x[531]    OBJ       -1
    x[532]    c4        1
    x[532]    c1029     1
    x[532]    OBJ       -1
    x[533]    c5        1
    x[533]    c1312     1
    x[533]    OBJ       -1
    x[534]    c6        1
    x[534]    c1595     1
    x[534]    OBJ       -1
    x[535]    c7        1
    x[535]    c1878     1
    x[535]    OBJ       -1
    x[536]    c8        1
    x[536]    c2161     1
    x[536]    OBJ       -1
    x[537]    c9        1
    x[537]    c2444     1
    x[537]    OBJ       -1
    x[538]    c10       1
    x[538]    c2727     1
    x[538]    OBJ       -1
    x[539]    c11       1
    x[539]    c3010     1
    x[539]    OBJ       -1
    x[540]    c12       1
    x[540]    c3293     1
    x[540]    OBJ       -1
    x[541]    c13       1
    x[541]    c3576     1
    x[541]    OBJ       -1
    x[542]    c14       1
    x[542]    c3859     1
    x[542]    OBJ       -1
    x[543]    c15       1
    x[543]    c4142     1
    x[543]    OBJ       -1
    x[544]    c16       1
    x[544]    c4425     1
    x[544]    OBJ       -1
    x[545]    c1        1
    x[545]    c181      1
    x[545]    c182      1
    x[545]    OBJ       -1
    x[546]    c2        1
    x[546]    c464      1
    x[546]    c465      1
    x[546]    OBJ       -1
    x[547]    c3        1
    x[547]    c747      1
    x[547]    c748      1
    x[547]    OBJ       -1
    x[548]    c4        1
    x[548]    c1030     1
    x[548]    c1031     1
    x[548]    OBJ       -1
    x[549]    c5        1
    x[549]    c1313     1
    x[549]    c1314     1
    x[549]    OBJ       -1
    x[550]    c6        1
    x[550]    c1596     1
    x[550]    c1597     1
    x[550]    OBJ       -1
    x[551]    c7        1
    x[551]    c1879     1
    x[551]    c1880     1
    x[551]    OBJ       -1
    x[552]    c8        1
    x[552]    c2162     1
    x[552]    c2163     1
    x[552]    OBJ       -1
    x[553]    c9        1
    x[553]    c2445     1
    x[553]    c2446     1
    x[553]    OBJ       -1
    x[554]    c10       1
    x[554]    c2728     1
    x[554]    c2729     1
    x[554]    OBJ       -1
    x[555]    c11       1
    x[555]    c3011     1
    x[555]    c3012     1
    x[555]    OBJ       -1
    x[556]    c12       1
    x[556]    c3294     1
    x[556]    c3295     1
    x[556]    OBJ       -1
    x[557]    c13       1
    x[557]    c3577     1
    x[557]    c3578     1
    x[557]    OBJ       -1
    x[558]    c14       1
    x[558]    c3860     1
    x[558]    c3861     1
    x[558]    OBJ       -1
    x[559]    c15       1
    x[559]    c4143     1
    x[559]    c4144     1
    x[559]    OBJ       -1
    x[560]    c16       1
    x[560]    c4426     1
    x[560]    c4427     1
    x[560]    OBJ       -1
    x[561]    c1        1
    x[561]    c183      1
    x[561]    OBJ       -1
    x[562]    c2        1
    x[562]    c466      1
    x[562]    OBJ       -1
    x[563]    c3        1
    x[563]    c749      1
    x[563]    OBJ       -1
    x[564]    c4        1
    x[564]    c1032     1
    x[564]    OBJ       -1
    x[565]    c5        1
    x[565]    c1315     1
    x[565]    OBJ       -1
    x[566]    c6        1
    x[566]    c1598     1
    x[566]    OBJ       -1
    x[567]    c7        1
    x[567]    c1881     1
    x[567]    OBJ       -1
    x[568]    c8        1
    x[568]    c2164     1
    x[568]    OBJ       -1
    x[569]    c9        1
    x[569]    c2447     1
    x[569]    OBJ       -1
    x[570]    c10       1
    x[570]    c2730     1
    x[570]    OBJ       -1
    x[571]    c11       1
    x[571]    c3013     1
    x[571]    OBJ       -1
    x[572]    c12       1
    x[572]    c3296     1
    x[572]    OBJ       -1
    x[573]    c13       1
    x[573]    c3579     1
    x[573]    OBJ       -1
    x[574]    c14       1
    x[574]    c3862     1
    x[574]    OBJ       -1
    x[575]    c15       1
    x[575]    c4145     1
    x[575]    OBJ       -1
    x[576]    c16       1
    x[576]    c4428     1
    x[576]    OBJ       -1
    x[577]    c1        1
    x[577]    c184      1
    x[577]    OBJ       -1
    x[578]    c2        1
    x[578]    c467      1
    x[578]    OBJ       -1
    x[579]    c3        1
    x[579]    c750      1
    x[579]    OBJ       -1
    x[580]    c4        1
    x[580]    c1033     1
    x[580]    OBJ       -1
    x[581]    c5        1
    x[581]    c1316     1
    x[581]    OBJ       -1
    x[582]    c6        1
    x[582]    c1599     1
    x[582]    OBJ       -1
    x[583]    c7        1
    x[583]    c1882     1
    x[583]    OBJ       -1
    x[584]    c8        1
    x[584]    c2165     1
    x[584]    OBJ       -1
    x[585]    c9        1
    x[585]    c2448     1
    x[585]    OBJ       -1
    x[586]    c10       1
    x[586]    c2731     1
    x[586]    OBJ       -1
    x[587]    c11       1
    x[587]    c3014     1
    x[587]    OBJ       -1
    x[588]    c12       1
    x[588]    c3297     1
    x[588]    OBJ       -1
    x[589]    c13       1
    x[589]    c3580     1
    x[589]    OBJ       -1
    x[590]    c14       1
    x[590]    c3863     1
    x[590]    OBJ       -1
    x[591]    c15       1
    x[591]    c4146     1
    x[591]    OBJ       -1
    x[592]    c16       1
    x[592]    c4429     1
    x[592]    OBJ       -1
    x[593]    c1        1
    x[593]    c185      1
    x[593]    c186      1
    x[593]    c187      1
    x[593]    OBJ       -1
    x[594]    c2        1
    x[594]    c468      1
    x[594]    c469      1
    x[594]    c470      1
    x[594]    OBJ       -1
    x[595]    c3        1
    x[595]    c751      1
    x[595]    c752      1
    x[595]    c753      1
    x[595]    OBJ       -1
    x[596]    c4        1
    x[596]    c1034     1
    x[596]    c1035     1
    x[596]    c1036     1
    x[596]    OBJ       -1
    x[597]    c5        1
    x[597]    c1317     1
    x[597]    c1318     1
    x[597]    c1319     1
    x[597]    OBJ       -1
    x[598]    c6        1
    x[598]    c1600     1
    x[598]    c1601     1
    x[598]    c1602     1
    x[598]    OBJ       -1
    x[599]    c7        1
    x[599]    c1883     1
    x[599]    c1884     1
    x[599]    c1885     1
    x[599]    OBJ       -1
    x[600]    c8        1
    x[600]    c2166     1
    x[600]    c2167     1
    x[600]    c2168     1
    x[600]    OBJ       -1
    x[601]    c9        1
    x[601]    c2449     1
    x[601]    c2450     1
    x[601]    c2451     1
    x[601]    OBJ       -1
    x[602]    c10       1
    x[602]    c2732     1
    x[602]    c2733     1
    x[602]    c2734     1
    x[602]    OBJ       -1
    x[603]    c11       1
    x[603]    c3015     1
    x[603]    c3016     1
    x[603]    c3017     1
    x[603]    OBJ       -1
    x[604]    c12       1
    x[604]    c3298     1
    x[604]    c3299     1
    x[604]    c3300     1
    x[604]    OBJ       -1
    x[605]    c13       1
    x[605]    c3581     1
    x[605]    c3582     1
    x[605]    c3583     1
    x[605]    OBJ       -1
    x[606]    c14       1
    x[606]    c3864     1
    x[606]    c3865     1
    x[606]    c3866     1
    x[606]    OBJ       -1
    x[607]    c15       1
    x[607]    c4147     1
    x[607]    c4148     1
    x[607]    c4149     1
    x[607]    OBJ       -1
    x[608]    c16       1
    x[608]    c4430     1
    x[608]    c4431     1
    x[608]    c4432     1
    x[608]    OBJ       -1
    x[609]    c1        1
    x[609]    c188      1
    x[609]    c189      1
    x[609]    OBJ       -1
    x[610]    c2        1
    x[610]    c471      1
    x[610]    c472      1
    x[610]    OBJ       -1
    x[611]    c3        1
    x[611]    c754      1
    x[611]    c755      1
    x[611]    OBJ       -1
    x[612]    c4        1
    x[612]    c1037     1
    x[612]    c1038     1
    x[612]    OBJ       -1
    x[613]    c5        1
    x[613]    c1320     1
    x[613]    c1321     1
    x[613]    OBJ       -1
    x[614]    c6        1
    x[614]    c1603     1
    x[614]    c1604     1
    x[614]    OBJ       -1
    x[615]    c7        1
    x[615]    c1886     1
    x[615]    c1887     1
    x[615]    OBJ       -1
    x[616]    c8        1
    x[616]    c2169     1
    x[616]    c2170     1
    x[616]    OBJ       -1
    x[617]    c9        1
    x[617]    c2452     1
    x[617]    c2453     1
    x[617]    OBJ       -1
    x[618]    c10       1
    x[618]    c2735     1
    x[618]    c2736     1
    x[618]    OBJ       -1
    x[619]    c11       1
    x[619]    c3018     1
    x[619]    c3019     1
    x[619]    OBJ       -1
    x[620]    c12       1
    x[620]    c3301     1
    x[620]    c3302     1
    x[620]    OBJ       -1
    x[621]    c13       1
    x[621]    c3584     1
    x[621]    c3585     1
    x[621]    OBJ       -1
    x[622]    c14       1
    x[622]    c3867     1
    x[622]    c3868     1
    x[622]    OBJ       -1
    x[623]    c15       1
    x[623]    c4150     1
    x[623]    c4151     1
    x[623]    OBJ       -1
    x[624]    c16       1
    x[624]    c4433     1
    x[624]    c4434     1
    x[624]    OBJ       -1
    x[625]    c1        1
    x[625]    c190      1
    x[625]    OBJ       -1
    x[626]    c2        1
    x[626]    c473      1
    x[626]    OBJ       -1
    x[627]    c3        1
    x[627]    c756      1
    x[627]    OBJ       -1
    x[628]    c4        1
    x[628]    c1039     1
    x[628]    OBJ       -1
    x[629]    c5        1
    x[629]    c1322     1
    x[629]    OBJ       -1
    x[630]    c6        1
    x[630]    c1605     1
    x[630]    OBJ       -1
    x[631]    c7        1
    x[631]    c1888     1
    x[631]    OBJ       -1
    x[632]    c8        1
    x[632]    c2171     1
    x[632]    OBJ       -1
    x[633]    c9        1
    x[633]    c2454     1
    x[633]    OBJ       -1
    x[634]    c10       1
    x[634]    c2737     1
    x[634]    OBJ       -1
    x[635]    c11       1
    x[635]    c3020     1
    x[635]    OBJ       -1
    x[636]    c12       1
    x[636]    c3303     1
    x[636]    OBJ       -1
    x[637]    c13       1
    x[637]    c3586     1
    x[637]    OBJ       -1
    x[638]    c14       1
    x[638]    c3869     1
    x[638]    OBJ       -1
    x[639]    c15       1
    x[639]    c4152     1
    x[639]    OBJ       -1
    x[640]    c16       1
    x[640]    c4435     1
    x[640]    OBJ       -1
    x[641]    c1        1
    x[641]    c191      1
    x[641]    c192      1
    x[641]    c193      1
    x[641]    c194      1
    x[641]    OBJ       -1
    x[642]    c2        1
    x[642]    c474      1
    x[642]    c475      1
    x[642]    c476      1
    x[642]    c477      1
    x[642]    OBJ       -1
    x[643]    c3        1
    x[643]    c757      1
    x[643]    c758      1
    x[643]    c759      1
    x[643]    c760      1
    x[643]    OBJ       -1
    x[644]    c4        1
    x[644]    c1040     1
    x[644]    c1041     1
    x[644]    c1042     1
    x[644]    c1043     1
    x[644]    OBJ       -1
    x[645]    c5        1
    x[645]    c1323     1
    x[645]    c1324     1
    x[645]    c1325     1
    x[645]    c1326     1
    x[645]    OBJ       -1
    x[646]    c6        1
    x[646]    c1606     1
    x[646]    c1607     1
    x[646]    c1608     1
    x[646]    c1609     1
    x[646]    OBJ       -1
    x[647]    c7        1
    x[647]    c1889     1
    x[647]    c1890     1
    x[647]    c1891     1
    x[647]    c1892     1
    x[647]    OBJ       -1
    x[648]    c8        1
    x[648]    c2172     1
    x[648]    c2173     1
    x[648]    c2174     1
    x[648]    c2175     1
    x[648]    OBJ       -1
    x[649]    c9        1
    x[649]    c2455     1
    x[649]    c2456     1
    x[649]    c2457     1
    x[649]    c2458     1
    x[649]    OBJ       -1
    x[650]    c10       1
    x[650]    c2738     1
    x[650]    c2739     1
    x[650]    c2740     1
    x[650]    c2741     1
    x[650]    OBJ       -1
    x[651]    c11       1
    x[651]    c3021     1
    x[651]    c3022     1
    x[651]    c3023     1
    x[651]    c3024     1
    x[651]    OBJ       -1
    x[652]    c12       1
    x[652]    c3304     1
    x[652]    c3305     1
    x[652]    c3306     1
    x[652]    c3307     1
    x[652]    OBJ       -1
    x[653]    c13       1
    x[653]    c3587     1
    x[653]    c3588     1
    x[653]    c3589     1
    x[653]    c3590     1
    x[653]    OBJ       -1
    x[654]    c14       1
    x[654]    c3870     1
    x[654]    c3871     1
    x[654]    c3872     1
    x[654]    c3873     1
    x[654]    OBJ       -1
    x[655]    c15       1
    x[655]    c4153     1
    x[655]    c4154     1
    x[655]    c4155     1
    x[655]    c4156     1
    x[655]    OBJ       -1
    x[656]    c16       1
    x[656]    c4436     1
    x[656]    c4437     1
    x[656]    c4438     1
    x[656]    c4439     1
    x[656]    OBJ       -1
    x[657]    c1        1
    x[657]    c195      1
    x[657]    c196      1
    x[657]    c197      1
    x[657]    c198      1
    x[657]    c199      1
    x[657]    c200      1
    x[657]    OBJ       -1
    x[658]    c2        1
    x[658]    c478      1
    x[658]    c479      1
    x[658]    c480      1
    x[658]    c481      1
    x[658]    c482      1
    x[658]    c483      1
    x[658]    OBJ       -1
    x[659]    c3        1
    x[659]    c761      1
    x[659]    c762      1
    x[659]    c763      1
    x[659]    c764      1
    x[659]    c765      1
    x[659]    c766      1
    x[659]    OBJ       -1
    x[660]    c4        1
    x[660]    c1044     1
    x[660]    c1045     1
    x[660]    c1046     1
    x[660]    c1047     1
    x[660]    c1048     1
    x[660]    c1049     1
    x[660]    OBJ       -1
    x[661]    c5        1
    x[661]    c1327     1
    x[661]    c1328     1
    x[661]    c1329     1
    x[661]    c1330     1
    x[661]    c1331     1
    x[661]    c1332     1
    x[661]    OBJ       -1
    x[662]    c6        1
    x[662]    c1610     1
    x[662]    c1611     1
    x[662]    c1612     1
    x[662]    c1613     1
    x[662]    c1614     1
    x[662]    c1615     1
    x[662]    OBJ       -1
    x[663]    c7        1
    x[663]    c1893     1
    x[663]    c1894     1
    x[663]    c1895     1
    x[663]    c1896     1
    x[663]    c1897     1
    x[663]    c1898     1
    x[663]    OBJ       -1
    x[664]    c8        1
    x[664]    c2176     1
    x[664]    c2177     1
    x[664]    c2178     1
    x[664]    c2179     1
    x[664]    c2180     1
    x[664]    c2181     1
    x[664]    OBJ       -1
    x[665]    c9        1
    x[665]    c2459     1
    x[665]    c2460     1
    x[665]    c2461     1
    x[665]    c2462     1
    x[665]    c2463     1
    x[665]    c2464     1
    x[665]    OBJ       -1
    x[666]    c10       1
    x[666]    c2742     1
    x[666]    c2743     1
    x[666]    c2744     1
    x[666]    c2745     1
    x[666]    c2746     1
    x[666]    c2747     1
    x[666]    OBJ       -1
    x[667]    c11       1
    x[667]    c3025     1
    x[667]    c3026     1
    x[667]    c3027     1
    x[667]    c3028     1
    x[667]    c3029     1
    x[667]    c3030     1
    x[667]    OBJ       -1
    x[668]    c12       1
    x[668]    c3308     1
    x[668]    c3309     1
    x[668]    c3310     1
    x[668]    c3311     1
    x[668]    c3312     1
    x[668]    c3313     1
    x[668]    OBJ       -1
    x[669]    c13       1
    x[669]    c3591     1
    x[669]    c3592     1
    x[669]    c3593     1
    x[669]    c3594     1
    x[669]    c3595     1
    x[669]    c3596     1
    x[669]    OBJ       -1
    x[670]    c14       1
    x[670]    c3874     1
    x[670]    c3875     1
    x[670]    c3876     1
    x[670]    c3877     1
    x[670]    c3878     1
    x[670]    c3879     1
    x[670]    OBJ       -1
    x[671]    c15       1
    x[671]    c4157     1
    x[671]    c4158     1
    x[671]    c4159     1
    x[671]    c4160     1
    x[671]    c4161     1
    x[671]    c4162     1
    x[671]    OBJ       -1
    x[672]    c16       1
    x[672]    c4440     1
    x[672]    c4441     1
    x[672]    c4442     1
    x[672]    c4443     1
    x[672]    c4444     1
    x[672]    c4445     1
    x[672]    OBJ       -1
    x[673]    c1        1
    x[673]    c201      1
    x[673]    OBJ       -1
    x[674]    c2        1
    x[674]    c484      1
    x[674]    OBJ       -1
    x[675]    c3        1
    x[675]    c767      1
    x[675]    OBJ       -1
    x[676]    c4        1
    x[676]    c1050     1
    x[676]    OBJ       -1
    x[677]    c5        1
    x[677]    c1333     1
    x[677]    OBJ       -1
    x[678]    c6        1
    x[678]    c1616     1
    x[678]    OBJ       -1
    x[679]    c7        1
    x[679]    c1899     1
    x[679]    OBJ       -1
    x[680]    c8        1
    x[680]    c2182     1
    x[680]    OBJ       -1
    x[681]    c9        1
    x[681]    c2465     1
    x[681]    OBJ       -1
    x[682]    c10       1
    x[682]    c2748     1
    x[682]    OBJ       -1
    x[683]    c11       1
    x[683]    c3031     1
    x[683]    OBJ       -1
    x[684]    c12       1
    x[684]    c3314     1
    x[684]    OBJ       -1
    x[685]    c13       1
    x[685]    c3597     1
    x[685]    OBJ       -1
    x[686]    c14       1
    x[686]    c3880     1
    x[686]    OBJ       -1
    x[687]    c15       1
    x[687]    c4163     1
    x[687]    OBJ       -1
    x[688]    c16       1
    x[688]    c4446     1
    x[688]    OBJ       -1
    x[689]    c1        1
    x[689]    c202      1
    x[689]    OBJ       -1
    x[690]    c2        1
    x[690]    c485      1
    x[690]    OBJ       -1
    x[691]    c3        1
    x[691]    c768      1
    x[691]    OBJ       -1
    x[692]    c4        1
    x[692]    c1051     1
    x[692]    OBJ       -1
    x[693]    c5        1
    x[693]    c1334     1
    x[693]    OBJ       -1
    x[694]    c6        1
    x[694]    c1617     1
    x[694]    OBJ       -1
    x[695]    c7        1
    x[695]    c1900     1
    x[695]    OBJ       -1
    x[696]    c8        1
    x[696]    c2183     1
    x[696]    OBJ       -1
    x[697]    c9        1
    x[697]    c2466     1
    x[697]    OBJ       -1
    x[698]    c10       1
    x[698]    c2749     1
    x[698]    OBJ       -1
    x[699]    c11       1
    x[699]    c3032     1
    x[699]    OBJ       -1
    x[700]    c12       1
    x[700]    c3315     1
    x[700]    OBJ       -1
    x[701]    c13       1
    x[701]    c3598     1
    x[701]    OBJ       -1
    x[702]    c14       1
    x[702]    c3881     1
    x[702]    OBJ       -1
    x[703]    c15       1
    x[703]    c4164     1
    x[703]    OBJ       -1
    x[704]    c16       1
    x[704]    c4447     1
    x[704]    OBJ       -1
    x[705]    c1        1
    x[705]    c203      1
    x[705]    c204      1
    x[705]    OBJ       -1
    x[706]    c2        1
    x[706]    c486      1
    x[706]    c487      1
    x[706]    OBJ       -1
    x[707]    c3        1
    x[707]    c769      1
    x[707]    c770      1
    x[707]    OBJ       -1
    x[708]    c4        1
    x[708]    c1052     1
    x[708]    c1053     1
    x[708]    OBJ       -1
    x[709]    c5        1
    x[709]    c1335     1
    x[709]    c1336     1
    x[709]    OBJ       -1
    x[710]    c6        1
    x[710]    c1618     1
    x[710]    c1619     1
    x[710]    OBJ       -1
    x[711]    c7        1
    x[711]    c1901     1
    x[711]    c1902     1
    x[711]    OBJ       -1
    x[712]    c8        1
    x[712]    c2184     1
    x[712]    c2185     1
    x[712]    OBJ       -1
    x[713]    c9        1
    x[713]    c2467     1
    x[713]    c2468     1
    x[713]    OBJ       -1
    x[714]    c10       1
    x[714]    c2750     1
    x[714]    c2751     1
    x[714]    OBJ       -1
    x[715]    c11       1
    x[715]    c3033     1
    x[715]    c3034     1
    x[715]    OBJ       -1
    x[716]    c12       1
    x[716]    c3316     1
    x[716]    c3317     1
    x[716]    OBJ       -1
    x[717]    c13       1
    x[717]    c3599     1
    x[717]    c3600     1
    x[717]    OBJ       -1
    x[718]    c14       1
    x[718]    c3882     1
    x[718]    c3883     1
    x[718]    OBJ       -1
    x[719]    c15       1
    x[719]    c4165     1
    x[719]    c4166     1
    x[719]    OBJ       -1
    x[720]    c16       1
    x[720]    c4448     1
    x[720]    c4449     1
    x[720]    OBJ       -1
    x[721]    c1        1
    x[721]    c205      1
    x[721]    c206      1
    x[721]    c207      1
    x[721]    c208      1
    x[721]    OBJ       -1
    x[722]    c2        1
    x[722]    c488      1
    x[722]    c489      1
    x[722]    c490      1
    x[722]    c491      1
    x[722]    OBJ       -1
    x[723]    c3        1
    x[723]    c771      1
    x[723]    c772      1
    x[723]    c773      1
    x[723]    c774      1
    x[723]    OBJ       -1
    x[724]    c4        1
    x[724]    c1054     1
    x[724]    c1055     1
    x[724]    c1056     1
    x[724]    c1057     1
    x[724]    OBJ       -1
    x[725]    c5        1
    x[725]    c1337     1
    x[725]    c1338     1
    x[725]    c1339     1
    x[725]    c1340     1
    x[725]    OBJ       -1
    x[726]    c6        1
    x[726]    c1620     1
    x[726]    c1621     1
    x[726]    c1622     1
    x[726]    c1623     1
    x[726]    OBJ       -1
    x[727]    c7        1
    x[727]    c1903     1
    x[727]    c1904     1
    x[727]    c1905     1
    x[727]    c1906     1
    x[727]    OBJ       -1
    x[728]    c8        1
    x[728]    c2186     1
    x[728]    c2187     1
    x[728]    c2188     1
    x[728]    c2189     1
    x[728]    OBJ       -1
    x[729]    c9        1
    x[729]    c2469     1
    x[729]    c2470     1
    x[729]    c2471     1
    x[729]    c2472     1
    x[729]    OBJ       -1
    x[730]    c10       1
    x[730]    c2752     1
    x[730]    c2753     1
    x[730]    c2754     1
    x[730]    c2755     1
    x[730]    OBJ       -1
    x[731]    c11       1
    x[731]    c3035     1
    x[731]    c3036     1
    x[731]    c3037     1
    x[731]    c3038     1
    x[731]    OBJ       -1
    x[732]    c12       1
    x[732]    c3318     1
    x[732]    c3319     1
    x[732]    c3320     1
    x[732]    c3321     1
    x[732]    OBJ       -1
    x[733]    c13       1
    x[733]    c3601     1
    x[733]    c3602     1
    x[733]    c3603     1
    x[733]    c3604     1
    x[733]    OBJ       -1
    x[734]    c14       1
    x[734]    c3884     1
    x[734]    c3885     1
    x[734]    c3886     1
    x[734]    c3887     1
    x[734]    OBJ       -1
    x[735]    c15       1
    x[735]    c4167     1
    x[735]    c4168     1
    x[735]    c4169     1
    x[735]    c4170     1
    x[735]    OBJ       -1
    x[736]    c16       1
    x[736]    c4450     1
    x[736]    c4451     1
    x[736]    c4452     1
    x[736]    c4453     1
    x[736]    OBJ       -1
    x[737]    c1        1
    x[737]    c209      1
    x[737]    OBJ       -1
    x[738]    c2        1
    x[738]    c492      1
    x[738]    OBJ       -1
    x[739]    c3        1
    x[739]    c775      1
    x[739]    OBJ       -1
    x[740]    c4        1
    x[740]    c1058     1
    x[740]    OBJ       -1
    x[741]    c5        1
    x[741]    c1341     1
    x[741]    OBJ       -1
    x[742]    c6        1
    x[742]    c1624     1
    x[742]    OBJ       -1
    x[743]    c7        1
    x[743]    c1907     1
    x[743]    OBJ       -1
    x[744]    c8        1
    x[744]    c2190     1
    x[744]    OBJ       -1
    x[745]    c9        1
    x[745]    c2473     1
    x[745]    OBJ       -1
    x[746]    c10       1
    x[746]    c2756     1
    x[746]    OBJ       -1
    x[747]    c11       1
    x[747]    c3039     1
    x[747]    OBJ       -1
    x[748]    c12       1
    x[748]    c3322     1
    x[748]    OBJ       -1
    x[749]    c13       1
    x[749]    c3605     1
    x[749]    OBJ       -1
    x[750]    c14       1
    x[750]    c3888     1
    x[750]    OBJ       -1
    x[751]    c15       1
    x[751]    c4171     1
    x[751]    OBJ       -1
    x[752]    c16       1
    x[752]    c4454     1
    x[752]    OBJ       -1
    x[753]    c1        1
    x[753]    c210      1
    x[753]    c211      1
    x[753]    OBJ       -1
    x[754]    c2        1
    x[754]    c493      1
    x[754]    c494      1
    x[754]    OBJ       -1
    x[755]    c3        1
    x[755]    c776      1
    x[755]    c777      1
    x[755]    OBJ       -1
    x[756]    c4        1
    x[756]    c1059     1
    x[756]    c1060     1
    x[756]    OBJ       -1
    x[757]    c5        1
    x[757]    c1342     1
    x[757]    c1343     1
    x[757]    OBJ       -1
    x[758]    c6        1
    x[758]    c1625     1
    x[758]    c1626     1
    x[758]    OBJ       -1
    x[759]    c7        1
    x[759]    c1908     1
    x[759]    c1909     1
    x[759]    OBJ       -1
    x[760]    c8        1
    x[760]    c2191     1
    x[760]    c2192     1
    x[760]    OBJ       -1
    x[761]    c9        1
    x[761]    c2474     1
    x[761]    c2475     1
    x[761]    OBJ       -1
    x[762]    c10       1
    x[762]    c2757     1
    x[762]    c2758     1
    x[762]    OBJ       -1
    x[763]    c11       1
    x[763]    c3040     1
    x[763]    c3041     1
    x[763]    OBJ       -1
    x[764]    c12       1
    x[764]    c3323     1
    x[764]    c3324     1
    x[764]    OBJ       -1
    x[765]    c13       1
    x[765]    c3606     1
    x[765]    c3607     1
    x[765]    OBJ       -1
    x[766]    c14       1
    x[766]    c3889     1
    x[766]    c3890     1
    x[766]    OBJ       -1
    x[767]    c15       1
    x[767]    c4172     1
    x[767]    c4173     1
    x[767]    OBJ       -1
    x[768]    c16       1
    x[768]    c4455     1
    x[768]    c4456     1
    x[768]    OBJ       -1
    x[769]    c1        1
    x[769]    c212      1
    x[769]    c213      1
    x[769]    OBJ       -1
    x[770]    c2        1
    x[770]    c495      1
    x[770]    c496      1
    x[770]    OBJ       -1
    x[771]    c3        1
    x[771]    c778      1
    x[771]    c779      1
    x[771]    OBJ       -1
    x[772]    c4        1
    x[772]    c1061     1
    x[772]    c1062     1
    x[772]    OBJ       -1
    x[773]    c5        1
    x[773]    c1344     1
    x[773]    c1345     1
    x[773]    OBJ       -1
    x[774]    c6        1
    x[774]    c1627     1
    x[774]    c1628     1
    x[774]    OBJ       -1
    x[775]    c7        1
    x[775]    c1910     1
    x[775]    c1911     1
    x[775]    OBJ       -1
    x[776]    c8        1
    x[776]    c2193     1
    x[776]    c2194     1
    x[776]    OBJ       -1
    x[777]    c9        1
    x[777]    c2476     1
    x[777]    c2477     1
    x[777]    OBJ       -1
    x[778]    c10       1
    x[778]    c2759     1
    x[778]    c2760     1
    x[778]    OBJ       -1
    x[779]    c11       1
    x[779]    c3042     1
    x[779]    c3043     1
    x[779]    OBJ       -1
    x[780]    c12       1
    x[780]    c3325     1
    x[780]    c3326     1
    x[780]    OBJ       -1
    x[781]    c13       1
    x[781]    c3608     1
    x[781]    c3609     1
    x[781]    OBJ       -1
    x[782]    c14       1
    x[782]    c3891     1
    x[782]    c3892     1
    x[782]    OBJ       -1
    x[783]    c15       1
    x[783]    c4174     1
    x[783]    c4175     1
    x[783]    OBJ       -1
    x[784]    c16       1
    x[784]    c4457     1
    x[784]    c4458     1
    x[784]    OBJ       -1
    x[785]    c1        1
    x[785]    c214      1
    x[785]    c215      1
    x[785]    OBJ       -1
    x[786]    c2        1
    x[786]    c497      1
    x[786]    c498      1
    x[786]    OBJ       -1
    x[787]    c3        1
    x[787]    c780      1
    x[787]    c781      1
    x[787]    OBJ       -1
    x[788]    c4        1
    x[788]    c1063     1
    x[788]    c1064     1
    x[788]    OBJ       -1
    x[789]    c5        1
    x[789]    c1346     1
    x[789]    c1347     1
    x[789]    OBJ       -1
    x[790]    c6        1
    x[790]    c1629     1
    x[790]    c1630     1
    x[790]    OBJ       -1
    x[791]    c7        1
    x[791]    c1912     1
    x[791]    c1913     1
    x[791]    OBJ       -1
    x[792]    c8        1
    x[792]    c2195     1
    x[792]    c2196     1
    x[792]    OBJ       -1
    x[793]    c9        1
    x[793]    c2478     1
    x[793]    c2479     1
    x[793]    OBJ       -1
    x[794]    c10       1
    x[794]    c2761     1
    x[794]    c2762     1
    x[794]    OBJ       -1
    x[795]    c11       1
    x[795]    c3044     1
    x[795]    c3045     1
    x[795]    OBJ       -1
    x[796]    c12       1
    x[796]    c3327     1
    x[796]    c3328     1
    x[796]    OBJ       -1
    x[797]    c13       1
    x[797]    c3610     1
    x[797]    c3611     1
    x[797]    OBJ       -1
    x[798]    c14       1
    x[798]    c3893     1
    x[798]    c3894     1
    x[798]    OBJ       -1
    x[799]    c15       1
    x[799]    c4176     1
    x[799]    c4177     1
    x[799]    OBJ       -1
    x[800]    c16       1
    x[800]    c4459     1
    x[800]    c4460     1
    x[800]    OBJ       -1
    x[801]    c1        1
    x[801]    c216      1
    x[801]    OBJ       -1
    x[802]    c2        1
    x[802]    c499      1
    x[802]    OBJ       -1
    x[803]    c3        1
    x[803]    c782      1
    x[803]    OBJ       -1
    x[804]    c4        1
    x[804]    c1065     1
    x[804]    OBJ       -1
    x[805]    c5        1
    x[805]    c1348     1
    x[805]    OBJ       -1
    x[806]    c6        1
    x[806]    c1631     1
    x[806]    OBJ       -1
    x[807]    c7        1
    x[807]    c1914     1
    x[807]    OBJ       -1
    x[808]    c8        1
    x[808]    c2197     1
    x[808]    OBJ       -1
    x[809]    c9        1
    x[809]    c2480     1
    x[809]    OBJ       -1
    x[810]    c10       1
    x[810]    c2763     1
    x[810]    OBJ       -1
    x[811]    c11       1
    x[811]    c3046     1
    x[811]    OBJ       -1
    x[812]    c12       1
    x[812]    c3329     1
    x[812]    OBJ       -1
    x[813]    c13       1
    x[813]    c3612     1
    x[813]    OBJ       -1
    x[814]    c14       1
    x[814]    c3895     1
    x[814]    OBJ       -1
    x[815]    c15       1
    x[815]    c4178     1
    x[815]    OBJ       -1
    x[816]    c16       1
    x[816]    c4461     1
    x[816]    OBJ       -1
    x[817]    c1        1
    x[817]    c217      1
    x[817]    c218      1
    x[817]    c219      1
    x[817]    OBJ       -1
    x[818]    c2        1
    x[818]    c500      1
    x[818]    c501      1
    x[818]    c502      1
    x[818]    OBJ       -1
    x[819]    c3        1
    x[819]    c783      1
    x[819]    c784      1
    x[819]    c785      1
    x[819]    OBJ       -1
    x[820]    c4        1
    x[820]    c1066     1
    x[820]    c1067     1
    x[820]    c1068     1
    x[820]    OBJ       -1
    x[821]    c5        1
    x[821]    c1349     1
    x[821]    c1350     1
    x[821]    c1351     1
    x[821]    OBJ       -1
    x[822]    c6        1
    x[822]    c1632     1
    x[822]    c1633     1
    x[822]    c1634     1
    x[822]    OBJ       -1
    x[823]    c7        1
    x[823]    c1915     1
    x[823]    c1916     1
    x[823]    c1917     1
    x[823]    OBJ       -1
    x[824]    c8        1
    x[824]    c2198     1
    x[824]    c2199     1
    x[824]    c2200     1
    x[824]    OBJ       -1
    x[825]    c9        1
    x[825]    c2481     1
    x[825]    c2482     1
    x[825]    c2483     1
    x[825]    OBJ       -1
    x[826]    c10       1
    x[826]    c2764     1
    x[826]    c2765     1
    x[826]    c2766     1
    x[826]    OBJ       -1
    x[827]    c11       1
    x[827]    c3047     1
    x[827]    c3048     1
    x[827]    c3049     1
    x[827]    OBJ       -1
    x[828]    c12       1
    x[828]    c3330     1
    x[828]    c3331     1
    x[828]    c3332     1
    x[828]    OBJ       -1
    x[829]    c13       1
    x[829]    c3613     1
    x[829]    c3614     1
    x[829]    c3615     1
    x[829]    OBJ       -1
    x[830]    c14       1
    x[830]    c3896     1
    x[830]    c3897     1
    x[830]    c3898     1
    x[830]    OBJ       -1
    x[831]    c15       1
    x[831]    c4179     1
    x[831]    c4180     1
    x[831]    c4181     1
    x[831]    OBJ       -1
    x[832]    c16       1
    x[832]    c4462     1
    x[832]    c4463     1
    x[832]    c4464     1
    x[832]    OBJ       -1
    x[833]    c1        1
    x[833]    c220      1
    x[833]    c221      1
    x[833]    c222      1
    x[833]    c223      1
    x[833]    OBJ       -1
    x[834]    c2        1
    x[834]    c503      1
    x[834]    c504      1
    x[834]    c505      1
    x[834]    c506      1
    x[834]    OBJ       -1
    x[835]    c3        1
    x[835]    c786      1
    x[835]    c787      1
    x[835]    c788      1
    x[835]    c789      1
    x[835]    OBJ       -1
    x[836]    c4        1
    x[836]    c1069     1
    x[836]    c1070     1
    x[836]    c1071     1
    x[836]    c1072     1
    x[836]    OBJ       -1
    x[837]    c5        1
    x[837]    c1352     1
    x[837]    c1353     1
    x[837]    c1354     1
    x[837]    c1355     1
    x[837]    OBJ       -1
    x[838]    c6        1
    x[838]    c1635     1
    x[838]    c1636     1
    x[838]    c1637     1
    x[838]    c1638     1
    x[838]    OBJ       -1
    x[839]    c7        1
    x[839]    c1918     1
    x[839]    c1919     1
    x[839]    c1920     1
    x[839]    c1921     1
    x[839]    OBJ       -1
    x[840]    c8        1
    x[840]    c2201     1
    x[840]    c2202     1
    x[840]    c2203     1
    x[840]    c2204     1
    x[840]    OBJ       -1
    x[841]    c9        1
    x[841]    c2484     1
    x[841]    c2485     1
    x[841]    c2486     1
    x[841]    c2487     1
    x[841]    OBJ       -1
    x[842]    c10       1
    x[842]    c2767     1
    x[842]    c2768     1
    x[842]    c2769     1
    x[842]    c2770     1
    x[842]    OBJ       -1
    x[843]    c11       1
    x[843]    c3050     1
    x[843]    c3051     1
    x[843]    c3052     1
    x[843]    c3053     1
    x[843]    OBJ       -1
    x[844]    c12       1
    x[844]    c3333     1
    x[844]    c3334     1
    x[844]    c3335     1
    x[844]    c3336     1
    x[844]    OBJ       -1
    x[845]    c13       1
    x[845]    c3616     1
    x[845]    c3617     1
    x[845]    c3618     1
    x[845]    c3619     1
    x[845]    OBJ       -1
    x[846]    c14       1
    x[846]    c3899     1
    x[846]    c3900     1
    x[846]    c3901     1
    x[846]    c3902     1
    x[846]    OBJ       -1
    x[847]    c15       1
    x[847]    c4182     1
    x[847]    c4183     1
    x[847]    c4184     1
    x[847]    c4185     1
    x[847]    OBJ       -1
    x[848]    c16       1
    x[848]    c4465     1
    x[848]    c4466     1
    x[848]    c4467     1
    x[848]    c4468     1
    x[848]    OBJ       -1
    x[849]    c1        1
    x[849]    c224      1
    x[849]    c225      1
    x[849]    OBJ       -1
    x[850]    c2        1
    x[850]    c507      1
    x[850]    c508      1
    x[850]    OBJ       -1
    x[851]    c3        1
    x[851]    c790      1
    x[851]    c791      1
    x[851]    OBJ       -1
    x[852]    c4        1
    x[852]    c1073     1
    x[852]    c1074     1
    x[852]    OBJ       -1
    x[853]    c5        1
    x[853]    c1356     1
    x[853]    c1357     1
    x[853]    OBJ       -1
    x[854]    c6        1
    x[854]    c1639     1
    x[854]    c1640     1
    x[854]    OBJ       -1
    x[855]    c7        1
    x[855]    c1922     1
    x[855]    c1923     1
    x[855]    OBJ       -1
    x[856]    c8        1
    x[856]    c2205     1
    x[856]    c2206     1
    x[856]    OBJ       -1
    x[857]    c9        1
    x[857]    c2488     1
    x[857]    c2489     1
    x[857]    OBJ       -1
    x[858]    c10       1
    x[858]    c2771     1
    x[858]    c2772     1
    x[858]    OBJ       -1
    x[859]    c11       1
    x[859]    c3054     1
    x[859]    c3055     1
    x[859]    OBJ       -1
    x[860]    c12       1
    x[860]    c3337     1
    x[860]    c3338     1
    x[860]    OBJ       -1
    x[861]    c13       1
    x[861]    c3620     1
    x[861]    c3621     1
    x[861]    OBJ       -1
    x[862]    c14       1
    x[862]    c3903     1
    x[862]    c3904     1
    x[862]    OBJ       -1
    x[863]    c15       1
    x[863]    c4186     1
    x[863]    c4187     1
    x[863]    OBJ       -1
    x[864]    c16       1
    x[864]    c4469     1
    x[864]    c4470     1
    x[864]    OBJ       -1
    x[865]    c1        1
    x[865]    c226      1
    x[865]    OBJ       -1
    x[866]    c2        1
    x[866]    c509      1
    x[866]    OBJ       -1
    x[867]    c3        1
    x[867]    c792      1
    x[867]    OBJ       -1
    x[868]    c4        1
    x[868]    c1075     1
    x[868]    OBJ       -1
    x[869]    c5        1
    x[869]    c1358     1
    x[869]    OBJ       -1
    x[870]    c6        1
    x[870]    c1641     1
    x[870]    OBJ       -1
    x[871]    c7        1
    x[871]    c1924     1
    x[871]    OBJ       -1
    x[872]    c8        1
    x[872]    c2207     1
    x[872]    OBJ       -1
    x[873]    c9        1
    x[873]    c2490     1
    x[873]    OBJ       -1
    x[874]    c10       1
    x[874]    c2773     1
    x[874]    OBJ       -1
    x[875]    c11       1
    x[875]    c3056     1
    x[875]    OBJ       -1
    x[876]    c12       1
    x[876]    c3339     1
    x[876]    OBJ       -1
    x[877]    c13       1
    x[877]    c3622     1
    x[877]    OBJ       -1
    x[878]    c14       1
    x[878]    c3905     1
    x[878]    OBJ       -1
    x[879]    c15       1
    x[879]    c4188     1
    x[879]    OBJ       -1
    x[880]    c16       1
    x[880]    c4471     1
    x[880]    OBJ       -1
    x[881]    c1        1
    x[881]    c227      1
    x[881]    OBJ       -1
    x[882]    c2        1
    x[882]    c510      1
    x[882]    OBJ       -1
    x[883]    c3        1
    x[883]    c793      1
    x[883]    OBJ       -1
    x[884]    c4        1
    x[884]    c1076     1
    x[884]    OBJ       -1
    x[885]    c5        1
    x[885]    c1359     1
    x[885]    OBJ       -1
    x[886]    c6        1
    x[886]    c1642     1
    x[886]    OBJ       -1
    x[887]    c7        1
    x[887]    c1925     1
    x[887]    OBJ       -1
    x[888]    c8        1
    x[888]    c2208     1
    x[888]    OBJ       -1
    x[889]    c9        1
    x[889]    c2491     1
    x[889]    OBJ       -1
    x[890]    c10       1
    x[890]    c2774     1
    x[890]    OBJ       -1
    x[891]    c11       1
    x[891]    c3057     1
    x[891]    OBJ       -1
    x[892]    c12       1
    x[892]    c3340     1
    x[892]    OBJ       -1
    x[893]    c13       1
    x[893]    c3623     1
    x[893]    OBJ       -1
    x[894]    c14       1
    x[894]    c3906     1
    x[894]    OBJ       -1
    x[895]    c15       1
    x[895]    c4189     1
    x[895]    OBJ       -1
    x[896]    c16       1
    x[896]    c4472     1
    x[896]    OBJ       -1
    x[897]    c1        1
    x[897]    c228      1
    x[897]    c229      1
    x[897]    c230      1
    x[897]    c231      1
    x[897]    OBJ       -1
    x[898]    c2        1
    x[898]    c511      1
    x[898]    c512      1
    x[898]    c513      1
    x[898]    c514      1
    x[898]    OBJ       -1
    x[899]    c3        1
    x[899]    c794      1
    x[899]    c795      1
    x[899]    c796      1
    x[899]    c797      1
    x[899]    OBJ       -1
    x[900]    c4        1
    x[900]    c1077     1
    x[900]    c1078     1
    x[900]    c1079     1
    x[900]    c1080     1
    x[900]    OBJ       -1
    x[901]    c5        1
    x[901]    c1360     1
    x[901]    c1361     1
    x[901]    c1362     1
    x[901]    c1363     1
    x[901]    OBJ       -1
    x[902]    c6        1
    x[902]    c1643     1
    x[902]    c1644     1
    x[902]    c1645     1
    x[902]    c1646     1
    x[902]    OBJ       -1
    x[903]    c7        1
    x[903]    c1926     1
    x[903]    c1927     1
    x[903]    c1928     1
    x[903]    c1929     1
    x[903]    OBJ       -1
    x[904]    c8        1
    x[904]    c2209     1
    x[904]    c2210     1
    x[904]    c2211     1
    x[904]    c2212     1
    x[904]    OBJ       -1
    x[905]    c9        1
    x[905]    c2492     1
    x[905]    c2493     1
    x[905]    c2494     1
    x[905]    c2495     1
    x[905]    OBJ       -1
    x[906]    c10       1
    x[906]    c2775     1
    x[906]    c2776     1
    x[906]    c2777     1
    x[906]    c2778     1
    x[906]    OBJ       -1
    x[907]    c11       1
    x[907]    c3058     1
    x[907]    c3059     1
    x[907]    c3060     1
    x[907]    c3061     1
    x[907]    OBJ       -1
    x[908]    c12       1
    x[908]    c3341     1
    x[908]    c3342     1
    x[908]    c3343     1
    x[908]    c3344     1
    x[908]    OBJ       -1
    x[909]    c13       1
    x[909]    c3624     1
    x[909]    c3625     1
    x[909]    c3626     1
    x[909]    c3627     1
    x[909]    OBJ       -1
    x[910]    c14       1
    x[910]    c3907     1
    x[910]    c3908     1
    x[910]    c3909     1
    x[910]    c3910     1
    x[910]    OBJ       -1
    x[911]    c15       1
    x[911]    c4190     1
    x[911]    c4191     1
    x[911]    c4192     1
    x[911]    c4193     1
    x[911]    OBJ       -1
    x[912]    c16       1
    x[912]    c4473     1
    x[912]    c4474     1
    x[912]    c4475     1
    x[912]    c4476     1
    x[912]    OBJ       -1
    x[913]    c1        1
    x[913]    c232      1
    x[913]    c233      1
    x[913]    OBJ       -1
    x[914]    c2        1
    x[914]    c515      1
    x[914]    c516      1
    x[914]    OBJ       -1
    x[915]    c3        1
    x[915]    c798      1
    x[915]    c799      1
    x[915]    OBJ       -1
    x[916]    c4        1
    x[916]    c1081     1
    x[916]    c1082     1
    x[916]    OBJ       -1
    x[917]    c5        1
    x[917]    c1364     1
    x[917]    c1365     1
    x[917]    OBJ       -1
    x[918]    c6        1
    x[918]    c1647     1
    x[918]    c1648     1
    x[918]    OBJ       -1
    x[919]    c7        1
    x[919]    c1930     1
    x[919]    c1931     1
    x[919]    OBJ       -1
    x[920]    c8        1
    x[920]    c2213     1
    x[920]    c2214     1
    x[920]    OBJ       -1
    x[921]    c9        1
    x[921]    c2496     1
    x[921]    c2497     1
    x[921]    OBJ       -1
    x[922]    c10       1
    x[922]    c2779     1
    x[922]    c2780     1
    x[922]    OBJ       -1
    x[923]    c11       1
    x[923]    c3062     1
    x[923]    c3063     1
    x[923]    OBJ       -1
    x[924]    c12       1
    x[924]    c3345     1
    x[924]    c3346     1
    x[924]    OBJ       -1
    x[925]    c13       1
    x[925]    c3628     1
    x[925]    c3629     1
    x[925]    OBJ       -1
    x[926]    c14       1
    x[926]    c3911     1
    x[926]    c3912     1
    x[926]    OBJ       -1
    x[927]    c15       1
    x[927]    c4194     1
    x[927]    c4195     1
    x[927]    OBJ       -1
    x[928]    c16       1
    x[928]    c4477     1
    x[928]    c4478     1
    x[928]    OBJ       -1
    x[929]    c1        1
    x[929]    c234      1
    x[929]    c235      1
    x[929]    c236      1
    x[929]    OBJ       -1
    x[930]    c2        1
    x[930]    c517      1
    x[930]    c518      1
    x[930]    c519      1
    x[930]    OBJ       -1
    x[931]    c3        1
    x[931]    c800      1
    x[931]    c801      1
    x[931]    c802      1
    x[931]    OBJ       -1
    x[932]    c4        1
    x[932]    c1083     1
    x[932]    c1084     1
    x[932]    c1085     1
    x[932]    OBJ       -1
    x[933]    c5        1
    x[933]    c1366     1
    x[933]    c1367     1
    x[933]    c1368     1
    x[933]    OBJ       -1
    x[934]    c6        1
    x[934]    c1649     1
    x[934]    c1650     1
    x[934]    c1651     1
    x[934]    OBJ       -1
    x[935]    c7        1
    x[935]    c1932     1
    x[935]    c1933     1
    x[935]    c1934     1
    x[935]    OBJ       -1
    x[936]    c8        1
    x[936]    c2215     1
    x[936]    c2216     1
    x[936]    c2217     1
    x[936]    OBJ       -1
    x[937]    c9        1
    x[937]    c2498     1
    x[937]    c2499     1
    x[937]    c2500     1
    x[937]    OBJ       -1
    x[938]    c10       1
    x[938]    c2781     1
    x[938]    c2782     1
    x[938]    c2783     1
    x[938]    OBJ       -1
    x[939]    c11       1
    x[939]    c3064     1
    x[939]    c3065     1
    x[939]    c3066     1
    x[939]    OBJ       -1
    x[940]    c12       1
    x[940]    c3347     1
    x[940]    c3348     1
    x[940]    c3349     1
    x[940]    OBJ       -1
    x[941]    c13       1
    x[941]    c3630     1
    x[941]    c3631     1
    x[941]    c3632     1
    x[941]    OBJ       -1
    x[942]    c14       1
    x[942]    c3913     1
    x[942]    c3914     1
    x[942]    c3915     1
    x[942]    OBJ       -1
    x[943]    c15       1
    x[943]    c4196     1
    x[943]    c4197     1
    x[943]    c4198     1
    x[943]    OBJ       -1
    x[944]    c16       1
    x[944]    c4479     1
    x[944]    c4480     1
    x[944]    c4481     1
    x[944]    OBJ       -1
    x[945]    c1        1
    x[945]    c237      1
    x[945]    c238      1
    x[945]    c239      1
    x[945]    OBJ       -1
    x[946]    c2        1
    x[946]    c520      1
    x[946]    c521      1
    x[946]    c522      1
    x[946]    OBJ       -1
    x[947]    c3        1
    x[947]    c803      1
    x[947]    c804      1
    x[947]    c805      1
    x[947]    OBJ       -1
    x[948]    c4        1
    x[948]    c1086     1
    x[948]    c1087     1
    x[948]    c1088     1
    x[948]    OBJ       -1
    x[949]    c5        1
    x[949]    c1369     1
    x[949]    c1370     1
    x[949]    c1371     1
    x[949]    OBJ       -1
    x[950]    c6        1
    x[950]    c1652     1
    x[950]    c1653     1
    x[950]    c1654     1
    x[950]    OBJ       -1
    x[951]    c7        1
    x[951]    c1935     1
    x[951]    c1936     1
    x[951]    c1937     1
    x[951]    OBJ       -1
    x[952]    c8        1
    x[952]    c2218     1
    x[952]    c2219     1
    x[952]    c2220     1
    x[952]    OBJ       -1
    x[953]    c9        1
    x[953]    c2501     1
    x[953]    c2502     1
    x[953]    c2503     1
    x[953]    OBJ       -1
    x[954]    c10       1
    x[954]    c2784     1
    x[954]    c2785     1
    x[954]    c2786     1
    x[954]    OBJ       -1
    x[955]    c11       1
    x[955]    c3067     1
    x[955]    c3068     1
    x[955]    c3069     1
    x[955]    OBJ       -1
    x[956]    c12       1
    x[956]    c3350     1
    x[956]    c3351     1
    x[956]    c3352     1
    x[956]    OBJ       -1
    x[957]    c13       1
    x[957]    c3633     1
    x[957]    c3634     1
    x[957]    c3635     1
    x[957]    OBJ       -1
    x[958]    c14       1
    x[958]    c3916     1
    x[958]    c3917     1
    x[958]    c3918     1
    x[958]    OBJ       -1
    x[959]    c15       1
    x[959]    c4199     1
    x[959]    c4200     1
    x[959]    c4201     1
    x[959]    OBJ       -1
    x[960]    c16       1
    x[960]    c4482     1
    x[960]    c4483     1
    x[960]    c4484     1
    x[960]    OBJ       -1
    x[961]    c1        1
    x[961]    c240      1
    x[961]    c241      1
    x[961]    c242      1
    x[961]    c243      1
    x[961]    OBJ       -1
    x[962]    c2        1
    x[962]    c523      1
    x[962]    c524      1
    x[962]    c525      1
    x[962]    c526      1
    x[962]    OBJ       -1
    x[963]    c3        1
    x[963]    c806      1
    x[963]    c807      1
    x[963]    c808      1
    x[963]    c809      1
    x[963]    OBJ       -1
    x[964]    c4        1
    x[964]    c1089     1
    x[964]    c1090     1
    x[964]    c1091     1
    x[964]    c1092     1
    x[964]    OBJ       -1
    x[965]    c5        1
    x[965]    c1372     1
    x[965]    c1373     1
    x[965]    c1374     1
    x[965]    c1375     1
    x[965]    OBJ       -1
    x[966]    c6        1
    x[966]    c1655     1
    x[966]    c1656     1
    x[966]    c1657     1
    x[966]    c1658     1
    x[966]    OBJ       -1
    x[967]    c7        1
    x[967]    c1938     1
    x[967]    c1939     1
    x[967]    c1940     1
    x[967]    c1941     1
    x[967]    OBJ       -1
    x[968]    c8        1
    x[968]    c2221     1
    x[968]    c2222     1
    x[968]    c2223     1
    x[968]    c2224     1
    x[968]    OBJ       -1
    x[969]    c9        1
    x[969]    c2504     1
    x[969]    c2505     1
    x[969]    c2506     1
    x[969]    c2507     1
    x[969]    OBJ       -1
    x[970]    c10       1
    x[970]    c2787     1
    x[970]    c2788     1
    x[970]    c2789     1
    x[970]    c2790     1
    x[970]    OBJ       -1
    x[971]    c11       1
    x[971]    c3070     1
    x[971]    c3071     1
    x[971]    c3072     1
    x[971]    c3073     1
    x[971]    OBJ       -1
    x[972]    c12       1
    x[972]    c3353     1
    x[972]    c3354     1
    x[972]    c3355     1
    x[972]    c3356     1
    x[972]    OBJ       -1
    x[973]    c13       1
    x[973]    c3636     1
    x[973]    c3637     1
    x[973]    c3638     1
    x[973]    c3639     1
    x[973]    OBJ       -1
    x[974]    c14       1
    x[974]    c3919     1
    x[974]    c3920     1
    x[974]    c3921     1
    x[974]    c3922     1
    x[974]    OBJ       -1
    x[975]    c15       1
    x[975]    c4202     1
    x[975]    c4203     1
    x[975]    c4204     1
    x[975]    c4205     1
    x[975]    OBJ       -1
    x[976]    c16       1
    x[976]    c4485     1
    x[976]    c4486     1
    x[976]    c4487     1
    x[976]    c4488     1
    x[976]    OBJ       -1
    x[977]    c1        1
    x[977]    c244      1
    x[977]    c245      1
    x[977]    c246      1
    x[977]    OBJ       -1
    x[978]    c2        1
    x[978]    c527      1
    x[978]    c528      1
    x[978]    c529      1
    x[978]    OBJ       -1
    x[979]    c3        1
    x[979]    c810      1
    x[979]    c811      1
    x[979]    c812      1
    x[979]    OBJ       -1
    x[980]    c4        1
    x[980]    c1093     1
    x[980]    c1094     1
    x[980]    c1095     1
    x[980]    OBJ       -1
    x[981]    c5        1
    x[981]    c1376     1
    x[981]    c1377     1
    x[981]    c1378     1
    x[981]    OBJ       -1
    x[982]    c6        1
    x[982]    c1659     1
    x[982]    c1660     1
    x[982]    c1661     1
    x[982]    OBJ       -1
    x[983]    c7        1
    x[983]    c1942     1
    x[983]    c1943     1
    x[983]    c1944     1
    x[983]    OBJ       -1
    x[984]    c8        1
    x[984]    c2225     1
    x[984]    c2226     1
    x[984]    c2227     1
    x[984]    OBJ       -1
    x[985]    c9        1
    x[985]    c2508     1
    x[985]    c2509     1
    x[985]    c2510     1
    x[985]    OBJ       -1
    x[986]    c10       1
    x[986]    c2791     1
    x[986]    c2792     1
    x[986]    c2793     1
    x[986]    OBJ       -1
    x[987]    c11       1
    x[987]    c3074     1
    x[987]    c3075     1
    x[987]    c3076     1
    x[987]    OBJ       -1
    x[988]    c12       1
    x[988]    c3357     1
    x[988]    c3358     1
    x[988]    c3359     1
    x[988]    OBJ       -1
    x[989]    c13       1
    x[989]    c3640     1
    x[989]    c3641     1
    x[989]    c3642     1
    x[989]    OBJ       -1
    x[990]    c14       1
    x[990]    c3923     1
    x[990]    c3924     1
    x[990]    c3925     1
    x[990]    OBJ       -1
    x[991]    c15       1
    x[991]    c4206     1
    x[991]    c4207     1
    x[991]    c4208     1
    x[991]    OBJ       -1
    x[992]    c16       1
    x[992]    c4489     1
    x[992]    c4490     1
    x[992]    c4491     1
    x[992]    OBJ       -1
    x[993]    c1        1
    x[993]    c247      1
    x[993]    OBJ       -1
    x[994]    c2        1
    x[994]    c530      1
    x[994]    OBJ       -1
    x[995]    c3        1
    x[995]    c813      1
    x[995]    OBJ       -1
    x[996]    c4        1
    x[996]    c1096     1
    x[996]    OBJ       -1
    x[997]    c5        1
    x[997]    c1379     1
    x[997]    OBJ       -1
    x[998]    c6        1
    x[998]    c1662     1
    x[998]    OBJ       -1
    x[999]    c7        1
    x[999]    c1945     1
    x[999]    OBJ       -1
    x[1000]   c8        1
    x[1000]   c2228     1
    x[1000]   OBJ       -1
    x[1001]   c9        1
    x[1001]   c2511     1
    x[1001]   OBJ       -1
    x[1002]   c10       1
    x[1002]   c2794     1
    x[1002]   OBJ       -1
    x[1003]   c11       1
    x[1003]   c3077     1
    x[1003]   OBJ       -1
    x[1004]   c12       1
    x[1004]   c3360     1
    x[1004]   OBJ       -1
    x[1005]   c13       1
    x[1005]   c3643     1
    x[1005]   OBJ       -1
    x[1006]   c14       1
    x[1006]   c3926     1
    x[1006]   OBJ       -1
    x[1007]   c15       1
    x[1007]   c4209     1
    x[1007]   OBJ       -1
    x[1008]   c16       1
    x[1008]   c4492     1
    x[1008]   OBJ       -1
    x[1009]   c1        1
    x[1009]   c248      1
    x[1009]   OBJ       -1
    x[1010]   c2        1
    x[1010]   c531      1
    x[1010]   OBJ       -1
    x[1011]   c3        1
    x[1011]   c814      1
    x[1011]   OBJ       -1
    x[1012]   c4        1
    x[1012]   c1097     1
    x[1012]   OBJ       -1
    x[1013]   c5        1
    x[1013]   c1380     1
    x[1013]   OBJ       -1
    x[1014]   c6        1
    x[1014]   c1663     1
    x[1014]   OBJ       -1
    x[1015]   c7        1
    x[1015]   c1946     1
    x[1015]   OBJ       -1
    x[1016]   c8        1
    x[1016]   c2229     1
    x[1016]   OBJ       -1
    x[1017]   c9        1
    x[1017]   c2512     1
    x[1017]   OBJ       -1
    x[1018]   c10       1
    x[1018]   c2795     1
    x[1018]   OBJ       -1
    x[1019]   c11       1
    x[1019]   c3078     1
    x[1019]   OBJ       -1
    x[1020]   c12       1
    x[1020]   c3361     1
    x[1020]   OBJ       -1
    x[1021]   c13       1
    x[1021]   c3644     1
    x[1021]   OBJ       -1
    x[1022]   c14       1
    x[1022]   c3927     1
    x[1022]   OBJ       -1
    x[1023]   c15       1
    x[1023]   c4210     1
    x[1023]   OBJ       -1
    x[1024]   c16       1
    x[1024]   c4493     1
    x[1024]   OBJ       -1
    x[1025]   c1        1
    x[1025]   c249      1
    x[1025]   c250      1
    x[1025]   c251      1
    x[1025]   c252      1
    x[1025]   OBJ       -1
    x[1026]   c2        1
    x[1026]   c532      1
    x[1026]   c533      1
    x[1026]   c534      1
    x[1026]   c535      1
    x[1026]   OBJ       -1
    x[1027]   c3        1
    x[1027]   c815      1
    x[1027]   c816      1
    x[1027]   c817      1
    x[1027]   c818      1
    x[1027]   OBJ       -1
    x[1028]   c4        1
    x[1028]   c1098     1
    x[1028]   c1099     1
    x[1028]   c1100     1
    x[1028]   c1101     1
    x[1028]   OBJ       -1
    x[1029]   c5        1
    x[1029]   c1381     1
    x[1029]   c1382     1
    x[1029]   c1383     1
    x[1029]   c1384     1
    x[1029]   OBJ       -1
    x[1030]   c6        1
    x[1030]   c1664     1
    x[1030]   c1665     1
    x[1030]   c1666     1
    x[1030]   c1667     1
    x[1030]   OBJ       -1
    x[1031]   c7        1
    x[1031]   c1947     1
    x[1031]   c1948     1
    x[1031]   c1949     1
    x[1031]   c1950     1
    x[1031]   OBJ       -1
    x[1032]   c8        1
    x[1032]   c2230     1
    x[1032]   c2231     1
    x[1032]   c2232     1
    x[1032]   c2233     1
    x[1032]   OBJ       -1
    x[1033]   c9        1
    x[1033]   c2513     1
    x[1033]   c2514     1
    x[1033]   c2515     1
    x[1033]   c2516     1
    x[1033]   OBJ       -1
    x[1034]   c10       1
    x[1034]   c2796     1
    x[1034]   c2797     1
    x[1034]   c2798     1
    x[1034]   c2799     1
    x[1034]   OBJ       -1
    x[1035]   c11       1
    x[1035]   c3079     1
    x[1035]   c3080     1
    x[1035]   c3081     1
    x[1035]   c3082     1
    x[1035]   OBJ       -1
    x[1036]   c12       1
    x[1036]   c3362     1
    x[1036]   c3363     1
    x[1036]   c3364     1
    x[1036]   c3365     1
    x[1036]   OBJ       -1
    x[1037]   c13       1
    x[1037]   c3645     1
    x[1037]   c3646     1
    x[1037]   c3647     1
    x[1037]   c3648     1
    x[1037]   OBJ       -1
    x[1038]   c14       1
    x[1038]   c3928     1
    x[1038]   c3929     1
    x[1038]   c3930     1
    x[1038]   c3931     1
    x[1038]   OBJ       -1
    x[1039]   c15       1
    x[1039]   c4211     1
    x[1039]   c4212     1
    x[1039]   c4213     1
    x[1039]   c4214     1
    x[1039]   OBJ       -1
    x[1040]   c16       1
    x[1040]   c4494     1
    x[1040]   c4495     1
    x[1040]   c4496     1
    x[1040]   c4497     1
    x[1040]   OBJ       -1
    x[1041]   c1        1
    x[1041]   c253      1
    x[1041]   c254      1
    x[1041]   c255      1
    x[1041]   c256      1
    x[1041]   OBJ       -1
    x[1042]   c2        1
    x[1042]   c536      1
    x[1042]   c537      1
    x[1042]   c538      1
    x[1042]   c539      1
    x[1042]   OBJ       -1
    x[1043]   c3        1
    x[1043]   c819      1
    x[1043]   c820      1
    x[1043]   c821      1
    x[1043]   c822      1
    x[1043]   OBJ       -1
    x[1044]   c4        1
    x[1044]   c1102     1
    x[1044]   c1103     1
    x[1044]   c1104     1
    x[1044]   c1105     1
    x[1044]   OBJ       -1
    x[1045]   c5        1
    x[1045]   c1385     1
    x[1045]   c1386     1
    x[1045]   c1387     1
    x[1045]   c1388     1
    x[1045]   OBJ       -1
    x[1046]   c6        1
    x[1046]   c1668     1
    x[1046]   c1669     1
    x[1046]   c1670     1
    x[1046]   c1671     1
    x[1046]   OBJ       -1
    x[1047]   c7        1
    x[1047]   c1951     1
    x[1047]   c1952     1
    x[1047]   c1953     1
    x[1047]   c1954     1
    x[1047]   OBJ       -1
    x[1048]   c8        1
    x[1048]   c2234     1
    x[1048]   c2235     1
    x[1048]   c2236     1
    x[1048]   c2237     1
    x[1048]   OBJ       -1
    x[1049]   c9        1
    x[1049]   c2517     1
    x[1049]   c2518     1
    x[1049]   c2519     1
    x[1049]   c2520     1
    x[1049]   OBJ       -1
    x[1050]   c10       1
    x[1050]   c2800     1
    x[1050]   c2801     1
    x[1050]   c2802     1
    x[1050]   c2803     1
    x[1050]   OBJ       -1
    x[1051]   c11       1
    x[1051]   c3083     1
    x[1051]   c3084     1
    x[1051]   c3085     1
    x[1051]   c3086     1
    x[1051]   OBJ       -1
    x[1052]   c12       1
    x[1052]   c3366     1
    x[1052]   c3367     1
    x[1052]   c3368     1
    x[1052]   c3369     1
    x[1052]   OBJ       -1
    x[1053]   c13       1
    x[1053]   c3649     1
    x[1053]   c3650     1
    x[1053]   c3651     1
    x[1053]   c3652     1
    x[1053]   OBJ       -1
    x[1054]   c14       1
    x[1054]   c3932     1
    x[1054]   c3933     1
    x[1054]   c3934     1
    x[1054]   c3935     1
    x[1054]   OBJ       -1
    x[1055]   c15       1
    x[1055]   c4215     1
    x[1055]   c4216     1
    x[1055]   c4217     1
    x[1055]   c4218     1
    x[1055]   OBJ       -1
    x[1056]   c16       1
    x[1056]   c4498     1
    x[1056]   c4499     1
    x[1056]   c4500     1
    x[1056]   c4501     1
    x[1056]   OBJ       -1
    x[1057]   c1        1
    x[1057]   c257      1
    x[1057]   c258      1
    x[1057]   c259      1
    x[1057]   c260      1
    x[1057]   c261      1
    x[1057]   OBJ       -1
    x[1058]   c2        1
    x[1058]   c540      1
    x[1058]   c541      1
    x[1058]   c542      1
    x[1058]   c543      1
    x[1058]   c544      1
    x[1058]   OBJ       -1
    x[1059]   c3        1
    x[1059]   c823      1
    x[1059]   c824      1
    x[1059]   c825      1
    x[1059]   c826      1
    x[1059]   c827      1
    x[1059]   OBJ       -1
    x[1060]   c4        1
    x[1060]   c1106     1
    x[1060]   c1107     1
    x[1060]   c1108     1
    x[1060]   c1109     1
    x[1060]   c1110     1
    x[1060]   OBJ       -1
    x[1061]   c5        1
    x[1061]   c1389     1
    x[1061]   c1390     1
    x[1061]   c1391     1
    x[1061]   c1392     1
    x[1061]   c1393     1
    x[1061]   OBJ       -1
    x[1062]   c6        1
    x[1062]   c1672     1
    x[1062]   c1673     1
    x[1062]   c1674     1
    x[1062]   c1675     1
    x[1062]   c1676     1
    x[1062]   OBJ       -1
    x[1063]   c7        1
    x[1063]   c1955     1
    x[1063]   c1956     1
    x[1063]   c1957     1
    x[1063]   c1958     1
    x[1063]   c1959     1
    x[1063]   OBJ       -1
    x[1064]   c8        1
    x[1064]   c2238     1
    x[1064]   c2239     1
    x[1064]   c2240     1
    x[1064]   c2241     1
    x[1064]   c2242     1
    x[1064]   OBJ       -1
    x[1065]   c9        1
    x[1065]   c2521     1
    x[1065]   c2522     1
    x[1065]   c2523     1
    x[1065]   c2524     1
    x[1065]   c2525     1
    x[1065]   OBJ       -1
    x[1066]   c10       1
    x[1066]   c2804     1
    x[1066]   c2805     1
    x[1066]   c2806     1
    x[1066]   c2807     1
    x[1066]   c2808     1
    x[1066]   OBJ       -1
    x[1067]   c11       1
    x[1067]   c3087     1
    x[1067]   c3088     1
    x[1067]   c3089     1
    x[1067]   c3090     1
    x[1067]   c3091     1
    x[1067]   OBJ       -1
    x[1068]   c12       1
    x[1068]   c3370     1
    x[1068]   c3371     1
    x[1068]   c3372     1
    x[1068]   c3373     1
    x[1068]   c3374     1
    x[1068]   OBJ       -1
    x[1069]   c13       1
    x[1069]   c3653     1
    x[1069]   c3654     1
    x[1069]   c3655     1
    x[1069]   c3656     1
    x[1069]   c3657     1
    x[1069]   OBJ       -1
    x[1070]   c14       1
    x[1070]   c3936     1
    x[1070]   c3937     1
    x[1070]   c3938     1
    x[1070]   c3939     1
    x[1070]   c3940     1
    x[1070]   OBJ       -1
    x[1071]   c15       1
    x[1071]   c4219     1
    x[1071]   c4220     1
    x[1071]   c4221     1
    x[1071]   c4222     1
    x[1071]   c4223     1
    x[1071]   OBJ       -1
    x[1072]   c16       1
    x[1072]   c4502     1
    x[1072]   c4503     1
    x[1072]   c4504     1
    x[1072]   c4505     1
    x[1072]   c4506     1
    x[1072]   OBJ       -1
    x[1073]   c1        1
    x[1073]   c262      1
    x[1073]   OBJ       -1
    x[1074]   c2        1
    x[1074]   c545      1
    x[1074]   OBJ       -1
    x[1075]   c3        1
    x[1075]   c828      1
    x[1075]   OBJ       -1
    x[1076]   c4        1
    x[1076]   c1111     1
    x[1076]   OBJ       -1
    x[1077]   c5        1
    x[1077]   c1394     1
    x[1077]   OBJ       -1
    x[1078]   c6        1
    x[1078]   c1677     1
    x[1078]   OBJ       -1
    x[1079]   c7        1
    x[1079]   c1960     1
    x[1079]   OBJ       -1
    x[1080]   c8        1
    x[1080]   c2243     1
    x[1080]   OBJ       -1
    x[1081]   c9        1
    x[1081]   c2526     1
    x[1081]   OBJ       -1
    x[1082]   c10       1
    x[1082]   c2809     1
    x[1082]   OBJ       -1
    x[1083]   c11       1
    x[1083]   c3092     1
    x[1083]   OBJ       -1
    x[1084]   c12       1
    x[1084]   c3375     1
    x[1084]   OBJ       -1
    x[1085]   c13       1
    x[1085]   c3658     1
    x[1085]   OBJ       -1
    x[1086]   c14       1
    x[1086]   c3941     1
    x[1086]   OBJ       -1
    x[1087]   c15       1
    x[1087]   c4224     1
    x[1087]   OBJ       -1
    x[1088]   c16       1
    x[1088]   c4507     1
    x[1088]   OBJ       -1
    x[1089]   c1        1
    x[1089]   c263      1
    x[1089]   c264      1
    x[1089]   OBJ       -1
    x[1090]   c2        1
    x[1090]   c546      1
    x[1090]   c547      1
    x[1090]   OBJ       -1
    x[1091]   c3        1
    x[1091]   c829      1
    x[1091]   c830      1
    x[1091]   OBJ       -1
    x[1092]   c4        1
    x[1092]   c1112     1
    x[1092]   c1113     1
    x[1092]   OBJ       -1
    x[1093]   c5        1
    x[1093]   c1395     1
    x[1093]   c1396     1
    x[1093]   OBJ       -1
    x[1094]   c6        1
    x[1094]   c1678     1
    x[1094]   c1679     1
    x[1094]   OBJ       -1
    x[1095]   c7        1
    x[1095]   c1961     1
    x[1095]   c1962     1
    x[1095]   OBJ       -1
    x[1096]   c8        1
    x[1096]   c2244     1
    x[1096]   c2245     1
    x[1096]   OBJ       -1
    x[1097]   c9        1
    x[1097]   c2527     1
    x[1097]   c2528     1
    x[1097]   OBJ       -1
    x[1098]   c10       1
    x[1098]   c2810     1
    x[1098]   c2811     1
    x[1098]   OBJ       -1
    x[1099]   c11       1
    x[1099]   c3093     1
    x[1099]   c3094     1
    x[1099]   OBJ       -1
    x[1100]   c12       1
    x[1100]   c3376     1
    x[1100]   c3377     1
    x[1100]   OBJ       -1
    x[1101]   c13       1
    x[1101]   c3659     1
    x[1101]   c3660     1
    x[1101]   OBJ       -1
    x[1102]   c14       1
    x[1102]   c3942     1
    x[1102]   c3943     1
    x[1102]   OBJ       -1
    x[1103]   c15       1
    x[1103]   c4225     1
    x[1103]   c4226     1
    x[1103]   OBJ       -1
    x[1104]   c16       1
    x[1104]   c4508     1
    x[1104]   c4509     1
    x[1104]   OBJ       -1
    x[1105]   c1        1
    x[1105]   c265      1
    x[1105]   c266      1
    x[1105]   c267      1
    x[1105]   c268      1
    x[1105]   OBJ       -1
    x[1106]   c2        1
    x[1106]   c548      1
    x[1106]   c549      1
    x[1106]   c550      1
    x[1106]   c551      1
    x[1106]   OBJ       -1
    x[1107]   c3        1
    x[1107]   c831      1
    x[1107]   c832      1
    x[1107]   c833      1
    x[1107]   c834      1
    x[1107]   OBJ       -1
    x[1108]   c4        1
    x[1108]   c1114     1
    x[1108]   c1115     1
    x[1108]   c1116     1
    x[1108]   c1117     1
    x[1108]   OBJ       -1
    x[1109]   c5        1
    x[1109]   c1397     1
    x[1109]   c1398     1
    x[1109]   c1399     1
    x[1109]   c1400     1
    x[1109]   OBJ       -1
    x[1110]   c6        1
    x[1110]   c1680     1
    x[1110]   c1681     1
    x[1110]   c1682     1
    x[1110]   c1683     1
    x[1110]   OBJ       -1
    x[1111]   c7        1
    x[1111]   c1963     1
    x[1111]   c1964     1
    x[1111]   c1965     1
    x[1111]   c1966     1
    x[1111]   OBJ       -1
    x[1112]   c8        1
    x[1112]   c2246     1
    x[1112]   c2247     1
    x[1112]   c2248     1
    x[1112]   c2249     1
    x[1112]   OBJ       -1
    x[1113]   c9        1
    x[1113]   c2529     1
    x[1113]   c2530     1
    x[1113]   c2531     1
    x[1113]   c2532     1
    x[1113]   OBJ       -1
    x[1114]   c10       1
    x[1114]   c2812     1
    x[1114]   c2813     1
    x[1114]   c2814     1
    x[1114]   c2815     1
    x[1114]   OBJ       -1
    x[1115]   c11       1
    x[1115]   c3095     1
    x[1115]   c3096     1
    x[1115]   c3097     1
    x[1115]   c3098     1
    x[1115]   OBJ       -1
    x[1116]   c12       1
    x[1116]   c3378     1
    x[1116]   c3379     1
    x[1116]   c3380     1
    x[1116]   c3381     1
    x[1116]   OBJ       -1
    x[1117]   c13       1
    x[1117]   c3661     1
    x[1117]   c3662     1
    x[1117]   c3663     1
    x[1117]   c3664     1
    x[1117]   OBJ       -1
    x[1118]   c14       1
    x[1118]   c3944     1
    x[1118]   c3945     1
    x[1118]   c3946     1
    x[1118]   c3947     1
    x[1118]   OBJ       -1
    x[1119]   c15       1
    x[1119]   c4227     1
    x[1119]   c4228     1
    x[1119]   c4229     1
    x[1119]   c4230     1
    x[1119]   OBJ       -1
    x[1120]   c16       1
    x[1120]   c4510     1
    x[1120]   c4511     1
    x[1120]   c4512     1
    x[1120]   c4513     1
    x[1120]   OBJ       -1
    x[1121]   c1        1
    x[1121]   c269      1
    x[1121]   OBJ       -1
    x[1122]   c2        1
    x[1122]   c552      1
    x[1122]   OBJ       -1
    x[1123]   c3        1
    x[1123]   c835      1
    x[1123]   OBJ       -1
    x[1124]   c4        1
    x[1124]   c1118     1
    x[1124]   OBJ       -1
    x[1125]   c5        1
    x[1125]   c1401     1
    x[1125]   OBJ       -1
    x[1126]   c6        1
    x[1126]   c1684     1
    x[1126]   OBJ       -1
    x[1127]   c7        1
    x[1127]   c1967     1
    x[1127]   OBJ       -1
    x[1128]   c8        1
    x[1128]   c2250     1
    x[1128]   OBJ       -1
    x[1129]   c9        1
    x[1129]   c2533     1
    x[1129]   OBJ       -1
    x[1130]   c10       1
    x[1130]   c2816     1
    x[1130]   OBJ       -1
    x[1131]   c11       1
    x[1131]   c3099     1
    x[1131]   OBJ       -1
    x[1132]   c12       1
    x[1132]   c3382     1
    x[1132]   OBJ       -1
    x[1133]   c13       1
    x[1133]   c3665     1
    x[1133]   OBJ       -1
    x[1134]   c14       1
    x[1134]   c3948     1
    x[1134]   OBJ       -1
    x[1135]   c15       1
    x[1135]   c4231     1
    x[1135]   OBJ       -1
    x[1136]   c16       1
    x[1136]   c4514     1
    x[1136]   OBJ       -1
    x[1137]   c1        1
    x[1137]   c270      1
    x[1137]   c271      1
    x[1137]   OBJ       -1
    x[1138]   c2        1
    x[1138]   c553      1
    x[1138]   c554      1
    x[1138]   OBJ       -1
    x[1139]   c3        1
    x[1139]   c836      1
    x[1139]   c837      1
    x[1139]   OBJ       -1
    x[1140]   c4        1
    x[1140]   c1119     1
    x[1140]   c1120     1
    x[1140]   OBJ       -1
    x[1141]   c5        1
    x[1141]   c1402     1
    x[1141]   c1403     1
    x[1141]   OBJ       -1
    x[1142]   c6        1
    x[1142]   c1685     1
    x[1142]   c1686     1
    x[1142]   OBJ       -1
    x[1143]   c7        1
    x[1143]   c1968     1
    x[1143]   c1969     1
    x[1143]   OBJ       -1
    x[1144]   c8        1
    x[1144]   c2251     1
    x[1144]   c2252     1
    x[1144]   OBJ       -1
    x[1145]   c9        1
    x[1145]   c2534     1
    x[1145]   c2535     1
    x[1145]   OBJ       -1
    x[1146]   c10       1
    x[1146]   c2817     1
    x[1146]   c2818     1
    x[1146]   OBJ       -1
    x[1147]   c11       1
    x[1147]   c3100     1
    x[1147]   c3101     1
    x[1147]   OBJ       -1
    x[1148]   c12       1
    x[1148]   c3383     1
    x[1148]   c3384     1
    x[1148]   OBJ       -1
    x[1149]   c13       1
    x[1149]   c3666     1
    x[1149]   c3667     1
    x[1149]   OBJ       -1
    x[1150]   c14       1
    x[1150]   c3949     1
    x[1150]   c3950     1
    x[1150]   OBJ       -1
    x[1151]   c15       1
    x[1151]   c4232     1
    x[1151]   c4233     1
    x[1151]   OBJ       -1
    x[1152]   c16       1
    x[1152]   c4515     1
    x[1152]   c4516     1
    x[1152]   OBJ       -1
    x[1153]   c1        1
    x[1153]   c272      1
    x[1153]   c273      1
    x[1153]   c274      1
    x[1153]   OBJ       -1
    x[1154]   c2        1
    x[1154]   c555      1
    x[1154]   c556      1
    x[1154]   c557      1
    x[1154]   OBJ       -1
    x[1155]   c3        1
    x[1155]   c838      1
    x[1155]   c839      1
    x[1155]   c840      1
    x[1155]   OBJ       -1
    x[1156]   c4        1
    x[1156]   c1121     1
    x[1156]   c1122     1
    x[1156]   c1123     1
    x[1156]   OBJ       -1
    x[1157]   c5        1
    x[1157]   c1404     1
    x[1157]   c1405     1
    x[1157]   c1406     1
    x[1157]   OBJ       -1
    x[1158]   c6        1
    x[1158]   c1687     1
    x[1158]   c1688     1
    x[1158]   c1689     1
    x[1158]   OBJ       -1
    x[1159]   c7        1
    x[1159]   c1970     1
    x[1159]   c1971     1
    x[1159]   c1972     1
    x[1159]   OBJ       -1
    x[1160]   c8        1
    x[1160]   c2253     1
    x[1160]   c2254     1
    x[1160]   c2255     1
    x[1160]   OBJ       -1
    x[1161]   c9        1
    x[1161]   c2536     1
    x[1161]   c2537     1
    x[1161]   c2538     1
    x[1161]   OBJ       -1
    x[1162]   c10       1
    x[1162]   c2819     1
    x[1162]   c2820     1
    x[1162]   c2821     1
    x[1162]   OBJ       -1
    x[1163]   c11       1
    x[1163]   c3102     1
    x[1163]   c3103     1
    x[1163]   c3104     1
    x[1163]   OBJ       -1
    x[1164]   c12       1
    x[1164]   c3385     1
    x[1164]   c3386     1
    x[1164]   c3387     1
    x[1164]   OBJ       -1
    x[1165]   c13       1
    x[1165]   c3668     1
    x[1165]   c3669     1
    x[1165]   c3670     1
    x[1165]   OBJ       -1
    x[1166]   c14       1
    x[1166]   c3951     1
    x[1166]   c3952     1
    x[1166]   c3953     1
    x[1166]   OBJ       -1
    x[1167]   c15       1
    x[1167]   c4234     1
    x[1167]   c4235     1
    x[1167]   c4236     1
    x[1167]   OBJ       -1
    x[1168]   c16       1
    x[1168]   c4517     1
    x[1168]   c4518     1
    x[1168]   c4519     1
    x[1168]   OBJ       -1
    x[1169]   c1        1
    x[1169]   c275      1
    x[1169]   OBJ       -1
    x[1170]   c2        1
    x[1170]   c558      1
    x[1170]   OBJ       -1
    x[1171]   c3        1
    x[1171]   c841      1
    x[1171]   OBJ       -1
    x[1172]   c4        1
    x[1172]   c1124     1
    x[1172]   OBJ       -1
    x[1173]   c5        1
    x[1173]   c1407     1
    x[1173]   OBJ       -1
    x[1174]   c6        1
    x[1174]   c1690     1
    x[1174]   OBJ       -1
    x[1175]   c7        1
    x[1175]   c1973     1
    x[1175]   OBJ       -1
    x[1176]   c8        1
    x[1176]   c2256     1
    x[1176]   OBJ       -1
    x[1177]   c9        1
    x[1177]   c2539     1
    x[1177]   OBJ       -1
    x[1178]   c10       1
    x[1178]   c2822     1
    x[1178]   OBJ       -1
    x[1179]   c11       1
    x[1179]   c3105     1
    x[1179]   OBJ       -1
    x[1180]   c12       1
    x[1180]   c3388     1
    x[1180]   OBJ       -1
    x[1181]   c13       1
    x[1181]   c3671     1
    x[1181]   OBJ       -1
    x[1182]   c14       1
    x[1182]   c3954     1
    x[1182]   OBJ       -1
    x[1183]   c15       1
    x[1183]   c4237     1
    x[1183]   OBJ       -1
    x[1184]   c16       1
    x[1184]   c4520     1
    x[1184]   OBJ       -1
    x[1185]   c1        1
    x[1185]   c276      1
    x[1185]   c277      1
    x[1185]   c278      1
    x[1185]   OBJ       -1
    x[1186]   c2        1
    x[1186]   c559      1
    x[1186]   c560      1
    x[1186]   c561      1
    x[1186]   OBJ       -1
    x[1187]   c3        1
    x[1187]   c842      1
    x[1187]   c843      1
    x[1187]   c844      1
    x[1187]   OBJ       -1
    x[1188]   c4        1
    x[1188]   c1125     1
    x[1188]   c1126     1
    x[1188]   c1127     1
    x[1188]   OBJ       -1
    x[1189]   c5        1
    x[1189]   c1408     1
    x[1189]   c1409     1
    x[1189]   c1410     1
    x[1189]   OBJ       -1
    x[1190]   c6        1
    x[1190]   c1691     1
    x[1190]   c1692     1
    x[1190]   c1693     1
    x[1190]   OBJ       -1
    x[1191]   c7        1
    x[1191]   c1974     1
    x[1191]   c1975     1
    x[1191]   c1976     1
    x[1191]   OBJ       -1
    x[1192]   c8        1
    x[1192]   c2257     1
    x[1192]   c2258     1
    x[1192]   c2259     1
    x[1192]   OBJ       -1
    x[1193]   c9        1
    x[1193]   c2540     1
    x[1193]   c2541     1
    x[1193]   c2542     1
    x[1193]   OBJ       -1
    x[1194]   c10       1
    x[1194]   c2823     1
    x[1194]   c2824     1
    x[1194]   c2825     1
    x[1194]   OBJ       -1
    x[1195]   c11       1
    x[1195]   c3106     1
    x[1195]   c3107     1
    x[1195]   c3108     1
    x[1195]   OBJ       -1
    x[1196]   c12       1
    x[1196]   c3389     1
    x[1196]   c3390     1
    x[1196]   c3391     1
    x[1196]   OBJ       -1
    x[1197]   c13       1
    x[1197]   c3672     1
    x[1197]   c3673     1
    x[1197]   c3674     1
    x[1197]   OBJ       -1
    x[1198]   c14       1
    x[1198]   c3955     1
    x[1198]   c3956     1
    x[1198]   c3957     1
    x[1198]   OBJ       -1
    x[1199]   c15       1
    x[1199]   c4238     1
    x[1199]   c4239     1
    x[1199]   c4240     1
    x[1199]   OBJ       -1
    x[1200]   c16       1
    x[1200]   c4521     1
    x[1200]   c4522     1
    x[1200]   c4523     1
    x[1200]   OBJ       -1
    x[1201]   c1        1
    x[1201]   c279      1
    x[1201]   OBJ       -1
    x[1202]   c2        1
    x[1202]   c562      1
    x[1202]   OBJ       -1
    x[1203]   c3        1
    x[1203]   c845      1
    x[1203]   OBJ       -1
    x[1204]   c4        1
    x[1204]   c1128     1
    x[1204]   OBJ       -1
    x[1205]   c5        1
    x[1205]   c1411     1
    x[1205]   OBJ       -1
    x[1206]   c6        1
    x[1206]   c1694     1
    x[1206]   OBJ       -1
    x[1207]   c7        1
    x[1207]   c1977     1
    x[1207]   OBJ       -1
    x[1208]   c8        1
    x[1208]   c2260     1
    x[1208]   OBJ       -1
    x[1209]   c9        1
    x[1209]   c2543     1
    x[1209]   OBJ       -1
    x[1210]   c10       1
    x[1210]   c2826     1
    x[1210]   OBJ       -1
    x[1211]   c11       1
    x[1211]   c3109     1
    x[1211]   OBJ       -1
    x[1212]   c12       1
    x[1212]   c3392     1
    x[1212]   OBJ       -1
    x[1213]   c13       1
    x[1213]   c3675     1
    x[1213]   OBJ       -1
    x[1214]   c14       1
    x[1214]   c3958     1
    x[1214]   OBJ       -1
    x[1215]   c15       1
    x[1215]   c4241     1
    x[1215]   OBJ       -1
    x[1216]   c16       1
    x[1216]   c4524     1
    x[1216]   OBJ       -1
    x[1217]   c1        1
    x[1217]   c280      1
    x[1217]   c281      1
    x[1217]   OBJ       -1
    x[1218]   c2        1
    x[1218]   c563      1
    x[1218]   c564      1
    x[1218]   OBJ       -1
    x[1219]   c3        1
    x[1219]   c846      1
    x[1219]   c847      1
    x[1219]   OBJ       -1
    x[1220]   c4        1
    x[1220]   c1129     1
    x[1220]   c1130     1
    x[1220]   OBJ       -1
    x[1221]   c5        1
    x[1221]   c1412     1
    x[1221]   c1413     1
    x[1221]   OBJ       -1
    x[1222]   c6        1
    x[1222]   c1695     1
    x[1222]   c1696     1
    x[1222]   OBJ       -1
    x[1223]   c7        1
    x[1223]   c1978     1
    x[1223]   c1979     1
    x[1223]   OBJ       -1
    x[1224]   c8        1
    x[1224]   c2261     1
    x[1224]   c2262     1
    x[1224]   OBJ       -1
    x[1225]   c9        1
    x[1225]   c2544     1
    x[1225]   c2545     1
    x[1225]   OBJ       -1
    x[1226]   c10       1
    x[1226]   c2827     1
    x[1226]   c2828     1
    x[1226]   OBJ       -1
    x[1227]   c11       1
    x[1227]   c3110     1
    x[1227]   c3111     1
    x[1227]   OBJ       -1
    x[1228]   c12       1
    x[1228]   c3393     1
    x[1228]   c3394     1
    x[1228]   OBJ       -1
    x[1229]   c13       1
    x[1229]   c3676     1
    x[1229]   c3677     1
    x[1229]   OBJ       -1
    x[1230]   c14       1
    x[1230]   c3959     1
    x[1230]   c3960     1
    x[1230]   OBJ       -1
    x[1231]   c15       1
    x[1231]   c4242     1
    x[1231]   c4243     1
    x[1231]   OBJ       -1
    x[1232]   c16       1
    x[1232]   c4525     1
    x[1232]   c4526     1
    x[1232]   OBJ       -1
    x[1233]   c1        1
    x[1233]   c282      1
    x[1233]   OBJ       -1
    x[1234]   c2        1
    x[1234]   c565      1
    x[1234]   OBJ       -1
    x[1235]   c3        1
    x[1235]   c848      1
    x[1235]   OBJ       -1
    x[1236]   c4        1
    x[1236]   c1131     1
    x[1236]   OBJ       -1
    x[1237]   c5        1
    x[1237]   c1414     1
    x[1237]   OBJ       -1
    x[1238]   c6        1
    x[1238]   c1697     1
    x[1238]   OBJ       -1
    x[1239]   c7        1
    x[1239]   c1980     1
    x[1239]   OBJ       -1
    x[1240]   c8        1
    x[1240]   c2263     1
    x[1240]   OBJ       -1
    x[1241]   c9        1
    x[1241]   c2546     1
    x[1241]   OBJ       -1
    x[1242]   c10       1
    x[1242]   c2829     1
    x[1242]   OBJ       -1
    x[1243]   c11       1
    x[1243]   c3112     1
    x[1243]   OBJ       -1
    x[1244]   c12       1
    x[1244]   c3395     1
    x[1244]   OBJ       -1
    x[1245]   c13       1
    x[1245]   c3678     1
    x[1245]   OBJ       -1
    x[1246]   c14       1
    x[1246]   c3961     1
    x[1246]   OBJ       -1
    x[1247]   c15       1
    x[1247]   c4244     1
    x[1247]   OBJ       -1
    x[1248]   c16       1
    x[1248]   c4527     1
    x[1248]   OBJ       -1
    x[1249]   c1        1
    x[1249]   c283      1
    x[1249]   OBJ       -1
    x[1250]   c2        1
    x[1250]   c566      1
    x[1250]   OBJ       -1
    x[1251]   c3        1
    x[1251]   c849      1
    x[1251]   OBJ       -1
    x[1252]   c4        1
    x[1252]   c1132     1
    x[1252]   OBJ       -1
    x[1253]   c5        1
    x[1253]   c1415     1
    x[1253]   OBJ       -1
    x[1254]   c6        1
    x[1254]   c1698     1
    x[1254]   OBJ       -1
    x[1255]   c7        1
    x[1255]   c1981     1
    x[1255]   OBJ       -1
    x[1256]   c8        1
    x[1256]   c2264     1
    x[1256]   OBJ       -1
    x[1257]   c9        1
    x[1257]   c2547     1
    x[1257]   OBJ       -1
    x[1258]   c10       1
    x[1258]   c2830     1
    x[1258]   OBJ       -1
    x[1259]   c11       1
    x[1259]   c3113     1
    x[1259]   OBJ       -1
    x[1260]   c12       1
    x[1260]   c3396     1
    x[1260]   OBJ       -1
    x[1261]   c13       1
    x[1261]   c3679     1
    x[1261]   OBJ       -1
    x[1262]   c14       1
    x[1262]   c3962     1
    x[1262]   OBJ       -1
    x[1263]   c15       1
    x[1263]   c4245     1
    x[1263]   OBJ       -1
    x[1264]   c16       1
    x[1264]   c4528     1
    x[1264]   OBJ       -1
    x[1265]   c1        1
    x[1265]   c284      1
    x[1265]   c285      1
    x[1265]   c286      1
    x[1265]   OBJ       -1
    x[1266]   c2        1
    x[1266]   c567      1
    x[1266]   c568      1
    x[1266]   c569      1
    x[1266]   OBJ       -1
    x[1267]   c3        1
    x[1267]   c850      1
    x[1267]   c851      1
    x[1267]   c852      1
    x[1267]   OBJ       -1
    x[1268]   c4        1
    x[1268]   c1133     1
    x[1268]   c1134     1
    x[1268]   c1135     1
    x[1268]   OBJ       -1
    x[1269]   c5        1
    x[1269]   c1416     1
    x[1269]   c1417     1
    x[1269]   c1418     1
    x[1269]   OBJ       -1
    x[1270]   c6        1
    x[1270]   c1699     1
    x[1270]   c1700     1
    x[1270]   c1701     1
    x[1270]   OBJ       -1
    x[1271]   c7        1
    x[1271]   c1982     1
    x[1271]   c1983     1
    x[1271]   c1984     1
    x[1271]   OBJ       -1
    x[1272]   c8        1
    x[1272]   c2265     1
    x[1272]   c2266     1
    x[1272]   c2267     1
    x[1272]   OBJ       -1
    x[1273]   c9        1
    x[1273]   c2548     1
    x[1273]   c2549     1
    x[1273]   c2550     1
    x[1273]   OBJ       -1
    x[1274]   c10       1
    x[1274]   c2831     1
    x[1274]   c2832     1
    x[1274]   c2833     1
    x[1274]   OBJ       -1
    x[1275]   c11       1
    x[1275]   c3114     1
    x[1275]   c3115     1
    x[1275]   c3116     1
    x[1275]   OBJ       -1
    x[1276]   c12       1
    x[1276]   c3397     1
    x[1276]   c3398     1
    x[1276]   c3399     1
    x[1276]   OBJ       -1
    x[1277]   c13       1
    x[1277]   c3680     1
    x[1277]   c3681     1
    x[1277]   c3682     1
    x[1277]   OBJ       -1
    x[1278]   c14       1
    x[1278]   c3963     1
    x[1278]   c3964     1
    x[1278]   c3965     1
    x[1278]   OBJ       -1
    x[1279]   c15       1
    x[1279]   c4246     1
    x[1279]   c4247     1
    x[1279]   c4248     1
    x[1279]   OBJ       -1
    x[1280]   c16       1
    x[1280]   c4529     1
    x[1280]   c4530     1
    x[1280]   c4531     1
    x[1280]   OBJ       -1
    x[1281]   c1        1
    x[1281]   c287      1
    x[1281]   c288      1
    x[1281]   OBJ       -1
    x[1282]   c2        1
    x[1282]   c570      1
    x[1282]   c571      1
    x[1282]   OBJ       -1
    x[1283]   c3        1
    x[1283]   c853      1
    x[1283]   c854      1
    x[1283]   OBJ       -1
    x[1284]   c4        1
    x[1284]   c1136     1
    x[1284]   c1137     1
    x[1284]   OBJ       -1
    x[1285]   c5        1
    x[1285]   c1419     1
    x[1285]   c1420     1
    x[1285]   OBJ       -1
    x[1286]   c6        1
    x[1286]   c1702     1
    x[1286]   c1703     1
    x[1286]   OBJ       -1
    x[1287]   c7        1
    x[1287]   c1985     1
    x[1287]   c1986     1
    x[1287]   OBJ       -1
    x[1288]   c8        1
    x[1288]   c2268     1
    x[1288]   c2269     1
    x[1288]   OBJ       -1
    x[1289]   c9        1
    x[1289]   c2551     1
    x[1289]   c2552     1
    x[1289]   OBJ       -1
    x[1290]   c10       1
    x[1290]   c2834     1
    x[1290]   c2835     1
    x[1290]   OBJ       -1
    x[1291]   c11       1
    x[1291]   c3117     1
    x[1291]   c3118     1
    x[1291]   OBJ       -1
    x[1292]   c12       1
    x[1292]   c3400     1
    x[1292]   c3401     1
    x[1292]   OBJ       -1
    x[1293]   c13       1
    x[1293]   c3683     1
    x[1293]   c3684     1
    x[1293]   OBJ       -1
    x[1294]   c14       1
    x[1294]   c3966     1
    x[1294]   c3967     1
    x[1294]   OBJ       -1
    x[1295]   c15       1
    x[1295]   c4249     1
    x[1295]   c4250     1
    x[1295]   OBJ       -1
    x[1296]   c16       1
    x[1296]   c4532     1
    x[1296]   c4533     1
    x[1296]   OBJ       -1
    x[1297]   c1        1
    x[1297]   c289      1
    x[1297]   c290      1
    x[1297]   c291      1
    x[1297]   OBJ       -1
    x[1298]   c2        1
    x[1298]   c572      1
    x[1298]   c573      1
    x[1298]   c574      1
    x[1298]   OBJ       -1
    x[1299]   c3        1
    x[1299]   c855      1
    x[1299]   c856      1
    x[1299]   c857      1
    x[1299]   OBJ       -1
    x[1300]   c4        1
    x[1300]   c1138     1
    x[1300]   c1139     1
    x[1300]   c1140     1
    x[1300]   OBJ       -1
    x[1301]   c5        1
    x[1301]   c1421     1
    x[1301]   c1422     1
    x[1301]   c1423     1
    x[1301]   OBJ       -1
    x[1302]   c6        1
    x[1302]   c1704     1
    x[1302]   c1705     1
    x[1302]   c1706     1
    x[1302]   OBJ       -1
    x[1303]   c7        1
    x[1303]   c1987     1
    x[1303]   c1988     1
    x[1303]   c1989     1
    x[1303]   OBJ       -1
    x[1304]   c8        1
    x[1304]   c2270     1
    x[1304]   c2271     1
    x[1304]   c2272     1
    x[1304]   OBJ       -1
    x[1305]   c9        1
    x[1305]   c2553     1
    x[1305]   c2554     1
    x[1305]   c2555     1
    x[1305]   OBJ       -1
    x[1306]   c10       1
    x[1306]   c2836     1
    x[1306]   c2837     1
    x[1306]   c2838     1
    x[1306]   OBJ       -1
    x[1307]   c11       1
    x[1307]   c3119     1
    x[1307]   c3120     1
    x[1307]   c3121     1
    x[1307]   OBJ       -1
    x[1308]   c12       1
    x[1308]   c3402     1
    x[1308]   c3403     1
    x[1308]   c3404     1
    x[1308]   OBJ       -1
    x[1309]   c13       1
    x[1309]   c3685     1
    x[1309]   c3686     1
    x[1309]   c3687     1
    x[1309]   OBJ       -1
    x[1310]   c14       1
    x[1310]   c3968     1
    x[1310]   c3969     1
    x[1310]   c3970     1
    x[1310]   OBJ       -1
    x[1311]   c15       1
    x[1311]   c4251     1
    x[1311]   c4252     1
    x[1311]   c4253     1
    x[1311]   OBJ       -1
    x[1312]   c16       1
    x[1312]   c4534     1
    x[1312]   c4535     1
    x[1312]   c4536     1
    x[1312]   OBJ       -1
    x[1313]   c1        1
    x[1313]   c292      1
    x[1313]   c293      1
    x[1313]   OBJ       -1
    x[1314]   c2        1
    x[1314]   c575      1
    x[1314]   c576      1
    x[1314]   OBJ       -1
    x[1315]   c3        1
    x[1315]   c858      1
    x[1315]   c859      1
    x[1315]   OBJ       -1
    x[1316]   c4        1
    x[1316]   c1141     1
    x[1316]   c1142     1
    x[1316]   OBJ       -1
    x[1317]   c5        1
    x[1317]   c1424     1
    x[1317]   c1425     1
    x[1317]   OBJ       -1
    x[1318]   c6        1
    x[1318]   c1707     1
    x[1318]   c1708     1
    x[1318]   OBJ       -1
    x[1319]   c7        1
    x[1319]   c1990     1
    x[1319]   c1991     1
    x[1319]   OBJ       -1
    x[1320]   c8        1
    x[1320]   c2273     1
    x[1320]   c2274     1
    x[1320]   OBJ       -1
    x[1321]   c9        1
    x[1321]   c2556     1
    x[1321]   c2557     1
    x[1321]   OBJ       -1
    x[1322]   c10       1
    x[1322]   c2839     1
    x[1322]   c2840     1
    x[1322]   OBJ       -1
    x[1323]   c11       1
    x[1323]   c3122     1
    x[1323]   c3123     1
    x[1323]   OBJ       -1
    x[1324]   c12       1
    x[1324]   c3405     1
    x[1324]   c3406     1
    x[1324]   OBJ       -1
    x[1325]   c13       1
    x[1325]   c3688     1
    x[1325]   c3689     1
    x[1325]   OBJ       -1
    x[1326]   c14       1
    x[1326]   c3971     1
    x[1326]   c3972     1
    x[1326]   OBJ       -1
    x[1327]   c15       1
    x[1327]   c4254     1
    x[1327]   c4255     1
    x[1327]   OBJ       -1
    x[1328]   c16       1
    x[1328]   c4537     1
    x[1328]   c4538     1
    x[1328]   OBJ       -1
    x[1329]   c1        1
    x[1329]   c294      1
    x[1329]   OBJ       -1
    x[1330]   c2        1
    x[1330]   c577      1
    x[1330]   OBJ       -1
    x[1331]   c3        1
    x[1331]   c860      1
    x[1331]   OBJ       -1
    x[1332]   c4        1
    x[1332]   c1143     1
    x[1332]   OBJ       -1
    x[1333]   c5        1
    x[1333]   c1426     1
    x[1333]   OBJ       -1
    x[1334]   c6        1
    x[1334]   c1709     1
    x[1334]   OBJ       -1
    x[1335]   c7        1
    x[1335]   c1992     1
    x[1335]   OBJ       -1
    x[1336]   c8        1
    x[1336]   c2275     1
    x[1336]   OBJ       -1
    x[1337]   c9        1
    x[1337]   c2558     1
    x[1337]   OBJ       -1
    x[1338]   c10       1
    x[1338]   c2841     1
    x[1338]   OBJ       -1
    x[1339]   c11       1
    x[1339]   c3124     1
    x[1339]   OBJ       -1
    x[1340]   c12       1
    x[1340]   c3407     1
    x[1340]   OBJ       -1
    x[1341]   c13       1
    x[1341]   c3690     1
    x[1341]   OBJ       -1
    x[1342]   c14       1
    x[1342]   c3973     1
    x[1342]   OBJ       -1
    x[1343]   c15       1
    x[1343]   c4256     1
    x[1343]   OBJ       -1
    x[1344]   c16       1
    x[1344]   c4539     1
    x[1344]   OBJ       -1
    x[1345]   c1        1
    x[1345]   c295      1
    x[1345]   c296      1
    x[1345]   c297      1
    x[1345]   OBJ       -1
    x[1346]   c2        1
    x[1346]   c578      1
    x[1346]   c579      1
    x[1346]   c580      1
    x[1346]   OBJ       -1
    x[1347]   c3        1
    x[1347]   c861      1
    x[1347]   c862      1
    x[1347]   c863      1
    x[1347]   OBJ       -1
    x[1348]   c4        1
    x[1348]   c1144     1
    x[1348]   c1145     1
    x[1348]   c1146     1
    x[1348]   OBJ       -1
    x[1349]   c5        1
    x[1349]   c1427     1
    x[1349]   c1428     1
    x[1349]   c1429     1
    x[1349]   OBJ       -1
    x[1350]   c6        1
    x[1350]   c1710     1
    x[1350]   c1711     1
    x[1350]   c1712     1
    x[1350]   OBJ       -1
    x[1351]   c7        1
    x[1351]   c1993     1
    x[1351]   c1994     1
    x[1351]   c1995     1
    x[1351]   OBJ       -1
    x[1352]   c8        1
    x[1352]   c2276     1
    x[1352]   c2277     1
    x[1352]   c2278     1
    x[1352]   OBJ       -1
    x[1353]   c9        1
    x[1353]   c2559     1
    x[1353]   c2560     1
    x[1353]   c2561     1
    x[1353]   OBJ       -1
    x[1354]   c10       1
    x[1354]   c2842     1
    x[1354]   c2843     1
    x[1354]   c2844     1
    x[1354]   OBJ       -1
    x[1355]   c11       1
    x[1355]   c3125     1
    x[1355]   c3126     1
    x[1355]   c3127     1
    x[1355]   OBJ       -1
    x[1356]   c12       1
    x[1356]   c3408     1
    x[1356]   c3409     1
    x[1356]   c3410     1
    x[1356]   OBJ       -1
    x[1357]   c13       1
    x[1357]   c3691     1
    x[1357]   c3692     1
    x[1357]   c3693     1
    x[1357]   OBJ       -1
    x[1358]   c14       1
    x[1358]   c3974     1
    x[1358]   c3975     1
    x[1358]   c3976     1
    x[1358]   OBJ       -1
    x[1359]   c15       1
    x[1359]   c4257     1
    x[1359]   c4258     1
    x[1359]   c4259     1
    x[1359]   OBJ       -1
    x[1360]   c16       1
    x[1360]   c4540     1
    x[1360]   c4541     1
    x[1360]   c4542     1
    x[1360]   OBJ       -1
    x[1361]   c1        1
    x[1361]   c298      1
    x[1361]   c299      1
    x[1361]   OBJ       -1
    x[1362]   c2        1
    x[1362]   c581      1
    x[1362]   c582      1
    x[1362]   OBJ       -1
    x[1363]   c3        1
    x[1363]   c864      1
    x[1363]   c865      1
    x[1363]   OBJ       -1
    x[1364]   c4        1
    x[1364]   c1147     1
    x[1364]   c1148     1
    x[1364]   OBJ       -1
    x[1365]   c5        1
    x[1365]   c1430     1
    x[1365]   c1431     1
    x[1365]   OBJ       -1
    x[1366]   c6        1
    x[1366]   c1713     1
    x[1366]   c1714     1
    x[1366]   OBJ       -1
    x[1367]   c7        1
    x[1367]   c1996     1
    x[1367]   c1997     1
    x[1367]   OBJ       -1
    x[1368]   c8        1
    x[1368]   c2279     1
    x[1368]   c2280     1
    x[1368]   OBJ       -1
    x[1369]   c9        1
    x[1369]   c2562     1
    x[1369]   c2563     1
    x[1369]   OBJ       -1
    x[1370]   c10       1
    x[1370]   c2845     1
    x[1370]   c2846     1
    x[1370]   OBJ       -1
    x[1371]   c11       1
    x[1371]   c3128     1
    x[1371]   c3129     1
    x[1371]   OBJ       -1
    x[1372]   c12       1
    x[1372]   c3411     1
    x[1372]   c3412     1
    x[1372]   OBJ       -1
    x[1373]   c13       1
    x[1373]   c3694     1
    x[1373]   c3695     1
    x[1373]   OBJ       -1
    x[1374]   c14       1
    x[1374]   c3977     1
    x[1374]   c3978     1
    x[1374]   OBJ       -1
    x[1375]   c15       1
    x[1375]   c4260     1
    x[1375]   c4261     1
    x[1375]   OBJ       -1
    x[1376]   c16       1
    x[1376]   c4543     1
    x[1376]   c4544     1
    x[1376]   OBJ       -1
    x[1377]   c1        1
    x[1377]   c300      1
    x[1377]   c301      1
    x[1377]   c302      1
    x[1377]   c303      1
    x[1377]   c304      1
    x[1377]   OBJ       -1
    x[1378]   c2        1
    x[1378]   c583      1
    x[1378]   c584      1
    x[1378]   c585      1
    x[1378]   c586      1
    x[1378]   c587      1
    x[1378]   OBJ       -1
    x[1379]   c3        1
    x[1379]   c866      1
    x[1379]   c867      1
    x[1379]   c868      1
    x[1379]   c869      1
    x[1379]   c870      1
    x[1379]   OBJ       -1
    x[1380]   c4        1
    x[1380]   c1149     1
    x[1380]   c1150     1
    x[1380]   c1151     1
    x[1380]   c1152     1
    x[1380]   c1153     1
    x[1380]   OBJ       -1
    x[1381]   c5        1
    x[1381]   c1432     1
    x[1381]   c1433     1
    x[1381]   c1434     1
    x[1381]   c1435     1
    x[1381]   c1436     1
    x[1381]   OBJ       -1
    x[1382]   c6        1
    x[1382]   c1715     1
    x[1382]   c1716     1
    x[1382]   c1717     1
    x[1382]   c1718     1
    x[1382]   c1719     1
    x[1382]   OBJ       -1
    x[1383]   c7        1
    x[1383]   c1998     1
    x[1383]   c1999     1
    x[1383]   c2000     1
    x[1383]   c2001     1
    x[1383]   c2002     1
    x[1383]   OBJ       -1
    x[1384]   c8        1
    x[1384]   c2281     1
    x[1384]   c2282     1
    x[1384]   c2283     1
    x[1384]   c2284     1
    x[1384]   c2285     1
    x[1384]   OBJ       -1
    x[1385]   c9        1
    x[1385]   c2564     1
    x[1385]   c2565     1
    x[1385]   c2566     1
    x[1385]   c2567     1
    x[1385]   c2568     1
    x[1385]   OBJ       -1
    x[1386]   c10       1
    x[1386]   c2847     1
    x[1386]   c2848     1
    x[1386]   c2849     1
    x[1386]   c2850     1
    x[1386]   c2851     1
    x[1386]   OBJ       -1
    x[1387]   c11       1
    x[1387]   c3130     1
    x[1387]   c3131     1
    x[1387]   c3132     1
    x[1387]   c3133     1
    x[1387]   c3134     1
    x[1387]   OBJ       -1
    x[1388]   c12       1
    x[1388]   c3413     1
    x[1388]   c3414     1
    x[1388]   c3415     1
    x[1388]   c3416     1
    x[1388]   c3417     1
    x[1388]   OBJ       -1
    x[1389]   c13       1
    x[1389]   c3696     1
    x[1389]   c3697     1
    x[1389]   c3698     1
    x[1389]   c3699     1
    x[1389]   c3700     1
    x[1389]   OBJ       -1
    x[1390]   c14       1
    x[1390]   c3979     1
    x[1390]   c3980     1
    x[1390]   c3981     1
    x[1390]   c3982     1
    x[1390]   c3983     1
    x[1390]   OBJ       -1
    x[1391]   c15       1
    x[1391]   c4262     1
    x[1391]   c4263     1
    x[1391]   c4264     1
    x[1391]   c4265     1
    x[1391]   c4266     1
    x[1391]   OBJ       -1
    x[1392]   c16       1
    x[1392]   c4545     1
    x[1392]   c4546     1
    x[1392]   c4547     1
    x[1392]   c4548     1
    x[1392]   c4549     1
    x[1392]   OBJ       -1
    x[1393]   c1        1
    x[1393]   c305      1
    x[1393]   OBJ       -1
    x[1394]   c2        1
    x[1394]   c588      1
    x[1394]   OBJ       -1
    x[1395]   c3        1
    x[1395]   c871      1
    x[1395]   OBJ       -1
    x[1396]   c4        1
    x[1396]   c1154     1
    x[1396]   OBJ       -1
    x[1397]   c5        1
    x[1397]   c1437     1
    x[1397]   OBJ       -1
    x[1398]   c6        1
    x[1398]   c1720     1
    x[1398]   OBJ       -1
    x[1399]   c7        1
    x[1399]   c2003     1
    x[1399]   OBJ       -1
    x[1400]   c8        1
    x[1400]   c2286     1
    x[1400]   OBJ       -1
    x[1401]   c9        1
    x[1401]   c2569     1
    x[1401]   OBJ       -1
    x[1402]   c10       1
    x[1402]   c2852     1
    x[1402]   OBJ       -1
    x[1403]   c11       1
    x[1403]   c3135     1
    x[1403]   OBJ       -1
    x[1404]   c12       1
    x[1404]   c3418     1
    x[1404]   OBJ       -1
    x[1405]   c13       1
    x[1405]   c3701     1
    x[1405]   OBJ       -1
    x[1406]   c14       1
    x[1406]   c3984     1
    x[1406]   OBJ       -1
    x[1407]   c15       1
    x[1407]   c4267     1
    x[1407]   OBJ       -1
    x[1408]   c16       1
    x[1408]   c4550     1
    x[1408]   OBJ       -1
    x[1409]   c1        1
    x[1409]   c306      1
    x[1409]   c307      1
    x[1409]   OBJ       -1
    x[1410]   c2        1
    x[1410]   c589      1
    x[1410]   c590      1
    x[1410]   OBJ       -1
    x[1411]   c3        1
    x[1411]   c872      1
    x[1411]   c873      1
    x[1411]   OBJ       -1
    x[1412]   c4        1
    x[1412]   c1155     1
    x[1412]   c1156     1
    x[1412]   OBJ       -1
    x[1413]   c5        1
    x[1413]   c1438     1
    x[1413]   c1439     1
    x[1413]   OBJ       -1
    x[1414]   c6        1
    x[1414]   c1721     1
    x[1414]   c1722     1
    x[1414]   OBJ       -1
    x[1415]   c7        1
    x[1415]   c2004     1
    x[1415]   c2005     1
    x[1415]   OBJ       -1
    x[1416]   c8        1
    x[1416]   c2287     1
    x[1416]   c2288     1
    x[1416]   OBJ       -1
    x[1417]   c9        1
    x[1417]   c2570     1
    x[1417]   c2571     1
    x[1417]   OBJ       -1
    x[1418]   c10       1
    x[1418]   c2853     1
    x[1418]   c2854     1
    x[1418]   OBJ       -1
    x[1419]   c11       1
    x[1419]   c3136     1
    x[1419]   c3137     1
    x[1419]   OBJ       -1
    x[1420]   c12       1
    x[1420]   c3419     1
    x[1420]   c3420     1
    x[1420]   OBJ       -1
    x[1421]   c13       1
    x[1421]   c3702     1
    x[1421]   c3703     1
    x[1421]   OBJ       -1
    x[1422]   c14       1
    x[1422]   c3985     1
    x[1422]   c3986     1
    x[1422]   OBJ       -1
    x[1423]   c15       1
    x[1423]   c4268     1
    x[1423]   c4269     1
    x[1423]   OBJ       -1
    x[1424]   c16       1
    x[1424]   c4551     1
    x[1424]   c4552     1
    x[1424]   OBJ       -1
    x[1425]   c1        1
    x[1425]   c308      1
    x[1425]   c309      1
    x[1425]   OBJ       -1
    x[1426]   c2        1
    x[1426]   c591      1
    x[1426]   c592      1
    x[1426]   OBJ       -1
    x[1427]   c3        1
    x[1427]   c874      1
    x[1427]   c875      1
    x[1427]   OBJ       -1
    x[1428]   c4        1
    x[1428]   c1157     1
    x[1428]   c1158     1
    x[1428]   OBJ       -1
    x[1429]   c5        1
    x[1429]   c1440     1
    x[1429]   c1441     1
    x[1429]   OBJ       -1
    x[1430]   c6        1
    x[1430]   c1723     1
    x[1430]   c1724     1
    x[1430]   OBJ       -1
    x[1431]   c7        1
    x[1431]   c2006     1
    x[1431]   c2007     1
    x[1431]   OBJ       -1
    x[1432]   c8        1
    x[1432]   c2289     1
    x[1432]   c2290     1
    x[1432]   OBJ       -1
    x[1433]   c9        1
    x[1433]   c2572     1
    x[1433]   c2573     1
    x[1433]   OBJ       -1
    x[1434]   c10       1
    x[1434]   c2855     1
    x[1434]   c2856     1
    x[1434]   OBJ       -1
    x[1435]   c11       1
    x[1435]   c3138     1
    x[1435]   c3139     1
    x[1435]   OBJ       -1
    x[1436]   c12       1
    x[1436]   c3421     1
    x[1436]   c3422     1
    x[1436]   OBJ       -1
    x[1437]   c13       1
    x[1437]   c3704     1
    x[1437]   c3705     1
    x[1437]   OBJ       -1
    x[1438]   c14       1
    x[1438]   c3987     1
    x[1438]   c3988     1
    x[1438]   OBJ       -1
    x[1439]   c15       1
    x[1439]   c4270     1
    x[1439]   c4271     1
    x[1439]   OBJ       -1
    x[1440]   c16       1
    x[1440]   c4553     1
    x[1440]   c4554     1
    x[1440]   OBJ       -1
    x[1441]   c1        1
    x[1441]   c310      1
    x[1441]   OBJ       -1
    x[1442]   c2        1
    x[1442]   c593      1
    x[1442]   OBJ       -1
    x[1443]   c3        1
    x[1443]   c876      1
    x[1443]   OBJ       -1
    x[1444]   c4        1
    x[1444]   c1159     1
    x[1444]   OBJ       -1
    x[1445]   c5        1
    x[1445]   c1442     1
    x[1445]   OBJ       -1
    x[1446]   c6        1
    x[1446]   c1725     1
    x[1446]   OBJ       -1
    x[1447]   c7        1
    x[1447]   c2008     1
    x[1447]   OBJ       -1
    x[1448]   c8        1
    x[1448]   c2291     1
    x[1448]   OBJ       -1
    x[1449]   c9        1
    x[1449]   c2574     1
    x[1449]   OBJ       -1
    x[1450]   c10       1
    x[1450]   c2857     1
    x[1450]   OBJ       -1
    x[1451]   c11       1
    x[1451]   c3140     1
    x[1451]   OBJ       -1
    x[1452]   c12       1
    x[1452]   c3423     1
    x[1452]   OBJ       -1
    x[1453]   c13       1
    x[1453]   c3706     1
    x[1453]   OBJ       -1
    x[1454]   c14       1
    x[1454]   c3989     1
    x[1454]   OBJ       -1
    x[1455]   c15       1
    x[1455]   c4272     1
    x[1455]   OBJ       -1
    x[1456]   c16       1
    x[1456]   c4555     1
    x[1456]   OBJ       -1
    x[1457]   c1        1
    x[1457]   c311      1
    x[1457]   OBJ       -1
    x[1458]   c2        1
    x[1458]   c594      1
    x[1458]   OBJ       -1
    x[1459]   c3        1
    x[1459]   c877      1
    x[1459]   OBJ       -1
    x[1460]   c4        1
    x[1460]   c1160     1
    x[1460]   OBJ       -1
    x[1461]   c5        1
    x[1461]   c1443     1
    x[1461]   OBJ       -1
    x[1462]   c6        1
    x[1462]   c1726     1
    x[1462]   OBJ       -1
    x[1463]   c7        1
    x[1463]   c2009     1
    x[1463]   OBJ       -1
    x[1464]   c8        1
    x[1464]   c2292     1
    x[1464]   OBJ       -1
    x[1465]   c9        1
    x[1465]   c2575     1
    x[1465]   OBJ       -1
    x[1466]   c10       1
    x[1466]   c2858     1
    x[1466]   OBJ       -1
    x[1467]   c11       1
    x[1467]   c3141     1
    x[1467]   OBJ       -1
    x[1468]   c12       1
    x[1468]   c3424     1
    x[1468]   OBJ       -1
    x[1469]   c13       1
    x[1469]   c3707     1
    x[1469]   OBJ       -1
    x[1470]   c14       1
    x[1470]   c3990     1
    x[1470]   OBJ       -1
    x[1471]   c15       1
    x[1471]   c4273     1
    x[1471]   OBJ       -1
    x[1472]   c16       1
    x[1472]   c4556     1
    x[1472]   OBJ       -1
    x[1473]   c1        1
    x[1473]   c312      1
    x[1473]   OBJ       -1
    x[1474]   c2        1
    x[1474]   c595      1
    x[1474]   OBJ       -1
    x[1475]   c3        1
    x[1475]   c878      1
    x[1475]   OBJ       -1
    x[1476]   c4        1
    x[1476]   c1161     1
    x[1476]   OBJ       -1
    x[1477]   c5        1
    x[1477]   c1444     1
    x[1477]   OBJ       -1
    x[1478]   c6        1
    x[1478]   c1727     1
    x[1478]   OBJ       -1
    x[1479]   c7        1
    x[1479]   c2010     1
    x[1479]   OBJ       -1
    x[1480]   c8        1
    x[1480]   c2293     1
    x[1480]   OBJ       -1
    x[1481]   c9        1
    x[1481]   c2576     1
    x[1481]   OBJ       -1
    x[1482]   c10       1
    x[1482]   c2859     1
    x[1482]   OBJ       -1
    x[1483]   c11       1
    x[1483]   c3142     1
    x[1483]   OBJ       -1
    x[1484]   c12       1
    x[1484]   c3425     1
    x[1484]   OBJ       -1
    x[1485]   c13       1
    x[1485]   c3708     1
    x[1485]   OBJ       -1
    x[1486]   c14       1
    x[1486]   c3991     1
    x[1486]   OBJ       -1
    x[1487]   c15       1
    x[1487]   c4274     1
    x[1487]   OBJ       -1
    x[1488]   c16       1
    x[1488]   c4557     1
    x[1488]   OBJ       -1
    x[1489]   c1        1
    x[1489]   c313      1
    x[1489]   c314      1
    x[1489]   OBJ       -1
    x[1490]   c2        1
    x[1490]   c596      1
    x[1490]   c597      1
    x[1490]   OBJ       -1
    x[1491]   c3        1
    x[1491]   c879      1
    x[1491]   c880      1
    x[1491]   OBJ       -1
    x[1492]   c4        1
    x[1492]   c1162     1
    x[1492]   c1163     1
    x[1492]   OBJ       -1
    x[1493]   c5        1
    x[1493]   c1445     1
    x[1493]   c1446     1
    x[1493]   OBJ       -1
    x[1494]   c6        1
    x[1494]   c1728     1
    x[1494]   c1729     1
    x[1494]   OBJ       -1
    x[1495]   c7        1
    x[1495]   c2011     1
    x[1495]   c2012     1
    x[1495]   OBJ       -1
    x[1496]   c8        1
    x[1496]   c2294     1
    x[1496]   c2295     1
    x[1496]   OBJ       -1
    x[1497]   c9        1
    x[1497]   c2577     1
    x[1497]   c2578     1
    x[1497]   OBJ       -1
    x[1498]   c10       1
    x[1498]   c2860     1
    x[1498]   c2861     1
    x[1498]   OBJ       -1
    x[1499]   c11       1
    x[1499]   c3143     1
    x[1499]   c3144     1
    x[1499]   OBJ       -1
    x[1500]   c12       1
    x[1500]   c3426     1
    x[1500]   c3427     1
    x[1500]   OBJ       -1
    x[1501]   c13       1
    x[1501]   c3709     1
    x[1501]   c3710     1
    x[1501]   OBJ       -1
    x[1502]   c14       1
    x[1502]   c3992     1
    x[1502]   c3993     1
    x[1502]   OBJ       -1
    x[1503]   c15       1
    x[1503]   c4275     1
    x[1503]   c4276     1
    x[1503]   OBJ       -1
    x[1504]   c16       1
    x[1504]   c4558     1
    x[1504]   c4559     1
    x[1504]   OBJ       -1
    x[1505]   c1        1
    x[1505]   c315      1
    x[1505]   c316      1
    x[1505]   OBJ       -1
    x[1506]   c2        1
    x[1506]   c598      1
    x[1506]   c599      1
    x[1506]   OBJ       -1
    x[1507]   c3        1
    x[1507]   c881      1
    x[1507]   c882      1
    x[1507]   OBJ       -1
    x[1508]   c4        1
    x[1508]   c1164     1
    x[1508]   c1165     1
    x[1508]   OBJ       -1
    x[1509]   c5        1
    x[1509]   c1447     1
    x[1509]   c1448     1
    x[1509]   OBJ       -1
    x[1510]   c6        1
    x[1510]   c1730     1
    x[1510]   c1731     1
    x[1510]   OBJ       -1
    x[1511]   c7        1
    x[1511]   c2013     1
    x[1511]   c2014     1
    x[1511]   OBJ       -1
    x[1512]   c8        1
    x[1512]   c2296     1
    x[1512]   c2297     1
    x[1512]   OBJ       -1
    x[1513]   c9        1
    x[1513]   c2579     1
    x[1513]   c2580     1
    x[1513]   OBJ       -1
    x[1514]   c10       1
    x[1514]   c2862     1
    x[1514]   c2863     1
    x[1514]   OBJ       -1
    x[1515]   c11       1
    x[1515]   c3145     1
    x[1515]   c3146     1
    x[1515]   OBJ       -1
    x[1516]   c12       1
    x[1516]   c3428     1
    x[1516]   c3429     1
    x[1516]   OBJ       -1
    x[1517]   c13       1
    x[1517]   c3711     1
    x[1517]   c3712     1
    x[1517]   OBJ       -1
    x[1518]   c14       1
    x[1518]   c3994     1
    x[1518]   c3995     1
    x[1518]   OBJ       -1
    x[1519]   c15       1
    x[1519]   c4277     1
    x[1519]   c4278     1
    x[1519]   OBJ       -1
    x[1520]   c16       1
    x[1520]   c4560     1
    x[1520]   c4561     1
    x[1520]   OBJ       -1
    x[1521]   c1        1
    x[1521]   c317      1
    x[1521]   c318      1
    x[1521]   c319      1
    x[1521]   c320      1
    x[1521]   c321      1
    x[1521]   OBJ       -1
    x[1522]   c2        1
    x[1522]   c600      1
    x[1522]   c601      1
    x[1522]   c602      1
    x[1522]   c603      1
    x[1522]   c604      1
    x[1522]   OBJ       -1
    x[1523]   c3        1
    x[1523]   c883      1
    x[1523]   c884      1
    x[1523]   c885      1
    x[1523]   c886      1
    x[1523]   c887      1
    x[1523]   OBJ       -1
    x[1524]   c4        1
    x[1524]   c1166     1
    x[1524]   c1167     1
    x[1524]   c1168     1
    x[1524]   c1169     1
    x[1524]   c1170     1
    x[1524]   OBJ       -1
    x[1525]   c5        1
    x[1525]   c1449     1
    x[1525]   c1450     1
    x[1525]   c1451     1
    x[1525]   c1452     1
    x[1525]   c1453     1
    x[1525]   OBJ       -1
    x[1526]   c6        1
    x[1526]   c1732     1
    x[1526]   c1733     1
    x[1526]   c1734     1
    x[1526]   c1735     1
    x[1526]   c1736     1
    x[1526]   OBJ       -1
    x[1527]   c7        1
    x[1527]   c2015     1
    x[1527]   c2016     1
    x[1527]   c2017     1
    x[1527]   c2018     1
    x[1527]   c2019     1
    x[1527]   OBJ       -1
    x[1528]   c8        1
    x[1528]   c2298     1
    x[1528]   c2299     1
    x[1528]   c2300     1
    x[1528]   c2301     1
    x[1528]   c2302     1
    x[1528]   OBJ       -1
    x[1529]   c9        1
    x[1529]   c2581     1
    x[1529]   c2582     1
    x[1529]   c2583     1
    x[1529]   c2584     1
    x[1529]   c2585     1
    x[1529]   OBJ       -1
    x[1530]   c10       1
    x[1530]   c2864     1
    x[1530]   c2865     1
    x[1530]   c2866     1
    x[1530]   c2867     1
    x[1530]   c2868     1
    x[1530]   OBJ       -1
    x[1531]   c11       1
    x[1531]   c3147     1
    x[1531]   c3148     1
    x[1531]   c3149     1
    x[1531]   c3150     1
    x[1531]   c3151     1
    x[1531]   OBJ       -1
    x[1532]   c12       1
    x[1532]   c3430     1
    x[1532]   c3431     1
    x[1532]   c3432     1
    x[1532]   c3433     1
    x[1532]   c3434     1
    x[1532]   OBJ       -1
    x[1533]   c13       1
    x[1533]   c3713     1
    x[1533]   c3714     1
    x[1533]   c3715     1
    x[1533]   c3716     1
    x[1533]   c3717     1
    x[1533]   OBJ       -1
    x[1534]   c14       1
    x[1534]   c3996     1
    x[1534]   c3997     1
    x[1534]   c3998     1
    x[1534]   c3999     1
    x[1534]   c4000     1
    x[1534]   OBJ       -1
    x[1535]   c15       1
    x[1535]   c4279     1
    x[1535]   c4280     1
    x[1535]   c4281     1
    x[1535]   c4282     1
    x[1535]   c4283     1
    x[1535]   OBJ       -1
    x[1536]   c16       1
    x[1536]   c4562     1
    x[1536]   c4563     1
    x[1536]   c4564     1
    x[1536]   c4565     1
    x[1536]   c4566     1
    x[1536]   OBJ       -1
    x[1537]   c1        1
    x[1537]   c322      1
    x[1537]   OBJ       -1
    x[1538]   c2        1
    x[1538]   c605      1
    x[1538]   OBJ       -1
    x[1539]   c3        1
    x[1539]   c888      1
    x[1539]   OBJ       -1
    x[1540]   c4        1
    x[1540]   c1171     1
    x[1540]   OBJ       -1
    x[1541]   c5        1
    x[1541]   c1454     1
    x[1541]   OBJ       -1
    x[1542]   c6        1
    x[1542]   c1737     1
    x[1542]   OBJ       -1
    x[1543]   c7        1
    x[1543]   c2020     1
    x[1543]   OBJ       -1
    x[1544]   c8        1
    x[1544]   c2303     1
    x[1544]   OBJ       -1
    x[1545]   c9        1
    x[1545]   c2586     1
    x[1545]   OBJ       -1
    x[1546]   c10       1
    x[1546]   c2869     1
    x[1546]   OBJ       -1
    x[1547]   c11       1
    x[1547]   c3152     1
    x[1547]   OBJ       -1
    x[1548]   c12       1
    x[1548]   c3435     1
    x[1548]   OBJ       -1
    x[1549]   c13       1
    x[1549]   c3718     1
    x[1549]   OBJ       -1
    x[1550]   c14       1
    x[1550]   c4001     1
    x[1550]   OBJ       -1
    x[1551]   c15       1
    x[1551]   c4284     1
    x[1551]   OBJ       -1
    x[1552]   c16       1
    x[1552]   c4567     1
    x[1552]   OBJ       -1
    x[1553]   c1        1
    x[1553]   c323      1
    x[1553]   c324      1
    x[1553]   c325      1
    x[1553]   OBJ       -1
    x[1554]   c2        1
    x[1554]   c606      1
    x[1554]   c607      1
    x[1554]   c608      1
    x[1554]   OBJ       -1
    x[1555]   c3        1
    x[1555]   c889      1
    x[1555]   c890      1
    x[1555]   c891      1
    x[1555]   OBJ       -1
    x[1556]   c4        1
    x[1556]   c1172     1
    x[1556]   c1173     1
    x[1556]   c1174     1
    x[1556]   OBJ       -1
    x[1557]   c5        1
    x[1557]   c1455     1
    x[1557]   c1456     1
    x[1557]   c1457     1
    x[1557]   OBJ       -1
    x[1558]   c6        1
    x[1558]   c1738     1
    x[1558]   c1739     1
    x[1558]   c1740     1
    x[1558]   OBJ       -1
    x[1559]   c7        1
    x[1559]   c2021     1
    x[1559]   c2022     1
    x[1559]   c2023     1
    x[1559]   OBJ       -1
    x[1560]   c8        1
    x[1560]   c2304     1
    x[1560]   c2305     1
    x[1560]   c2306     1
    x[1560]   OBJ       -1
    x[1561]   c9        1
    x[1561]   c2587     1
    x[1561]   c2588     1
    x[1561]   c2589     1
    x[1561]   OBJ       -1
    x[1562]   c10       1
    x[1562]   c2870     1
    x[1562]   c2871     1
    x[1562]   c2872     1
    x[1562]   OBJ       -1
    x[1563]   c11       1
    x[1563]   c3153     1
    x[1563]   c3154     1
    x[1563]   c3155     1
    x[1563]   OBJ       -1
    x[1564]   c12       1
    x[1564]   c3436     1
    x[1564]   c3437     1
    x[1564]   c3438     1
    x[1564]   OBJ       -1
    x[1565]   c13       1
    x[1565]   c3719     1
    x[1565]   c3720     1
    x[1565]   c3721     1
    x[1565]   OBJ       -1
    x[1566]   c14       1
    x[1566]   c4002     1
    x[1566]   c4003     1
    x[1566]   c4004     1
    x[1566]   OBJ       -1
    x[1567]   c15       1
    x[1567]   c4285     1
    x[1567]   c4286     1
    x[1567]   c4287     1
    x[1567]   OBJ       -1
    x[1568]   c16       1
    x[1568]   c4568     1
    x[1568]   c4569     1
    x[1568]   c4570     1
    x[1568]   OBJ       -1
    x[1569]   c1        1
    x[1569]   c326      1
    x[1569]   OBJ       -1
    x[1570]   c2        1
    x[1570]   c609      1
    x[1570]   OBJ       -1
    x[1571]   c3        1
    x[1571]   c892      1
    x[1571]   OBJ       -1
    x[1572]   c4        1
    x[1572]   c1175     1
    x[1572]   OBJ       -1
    x[1573]   c5        1
    x[1573]   c1458     1
    x[1573]   OBJ       -1
    x[1574]   c6        1
    x[1574]   c1741     1
    x[1574]   OBJ       -1
    x[1575]   c7        1
    x[1575]   c2024     1
    x[1575]   OBJ       -1
    x[1576]   c8        1
    x[1576]   c2307     1
    x[1576]   OBJ       -1
    x[1577]   c9        1
    x[1577]   c2590     1
    x[1577]   OBJ       -1
    x[1578]   c10       1
    x[1578]   c2873     1
    x[1578]   OBJ       -1
    x[1579]   c11       1
    x[1579]   c3156     1
    x[1579]   OBJ       -1
    x[1580]   c12       1
    x[1580]   c3439     1
    x[1580]   OBJ       -1
    x[1581]   c13       1
    x[1581]   c3722     1
    x[1581]   OBJ       -1
    x[1582]   c14       1
    x[1582]   c4005     1
    x[1582]   OBJ       -1
    x[1583]   c15       1
    x[1583]   c4288     1
    x[1583]   OBJ       -1
    x[1584]   c16       1
    x[1584]   c4571     1
    x[1584]   OBJ       -1
    x[1585]   c1        1
    x[1585]   c327      1
    x[1585]   OBJ       -1
    x[1586]   c2        1
    x[1586]   c610      1
    x[1586]   OBJ       -1
    x[1587]   c3        1
    x[1587]   c893      1
    x[1587]   OBJ       -1
    x[1588]   c4        1
    x[1588]   c1176     1
    x[1588]   OBJ       -1
    x[1589]   c5        1
    x[1589]   c1459     1
    x[1589]   OBJ       -1
    x[1590]   c6        1
    x[1590]   c1742     1
    x[1590]   OBJ       -1
    x[1591]   c7        1
    x[1591]   c2025     1
    x[1591]   OBJ       -1
    x[1592]   c8        1
    x[1592]   c2308     1
    x[1592]   OBJ       -1
    x[1593]   c9        1
    x[1593]   c2591     1
    x[1593]   OBJ       -1
    x[1594]   c10       1
    x[1594]   c2874     1
    x[1594]   OBJ       -1
    x[1595]   c11       1
    x[1595]   c3157     1
    x[1595]   OBJ       -1
    x[1596]   c12       1
    x[1596]   c3440     1
    x[1596]   OBJ       -1
    x[1597]   c13       1
    x[1597]   c3723     1
    x[1597]   OBJ       -1
    x[1598]   c14       1
    x[1598]   c4006     1
    x[1598]   OBJ       -1
    x[1599]   c15       1
    x[1599]   c4289     1
    x[1599]   OBJ       -1
    x[1600]   c16       1
    x[1600]   c4572     1
    x[1600]   OBJ       -1
    x[1601]   c1        1
    x[1601]   c328      1
    x[1601]   c329      1
    x[1601]   c330      1
    x[1601]   c331      1
    x[1601]   c332      1
    x[1601]   c333      1
    x[1601]   OBJ       -1
    x[1602]   c2        1
    x[1602]   c611      1
    x[1602]   c612      1
    x[1602]   c613      1
    x[1602]   c614      1
    x[1602]   c615      1
    x[1602]   c616      1
    x[1602]   OBJ       -1
    x[1603]   c3        1
    x[1603]   c894      1
    x[1603]   c895      1
    x[1603]   c896      1
    x[1603]   c897      1
    x[1603]   c898      1
    x[1603]   c899      1
    x[1603]   OBJ       -1
    x[1604]   c4        1
    x[1604]   c1177     1
    x[1604]   c1178     1
    x[1604]   c1179     1
    x[1604]   c1180     1
    x[1604]   c1181     1
    x[1604]   c1182     1
    x[1604]   OBJ       -1
    x[1605]   c5        1
    x[1605]   c1460     1
    x[1605]   c1461     1
    x[1605]   c1462     1
    x[1605]   c1463     1
    x[1605]   c1464     1
    x[1605]   c1465     1
    x[1605]   OBJ       -1
    x[1606]   c6        1
    x[1606]   c1743     1
    x[1606]   c1744     1
    x[1606]   c1745     1
    x[1606]   c1746     1
    x[1606]   c1747     1
    x[1606]   c1748     1
    x[1606]   OBJ       -1
    x[1607]   c7        1
    x[1607]   c2026     1
    x[1607]   c2027     1
    x[1607]   c2028     1
    x[1607]   c2029     1
    x[1607]   c2030     1
    x[1607]   c2031     1
    x[1607]   OBJ       -1
    x[1608]   c8        1
    x[1608]   c2309     1
    x[1608]   c2310     1
    x[1608]   c2311     1
    x[1608]   c2312     1
    x[1608]   c2313     1
    x[1608]   c2314     1
    x[1608]   OBJ       -1
    x[1609]   c9        1
    x[1609]   c2592     1
    x[1609]   c2593     1
    x[1609]   c2594     1
    x[1609]   c2595     1
    x[1609]   c2596     1
    x[1609]   c2597     1
    x[1609]   OBJ       -1
    x[1610]   c10       1
    x[1610]   c2875     1
    x[1610]   c2876     1
    x[1610]   c2877     1
    x[1610]   c2878     1
    x[1610]   c2879     1
    x[1610]   c2880     1
    x[1610]   OBJ       -1
    x[1611]   c11       1
    x[1611]   c3158     1
    x[1611]   c3159     1
    x[1611]   c3160     1
    x[1611]   c3161     1
    x[1611]   c3162     1
    x[1611]   c3163     1
    x[1611]   OBJ       -1
    x[1612]   c12       1
    x[1612]   c3441     1
    x[1612]   c3442     1
    x[1612]   c3443     1
    x[1612]   c3444     1
    x[1612]   c3445     1
    x[1612]   c3446     1
    x[1612]   OBJ       -1
    x[1613]   c13       1
    x[1613]   c3724     1
    x[1613]   c3725     1
    x[1613]   c3726     1
    x[1613]   c3727     1
    x[1613]   c3728     1
    x[1613]   c3729     1
    x[1613]   OBJ       -1
    x[1614]   c14       1
    x[1614]   c4007     1
    x[1614]   c4008     1
    x[1614]   c4009     1
    x[1614]   c4010     1
    x[1614]   c4011     1
    x[1614]   c4012     1
    x[1614]   OBJ       -1
    x[1615]   c15       1
    x[1615]   c4290     1
    x[1615]   c4291     1
    x[1615]   c4292     1
    x[1615]   c4293     1
    x[1615]   c4294     1
    x[1615]   c4295     1
    x[1615]   OBJ       -1
    x[1616]   c16       1
    x[1616]   c4573     1
    x[1616]   c4574     1
    x[1616]   c4575     1
    x[1616]   c4576     1
    x[1616]   c4577     1
    x[1616]   c4578     1
    x[1616]   OBJ       -1
    x[1617]   c1        1
    x[1617]   c334      1
    x[1617]   c335      1
    x[1617]   c336      1
    x[1617]   OBJ       -1
    x[1618]   c2        1
    x[1618]   c617      1
    x[1618]   c618      1
    x[1618]   c619      1
    x[1618]   OBJ       -1
    x[1619]   c3        1
    x[1619]   c900      1
    x[1619]   c901      1
    x[1619]   c902      1
    x[1619]   OBJ       -1
    x[1620]   c4        1
    x[1620]   c1183     1
    x[1620]   c1184     1
    x[1620]   c1185     1
    x[1620]   OBJ       -1
    x[1621]   c5        1
    x[1621]   c1466     1
    x[1621]   c1467     1
    x[1621]   c1468     1
    x[1621]   OBJ       -1
    x[1622]   c6        1
    x[1622]   c1749     1
    x[1622]   c1750     1
    x[1622]   c1751     1
    x[1622]   OBJ       -1
    x[1623]   c7        1
    x[1623]   c2032     1
    x[1623]   c2033     1
    x[1623]   c2034     1
    x[1623]   OBJ       -1
    x[1624]   c8        1
    x[1624]   c2315     1
    x[1624]   c2316     1
    x[1624]   c2317     1
    x[1624]   OBJ       -1
    x[1625]   c9        1
    x[1625]   c2598     1
    x[1625]   c2599     1
    x[1625]   c2600     1
    x[1625]   OBJ       -1
    x[1626]   c10       1
    x[1626]   c2881     1
    x[1626]   c2882     1
    x[1626]   c2883     1
    x[1626]   OBJ       -1
    x[1627]   c11       1
    x[1627]   c3164     1
    x[1627]   c3165     1
    x[1627]   c3166     1
    x[1627]   OBJ       -1
    x[1628]   c12       1
    x[1628]   c3447     1
    x[1628]   c3448     1
    x[1628]   c3449     1
    x[1628]   OBJ       -1
    x[1629]   c13       1
    x[1629]   c3730     1
    x[1629]   c3731     1
    x[1629]   c3732     1
    x[1629]   OBJ       -1
    x[1630]   c14       1
    x[1630]   c4013     1
    x[1630]   c4014     1
    x[1630]   c4015     1
    x[1630]   OBJ       -1
    x[1631]   c15       1
    x[1631]   c4296     1
    x[1631]   c4297     1
    x[1631]   c4298     1
    x[1631]   OBJ       -1
    x[1632]   c16       1
    x[1632]   c4579     1
    x[1632]   c4580     1
    x[1632]   c4581     1
    x[1632]   OBJ       -1
    x[1633]   c1        1
    x[1633]   c337      1
    x[1633]   c338      1
    x[1633]   c339      1
    x[1633]   c340      1
    x[1633]   OBJ       -1
    x[1634]   c2        1
    x[1634]   c620      1
    x[1634]   c621      1
    x[1634]   c622      1
    x[1634]   c623      1
    x[1634]   OBJ       -1
    x[1635]   c3        1
    x[1635]   c903      1
    x[1635]   c904      1
    x[1635]   c905      1
    x[1635]   c906      1
    x[1635]   OBJ       -1
    x[1636]   c4        1
    x[1636]   c1186     1
    x[1636]   c1187     1
    x[1636]   c1188     1
    x[1636]   c1189     1
    x[1636]   OBJ       -1
    x[1637]   c5        1
    x[1637]   c1469     1
    x[1637]   c1470     1
    x[1637]   c1471     1
    x[1637]   c1472     1
    x[1637]   OBJ       -1
    x[1638]   c6        1
    x[1638]   c1752     1
    x[1638]   c1753     1
    x[1638]   c1754     1
    x[1638]   c1755     1
    x[1638]   OBJ       -1
    x[1639]   c7        1
    x[1639]   c2035     1
    x[1639]   c2036     1
    x[1639]   c2037     1
    x[1639]   c2038     1
    x[1639]   OBJ       -1
    x[1640]   c8        1
    x[1640]   c2318     1
    x[1640]   c2319     1
    x[1640]   c2320     1
    x[1640]   c2321     1
    x[1640]   OBJ       -1
    x[1641]   c9        1
    x[1641]   c2601     1
    x[1641]   c2602     1
    x[1641]   c2603     1
    x[1641]   c2604     1
    x[1641]   OBJ       -1
    x[1642]   c10       1
    x[1642]   c2884     1
    x[1642]   c2885     1
    x[1642]   c2886     1
    x[1642]   c2887     1
    x[1642]   OBJ       -1
    x[1643]   c11       1
    x[1643]   c3167     1
    x[1643]   c3168     1
    x[1643]   c3169     1
    x[1643]   c3170     1
    x[1643]   OBJ       -1
    x[1644]   c12       1
    x[1644]   c3450     1
    x[1644]   c3451     1
    x[1644]   c3452     1
    x[1644]   c3453     1
    x[1644]   OBJ       -1
    x[1645]   c13       1
    x[1645]   c3733     1
    x[1645]   c3734     1
    x[1645]   c3735     1
    x[1645]   c3736     1
    x[1645]   OBJ       -1
    x[1646]   c14       1
    x[1646]   c4016     1
    x[1646]   c4017     1
    x[1646]   c4018     1
    x[1646]   c4019     1
    x[1646]   OBJ       -1
    x[1647]   c15       1
    x[1647]   c4299     1
    x[1647]   c4300     1
    x[1647]   c4301     1
    x[1647]   c4302     1
    x[1647]   OBJ       -1
    x[1648]   c16       1
    x[1648]   c4582     1
    x[1648]   c4583     1
    x[1648]   c4584     1
    x[1648]   c4585     1
    x[1648]   OBJ       -1
    x[1649]   c1        1
    x[1649]   c341      1
    x[1649]   OBJ       -1
    x[1650]   c2        1
    x[1650]   c624      1
    x[1650]   OBJ       -1
    x[1651]   c3        1
    x[1651]   c907      1
    x[1651]   OBJ       -1
    x[1652]   c4        1
    x[1652]   c1190     1
    x[1652]   OBJ       -1
    x[1653]   c5        1
    x[1653]   c1473     1
    x[1653]   OBJ       -1
    x[1654]   c6        1
    x[1654]   c1756     1
    x[1654]   OBJ       -1
    x[1655]   c7        1
    x[1655]   c2039     1
    x[1655]   OBJ       -1
    x[1656]   c8        1
    x[1656]   c2322     1
    x[1656]   OBJ       -1
    x[1657]   c9        1
    x[1657]   c2605     1
    x[1657]   OBJ       -1
    x[1658]   c10       1
    x[1658]   c2888     1
    x[1658]   OBJ       -1
    x[1659]   c11       1
    x[1659]   c3171     1
    x[1659]   OBJ       -1
    x[1660]   c12       1
    x[1660]   c3454     1
    x[1660]   OBJ       -1
    x[1661]   c13       1
    x[1661]   c3737     1
    x[1661]   OBJ       -1
    x[1662]   c14       1
    x[1662]   c4020     1
    x[1662]   OBJ       -1
    x[1663]   c15       1
    x[1663]   c4303     1
    x[1663]   OBJ       -1
    x[1664]   c16       1
    x[1664]   c4586     1
    x[1664]   OBJ       -1
    x[1665]   c1        1
    x[1665]   c342      1
    x[1665]   OBJ       -1
    x[1666]   c2        1
    x[1666]   c625      1
    x[1666]   OBJ       -1
    x[1667]   c3        1
    x[1667]   c908      1
    x[1667]   OBJ       -1
    x[1668]   c4        1
    x[1668]   c1191     1
    x[1668]   OBJ       -1
    x[1669]   c5        1
    x[1669]   c1474     1
    x[1669]   OBJ       -1
    x[1670]   c6        1
    x[1670]   c1757     1
    x[1670]   OBJ       -1
    x[1671]   c7        1
    x[1671]   c2040     1
    x[1671]   OBJ       -1
    x[1672]   c8        1
    x[1672]   c2323     1
    x[1672]   OBJ       -1
    x[1673]   c9        1
    x[1673]   c2606     1
    x[1673]   OBJ       -1
    x[1674]   c10       1
    x[1674]   c2889     1
    x[1674]   OBJ       -1
    x[1675]   c11       1
    x[1675]   c3172     1
    x[1675]   OBJ       -1
    x[1676]   c12       1
    x[1676]   c3455     1
    x[1676]   OBJ       -1
    x[1677]   c13       1
    x[1677]   c3738     1
    x[1677]   OBJ       -1
    x[1678]   c14       1
    x[1678]   c4021     1
    x[1678]   OBJ       -1
    x[1679]   c15       1
    x[1679]   c4304     1
    x[1679]   OBJ       -1
    x[1680]   c16       1
    x[1680]   c4587     1
    x[1680]   OBJ       -1
    x[1681]   c1        1
    x[1681]   c343      1
    x[1681]   c344      1
    x[1681]   OBJ       -1
    x[1682]   c2        1
    x[1682]   c626      1
    x[1682]   c627      1
    x[1682]   OBJ       -1
    x[1683]   c3        1
    x[1683]   c909      1
    x[1683]   c910      1
    x[1683]   OBJ       -1
    x[1684]   c4        1
    x[1684]   c1192     1
    x[1684]   c1193     1
    x[1684]   OBJ       -1
    x[1685]   c5        1
    x[1685]   c1475     1
    x[1685]   c1476     1
    x[1685]   OBJ       -1
    x[1686]   c6        1
    x[1686]   c1758     1
    x[1686]   c1759     1
    x[1686]   OBJ       -1
    x[1687]   c7        1
    x[1687]   c2041     1
    x[1687]   c2042     1
    x[1687]   OBJ       -1
    x[1688]   c8        1
    x[1688]   c2324     1
    x[1688]   c2325     1
    x[1688]   OBJ       -1
    x[1689]   c9        1
    x[1689]   c2607     1
    x[1689]   c2608     1
    x[1689]   OBJ       -1
    x[1690]   c10       1
    x[1690]   c2890     1
    x[1690]   c2891     1
    x[1690]   OBJ       -1
    x[1691]   c11       1
    x[1691]   c3173     1
    x[1691]   c3174     1
    x[1691]   OBJ       -1
    x[1692]   c12       1
    x[1692]   c3456     1
    x[1692]   c3457     1
    x[1692]   OBJ       -1
    x[1693]   c13       1
    x[1693]   c3739     1
    x[1693]   c3740     1
    x[1693]   OBJ       -1
    x[1694]   c14       1
    x[1694]   c4022     1
    x[1694]   c4023     1
    x[1694]   OBJ       -1
    x[1695]   c15       1
    x[1695]   c4305     1
    x[1695]   c4306     1
    x[1695]   OBJ       -1
    x[1696]   c16       1
    x[1696]   c4588     1
    x[1696]   c4589     1
    x[1696]   OBJ       -1
    x[1697]   c1        1
    x[1697]   c345      1
    x[1697]   c346      1
    x[1697]   OBJ       -1
    x[1698]   c2        1
    x[1698]   c628      1
    x[1698]   c629      1
    x[1698]   OBJ       -1
    x[1699]   c3        1
    x[1699]   c911      1
    x[1699]   c912      1
    x[1699]   OBJ       -1
    x[1700]   c4        1
    x[1700]   c1194     1
    x[1700]   c1195     1
    x[1700]   OBJ       -1
    x[1701]   c5        1
    x[1701]   c1477     1
    x[1701]   c1478     1
    x[1701]   OBJ       -1
    x[1702]   c6        1
    x[1702]   c1760     1
    x[1702]   c1761     1
    x[1702]   OBJ       -1
    x[1703]   c7        1
    x[1703]   c2043     1
    x[1703]   c2044     1
    x[1703]   OBJ       -1
    x[1704]   c8        1
    x[1704]   c2326     1
    x[1704]   c2327     1
    x[1704]   OBJ       -1
    x[1705]   c9        1
    x[1705]   c2609     1
    x[1705]   c2610     1
    x[1705]   OBJ       -1
    x[1706]   c10       1
    x[1706]   c2892     1
    x[1706]   c2893     1
    x[1706]   OBJ       -1
    x[1707]   c11       1
    x[1707]   c3175     1
    x[1707]   c3176     1
    x[1707]   OBJ       -1
    x[1708]   c12       1
    x[1708]   c3458     1
    x[1708]   c3459     1
    x[1708]   OBJ       -1
    x[1709]   c13       1
    x[1709]   c3741     1
    x[1709]   c3742     1
    x[1709]   OBJ       -1
    x[1710]   c14       1
    x[1710]   c4024     1
    x[1710]   c4025     1
    x[1710]   OBJ       -1
    x[1711]   c15       1
    x[1711]   c4307     1
    x[1711]   c4308     1
    x[1711]   OBJ       -1
    x[1712]   c16       1
    x[1712]   c4590     1
    x[1712]   c4591     1
    x[1712]   OBJ       -1
    x[1713]   c1        1
    x[1713]   c347      1
    x[1713]   c348      1
    x[1713]   c349      1
    x[1713]   c350      1
    x[1713]   OBJ       -1
    x[1714]   c2        1
    x[1714]   c630      1
    x[1714]   c631      1
    x[1714]   c632      1
    x[1714]   c633      1
    x[1714]   OBJ       -1
    x[1715]   c3        1
    x[1715]   c913      1
    x[1715]   c914      1
    x[1715]   c915      1
    x[1715]   c916      1
    x[1715]   OBJ       -1
    x[1716]   c4        1
    x[1716]   c1196     1
    x[1716]   c1197     1
    x[1716]   c1198     1
    x[1716]   c1199     1
    x[1716]   OBJ       -1
    x[1717]   c5        1
    x[1717]   c1479     1
    x[1717]   c1480     1
    x[1717]   c1481     1
    x[1717]   c1482     1
    x[1717]   OBJ       -1
    x[1718]   c6        1
    x[1718]   c1762     1
    x[1718]   c1763     1
    x[1718]   c1764     1
    x[1718]   c1765     1
    x[1718]   OBJ       -1
    x[1719]   c7        1
    x[1719]   c2045     1
    x[1719]   c2046     1
    x[1719]   c2047     1
    x[1719]   c2048     1
    x[1719]   OBJ       -1
    x[1720]   c8        1
    x[1720]   c2328     1
    x[1720]   c2329     1
    x[1720]   c2330     1
    x[1720]   c2331     1
    x[1720]   OBJ       -1
    x[1721]   c9        1
    x[1721]   c2611     1
    x[1721]   c2612     1
    x[1721]   c2613     1
    x[1721]   c2614     1
    x[1721]   OBJ       -1
    x[1722]   c10       1
    x[1722]   c2894     1
    x[1722]   c2895     1
    x[1722]   c2896     1
    x[1722]   c2897     1
    x[1722]   OBJ       -1
    x[1723]   c11       1
    x[1723]   c3177     1
    x[1723]   c3178     1
    x[1723]   c3179     1
    x[1723]   c3180     1
    x[1723]   OBJ       -1
    x[1724]   c12       1
    x[1724]   c3460     1
    x[1724]   c3461     1
    x[1724]   c3462     1
    x[1724]   c3463     1
    x[1724]   OBJ       -1
    x[1725]   c13       1
    x[1725]   c3743     1
    x[1725]   c3744     1
    x[1725]   c3745     1
    x[1725]   c3746     1
    x[1725]   OBJ       -1
    x[1726]   c14       1
    x[1726]   c4026     1
    x[1726]   c4027     1
    x[1726]   c4028     1
    x[1726]   c4029     1
    x[1726]   OBJ       -1
    x[1727]   c15       1
    x[1727]   c4309     1
    x[1727]   c4310     1
    x[1727]   c4311     1
    x[1727]   c4312     1
    x[1727]   OBJ       -1
    x[1728]   c16       1
    x[1728]   c4592     1
    x[1728]   c4593     1
    x[1728]   c4594     1
    x[1728]   c4595     1
    x[1728]   OBJ       -1
    x[1729]   c1        1
    x[1729]   c351      1
    x[1729]   OBJ       -1
    x[1730]   c2        1
    x[1730]   c634      1
    x[1730]   OBJ       -1
    x[1731]   c3        1
    x[1731]   c917      1
    x[1731]   OBJ       -1
    x[1732]   c4        1
    x[1732]   c1200     1
    x[1732]   OBJ       -1
    x[1733]   c5        1
    x[1733]   c1483     1
    x[1733]   OBJ       -1
    x[1734]   c6        1
    x[1734]   c1766     1
    x[1734]   OBJ       -1
    x[1735]   c7        1
    x[1735]   c2049     1
    x[1735]   OBJ       -1
    x[1736]   c8        1
    x[1736]   c2332     1
    x[1736]   OBJ       -1
    x[1737]   c9        1
    x[1737]   c2615     1
    x[1737]   OBJ       -1
    x[1738]   c10       1
    x[1738]   c2898     1
    x[1738]   OBJ       -1
    x[1739]   c11       1
    x[1739]   c3181     1
    x[1739]   OBJ       -1
    x[1740]   c12       1
    x[1740]   c3464     1
    x[1740]   OBJ       -1
    x[1741]   c13       1
    x[1741]   c3747     1
    x[1741]   OBJ       -1
    x[1742]   c14       1
    x[1742]   c4030     1
    x[1742]   OBJ       -1
    x[1743]   c15       1
    x[1743]   c4313     1
    x[1743]   OBJ       -1
    x[1744]   c16       1
    x[1744]   c4596     1
    x[1744]   OBJ       -1
    x[1745]   c1        1
    x[1745]   c352      1
    x[1745]   c353      1
    x[1745]   c354      1
    x[1745]   c355      1
    x[1745]   c356      1
    x[1745]   OBJ       -1
    x[1746]   c2        1
    x[1746]   c635      1
    x[1746]   c636      1
    x[1746]   c637      1
    x[1746]   c638      1
    x[1746]   c639      1
    x[1746]   OBJ       -1
    x[1747]   c3        1
    x[1747]   c918      1
    x[1747]   c919      1
    x[1747]   c920      1
    x[1747]   c921      1
    x[1747]   c922      1
    x[1747]   OBJ       -1
    x[1748]   c4        1
    x[1748]   c1201     1
    x[1748]   c1202     1
    x[1748]   c1203     1
    x[1748]   c1204     1
    x[1748]   c1205     1
    x[1748]   OBJ       -1
    x[1749]   c5        1
    x[1749]   c1484     1
    x[1749]   c1485     1
    x[1749]   c1486     1
    x[1749]   c1487     1
    x[1749]   c1488     1
    x[1749]   OBJ       -1
    x[1750]   c6        1
    x[1750]   c1767     1
    x[1750]   c1768     1
    x[1750]   c1769     1
    x[1750]   c1770     1
    x[1750]   c1771     1
    x[1750]   OBJ       -1
    x[1751]   c7        1
    x[1751]   c2050     1
    x[1751]   c2051     1
    x[1751]   c2052     1
    x[1751]   c2053     1
    x[1751]   c2054     1
    x[1751]   OBJ       -1
    x[1752]   c8        1
    x[1752]   c2333     1
    x[1752]   c2334     1
    x[1752]   c2335     1
    x[1752]   c2336     1
    x[1752]   c2337     1
    x[1752]   OBJ       -1
    x[1753]   c9        1
    x[1753]   c2616     1
    x[1753]   c2617     1
    x[1753]   c2618     1
    x[1753]   c2619     1
    x[1753]   c2620     1
    x[1753]   OBJ       -1
    x[1754]   c10       1
    x[1754]   c2899     1
    x[1754]   c2900     1
    x[1754]   c2901     1
    x[1754]   c2902     1
    x[1754]   c2903     1
    x[1754]   OBJ       -1
    x[1755]   c11       1
    x[1755]   c3182     1
    x[1755]   c3183     1
    x[1755]   c3184     1
    x[1755]   c3185     1
    x[1755]   c3186     1
    x[1755]   OBJ       -1
    x[1756]   c12       1
    x[1756]   c3465     1
    x[1756]   c3466     1
    x[1756]   c3467     1
    x[1756]   c3468     1
    x[1756]   c3469     1
    x[1756]   OBJ       -1
    x[1757]   c13       1
    x[1757]   c3748     1
    x[1757]   c3749     1
    x[1757]   c3750     1
    x[1757]   c3751     1
    x[1757]   c3752     1
    x[1757]   OBJ       -1
    x[1758]   c14       1
    x[1758]   c4031     1
    x[1758]   c4032     1
    x[1758]   c4033     1
    x[1758]   c4034     1
    x[1758]   c4035     1
    x[1758]   OBJ       -1
    x[1759]   c15       1
    x[1759]   c4314     1
    x[1759]   c4315     1
    x[1759]   c4316     1
    x[1759]   c4317     1
    x[1759]   c4318     1
    x[1759]   OBJ       -1
    x[1760]   c16       1
    x[1760]   c4597     1
    x[1760]   c4598     1
    x[1760]   c4599     1
    x[1760]   c4600     1
    x[1760]   c4601     1
    x[1760]   OBJ       -1
    x[1761]   c1        1
    x[1761]   c357      1
    x[1761]   OBJ       -1
    x[1762]   c2        1
    x[1762]   c640      1
    x[1762]   OBJ       -1
    x[1763]   c3        1
    x[1763]   c923      1
    x[1763]   OBJ       -1
    x[1764]   c4        1
    x[1764]   c1206     1
    x[1764]   OBJ       -1
    x[1765]   c5        1
    x[1765]   c1489     1
    x[1765]   OBJ       -1
    x[1766]   c6        1
    x[1766]   c1772     1
    x[1766]   OBJ       -1
    x[1767]   c7        1
    x[1767]   c2055     1
    x[1767]   OBJ       -1
    x[1768]   c8        1
    x[1768]   c2338     1
    x[1768]   OBJ       -1
    x[1769]   c9        1
    x[1769]   c2621     1
    x[1769]   OBJ       -1
    x[1770]   c10       1
    x[1770]   c2904     1
    x[1770]   OBJ       -1
    x[1771]   c11       1
    x[1771]   c3187     1
    x[1771]   OBJ       -1
    x[1772]   c12       1
    x[1772]   c3470     1
    x[1772]   OBJ       -1
    x[1773]   c13       1
    x[1773]   c3753     1
    x[1773]   OBJ       -1
    x[1774]   c14       1
    x[1774]   c4036     1
    x[1774]   OBJ       -1
    x[1775]   c15       1
    x[1775]   c4319     1
    x[1775]   OBJ       -1
    x[1776]   c16       1
    x[1776]   c4602     1
    x[1776]   OBJ       -1
    x[1777]   c1        1
    x[1777]   c358      1
    x[1777]   c359      1
    x[1777]   OBJ       -1
    x[1778]   c2        1
    x[1778]   c641      1
    x[1778]   c642      1
    x[1778]   OBJ       -1
    x[1779]   c3        1
    x[1779]   c924      1
    x[1779]   c925      1
    x[1779]   OBJ       -1
    x[1780]   c4        1
    x[1780]   c1207     1
    x[1780]   c1208     1
    x[1780]   OBJ       -1
    x[1781]   c5        1
    x[1781]   c1490     1
    x[1781]   c1491     1
    x[1781]   OBJ       -1
    x[1782]   c6        1
    x[1782]   c1773     1
    x[1782]   c1774     1
    x[1782]   OBJ       -1
    x[1783]   c7        1
    x[1783]   c2056     1
    x[1783]   c2057     1
    x[1783]   OBJ       -1
    x[1784]   c8        1
    x[1784]   c2339     1
    x[1784]   c2340     1
    x[1784]   OBJ       -1
    x[1785]   c9        1
    x[1785]   c2622     1
    x[1785]   c2623     1
    x[1785]   OBJ       -1
    x[1786]   c10       1
    x[1786]   c2905     1
    x[1786]   c2906     1
    x[1786]   OBJ       -1
    x[1787]   c11       1
    x[1787]   c3188     1
    x[1787]   c3189     1
    x[1787]   OBJ       -1
    x[1788]   c12       1
    x[1788]   c3471     1
    x[1788]   c3472     1
    x[1788]   OBJ       -1
    x[1789]   c13       1
    x[1789]   c3754     1
    x[1789]   c3755     1
    x[1789]   OBJ       -1
    x[1790]   c14       1
    x[1790]   c4037     1
    x[1790]   c4038     1
    x[1790]   OBJ       -1
    x[1791]   c15       1
    x[1791]   c4320     1
    x[1791]   c4321     1
    x[1791]   OBJ       -1
    x[1792]   c16       1
    x[1792]   c4603     1
    x[1792]   c4604     1
    x[1792]   OBJ       -1
    x[1793]   c1        1
    x[1793]   c360      1
    x[1793]   c361      1
    x[1793]   c362      1
    x[1793]   c363      1
    x[1793]   OBJ       -1
    x[1794]   c2        1
    x[1794]   c643      1
    x[1794]   c644      1
    x[1794]   c645      1
    x[1794]   c646      1
    x[1794]   OBJ       -1
    x[1795]   c3        1
    x[1795]   c926      1
    x[1795]   c927      1
    x[1795]   c928      1
    x[1795]   c929      1
    x[1795]   OBJ       -1
    x[1796]   c4        1
    x[1796]   c1209     1
    x[1796]   c1210     1
    x[1796]   c1211     1
    x[1796]   c1212     1
    x[1796]   OBJ       -1
    x[1797]   c5        1
    x[1797]   c1492     1
    x[1797]   c1493     1
    x[1797]   c1494     1
    x[1797]   c1495     1
    x[1797]   OBJ       -1
    x[1798]   c6        1
    x[1798]   c1775     1
    x[1798]   c1776     1
    x[1798]   c1777     1
    x[1798]   c1778     1
    x[1798]   OBJ       -1
    x[1799]   c7        1
    x[1799]   c2058     1
    x[1799]   c2059     1
    x[1799]   c2060     1
    x[1799]   c2061     1
    x[1799]   OBJ       -1
    x[1800]   c8        1
    x[1800]   c2341     1
    x[1800]   c2342     1
    x[1800]   c2343     1
    x[1800]   c2344     1
    x[1800]   OBJ       -1
    x[1801]   c9        1
    x[1801]   c2624     1
    x[1801]   c2625     1
    x[1801]   c2626     1
    x[1801]   c2627     1
    x[1801]   OBJ       -1
    x[1802]   c10       1
    x[1802]   c2907     1
    x[1802]   c2908     1
    x[1802]   c2909     1
    x[1802]   c2910     1
    x[1802]   OBJ       -1
    x[1803]   c11       1
    x[1803]   c3190     1
    x[1803]   c3191     1
    x[1803]   c3192     1
    x[1803]   c3193     1
    x[1803]   OBJ       -1
    x[1804]   c12       1
    x[1804]   c3473     1
    x[1804]   c3474     1
    x[1804]   c3475     1
    x[1804]   c3476     1
    x[1804]   OBJ       -1
    x[1805]   c13       1
    x[1805]   c3756     1
    x[1805]   c3757     1
    x[1805]   c3758     1
    x[1805]   c3759     1
    x[1805]   OBJ       -1
    x[1806]   c14       1
    x[1806]   c4039     1
    x[1806]   c4040     1
    x[1806]   c4041     1
    x[1806]   c4042     1
    x[1806]   OBJ       -1
    x[1807]   c15       1
    x[1807]   c4322     1
    x[1807]   c4323     1
    x[1807]   c4324     1
    x[1807]   c4325     1
    x[1807]   OBJ       -1
    x[1808]   c16       1
    x[1808]   c4605     1
    x[1808]   c4606     1
    x[1808]   c4607     1
    x[1808]   c4608     1
    x[1808]   OBJ       -1
    x[1809]   c1        1
    x[1809]   c364      1
    x[1809]   c365      1
    x[1809]   c366      1
    x[1809]   c367      1
    x[1809]   OBJ       -1
    x[1810]   c2        1
    x[1810]   c647      1
    x[1810]   c648      1
    x[1810]   c649      1
    x[1810]   c650      1
    x[1810]   OBJ       -1
    x[1811]   c3        1
    x[1811]   c930      1
    x[1811]   c931      1
    x[1811]   c932      1
    x[1811]   c933      1
    x[1811]   OBJ       -1
    x[1812]   c4        1
    x[1812]   c1213     1
    x[1812]   c1214     1
    x[1812]   c1215     1
    x[1812]   c1216     1
    x[1812]   OBJ       -1
    x[1813]   c5        1
    x[1813]   c1496     1
    x[1813]   c1497     1
    x[1813]   c1498     1
    x[1813]   c1499     1
    x[1813]   OBJ       -1
    x[1814]   c6        1
    x[1814]   c1779     1
    x[1814]   c1780     1
    x[1814]   c1781     1
    x[1814]   c1782     1
    x[1814]   OBJ       -1
    x[1815]   c7        1
    x[1815]   c2062     1
    x[1815]   c2063     1
    x[1815]   c2064     1
    x[1815]   c2065     1
    x[1815]   OBJ       -1
    x[1816]   c8        1
    x[1816]   c2345     1
    x[1816]   c2346     1
    x[1816]   c2347     1
    x[1816]   c2348     1
    x[1816]   OBJ       -1
    x[1817]   c9        1
    x[1817]   c2628     1
    x[1817]   c2629     1
    x[1817]   c2630     1
    x[1817]   c2631     1
    x[1817]   OBJ       -1
    x[1818]   c10       1
    x[1818]   c2911     1
    x[1818]   c2912     1
    x[1818]   c2913     1
    x[1818]   c2914     1
    x[1818]   OBJ       -1
    x[1819]   c11       1
    x[1819]   c3194     1
    x[1819]   c3195     1
    x[1819]   c3196     1
    x[1819]   c3197     1
    x[1819]   OBJ       -1
    x[1820]   c12       1
    x[1820]   c3477     1
    x[1820]   c3478     1
    x[1820]   c3479     1
    x[1820]   c3480     1
    x[1820]   OBJ       -1
    x[1821]   c13       1
    x[1821]   c3760     1
    x[1821]   c3761     1
    x[1821]   c3762     1
    x[1821]   c3763     1
    x[1821]   OBJ       -1
    x[1822]   c14       1
    x[1822]   c4043     1
    x[1822]   c4044     1
    x[1822]   c4045     1
    x[1822]   c4046     1
    x[1822]   OBJ       -1
    x[1823]   c15       1
    x[1823]   c4326     1
    x[1823]   c4327     1
    x[1823]   c4328     1
    x[1823]   c4329     1
    x[1823]   OBJ       -1
    x[1824]   c16       1
    x[1824]   c4609     1
    x[1824]   c4610     1
    x[1824]   c4611     1
    x[1824]   c4612     1
    x[1824]   OBJ       -1
    x[1825]   c1        1
    x[1825]   c368      1
    x[1825]   OBJ       -1
    x[1826]   c2        1
    x[1826]   c651      1
    x[1826]   OBJ       -1
    x[1827]   c3        1
    x[1827]   c934      1
    x[1827]   OBJ       -1
    x[1828]   c4        1
    x[1828]   c1217     1
    x[1828]   OBJ       -1
    x[1829]   c5        1
    x[1829]   c1500     1
    x[1829]   OBJ       -1
    x[1830]   c6        1
    x[1830]   c1783     1
    x[1830]   OBJ       -1
    x[1831]   c7        1
    x[1831]   c2066     1
    x[1831]   OBJ       -1
    x[1832]   c8        1
    x[1832]   c2349     1
    x[1832]   OBJ       -1
    x[1833]   c9        1
    x[1833]   c2632     1
    x[1833]   OBJ       -1
    x[1834]   c10       1
    x[1834]   c2915     1
    x[1834]   OBJ       -1
    x[1835]   c11       1
    x[1835]   c3198     1
    x[1835]   OBJ       -1
    x[1836]   c12       1
    x[1836]   c3481     1
    x[1836]   OBJ       -1
    x[1837]   c13       1
    x[1837]   c3764     1
    x[1837]   OBJ       -1
    x[1838]   c14       1
    x[1838]   c4047     1
    x[1838]   OBJ       -1
    x[1839]   c15       1
    x[1839]   c4330     1
    x[1839]   OBJ       -1
    x[1840]   c16       1
    x[1840]   c4613     1
    x[1840]   OBJ       -1
    x[1841]   c1        1
    x[1841]   c369      1
    x[1841]   c370      1
    x[1841]   c371      1
    x[1841]   OBJ       -1
    x[1842]   c2        1
    x[1842]   c652      1
    x[1842]   c653      1
    x[1842]   c654      1
    x[1842]   OBJ       -1
    x[1843]   c3        1
    x[1843]   c935      1
    x[1843]   c936      1
    x[1843]   c937      1
    x[1843]   OBJ       -1
    x[1844]   c4        1
    x[1844]   c1218     1
    x[1844]   c1219     1
    x[1844]   c1220     1
    x[1844]   OBJ       -1
    x[1845]   c5        1
    x[1845]   c1501     1
    x[1845]   c1502     1
    x[1845]   c1503     1
    x[1845]   OBJ       -1
    x[1846]   c6        1
    x[1846]   c1784     1
    x[1846]   c1785     1
    x[1846]   c1786     1
    x[1846]   OBJ       -1
    x[1847]   c7        1
    x[1847]   c2067     1
    x[1847]   c2068     1
    x[1847]   c2069     1
    x[1847]   OBJ       -1
    x[1848]   c8        1
    x[1848]   c2350     1
    x[1848]   c2351     1
    x[1848]   c2352     1
    x[1848]   OBJ       -1
    x[1849]   c9        1
    x[1849]   c2633     1
    x[1849]   c2634     1
    x[1849]   c2635     1
    x[1849]   OBJ       -1
    x[1850]   c10       1
    x[1850]   c2916     1
    x[1850]   c2917     1
    x[1850]   c2918     1
    x[1850]   OBJ       -1
    x[1851]   c11       1
    x[1851]   c3199     1
    x[1851]   c3200     1
    x[1851]   c3201     1
    x[1851]   OBJ       -1
    x[1852]   c12       1
    x[1852]   c3482     1
    x[1852]   c3483     1
    x[1852]   c3484     1
    x[1852]   OBJ       -1
    x[1853]   c13       1
    x[1853]   c3765     1
    x[1853]   c3766     1
    x[1853]   c3767     1
    x[1853]   OBJ       -1
    x[1854]   c14       1
    x[1854]   c4048     1
    x[1854]   c4049     1
    x[1854]   c4050     1
    x[1854]   OBJ       -1
    x[1855]   c15       1
    x[1855]   c4331     1
    x[1855]   c4332     1
    x[1855]   c4333     1
    x[1855]   OBJ       -1
    x[1856]   c16       1
    x[1856]   c4614     1
    x[1856]   c4615     1
    x[1856]   c4616     1
    x[1856]   OBJ       -1
    x[1857]   c1        1
    x[1857]   c372      1
    x[1857]   OBJ       -1
    x[1858]   c2        1
    x[1858]   c655      1
    x[1858]   OBJ       -1
    x[1859]   c3        1
    x[1859]   c938      1
    x[1859]   OBJ       -1
    x[1860]   c4        1
    x[1860]   c1221     1
    x[1860]   OBJ       -1
    x[1861]   c5        1
    x[1861]   c1504     1
    x[1861]   OBJ       -1
    x[1862]   c6        1
    x[1862]   c1787     1
    x[1862]   OBJ       -1
    x[1863]   c7        1
    x[1863]   c2070     1
    x[1863]   OBJ       -1
    x[1864]   c8        1
    x[1864]   c2353     1
    x[1864]   OBJ       -1
    x[1865]   c9        1
    x[1865]   c2636     1
    x[1865]   OBJ       -1
    x[1866]   c10       1
    x[1866]   c2919     1
    x[1866]   OBJ       -1
    x[1867]   c11       1
    x[1867]   c3202     1
    x[1867]   OBJ       -1
    x[1868]   c12       1
    x[1868]   c3485     1
    x[1868]   OBJ       -1
    x[1869]   c13       1
    x[1869]   c3768     1
    x[1869]   OBJ       -1
    x[1870]   c14       1
    x[1870]   c4051     1
    x[1870]   OBJ       -1
    x[1871]   c15       1
    x[1871]   c4334     1
    x[1871]   OBJ       -1
    x[1872]   c16       1
    x[1872]   c4617     1
    x[1872]   OBJ       -1
    x[1873]   c1        1
    x[1873]   c373      1
    x[1873]   c374      1
    x[1873]   OBJ       -1
    x[1874]   c2        1
    x[1874]   c656      1
    x[1874]   c657      1
    x[1874]   OBJ       -1
    x[1875]   c3        1
    x[1875]   c939      1
    x[1875]   c940      1
    x[1875]   OBJ       -1
    x[1876]   c4        1
    x[1876]   c1222     1
    x[1876]   c1223     1
    x[1876]   OBJ       -1
    x[1877]   c5        1
    x[1877]   c1505     1
    x[1877]   c1506     1
    x[1877]   OBJ       -1
    x[1878]   c6        1
    x[1878]   c1788     1
    x[1878]   c1789     1
    x[1878]   OBJ       -1
    x[1879]   c7        1
    x[1879]   c2071     1
    x[1879]   c2072     1
    x[1879]   OBJ       -1
    x[1880]   c8        1
    x[1880]   c2354     1
    x[1880]   c2355     1
    x[1880]   OBJ       -1
    x[1881]   c9        1
    x[1881]   c2637     1
    x[1881]   c2638     1
    x[1881]   OBJ       -1
    x[1882]   c10       1
    x[1882]   c2920     1
    x[1882]   c2921     1
    x[1882]   OBJ       -1
    x[1883]   c11       1
    x[1883]   c3203     1
    x[1883]   c3204     1
    x[1883]   OBJ       -1
    x[1884]   c12       1
    x[1884]   c3486     1
    x[1884]   c3487     1
    x[1884]   OBJ       -1
    x[1885]   c13       1
    x[1885]   c3769     1
    x[1885]   c3770     1
    x[1885]   OBJ       -1
    x[1886]   c14       1
    x[1886]   c4052     1
    x[1886]   c4053     1
    x[1886]   OBJ       -1
    x[1887]   c15       1
    x[1887]   c4335     1
    x[1887]   c4336     1
    x[1887]   OBJ       -1
    x[1888]   c16       1
    x[1888]   c4618     1
    x[1888]   c4619     1
    x[1888]   OBJ       -1
    x[1889]   c1        1
    x[1889]   c375      1
    x[1889]   OBJ       -1
    x[1890]   c2        1
    x[1890]   c658      1
    x[1890]   OBJ       -1
    x[1891]   c3        1
    x[1891]   c941      1
    x[1891]   OBJ       -1
    x[1892]   c4        1
    x[1892]   c1224     1
    x[1892]   OBJ       -1
    x[1893]   c5        1
    x[1893]   c1507     1
    x[1893]   OBJ       -1
    x[1894]   c6        1
    x[1894]   c1790     1
    x[1894]   OBJ       -1
    x[1895]   c7        1
    x[1895]   c2073     1
    x[1895]   OBJ       -1
    x[1896]   c8        1
    x[1896]   c2356     1
    x[1896]   OBJ       -1
    x[1897]   c9        1
    x[1897]   c2639     1
    x[1897]   OBJ       -1
    x[1898]   c10       1
    x[1898]   c2922     1
    x[1898]   OBJ       -1
    x[1899]   c11       1
    x[1899]   c3205     1
    x[1899]   OBJ       -1
    x[1900]   c12       1
    x[1900]   c3488     1
    x[1900]   OBJ       -1
    x[1901]   c13       1
    x[1901]   c3771     1
    x[1901]   OBJ       -1
    x[1902]   c14       1
    x[1902]   c4054     1
    x[1902]   OBJ       -1
    x[1903]   c15       1
    x[1903]   c4337     1
    x[1903]   OBJ       -1
    x[1904]   c16       1
    x[1904]   c4620     1
    x[1904]   OBJ       -1
    x[1905]   c1        1
    x[1905]   c376      1
    x[1905]   OBJ       -1
    x[1906]   c2        1
    x[1906]   c659      1
    x[1906]   OBJ       -1
    x[1907]   c3        1
    x[1907]   c942      1
    x[1907]   OBJ       -1
    x[1908]   c4        1
    x[1908]   c1225     1
    x[1908]   OBJ       -1
    x[1909]   c5        1
    x[1909]   c1508     1
    x[1909]   OBJ       -1
    x[1910]   c6        1
    x[1910]   c1791     1
    x[1910]   OBJ       -1
    x[1911]   c7        1
    x[1911]   c2074     1
    x[1911]   OBJ       -1
    x[1912]   c8        1
    x[1912]   c2357     1
    x[1912]   OBJ       -1
    x[1913]   c9        1
    x[1913]   c2640     1
    x[1913]   OBJ       -1
    x[1914]   c10       1
    x[1914]   c2923     1
    x[1914]   OBJ       -1
    x[1915]   c11       1
    x[1915]   c3206     1
    x[1915]   OBJ       -1
    x[1916]   c12       1
    x[1916]   c3489     1
    x[1916]   OBJ       -1
    x[1917]   c13       1
    x[1917]   c3772     1
    x[1917]   OBJ       -1
    x[1918]   c14       1
    x[1918]   c4055     1
    x[1918]   OBJ       -1
    x[1919]   c15       1
    x[1919]   c4338     1
    x[1919]   OBJ       -1
    x[1920]   c16       1
    x[1920]   c4621     1
    x[1920]   OBJ       -1
    x[1921]   c1        1
    x[1921]   c377      1
    x[1921]   c378      1
    x[1921]   OBJ       -1
    x[1922]   c2        1
    x[1922]   c660      1
    x[1922]   c661      1
    x[1922]   OBJ       -1
    x[1923]   c3        1
    x[1923]   c943      1
    x[1923]   c944      1
    x[1923]   OBJ       -1
    x[1924]   c4        1
    x[1924]   c1226     1
    x[1924]   c1227     1
    x[1924]   OBJ       -1
    x[1925]   c5        1
    x[1925]   c1509     1
    x[1925]   c1510     1
    x[1925]   OBJ       -1
    x[1926]   c6        1
    x[1926]   c1792     1
    x[1926]   c1793     1
    x[1926]   OBJ       -1
    x[1927]   c7        1
    x[1927]   c2075     1
    x[1927]   c2076     1
    x[1927]   OBJ       -1
    x[1928]   c8        1
    x[1928]   c2358     1
    x[1928]   c2359     1
    x[1928]   OBJ       -1
    x[1929]   c9        1
    x[1929]   c2641     1
    x[1929]   c2642     1
    x[1929]   OBJ       -1
    x[1930]   c10       1
    x[1930]   c2924     1
    x[1930]   c2925     1
    x[1930]   OBJ       -1
    x[1931]   c11       1
    x[1931]   c3207     1
    x[1931]   c3208     1
    x[1931]   OBJ       -1
    x[1932]   c12       1
    x[1932]   c3490     1
    x[1932]   c3491     1
    x[1932]   OBJ       -1
    x[1933]   c13       1
    x[1933]   c3773     1
    x[1933]   c3774     1
    x[1933]   OBJ       -1
    x[1934]   c14       1
    x[1934]   c4056     1
    x[1934]   c4057     1
    x[1934]   OBJ       -1
    x[1935]   c15       1
    x[1935]   c4339     1
    x[1935]   c4340     1
    x[1935]   OBJ       -1
    x[1936]   c16       1
    x[1936]   c4622     1
    x[1936]   c4623     1
    x[1936]   OBJ       -1
    x[1937]   c1        1
    x[1937]   c379      1
    x[1937]   c380      1
    x[1937]   OBJ       -1
    x[1938]   c2        1
    x[1938]   c662      1
    x[1938]   c663      1
    x[1938]   OBJ       -1
    x[1939]   c3        1
    x[1939]   c945      1
    x[1939]   c946      1
    x[1939]   OBJ       -1
    x[1940]   c4        1
    x[1940]   c1228     1
    x[1940]   c1229     1
    x[1940]   OBJ       -1
    x[1941]   c5        1
    x[1941]   c1511     1
    x[1941]   c1512     1
    x[1941]   OBJ       -1
    x[1942]   c6        1
    x[1942]   c1794     1
    x[1942]   c1795     1
    x[1942]   OBJ       -1
    x[1943]   c7        1
    x[1943]   c2077     1
    x[1943]   c2078     1
    x[1943]   OBJ       -1
    x[1944]   c8        1
    x[1944]   c2360     1
    x[1944]   c2361     1
    x[1944]   OBJ       -1
    x[1945]   c9        1
    x[1945]   c2643     1
    x[1945]   c2644     1
    x[1945]   OBJ       -1
    x[1946]   c10       1
    x[1946]   c2926     1
    x[1946]   c2927     1
    x[1946]   OBJ       -1
    x[1947]   c11       1
    x[1947]   c3209     1
    x[1947]   c3210     1
    x[1947]   OBJ       -1
    x[1948]   c12       1
    x[1948]   c3492     1
    x[1948]   c3493     1
    x[1948]   OBJ       -1
    x[1949]   c13       1
    x[1949]   c3775     1
    x[1949]   c3776     1
    x[1949]   OBJ       -1
    x[1950]   c14       1
    x[1950]   c4058     1
    x[1950]   c4059     1
    x[1950]   OBJ       -1
    x[1951]   c15       1
    x[1951]   c4341     1
    x[1951]   c4342     1
    x[1951]   OBJ       -1
    x[1952]   c16       1
    x[1952]   c4624     1
    x[1952]   c4625     1
    x[1952]   OBJ       -1
    x[1953]   c1        1
    x[1953]   c381      1
    x[1953]   c382      1
    x[1953]   OBJ       -1
    x[1954]   c2        1
    x[1954]   c664      1
    x[1954]   c665      1
    x[1954]   OBJ       -1
    x[1955]   c3        1
    x[1955]   c947      1
    x[1955]   c948      1
    x[1955]   OBJ       -1
    x[1956]   c4        1
    x[1956]   c1230     1
    x[1956]   c1231     1
    x[1956]   OBJ       -1
    x[1957]   c5        1
    x[1957]   c1513     1
    x[1957]   c1514     1
    x[1957]   OBJ       -1
    x[1958]   c6        1
    x[1958]   c1796     1
    x[1958]   c1797     1
    x[1958]   OBJ       -1
    x[1959]   c7        1
    x[1959]   c2079     1
    x[1959]   c2080     1
    x[1959]   OBJ       -1
    x[1960]   c8        1
    x[1960]   c2362     1
    x[1960]   c2363     1
    x[1960]   OBJ       -1
    x[1961]   c9        1
    x[1961]   c2645     1
    x[1961]   c2646     1
    x[1961]   OBJ       -1
    x[1962]   c10       1
    x[1962]   c2928     1
    x[1962]   c2929     1
    x[1962]   OBJ       -1
    x[1963]   c11       1
    x[1963]   c3211     1
    x[1963]   c3212     1
    x[1963]   OBJ       -1
    x[1964]   c12       1
    x[1964]   c3494     1
    x[1964]   c3495     1
    x[1964]   OBJ       -1
    x[1965]   c13       1
    x[1965]   c3777     1
    x[1965]   c3778     1
    x[1965]   OBJ       -1
    x[1966]   c14       1
    x[1966]   c4060     1
    x[1966]   c4061     1
    x[1966]   OBJ       -1
    x[1967]   c15       1
    x[1967]   c4343     1
    x[1967]   c4344     1
    x[1967]   OBJ       -1
    x[1968]   c16       1
    x[1968]   c4626     1
    x[1968]   c4627     1
    x[1968]   OBJ       -1
    x[1969]   c1        1
    x[1969]   c383      1
    x[1969]   OBJ       -1
    x[1970]   c2        1
    x[1970]   c666      1
    x[1970]   OBJ       -1
    x[1971]   c3        1
    x[1971]   c949      1
    x[1971]   OBJ       -1
    x[1972]   c4        1
    x[1972]   c1232     1
    x[1972]   OBJ       -1
    x[1973]   c5        1
    x[1973]   c1515     1
    x[1973]   OBJ       -1
    x[1974]   c6        1
    x[1974]   c1798     1
    x[1974]   OBJ       -1
    x[1975]   c7        1
    x[1975]   c2081     1
    x[1975]   OBJ       -1
    x[1976]   c8        1
    x[1976]   c2364     1
    x[1976]   OBJ       -1
    x[1977]   c9        1
    x[1977]   c2647     1
    x[1977]   OBJ       -1
    x[1978]   c10       1
    x[1978]   c2930     1
    x[1978]   OBJ       -1
    x[1979]   c11       1
    x[1979]   c3213     1
    x[1979]   OBJ       -1
    x[1980]   c12       1
    x[1980]   c3496     1
    x[1980]   OBJ       -1
    x[1981]   c13       1
    x[1981]   c3779     1
    x[1981]   OBJ       -1
    x[1982]   c14       1
    x[1982]   c4062     1
    x[1982]   OBJ       -1
    x[1983]   c15       1
    x[1983]   c4345     1
    x[1983]   OBJ       -1
    x[1984]   c16       1
    x[1984]   c4628     1
    x[1984]   OBJ       -1
    x[1985]   c1        1
    x[1985]   c384      1
    x[1985]   OBJ       -1
    x[1986]   c2        1
    x[1986]   c667      1
    x[1986]   OBJ       -1
    x[1987]   c3        1
    x[1987]   c950      1
    x[1987]   OBJ       -1
    x[1988]   c4        1
    x[1988]   c1233     1
    x[1988]   OBJ       -1
    x[1989]   c5        1
    x[1989]   c1516     1
    x[1989]   OBJ       -1
    x[1990]   c6        1
    x[1990]   c1799     1
    x[1990]   OBJ       -1
    x[1991]   c7        1
    x[1991]   c2082     1
    x[1991]   OBJ       -1
    x[1992]   c8        1
    x[1992]   c2365     1
    x[1992]   OBJ       -1
    x[1993]   c9        1
    x[1993]   c2648     1
    x[1993]   OBJ       -1
    x[1994]   c10       1
    x[1994]   c2931     1
    x[1994]   OBJ       -1
    x[1995]   c11       1
    x[1995]   c3214     1
    x[1995]   OBJ       -1
    x[1996]   c12       1
    x[1996]   c3497     1
    x[1996]   OBJ       -1
    x[1997]   c13       1
    x[1997]   c3780     1
    x[1997]   OBJ       -1
    x[1998]   c14       1
    x[1998]   c4063     1
    x[1998]   OBJ       -1
    x[1999]   c15       1
    x[1999]   c4346     1
    x[1999]   OBJ       -1
    x[2000]   c16       1
    x[2000]   c4629     1
    x[2000]   OBJ       -1
    x[2001]   c1        1
    x[2001]   c385      1
    x[2001]   c386      1
    x[2001]   OBJ       -1
    x[2002]   c2        1
    x[2002]   c668      1
    x[2002]   c669      1
    x[2002]   OBJ       -1
    x[2003]   c3        1
    x[2003]   c951      1
    x[2003]   c952      1
    x[2003]   OBJ       -1
    x[2004]   c4        1
    x[2004]   c1234     1
    x[2004]   c1235     1
    x[2004]   OBJ       -1
    x[2005]   c5        1
    x[2005]   c1517     1
    x[2005]   c1518     1
    x[2005]   OBJ       -1
    x[2006]   c6        1
    x[2006]   c1800     1
    x[2006]   c1801     1
    x[2006]   OBJ       -1
    x[2007]   c7        1
    x[2007]   c2083     1
    x[2007]   c2084     1
    x[2007]   OBJ       -1
    x[2008]   c8        1
    x[2008]   c2366     1
    x[2008]   c2367     1
    x[2008]   OBJ       -1
    x[2009]   c9        1
    x[2009]   c2649     1
    x[2009]   c2650     1
    x[2009]   OBJ       -1
    x[2010]   c10       1
    x[2010]   c2932     1
    x[2010]   c2933     1
    x[2010]   OBJ       -1
    x[2011]   c11       1
    x[2011]   c3215     1
    x[2011]   c3216     1
    x[2011]   OBJ       -1
    x[2012]   c12       1
    x[2012]   c3498     1
    x[2012]   c3499     1
    x[2012]   OBJ       -1
    x[2013]   c13       1
    x[2013]   c3781     1
    x[2013]   c3782     1
    x[2013]   OBJ       -1
    x[2014]   c14       1
    x[2014]   c4064     1
    x[2014]   c4065     1
    x[2014]   OBJ       -1
    x[2015]   c15       1
    x[2015]   c4347     1
    x[2015]   c4348     1
    x[2015]   OBJ       -1
    x[2016]   c16       1
    x[2016]   c4630     1
    x[2016]   c4631     1
    x[2016]   OBJ       -1
    x[2017]   c1        1
    x[2017]   c387      1
    x[2017]   OBJ       -1
    x[2018]   c2        1
    x[2018]   c670      1
    x[2018]   OBJ       -1
    x[2019]   c3        1
    x[2019]   c953      1
    x[2019]   OBJ       -1
    x[2020]   c4        1
    x[2020]   c1236     1
    x[2020]   OBJ       -1
    x[2021]   c5        1
    x[2021]   c1519     1
    x[2021]   OBJ       -1
    x[2022]   c6        1
    x[2022]   c1802     1
    x[2022]   OBJ       -1
    x[2023]   c7        1
    x[2023]   c2085     1
    x[2023]   OBJ       -1
    x[2024]   c8        1
    x[2024]   c2368     1
    x[2024]   OBJ       -1
    x[2025]   c9        1
    x[2025]   c2651     1
    x[2025]   OBJ       -1
    x[2026]   c10       1
    x[2026]   c2934     1
    x[2026]   OBJ       -1
    x[2027]   c11       1
    x[2027]   c3217     1
    x[2027]   OBJ       -1
    x[2028]   c12       1
    x[2028]   c3500     1
    x[2028]   OBJ       -1
    x[2029]   c13       1
    x[2029]   c3783     1
    x[2029]   OBJ       -1
    x[2030]   c14       1
    x[2030]   c4066     1
    x[2030]   OBJ       -1
    x[2031]   c15       1
    x[2031]   c4349     1
    x[2031]   OBJ       -1
    x[2032]   c16       1
    x[2032]   c4632     1
    x[2032]   OBJ       -1
    x[2033]   c1        1
    x[2033]   c388      1
    x[2033]   OBJ       -1
    x[2034]   c2        1
    x[2034]   c671      1
    x[2034]   OBJ       -1
    x[2035]   c3        1
    x[2035]   c954      1
    x[2035]   OBJ       -1
    x[2036]   c4        1
    x[2036]   c1237     1
    x[2036]   OBJ       -1
    x[2037]   c5        1
    x[2037]   c1520     1
    x[2037]   OBJ       -1
    x[2038]   c6        1
    x[2038]   c1803     1
    x[2038]   OBJ       -1
    x[2039]   c7        1
    x[2039]   c2086     1
    x[2039]   OBJ       -1
    x[2040]   c8        1
    x[2040]   c2369     1
    x[2040]   OBJ       -1
    x[2041]   c9        1
    x[2041]   c2652     1
    x[2041]   OBJ       -1
    x[2042]   c10       1
    x[2042]   c2935     1
    x[2042]   OBJ       -1
    x[2043]   c11       1
    x[2043]   c3218     1
    x[2043]   OBJ       -1
    x[2044]   c12       1
    x[2044]   c3501     1
    x[2044]   OBJ       -1
    x[2045]   c13       1
    x[2045]   c3784     1
    x[2045]   OBJ       -1
    x[2046]   c14       1
    x[2046]   c4067     1
    x[2046]   OBJ       -1
    x[2047]   c15       1
    x[2047]   c4350     1
    x[2047]   OBJ       -1
    x[2048]   c16       1
    x[2048]   c4633     1
    x[2048]   OBJ       -1
    x[2049]   c17       1
    x[2049]   c137      -1
    x[2049]   c150      -1
    x[2049]   c183      -1
    x[2049]   c373      -1
    x[2050]   c17       1
    x[2050]   c420      -1
    x[2050]   c433      -1
    x[2050]   c466      -1
    x[2050]   c656      -1
    x[2051]   c17       1
    x[2051]   c703      -1
    x[2051]   c716      -1
    x[2051]   c749      -1
    x[2051]   c939      -1
    x[2052]   c17       1
    x[2052]   c986      -1
    x[2052]   c999      -1
    x[2052]   c1032     -1
    x[2052]   c1222     -1
    x[2053]   c17       1
    x[2053]   c1269     -1
    x[2053]   c1282     -1
    x[2053]   c1315     -1
    x[2053]   c1505     -1
    x[2054]   c17       1
    x[2054]   c1552     -1
    x[2054]   c1565     -1
    x[2054]   c1598     -1
    x[2054]   c1788     -1
    x[2055]   c17       1
    x[2055]   c1835     -1
    x[2055]   c1848     -1
    x[2055]   c1881     -1
    x[2055]   c2071     -1
    x[2056]   c17       1
    x[2056]   c2118     -1
    x[2056]   c2131     -1
    x[2056]   c2164     -1
    x[2056]   c2354     -1
    x[2057]   c17       1
    x[2057]   c2401     -1
    x[2057]   c2414     -1
    x[2057]   c2447     -1
    x[2057]   c2637     -1
    x[2058]   c17       1
    x[2058]   c2684     -1
    x[2058]   c2697     -1
    x[2058]   c2730     -1
    x[2058]   c2920     -1
    x[2059]   c17       1
    x[2059]   c2967     -1
    x[2059]   c2980     -1
    x[2059]   c3013     -1
    x[2059]   c3203     -1
    x[2060]   c17       1
    x[2060]   c3250     -1
    x[2060]   c3263     -1
    x[2060]   c3296     -1
    x[2060]   c3486     -1
    x[2061]   c17       1
    x[2061]   c3533     -1
    x[2061]   c3546     -1
    x[2061]   c3579     -1
    x[2061]   c3769     -1
    x[2062]   c17       1
    x[2062]   c3816     -1
    x[2062]   c3829     -1
    x[2062]   c3862     -1
    x[2062]   c4052     -1
    x[2063]   c17       1
    x[2063]   c4099     -1
    x[2063]   c4112     -1
    x[2063]   c4145     -1
    x[2063]   c4335     -1
    x[2064]   c17       1
    x[2064]   c4382     -1
    x[2064]   c4395     -1
    x[2064]   c4428     -1
    x[2064]   c4618     -1
    x[2065]   c18       1
    x[2065]   c270      -1
    x[2065]   c280      -1
    x[2066]   c18       1
    x[2066]   c553      -1
    x[2066]   c563      -1
    x[2067]   c18       1
    x[2067]   c836      -1
    x[2067]   c846      -1
    x[2068]   c18       1
    x[2068]   c1119     -1
    x[2068]   c1129     -1
    x[2069]   c18       1
    x[2069]   c1402     -1
    x[2069]   c1412     -1
    x[2070]   c18       1
    x[2070]   c1685     -1
    x[2070]   c1695     -1
    x[2071]   c18       1
    x[2071]   c1968     -1
    x[2071]   c1978     -1
    x[2072]   c18       1
    x[2072]   c2251     -1
    x[2072]   c2261     -1
    x[2073]   c18       1
    x[2073]   c2534     -1
    x[2073]   c2544     -1
    x[2074]   c18       1
    x[2074]   c2817     -1
    x[2074]   c2827     -1
    x[2075]   c18       1
    x[2075]   c3100     -1
    x[2075]   c3110     -1
    x[2076]   c18       1
    x[2076]   c3383     -1
    x[2076]   c3393     -1
    x[2077]   c18       1
    x[2077]   c3666     -1
    x[2077]   c3676     -1
    x[2078]   c18       1
    x[2078]   c3949     -1
    x[2078]   c3959     -1
    x[2079]   c18       1
    x[2079]   c4232     -1
    x[2079]   c4242     -1
    x[2080]   c18       1
    x[2080]   c4515     -1
    x[2080]   c4525     -1
    x[2081]   c19       1
    x[2081]   c139      -1
    x[2081]   c151      -1
    x[2081]   c328      -1
    x[2082]   c19       1
    x[2082]   c422      -1
    x[2082]   c434      -1
    x[2082]   c611      -1
    x[2083]   c19       1
    x[2083]   c705      -1
    x[2083]   c717      -1
    x[2083]   c894      -1
    x[2084]   c19       1
    x[2084]   c988      -1
    x[2084]   c1000     -1
    x[2084]   c1177     -1
    x[2085]   c19       1
    x[2085]   c1271     -1
    x[2085]   c1283     -1
    x[2085]   c1460     -1
    x[2086]   c19       1
    x[2086]   c1554     -1
    x[2086]   c1566     -1
    x[2086]   c1743     -1
    x[2087]   c19       1
    x[2087]   c1837     -1
    x[2087]   c1849     -1
    x[2087]   c2026     -1
    x[2088]   c19       1
    x[2088]   c2120     -1
    x[2088]   c2132     -1
    x[2088]   c2309     -1
    x[2089]   c19       1
    x[2089]   c2403     -1
    x[2089]   c2415     -1
    x[2089]   c2592     -1
    x[2090]   c19       1
    x[2090]   c2686     -1
    x[2090]   c2698     -1
    x[2090]   c2875     -1
    x[2091]   c19       1
    x[2091]   c2969     -1
    x[2091]   c2981     -1
    x[2091]   c3158     -1
    x[2092]   c19       1
    x[2092]   c3252     -1
    x[2092]   c3264     -1
    x[2092]   c3441     -1
    x[2093]   c19       1
    x[2093]   c3535     -1
    x[2093]   c3547     -1
    x[2093]   c3724     -1
    x[2094]   c19       1
    x[2094]   c3818     -1
    x[2094]   c3830     -1
    x[2094]   c4007     -1
    x[2095]   c19       1
    x[2095]   c4101     -1
    x[2095]   c4113     -1
    x[2095]   c4290     -1
    x[2096]   c19       1
    x[2096]   c4384     -1
    x[2096]   c4396     -1
    x[2096]   c4573     -1
    x[2097]   c20       1
    x[2097]   c205      -1
    x[2097]   c306      -1
    x[2097]   c347      -1
    x[2098]   c20       1
    x[2098]   c488      -1
    x[2098]   c589      -1
    x[2098]   c630      -1
    x[2099]   c20       1
    x[2099]   c771      -1
    x[2099]   c872      -1
    x[2099]   c913      -1
    x[2100]   c20       1
    x[2100]   c1054     -1
    x[2100]   c1155     -1
    x[2100]   c1196     -1
    x[2101]   c20       1
    x[2101]   c1337     -1
    x[2101]   c1438     -1
    x[2101]   c1479     -1
    x[2102]   c20       1
    x[2102]   c1620     -1
    x[2102]   c1721     -1
    x[2102]   c1762     -1
    x[2103]   c20       1
    x[2103]   c1903     -1
    x[2103]   c2004     -1
    x[2103]   c2045     -1
    x[2104]   c20       1
    x[2104]   c2186     -1
    x[2104]   c2287     -1
    x[2104]   c2328     -1
    x[2105]   c20       1
    x[2105]   c2469     -1
    x[2105]   c2570     -1
    x[2105]   c2611     -1
    x[2106]   c20       1
    x[2106]   c2752     -1
    x[2106]   c2853     -1
    x[2106]   c2894     -1
    x[2107]   c20       1
    x[2107]   c3035     -1
    x[2107]   c3136     -1
    x[2107]   c3177     -1
    x[2108]   c20       1
    x[2108]   c3318     -1
    x[2108]   c3419     -1
    x[2108]   c3460     -1
    x[2109]   c20       1
    x[2109]   c3601     -1
    x[2109]   c3702     -1
    x[2109]   c3743     -1
    x[2110]   c20       1
    x[2110]   c3884     -1
    x[2110]   c3985     -1
    x[2110]   c4026     -1
    x[2111]   c20       1
    x[2111]   c4167     -1
    x[2111]   c4268     -1
    x[2111]   c4309     -1
    x[2112]   c20       1
    x[2112]   c4450     -1
    x[2112]   c4551     -1
    x[2112]   c4592     -1
    x[2113]   c21       1
    x[2113]   c140      -1
    x[2113]   c345      -1
    x[2114]   c21       1
    x[2114]   c423      -1
    x[2114]   c628      -1
    x[2115]   c21       1
    x[2115]   c706      -1
    x[2115]   c911      -1
    x[2116]   c21       1
    x[2116]   c989      -1
    x[2116]   c1194     -1
    x[2117]   c21       1
    x[2117]   c1272     -1
    x[2117]   c1477     -1
    x[2118]   c21       1
    x[2118]   c1555     -1
    x[2118]   c1760     -1
    x[2119]   c21       1
    x[2119]   c1838     -1
    x[2119]   c2043     -1
    x[2120]   c21       1
    x[2120]   c2121     -1
    x[2120]   c2326     -1
    x[2121]   c21       1
    x[2121]   c2404     -1
    x[2121]   c2609     -1
    x[2122]   c21       1
    x[2122]   c2687     -1
    x[2122]   c2892     -1
    x[2123]   c21       1
    x[2123]   c2970     -1
    x[2123]   c3175     -1
    x[2124]   c21       1
    x[2124]   c3253     -1
    x[2124]   c3458     -1
    x[2125]   c21       1
    x[2125]   c3536     -1
    x[2125]   c3741     -1
    x[2126]   c21       1
    x[2126]   c3819     -1
    x[2126]   c4024     -1
    x[2127]   c21       1
    x[2127]   c4102     -1
    x[2127]   c4307     -1
    x[2128]   c21       1
    x[2128]   c4385     -1
    x[2128]   c4590     -1
    x[2129]   c22       1
    x[2129]   c226      -1
    x[2129]   c244      -1
    x[2129]   c249      -1
    x[2129]   c295      -1
    x[2130]   c22       1
    x[2130]   c509      -1
    x[2130]   c527      -1
    x[2130]   c532      -1
    x[2130]   c578      -1
    x[2131]   c22       1
    x[2131]   c792      -1
    x[2131]   c810      -1
    x[2131]   c815      -1
    x[2131]   c861      -1
    x[2132]   c22       1
    x[2132]   c1075     -1
    x[2132]   c1093     -1
    x[2132]   c1098     -1
    x[2132]   c1144     -1
    x[2133]   c22       1
    x[2133]   c1358     -1
    x[2133]   c1376     -1
    x[2133]   c1381     -1
    x[2133]   c1427     -1
    x[2134]   c22       1
    x[2134]   c1641     -1
    x[2134]   c1659     -1
    x[2134]   c1664     -1
    x[2134]   c1710     -1
    x[2135]   c22       1
    x[2135]   c1924     -1
    x[2135]   c1942     -1
    x[2135]   c1947     -1
    x[2135]   c1993     -1
    x[2136]   c22       1
    x[2136]   c2207     -1
    x[2136]   c2225     -1
    x[2136]   c2230     -1
    x[2136]   c2276     -1
    x[2137]   c22       1
    x[2137]   c2490     -1
    x[2137]   c2508     -1
    x[2137]   c2513     -1
    x[2137]   c2559     -1
    x[2138]   c22       1
    x[2138]   c2773     -1
    x[2138]   c2791     -1
    x[2138]   c2796     -1
    x[2138]   c2842     -1
    x[2139]   c22       1
    x[2139]   c3056     -1
    x[2139]   c3074     -1
    x[2139]   c3079     -1
    x[2139]   c3125     -1
    x[2140]   c22       1
    x[2140]   c3339     -1
    x[2140]   c3357     -1
    x[2140]   c3362     -1
    x[2140]   c3408     -1
    x[2141]   c22       1
    x[2141]   c3622     -1
    x[2141]   c3640     -1
    x[2141]   c3645     -1
    x[2141]   c3691     -1
    x[2142]   c22       1
    x[2142]   c3905     -1
    x[2142]   c3923     -1
    x[2142]   c3928     -1
    x[2142]   c3974     -1
    x[2143]   c22       1
    x[2143]   c4188     -1
    x[2143]   c4206     -1
    x[2143]   c4211     -1
    x[2143]   c4257     -1
    x[2144]   c22       1
    x[2144]   c4471     -1
    x[2144]   c4489     -1
    x[2144]   c4494     -1
    x[2144]   c4540     -1
    x[2145]   c23       1
    x[2145]   c206      -1
    x[2145]   c245      -1
    x[2145]   c317      -1
    x[2146]   c23       1
    x[2146]   c489      -1
    x[2146]   c528      -1
    x[2146]   c600      -1
    x[2147]   c23       1
    x[2147]   c772      -1
    x[2147]   c811      -1
    x[2147]   c883      -1
    x[2148]   c23       1
    x[2148]   c1055     -1
    x[2148]   c1094     -1
    x[2148]   c1166     -1
    x[2149]   c23       1
    x[2149]   c1338     -1
    x[2149]   c1377     -1
    x[2149]   c1449     -1
    x[2150]   c23       1
    x[2150]   c1621     -1
    x[2150]   c1660     -1
    x[2150]   c1732     -1
    x[2151]   c23       1
    x[2151]   c1904     -1
    x[2151]   c1943     -1
    x[2151]   c2015     -1
    x[2152]   c23       1
    x[2152]   c2187     -1
    x[2152]   c2226     -1
    x[2152]   c2298     -1
    x[2153]   c23       1
    x[2153]   c2470     -1
    x[2153]   c2509     -1
    x[2153]   c2581     -1
    x[2154]   c23       1
    x[2154]   c2753     -1
    x[2154]   c2792     -1
    x[2154]   c2864     -1
    x[2155]   c23       1
    x[2155]   c3036     -1
    x[2155]   c3075     -1
    x[2155]   c3147     -1
    x[2156]   c23       1
    x[2156]   c3319     -1
    x[2156]   c3358     -1
    x[2156]   c3430     -1
    x[2157]   c23       1
    x[2157]   c3602     -1
    x[2157]   c3641     -1
    x[2157]   c3713     -1
    x[2158]   c23       1
    x[2158]   c3885     -1
    x[2158]   c3924     -1
    x[2158]   c3996     -1
    x[2159]   c23       1
    x[2159]   c4168     -1
    x[2159]   c4207     -1
    x[2159]   c4279     -1
    x[2160]   c23       1
    x[2160]   c4451     -1
    x[2160]   c4490     -1
    x[2160]   c4562     -1
    x[2161]   c24       1
    x[2161]   c161      -1
    x[2161]   c281      -1
    x[2162]   c24       1
    x[2162]   c444      -1
    x[2162]   c564      -1
    x[2163]   c24       1
    x[2163]   c727      -1
    x[2163]   c847      -1
    x[2164]   c24       1
    x[2164]   c1010     -1
    x[2164]   c1130     -1
    x[2165]   c24       1
    x[2165]   c1293     -1
    x[2165]   c1413     -1
    x[2166]   c24       1
    x[2166]   c1576     -1
    x[2166]   c1696     -1
    x[2167]   c24       1
    x[2167]   c1859     -1
    x[2167]   c1979     -1
    x[2168]   c24       1
    x[2168]   c2142     -1
    x[2168]   c2262     -1
    x[2169]   c24       1
    x[2169]   c2425     -1
    x[2169]   c2545     -1
    x[2170]   c24       1
    x[2170]   c2708     -1
    x[2170]   c2828     -1
    x[2171]   c24       1
    x[2171]   c2991     -1
    x[2171]   c3111     -1
    x[2172]   c24       1
    x[2172]   c3274     -1
    x[2172]   c3394     -1
    x[2173]   c24       1
    x[2173]   c3557     -1
    x[2173]   c3677     -1
    x[2174]   c24       1
    x[2174]   c3840     -1
    x[2174]   c3960     -1
    x[2175]   c24       1
    x[2175]   c4123     -1
    x[2175]   c4243     -1
    x[2176]   c24       1
    x[2176]   c4406     -1
    x[2176]   c4526     -1
    x[2177]   c25       1
    x[2177]   c195      -1
    x[2177]   c262      -1
    x[2177]   c284      -1
    x[2178]   c25       1
    x[2178]   c478      -1
    x[2178]   c545      -1
    x[2178]   c567      -1
    x[2179]   c25       1
    x[2179]   c761      -1
    x[2179]   c828      -1
    x[2179]   c850      -1
    x[2180]   c25       1
    x[2180]   c1044     -1
    x[2180]   c1111     -1
    x[2180]   c1133     -1
    x[2181]   c25       1
    x[2181]   c1327     -1
    x[2181]   c1394     -1
    x[2181]   c1416     -1
    x[2182]   c25       1
    x[2182]   c1610     -1
    x[2182]   c1677     -1
    x[2182]   c1699     -1
    x[2183]   c25       1
    x[2183]   c1893     -1
    x[2183]   c1960     -1
    x[2183]   c1982     -1
    x[2184]   c25       1
    x[2184]   c2176     -1
    x[2184]   c2243     -1
    x[2184]   c2265     -1
    x[2185]   c25       1
    x[2185]   c2459     -1
    x[2185]   c2526     -1
    x[2185]   c2548     -1
    x[2186]   c25       1
    x[2186]   c2742     -1
    x[2186]   c2809     -1
    x[2186]   c2831     -1
    x[2187]   c25       1
    x[2187]   c3025     -1
    x[2187]   c3092     -1
    x[2187]   c3114     -1
    x[2188]   c25       1
    x[2188]   c3308     -1
    x[2188]   c3375     -1
    x[2188]   c3397     -1
    x[2189]   c25       1
    x[2189]   c3591     -1
    x[2189]   c3658     -1
    x[2189]   c3680     -1
    x[2190]   c25       1
    x[2190]   c3874     -1
    x[2190]   c3941     -1
    x[2190]   c3963     -1
    x[2191]   c25       1
    x[2191]   c4157     -1
    x[2191]   c4224     -1
    x[2191]   c4246     -1
    x[2192]   c25       1
    x[2192]   c4440     -1
    x[2192]   c4507     -1
    x[2192]   c4529     -1
    x[2193]   c26       1
    x[2193]   c217      -1
    x[2193]   c237      -1
    x[2193]   c296      -1
    x[2194]   c26       1
    x[2194]   c500      -1
    x[2194]   c520      -1
    x[2194]   c579      -1
    x[2195]   c26       1
    x[2195]   c783      -1
    x[2195]   c803      -1
    x[2195]   c862      -1
    x[2196]   c26       1
    x[2196]   c1066     -1
    x[2196]   c1086     -1
    x[2196]   c1145     -1
    x[2197]   c26       1
    x[2197]   c1349     -1
    x[2197]   c1369     -1
    x[2197]   c1428     -1
    x[2198]   c26       1
    x[2198]   c1632     -1
    x[2198]   c1652     -1
    x[2198]   c1711     -1
    x[2199]   c26       1
    x[2199]   c1915     -1
    x[2199]   c1935     -1
    x[2199]   c1994     -1
    x[2200]   c26       1
    x[2200]   c2198     -1
    x[2200]   c2218     -1
    x[2200]   c2277     -1
    x[2201]   c26       1
    x[2201]   c2481     -1
    x[2201]   c2501     -1
    x[2201]   c2560     -1
    x[2202]   c26       1
    x[2202]   c2764     -1
    x[2202]   c2784     -1
    x[2202]   c2843     -1
    x[2203]   c26       1
    x[2203]   c3047     -1
    x[2203]   c3067     -1
    x[2203]   c3126     -1
    x[2204]   c26       1
    x[2204]   c3330     -1
    x[2204]   c3350     -1
    x[2204]   c3409     -1
    x[2205]   c26       1
    x[2205]   c3613     -1
    x[2205]   c3633     -1
    x[2205]   c3692     -1
    x[2206]   c26       1
    x[2206]   c3896     -1
    x[2206]   c3916     -1
    x[2206]   c3975     -1
    x[2207]   c26       1
    x[2207]   c4179     -1
    x[2207]   c4199     -1
    x[2207]   c4258     -1
    x[2208]   c26       1
    x[2208]   c4462     -1
    x[2208]   c4482     -1
    x[2208]   c4541     -1
    x[2209]   c27       1
    x[2209]   c129      -1
    x[2209]   c153      -1
    x[2209]   c218      -1
    x[2209]   c240      -1
    x[2210]   c27       1
    x[2210]   c412      -1
    x[2210]   c436      -1
    x[2210]   c501      -1
    x[2210]   c523      -1
    x[2211]   c27       1
    x[2211]   c695      -1
    x[2211]   c719      -1
    x[2211]   c784      -1
    x[2211]   c806      -1
    x[2212]   c27       1
    x[2212]   c978      -1
    x[2212]   c1002     -1
    x[2212]   c1067     -1
    x[2212]   c1089     -1
    x[2213]   c27       1
    x[2213]   c1261     -1
    x[2213]   c1285     -1
    x[2213]   c1350     -1
    x[2213]   c1372     -1
    x[2214]   c27       1
    x[2214]   c1544     -1
    x[2214]   c1568     -1
    x[2214]   c1633     -1
    x[2214]   c1655     -1
    x[2215]   c27       1
    x[2215]   c1827     -1
    x[2215]   c1851     -1
    x[2215]   c1916     -1
    x[2215]   c1938     -1
    x[2216]   c27       1
    x[2216]   c2110     -1
    x[2216]   c2134     -1
    x[2216]   c2199     -1
    x[2216]   c2221     -1
    x[2217]   c27       1
    x[2217]   c2393     -1
    x[2217]   c2417     -1
    x[2217]   c2482     -1
    x[2217]   c2504     -1
    x[2218]   c27       1
    x[2218]   c2676     -1
    x[2218]   c2700     -1
    x[2218]   c2765     -1
    x[2218]   c2787     -1
    x[2219]   c27       1
    x[2219]   c2959     -1
    x[2219]   c2983     -1
    x[2219]   c3048     -1
    x[2219]   c3070     -1
    x[2220]   c27       1
    x[2220]   c3242     -1
    x[2220]   c3266     -1
    x[2220]   c3331     -1
    x[2220]   c3353     -1
    x[2221]   c27       1
    x[2221]   c3525     -1
    x[2221]   c3549     -1
    x[2221]   c3614     -1
    x[2221]   c3636     -1
    x[2222]   c27       1
    x[2222]   c3808     -1
    x[2222]   c3832     -1
    x[2222]   c3897     -1
    x[2222]   c3919     -1
    x[2223]   c27       1
    x[2223]   c4091     -1
    x[2223]   c4115     -1
    x[2223]   c4180     -1
    x[2223]   c4202     -1
    x[2224]   c27       1
    x[2224]   c4374     -1
    x[2224]   c4398     -1
    x[2224]   c4463     -1
    x[2224]   c4485     -1
    x[2225]   c28       1
    x[2225]   c152      -1
    x[2225]   c214      -1
    x[2225]   c343      -1
    x[2225]   c352      -1
    x[2226]   c28       1
    x[2226]   c435      -1
    x[2226]   c497      -1
    x[2226]   c626      -1
    x[2226]   c635      -1
    x[2227]   c28       1
    x[2227]   c718      -1
    x[2227]   c780      -1
    x[2227]   c909      -1
    x[2227]   c918      -1
    x[2228]   c28       1
    x[2228]   c1001     -1
    x[2228]   c1063     -1
    x[2228]   c1192     -1
    x[2228]   c1201     -1
    x[2229]   c28       1
    x[2229]   c1284     -1
    x[2229]   c1346     -1
    x[2229]   c1475     -1
    x[2229]   c1484     -1
    x[2230]   c28       1
    x[2230]   c1567     -1
    x[2230]   c1629     -1
    x[2230]   c1758     -1
    x[2230]   c1767     -1
    x[2231]   c28       1
    x[2231]   c1850     -1
    x[2231]   c1912     -1
    x[2231]   c2041     -1
    x[2231]   c2050     -1
    x[2232]   c28       1
    x[2232]   c2133     -1
    x[2232]   c2195     -1
    x[2232]   c2324     -1
    x[2232]   c2333     -1
    x[2233]   c28       1
    x[2233]   c2416     -1
    x[2233]   c2478     -1
    x[2233]   c2607     -1
    x[2233]   c2616     -1
    x[2234]   c28       1
    x[2234]   c2699     -1
    x[2234]   c2761     -1
    x[2234]   c2890     -1
    x[2234]   c2899     -1
    x[2235]   c28       1
    x[2235]   c2982     -1
    x[2235]   c3044     -1
    x[2235]   c3173     -1
    x[2235]   c3182     -1
    x[2236]   c28       1
    x[2236]   c3265     -1
    x[2236]   c3327     -1
    x[2236]   c3456     -1
    x[2236]   c3465     -1
    x[2237]   c28       1
    x[2237]   c3548     -1
    x[2237]   c3610     -1
    x[2237]   c3739     -1
    x[2237]   c3748     -1
    x[2238]   c28       1
    x[2238]   c3831     -1
    x[2238]   c3893     -1
    x[2238]   c4022     -1
    x[2238]   c4031     -1
    x[2239]   c28       1
    x[2239]   c4114     -1
    x[2239]   c4176     -1
    x[2239]   c4305     -1
    x[2239]   c4314     -1
    x[2240]   c28       1
    x[2240]   c4397     -1
    x[2240]   c4459     -1
    x[2240]   c4588     -1
    x[2240]   c4597     -1
    x[2241]   c29       1
    x[2241]   c188      -1
    x[2241]   c196      -1
    x[2242]   c29       1
    x[2242]   c471      -1
    x[2242]   c479      -1
    x[2243]   c29       1
    x[2243]   c754      -1
    x[2243]   c762      -1
    x[2244]   c29       1
    x[2244]   c1037     -1
    x[2244]   c1045     -1
    x[2245]   c29       1
    x[2245]   c1320     -1
    x[2245]   c1328     -1
    x[2246]   c29       1
    x[2246]   c1603     -1
    x[2246]   c1611     -1
    x[2247]   c29       1
    x[2247]   c1886     -1
    x[2247]   c1894     -1
    x[2248]   c29       1
    x[2248]   c2169     -1
    x[2248]   c2177     -1
    x[2249]   c29       1
    x[2249]   c2452     -1
    x[2249]   c2460     -1
    x[2250]   c29       1
    x[2250]   c2735     -1
    x[2250]   c2743     -1
    x[2251]   c29       1
    x[2251]   c3018     -1
    x[2251]   c3026     -1
    x[2252]   c29       1
    x[2252]   c3301     -1
    x[2252]   c3309     -1
    x[2253]   c29       1
    x[2253]   c3584     -1
    x[2253]   c3592     -1
    x[2254]   c29       1
    x[2254]   c3867     -1
    x[2254]   c3875     -1
    x[2255]   c29       1
    x[2255]   c4150     -1
    x[2255]   c4158     -1
    x[2256]   c29       1
    x[2256]   c4433     -1
    x[2256]   c4441     -1
    x[2257]   c30       1
    x[2257]   c234      -1
    x[2257]   c294      -1
    x[2257]   c313      -1
    x[2258]   c30       1
    x[2258]   c517      -1
    x[2258]   c577      -1
    x[2258]   c596      -1
    x[2259]   c30       1
    x[2259]   c800      -1
    x[2259]   c860      -1
    x[2259]   c879      -1
    x[2260]   c30       1
    x[2260]   c1083     -1
    x[2260]   c1143     -1
    x[2260]   c1162     -1
    x[2261]   c30       1
    x[2261]   c1366     -1
    x[2261]   c1426     -1
    x[2261]   c1445     -1
    x[2262]   c30       1
    x[2262]   c1649     -1
    x[2262]   c1709     -1
    x[2262]   c1728     -1
    x[2263]   c30       1
    x[2263]   c1932     -1
    x[2263]   c1992     -1
    x[2263]   c2011     -1
    x[2264]   c30       1
    x[2264]   c2215     -1
    x[2264]   c2275     -1
    x[2264]   c2294     -1
    x[2265]   c30       1
    x[2265]   c2498     -1
    x[2265]   c2558     -1
    x[2265]   c2577     -1
    x[2266]   c30       1
    x[2266]   c2781     -1
    x[2266]   c2841     -1
    x[2266]   c2860     -1
    x[2267]   c30       1
    x[2267]   c3064     -1
    x[2267]   c3124     -1
    x[2267]   c3143     -1
    x[2268]   c30       1
    x[2268]   c3347     -1
    x[2268]   c3407     -1
    x[2268]   c3426     -1
    x[2269]   c30       1
    x[2269]   c3630     -1
    x[2269]   c3690     -1
    x[2269]   c3709     -1
    x[2270]   c30       1
    x[2270]   c3913     -1
    x[2270]   c3973     -1
    x[2270]   c3992     -1
    x[2271]   c30       1
    x[2271]   c4196     -1
    x[2271]   c4256     -1
    x[2271]   c4275     -1
    x[2272]   c30       1
    x[2272]   c4479     -1
    x[2272]   c4539     -1
    x[2272]   c4558     -1
    x[2273]   c31       1
    x[2273]   c132      -1
    x[2273]   c164      -1
    x[2273]   c215      -1
    x[2273]   c276      -1
    x[2274]   c31       1
    x[2274]   c415      -1
    x[2274]   c447      -1
    x[2274]   c498      -1
    x[2274]   c559      -1
    x[2275]   c31       1
    x[2275]   c698      -1
    x[2275]   c730      -1
    x[2275]   c781      -1
    x[2275]   c842      -1
    x[2276]   c31       1
    x[2276]   c981      -1
    x[2276]   c1013     -1
    x[2276]   c1064     -1
    x[2276]   c1125     -1
    x[2277]   c31       1
    x[2277]   c1264     -1
    x[2277]   c1296     -1
    x[2277]   c1347     -1
    x[2277]   c1408     -1
    x[2278]   c31       1
    x[2278]   c1547     -1
    x[2278]   c1579     -1
    x[2278]   c1630     -1
    x[2278]   c1691     -1
    x[2279]   c31       1
    x[2279]   c1830     -1
    x[2279]   c1862     -1
    x[2279]   c1913     -1
    x[2279]   c1974     -1
    x[2280]   c31       1
    x[2280]   c2113     -1
    x[2280]   c2145     -1
    x[2280]   c2196     -1
    x[2280]   c2257     -1
    x[2281]   c31       1
    x[2281]   c2396     -1
    x[2281]   c2428     -1
    x[2281]   c2479     -1
    x[2281]   c2540     -1
    x[2282]   c31       1
    x[2282]   c2679     -1
    x[2282]   c2711     -1
    x[2282]   c2762     -1
    x[2282]   c2823     -1
    x[2283]   c31       1
    x[2283]   c2962     -1
    x[2283]   c2994     -1
    x[2283]   c3045     -1
    x[2283]   c3106     -1
    x[2284]   c31       1
    x[2284]   c3245     -1
    x[2284]   c3277     -1
    x[2284]   c3328     -1
    x[2284]   c3389     -1
    x[2285]   c31       1
    x[2285]   c3528     -1
    x[2285]   c3560     -1
    x[2285]   c3611     -1
    x[2285]   c3672     -1
    x[2286]   c31       1
    x[2286]   c3811     -1
    x[2286]   c3843     -1
    x[2286]   c3894     -1
    x[2286]   c3955     -1
    x[2287]   c31       1
    x[2287]   c4094     -1
    x[2287]   c4126     -1
    x[2287]   c4177     -1
    x[2287]   c4238     -1
    x[2288]   c31       1
    x[2288]   c4377     -1
    x[2288]   c4409     -1
    x[2288]   c4460     -1
    x[2288]   c4521     -1
    x[2289]   c32       1
    x[2289]   c128      -1
    x[2289]   c318      -1
    x[2289]   c364      -1
    x[2290]   c32       1
    x[2290]   c411      -1
    x[2290]   c601      -1
    x[2290]   c647      -1
    x[2291]   c32       1
    x[2291]   c694      -1
    x[2291]   c884      -1
    x[2291]   c930      -1
    x[2292]   c32       1
    x[2292]   c977      -1
    x[2292]   c1167     -1
    x[2292]   c1213     -1
    x[2293]   c32       1
    x[2293]   c1260     -1
    x[2293]   c1450     -1
    x[2293]   c1496     -1
    x[2294]   c32       1
    x[2294]   c1543     -1
    x[2294]   c1733     -1
    x[2294]   c1779     -1
    x[2295]   c32       1
    x[2295]   c1826     -1
    x[2295]   c2016     -1
    x[2295]   c2062     -1
    x[2296]   c32       1
    x[2296]   c2109     -1
    x[2296]   c2299     -1
    x[2296]   c2345     -1
    x[2297]   c32       1
    x[2297]   c2392     -1
    x[2297]   c2582     -1
    x[2297]   c2628     -1
    x[2298]   c32       1
    x[2298]   c2675     -1
    x[2298]   c2865     -1
    x[2298]   c2911     -1
    x[2299]   c32       1
    x[2299]   c2958     -1
    x[2299]   c3148     -1
    x[2299]   c3194     -1
    x[2300]   c32       1
    x[2300]   c3241     -1
    x[2300]   c3431     -1
    x[2300]   c3477     -1
    x[2301]   c32       1
    x[2301]   c3524     -1
    x[2301]   c3714     -1
    x[2301]   c3760     -1
    x[2302]   c32       1
    x[2302]   c3807     -1
    x[2302]   c3997     -1
    x[2302]   c4043     -1
    x[2303]   c32       1
    x[2303]   c4090     -1
    x[2303]   c4280     -1
    x[2303]   c4326     -1
    x[2304]   c32       1
    x[2304]   c4373     -1
    x[2304]   c4563     -1
    x[2304]   c4609     -1
    x[2305]   c33       1
    x[2305]   c154      -1
    x[2305]   c250      -1
    x[2305]   c365      -1
    x[2305]   c376      -1
    x[2306]   c33       1
    x[2306]   c437      -1
    x[2306]   c533      -1
    x[2306]   c648      -1
    x[2306]   c659      -1
    x[2307]   c33       1
    x[2307]   c720      -1
    x[2307]   c816      -1
    x[2307]   c931      -1
    x[2307]   c942      -1
    x[2308]   c33       1
    x[2308]   c1003     -1
    x[2308]   c1099     -1
    x[2308]   c1214     -1
    x[2308]   c1225     -1
    x[2309]   c33       1
    x[2309]   c1286     -1
    x[2309]   c1382     -1
    x[2309]   c1497     -1
    x[2309]   c1508     -1
    x[2310]   c33       1
    x[2310]   c1569     -1
    x[2310]   c1665     -1
    x[2310]   c1780     -1
    x[2310]   c1791     -1
    x[2311]   c33       1
    x[2311]   c1852     -1
    x[2311]   c1948     -1
    x[2311]   c2063     -1
    x[2311]   c2074     -1
    x[2312]   c33       1
    x[2312]   c2135     -1
    x[2312]   c2231     -1
    x[2312]   c2346     -1
    x[2312]   c2357     -1
    x[2313]   c33       1
    x[2313]   c2418     -1
    x[2313]   c2514     -1
    x[2313]   c2629     -1
    x[2313]   c2640     -1
    x[2314]   c33       1
    x[2314]   c2701     -1
    x[2314]   c2797     -1
    x[2314]   c2912     -1
    x[2314]   c2923     -1
    x[2315]   c33       1
    x[2315]   c2984     -1
    x[2315]   c3080     -1
    x[2315]   c3195     -1
    x[2315]   c3206     -1
    x[2316]   c33       1
    x[2316]   c3267     -1
    x[2316]   c3363     -1
    x[2316]   c3478     -1
    x[2316]   c3489     -1
    x[2317]   c33       1
    x[2317]   c3550     -1
    x[2317]   c3646     -1
    x[2317]   c3761     -1
    x[2317]   c3772     -1
    x[2318]   c33       1
    x[2318]   c3833     -1
    x[2318]   c3929     -1
    x[2318]   c4044     -1
    x[2318]   c4055     -1
    x[2319]   c33       1
    x[2319]   c4116     -1
    x[2319]   c4212     -1
    x[2319]   c4327     -1
    x[2319]   c4338     -1
    x[2320]   c33       1
    x[2320]   c4399     -1
    x[2320]   c4495     -1
    x[2320]   c4610     -1
    x[2320]   c4621     -1
    x[2321]   c34       1
    x[2321]   c228      -1
    x[2321]   c326      -1
    x[2321]   c353      -1
    x[2321]   c381      -1
    x[2322]   c34       1
    x[2322]   c511      -1
    x[2322]   c609      -1
    x[2322]   c636      -1
    x[2322]   c664      -1
    x[2323]   c34       1
    x[2323]   c794      -1
    x[2323]   c892      -1
    x[2323]   c919      -1
    x[2323]   c947      -1
    x[2324]   c34       1
    x[2324]   c1077     -1
    x[2324]   c1175     -1
    x[2324]   c1202     -1
    x[2324]   c1230     -1
    x[2325]   c34       1
    x[2325]   c1360     -1
    x[2325]   c1458     -1
    x[2325]   c1485     -1
    x[2325]   c1513     -1
    x[2326]   c34       1
    x[2326]   c1643     -1
    x[2326]   c1741     -1
    x[2326]   c1768     -1
    x[2326]   c1796     -1
    x[2327]   c34       1
    x[2327]   c1926     -1
    x[2327]   c2024     -1
    x[2327]   c2051     -1
    x[2327]   c2079     -1
    x[2328]   c34       1
    x[2328]   c2209     -1
    x[2328]   c2307     -1
    x[2328]   c2334     -1
    x[2328]   c2362     -1
    x[2329]   c34       1
    x[2329]   c2492     -1
    x[2329]   c2590     -1
    x[2329]   c2617     -1
    x[2329]   c2645     -1
    x[2330]   c34       1
    x[2330]   c2775     -1
    x[2330]   c2873     -1
    x[2330]   c2900     -1
    x[2330]   c2928     -1
    x[2331]   c34       1
    x[2331]   c3058     -1
    x[2331]   c3156     -1
    x[2331]   c3183     -1
    x[2331]   c3211     -1
    x[2332]   c34       1
    x[2332]   c3341     -1
    x[2332]   c3439     -1
    x[2332]   c3466     -1
    x[2332]   c3494     -1
    x[2333]   c34       1
    x[2333]   c3624     -1
    x[2333]   c3722     -1
    x[2333]   c3749     -1
    x[2333]   c3777     -1
    x[2334]   c34       1
    x[2334]   c3907     -1
    x[2334]   c4005     -1
    x[2334]   c4032     -1
    x[2334]   c4060     -1
    x[2335]   c34       1
    x[2335]   c4190     -1
    x[2335]   c4288     -1
    x[2335]   c4315     -1
    x[2335]   c4343     -1
    x[2336]   c34       1
    x[2336]   c4473     -1
    x[2336]   c4571     -1
    x[2336]   c4598     -1
    x[2336]   c4626     -1
    x[2337]   c35       1
    x[2337]   c238      -1
    x[2337]   c247      -1
    x[2338]   c35       1
    x[2338]   c521      -1
    x[2338]   c530      -1
    x[2339]   c35       1
    x[2339]   c804      -1
    x[2339]   c813      -1
    x[2340]   c35       1
    x[2340]   c1087     -1
    x[2340]   c1096     -1
    x[2341]   c35       1
    x[2341]   c1370     -1
    x[2341]   c1379     -1
    x[2342]   c35       1
    x[2342]   c1653     -1
    x[2342]   c1662     -1
    x[2343]   c35       1
    x[2343]   c1936     -1
    x[2343]   c1945     -1
    x[2344]   c35       1
    x[2344]   c2219     -1
    x[2344]   c2228     -1
    x[2345]   c35       1
    x[2345]   c2502     -1
    x[2345]   c2511     -1
    x[2346]   c35       1
    x[2346]   c2785     -1
    x[2346]   c2794     -1
    x[2347]   c35       1
    x[2347]   c3068     -1
    x[2347]   c3077     -1
    x[2348]   c35       1
    x[2348]   c3351     -1
    x[2348]   c3360     -1
    x[2349]   c35       1
    x[2349]   c3634     -1
    x[2349]   c3643     -1
    x[2350]   c35       1
    x[2350]   c3917     -1
    x[2350]   c3926     -1
    x[2351]   c35       1
    x[2351]   c4200     -1
    x[2351]   c4209     -1
    x[2352]   c35       1
    x[2352]   c4483     -1
    x[2352]   c4492     -1
    x[2353]   c36       1
    x[2353]   c133      -1
    x[2353]   c272      -1
    x[2353]   c382      -1
    x[2353]   c383      -1
    x[2354]   c36       1
    x[2354]   c416      -1
    x[2354]   c555      -1
    x[2354]   c665      -1
    x[2354]   c666      -1
    x[2355]   c36       1
    x[2355]   c699      -1
    x[2355]   c838      -1
    x[2355]   c948      -1
    x[2355]   c949      -1
    x[2356]   c36       1
    x[2356]   c982      -1
    x[2356]   c1121     -1
    x[2356]   c1231     -1
    x[2356]   c1232     -1
    x[2357]   c36       1
    x[2357]   c1265     -1
    x[2357]   c1404     -1
    x[2357]   c1514     -1
    x[2357]   c1515     -1
    x[2358]   c36       1
    x[2358]   c1548     -1
    x[2358]   c1687     -1
    x[2358]   c1797     -1
    x[2358]   c1798     -1
    x[2359]   c36       1
    x[2359]   c1831     -1
    x[2359]   c1970     -1
    x[2359]   c2080     -1
    x[2359]   c2081     -1
    x[2360]   c36       1
    x[2360]   c2114     -1
    x[2360]   c2253     -1
    x[2360]   c2363     -1
    x[2360]   c2364     -1
    x[2361]   c36       1
    x[2361]   c2397     -1
    x[2361]   c2536     -1
    x[2361]   c2646     -1
    x[2361]   c2647     -1
    x[2362]   c36       1
    x[2362]   c2680     -1
    x[2362]   c2819     -1
    x[2362]   c2929     -1
    x[2362]   c2930     -1
    x[2363]   c36       1
    x[2363]   c2963     -1
    x[2363]   c3102     -1
    x[2363]   c3212     -1
    x[2363]   c3213     -1
    x[2364]   c36       1
    x[2364]   c3246     -1
    x[2364]   c3385     -1
    x[2364]   c3495     -1
    x[2364]   c3496     -1
    x[2365]   c36       1
    x[2365]   c3529     -1
    x[2365]   c3668     -1
    x[2365]   c3778     -1
    x[2365]   c3779     -1
    x[2366]   c36       1
    x[2366]   c3812     -1
    x[2366]   c3951     -1
    x[2366]   c4061     -1
    x[2366]   c4062     -1
    x[2367]   c36       1
    x[2367]   c4095     -1
    x[2367]   c4234     -1
    x[2367]   c4344     -1
    x[2367]   c4345     -1
    x[2368]   c36       1
    x[2368]   c4378     -1
    x[2368]   c4517     -1
    x[2368]   c4627     -1
    x[2368]   c4628     -1
    x[2369]   c37       1
    x[2369]   c115      -1
    x[2369]   c265      -1
    x[2369]   c285      -1
    x[2370]   c37       1
    x[2370]   c398      -1
    x[2370]   c548      -1
    x[2370]   c568      -1
    x[2371]   c37       1
    x[2371]   c681      -1
    x[2371]   c831      -1
    x[2371]   c851      -1
    x[2372]   c37       1
    x[2372]   c964      -1
    x[2372]   c1114     -1
    x[2372]   c1134     -1
    x[2373]   c37       1
    x[2373]   c1247     -1
    x[2373]   c1397     -1
    x[2373]   c1417     -1
    x[2374]   c37       1
    x[2374]   c1530     -1
    x[2374]   c1680     -1
    x[2374]   c1700     -1
    x[2375]   c37       1
    x[2375]   c1813     -1
    x[2375]   c1963     -1
    x[2375]   c1983     -1
    x[2376]   c37       1
    x[2376]   c2096     -1
    x[2376]   c2246     -1
    x[2376]   c2266     -1
    x[2377]   c37       1
    x[2377]   c2379     -1
    x[2377]   c2529     -1
    x[2377]   c2549     -1
    x[2378]   c37       1
    x[2378]   c2662     -1
    x[2378]   c2812     -1
    x[2378]   c2832     -1
    x[2379]   c37       1
    x[2379]   c2945     -1
    x[2379]   c3095     -1
    x[2379]   c3115     -1
    x[2380]   c37       1
    x[2380]   c3228     -1
    x[2380]   c3378     -1
    x[2380]   c3398     -1
    x[2381]   c37       1
    x[2381]   c3511     -1
    x[2381]   c3661     -1
    x[2381]   c3681     -1
    x[2382]   c37       1
    x[2382]   c3794     -1
    x[2382]   c3944     -1
    x[2382]   c3964     -1
    x[2383]   c37       1
    x[2383]   c4077     -1
    x[2383]   c4227     -1
    x[2383]   c4247     -1
    x[2384]   c37       1
    x[2384]   c4360     -1
    x[2384]   c4510     -1
    x[2384]   c4530     -1
    x[2385]   c38       1
    x[2385]   c227      -1
    x[2385]   c308      -1
    x[2385]   c366      -1
    x[2385]   c385      -1
    x[2386]   c38       1
    x[2386]   c510      -1
    x[2386]   c591      -1
    x[2386]   c649      -1
    x[2386]   c668      -1
    x[2387]   c38       1
    x[2387]   c793      -1
    x[2387]   c874      -1
    x[2387]   c932      -1
    x[2387]   c951      -1
    x[2388]   c38       1
    x[2388]   c1076     -1
    x[2388]   c1157     -1
    x[2388]   c1215     -1
    x[2388]   c1234     -1
    x[2389]   c38       1
    x[2389]   c1359     -1
    x[2389]   c1440     -1
    x[2389]   c1498     -1
    x[2389]   c1517     -1
    x[2390]   c38       1
    x[2390]   c1642     -1
    x[2390]   c1723     -1
    x[2390]   c1781     -1
    x[2390]   c1800     -1
    x[2391]   c38       1
    x[2391]   c1925     -1
    x[2391]   c2006     -1
    x[2391]   c2064     -1
    x[2391]   c2083     -1
    x[2392]   c38       1
    x[2392]   c2208     -1
    x[2392]   c2289     -1
    x[2392]   c2347     -1
    x[2392]   c2366     -1
    x[2393]   c38       1
    x[2393]   c2491     -1
    x[2393]   c2572     -1
    x[2393]   c2630     -1
    x[2393]   c2649     -1
    x[2394]   c38       1
    x[2394]   c2774     -1
    x[2394]   c2855     -1
    x[2394]   c2913     -1
    x[2394]   c2932     -1
    x[2395]   c38       1
    x[2395]   c3057     -1
    x[2395]   c3138     -1
    x[2395]   c3196     -1
    x[2395]   c3215     -1
    x[2396]   c38       1
    x[2396]   c3340     -1
    x[2396]   c3421     -1
    x[2396]   c3479     -1
    x[2396]   c3498     -1
    x[2397]   c38       1
    x[2397]   c3623     -1
    x[2397]   c3704     -1
    x[2397]   c3762     -1
    x[2397]   c3781     -1
    x[2398]   c38       1
    x[2398]   c3906     -1
    x[2398]   c3987     -1
    x[2398]   c4045     -1
    x[2398]   c4064     -1
    x[2399]   c38       1
    x[2399]   c4189     -1
    x[2399]   c4270     -1
    x[2399]   c4328     -1
    x[2399]   c4347     -1
    x[2400]   c38       1
    x[2400]   c4472     -1
    x[2400]   c4553     -1
    x[2400]   c4611     -1
    x[2400]   c4630     -1
    x[2401]   c39       1
    x[2401]   c185      -1
    x[2401]   c251      -1
    x[2402]   c39       1
    x[2402]   c468      -1
    x[2402]   c534      -1
    x[2403]   c39       1
    x[2403]   c751      -1
    x[2403]   c817      -1
    x[2404]   c39       1
    x[2404]   c1034     -1
    x[2404]   c1100     -1
    x[2405]   c39       1
    x[2405]   c1317     -1
    x[2405]   c1383     -1
    x[2406]   c39       1
    x[2406]   c1600     -1
    x[2406]   c1666     -1
    x[2407]   c39       1
    x[2407]   c1883     -1
    x[2407]   c1949     -1
    x[2408]   c39       1
    x[2408]   c2166     -1
    x[2408]   c2232     -1
    x[2409]   c39       1
    x[2409]   c2449     -1
    x[2409]   c2515     -1
    x[2410]   c39       1
    x[2410]   c2732     -1
    x[2410]   c2798     -1
    x[2411]   c39       1
    x[2411]   c3015     -1
    x[2411]   c3081     -1
    x[2412]   c39       1
    x[2412]   c3298     -1
    x[2412]   c3364     -1
    x[2413]   c39       1
    x[2413]   c3581     -1
    x[2413]   c3647     -1
    x[2414]   c39       1
    x[2414]   c3864     -1
    x[2414]   c3930     -1
    x[2415]   c39       1
    x[2415]   c4147     -1
    x[2415]   c4213     -1
    x[2416]   c39       1
    x[2416]   c4430     -1
    x[2416]   c4496     -1
    x[2417]   c40       1
    x[2417]   c257      -1
    x[2417]   c289      -1
    x[2417]   c337      -1
    x[2418]   c40       1
    x[2418]   c540      -1
    x[2418]   c572      -1
    x[2418]   c620      -1
    x[2419]   c40       1
    x[2419]   c823      -1
    x[2419]   c855      -1
    x[2419]   c903      -1
    x[2420]   c40       1
    x[2420]   c1106     -1
    x[2420]   c1138     -1
    x[2420]   c1186     -1
    x[2421]   c40       1
    x[2421]   c1389     -1
    x[2421]   c1421     -1
    x[2421]   c1469     -1
    x[2422]   c40       1
    x[2422]   c1672     -1
    x[2422]   c1704     -1
    x[2422]   c1752     -1
    x[2423]   c40       1
    x[2423]   c1955     -1
    x[2423]   c1987     -1
    x[2423]   c2035     -1
    x[2424]   c40       1
    x[2424]   c2238     -1
    x[2424]   c2270     -1
    x[2424]   c2318     -1
    x[2425]   c40       1
    x[2425]   c2521     -1
    x[2425]   c2553     -1
    x[2425]   c2601     -1
    x[2426]   c40       1
    x[2426]   c2804     -1
    x[2426]   c2836     -1
    x[2426]   c2884     -1
    x[2427]   c40       1
    x[2427]   c3087     -1
    x[2427]   c3119     -1
    x[2427]   c3167     -1
    x[2428]   c40       1
    x[2428]   c3370     -1
    x[2428]   c3402     -1
    x[2428]   c3450     -1
    x[2429]   c40       1
    x[2429]   c3653     -1
    x[2429]   c3685     -1
    x[2429]   c3733     -1
    x[2430]   c40       1
    x[2430]   c3936     -1
    x[2430]   c3968     -1
    x[2430]   c4016     -1
    x[2431]   c40       1
    x[2431]   c4219     -1
    x[2431]   c4251     -1
    x[2431]   c4299     -1
    x[2432]   c40       1
    x[2432]   c4502     -1
    x[2432]   c4534     -1
    x[2432]   c4582     -1
    x[2433]   c41       1
    x[2433]   c147      -1
    x[2433]   c158      -1
    x[2433]   c252      -1
    x[2434]   c41       1
    x[2434]   c430      -1
    x[2434]   c441      -1
    x[2434]   c535      -1
    x[2435]   c41       1
    x[2435]   c713      -1
    x[2435]   c724      -1
    x[2435]   c818      -1
    x[2436]   c41       1
    x[2436]   c996      -1
    x[2436]   c1007     -1
    x[2436]   c1101     -1
    x[2437]   c41       1
    x[2437]   c1279     -1
    x[2437]   c1290     -1
    x[2437]   c1384     -1
    x[2438]   c41       1
    x[2438]   c1562     -1
    x[2438]   c1573     -1
    x[2438]   c1667     -1
    x[2439]   c41       1
    x[2439]   c1845     -1
    x[2439]   c1856     -1
    x[2439]   c1950     -1
    x[2440]   c41       1
    x[2440]   c2128     -1
    x[2440]   c2139     -1
    x[2440]   c2233     -1
    x[2441]   c41       1
    x[2441]   c2411     -1
    x[2441]   c2422     -1
    x[2441]   c2516     -1
    x[2442]   c41       1
    x[2442]   c2694     -1
    x[2442]   c2705     -1
    x[2442]   c2799     -1
    x[2443]   c41       1
    x[2443]   c2977     -1
    x[2443]   c2988     -1
    x[2443]   c3082     -1
    x[2444]   c41       1
    x[2444]   c3260     -1
    x[2444]   c3271     -1
    x[2444]   c3365     -1
    x[2445]   c41       1
    x[2445]   c3543     -1
    x[2445]   c3554     -1
    x[2445]   c3648     -1
    x[2446]   c41       1
    x[2446]   c3826     -1
    x[2446]   c3837     -1
    x[2446]   c3931     -1
    x[2447]   c41       1
    x[2447]   c4109     -1
    x[2447]   c4120     -1
    x[2447]   c4214     -1
    x[2448]   c41       1
    x[2448]   c4392     -1
    x[2448]   c4403     -1
    x[2448]   c4497     -1
    x[2449]   c42       1
    x[2449]   c145      -1
    x[2449]   c209      -1
    x[2449]   c360      -1
    x[2450]   c42       1
    x[2450]   c428      -1
    x[2450]   c492      -1
    x[2450]   c643      -1
    x[2451]   c42       1
    x[2451]   c711      -1
    x[2451]   c775      -1
    x[2451]   c926      -1
    x[2452]   c42       1
    x[2452]   c994      -1
    x[2452]   c1058     -1
    x[2452]   c1209     -1
    x[2453]   c42       1
    x[2453]   c1277     -1
    x[2453]   c1341     -1
    x[2453]   c1492     -1
    x[2454]   c42       1
    x[2454]   c1560     -1
    x[2454]   c1624     -1
    x[2454]   c1775     -1
    x[2455]   c42       1
    x[2455]   c1843     -1
    x[2455]   c1907     -1
    x[2455]   c2058     -1
    x[2456]   c42       1
    x[2456]   c2126     -1
    x[2456]   c2190     -1
    x[2456]   c2341     -1
    x[2457]   c42       1
    x[2457]   c2409     -1
    x[2457]   c2473     -1
    x[2457]   c2624     -1
    x[2458]   c42       1
    x[2458]   c2692     -1
    x[2458]   c2756     -1
    x[2458]   c2907     -1
    x[2459]   c42       1
    x[2459]   c2975     -1
    x[2459]   c3039     -1
    x[2459]   c3190     -1
    x[2460]   c42       1
    x[2460]   c3258     -1
    x[2460]   c3322     -1
    x[2460]   c3473     -1
    x[2461]   c42       1
    x[2461]   c3541     -1
    x[2461]   c3605     -1
    x[2461]   c3756     -1
    x[2462]   c42       1
    x[2462]   c3824     -1
    x[2462]   c3888     -1
    x[2462]   c4039     -1
    x[2463]   c42       1
    x[2463]   c4107     -1
    x[2463]   c4171     -1
    x[2463]   c4322     -1
    x[2464]   c42       1
    x[2464]   c4390     -1
    x[2464]   c4454     -1
    x[2464]   c4605     -1
    x[2465]   c43       1
    x[2465]   c121      -1
    x[2465]   c197      -1
    x[2465]   c207      -1
    x[2465]   c229      -1
    x[2466]   c43       1
    x[2466]   c404      -1
    x[2466]   c480      -1
    x[2466]   c490      -1
    x[2466]   c512      -1
    x[2467]   c43       1
    x[2467]   c687      -1
    x[2467]   c763      -1
    x[2467]   c773      -1
    x[2467]   c795      -1
    x[2468]   c43       1
    x[2468]   c970      -1
    x[2468]   c1046     -1
    x[2468]   c1056     -1
    x[2468]   c1078     -1
    x[2469]   c43       1
    x[2469]   c1253     -1
    x[2469]   c1329     -1
    x[2469]   c1339     -1
    x[2469]   c1361     -1
    x[2470]   c43       1
    x[2470]   c1536     -1
    x[2470]   c1612     -1
    x[2470]   c1622     -1
    x[2470]   c1644     -1
    x[2471]   c43       1
    x[2471]   c1819     -1
    x[2471]   c1895     -1
    x[2471]   c1905     -1
    x[2471]   c1927     -1
    x[2472]   c43       1
    x[2472]   c2102     -1
    x[2472]   c2178     -1
    x[2472]   c2188     -1
    x[2472]   c2210     -1
    x[2473]   c43       1
    x[2473]   c2385     -1
    x[2473]   c2461     -1
    x[2473]   c2471     -1
    x[2473]   c2493     -1
    x[2474]   c43       1
    x[2474]   c2668     -1
    x[2474]   c2744     -1
    x[2474]   c2754     -1
    x[2474]   c2776     -1
    x[2475]   c43       1
    x[2475]   c2951     -1
    x[2475]   c3027     -1
    x[2475]   c3037     -1
    x[2475]   c3059     -1
    x[2476]   c43       1
    x[2476]   c3234     -1
    x[2476]   c3310     -1
    x[2476]   c3320     -1
    x[2476]   c3342     -1
    x[2477]   c43       1
    x[2477]   c3517     -1
    x[2477]   c3593     -1
    x[2477]   c3603     -1
    x[2477]   c3625     -1
    x[2478]   c43       1
    x[2478]   c3800     -1
    x[2478]   c3876     -1
    x[2478]   c3886     -1
    x[2478]   c3908     -1
    x[2479]   c43       1
    x[2479]   c4083     -1
    x[2479]   c4159     -1
    x[2479]   c4169     -1
    x[2479]   c4191     -1
    x[2480]   c43       1
    x[2480]   c4366     -1
    x[2480]   c4442     -1
    x[2480]   c4452     -1
    x[2480]   c4474     -1
    x[2481]   c44       1
    x[2481]   c220      -1
    x[2481]   c232      -1
    x[2481]   c300      -1
    x[2481]   c341      -1
    x[2482]   c44       1
    x[2482]   c503      -1
    x[2482]   c515      -1
    x[2482]   c583      -1
    x[2482]   c624      -1
    x[2483]   c44       1
    x[2483]   c786      -1
    x[2483]   c798      -1
    x[2483]   c866      -1
    x[2483]   c907      -1
    x[2484]   c44       1
    x[2484]   c1069     -1
    x[2484]   c1081     -1
    x[2484]   c1149     -1
    x[2484]   c1190     -1
    x[2485]   c44       1
    x[2485]   c1352     -1
    x[2485]   c1364     -1
    x[2485]   c1432     -1
    x[2485]   c1473     -1
    x[2486]   c44       1
    x[2486]   c1635     -1
    x[2486]   c1647     -1
    x[2486]   c1715     -1
    x[2486]   c1756     -1
    x[2487]   c44       1
    x[2487]   c1918     -1
    x[2487]   c1930     -1
    x[2487]   c1998     -1
    x[2487]   c2039     -1
    x[2488]   c44       1
    x[2488]   c2201     -1
    x[2488]   c2213     -1
    x[2488]   c2281     -1
    x[2488]   c2322     -1
    x[2489]   c44       1
    x[2489]   c2484     -1
    x[2489]   c2496     -1
    x[2489]   c2564     -1
    x[2489]   c2605     -1
    x[2490]   c44       1
    x[2490]   c2767     -1
    x[2490]   c2779     -1
    x[2490]   c2847     -1
    x[2490]   c2888     -1
    x[2491]   c44       1
    x[2491]   c3050     -1
    x[2491]   c3062     -1
    x[2491]   c3130     -1
    x[2491]   c3171     -1
    x[2492]   c44       1
    x[2492]   c3333     -1
    x[2492]   c3345     -1
    x[2492]   c3413     -1
    x[2492]   c3454     -1
    x[2493]   c44       1
    x[2493]   c3616     -1
    x[2493]   c3628     -1
    x[2493]   c3696     -1
    x[2493]   c3737     -1
    x[2494]   c44       1
    x[2494]   c3899     -1
    x[2494]   c3911     -1
    x[2494]   c3979     -1
    x[2494]   c4020     -1
    x[2495]   c44       1
    x[2495]   c4182     -1
    x[2495]   c4194     -1
    x[2495]   c4262     -1
    x[2495]   c4303     -1
    x[2496]   c44       1
    x[2496]   c4465     -1
    x[2496]   c4477     -1
    x[2496]   c4545     -1
    x[2496]   c4586     -1
    x[2497]   c45       1
    x[2497]   c178      -1
    x[2497]   c210      -1
    x[2497]   c241      -1
    x[2497]   c246      -1
    x[2498]   c45       1
    x[2498]   c461      -1
    x[2498]   c493      -1
    x[2498]   c524      -1
    x[2498]   c529      -1
    x[2499]   c45       1
    x[2499]   c744      -1
    x[2499]   c776      -1
    x[2499]   c807      -1
    x[2499]   c812      -1
    x[2500]   c45       1
    x[2500]   c1027     -1
    x[2500]   c1059     -1
    x[2500]   c1090     -1
    x[2500]   c1095     -1
    x[2501]   c45       1
    x[2501]   c1310     -1
    x[2501]   c1342     -1
    x[2501]   c1373     -1
    x[2501]   c1378     -1
    x[2502]   c45       1
    x[2502]   c1593     -1
    x[2502]   c1625     -1
    x[2502]   c1656     -1
    x[2502]   c1661     -1
    x[2503]   c45       1
    x[2503]   c1876     -1
    x[2503]   c1908     -1
    x[2503]   c1939     -1
    x[2503]   c1944     -1
    x[2504]   c45       1
    x[2504]   c2159     -1
    x[2504]   c2191     -1
    x[2504]   c2222     -1
    x[2504]   c2227     -1
    x[2505]   c45       1
    x[2505]   c2442     -1
    x[2505]   c2474     -1
    x[2505]   c2505     -1
    x[2505]   c2510     -1
    x[2506]   c45       1
    x[2506]   c2725     -1
    x[2506]   c2757     -1
    x[2506]   c2788     -1
    x[2506]   c2793     -1
    x[2507]   c45       1
    x[2507]   c3008     -1
    x[2507]   c3040     -1
    x[2507]   c3071     -1
    x[2507]   c3076     -1
    x[2508]   c45       1
    x[2508]   c3291     -1
    x[2508]   c3323     -1
    x[2508]   c3354     -1
    x[2508]   c3359     -1
    x[2509]   c45       1
    x[2509]   c3574     -1
    x[2509]   c3606     -1
    x[2509]   c3637     -1
    x[2509]   c3642     -1
    x[2510]   c45       1
    x[2510]   c3857     -1
    x[2510]   c3889     -1
    x[2510]   c3920     -1
    x[2510]   c3925     -1
    x[2511]   c45       1
    x[2511]   c4140     -1
    x[2511]   c4172     -1
    x[2511]   c4203     -1
    x[2511]   c4208     -1
    x[2512]   c45       1
    x[2512]   c4423     -1
    x[2512]   c4455     -1
    x[2512]   c4486     -1
    x[2512]   c4491     -1
    x[2513]   c46       1
    x[2513]   c298      -1
    x[2513]   c301      -1
    x[2514]   c46       1
    x[2514]   c581      -1
    x[2514]   c584      -1
    x[2515]   c46       1
    x[2515]   c864      -1
    x[2515]   c867      -1
    x[2516]   c46       1
    x[2516]   c1147     -1
    x[2516]   c1150     -1
    x[2517]   c46       1
    x[2517]   c1430     -1
    x[2517]   c1433     -1
    x[2518]   c46       1
    x[2518]   c1713     -1
    x[2518]   c1716     -1
    x[2519]   c46       1
    x[2519]   c1996     -1
    x[2519]   c1999     -1
    x[2520]   c46       1
    x[2520]   c2279     -1
    x[2520]   c2282     -1
    x[2521]   c46       1
    x[2521]   c2562     -1
    x[2521]   c2565     -1
    x[2522]   c46       1
    x[2522]   c2845     -1
    x[2522]   c2848     -1
    x[2523]   c46       1
    x[2523]   c3128     -1
    x[2523]   c3131     -1
    x[2524]   c46       1
    x[2524]   c3411     -1
    x[2524]   c3414     -1
    x[2525]   c46       1
    x[2525]   c3694     -1
    x[2525]   c3697     -1
    x[2526]   c46       1
    x[2526]   c3977     -1
    x[2526]   c3980     -1
    x[2527]   c46       1
    x[2527]   c4260     -1
    x[2527]   c4263     -1
    x[2528]   c46       1
    x[2528]   c4543     -1
    x[2528]   c4546     -1
    x[2529]   c47       1
    x[2529]   c109      -1
    x[2529]   c172      -1
    x[2529]   c297      -1
    x[2530]   c47       1
    x[2530]   c392      -1
    x[2530]   c455      -1
    x[2530]   c580      -1
    x[2531]   c47       1
    x[2531]   c675      -1
    x[2531]   c738      -1
    x[2531]   c863      -1
    x[2532]   c47       1
    x[2532]   c958      -1
    x[2532]   c1021     -1
    x[2532]   c1146     -1
    x[2533]   c47       1
    x[2533]   c1241     -1
    x[2533]   c1304     -1
    x[2533]   c1429     -1
    x[2534]   c47       1
    x[2534]   c1524     -1
    x[2534]   c1587     -1
    x[2534]   c1712     -1
    x[2535]   c47       1
    x[2535]   c1807     -1
    x[2535]   c1870     -1
    x[2535]   c1995     -1
    x[2536]   c47       1
    x[2536]   c2090     -1
    x[2536]   c2153     -1
    x[2536]   c2278     -1
    x[2537]   c47       1
    x[2537]   c2373     -1
    x[2537]   c2436     -1
    x[2537]   c2561     -1
    x[2538]   c47       1
    x[2538]   c2656     -1
    x[2538]   c2719     -1
    x[2538]   c2844     -1
    x[2539]   c47       1
    x[2539]   c2939     -1
    x[2539]   c3002     -1
    x[2539]   c3127     -1
    x[2540]   c47       1
    x[2540]   c3222     -1
    x[2540]   c3285     -1
    x[2540]   c3410     -1
    x[2541]   c47       1
    x[2541]   c3505     -1
    x[2541]   c3568     -1
    x[2541]   c3693     -1
    x[2542]   c47       1
    x[2542]   c3788     -1
    x[2542]   c3851     -1
    x[2542]   c3976     -1
    x[2543]   c47       1
    x[2543]   c4071     -1
    x[2543]   c4134     -1
    x[2543]   c4259     -1
    x[2544]   c47       1
    x[2544]   c4354     -1
    x[2544]   c4417     -1
    x[2544]   c4542     -1
    x[2545]   c48       1
    x[2545]   c122      -1
    x[2545]   c175      -1
    x[2545]   c221      -1
    x[2545]   c258      -1
    x[2546]   c48       1
    x[2546]   c405      -1
    x[2546]   c458      -1
    x[2546]   c504      -1
    x[2546]   c541      -1
    x[2547]   c48       1
    x[2547]   c688      -1
    x[2547]   c741      -1
    x[2547]   c787      -1
    x[2547]   c824      -1
    x[2548]   c48       1
    x[2548]   c971      -1
    x[2548]   c1024     -1
    x[2548]   c1070     -1
    x[2548]   c1107     -1
    x[2549]   c48       1
    x[2549]   c1254     -1
    x[2549]   c1307     -1
    x[2549]   c1353     -1
    x[2549]   c1390     -1
    x[2550]   c48       1
    x[2550]   c1537     -1
    x[2550]   c1590     -1
    x[2550]   c1636     -1
    x[2550]   c1673     -1
    x[2551]   c48       1
    x[2551]   c1820     -1
    x[2551]   c1873     -1
    x[2551]   c1919     -1
    x[2551]   c1956     -1
    x[2552]   c48       1
    x[2552]   c2103     -1
    x[2552]   c2156     -1
    x[2552]   c2202     -1
    x[2552]   c2239     -1
    x[2553]   c48       1
    x[2553]   c2386     -1
    x[2553]   c2439     -1
    x[2553]   c2485     -1
    x[2553]   c2522     -1
    x[2554]   c48       1
    x[2554]   c2669     -1
    x[2554]   c2722     -1
    x[2554]   c2768     -1
    x[2554]   c2805     -1
    x[2555]   c48       1
    x[2555]   c2952     -1
    x[2555]   c3005     -1
    x[2555]   c3051     -1
    x[2555]   c3088     -1
    x[2556]   c48       1
    x[2556]   c3235     -1
    x[2556]   c3288     -1
    x[2556]   c3334     -1
    x[2556]   c3371     -1
    x[2557]   c48       1
    x[2557]   c3518     -1
    x[2557]   c3571     -1
    x[2557]   c3617     -1
    x[2557]   c3654     -1
    x[2558]   c48       1
    x[2558]   c3801     -1
    x[2558]   c3854     -1
    x[2558]   c3900     -1
    x[2558]   c3937     -1
    x[2559]   c48       1
    x[2559]   c4084     -1
    x[2559]   c4137     -1
    x[2559]   c4183     -1
    x[2559]   c4220     -1
    x[2560]   c48       1
    x[2560]   c4367     -1
    x[2560]   c4420     -1
    x[2560]   c4466     -1
    x[2560]   c4503     -1
    x[2561]   c49       1
    x[2561]   c130      -1
    x[2561]   c181      -1
    x[2562]   c49       1
    x[2562]   c413      -1
    x[2562]   c464      -1
    x[2563]   c49       1
    x[2563]   c696      -1
    x[2563]   c747      -1
    x[2564]   c49       1
    x[2564]   c979      -1
    x[2564]   c1030     -1
    x[2565]   c49       1
    x[2565]   c1262     -1
    x[2565]   c1313     -1
    x[2566]   c49       1
    x[2566]   c1545     -1
    x[2566]   c1596     -1
    x[2567]   c49       1
    x[2567]   c1828     -1
    x[2567]   c1879     -1
    x[2568]   c49       1
    x[2568]   c2111     -1
    x[2568]   c2162     -1
    x[2569]   c49       1
    x[2569]   c2394     -1
    x[2569]   c2445     -1
    x[2570]   c49       1
    x[2570]   c2677     -1
    x[2570]   c2728     -1
    x[2571]   c49       1
    x[2571]   c2960     -1
    x[2571]   c3011     -1
    x[2572]   c49       1
    x[2572]   c3243     -1
    x[2572]   c3294     -1
    x[2573]   c49       1
    x[2573]   c3526     -1
    x[2573]   c3577     -1
    x[2574]   c49       1
    x[2574]   c3809     -1
    x[2574]   c3860     -1
    x[2575]   c49       1
    x[2575]   c4092     -1
    x[2575]   c4143     -1
    x[2576]   c49       1
    x[2576]   c4375     -1
    x[2576]   c4426     -1
    x[2577]   c50       1
    x[2577]   c162      -1
    x[2577]   c224      -1
    x[2578]   c50       1
    x[2578]   c445      -1
    x[2578]   c507      -1
    x[2579]   c50       1
    x[2579]   c728      -1
    x[2579]   c790      -1
    x[2580]   c50       1
    x[2580]   c1011     -1
    x[2580]   c1073     -1
    x[2581]   c50       1
    x[2581]   c1294     -1
    x[2581]   c1356     -1
    x[2582]   c50       1
    x[2582]   c1577     -1
    x[2582]   c1639     -1
    x[2583]   c50       1
    x[2583]   c1860     -1
    x[2583]   c1922     -1
    x[2584]   c50       1
    x[2584]   c2143     -1
    x[2584]   c2205     -1
    x[2585]   c50       1
    x[2585]   c2426     -1
    x[2585]   c2488     -1
    x[2586]   c50       1
    x[2586]   c2709     -1
    x[2586]   c2771     -1
    x[2587]   c50       1
    x[2587]   c2992     -1
    x[2587]   c3054     -1
    x[2588]   c50       1
    x[2588]   c3275     -1
    x[2588]   c3337     -1
    x[2589]   c50       1
    x[2589]   c3558     -1
    x[2589]   c3620     -1
    x[2590]   c50       1
    x[2590]   c3841     -1
    x[2590]   c3903     -1
    x[2591]   c50       1
    x[2591]   c4124     -1
    x[2591]   c4186     -1
    x[2592]   c50       1
    x[2592]   c4407     -1
    x[2592]   c4469     -1
    x[2593]   c51       1
    x[2593]   c230      -1
    x[2593]   c334      -1
    x[2593]   c348      -1
    x[2594]   c51       1
    x[2594]   c513      -1
    x[2594]   c617      -1
    x[2594]   c631      -1
    x[2595]   c51       1
    x[2595]   c796      -1
    x[2595]   c900      -1
    x[2595]   c914      -1
    x[2596]   c51       1
    x[2596]   c1079     -1
    x[2596]   c1183     -1
    x[2596]   c1197     -1
    x[2597]   c51       1
    x[2597]   c1362     -1
    x[2597]   c1466     -1
    x[2597]   c1480     -1
    x[2598]   c51       1
    x[2598]   c1645     -1
    x[2598]   c1749     -1
    x[2598]   c1763     -1
    x[2599]   c51       1
    x[2599]   c1928     -1
    x[2599]   c2032     -1
    x[2599]   c2046     -1
    x[2600]   c51       1
    x[2600]   c2211     -1
    x[2600]   c2315     -1
    x[2600]   c2329     -1
    x[2601]   c51       1
    x[2601]   c2494     -1
    x[2601]   c2598     -1
    x[2601]   c2612     -1
    x[2602]   c51       1
    x[2602]   c2777     -1
    x[2602]   c2881     -1
    x[2602]   c2895     -1
    x[2603]   c51       1
    x[2603]   c3060     -1
    x[2603]   c3164     -1
    x[2603]   c3178     -1
    x[2604]   c51       1
    x[2604]   c3343     -1
    x[2604]   c3447     -1
    x[2604]   c3461     -1
    x[2605]   c51       1
    x[2605]   c3626     -1
    x[2605]   c3730     -1
    x[2605]   c3744     -1
    x[2606]   c51       1
    x[2606]   c3909     -1
    x[2606]   c4013     -1
    x[2606]   c4027     -1
    x[2607]   c51       1
    x[2607]   c4192     -1
    x[2607]   c4296     -1
    x[2607]   c4310     -1
    x[2608]   c51       1
    x[2608]   c4475     -1
    x[2608]   c4579     -1
    x[2608]   c4593     -1
    x[2609]   c52       1
    x[2609]   c182      -1
    x[2609]   c279      -1
    x[2609]   c354      -1
    x[2609]   c375      -1
    x[2610]   c52       1
    x[2610]   c465      -1
    x[2610]   c562      -1
    x[2610]   c637      -1
    x[2610]   c658      -1
    x[2611]   c52       1
    x[2611]   c748      -1
    x[2611]   c845      -1
    x[2611]   c920      -1
    x[2611]   c941      -1
    x[2612]   c52       1
    x[2612]   c1031     -1
    x[2612]   c1128     -1
    x[2612]   c1203     -1
    x[2612]   c1224     -1
    x[2613]   c52       1
    x[2613]   c1314     -1
    x[2613]   c1411     -1
    x[2613]   c1486     -1
    x[2613]   c1507     -1
    x[2614]   c52       1
    x[2614]   c1597     -1
    x[2614]   c1694     -1
    x[2614]   c1769     -1
    x[2614]   c1790     -1
    x[2615]   c52       1
    x[2615]   c1880     -1
    x[2615]   c1977     -1
    x[2615]   c2052     -1
    x[2615]   c2073     -1
    x[2616]   c52       1
    x[2616]   c2163     -1
    x[2616]   c2260     -1
    x[2616]   c2335     -1
    x[2616]   c2356     -1
    x[2617]   c52       1
    x[2617]   c2446     -1
    x[2617]   c2543     -1
    x[2617]   c2618     -1
    x[2617]   c2639     -1
    x[2618]   c52       1
    x[2618]   c2729     -1
    x[2618]   c2826     -1
    x[2618]   c2901     -1
    x[2618]   c2922     -1
    x[2619]   c52       1
    x[2619]   c3012     -1
    x[2619]   c3109     -1
    x[2619]   c3184     -1
    x[2619]   c3205     -1
    x[2620]   c52       1
    x[2620]   c3295     -1
    x[2620]   c3392     -1
    x[2620]   c3467     -1
    x[2620]   c3488     -1
    x[2621]   c52       1
    x[2621]   c3578     -1
    x[2621]   c3675     -1
    x[2621]   c3750     -1
    x[2621]   c3771     -1
    x[2622]   c52       1
    x[2622]   c3861     -1
    x[2622]   c3958     -1
    x[2622]   c4033     -1
    x[2622]   c4054     -1
    x[2623]   c52       1
    x[2623]   c4144     -1
    x[2623]   c4241     -1
    x[2623]   c4316     -1
    x[2623]   c4337     -1
    x[2624]   c52       1
    x[2624]   c4427     -1
    x[2624]   c4524     -1
    x[2624]   c4599     -1
    x[2624]   c4620     -1
    x[2625]   c53       1
    x[2625]   c173      -1
    x[2625]   c198      -1
    x[2625]   c307      -1
    x[2625]   c329      -1
    x[2626]   c53       1
    x[2626]   c456      -1
    x[2626]   c481      -1
    x[2626]   c590      -1
    x[2626]   c612      -1
    x[2627]   c53       1
    x[2627]   c739      -1
    x[2627]   c764      -1
    x[2627]   c873      -1
    x[2627]   c895      -1
    x[2628]   c53       1
    x[2628]   c1022     -1
    x[2628]   c1047     -1
    x[2628]   c1156     -1
    x[2628]   c1178     -1
    x[2629]   c53       1
    x[2629]   c1305     -1
    x[2629]   c1330     -1
    x[2629]   c1439     -1
    x[2629]   c1461     -1
    x[2630]   c53       1
    x[2630]   c1588     -1
    x[2630]   c1613     -1
    x[2630]   c1722     -1
    x[2630]   c1744     -1
    x[2631]   c53       1
    x[2631]   c1871     -1
    x[2631]   c1896     -1
    x[2631]   c2005     -1
    x[2631]   c2027     -1
    x[2632]   c53       1
    x[2632]   c2154     -1
    x[2632]   c2179     -1
    x[2632]   c2288     -1
    x[2632]   c2310     -1
    x[2633]   c53       1
    x[2633]   c2437     -1
    x[2633]   c2462     -1
    x[2633]   c2571     -1
    x[2633]   c2593     -1
    x[2634]   c53       1
    x[2634]   c2720     -1
    x[2634]   c2745     -1
    x[2634]   c2854     -1
    x[2634]   c2876     -1
    x[2635]   c53       1
    x[2635]   c3003     -1
    x[2635]   c3028     -1
    x[2635]   c3137     -1
    x[2635]   c3159     -1
    x[2636]   c53       1
    x[2636]   c3286     -1
    x[2636]   c3311     -1
    x[2636]   c3420     -1
    x[2636]   c3442     -1
    x[2637]   c53       1
    x[2637]   c3569     -1
    x[2637]   c3594     -1
    x[2637]   c3703     -1
    x[2637]   c3725     -1
    x[2638]   c53       1
    x[2638]   c3852     -1
    x[2638]   c3877     -1
    x[2638]   c3986     -1
    x[2638]   c4008     -1
    x[2639]   c53       1
    x[2639]   c4135     -1
    x[2639]   c4160     -1
    x[2639]   c4269     -1
    x[2639]   c4291     -1
    x[2640]   c53       1
    x[2640]   c4418     -1
    x[2640]   c4443     -1
    x[2640]   c4552     -1
    x[2640]   c4574     -1
    x[2641]   c54       1
    x[2641]   c126      -1
    x[2641]   c327      -1
    x[2642]   c54       1
    x[2642]   c409      -1
    x[2642]   c610      -1
    x[2643]   c54       1
    x[2643]   c692      -1
    x[2643]   c893      -1
    x[2644]   c54       1
    x[2644]   c975      -1
    x[2644]   c1176     -1
    x[2645]   c54       1
    x[2645]   c1258     -1
    x[2645]   c1459     -1
    x[2646]   c54       1
    x[2646]   c1541     -1
    x[2646]   c1742     -1
    x[2647]   c54       1
    x[2647]   c1824     -1
    x[2647]   c2025     -1
    x[2648]   c54       1
    x[2648]   c2107     -1
    x[2648]   c2308     -1
    x[2649]   c54       1
    x[2649]   c2390     -1
    x[2649]   c2591     -1
    x[2650]   c54       1
    x[2650]   c2673     -1
    x[2650]   c2874     -1
    x[2651]   c54       1
    x[2651]   c2956     -1
    x[2651]   c3157     -1
    x[2652]   c54       1
    x[2652]   c3239     -1
    x[2652]   c3440     -1
    x[2653]   c54       1
    x[2653]   c3522     -1
    x[2653]   c3723     -1
    x[2654]   c54       1
    x[2654]   c3805     -1
    x[2654]   c4006     -1
    x[2655]   c54       1
    x[2655]   c4088     -1
    x[2655]   c4289     -1
    x[2656]   c54       1
    x[2656]   c4371     -1
    x[2656]   c4572     -1
    x[2657]   c55       1
    x[2657]   c330      -1
    x[2657]   c384      -1
    x[2658]   c55       1
    x[2658]   c613      -1
    x[2658]   c667      -1
    x[2659]   c55       1
    x[2659]   c896      -1
    x[2659]   c950      -1
    x[2660]   c55       1
    x[2660]   c1179     -1
    x[2660]   c1233     -1
    x[2661]   c55       1
    x[2661]   c1462     -1
    x[2661]   c1516     -1
    x[2662]   c55       1
    x[2662]   c1745     -1
    x[2662]   c1799     -1
    x[2663]   c55       1
    x[2663]   c2028     -1
    x[2663]   c2082     -1
    x[2664]   c55       1
    x[2664]   c2311     -1
    x[2664]   c2365     -1
    x[2665]   c55       1
    x[2665]   c2594     -1
    x[2665]   c2648     -1
    x[2666]   c55       1
    x[2666]   c2877     -1
    x[2666]   c2931     -1
    x[2667]   c55       1
    x[2667]   c3160     -1
    x[2667]   c3214     -1
    x[2668]   c55       1
    x[2668]   c3443     -1
    x[2668]   c3497     -1
    x[2669]   c55       1
    x[2669]   c3726     -1
    x[2669]   c3780     -1
    x[2670]   c55       1
    x[2670]   c4009     -1
    x[2670]   c4063     -1
    x[2671]   c55       1
    x[2671]   c4292     -1
    x[2671]   c4346     -1
    x[2672]   c55       1
    x[2672]   c4575     -1
    x[2672]   c4629     -1
    x[2673]   c56       1
    x[2673]   c106      -1
    x[2673]   c159      -1
    x[2673]   c186      -1
    x[2673]   c219      -1
    x[2674]   c56       1
    x[2674]   c389      -1
    x[2674]   c442      -1
    x[2674]   c469      -1
    x[2674]   c502      -1
    x[2675]   c56       1
    x[2675]   c672      -1
    x[2675]   c725      -1
    x[2675]   c752      -1
    x[2675]   c785      -1
    x[2676]   c56       1
    x[2676]   c955      -1
    x[2676]   c1008     -1
    x[2676]   c1035     -1
    x[2676]   c1068     -1
    x[2677]   c56       1
    x[2677]   c1238     -1
    x[2677]   c1291     -1
    x[2677]   c1318     -1
    x[2677]   c1351     -1
    x[2678]   c56       1
    x[2678]   c1521     -1
    x[2678]   c1574     -1
    x[2678]   c1601     -1
    x[2678]   c1634     -1
    x[2679]   c56       1
    x[2679]   c1804     -1
    x[2679]   c1857     -1
    x[2679]   c1884     -1
    x[2679]   c1917     -1
    x[2680]   c56       1
    x[2680]   c2087     -1
    x[2680]   c2140     -1
    x[2680]   c2167     -1
    x[2680]   c2200     -1
    x[2681]   c56       1
    x[2681]   c2370     -1
    x[2681]   c2423     -1
    x[2681]   c2450     -1
    x[2681]   c2483     -1
    x[2682]   c56       1
    x[2682]   c2653     -1
    x[2682]   c2706     -1
    x[2682]   c2733     -1
    x[2682]   c2766     -1
    x[2683]   c56       1
    x[2683]   c2936     -1
    x[2683]   c2989     -1
    x[2683]   c3016     -1
    x[2683]   c3049     -1
    x[2684]   c56       1
    x[2684]   c3219     -1
    x[2684]   c3272     -1
    x[2684]   c3299     -1
    x[2684]   c3332     -1
    x[2685]   c56       1
    x[2685]   c3502     -1
    x[2685]   c3555     -1
    x[2685]   c3582     -1
    x[2685]   c3615     -1
    x[2686]   c56       1
    x[2686]   c3785     -1
    x[2686]   c3838     -1
    x[2686]   c3865     -1
    x[2686]   c3898     -1
    x[2687]   c56       1
    x[2687]   c4068     -1
    x[2687]   c4121     -1
    x[2687]   c4148     -1
    x[2687]   c4181     -1
    x[2688]   c56       1
    x[2688]   c4351     -1
    x[2688]   c4404     -1
    x[2688]   c4431     -1
    x[2688]   c4464     -1
    x[2689]   c57       1
    x[2689]   c107      -1
    x[2689]   c203      -1
    x[2689]   c331      -1
    x[2690]   c57       1
    x[2690]   c390      -1
    x[2690]   c486      -1
    x[2690]   c614      -1
    x[2691]   c57       1
    x[2691]   c673      -1
    x[2691]   c769      -1
    x[2691]   c897      -1
    x[2692]   c57       1
    x[2692]   c956      -1
    x[2692]   c1052     -1
    x[2692]   c1180     -1
    x[2693]   c57       1
    x[2693]   c1239     -1
    x[2693]   c1335     -1
    x[2693]   c1463     -1
    x[2694]   c57       1
    x[2694]   c1522     -1
    x[2694]   c1618     -1
    x[2694]   c1746     -1
    x[2695]   c57       1
    x[2695]   c1805     -1
    x[2695]   c1901     -1
    x[2695]   c2029     -1
    x[2696]   c57       1
    x[2696]   c2088     -1
    x[2696]   c2184     -1
    x[2696]   c2312     -1
    x[2697]   c57       1
    x[2697]   c2371     -1
    x[2697]   c2467     -1
    x[2697]   c2595     -1
    x[2698]   c57       1
    x[2698]   c2654     -1
    x[2698]   c2750     -1
    x[2698]   c2878     -1
    x[2699]   c57       1
    x[2699]   c2937     -1
    x[2699]   c3033     -1
    x[2699]   c3161     -1
    x[2700]   c57       1
    x[2700]   c3220     -1
    x[2700]   c3316     -1
    x[2700]   c3444     -1
    x[2701]   c57       1
    x[2701]   c3503     -1
    x[2701]   c3599     -1
    x[2701]   c3727     -1
    x[2702]   c57       1
    x[2702]   c3786     -1
    x[2702]   c3882     -1
    x[2702]   c4010     -1
    x[2703]   c57       1
    x[2703]   c4069     -1
    x[2703]   c4165     -1
    x[2703]   c4293     -1
    x[2704]   c57       1
    x[2704]   c4352     -1
    x[2704]   c4448     -1
    x[2704]   c4576     -1
    x[2705]   c58       1
    x[2705]   c148      -1
    x[2705]   c338      -1
    x[2705]   c361      -1
    x[2706]   c58       1
    x[2706]   c431      -1
    x[2706]   c621      -1
    x[2706]   c644      -1
    x[2707]   c58       1
    x[2707]   c714      -1
    x[2707]   c904      -1
    x[2707]   c927      -1
    x[2708]   c58       1
    x[2708]   c997      -1
    x[2708]   c1187     -1
    x[2708]   c1210     -1
    x[2709]   c58       1
    x[2709]   c1280     -1
    x[2709]   c1470     -1
    x[2709]   c1493     -1
    x[2710]   c58       1
    x[2710]   c1563     -1
    x[2710]   c1753     -1
    x[2710]   c1776     -1
    x[2711]   c58       1
    x[2711]   c1846     -1
    x[2711]   c2036     -1
    x[2711]   c2059     -1
    x[2712]   c58       1
    x[2712]   c2129     -1
    x[2712]   c2319     -1
    x[2712]   c2342     -1
    x[2713]   c58       1
    x[2713]   c2412     -1
    x[2713]   c2602     -1
    x[2713]   c2625     -1
    x[2714]   c58       1
    x[2714]   c2695     -1
    x[2714]   c2885     -1
    x[2714]   c2908     -1
    x[2715]   c58       1
    x[2715]   c2978     -1
    x[2715]   c3168     -1
    x[2715]   c3191     -1
    x[2716]   c58       1
    x[2716]   c3261     -1
    x[2716]   c3451     -1
    x[2716]   c3474     -1
    x[2717]   c58       1
    x[2717]   c3544     -1
    x[2717]   c3734     -1
    x[2717]   c3757     -1
    x[2718]   c58       1
    x[2718]   c3827     -1
    x[2718]   c4017     -1
    x[2718]   c4040     -1
    x[2719]   c58       1
    x[2719]   c4110     -1
    x[2719]   c4300     -1
    x[2719]   c4323     -1
    x[2720]   c58       1
    x[2720]   c4393     -1
    x[2720]   c4583     -1
    x[2720]   c4606     -1
    x[2721]   c59       1
    x[2721]   c111      -1
    x[2721]   c212      -1
    x[2721]   c302      -1
    x[2721]   c367      -1
    x[2722]   c59       1
    x[2722]   c394      -1
    x[2722]   c495      -1
    x[2722]   c585      -1
    x[2722]   c650      -1
    x[2723]   c59       1
    x[2723]   c677      -1
    x[2723]   c778      -1
    x[2723]   c868      -1
    x[2723]   c933      -1
    x[2724]   c59       1
    x[2724]   c960      -1
    x[2724]   c1061     -1
    x[2724]   c1151     -1
    x[2724]   c1216     -1
    x[2725]   c59       1
    x[2725]   c1243     -1
    x[2725]   c1344     -1
    x[2725]   c1434     -1
    x[2725]   c1499     -1
    x[2726]   c59       1
    x[2726]   c1526     -1
    x[2726]   c1627     -1
    x[2726]   c1717     -1
    x[2726]   c1782     -1
    x[2727]   c59       1
    x[2727]   c1809     -1
    x[2727]   c1910     -1
    x[2727]   c2000     -1
    x[2727]   c2065     -1
    x[2728]   c59       1
    x[2728]   c2092     -1
    x[2728]   c2193     -1
    x[2728]   c2283     -1
    x[2728]   c2348     -1
    x[2729]   c59       1
    x[2729]   c2375     -1
    x[2729]   c2476     -1
    x[2729]   c2566     -1
    x[2729]   c2631     -1
    x[2730]   c59       1
    x[2730]   c2658     -1
    x[2730]   c2759     -1
    x[2730]   c2849     -1
    x[2730]   c2914     -1
    x[2731]   c59       1
    x[2731]   c2941     -1
    x[2731]   c3042     -1
    x[2731]   c3132     -1
    x[2731]   c3197     -1
    x[2732]   c59       1
    x[2732]   c3224     -1
    x[2732]   c3325     -1
    x[2732]   c3415     -1
    x[2732]   c3480     -1
    x[2733]   c59       1
    x[2733]   c3507     -1
    x[2733]   c3608     -1
    x[2733]   c3698     -1
    x[2733]   c3763     -1
    x[2734]   c59       1
    x[2734]   c3790     -1
    x[2734]   c3891     -1
    x[2734]   c3981     -1
    x[2734]   c4046     -1
    x[2735]   c59       1
    x[2735]   c4073     -1
    x[2735]   c4174     -1
    x[2735]   c4264     -1
    x[2735]   c4329     -1
    x[2736]   c59       1
    x[2736]   c4356     -1
    x[2736]   c4457     -1
    x[2736]   c4547     -1
    x[2736]   c4612     -1
    x[2737]   c60       1
    x[2737]   c180      -1
    x[2737]   c225      -1
    x[2737]   c287      -1
    x[2737]   c319      -1
    x[2738]   c60       1
    x[2738]   c463      -1
    x[2738]   c508      -1
    x[2738]   c570      -1
    x[2738]   c602      -1
    x[2739]   c60       1
    x[2739]   c746      -1
    x[2739]   c791      -1
    x[2739]   c853      -1
    x[2739]   c885      -1
    x[2740]   c60       1
    x[2740]   c1029     -1
    x[2740]   c1074     -1
    x[2740]   c1136     -1
    x[2740]   c1168     -1
    x[2741]   c60       1
    x[2741]   c1312     -1
    x[2741]   c1357     -1
    x[2741]   c1419     -1
    x[2741]   c1451     -1
    x[2742]   c60       1
    x[2742]   c1595     -1
    x[2742]   c1640     -1
    x[2742]   c1702     -1
    x[2742]   c1734     -1
    x[2743]   c60       1
    x[2743]   c1878     -1
    x[2743]   c1923     -1
    x[2743]   c1985     -1
    x[2743]   c2017     -1
    x[2744]   c60       1
    x[2744]   c2161     -1
    x[2744]   c2206     -1
    x[2744]   c2268     -1
    x[2744]   c2300     -1
    x[2745]   c60       1
    x[2745]   c2444     -1
    x[2745]   c2489     -1
    x[2745]   c2551     -1
    x[2745]   c2583     -1
    x[2746]   c60       1
    x[2746]   c2727     -1
    x[2746]   c2772     -1
    x[2746]   c2834     -1
    x[2746]   c2866     -1
    x[2747]   c60       1
    x[2747]   c3010     -1
    x[2747]   c3055     -1
    x[2747]   c3117     -1
    x[2747]   c3149     -1
    x[2748]   c60       1
    x[2748]   c3293     -1
    x[2748]   c3338     -1
    x[2748]   c3400     -1
    x[2748]   c3432     -1
    x[2749]   c60       1
    x[2749]   c3576     -1
    x[2749]   c3621     -1
    x[2749]   c3683     -1
    x[2749]   c3715     -1
    x[2750]   c60       1
    x[2750]   c3859     -1
    x[2750]   c3904     -1
    x[2750]   c3966     -1
    x[2750]   c3998     -1
    x[2751]   c60       1
    x[2751]   c4142     -1
    x[2751]   c4187     -1
    x[2751]   c4249     -1
    x[2751]   c4281     -1
    x[2752]   c60       1
    x[2752]   c4425     -1
    x[2752]   c4470     -1
    x[2752]   c4532     -1
    x[2752]   c4564     -1
    x[2753]   c61       1
    x[2753]   c136      -1
    x[2753]   c323      -1
    x[2753]   c377      -1
    x[2754]   c61       1
    x[2754]   c419      -1
    x[2754]   c606      -1
    x[2754]   c660      -1
    x[2755]   c61       1
    x[2755]   c702      -1
    x[2755]   c889      -1
    x[2755]   c943      -1
    x[2756]   c61       1
    x[2756]   c985      -1
    x[2756]   c1172     -1
    x[2756]   c1226     -1
    x[2757]   c61       1
    x[2757]   c1268     -1
    x[2757]   c1455     -1
    x[2757]   c1509     -1
    x[2758]   c61       1
    x[2758]   c1551     -1
    x[2758]   c1738     -1
    x[2758]   c1792     -1
    x[2759]   c61       1
    x[2759]   c1834     -1
    x[2759]   c2021     -1
    x[2759]   c2075     -1
    x[2760]   c61       1
    x[2760]   c2117     -1
    x[2760]   c2304     -1
    x[2760]   c2358     -1
    x[2761]   c61       1
    x[2761]   c2400     -1
    x[2761]   c2587     -1
    x[2761]   c2641     -1
    x[2762]   c61       1
    x[2762]   c2683     -1
    x[2762]   c2870     -1
    x[2762]   c2924     -1
    x[2763]   c61       1
    x[2763]   c2966     -1
    x[2763]   c3153     -1
    x[2763]   c3207     -1
    x[2764]   c61       1
    x[2764]   c3249     -1
    x[2764]   c3436     -1
    x[2764]   c3490     -1
    x[2765]   c61       1
    x[2765]   c3532     -1
    x[2765]   c3719     -1
    x[2765]   c3773     -1
    x[2766]   c61       1
    x[2766]   c3815     -1
    x[2766]   c4002     -1
    x[2766]   c4056     -1
    x[2767]   c61       1
    x[2767]   c4098     -1
    x[2767]   c4285     -1
    x[2767]   c4339     -1
    x[2768]   c61       1
    x[2768]   c4381     -1
    x[2768]   c4568     -1
    x[2768]   c4622     -1
    x[2769]   c62       1
    x[2769]   c116      -1
    x[2769]   c235      -1
    x[2769]   c248      -1
    x[2770]   c62       1
    x[2770]   c399      -1
    x[2770]   c518      -1
    x[2770]   c531      -1
    x[2771]   c62       1
    x[2771]   c682      -1
    x[2771]   c801      -1
    x[2771]   c814      -1
    x[2772]   c62       1
    x[2772]   c965      -1
    x[2772]   c1084     -1
    x[2772]   c1097     -1
    x[2773]   c62       1
    x[2773]   c1248     -1
    x[2773]   c1367     -1
    x[2773]   c1380     -1
    x[2774]   c62       1
    x[2774]   c1531     -1
    x[2774]   c1650     -1
    x[2774]   c1663     -1
    x[2775]   c62       1
    x[2775]   c1814     -1
    x[2775]   c1933     -1
    x[2775]   c1946     -1
    x[2776]   c62       1
    x[2776]   c2097     -1
    x[2776]   c2216     -1
    x[2776]   c2229     -1
    x[2777]   c62       1
    x[2777]   c2380     -1
    x[2777]   c2499     -1
    x[2777]   c2512     -1
    x[2778]   c62       1
    x[2778]   c2663     -1
    x[2778]   c2782     -1
    x[2778]   c2795     -1
    x[2779]   c62       1
    x[2779]   c2946     -1
    x[2779]   c3065     -1
    x[2779]   c3078     -1
    x[2780]   c62       1
    x[2780]   c3229     -1
    x[2780]   c3348     -1
    x[2780]   c3361     -1
    x[2781]   c62       1
    x[2781]   c3512     -1
    x[2781]   c3631     -1
    x[2781]   c3644     -1
    x[2782]   c62       1
    x[2782]   c3795     -1
    x[2782]   c3914     -1
    x[2782]   c3927     -1
    x[2783]   c62       1
    x[2783]   c4078     -1
    x[2783]   c4197     -1
    x[2783]   c4210     -1
    x[2784]   c62       1
    x[2784]   c4361     -1
    x[2784]   c4480     -1
    x[2784]   c4493     -1
    x[2785]   c63       1
    x[2785]   c273      -1
    x[2785]   c290      -1
    x[2785]   c342      -1
    x[2786]   c63       1
    x[2786]   c556      -1
    x[2786]   c573      -1
    x[2786]   c625      -1
    x[2787]   c63       1
    x[2787]   c839      -1
    x[2787]   c856      -1
    x[2787]   c908      -1
    x[2788]   c63       1
    x[2788]   c1122     -1
    x[2788]   c1139     -1
    x[2788]   c1191     -1
    x[2789]   c63       1
    x[2789]   c1405     -1
    x[2789]   c1422     -1
    x[2789]   c1474     -1
    x[2790]   c63       1
    x[2790]   c1688     -1
    x[2790]   c1705     -1
    x[2790]   c1757     -1
    x[2791]   c63       1
    x[2791]   c1971     -1
    x[2791]   c1988     -1
    x[2791]   c2040     -1
    x[2792]   c63       1
    x[2792]   c2254     -1
    x[2792]   c2271     -1
    x[2792]   c2323     -1
    x[2793]   c63       1
    x[2793]   c2537     -1
    x[2793]   c2554     -1
    x[2793]   c2606     -1
    x[2794]   c63       1
    x[2794]   c2820     -1
    x[2794]   c2837     -1
    x[2794]   c2889     -1
    x[2795]   c63       1
    x[2795]   c3103     -1
    x[2795]   c3120     -1
    x[2795]   c3172     -1
    x[2796]   c63       1
    x[2796]   c3386     -1
    x[2796]   c3403     -1
    x[2796]   c3455     -1
    x[2797]   c63       1
    x[2797]   c3669     -1
    x[2797]   c3686     -1
    x[2797]   c3738     -1
    x[2798]   c63       1
    x[2798]   c3952     -1
    x[2798]   c3969     -1
    x[2798]   c4021     -1
    x[2799]   c63       1
    x[2799]   c4235     -1
    x[2799]   c4252     -1
    x[2799]   c4304     -1
    x[2800]   c63       1
    x[2800]   c4518     -1
    x[2800]   c4535     -1
    x[2800]   c4587     -1
    x[2801]   c64       1
    x[2801]   c155      -1
    x[2801]   c286      -1
    x[2801]   c315      -1
    x[2801]   c351      -1
    x[2802]   c64       1
    x[2802]   c438      -1
    x[2802]   c569      -1
    x[2802]   c598      -1
    x[2802]   c634      -1
    x[2803]   c64       1
    x[2803]   c721      -1
    x[2803]   c852      -1
    x[2803]   c881      -1
    x[2803]   c917      -1
    x[2804]   c64       1
    x[2804]   c1004     -1
    x[2804]   c1135     -1
    x[2804]   c1164     -1
    x[2804]   c1200     -1
    x[2805]   c64       1
    x[2805]   c1287     -1
    x[2805]   c1418     -1
    x[2805]   c1447     -1
    x[2805]   c1483     -1
    x[2806]   c64       1
    x[2806]   c1570     -1
    x[2806]   c1701     -1
    x[2806]   c1730     -1
    x[2806]   c1766     -1
    x[2807]   c64       1
    x[2807]   c1853     -1
    x[2807]   c1984     -1
    x[2807]   c2013     -1
    x[2807]   c2049     -1
    x[2808]   c64       1
    x[2808]   c2136     -1
    x[2808]   c2267     -1
    x[2808]   c2296     -1
    x[2808]   c2332     -1
    x[2809]   c64       1
    x[2809]   c2419     -1
    x[2809]   c2550     -1
    x[2809]   c2579     -1
    x[2809]   c2615     -1
    x[2810]   c64       1
    x[2810]   c2702     -1
    x[2810]   c2833     -1
    x[2810]   c2862     -1
    x[2810]   c2898     -1
    x[2811]   c64       1
    x[2811]   c2985     -1
    x[2811]   c3116     -1
    x[2811]   c3145     -1
    x[2811]   c3181     -1
    x[2812]   c64       1
    x[2812]   c3268     -1
    x[2812]   c3399     -1
    x[2812]   c3428     -1
    x[2812]   c3464     -1
    x[2813]   c64       1
    x[2813]   c3551     -1
    x[2813]   c3682     -1
    x[2813]   c3711     -1
    x[2813]   c3747     -1
    x[2814]   c64       1
    x[2814]   c3834     -1
    x[2814]   c3965     -1
    x[2814]   c3994     -1
    x[2814]   c4030     -1
    x[2815]   c64       1
    x[2815]   c4117     -1
    x[2815]   c4248     -1
    x[2815]   c4277     -1
    x[2815]   c4313     -1
    x[2816]   c64       1
    x[2816]   c4400     -1
    x[2816]   c4531     -1
    x[2816]   c4560     -1
    x[2816]   c4596     -1
    x[2817]   c65       1
    x[2817]   c168      -1
    x[2817]   c177      -1
    x[2818]   c65       1
    x[2818]   c451      -1
    x[2818]   c460      -1
    x[2819]   c65       1
    x[2819]   c734      -1
    x[2819]   c743      -1
    x[2820]   c65       1
    x[2820]   c1017     -1
    x[2820]   c1026     -1
    x[2821]   c65       1
    x[2821]   c1300     -1
    x[2821]   c1309     -1
    x[2822]   c65       1
    x[2822]   c1583     -1
    x[2822]   c1592     -1
    x[2823]   c65       1
    x[2823]   c1866     -1
    x[2823]   c1875     -1
    x[2824]   c65       1
    x[2824]   c2149     -1
    x[2824]   c2158     -1
    x[2825]   c65       1
    x[2825]   c2432     -1
    x[2825]   c2441     -1
    x[2826]   c65       1
    x[2826]   c2715     -1
    x[2826]   c2724     -1
    x[2827]   c65       1
    x[2827]   c2998     -1
    x[2827]   c3007     -1
    x[2828]   c65       1
    x[2828]   c3281     -1
    x[2828]   c3290     -1
    x[2829]   c65       1
    x[2829]   c3564     -1
    x[2829]   c3573     -1
    x[2830]   c65       1
    x[2830]   c3847     -1
    x[2830]   c3856     -1
    x[2831]   c65       1
    x[2831]   c4130     -1
    x[2831]   c4139     -1
    x[2832]   c65       1
    x[2832]   c4413     -1
    x[2832]   c4422     -1
    x[2833]   c66       1
    x[2833]   c163      -1
    x[2833]   c191      -1
    x[2833]   c362      -1
    x[2834]   c66       1
    x[2834]   c446      -1
    x[2834]   c474      -1
    x[2834]   c645      -1
    x[2835]   c66       1
    x[2835]   c729      -1
    x[2835]   c757      -1
    x[2835]   c928      -1
    x[2836]   c66       1
    x[2836]   c1012     -1
    x[2836]   c1040     -1
    x[2836]   c1211     -1
    x[2837]   c66       1
    x[2837]   c1295     -1
    x[2837]   c1323     -1
    x[2837]   c1494     -1
    x[2838]   c66       1
    x[2838]   c1578     -1
    x[2838]   c1606     -1
    x[2838]   c1777     -1
    x[2839]   c66       1
    x[2839]   c1861     -1
    x[2839]   c1889     -1
    x[2839]   c2060     -1
    x[2840]   c66       1
    x[2840]   c2144     -1
    x[2840]   c2172     -1
    x[2840]   c2343     -1
    x[2841]   c66       1
    x[2841]   c2427     -1
    x[2841]   c2455     -1
    x[2841]   c2626     -1
    x[2842]   c66       1
    x[2842]   c2710     -1
    x[2842]   c2738     -1
    x[2842]   c2909     -1
    x[2843]   c66       1
    x[2843]   c2993     -1
    x[2843]   c3021     -1
    x[2843]   c3192     -1
    x[2844]   c66       1
    x[2844]   c3276     -1
    x[2844]   c3304     -1
    x[2844]   c3475     -1
    x[2845]   c66       1
    x[2845]   c3559     -1
    x[2845]   c3587     -1
    x[2845]   c3758     -1
    x[2846]   c66       1
    x[2846]   c3842     -1
    x[2846]   c3870     -1
    x[2846]   c4041     -1
    x[2847]   c66       1
    x[2847]   c4125     -1
    x[2847]   c4153     -1
    x[2847]   c4324     -1
    x[2848]   c66       1
    x[2848]   c4408     -1
    x[2848]   c4436     -1
    x[2848]   c4607     -1
    x[2849]   c67       1
    x[2849]   c165      -1
    x[2849]   c253      -1
    x[2849]   c349      -1
    x[2849]   c357      -1
    x[2850]   c67       1
    x[2850]   c448      -1
    x[2850]   c536      -1
    x[2850]   c632      -1
    x[2850]   c640      -1
    x[2851]   c67       1
    x[2851]   c731      -1
    x[2851]   c819      -1
    x[2851]   c915      -1
    x[2851]   c923      -1
    x[2852]   c67       1
    x[2852]   c1014     -1
    x[2852]   c1102     -1
    x[2852]   c1198     -1
    x[2852]   c1206     -1
    x[2853]   c67       1
    x[2853]   c1297     -1
    x[2853]   c1385     -1
    x[2853]   c1481     -1
    x[2853]   c1489     -1
    x[2854]   c67       1
    x[2854]   c1580     -1
    x[2854]   c1668     -1
    x[2854]   c1764     -1
    x[2854]   c1772     -1
    x[2855]   c67       1
    x[2855]   c1863     -1
    x[2855]   c1951     -1
    x[2855]   c2047     -1
    x[2855]   c2055     -1
    x[2856]   c67       1
    x[2856]   c2146     -1
    x[2856]   c2234     -1
    x[2856]   c2330     -1
    x[2856]   c2338     -1
    x[2857]   c67       1
    x[2857]   c2429     -1
    x[2857]   c2517     -1
    x[2857]   c2613     -1
    x[2857]   c2621     -1
    x[2858]   c67       1
    x[2858]   c2712     -1
    x[2858]   c2800     -1
    x[2858]   c2896     -1
    x[2858]   c2904     -1
    x[2859]   c67       1
    x[2859]   c2995     -1
    x[2859]   c3083     -1
    x[2859]   c3179     -1
    x[2859]   c3187     -1
    x[2860]   c67       1
    x[2860]   c3278     -1
    x[2860]   c3366     -1
    x[2860]   c3462     -1
    x[2860]   c3470     -1
    x[2861]   c67       1
    x[2861]   c3561     -1
    x[2861]   c3649     -1
    x[2861]   c3745     -1
    x[2861]   c3753     -1
    x[2862]   c67       1
    x[2862]   c3844     -1
    x[2862]   c3932     -1
    x[2862]   c4028     -1
    x[2862]   c4036     -1
    x[2863]   c67       1
    x[2863]   c4127     -1
    x[2863]   c4215     -1
    x[2863]   c4311     -1
    x[2863]   c4319     -1
    x[2864]   c67       1
    x[2864]   c4410     -1
    x[2864]   c4498     -1
    x[2864]   c4594     -1
    x[2864]   c4602     -1
    x[2865]   c68       1
    x[2865]   c112      -1
    x[2865]   c184      -1
    x[2865]   c263      -1
    x[2865]   c346      -1
    x[2866]   c68       1
    x[2866]   c395      -1
    x[2866]   c467      -1
    x[2866]   c546      -1
    x[2866]   c629      -1
    x[2867]   c68       1
    x[2867]   c678      -1
    x[2867]   c750      -1
    x[2867]   c829      -1
    x[2867]   c912      -1
    x[2868]   c68       1
    x[2868]   c961      -1
    x[2868]   c1033     -1
    x[2868]   c1112     -1
    x[2868]   c1195     -1
    x[2869]   c68       1
    x[2869]   c1244     -1
    x[2869]   c1316     -1
    x[2869]   c1395     -1
    x[2869]   c1478     -1
    x[2870]   c68       1
    x[2870]   c1527     -1
    x[2870]   c1599     -1
    x[2870]   c1678     -1
    x[2870]   c1761     -1
    x[2871]   c68       1
    x[2871]   c1810     -1
    x[2871]   c1882     -1
    x[2871]   c1961     -1
    x[2871]   c2044     -1
    x[2872]   c68       1
    x[2872]   c2093     -1
    x[2872]   c2165     -1
    x[2872]   c2244     -1
    x[2872]   c2327     -1
    x[2873]   c68       1
    x[2873]   c2376     -1
    x[2873]   c2448     -1
    x[2873]   c2527     -1
    x[2873]   c2610     -1
    x[2874]   c68       1
    x[2874]   c2659     -1
    x[2874]   c2731     -1
    x[2874]   c2810     -1
    x[2874]   c2893     -1
    x[2875]   c68       1
    x[2875]   c2942     -1
    x[2875]   c3014     -1
    x[2875]   c3093     -1
    x[2875]   c3176     -1
    x[2876]   c68       1
    x[2876]   c3225     -1
    x[2876]   c3297     -1
    x[2876]   c3376     -1
    x[2876]   c3459     -1
    x[2877]   c68       1
    x[2877]   c3508     -1
    x[2877]   c3580     -1
    x[2877]   c3659     -1
    x[2877]   c3742     -1
    x[2878]   c68       1
    x[2878]   c3791     -1
    x[2878]   c3863     -1
    x[2878]   c3942     -1
    x[2878]   c4025     -1
    x[2879]   c68       1
    x[2879]   c4074     -1
    x[2879]   c4146     -1
    x[2879]   c4225     -1
    x[2879]   c4308     -1
    x[2880]   c68       1
    x[2880]   c4357     -1
    x[2880]   c4429     -1
    x[2880]   c4508     -1
    x[2880]   c4591     -1
    x[2881]   c69       1
    x[2881]   c222      -1
    x[2881]   c266      -1
    x[2882]   c69       1
    x[2882]   c505      -1
    x[2882]   c549      -1
    x[2883]   c69       1
    x[2883]   c788      -1
    x[2883]   c832      -1
    x[2884]   c69       1
    x[2884]   c1071     -1
    x[2884]   c1115     -1
    x[2885]   c69       1
    x[2885]   c1354     -1
    x[2885]   c1398     -1
    x[2886]   c69       1
    x[2886]   c1637     -1
    x[2886]   c1681     -1
    x[2887]   c69       1
    x[2887]   c1920     -1
    x[2887]   c1964     -1
    x[2888]   c69       1
    x[2888]   c2203     -1
    x[2888]   c2247     -1
    x[2889]   c69       1
    x[2889]   c2486     -1
    x[2889]   c2530     -1
    x[2890]   c69       1
    x[2890]   c2769     -1
    x[2890]   c2813     -1
    x[2891]   c69       1
    x[2891]   c3052     -1
    x[2891]   c3096     -1
    x[2892]   c69       1
    x[2892]   c3335     -1
    x[2892]   c3379     -1
    x[2893]   c69       1
    x[2893]   c3618     -1
    x[2893]   c3662     -1
    x[2894]   c69       1
    x[2894]   c3901     -1
    x[2894]   c3945     -1
    x[2895]   c69       1
    x[2895]   c4184     -1
    x[2895]   c4228     -1
    x[2896]   c69       1
    x[2896]   c4467     -1
    x[2896]   c4511     -1
    x[2897]   c70       1
    x[2897]   c118      -1
    x[2897]   c199      -1
    x[2897]   c369      -1
    x[2898]   c70       1
    x[2898]   c401      -1
    x[2898]   c482      -1
    x[2898]   c652      -1
    x[2899]   c70       1
    x[2899]   c684      -1
    x[2899]   c765      -1
    x[2899]   c935      -1
    x[2900]   c70       1
    x[2900]   c967      -1
    x[2900]   c1048     -1
    x[2900]   c1218     -1
    x[2901]   c70       1
    x[2901]   c1250     -1
    x[2901]   c1331     -1
    x[2901]   c1501     -1
    x[2902]   c70       1
    x[2902]   c1533     -1
    x[2902]   c1614     -1
    x[2902]   c1784     -1
    x[2903]   c70       1
    x[2903]   c1816     -1
    x[2903]   c1897     -1
    x[2903]   c2067     -1
    x[2904]   c70       1
    x[2904]   c2099     -1
    x[2904]   c2180     -1
    x[2904]   c2350     -1
    x[2905]   c70       1
    x[2905]   c2382     -1
    x[2905]   c2463     -1
    x[2905]   c2633     -1
    x[2906]   c70       1
    x[2906]   c2665     -1
    x[2906]   c2746     -1
    x[2906]   c2916     -1
    x[2907]   c70       1
    x[2907]   c2948     -1
    x[2907]   c3029     -1
    x[2907]   c3199     -1
    x[2908]   c70       1
    x[2908]   c3231     -1
    x[2908]   c3312     -1
    x[2908]   c3482     -1
    x[2909]   c70       1
    x[2909]   c3514     -1
    x[2909]   c3595     -1
    x[2909]   c3765     -1
    x[2910]   c70       1
    x[2910]   c3797     -1
    x[2910]   c3878     -1
    x[2910]   c4048     -1
    x[2911]   c70       1
    x[2911]   c4080     -1
    x[2911]   c4161     -1
    x[2911]   c4331     -1
    x[2912]   c70       1
    x[2912]   c4363     -1
    x[2912]   c4444     -1
    x[2912]   c4614     -1
    x[2913]   c71       1
    x[2913]   c176      -1
    x[2913]   c192      -1
    x[2913]   c322      -1
    x[2913]   c358      -1
    x[2914]   c71       1
    x[2914]   c459      -1
    x[2914]   c475      -1
    x[2914]   c605      -1
    x[2914]   c641      -1
    x[2915]   c71       1
    x[2915]   c742      -1
    x[2915]   c758      -1
    x[2915]   c888      -1
    x[2915]   c924      -1
    x[2916]   c71       1
    x[2916]   c1025     -1
    x[2916]   c1041     -1
    x[2916]   c1171     -1
    x[2916]   c1207     -1
    x[2917]   c71       1
    x[2917]   c1308     -1
    x[2917]   c1324     -1
    x[2917]   c1454     -1
    x[2917]   c1490     -1
    x[2918]   c71       1
    x[2918]   c1591     -1
    x[2918]   c1607     -1
    x[2918]   c1737     -1
    x[2918]   c1773     -1
    x[2919]   c71       1
    x[2919]   c1874     -1
    x[2919]   c1890     -1
    x[2919]   c2020     -1
    x[2919]   c2056     -1
    x[2920]   c71       1
    x[2920]   c2157     -1
    x[2920]   c2173     -1
    x[2920]   c2303     -1
    x[2920]   c2339     -1
    x[2921]   c71       1
    x[2921]   c2440     -1
    x[2921]   c2456     -1
    x[2921]   c2586     -1
    x[2921]   c2622     -1
    x[2922]   c71       1
    x[2922]   c2723     -1
    x[2922]   c2739     -1
    x[2922]   c2869     -1
    x[2922]   c2905     -1
    x[2923]   c71       1
    x[2923]   c3006     -1
    x[2923]   c3022     -1
    x[2923]   c3152     -1
    x[2923]   c3188     -1
    x[2924]   c71       1
    x[2924]   c3289     -1
    x[2924]   c3305     -1
    x[2924]   c3435     -1
    x[2924]   c3471     -1
    x[2925]   c71       1
    x[2925]   c3572     -1
    x[2925]   c3588     -1
    x[2925]   c3718     -1
    x[2925]   c3754     -1
    x[2926]   c71       1
    x[2926]   c3855     -1
    x[2926]   c3871     -1
    x[2926]   c4001     -1
    x[2926]   c4037     -1
    x[2927]   c71       1
    x[2927]   c4138     -1
    x[2927]   c4154     -1
    x[2927]   c4284     -1
    x[2927]   c4320     -1
    x[2928]   c71       1
    x[2928]   c4421     -1
    x[2928]   c4437     -1
    x[2928]   c4567     -1
    x[2928]   c4603     -1
    x[2929]   c72       1
    x[2929]   c169      -1
    x[2929]   c277      -1
    x[2930]   c72       1
    x[2930]   c452      -1
    x[2930]   c560      -1
    x[2931]   c72       1
    x[2931]   c735      -1
    x[2931]   c843      -1
    x[2932]   c72       1
    x[2932]   c1018     -1
    x[2932]   c1126     -1
    x[2933]   c72       1
    x[2933]   c1301     -1
    x[2933]   c1409     -1
    x[2934]   c72       1
    x[2934]   c1584     -1
    x[2934]   c1692     -1
    x[2935]   c72       1
    x[2935]   c1867     -1
    x[2935]   c1975     -1
    x[2936]   c72       1
    x[2936]   c2150     -1
    x[2936]   c2258     -1
    x[2937]   c72       1
    x[2937]   c2433     -1
    x[2937]   c2541     -1
    x[2938]   c72       1
    x[2938]   c2716     -1
    x[2938]   c2824     -1
    x[2939]   c72       1
    x[2939]   c2999     -1
    x[2939]   c3107     -1
    x[2940]   c72       1
    x[2940]   c3282     -1
    x[2940]   c3390     -1
    x[2941]   c72       1
    x[2941]   c3565     -1
    x[2941]   c3673     -1
    x[2942]   c72       1
    x[2942]   c3848     -1
    x[2942]   c3956     -1
    x[2943]   c72       1
    x[2943]   c4131     -1
    x[2943]   c4239     -1
    x[2944]   c72       1
    x[2944]   c4414     -1
    x[2944]   c4522     -1
    x[2945]   c73       1
    x[2945]   c174      -1
    x[2945]   c223      -1
    x[2945]   c242      -1
    x[2945]   c324      -1
    x[2946]   c73       1
    x[2946]   c457      -1
    x[2946]   c506      -1
    x[2946]   c525      -1
    x[2946]   c607      -1
    x[2947]   c73       1
    x[2947]   c740      -1
    x[2947]   c789      -1
    x[2947]   c808      -1
    x[2947]   c890      -1
    x[2948]   c73       1
    x[2948]   c1023     -1
    x[2948]   c1072     -1
    x[2948]   c1091     -1
    x[2948]   c1173     -1
    x[2949]   c73       1
    x[2949]   c1306     -1
    x[2949]   c1355     -1
    x[2949]   c1374     -1
    x[2949]   c1456     -1
    x[2950]   c73       1
    x[2950]   c1589     -1
    x[2950]   c1638     -1
    x[2950]   c1657     -1
    x[2950]   c1739     -1
    x[2951]   c73       1
    x[2951]   c1872     -1
    x[2951]   c1921     -1
    x[2951]   c1940     -1
    x[2951]   c2022     -1
    x[2952]   c73       1
    x[2952]   c2155     -1
    x[2952]   c2204     -1
    x[2952]   c2223     -1
    x[2952]   c2305     -1
    x[2953]   c73       1
    x[2953]   c2438     -1
    x[2953]   c2487     -1
    x[2953]   c2506     -1
    x[2953]   c2588     -1
    x[2954]   c73       1
    x[2954]   c2721     -1
    x[2954]   c2770     -1
    x[2954]   c2789     -1
    x[2954]   c2871     -1
    x[2955]   c73       1
    x[2955]   c3004     -1
    x[2955]   c3053     -1
    x[2955]   c3072     -1
    x[2955]   c3154     -1
    x[2956]   c73       1
    x[2956]   c3287     -1
    x[2956]   c3336     -1
    x[2956]   c3355     -1
    x[2956]   c3437     -1
    x[2957]   c73       1
    x[2957]   c3570     -1
    x[2957]   c3619     -1
    x[2957]   c3638     -1
    x[2957]   c3720     -1
    x[2958]   c73       1
    x[2958]   c3853     -1
    x[2958]   c3902     -1
    x[2958]   c3921     -1
    x[2958]   c4003     -1
    x[2959]   c73       1
    x[2959]   c4136     -1
    x[2959]   c4185     -1
    x[2959]   c4204     -1
    x[2959]   c4286     -1
    x[2960]   c73       1
    x[2960]   c4419     -1
    x[2960]   c4468     -1
    x[2960]   c4487     -1
    x[2960]   c4569     -1
    x[2961]   c74       1
    x[2961]   c254      -1
    x[2961]   c374      -1
    x[2962]   c74       1
    x[2962]   c537      -1
    x[2962]   c657      -1
    x[2963]   c74       1
    x[2963]   c820      -1
    x[2963]   c940      -1
    x[2964]   c74       1
    x[2964]   c1103     -1
    x[2964]   c1223     -1
    x[2965]   c74       1
    x[2965]   c1386     -1
    x[2965]   c1506     -1
    x[2966]   c74       1
    x[2966]   c1669     -1
    x[2966]   c1789     -1
    x[2967]   c74       1
    x[2967]   c1952     -1
    x[2967]   c2072     -1
    x[2968]   c74       1
    x[2968]   c2235     -1
    x[2968]   c2355     -1
    x[2969]   c74       1
    x[2969]   c2518     -1
    x[2969]   c2638     -1
    x[2970]   c74       1
    x[2970]   c2801     -1
    x[2970]   c2921     -1
    x[2971]   c74       1
    x[2971]   c3084     -1
    x[2971]   c3204     -1
    x[2972]   c74       1
    x[2972]   c3367     -1
    x[2972]   c3487     -1
    x[2973]   c74       1
    x[2973]   c3650     -1
    x[2973]   c3770     -1
    x[2974]   c74       1
    x[2974]   c3933     -1
    x[2974]   c4053     -1
    x[2975]   c74       1
    x[2975]   c4216     -1
    x[2975]   c4336     -1
    x[2976]   c74       1
    x[2976]   c4499     -1
    x[2976]   c4619     -1
    x[2977]   c75       1
    x[2977]   c108      -1
    x[2977]   c259      -1
    x[2977]   c291      -1
    x[2978]   c75       1
    x[2978]   c391      -1
    x[2978]   c542      -1
    x[2978]   c574      -1
    x[2979]   c75       1
    x[2979]   c674      -1
    x[2979]   c825      -1
    x[2979]   c857      -1
    x[2980]   c75       1
    x[2980]   c957      -1
    x[2980]   c1108     -1
    x[2980]   c1140     -1
    x[2981]   c75       1
    x[2981]   c1240     -1
    x[2981]   c1391     -1
    x[2981]   c1423     -1
    x[2982]   c75       1
    x[2982]   c1523     -1
    x[2982]   c1674     -1
    x[2982]   c1706     -1
    x[2983]   c75       1
    x[2983]   c1806     -1
    x[2983]   c1957     -1
    x[2983]   c1989     -1
    x[2984]   c75       1
    x[2984]   c2089     -1
    x[2984]   c2240     -1
    x[2984]   c2272     -1
    x[2985]   c75       1
    x[2985]   c2372     -1
    x[2985]   c2523     -1
    x[2985]   c2555     -1
    x[2986]   c75       1
    x[2986]   c2655     -1
    x[2986]   c2806     -1
    x[2986]   c2838     -1
    x[2987]   c75       1
    x[2987]   c2938     -1
    x[2987]   c3089     -1
    x[2987]   c3121     -1
    x[2988]   c75       1
    x[2988]   c3221     -1
    x[2988]   c3372     -1
    x[2988]   c3404     -1
    x[2989]   c75       1
    x[2989]   c3504     -1
    x[2989]   c3655     -1
    x[2989]   c3687     -1
    x[2990]   c75       1
    x[2990]   c3787     -1
    x[2990]   c3938     -1
    x[2990]   c3970     -1
    x[2991]   c75       1
    x[2991]   c4070     -1
    x[2991]   c4221     -1
    x[2991]   c4253     -1
    x[2992]   c75       1
    x[2992]   c4353     -1
    x[2992]   c4504     -1
    x[2992]   c4536     -1
    x[2993]   c76       1
    x[2993]   c119      -1
    x[2993]   c149      -1
    x[2993]   c200      -1
    x[2993]   c260      -1
    x[2994]   c76       1
    x[2994]   c402      -1
    x[2994]   c432      -1
    x[2994]   c483      -1
    x[2994]   c543      -1
    x[2995]   c76       1
    x[2995]   c685      -1
    x[2995]   c715      -1
    x[2995]   c766      -1
    x[2995]   c826      -1
    x[2996]   c76       1
    x[2996]   c968      -1
    x[2996]   c998      -1
    x[2996]   c1049     -1
    x[2996]   c1109     -1
    x[2997]   c76       1
    x[2997]   c1251     -1
    x[2997]   c1281     -1
    x[2997]   c1332     -1
    x[2997]   c1392     -1
    x[2998]   c76       1
    x[2998]   c1534     -1
    x[2998]   c1564     -1
    x[2998]   c1615     -1
    x[2998]   c1675     -1
    x[2999]   c76       1
    x[2999]   c1817     -1
    x[2999]   c1847     -1
    x[2999]   c1898     -1
    x[2999]   c1958     -1
    x[3000]   c76       1
    x[3000]   c2100     -1
    x[3000]   c2130     -1
    x[3000]   c2181     -1
    x[3000]   c2241     -1
    x[3001]   c76       1
    x[3001]   c2383     -1
    x[3001]   c2413     -1
    x[3001]   c2464     -1
    x[3001]   c2524     -1
    x[3002]   c76       1
    x[3002]   c2666     -1
    x[3002]   c2696     -1
    x[3002]   c2747     -1
    x[3002]   c2807     -1
    x[3003]   c76       1
    x[3003]   c2949     -1
    x[3003]   c2979     -1
    x[3003]   c3030     -1
    x[3003]   c3090     -1
    x[3004]   c76       1
    x[3004]   c3232     -1
    x[3004]   c3262     -1
    x[3004]   c3313     -1
    x[3004]   c3373     -1
    x[3005]   c76       1
    x[3005]   c3515     -1
    x[3005]   c3545     -1
    x[3005]   c3596     -1
    x[3005]   c3656     -1
    x[3006]   c76       1
    x[3006]   c3798     -1
    x[3006]   c3828     -1
    x[3006]   c3879     -1
    x[3006]   c3939     -1
    x[3007]   c76       1
    x[3007]   c4081     -1
    x[3007]   c4111     -1
    x[3007]   c4162     -1
    x[3007]   c4222     -1
    x[3008]   c76       1
    x[3008]   c4364     -1
    x[3008]   c4394     -1
    x[3008]   c4445     -1
    x[3008]   c4505     -1
    x[3009]   c77       1
    x[3009]   c141      -1
    x[3009]   c211      -1
    x[3009]   c386      -1
    x[3010]   c77       1
    x[3010]   c424      -1
    x[3010]   c494      -1
    x[3010]   c669      -1
    x[3011]   c77       1
    x[3011]   c707      -1
    x[3011]   c777      -1
    x[3011]   c952      -1
    x[3012]   c77       1
    x[3012]   c990      -1
    x[3012]   c1060     -1
    x[3012]   c1235     -1
    x[3013]   c77       1
    x[3013]   c1273     -1
    x[3013]   c1343     -1
    x[3013]   c1518     -1
    x[3014]   c77       1
    x[3014]   c1556     -1
    x[3014]   c1626     -1
    x[3014]   c1801     -1
    x[3015]   c77       1
    x[3015]   c1839     -1
    x[3015]   c1909     -1
    x[3015]   c2084     -1
    x[3016]   c77       1
    x[3016]   c2122     -1
    x[3016]   c2192     -1
    x[3016]   c2367     -1
    x[3017]   c77       1
    x[3017]   c2405     -1
    x[3017]   c2475     -1
    x[3017]   c2650     -1
    x[3018]   c77       1
    x[3018]   c2688     -1
    x[3018]   c2758     -1
    x[3018]   c2933     -1
    x[3019]   c77       1
    x[3019]   c2971     -1
    x[3019]   c3041     -1
    x[3019]   c3216     -1
    x[3020]   c77       1
    x[3020]   c3254     -1
    x[3020]   c3324     -1
    x[3020]   c3499     -1
    x[3021]   c77       1
    x[3021]   c3537     -1
    x[3021]   c3607     -1
    x[3021]   c3782     -1
    x[3022]   c77       1
    x[3022]   c3820     -1
    x[3022]   c3890     -1
    x[3022]   c4065     -1
    x[3023]   c77       1
    x[3023]   c4103     -1
    x[3023]   c4173     -1
    x[3023]   c4348     -1
    x[3024]   c77       1
    x[3024]   c4386     -1
    x[3024]   c4456     -1
    x[3024]   c4631     -1
    x[3025]   c78       1
    x[3025]   c283      -1
    x[3025]   c288      -1
    x[3025]   c320      -1
    x[3025]   c332      -1
    x[3026]   c78       1
    x[3026]   c566      -1
    x[3026]   c571      -1
    x[3026]   c603      -1
    x[3026]   c615      -1
    x[3027]   c78       1
    x[3027]   c849      -1
    x[3027]   c854      -1
    x[3027]   c886      -1
    x[3027]   c898      -1
    x[3028]   c78       1
    x[3028]   c1132     -1
    x[3028]   c1137     -1
    x[3028]   c1169     -1
    x[3028]   c1181     -1
    x[3029]   c78       1
    x[3029]   c1415     -1
    x[3029]   c1420     -1
    x[3029]   c1452     -1
    x[3029]   c1464     -1
    x[3030]   c78       1
    x[3030]   c1698     -1
    x[3030]   c1703     -1
    x[3030]   c1735     -1
    x[3030]   c1747     -1
    x[3031]   c78       1
    x[3031]   c1981     -1
    x[3031]   c1986     -1
    x[3031]   c2018     -1
    x[3031]   c2030     -1
    x[3032]   c78       1
    x[3032]   c2264     -1
    x[3032]   c2269     -1
    x[3032]   c2301     -1
    x[3032]   c2313     -1
    x[3033]   c78       1
    x[3033]   c2547     -1
    x[3033]   c2552     -1
    x[3033]   c2584     -1
    x[3033]   c2596     -1
    x[3034]   c78       1
    x[3034]   c2830     -1
    x[3034]   c2835     -1
    x[3034]   c2867     -1
    x[3034]   c2879     -1
    x[3035]   c78       1
    x[3035]   c3113     -1
    x[3035]   c3118     -1
    x[3035]   c3150     -1
    x[3035]   c3162     -1
    x[3036]   c78       1
    x[3036]   c3396     -1
    x[3036]   c3401     -1
    x[3036]   c3433     -1
    x[3036]   c3445     -1
    x[3037]   c78       1
    x[3037]   c3679     -1
    x[3037]   c3684     -1
    x[3037]   c3716     -1
    x[3037]   c3728     -1
    x[3038]   c78       1
    x[3038]   c3962     -1
    x[3038]   c3967     -1
    x[3038]   c3999     -1
    x[3038]   c4011     -1
    x[3039]   c78       1
    x[3039]   c4245     -1
    x[3039]   c4250     -1
    x[3039]   c4282     -1
    x[3039]   c4294     -1
    x[3040]   c78       1
    x[3040]   c4528     -1
    x[3040]   c4533     -1
    x[3040]   c4565     -1
    x[3040]   c4577     -1
    x[3041]   c79       1
    x[3041]   c134      -1
    x[3041]   c135      -1
    x[3041]   c193      -1
    x[3041]   c233      -1
    x[3042]   c79       1
    x[3042]   c417      -1
    x[3042]   c418      -1
    x[3042]   c476      -1
    x[3042]   c516      -1
    x[3043]   c79       1
    x[3043]   c700      -1
    x[3043]   c701      -1
    x[3043]   c759      -1
    x[3043]   c799      -1
    x[3044]   c79       1
    x[3044]   c983      -1
    x[3044]   c984      -1
    x[3044]   c1042     -1
    x[3044]   c1082     -1
    x[3045]   c79       1
    x[3045]   c1266     -1
    x[3045]   c1267     -1
    x[3045]   c1325     -1
    x[3045]   c1365     -1
    x[3046]   c79       1
    x[3046]   c1549     -1
    x[3046]   c1550     -1
    x[3046]   c1608     -1
    x[3046]   c1648     -1
    x[3047]   c79       1
    x[3047]   c1832     -1
    x[3047]   c1833     -1
    x[3047]   c1891     -1
    x[3047]   c1931     -1
    x[3048]   c79       1
    x[3048]   c2115     -1
    x[3048]   c2116     -1
    x[3048]   c2174     -1
    x[3048]   c2214     -1
    x[3049]   c79       1
    x[3049]   c2398     -1
    x[3049]   c2399     -1
    x[3049]   c2457     -1
    x[3049]   c2497     -1
    x[3050]   c79       1
    x[3050]   c2681     -1
    x[3050]   c2682     -1
    x[3050]   c2740     -1
    x[3050]   c2780     -1
    x[3051]   c79       1
    x[3051]   c2964     -1
    x[3051]   c2965     -1
    x[3051]   c3023     -1
    x[3051]   c3063     -1
    x[3052]   c79       1
    x[3052]   c3247     -1
    x[3052]   c3248     -1
    x[3052]   c3306     -1
    x[3052]   c3346     -1
    x[3053]   c79       1
    x[3053]   c3530     -1
    x[3053]   c3531     -1
    x[3053]   c3589     -1
    x[3053]   c3629     -1
    x[3054]   c79       1
    x[3054]   c3813     -1
    x[3054]   c3814     -1
    x[3054]   c3872     -1
    x[3054]   c3912     -1
    x[3055]   c79       1
    x[3055]   c4096     -1
    x[3055]   c4097     -1
    x[3055]   c4155     -1
    x[3055]   c4195     -1
    x[3056]   c79       1
    x[3056]   c4379     -1
    x[3056]   c4380     -1
    x[3056]   c4438     -1
    x[3056]   c4478     -1
    x[3057]   c80       1
    x[3057]   c187      -1
    x[3057]   c213      -1
    x[3057]   c271      -1
    x[3057]   c274      -1
    x[3058]   c80       1
    x[3058]   c470      -1
    x[3058]   c496      -1
    x[3058]   c554      -1
    x[3058]   c557      -1
    x[3059]   c80       1
    x[3059]   c753      -1
    x[3059]   c779      -1
    x[3059]   c837      -1
    x[3059]   c840      -1
    x[3060]   c80       1
    x[3060]   c1036     -1
    x[3060]   c1062     -1
    x[3060]   c1120     -1
    x[3060]   c1123     -1
    x[3061]   c80       1
    x[3061]   c1319     -1
    x[3061]   c1345     -1
    x[3061]   c1403     -1
    x[3061]   c1406     -1
    x[3062]   c80       1
    x[3062]   c1602     -1
    x[3062]   c1628     -1
    x[3062]   c1686     -1
    x[3062]   c1689     -1
    x[3063]   c80       1
    x[3063]   c1885     -1
    x[3063]   c1911     -1
    x[3063]   c1969     -1
    x[3063]   c1972     -1
    x[3064]   c80       1
    x[3064]   c2168     -1
    x[3064]   c2194     -1
    x[3064]   c2252     -1
    x[3064]   c2255     -1
    x[3065]   c80       1
    x[3065]   c2451     -1
    x[3065]   c2477     -1
    x[3065]   c2535     -1
    x[3065]   c2538     -1
    x[3066]   c80       1
    x[3066]   c2734     -1
    x[3066]   c2760     -1
    x[3066]   c2818     -1
    x[3066]   c2821     -1
    x[3067]   c80       1
    x[3067]   c3017     -1
    x[3067]   c3043     -1
    x[3067]   c3101     -1
    x[3067]   c3104     -1
    x[3068]   c80       1
    x[3068]   c3300     -1
    x[3068]   c3326     -1
    x[3068]   c3384     -1
    x[3068]   c3387     -1
    x[3069]   c80       1
    x[3069]   c3583     -1
    x[3069]   c3609     -1
    x[3069]   c3667     -1
    x[3069]   c3670     -1
    x[3070]   c80       1
    x[3070]   c3866     -1
    x[3070]   c3892     -1
    x[3070]   c3950     -1
    x[3070]   c3953     -1
    x[3071]   c80       1
    x[3071]   c4149     -1
    x[3071]   c4175     -1
    x[3071]   c4233     -1
    x[3071]   c4236     -1
    x[3072]   c80       1
    x[3072]   c4432     -1
    x[3072]   c4458     -1
    x[3072]   c4516     -1
    x[3072]   c4519     -1
    x[3073]   c81       1
    x[3073]   c189      -1
    x[3073]   c312      -1
    x[3074]   c81       1
    x[3074]   c472      -1
    x[3074]   c595      -1
    x[3075]   c81       1
    x[3075]   c755      -1
    x[3075]   c878      -1
    x[3076]   c81       1
    x[3076]   c1038     -1
    x[3076]   c1161     -1
    x[3077]   c81       1
    x[3077]   c1321     -1
    x[3077]   c1444     -1
    x[3078]   c81       1
    x[3078]   c1604     -1
    x[3078]   c1727     -1
    x[3079]   c81       1
    x[3079]   c1887     -1
    x[3079]   c2010     -1
    x[3080]   c81       1
    x[3080]   c2170     -1
    x[3080]   c2293     -1
    x[3081]   c81       1
    x[3081]   c2453     -1
    x[3081]   c2576     -1
    x[3082]   c81       1
    x[3082]   c2736     -1
    x[3082]   c2859     -1
    x[3083]   c81       1
    x[3083]   c3019     -1
    x[3083]   c3142     -1
    x[3084]   c81       1
    x[3084]   c3302     -1
    x[3084]   c3425     -1
    x[3085]   c81       1
    x[3085]   c3585     -1
    x[3085]   c3708     -1
    x[3086]   c81       1
    x[3086]   c3868     -1
    x[3086]   c3991     -1
    x[3087]   c81       1
    x[3087]   c4151     -1
    x[3087]   c4274     -1
    x[3088]   c81       1
    x[3088]   c4434     -1
    x[3088]   c4557     -1
    x[3089]   c82       1
    x[3089]   c123      -1
    x[3089]   c202      -1
    x[3089]   c335      -1
    x[3090]   c82       1
    x[3090]   c406      -1
    x[3090]   c485      -1
    x[3090]   c618      -1
    x[3091]   c82       1
    x[3091]   c689      -1
    x[3091]   c768      -1
    x[3091]   c901      -1
    x[3092]   c82       1
    x[3092]   c972      -1
    x[3092]   c1051     -1
    x[3092]   c1184     -1
    x[3093]   c82       1
    x[3093]   c1255     -1
    x[3093]   c1334     -1
    x[3093]   c1467     -1
    x[3094]   c82       1
    x[3094]   c1538     -1
    x[3094]   c1617     -1
    x[3094]   c1750     -1
    x[3095]   c82       1
    x[3095]   c1821     -1
    x[3095]   c1900     -1
    x[3095]   c2033     -1
    x[3096]   c82       1
    x[3096]   c2104     -1
    x[3096]   c2183     -1
    x[3096]   c2316     -1
    x[3097]   c82       1
    x[3097]   c2387     -1
    x[3097]   c2466     -1
    x[3097]   c2599     -1
    x[3098]   c82       1
    x[3098]   c2670     -1
    x[3098]   c2749     -1
    x[3098]   c2882     -1
    x[3099]   c82       1
    x[3099]   c2953     -1
    x[3099]   c3032     -1
    x[3099]   c3165     -1
    x[3100]   c82       1
    x[3100]   c3236     -1
    x[3100]   c3315     -1
    x[3100]   c3448     -1
    x[3101]   c82       1
    x[3101]   c3519     -1
    x[3101]   c3598     -1
    x[3101]   c3731     -1
    x[3102]   c82       1
    x[3102]   c3802     -1
    x[3102]   c3881     -1
    x[3102]   c4014     -1
    x[3103]   c82       1
    x[3103]   c4085     -1
    x[3103]   c4164     -1
    x[3103]   c4297     -1
    x[3104]   c82       1
    x[3104]   c4368     -1
    x[3104]   c4447     -1
    x[3104]   c4580     -1
    x[3105]   c83       1
    x[3105]   c114      -1
    x[3105]   c142      -1
    x[3105]   c201      -1
    x[3105]   c378      -1
    x[3106]   c83       1
    x[3106]   c397      -1
    x[3106]   c425      -1
    x[3106]   c484      -1
    x[3106]   c661      -1
    x[3107]   c83       1
    x[3107]   c680      -1
    x[3107]   c708      -1
    x[3107]   c767      -1
    x[3107]   c944      -1
    x[3108]   c83       1
    x[3108]   c963      -1
    x[3108]   c991      -1
    x[3108]   c1050     -1
    x[3108]   c1227     -1
    x[3109]   c83       1
    x[3109]   c1246     -1
    x[3109]   c1274     -1
    x[3109]   c1333     -1
    x[3109]   c1510     -1
    x[3110]   c83       1
    x[3110]   c1529     -1
    x[3110]   c1557     -1
    x[3110]   c1616     -1
    x[3110]   c1793     -1
    x[3111]   c83       1
    x[3111]   c1812     -1
    x[3111]   c1840     -1
    x[3111]   c1899     -1
    x[3111]   c2076     -1
    x[3112]   c83       1
    x[3112]   c2095     -1
    x[3112]   c2123     -1
    x[3112]   c2182     -1
    x[3112]   c2359     -1
    x[3113]   c83       1
    x[3113]   c2378     -1
    x[3113]   c2406     -1
    x[3113]   c2465     -1
    x[3113]   c2642     -1
    x[3114]   c83       1
    x[3114]   c2661     -1
    x[3114]   c2689     -1
    x[3114]   c2748     -1
    x[3114]   c2925     -1
    x[3115]   c83       1
    x[3115]   c2944     -1
    x[3115]   c2972     -1
    x[3115]   c3031     -1
    x[3115]   c3208     -1
    x[3116]   c83       1
    x[3116]   c3227     -1
    x[3116]   c3255     -1
    x[3116]   c3314     -1
    x[3116]   c3491     -1
    x[3117]   c83       1
    x[3117]   c3510     -1
    x[3117]   c3538     -1
    x[3117]   c3597     -1
    x[3117]   c3774     -1
    x[3118]   c83       1
    x[3118]   c3793     -1
    x[3118]   c3821     -1
    x[3118]   c3880     -1
    x[3118]   c4057     -1
    x[3119]   c83       1
    x[3119]   c4076     -1
    x[3119]   c4104     -1
    x[3119]   c4163     -1
    x[3119]   c4340     -1
    x[3120]   c83       1
    x[3120]   c4359     -1
    x[3120]   c4387     -1
    x[3120]   c4446     -1
    x[3120]   c4623     -1
    x[3121]   c84       1
    x[3121]   c124      -1
    x[3121]   c160      -1
    x[3121]   c292      -1
    x[3122]   c84       1
    x[3122]   c407      -1
    x[3122]   c443      -1
    x[3122]   c575      -1
    x[3123]   c84       1
    x[3123]   c690      -1
    x[3123]   c726      -1
    x[3123]   c858      -1
    x[3124]   c84       1
    x[3124]   c973      -1
    x[3124]   c1009     -1
    x[3124]   c1141     -1
    x[3125]   c84       1
    x[3125]   c1256     -1
    x[3125]   c1292     -1
    x[3125]   c1424     -1
    x[3126]   c84       1
    x[3126]   c1539     -1
    x[3126]   c1575     -1
    x[3126]   c1707     -1
    x[3127]   c84       1
    x[3127]   c1822     -1
    x[3127]   c1858     -1
    x[3127]   c1990     -1
    x[3128]   c84       1
    x[3128]   c2105     -1
    x[3128]   c2141     -1
    x[3128]   c2273     -1
    x[3129]   c84       1
    x[3129]   c2388     -1
    x[3129]   c2424     -1
    x[3129]   c2556     -1
    x[3130]   c84       1
    x[3130]   c2671     -1
    x[3130]   c2707     -1
    x[3130]   c2839     -1
    x[3131]   c84       1
    x[3131]   c2954     -1
    x[3131]   c2990     -1
    x[3131]   c3122     -1
    x[3132]   c84       1
    x[3132]   c3237     -1
    x[3132]   c3273     -1
    x[3132]   c3405     -1
    x[3133]   c84       1
    x[3133]   c3520     -1
    x[3133]   c3556     -1
    x[3133]   c3688     -1
    x[3134]   c84       1
    x[3134]   c3803     -1
    x[3134]   c3839     -1
    x[3134]   c3971     -1
    x[3135]   c84       1
    x[3135]   c4086     -1
    x[3135]   c4122     -1
    x[3135]   c4254     -1
    x[3136]   c84       1
    x[3136]   c4369     -1
    x[3136]   c4405     -1
    x[3136]   c4537     -1
    x[3137]   c85       1
    x[3137]   c316      -1
    x[3137]   c350      -1
    x[3137]   c359      -1
    x[3137]   c379      -1
    x[3138]   c85       1
    x[3138]   c599      -1
    x[3138]   c633      -1
    x[3138]   c642      -1
    x[3138]   c662      -1
    x[3139]   c85       1
    x[3139]   c882      -1
    x[3139]   c916      -1
    x[3139]   c925      -1
    x[3139]   c945      -1
    x[3140]   c85       1
    x[3140]   c1165     -1
    x[3140]   c1199     -1
    x[3140]   c1208     -1
    x[3140]   c1228     -1
    x[3141]   c85       1
    x[3141]   c1448     -1
    x[3141]   c1482     -1
    x[3141]   c1491     -1
    x[3141]   c1511     -1
    x[3142]   c85       1
    x[3142]   c1731     -1
    x[3142]   c1765     -1
    x[3142]   c1774     -1
    x[3142]   c1794     -1
    x[3143]   c85       1
    x[3143]   c2014     -1
    x[3143]   c2048     -1
    x[3143]   c2057     -1
    x[3143]   c2077     -1
    x[3144]   c85       1
    x[3144]   c2297     -1
    x[3144]   c2331     -1
    x[3144]   c2340     -1
    x[3144]   c2360     -1
    x[3145]   c85       1
    x[3145]   c2580     -1
    x[3145]   c2614     -1
    x[3145]   c2623     -1
    x[3145]   c2643     -1
    x[3146]   c85       1
    x[3146]   c2863     -1
    x[3146]   c2897     -1
    x[3146]   c2906     -1
    x[3146]   c2926     -1
    x[3147]   c85       1
    x[3147]   c3146     -1
    x[3147]   c3180     -1
    x[3147]   c3189     -1
    x[3147]   c3209     -1
    x[3148]   c85       1
    x[3148]   c3429     -1
    x[3148]   c3463     -1
    x[3148]   c3472     -1
    x[3148]   c3492     -1
    x[3149]   c85       1
    x[3149]   c3712     -1
    x[3149]   c3746     -1
    x[3149]   c3755     -1
    x[3149]   c3775     -1
    x[3150]   c85       1
    x[3150]   c3995     -1
    x[3150]   c4029     -1
    x[3150]   c4038     -1
    x[3150]   c4058     -1
    x[3151]   c85       1
    x[3151]   c4278     -1
    x[3151]   c4312     -1
    x[3151]   c4321     -1
    x[3151]   c4341     -1
    x[3152]   c85       1
    x[3152]   c4561     -1
    x[3152]   c4595     -1
    x[3152]   c4604     -1
    x[3152]   c4624     -1
    x[3153]   c86       1
    x[3153]   c143      -1
    x[3153]   c170      -1
    x[3153]   c204      -1
    x[3153]   c255      -1
    x[3154]   c86       1
    x[3154]   c426      -1
    x[3154]   c453      -1
    x[3154]   c487      -1
    x[3154]   c538      -1
    x[3155]   c86       1
    x[3155]   c709      -1
    x[3155]   c736      -1
    x[3155]   c770      -1
    x[3155]   c821      -1
    x[3156]   c86       1
    x[3156]   c992      -1
    x[3156]   c1019     -1
    x[3156]   c1053     -1
    x[3156]   c1104     -1
    x[3157]   c86       1
    x[3157]   c1275     -1
    x[3157]   c1302     -1
    x[3157]   c1336     -1
    x[3157]   c1387     -1
    x[3158]   c86       1
    x[3158]   c1558     -1
    x[3158]   c1585     -1
    x[3158]   c1619     -1
    x[3158]   c1670     -1
    x[3159]   c86       1
    x[3159]   c1841     -1
    x[3159]   c1868     -1
    x[3159]   c1902     -1
    x[3159]   c1953     -1
    x[3160]   c86       1
    x[3160]   c2124     -1
    x[3160]   c2151     -1
    x[3160]   c2185     -1
    x[3160]   c2236     -1
    x[3161]   c86       1
    x[3161]   c2407     -1
    x[3161]   c2434     -1
    x[3161]   c2468     -1
    x[3161]   c2519     -1
    x[3162]   c86       1
    x[3162]   c2690     -1
    x[3162]   c2717     -1
    x[3162]   c2751     -1
    x[3162]   c2802     -1
    x[3163]   c86       1
    x[3163]   c2973     -1
    x[3163]   c3000     -1
    x[3163]   c3034     -1
    x[3163]   c3085     -1
    x[3164]   c86       1
    x[3164]   c3256     -1
    x[3164]   c3283     -1
    x[3164]   c3317     -1
    x[3164]   c3368     -1
    x[3165]   c86       1
    x[3165]   c3539     -1
    x[3165]   c3566     -1
    x[3165]   c3600     -1
    x[3165]   c3651     -1
    x[3166]   c86       1
    x[3166]   c3822     -1
    x[3166]   c3849     -1
    x[3166]   c3883     -1
    x[3166]   c3934     -1
    x[3167]   c86       1
    x[3167]   c4105     -1
    x[3167]   c4132     -1
    x[3167]   c4166     -1
    x[3167]   c4217     -1
    x[3168]   c86       1
    x[3168]   c4388     -1
    x[3168]   c4415     -1
    x[3168]   c4449     -1
    x[3168]   c4500     -1
    x[3169]   c87       1
    x[3169]   c110      -1
    x[3169]   c303      -1
    x[3170]   c87       1
    x[3170]   c393      -1
    x[3170]   c586      -1
    x[3171]   c87       1
    x[3171]   c676      -1
    x[3171]   c869      -1
    x[3172]   c87       1
    x[3172]   c959      -1
    x[3172]   c1152     -1
    x[3173]   c87       1
    x[3173]   c1242     -1
    x[3173]   c1435     -1
    x[3174]   c87       1
    x[3174]   c1525     -1
    x[3174]   c1718     -1
    x[3175]   c87       1
    x[3175]   c1808     -1
    x[3175]   c2001     -1
    x[3176]   c87       1
    x[3176]   c2091     -1
    x[3176]   c2284     -1
    x[3177]   c87       1
    x[3177]   c2374     -1
    x[3177]   c2567     -1
    x[3178]   c87       1
    x[3178]   c2657     -1
    x[3178]   c2850     -1
    x[3179]   c87       1
    x[3179]   c2940     -1
    x[3179]   c3133     -1
    x[3180]   c87       1
    x[3180]   c3223     -1
    x[3180]   c3416     -1
    x[3181]   c87       1
    x[3181]   c3506     -1
    x[3181]   c3699     -1
    x[3182]   c87       1
    x[3182]   c3789     -1
    x[3182]   c3982     -1
    x[3183]   c87       1
    x[3183]   c4072     -1
    x[3183]   c4265     -1
    x[3184]   c87       1
    x[3184]   c4355     -1
    x[3184]   c4548     -1
    x[3185]   c88       1
    x[3185]   c117      -1
    x[3185]   c166      -1
    x[3185]   c256      -1
    x[3185]   c314      -1
    x[3186]   c88       1
    x[3186]   c400      -1
    x[3186]   c449      -1
    x[3186]   c539      -1
    x[3186]   c597      -1
    x[3187]   c88       1
    x[3187]   c683      -1
    x[3187]   c732      -1
    x[3187]   c822      -1
    x[3187]   c880      -1
    x[3188]   c88       1
    x[3188]   c966      -1
    x[3188]   c1015     -1
    x[3188]   c1105     -1
    x[3188]   c1163     -1
    x[3189]   c88       1
    x[3189]   c1249     -1
    x[3189]   c1298     -1
    x[3189]   c1388     -1
    x[3189]   c1446     -1
    x[3190]   c88       1
    x[3190]   c1532     -1
    x[3190]   c1581     -1
    x[3190]   c1671     -1
    x[3190]   c1729     -1
    x[3191]   c88       1
    x[3191]   c1815     -1
    x[3191]   c1864     -1
    x[3191]   c1954     -1
    x[3191]   c2012     -1
    x[3192]   c88       1
    x[3192]   c2098     -1
    x[3192]   c2147     -1
    x[3192]   c2237     -1
    x[3192]   c2295     -1
    x[3193]   c88       1
    x[3193]   c2381     -1
    x[3193]   c2430     -1
    x[3193]   c2520     -1
    x[3193]   c2578     -1
    x[3194]   c88       1
    x[3194]   c2664     -1
    x[3194]   c2713     -1
    x[3194]   c2803     -1
    x[3194]   c2861     -1
    x[3195]   c88       1
    x[3195]   c2947     -1
    x[3195]   c2996     -1
    x[3195]   c3086     -1
    x[3195]   c3144     -1
    x[3196]   c88       1
    x[3196]   c3230     -1
    x[3196]   c3279     -1
    x[3196]   c3369     -1
    x[3196]   c3427     -1
    x[3197]   c88       1
    x[3197]   c3513     -1
    x[3197]   c3562     -1
    x[3197]   c3652     -1
    x[3197]   c3710     -1
    x[3198]   c88       1
    x[3198]   c3796     -1
    x[3198]   c3845     -1
    x[3198]   c3935     -1
    x[3198]   c3993     -1
    x[3199]   c88       1
    x[3199]   c4079     -1
    x[3199]   c4128     -1
    x[3199]   c4218     -1
    x[3199]   c4276     -1
    x[3200]   c88       1
    x[3200]   c4362     -1
    x[3200]   c4411     -1
    x[3200]   c4501     -1
    x[3200]   c4559     -1
    x[3201]   c89       1
    x[3201]   c156      -1
    x[3201]   c372      -1
    x[3202]   c89       1
    x[3202]   c439      -1
    x[3202]   c655      -1
    x[3203]   c89       1
    x[3203]   c722      -1
    x[3203]   c938      -1
    x[3204]   c89       1
    x[3204]   c1005     -1
    x[3204]   c1221     -1
    x[3205]   c89       1
    x[3205]   c1288     -1
    x[3205]   c1504     -1
    x[3206]   c89       1
    x[3206]   c1571     -1
    x[3206]   c1787     -1
    x[3207]   c89       1
    x[3207]   c1854     -1
    x[3207]   c2070     -1
    x[3208]   c89       1
    x[3208]   c2137     -1
    x[3208]   c2353     -1
    x[3209]   c89       1
    x[3209]   c2420     -1
    x[3209]   c2636     -1
    x[3210]   c89       1
    x[3210]   c2703     -1
    x[3210]   c2919     -1
    x[3211]   c89       1
    x[3211]   c2986     -1
    x[3211]   c3202     -1
    x[3212]   c89       1
    x[3212]   c3269     -1
    x[3212]   c3485     -1
    x[3213]   c89       1
    x[3213]   c3552     -1
    x[3213]   c3768     -1
    x[3214]   c89       1
    x[3214]   c3835     -1
    x[3214]   c4051     -1
    x[3215]   c89       1
    x[3215]   c4118     -1
    x[3215]   c4334     -1
    x[3216]   c89       1
    x[3216]   c4401     -1
    x[3216]   c4617     -1
    x[3217]   c90       1
    x[3217]   c127      -1
    x[3217]   c157      -1
    x[3217]   c333      -1
    x[3218]   c90       1
    x[3218]   c410      -1
    x[3218]   c440      -1
    x[3218]   c616      -1
    x[3219]   c90       1
    x[3219]   c693      -1
    x[3219]   c723      -1
    x[3219]   c899      -1
    x[3220]   c90       1
    x[3220]   c976      -1
    x[3220]   c1006     -1
    x[3220]   c1182     -1
    x[3221]   c90       1
    x[3221]   c1259     -1
    x[3221]   c1289     -1
    x[3221]   c1465     -1
    x[3222]   c90       1
    x[3222]   c1542     -1
    x[3222]   c1572     -1
    x[3222]   c1748     -1
    x[3223]   c90       1
    x[3223]   c1825     -1
    x[3223]   c1855     -1
    x[3223]   c2031     -1
    x[3224]   c90       1
    x[3224]   c2108     -1
    x[3224]   c2138     -1
    x[3224]   c2314     -1
    x[3225]   c90       1
    x[3225]   c2391     -1
    x[3225]   c2421     -1
    x[3225]   c2597     -1
    x[3226]   c90       1
    x[3226]   c2674     -1
    x[3226]   c2704     -1
    x[3226]   c2880     -1
    x[3227]   c90       1
    x[3227]   c2957     -1
    x[3227]   c2987     -1
    x[3227]   c3163     -1
    x[3228]   c90       1
    x[3228]   c3240     -1
    x[3228]   c3270     -1
    x[3228]   c3446     -1
    x[3229]   c90       1
    x[3229]   c3523     -1
    x[3229]   c3553     -1
    x[3229]   c3729     -1
    x[3230]   c90       1
    x[3230]   c3806     -1
    x[3230]   c3836     -1
    x[3230]   c4012     -1
    x[3231]   c90       1
    x[3231]   c4089     -1
    x[3231]   c4119     -1
    x[3231]   c4295     -1
    x[3232]   c90       1
    x[3232]   c4372     -1
    x[3232]   c4402     -1
    x[3232]   c4578     -1
    x[3233]   c91       1
    x[3233]   c194      -1
    x[3233]   c305      -1
    x[3233]   c309      -1
    x[3234]   c91       1
    x[3234]   c477      -1
    x[3234]   c588      -1
    x[3234]   c592      -1
    x[3235]   c91       1
    x[3235]   c760      -1
    x[3235]   c871      -1
    x[3235]   c875      -1
    x[3236]   c91       1
    x[3236]   c1043     -1
    x[3236]   c1154     -1
    x[3236]   c1158     -1
    x[3237]   c91       1
    x[3237]   c1326     -1
    x[3237]   c1437     -1
    x[3237]   c1441     -1
    x[3238]   c91       1
    x[3238]   c1609     -1
    x[3238]   c1720     -1
    x[3238]   c1724     -1
    x[3239]   c91       1
    x[3239]   c1892     -1
    x[3239]   c2003     -1
    x[3239]   c2007     -1
    x[3240]   c91       1
    x[3240]   c2175     -1
    x[3240]   c2286     -1
    x[3240]   c2290     -1
    x[3241]   c91       1
    x[3241]   c2458     -1
    x[3241]   c2569     -1
    x[3241]   c2573     -1
    x[3242]   c91       1
    x[3242]   c2741     -1
    x[3242]   c2852     -1
    x[3242]   c2856     -1
    x[3243]   c91       1
    x[3243]   c3024     -1
    x[3243]   c3135     -1
    x[3243]   c3139     -1
    x[3244]   c91       1
    x[3244]   c3307     -1
    x[3244]   c3418     -1
    x[3244]   c3422     -1
    x[3245]   c91       1
    x[3245]   c3590     -1
    x[3245]   c3701     -1
    x[3245]   c3705     -1
    x[3246]   c91       1
    x[3246]   c3873     -1
    x[3246]   c3984     -1
    x[3246]   c3988     -1
    x[3247]   c91       1
    x[3247]   c4156     -1
    x[3247]   c4267     -1
    x[3247]   c4271     -1
    x[3248]   c91       1
    x[3248]   c4439     -1
    x[3248]   c4550     -1
    x[3248]   c4554     -1
    x[3249]   c92       1
    x[3249]   c131      -1
    x[3249]   c236      -1
    x[3249]   c239      -1
    x[3249]   c304      -1
    x[3250]   c92       1
    x[3250]   c414      -1
    x[3250]   c519      -1
    x[3250]   c522      -1
    x[3250]   c587      -1
    x[3251]   c92       1
    x[3251]   c697      -1
    x[3251]   c802      -1
    x[3251]   c805      -1
    x[3251]   c870      -1
    x[3252]   c92       1
    x[3252]   c980      -1
    x[3252]   c1085     -1
    x[3252]   c1088     -1
    x[3252]   c1153     -1
    x[3253]   c92       1
    x[3253]   c1263     -1
    x[3253]   c1368     -1
    x[3253]   c1371     -1
    x[3253]   c1436     -1
    x[3254]   c92       1
    x[3254]   c1546     -1
    x[3254]   c1651     -1
    x[3254]   c1654     -1
    x[3254]   c1719     -1
    x[3255]   c92       1
    x[3255]   c1829     -1
    x[3255]   c1934     -1
    x[3255]   c1937     -1
    x[3255]   c2002     -1
    x[3256]   c92       1
    x[3256]   c2112     -1
    x[3256]   c2217     -1
    x[3256]   c2220     -1
    x[3256]   c2285     -1
    x[3257]   c92       1
    x[3257]   c2395     -1
    x[3257]   c2500     -1
    x[3257]   c2503     -1
    x[3257]   c2568     -1
    x[3258]   c92       1
    x[3258]   c2678     -1
    x[3258]   c2783     -1
    x[3258]   c2786     -1
    x[3258]   c2851     -1
    x[3259]   c92       1
    x[3259]   c2961     -1
    x[3259]   c3066     -1
    x[3259]   c3069     -1
    x[3259]   c3134     -1
    x[3260]   c92       1
    x[3260]   c3244     -1
    x[3260]   c3349     -1
    x[3260]   c3352     -1
    x[3260]   c3417     -1
    x[3261]   c92       1
    x[3261]   c3527     -1
    x[3261]   c3632     -1
    x[3261]   c3635     -1
    x[3261]   c3700     -1
    x[3262]   c92       1
    x[3262]   c3810     -1
    x[3262]   c3915     -1
    x[3262]   c3918     -1
    x[3262]   c3983     -1
    x[3263]   c92       1
    x[3263]   c4093     -1
    x[3263]   c4198     -1
    x[3263]   c4201     -1
    x[3263]   c4266     -1
    x[3264]   c92       1
    x[3264]   c4376     -1
    x[3264]   c4481     -1
    x[3264]   c4484     -1
    x[3264]   c4549     -1
    x[3265]   c93       1
    x[3265]   c261      -1
    x[3265]   c264      -1
    x[3265]   c282      -1
    x[3265]   c336      -1
    x[3266]   c93       1
    x[3266]   c544      -1
    x[3266]   c547      -1
    x[3266]   c565      -1
    x[3266]   c619      -1
    x[3267]   c93       1
    x[3267]   c827      -1
    x[3267]   c830      -1
    x[3267]   c848      -1
    x[3267]   c902      -1
    x[3268]   c93       1
    x[3268]   c1110     -1
    x[3268]   c1113     -1
    x[3268]   c1131     -1
    x[3268]   c1185     -1
    x[3269]   c93       1
    x[3269]   c1393     -1
    x[3269]   c1396     -1
    x[3269]   c1414     -1
    x[3269]   c1468     -1
    x[3270]   c93       1
    x[3270]   c1676     -1
    x[3270]   c1679     -1
    x[3270]   c1697     -1
    x[3270]   c1751     -1
    x[3271]   c93       1
    x[3271]   c1959     -1
    x[3271]   c1962     -1
    x[3271]   c1980     -1
    x[3271]   c2034     -1
    x[3272]   c93       1
    x[3272]   c2242     -1
    x[3272]   c2245     -1
    x[3272]   c2263     -1
    x[3272]   c2317     -1
    x[3273]   c93       1
    x[3273]   c2525     -1
    x[3273]   c2528     -1
    x[3273]   c2546     -1
    x[3273]   c2600     -1
    x[3274]   c93       1
    x[3274]   c2808     -1
    x[3274]   c2811     -1
    x[3274]   c2829     -1
    x[3274]   c2883     -1
    x[3275]   c93       1
    x[3275]   c3091     -1
    x[3275]   c3094     -1
    x[3275]   c3112     -1
    x[3275]   c3166     -1
    x[3276]   c93       1
    x[3276]   c3374     -1
    x[3276]   c3377     -1
    x[3276]   c3395     -1
    x[3276]   c3449     -1
    x[3277]   c93       1
    x[3277]   c3657     -1
    x[3277]   c3660     -1
    x[3277]   c3678     -1
    x[3277]   c3732     -1
    x[3278]   c93       1
    x[3278]   c3940     -1
    x[3278]   c3943     -1
    x[3278]   c3961     -1
    x[3278]   c4015     -1
    x[3279]   c93       1
    x[3279]   c4223     -1
    x[3279]   c4226     -1
    x[3279]   c4244     -1
    x[3279]   c4298     -1
    x[3280]   c93       1
    x[3280]   c4506     -1
    x[3280]   c4509     -1
    x[3280]   c4527     -1
    x[3280]   c4581     -1
    x[3281]   c94       1
    x[3281]   c231      -1
    x[3281]   c269      -1
    x[3281]   c293      -1
    x[3281]   c355      -1
    x[3282]   c94       1
    x[3282]   c514      -1
    x[3282]   c552      -1
    x[3282]   c576      -1
    x[3282]   c638      -1
    x[3283]   c94       1
    x[3283]   c797      -1
    x[3283]   c835      -1
    x[3283]   c859      -1
    x[3283]   c921      -1
    x[3284]   c94       1
    x[3284]   c1080     -1
    x[3284]   c1118     -1
    x[3284]   c1142     -1
    x[3284]   c1204     -1
    x[3285]   c94       1
    x[3285]   c1363     -1
    x[3285]   c1401     -1
    x[3285]   c1425     -1
    x[3285]   c1487     -1
    x[3286]   c94       1
    x[3286]   c1646     -1
    x[3286]   c1684     -1
    x[3286]   c1708     -1
    x[3286]   c1770     -1
    x[3287]   c94       1
    x[3287]   c1929     -1
    x[3287]   c1967     -1
    x[3287]   c1991     -1
    x[3287]   c2053     -1
    x[3288]   c94       1
    x[3288]   c2212     -1
    x[3288]   c2250     -1
    x[3288]   c2274     -1
    x[3288]   c2336     -1
    x[3289]   c94       1
    x[3289]   c2495     -1
    x[3289]   c2533     -1
    x[3289]   c2557     -1
    x[3289]   c2619     -1
    x[3290]   c94       1
    x[3290]   c2778     -1
    x[3290]   c2816     -1
    x[3290]   c2840     -1
    x[3290]   c2902     -1
    x[3291]   c94       1
    x[3291]   c3061     -1
    x[3291]   c3099     -1
    x[3291]   c3123     -1
    x[3291]   c3185     -1
    x[3292]   c94       1
    x[3292]   c3344     -1
    x[3292]   c3382     -1
    x[3292]   c3406     -1
    x[3292]   c3468     -1
    x[3293]   c94       1
    x[3293]   c3627     -1
    x[3293]   c3665     -1
    x[3293]   c3689     -1
    x[3293]   c3751     -1
    x[3294]   c94       1
    x[3294]   c3910     -1
    x[3294]   c3948     -1
    x[3294]   c3972     -1
    x[3294]   c4034     -1
    x[3295]   c94       1
    x[3295]   c4193     -1
    x[3295]   c4231     -1
    x[3295]   c4255     -1
    x[3295]   c4317     -1
    x[3296]   c94       1
    x[3296]   c4476     -1
    x[3296]   c4514     -1
    x[3296]   c4538     -1
    x[3296]   c4600     -1
    x[3297]   c95       1
    x[3297]   c113      -1
    x[3297]   c267      -1
    x[3297]   c344      -1
    x[3297]   c370      -1
    x[3298]   c95       1
    x[3298]   c396      -1
    x[3298]   c550      -1
    x[3298]   c627      -1
    x[3298]   c653      -1
    x[3299]   c95       1
    x[3299]   c679      -1
    x[3299]   c833      -1
    x[3299]   c910      -1
    x[3299]   c936      -1
    x[3300]   c95       1
    x[3300]   c962      -1
    x[3300]   c1116     -1
    x[3300]   c1193     -1
    x[3300]   c1219     -1
    x[3301]   c95       1
    x[3301]   c1245     -1
    x[3301]   c1399     -1
    x[3301]   c1476     -1
    x[3301]   c1502     -1
    x[3302]   c95       1
    x[3302]   c1528     -1
    x[3302]   c1682     -1
    x[3302]   c1759     -1
    x[3302]   c1785     -1
    x[3303]   c95       1
    x[3303]   c1811     -1
    x[3303]   c1965     -1
    x[3303]   c2042     -1
    x[3303]   c2068     -1
    x[3304]   c95       1
    x[3304]   c2094     -1
    x[3304]   c2248     -1
    x[3304]   c2325     -1
    x[3304]   c2351     -1
    x[3305]   c95       1
    x[3305]   c2377     -1
    x[3305]   c2531     -1
    x[3305]   c2608     -1
    x[3305]   c2634     -1
    x[3306]   c95       1
    x[3306]   c2660     -1
    x[3306]   c2814     -1
    x[3306]   c2891     -1
    x[3306]   c2917     -1
    x[3307]   c95       1
    x[3307]   c2943     -1
    x[3307]   c3097     -1
    x[3307]   c3174     -1
    x[3307]   c3200     -1
    x[3308]   c95       1
    x[3308]   c3226     -1
    x[3308]   c3380     -1
    x[3308]   c3457     -1
    x[3308]   c3483     -1
    x[3309]   c95       1
    x[3309]   c3509     -1
    x[3309]   c3663     -1
    x[3309]   c3740     -1
    x[3309]   c3766     -1
    x[3310]   c95       1
    x[3310]   c3792     -1
    x[3310]   c3946     -1
    x[3310]   c4023     -1
    x[3310]   c4049     -1
    x[3311]   c95       1
    x[3311]   c4075     -1
    x[3311]   c4229     -1
    x[3311]   c4306     -1
    x[3311]   c4332     -1
    x[3312]   c95       1
    x[3312]   c4358     -1
    x[3312]   c4512     -1
    x[3312]   c4589     -1
    x[3312]   c4615     -1
    x[3313]   c96       1
    x[3313]   c216      -1
    x[3313]   c339      -1
    x[3313]   c371      -1
    x[3314]   c96       1
    x[3314]   c499      -1
    x[3314]   c622      -1
    x[3314]   c654      -1
    x[3315]   c96       1
    x[3315]   c782      -1
    x[3315]   c905      -1
    x[3315]   c937      -1
    x[3316]   c96       1
    x[3316]   c1065     -1
    x[3316]   c1188     -1
    x[3316]   c1220     -1
    x[3317]   c96       1
    x[3317]   c1348     -1
    x[3317]   c1471     -1
    x[3317]   c1503     -1
    x[3318]   c96       1
    x[3318]   c1631     -1
    x[3318]   c1754     -1
    x[3318]   c1786     -1
    x[3319]   c96       1
    x[3319]   c1914     -1
    x[3319]   c2037     -1
    x[3319]   c2069     -1
    x[3320]   c96       1
    x[3320]   c2197     -1
    x[3320]   c2320     -1
    x[3320]   c2352     -1
    x[3321]   c96       1
    x[3321]   c2480     -1
    x[3321]   c2603     -1
    x[3321]   c2635     -1
    x[3322]   c96       1
    x[3322]   c2763     -1
    x[3322]   c2886     -1
    x[3322]   c2918     -1
    x[3323]   c96       1
    x[3323]   c3046     -1
    x[3323]   c3169     -1
    x[3323]   c3201     -1
    x[3324]   c96       1
    x[3324]   c3329     -1
    x[3324]   c3452     -1
    x[3324]   c3484     -1
    x[3325]   c96       1
    x[3325]   c3612     -1
    x[3325]   c3735     -1
    x[3325]   c3767     -1
    x[3326]   c96       1
    x[3326]   c3895     -1
    x[3326]   c4018     -1
    x[3326]   c4050     -1
    x[3327]   c96       1
    x[3327]   c4178     -1
    x[3327]   c4301     -1
    x[3327]   c4333     -1
    x[3328]   c96       1
    x[3328]   c4461     -1
    x[3328]   c4584     -1
    x[3328]   c4616     -1
    x[3329]   c97       1
    x[3329]   c299      -1
    x[3329]   c356      -1
    x[3330]   c97       1
    x[3330]   c582      -1
    x[3330]   c639      -1
    x[3331]   c97       1
    x[3331]   c865      -1
    x[3331]   c922      -1
    x[3332]   c97       1
    x[3332]   c1148     -1
    x[3332]   c1205     -1
    x[3333]   c97       1
    x[3333]   c1431     -1
    x[3333]   c1488     -1
    x[3334]   c97       1
    x[3334]   c1714     -1
    x[3334]   c1771     -1
    x[3335]   c97       1
    x[3335]   c1997     -1
    x[3335]   c2054     -1
    x[3336]   c97       1
    x[3336]   c2280     -1
    x[3336]   c2337     -1
    x[3337]   c97       1
    x[3337]   c2563     -1
    x[3337]   c2620     -1
    x[3338]   c97       1
    x[3338]   c2846     -1
    x[3338]   c2903     -1
    x[3339]   c97       1
    x[3339]   c3129     -1
    x[3339]   c3186     -1
    x[3340]   c97       1
    x[3340]   c3412     -1
    x[3340]   c3469     -1
    x[3341]   c97       1
    x[3341]   c3695     -1
    x[3341]   c3752     -1
    x[3342]   c97       1
    x[3342]   c3978     -1
    x[3342]   c4035     -1
    x[3343]   c97       1
    x[3343]   c4261     -1
    x[3343]   c4318     -1
    x[3344]   c97       1
    x[3344]   c4544     -1
    x[3344]   c4601     -1
    x[3345]   c98       1
    x[3345]   c268      -1
    x[3345]   c325      -1
    x[3345]   c340      -1
    x[3345]   c380      -1
    x[3346]   c98       1
    x[3346]   c551      -1
    x[3346]   c608      -1
    x[3346]   c623      -1
    x[3346]   c663      -1
    x[3347]   c98       1
    x[3347]   c834      -1
    x[3347]   c891      -1
    x[3347]   c906      -1
    x[3347]   c946      -1
    x[3348]   c98       1
    x[3348]   c1117     -1
    x[3348]   c1174     -1
    x[3348]   c1189     -1
    x[3348]   c1229     -1
    x[3349]   c98       1
    x[3349]   c1400     -1
    x[3349]   c1457     -1
    x[3349]   c1472     -1
    x[3349]   c1512     -1
    x[3350]   c98       1
    x[3350]   c1683     -1
    x[3350]   c1740     -1
    x[3350]   c1755     -1
    x[3350]   c1795     -1
    x[3351]   c98       1
    x[3351]   c1966     -1
    x[3351]   c2023     -1
    x[3351]   c2038     -1
    x[3351]   c2078     -1
    x[3352]   c98       1
    x[3352]   c2249     -1
    x[3352]   c2306     -1
    x[3352]   c2321     -1
    x[3352]   c2361     -1
    x[3353]   c98       1
    x[3353]   c2532     -1
    x[3353]   c2589     -1
    x[3353]   c2604     -1
    x[3353]   c2644     -1
    x[3354]   c98       1
    x[3354]   c2815     -1
    x[3354]   c2872     -1
    x[3354]   c2887     -1
    x[3354]   c2927     -1
    x[3355]   c98       1
    x[3355]   c3098     -1
    x[3355]   c3155     -1
    x[3355]   c3170     -1
    x[3355]   c3210     -1
    x[3356]   c98       1
    x[3356]   c3381     -1
    x[3356]   c3438     -1
    x[3356]   c3453     -1
    x[3356]   c3493     -1
    x[3357]   c98       1
    x[3357]   c3664     -1
    x[3357]   c3721     -1
    x[3357]   c3736     -1
    x[3357]   c3776     -1
    x[3358]   c98       1
    x[3358]   c3947     -1
    x[3358]   c4004     -1
    x[3358]   c4019     -1
    x[3358]   c4059     -1
    x[3359]   c98       1
    x[3359]   c4230     -1
    x[3359]   c4287     -1
    x[3359]   c4302     -1
    x[3359]   c4342     -1
    x[3360]   c98       1
    x[3360]   c4513     -1
    x[3360]   c4570     -1
    x[3360]   c4585     -1
    x[3360]   c4625     -1
    x[3361]   c99       1
    x[3361]   c144      -1
    x[3361]   c171      -1
    x[3361]   c275      -1
    x[3361]   c363      -1
    x[3362]   c99       1
    x[3362]   c427      -1
    x[3362]   c454      -1
    x[3362]   c558      -1
    x[3362]   c646      -1
    x[3363]   c99       1
    x[3363]   c710      -1
    x[3363]   c737      -1
    x[3363]   c841      -1
    x[3363]   c929      -1
    x[3364]   c99       1
    x[3364]   c993      -1
    x[3364]   c1020     -1
    x[3364]   c1124     -1
    x[3364]   c1212     -1
    x[3365]   c99       1
    x[3365]   c1276     -1
    x[3365]   c1303     -1
    x[3365]   c1407     -1
    x[3365]   c1495     -1
    x[3366]   c99       1
    x[3366]   c1559     -1
    x[3366]   c1586     -1
    x[3366]   c1690     -1
    x[3366]   c1778     -1
    x[3367]   c99       1
    x[3367]   c1842     -1
    x[3367]   c1869     -1
    x[3367]   c1973     -1
    x[3367]   c2061     -1
    x[3368]   c99       1
    x[3368]   c2125     -1
    x[3368]   c2152     -1
    x[3368]   c2256     -1
    x[3368]   c2344     -1
    x[3369]   c99       1
    x[3369]   c2408     -1
    x[3369]   c2435     -1
    x[3369]   c2539     -1
    x[3369]   c2627     -1
    x[3370]   c99       1
    x[3370]   c2691     -1
    x[3370]   c2718     -1
    x[3370]   c2822     -1
    x[3370]   c2910     -1
    x[3371]   c99       1
    x[3371]   c2974     -1
    x[3371]   c3001     -1
    x[3371]   c3105     -1
    x[3371]   c3193     -1
    x[3372]   c99       1
    x[3372]   c3257     -1
    x[3372]   c3284     -1
    x[3372]   c3388     -1
    x[3372]   c3476     -1
    x[3373]   c99       1
    x[3373]   c3540     -1
    x[3373]   c3567     -1
    x[3373]   c3671     -1
    x[3373]   c3759     -1
    x[3374]   c99       1
    x[3374]   c3823     -1
    x[3374]   c3850     -1
    x[3374]   c3954     -1
    x[3374]   c4042     -1
    x[3375]   c99       1
    x[3375]   c4106     -1
    x[3375]   c4133     -1
    x[3375]   c4237     -1
    x[3375]   c4325     -1
    x[3376]   c99       1
    x[3376]   c4389     -1
    x[3376]   c4416     -1
    x[3376]   c4520     -1
    x[3376]   c4608     -1
    x[3377]   c100      1
    x[3377]   c120      -1
    x[3377]   c321      -1
    x[3378]   c100      1
    x[3378]   c403      -1
    x[3378]   c604      -1
    x[3379]   c100      1
    x[3379]   c686      -1
    x[3379]   c887      -1
    x[3380]   c100      1
    x[3380]   c969      -1
    x[3380]   c1170     -1
    x[3381]   c100      1
    x[3381]   c1252     -1
    x[3381]   c1453     -1
    x[3382]   c100      1
    x[3382]   c1535     -1
    x[3382]   c1736     -1
    x[3383]   c100      1
    x[3383]   c1818     -1
    x[3383]   c2019     -1
    x[3384]   c100      1
    x[3384]   c2101     -1
    x[3384]   c2302     -1
    x[3385]   c100      1
    x[3385]   c2384     -1
    x[3385]   c2585     -1
    x[3386]   c100      1
    x[3386]   c2667     -1
    x[3386]   c2868     -1
    x[3387]   c100      1
    x[3387]   c2950     -1
    x[3387]   c3151     -1
    x[3388]   c100      1
    x[3388]   c3233     -1
    x[3388]   c3434     -1
    x[3389]   c100      1
    x[3389]   c3516     -1
    x[3389]   c3717     -1
    x[3390]   c100      1
    x[3390]   c3799     -1
    x[3390]   c4000     -1
    x[3391]   c100      1
    x[3391]   c4082     -1
    x[3391]   c4283     -1
    x[3392]   c100      1
    x[3392]   c4365     -1
    x[3392]   c4566     -1
    x[3393]   c101      1
    x[3393]   c138      -1
    x[3393]   c208      -1
    x[3393]   c311      -1
    x[3394]   c101      1
    x[3394]   c421      -1
    x[3394]   c491      -1
    x[3394]   c594      -1
    x[3395]   c101      1
    x[3395]   c704      -1
    x[3395]   c774      -1
    x[3395]   c877      -1
    x[3396]   c101      1
    x[3396]   c987      -1
    x[3396]   c1057     -1
    x[3396]   c1160     -1
    x[3397]   c101      1
    x[3397]   c1270     -1
    x[3397]   c1340     -1
    x[3397]   c1443     -1
    x[3398]   c101      1
    x[3398]   c1553     -1
    x[3398]   c1623     -1
    x[3398]   c1726     -1
    x[3399]   c101      1
    x[3399]   c1836     -1
    x[3399]   c1906     -1
    x[3399]   c2009     -1
    x[3400]   c101      1
    x[3400]   c2119     -1
    x[3400]   c2189     -1
    x[3400]   c2292     -1
    x[3401]   c101      1
    x[3401]   c2402     -1
    x[3401]   c2472     -1
    x[3401]   c2575     -1
    x[3402]   c101      1
    x[3402]   c2685     -1
    x[3402]   c2755     -1
    x[3402]   c2858     -1
    x[3403]   c101      1
    x[3403]   c2968     -1
    x[3403]   c3038     -1
    x[3403]   c3141     -1
    x[3404]   c101      1
    x[3404]   c3251     -1
    x[3404]   c3321     -1
    x[3404]   c3424     -1
    x[3405]   c101      1
    x[3405]   c3534     -1
    x[3405]   c3604     -1
    x[3405]   c3707     -1
    x[3406]   c101      1
    x[3406]   c3817     -1
    x[3406]   c3887     -1
    x[3406]   c3990     -1
    x[3407]   c101      1
    x[3407]   c4100     -1
    x[3407]   c4170     -1
    x[3407]   c4273     -1
    x[3408]   c101      1
    x[3408]   c4383     -1
    x[3408]   c4453     -1
    x[3408]   c4556     -1
    x[3409]   c102      1
    x[3409]   c125      -1
    x[3409]   c146      -1
    x[3409]   c190      -1
    x[3409]   c387      -1
    x[3410]   c102      1
    x[3410]   c408      -1
    x[3410]   c429      -1
    x[3410]   c473      -1
    x[3410]   c670      -1
    x[3411]   c102      1
    x[3411]   c691      -1
    x[3411]   c712      -1
    x[3411]   c756      -1
    x[3411]   c953      -1
    x[3412]   c102      1
    x[3412]   c974      -1
    x[3412]   c995      -1
    x[3412]   c1039     -1
    x[3412]   c1236     -1
    x[3413]   c102      1
    x[3413]   c1257     -1
    x[3413]   c1278     -1
    x[3413]   c1322     -1
    x[3413]   c1519     -1
    x[3414]   c102      1
    x[3414]   c1540     -1
    x[3414]   c1561     -1
    x[3414]   c1605     -1
    x[3414]   c1802     -1
    x[3415]   c102      1
    x[3415]   c1823     -1
    x[3415]   c1844     -1
    x[3415]   c1888     -1
    x[3415]   c2085     -1
    x[3416]   c102      1
    x[3416]   c2106     -1
    x[3416]   c2127     -1
    x[3416]   c2171     -1
    x[3416]   c2368     -1
    x[3417]   c102      1
    x[3417]   c2389     -1
    x[3417]   c2410     -1
    x[3417]   c2454     -1
    x[3417]   c2651     -1
    x[3418]   c102      1
    x[3418]   c2672     -1
    x[3418]   c2693     -1
    x[3418]   c2737     -1
    x[3418]   c2934     -1
    x[3419]   c102      1
    x[3419]   c2955     -1
    x[3419]   c2976     -1
    x[3419]   c3020     -1
    x[3419]   c3217     -1
    x[3420]   c102      1
    x[3420]   c3238     -1
    x[3420]   c3259     -1
    x[3420]   c3303     -1
    x[3420]   c3500     -1
    x[3421]   c102      1
    x[3421]   c3521     -1
    x[3421]   c3542     -1
    x[3421]   c3586     -1
    x[3421]   c3783     -1
    x[3422]   c102      1
    x[3422]   c3804     -1
    x[3422]   c3825     -1
    x[3422]   c3869     -1
    x[3422]   c4066     -1
    x[3423]   c102      1
    x[3423]   c4087     -1
    x[3423]   c4108     -1
    x[3423]   c4152     -1
    x[3423]   c4349     -1
    x[3424]   c102      1
    x[3424]   c4370     -1
    x[3424]   c4391     -1
    x[3424]   c4435     -1
    x[3424]   c4632     -1
    x[3425]   c103      1
    x[3425]   c243      -1
    x[3425]   c278      -1
    x[3425]   c310      -1
    x[3426]   c103      1
    x[3426]   c526      -1
    x[3426]   c561      -1
    x[3426]   c593      -1
    x[3427]   c103      1
    x[3427]   c809      -1
    x[3427]   c844      -1
    x[3427]   c876      -1
    x[3428]   c103      1
    x[3428]   c1092     -1
    x[3428]   c1127     -1
    x[3428]   c1159     -1
    x[3429]   c103      1
    x[3429]   c1375     -1
    x[3429]   c1410     -1
    x[3429]   c1442     -1
    x[3430]   c103      1
    x[3430]   c1658     -1
    x[3430]   c1693     -1
    x[3430]   c1725     -1
    x[3431]   c103      1
    x[3431]   c1941     -1
    x[3431]   c1976     -1
    x[3431]   c2008     -1
    x[3432]   c103      1
    x[3432]   c2224     -1
    x[3432]   c2259     -1
    x[3432]   c2291     -1
    x[3433]   c103      1
    x[3433]   c2507     -1
    x[3433]   c2542     -1
    x[3433]   c2574     -1
    x[3434]   c103      1
    x[3434]   c2790     -1
    x[3434]   c2825     -1
    x[3434]   c2857     -1
    x[3435]   c103      1
    x[3435]   c3073     -1
    x[3435]   c3108     -1
    x[3435]   c3140     -1
    x[3436]   c103      1
    x[3436]   c3356     -1
    x[3436]   c3391     -1
    x[3436]   c3423     -1
    x[3437]   c103      1
    x[3437]   c3639     -1
    x[3437]   c3674     -1
    x[3437]   c3706     -1
    x[3438]   c103      1
    x[3438]   c3922     -1
    x[3438]   c3957     -1
    x[3438]   c3989     -1
    x[3439]   c103      1
    x[3439]   c4205     -1
    x[3439]   c4240     -1
    x[3439]   c4272     -1
    x[3440]   c103      1
    x[3440]   c4488     -1
    x[3440]   c4523     -1
    x[3440]   c4555     -1
    x[3441]   c104      1
    x[3441]   c179      -1
    x[3441]   c368      -1
    x[3442]   c104      1
    x[3442]   c462      -1
    x[3442]   c651      -1
    x[3443]   c104      1
    x[3443]   c745      -1
    x[3443]   c934      -1
    x[3444]   c104      1
    x[3444]   c1028     -1
    x[3444]   c1217     -1
    x[3445]   c104      1
    x[3445]   c1311     -1
    x[3445]   c1500     -1
    x[3446]   c104      1
    x[3446]   c1594     -1
    x[3446]   c1783     -1
    x[3447]   c104      1
    x[3447]   c1877     -1
    x[3447]   c2066     -1
    x[3448]   c104      1
    x[3448]   c2160     -1
    x[3448]   c2349     -1
    x[3449]   c104      1
    x[3449]   c2443     -1
    x[3449]   c2632     -1
    x[3450]   c104      1
    x[3450]   c2726     -1
    x[3450]   c2915     -1
    x[3451]   c104      1
    x[3451]   c3009     -1
    x[3451]   c3198     -1
    x[3452]   c104      1
    x[3452]   c3292     -1
    x[3452]   c3481     -1
    x[3453]   c104      1
    x[3453]   c3575     -1
    x[3453]   c3764     -1
    x[3454]   c104      1
    x[3454]   c3858     -1
    x[3454]   c4047     -1
    x[3455]   c104      1
    x[3455]   c4141     -1
    x[3455]   c4330     -1
    x[3456]   c104      1
    x[3456]   c4424     -1
    x[3456]   c4613     -1
    x[3457]   c105      1
    x[3457]   c167      -1
    x[3457]   c388      -1
    x[3458]   c105      1
    x[3458]   c450      -1
    x[3458]   c671      -1
    x[3459]   c105      1
    x[3459]   c733      -1
    x[3459]   c954      -1
    x[3460]   c105      1
    x[3460]   c1016     -1
    x[3460]   c1237     -1
    x[3461]   c105      1
    x[3461]   c1299     -1
    x[3461]   c1520     -1
    x[3462]   c105      1
    x[3462]   c1582     -1
    x[3462]   c1803     -1
    x[3463]   c105      1
    x[3463]   c1865     -1
    x[3463]   c2086     -1
    x[3464]   c105      1
    x[3464]   c2148     -1
    x[3464]   c2369     -1
    x[3465]   c105      1
    x[3465]   c2431     -1
    x[3465]   c2652     -1
    x[3466]   c105      1
    x[3466]   c2714     -1
    x[3466]   c2935     -1
    x[3467]   c105      1
    x[3467]   c2997     -1
    x[3467]   c3218     -1
    x[3468]   c105      1
    x[3468]   c3280     -1
    x[3468]   c3501     -1
    x[3469]   c105      1
    x[3469]   c3563     -1
    x[3469]   c3784     -1
    x[3470]   c105      1
    x[3470]   c3846     -1
    x[3470]   c4067     -1
    x[3471]   c105      1
    x[3471]   c4129     -1
    x[3471]   c4350     -1
    x[3472]   c105      1
    x[3472]   c4412     -1
    x[3472]   c4633     -1
    MARKER    'MARKER'                 'INTEND'
RHS
    rhs       c1        9
    rhs       c2        9
    rhs       c3        9
    rhs       c4        9
    rhs       c5        9
    rhs       c6        9
    rhs       c7        9
    rhs       c8        9
    rhs       c9        9
    rhs       c10       9
    rhs       c11       9
    rhs       c12       9
    rhs       c13       9
    rhs       c14       9
    rhs       c15       9
    rhs       c16       9
    rhs       c17       1
    rhs       c18       1
    rhs       c19       1
    rhs       c20       1
    rhs       c21       1
    rhs       c22       1
    rhs       c23       1
    rhs       c24       1
    rhs       c25       1
    rhs       c26       1
    rhs       c27       1
    rhs       c28       1
    rhs       c29       1
    rhs       c30       1
    rhs       c31       1
    rhs       c32       1
    rhs       c33       1
    rhs       c34       1
    rhs       c35       1
    rhs       c36       1
    rhs       c37       1
    rhs       c38       1
    rhs       c39       1
    rhs       c40       1
    rhs       c41       1
    rhs       c42       1
    rhs       c43       1
    rhs       c44       1
    rhs       c45       1
    rhs       c46       1
    rhs       c47       1
    rhs       c48       1
    rhs       c49       1
    rhs       c50       1
    rhs       c51       1
    rhs       c52       1
    rhs       c53       1
    rhs       c54       1
    rhs       c55       1
    rhs       c56       1
    rhs       c57       1
    rhs       c58       1
    rhs       c59       1
    rhs       c60       1
    rhs       c61       1
    rhs       c62       1
    rhs       c63       1
    rhs       c64       1
    rhs       c65       1
    rhs       c66       1
    rhs       c67       1
    rhs       c68       1
    rhs       c69       1
    rhs       c70       1
    rhs       c71       1
    rhs       c72       1
    rhs       c73       1
    rhs       c74       1
    rhs       c75       1
    rhs       c76       1
    rhs       c77       1
    rhs       c78       1
    rhs       c79       1
    rhs       c80       1
    rhs       c81       1
    rhs       c82       1
    rhs       c83       1
    rhs       c84       1
    rhs       c85       1
    rhs       c86       1
    rhs       c87       1
    rhs       c88       1
    rhs       c89       1
    rhs       c90       1
    rhs       c91       1
    rhs       c92       1
    rhs       c93       1
    rhs       c94       1
    rhs       c95       1
    rhs       c96       1
    rhs       c97       1
    rhs       c98       1
    rhs       c99       1
    rhs       c100      1
    rhs       c101      1
    rhs       c102      1
    rhs       c103      1
    rhs       c104      1
    rhs       c105      1
    rhs       c106      0
    rhs       c107      0
    rhs       c108      0
    rhs       c109      0
    rhs       c110      0
    rhs       c111      0
    rhs       c112      0
    rhs       c113      0
    rhs       c114      0
    rhs       c115      0
    rhs       c116      0
    rhs       c117      0
    rhs       c118      0
    rhs       c119      0
    rhs       c120      0
    rhs       c121      0
    rhs       c122      0
    rhs       c123      0
    rhs       c124      0
    rhs       c125      0
    rhs       c126      0
    rhs       c127      0
    rhs       c128      0
    rhs       c129      0
    rhs       c130      0
    rhs       c131      0
    rhs       c132      0
    rhs       c133      0
    rhs       c134      0
    rhs       c135      0
    rhs       c136      0
    rhs       c137      0
    rhs       c138      0
    rhs       c139      0
    rhs       c140      0
    rhs       c141      0
    rhs       c142      0
    rhs       c143      0
    rhs       c144      0
    rhs       c145      0
    rhs       c146      0
    rhs       c147      0
    rhs       c148      0
    rhs       c149      0
    rhs       c150      0
    rhs       c151      0
    rhs       c152      0
    rhs       c153      0
    rhs       c154      0
    rhs       c155      0
    rhs       c156      0
    rhs       c157      0
    rhs       c158      0
    rhs       c159      0
    rhs       c160      0
    rhs       c161      0
    rhs       c162      0
    rhs       c163      0
    rhs       c164      0
    rhs       c165      0
    rhs       c166      0
    rhs       c167      0
    rhs       c168      0
    rhs       c169      0
    rhs       c170      0
    rhs       c171      0
    rhs       c172      0
    rhs       c173      0
    rhs       c174      0
    rhs       c175      0
    rhs       c176      0
    rhs       c177      0
    rhs       c178      0
    rhs       c179      0
    rhs       c180      0
    rhs       c181      0
    rhs       c182      0
    rhs       c183      0
    rhs       c184      0
    rhs       c185      0
    rhs       c186      0
    rhs       c187      0
    rhs       c188      0
    rhs       c189      0
    rhs       c190      0
    rhs       c191      0
    rhs       c192      0
    rhs       c193      0
    rhs       c194      0
    rhs       c195      0
    rhs       c196      0
    rhs       c197      0
    rhs       c198      0
    rhs       c199      0
    rhs       c200      0
    rhs       c201      0
    rhs       c202      0
    rhs       c203      0
    rhs       c204      0
    rhs       c205      0
    rhs       c206      0
    rhs       c207      0
    rhs       c208      0
    rhs       c209      0
    rhs       c210      0
    rhs       c211      0
    rhs       c212      0
    rhs       c213      0
    rhs       c214      0
    rhs       c215      0
    rhs       c216      0
    rhs       c217      0
    rhs       c218      0
    rhs       c219      0
    rhs       c220      0
    rhs       c221      0
    rhs       c222      0
    rhs       c223      0
    rhs       c224      0
    rhs       c225      0
    rhs       c226      0
    rhs       c227      0
    rhs       c228      0
    rhs       c229      0
    rhs       c230      0
    rhs       c231      0
    rhs       c232      0
    rhs       c233      0
    rhs       c234      0
    rhs       c235      0
    rhs       c236      0
    rhs       c237      0
    rhs       c238      0
    rhs       c239      0
    rhs       c240      0
    rhs       c241      0
    rhs       c242      0
    rhs       c243      0
    rhs       c244      0
    rhs       c245      0
    rhs       c246      0
    rhs       c247      0
    rhs       c248      0
    rhs       c249      0
    rhs       c250      0
    rhs       c251      0
    rhs       c252      0
    rhs       c253      0
    rhs       c254      0
    rhs       c255      0
    rhs       c256      0
    rhs       c257      0
    rhs       c258      0
    rhs       c259      0
    rhs       c260      0
    rhs       c261      0
    rhs       c262      0
    rhs       c263      0
    rhs       c264      0
    rhs       c265      0
    rhs       c266      0
    rhs       c267      0
    rhs       c268      0
    rhs       c269      0
    rhs       c270      0
    rhs       c271      0
    rhs       c272      0
    rhs       c273      0
    rhs       c274      0
    rhs       c275      0
    rhs       c276      0
    rhs       c277      0
    rhs       c278      0
    rhs       c279      0
    rhs       c280      0
    rhs       c281      0
    rhs       c282      0
    rhs       c283      0
    rhs       c284      0
    rhs       c285      0
    rhs       c286      0
    rhs       c287      0
    rhs       c288      0
    rhs       c289      0
    rhs       c290      0
    rhs       c291      0
    rhs       c292      0
    rhs       c293      0
    rhs       c294      0
    rhs       c295      0
    rhs       c296      0
    rhs       c297      0
    rhs       c298      0
    rhs       c299      0
    rhs       c300      0
    rhs       c301      0
    rhs       c302      0
    rhs       c303      0
    rhs       c304      0
    rhs       c305      0
    rhs       c306      0
    rhs       c307      0
    rhs       c308      0
    rhs       c309      0
    rhs       c310      0
    rhs       c311      0
    rhs       c312      0
    rhs       c313      0
    rhs       c314      0
    rhs       c315      0
    rhs       c316      0
    rhs       c317      0
    rhs       c318      0
    rhs       c319      0
    rhs       c320      0
    rhs       c321      0
    rhs       c322      0
    rhs       c323      0
    rhs       c324      0
    rhs       c325      0
    rhs       c326      0
    rhs       c327      0
    rhs       c328      0
    rhs       c329      0
    rhs       c330      0
    rhs       c331      0
    rhs       c332      0
    rhs       c333      0
    rhs       c334      0
    rhs       c335      0
    rhs       c336      0
    rhs       c337      0
    rhs       c338      0
    rhs       c339      0
    rhs       c340      0
    rhs       c341      0
    rhs       c342      0
    rhs       c343      0
    rhs       c344      0
    rhs       c345      0
    rhs       c346      0
    rhs       c347      0
    rhs       c348      0
    rhs       c349      0
    rhs       c350      0
    rhs       c351      0
    rhs       c352      0
    rhs       c353      0
    rhs       c354      0
    rhs       c355      0
    rhs       c356      0
    rhs       c357      0
    rhs       c358      0
    rhs       c359      0
    rhs       c360      0
    rhs       c361      0
    rhs       c362      0
    rhs       c363      0
    rhs       c364      0
    rhs       c365      0
    rhs       c366      0
    rhs       c367      0
    rhs       c368      0
    rhs       c369      0
    rhs       c370      0
    rhs       c371      0
    rhs       c372      0
    rhs       c373      0
    rhs       c374      0
    rhs       c375      0
    rhs       c376      0
    rhs       c377      0
    rhs       c378      0
    rhs       c379      0
    rhs       c380      0
    rhs       c381      0
    rhs       c382      0
    rhs       c383      0
    rhs       c384      0
    rhs       c385      0
    rhs       c386      0
    rhs       c387      0
    rhs       c388      0
    rhs       c389      0
    rhs       c390      0
    rhs       c391      0
    rhs       c392      0
    rhs       c393      0
    rhs       c394      0
    rhs       c395      0
    rhs       c396      0
    rhs       c397      0
    rhs       c398      0
    rhs       c399      0
    rhs       c400      0
    rhs       c401      0
    rhs       c402      0
    rhs       c403      0
    rhs       c404      0
    rhs       c405      0
    rhs       c406      0
    rhs       c407      0
    rhs       c408      0
    rhs       c409      0
    rhs       c410      0
    rhs       c411      0
    rhs       c412      0
    rhs       c413      0
    rhs       c414      0
    rhs       c415      0
    rhs       c416      0
    rhs       c417      0
    rhs       c418      0
    rhs       c419      0
    rhs       c420      0
    rhs       c421      0
    rhs       c422      0
    rhs       c423      0
    rhs       c424      0
    rhs       c425      0
    rhs       c426      0
    rhs       c427      0
    rhs       c428      0
    rhs       c429      0
    rhs       c430      0
    rhs       c431      0
    rhs       c432      0
    rhs       c433      0
    rhs       c434      0
    rhs       c435      0
    rhs       c436      0
    rhs       c437      0
    rhs       c438      0
    rhs       c439      0
    rhs       c440      0
    rhs       c441      0
    rhs       c442      0
    rhs       c443      0
    rhs       c444      0
    rhs       c445      0
    rhs       c446      0
    rhs       c447      0
    rhs       c448      0
    rhs       c449      0
    rhs       c450      0
    rhs       c451      0
    rhs       c452      0
    rhs       c453      0
    rhs       c454      0
    rhs       c455      0
    rhs       c456      0
    rhs       c457      0
    rhs       c458      0
    rhs       c459      0
    rhs       c460      0
    rhs       c461      0
    rhs       c462      0
    rhs       c463      0
    rhs       c464      0
    rhs       c465      0
    rhs       c466      0
    rhs       c467      0
    rhs       c468      0
    rhs       c469      0
    rhs       c470      0
    rhs       c471      0
    rhs       c472      0
    rhs       c473      0
    rhs       c474      0
    rhs       c475      0
    rhs       c476      0
    rhs       c477      0
    rhs       c478      0
    rhs       c479      0
    rhs       c480      0
    rhs       c481      0
    rhs       c482      0
    rhs       c483      0
    rhs       c484      0
    rhs       c485      0
    rhs       c486      0
    rhs       c487      0
    rhs       c488      0
    rhs       c489      0
    rhs       c490      0
    rhs       c491      0
    rhs       c492      0
    rhs       c493      0
    rhs       c494      0
    rhs       c495      0
    rhs       c496      0
    rhs       c497      0
    rhs       c498      0
    rhs       c499      0
    rhs       c500      0
    rhs       c501      0
    rhs       c502      0
    rhs       c503      0
    rhs       c504      0
    rhs       c505      0
    rhs       c506      0
    rhs       c507      0
    rhs       c508      0
    rhs       c509      0
    rhs       c510      0
    rhs       c511      0
    rhs       c512      0
    rhs       c513      0
    rhs       c514      0
    rhs       c515      0
    rhs       c516      0
    rhs       c517      0
    rhs       c518      0
    rhs       c519      0
    rhs       c520      0
    rhs       c521      0
    rhs       c522      0
    rhs       c523      0
    rhs       c524      0
    rhs       c525      0
    rhs       c526      0
    rhs       c527      0
    rhs       c528      0
    rhs       c529      0
    rhs       c530      0
    rhs       c531      0
    rhs       c532      0
    rhs       c533      0
    rhs       c534      0
    rhs       c535      0
    rhs       c536      0
    rhs       c537      0
    rhs       c538      0
    rhs       c539      0
    rhs       c540      0
    rhs       c541      0
    rhs       c542      0
    rhs       c543      0
    rhs       c544      0
    rhs       c545      0
    rhs       c546      0
    rhs       c547      0
    rhs       c548      0
    rhs       c549      0
    rhs       c550      0
    rhs       c551      0
    rhs       c552      0
    rhs       c553      0
    rhs       c554      0
    rhs       c555      0
    rhs       c556      0
    rhs       c557      0
    rhs       c558      0
    rhs       c559      0
    rhs       c560      0
    rhs       c561      0
    rhs       c562      0
    rhs       c563      0
    rhs       c564      0
    rhs       c565      0
    rhs       c566      0
    rhs       c567      0
    rhs       c568      0
    rhs       c569      0
    rhs       c570      0
    rhs       c571      0
    rhs       c572      0
    rhs       c573      0
    rhs       c574      0
    rhs       c575      0
    rhs       c576      0
    rhs       c577      0
    rhs       c578      0
    rhs       c579      0
    rhs       c580      0
    rhs       c581      0
    rhs       c582      0
    rhs       c583      0
    rhs       c584      0
    rhs       c585      0
    rhs       c586      0
    rhs       c587      0
    rhs       c588      0
    rhs       c589      0
    rhs       c590      0
    rhs       c591      0
    rhs       c592      0
    rhs       c593      0
    rhs       c594      0
    rhs       c595      0
    rhs       c596      0
    rhs       c597      0
    rhs       c598      0
    rhs       c599      0
    rhs       c600      0
    rhs       c601      0
    rhs       c602      0
    rhs       c603      0
    rhs       c604      0
    rhs       c605      0
    rhs       c606      0
    rhs       c607      0
    rhs       c608      0
    rhs       c609      0
    rhs       c610      0
    rhs       c611      0
    rhs       c612      0
    rhs       c613      0
    rhs       c614      0
    rhs       c615      0
    rhs       c616      0
    rhs       c617      0
    rhs       c618      0
    rhs       c619      0
    rhs       c620      0
    rhs       c621      0
    rhs       c622      0
    rhs       c623      0
    rhs       c624      0
    rhs       c625      0
    rhs       c626      0
    rhs       c627      0
    rhs       c628      0
    rhs       c629      0
    rhs       c630      0
    rhs       c631      0
    rhs       c632      0
    rhs       c633      0
    rhs       c634      0
    rhs       c635      0
    rhs       c636      0
    rhs       c637      0
    rhs       c638      0
    rhs       c639      0
    rhs       c640      0
    rhs       c641      0
    rhs       c642      0
    rhs       c643      0
    rhs       c644      0
    rhs       c645      0
    rhs       c646      0
    rhs       c647      0
    rhs       c648      0
    rhs       c649      0
    rhs       c650      0
    rhs       c651      0
    rhs       c652      0
    rhs       c653      0
    rhs       c654      0
    rhs       c655      0
    rhs       c656      0
    rhs       c657      0
    rhs       c658      0
    rhs       c659      0
    rhs       c660      0
    rhs       c661      0
    rhs       c662      0
    rhs       c663      0
    rhs       c664      0
    rhs       c665      0
    rhs       c666      0
    rhs       c667      0
    rhs       c668      0
    rhs       c669      0
    rhs       c670      0
    rhs       c671      0
    rhs       c672      0
    rhs       c673      0
    rhs       c674      0
    rhs       c675      0
    rhs       c676      0
    rhs       c677      0
    rhs       c678      0
    rhs       c679      0
    rhs       c680      0
    rhs       c681      0
    rhs       c682      0
    rhs       c683      0
    rhs       c684      0
    rhs       c685      0
    rhs       c686      0
    rhs       c687      0
    rhs       c688      0
    rhs       c689      0
    rhs       c690      0
    rhs       c691      0
    rhs       c692      0
    rhs       c693      0
    rhs       c694      0
    rhs       c695      0
    rhs       c696      0
    rhs       c697      0
    rhs       c698      0
    rhs       c699      0
    rhs       c700      0
    rhs       c701      0
    rhs       c702      0
    rhs       c703      0
    rhs       c704      0
    rhs       c705      0
    rhs       c706      0
    rhs       c707      0
    rhs       c708      0
    rhs       c709      0
    rhs       c710      0
    rhs       c711      0
    rhs       c712      0
    rhs       c713      0
    rhs       c714      0
    rhs       c715      0
    rhs       c716      0
    rhs       c717      0
    rhs       c718      0
    rhs       c719      0
    rhs       c720      0
    rhs       c721      0
    rhs       c722      0
    rhs       c723      0
    rhs       c724      0
    rhs       c725      0
    rhs       c726      0
    rhs       c727      0
    rhs       c728      0
    rhs       c729      0
    rhs       c730      0
    rhs       c731      0
    rhs       c732      0
    rhs       c733      0
    rhs       c734      0
    rhs       c735      0
    rhs       c736      0
    rhs       c737      0
    rhs       c738      0
    rhs       c739      0
    rhs       c740      0
    rhs       c741      0
    rhs       c742      0
    rhs       c743      0
    rhs       c744      0
    rhs       c745      0
    rhs       c746      0
    rhs       c747      0
    rhs       c748      0
    rhs       c749      0
    rhs       c750      0
    rhs       c751      0
    rhs       c752      0
    rhs       c753      0
    rhs       c754      0
    rhs       c755      0
    rhs       c756      0
    rhs       c757      0
    rhs       c758      0
    rhs       c759      0
    rhs       c760      0
    rhs       c761      0
    rhs       c762      0
    rhs       c763      0
    rhs       c764      0
    rhs       c765      0
    rhs       c766      0
    rhs       c767      0
    rhs       c768      0
    rhs       c769      0
    rhs       c770      0
    rhs       c771      0
    rhs       c772      0
    rhs       c773      0
    rhs       c774      0
    rhs       c775      0
    rhs       c776      0
    rhs       c777      0
    rhs       c778      0
    rhs       c779      0
    rhs       c780      0
    rhs       c781      0
    rhs       c782      0
    rhs       c783      0
    rhs       c784      0
    rhs       c785      0
    rhs       c786      0
    rhs       c787      0
    rhs       c788      0
    rhs       c789      0
    rhs       c790      0
    rhs       c791      0
    rhs       c792      0
    rhs       c793      0
    rhs       c794      0
    rhs       c795      0
    rhs       c796      0
    rhs       c797      0
    rhs       c798      0
    rhs       c799      0
    rhs       c800      0
    rhs       c801      0
    rhs       c802      0
    rhs       c803      0
    rhs       c804      0
    rhs       c805      0
    rhs       c806      0
    rhs       c807      0
    rhs       c808      0
    rhs       c809      0
    rhs       c810      0
    rhs       c811      0
    rhs       c812      0
    rhs       c813      0
    rhs       c814      0
    rhs       c815      0
    rhs       c816      0
    rhs       c817      0
    rhs       c818      0
    rhs       c819      0
    rhs       c820      0
    rhs       c821      0
    rhs       c822      0
    rhs       c823      0
    rhs       c824      0
    rhs       c825      0
    rhs       c826      0
    rhs       c827      0
    rhs       c828      0
    rhs       c829      0
    rhs       c830      0
    rhs       c831      0
    rhs       c832      0
    rhs       c833      0
    rhs       c834      0
    rhs       c835      0
    rhs       c836      0
    rhs       c837      0
    rhs       c838      0
    rhs       c839      0
    rhs       c840      0
    rhs       c841      0
    rhs       c842      0
    rhs       c843      0
    rhs       c844      0
    rhs       c845      0
    rhs       c846      0
    rhs       c847      0
    rhs       c848      0
    rhs       c849      0
    rhs       c850      0
    rhs       c851      0
    rhs       c852      0
    rhs       c853      0
    rhs       c854      0
    rhs       c855      0
    rhs       c856      0
    rhs       c857      0
    rhs       c858      0
    rhs       c859      0
    rhs       c860      0
    rhs       c861      0
    rhs       c862      0
    rhs       c863      0
    rhs       c864      0
    rhs       c865      0
    rhs       c866      0
    rhs       c867      0
    rhs       c868      0
    rhs       c869      0
    rhs       c870      0
    rhs       c871      0
    rhs       c872      0
    rhs       c873      0
    rhs       c874      0
    rhs       c875      0
    rhs       c876      0
    rhs       c877      0
    rhs       c878      0
    rhs       c879      0
    rhs       c880      0
    rhs       c881      0
    rhs       c882      0
    rhs       c883      0
    rhs       c884      0
    rhs       c885      0
    rhs       c886      0
    rhs       c887      0
    rhs       c888      0
    rhs       c889      0
    rhs       c890      0
    rhs       c891      0
    rhs       c892      0
    rhs       c893      0
    rhs       c894      0
    rhs       c895      0
    rhs       c896      0
    rhs       c897      0
    rhs       c898      0
    rhs       c899      0
    rhs       c900      0
    rhs       c901      0
    rhs       c902      0
    rhs       c903      0
    rhs       c904      0
    rhs       c905      0
    rhs       c906      0
    rhs       c907      0
    rhs       c908      0
    rhs       c909      0
    rhs       c910      0
    rhs       c911      0
    rhs       c912      0
    rhs       c913      0
    rhs       c914      0
    rhs       c915      0
    rhs       c916      0
    rhs       c917      0
    rhs       c918      0
    rhs       c919      0
    rhs       c920      0
    rhs       c921      0
    rhs       c922      0
    rhs       c923      0
    rhs       c924      0
    rhs       c925      0
    rhs       c926      0
    rhs       c927      0
    rhs       c928      0
    rhs       c929      0
    rhs       c930      0
    rhs       c931      0
    rhs       c932      0
    rhs       c933      0
    rhs       c934      0
    rhs       c935      0
    rhs       c936      0
    rhs       c937      0
    rhs       c938      0
    rhs       c939      0
    rhs       c940      0
    rhs       c941      0
    rhs       c942      0
    rhs       c943      0
    rhs       c944      0
    rhs       c945      0
    rhs       c946      0
    rhs       c947      0
    rhs       c948      0
    rhs       c949      0
    rhs       c950      0
    rhs       c951      0
    rhs       c952      0
    rhs       c953      0
    rhs       c954      0
    rhs       c955      0
    rhs       c956      0
    rhs       c957      0
    rhs       c958      0
    rhs       c959      0
    rhs       c960      0
    rhs       c961      0
    rhs       c962      0
    rhs       c963      0
    rhs       c964      0
    rhs       c965      0
    rhs       c966      0
    rhs       c967      0
    rhs       c968      0
    rhs       c969      0
    rhs       c970      0
    rhs       c971      0
    rhs       c972      0
    rhs       c973      0
    rhs       c974      0
    rhs       c975      0
    rhs       c976      0
    rhs       c977      0
    rhs       c978      0
    rhs       c979      0
    rhs       c980      0
    rhs       c981      0
    rhs       c982      0
    rhs       c983      0
    rhs       c984      0
    rhs       c985      0
    rhs       c986      0
    rhs       c987      0
    rhs       c988      0
    rhs       c989      0
    rhs       c990      0
    rhs       c991      0
    rhs       c992      0
    rhs       c993      0
    rhs       c994      0
    rhs       c995      0
    rhs       c996      0
    rhs       c997      0
    rhs       c998      0
    rhs       c999      0
    rhs       c1000     0
    rhs       c1001     0
    rhs       c1002     0
    rhs       c1003     0
    rhs       c1004     0
    rhs       c1005     0
    rhs       c1006     0
    rhs       c1007     0
    rhs       c1008     0
    rhs       c1009     0
    rhs       c1010     0
    rhs       c1011     0
    rhs       c1012     0
    rhs       c1013     0
    rhs       c1014     0
    rhs       c1015     0
    rhs       c1016     0
    rhs       c1017     0
    rhs       c1018     0
    rhs       c1019     0
    rhs       c1020     0
    rhs       c1021     0
    rhs       c1022     0
    rhs       c1023     0
    rhs       c1024     0
    rhs       c1025     0
    rhs       c1026     0
    rhs       c1027     0
    rhs       c1028     0
    rhs       c1029     0
    rhs       c1030     0
    rhs       c1031     0
    rhs       c1032     0
    rhs       c1033     0
    rhs       c1034     0
    rhs       c1035     0
    rhs       c1036     0
    rhs       c1037     0
    rhs       c1038     0
    rhs       c1039     0
    rhs       c1040     0
    rhs       c1041     0
    rhs       c1042     0
    rhs       c1043     0
    rhs       c1044     0
    rhs       c1045     0
    rhs       c1046     0
    rhs       c1047     0
    rhs       c1048     0
    rhs       c1049     0
    rhs       c1050     0
    rhs       c1051     0
    rhs       c1052     0
    rhs       c1053     0
    rhs       c1054     0
    rhs       c1055     0
    rhs       c1056     0
    rhs       c1057     0
    rhs       c1058     0
    rhs       c1059     0
    rhs       c1060     0
    rhs       c1061     0
    rhs       c1062     0
    rhs       c1063     0
    rhs       c1064     0
    rhs       c1065     0
    rhs       c1066     0
    rhs       c1067     0
    rhs       c1068     0
    rhs       c1069     0
    rhs       c1070     0
    rhs       c1071     0
    rhs       c1072     0
    rhs       c1073     0
    rhs       c1074     0
    rhs       c1075     0
    rhs       c1076     0
    rhs       c1077     0
    rhs       c1078     0
    rhs       c1079     0
    rhs       c1080     0
    rhs       c1081     0
    rhs       c1082     0
    rhs       c1083     0
    rhs       c1084     0
    rhs       c1085     0
    rhs       c1086     0
    rhs       c1087     0
    rhs       c1088     0
    rhs       c1089     0
    rhs       c1090     0
    rhs       c1091     0
    rhs       c1092     0
    rhs       c1093     0
    rhs       c1094     0
    rhs       c1095     0
    rhs       c1096     0
    rhs       c1097     0
    rhs       c1098     0
    rhs       c1099     0
    rhs       c1100     0
    rhs       c1101     0
    rhs       c1102     0
    rhs       c1103     0
    rhs       c1104     0
    rhs       c1105     0
    rhs       c1106     0
    rhs       c1107     0
    rhs       c1108     0
    rhs       c1109     0
    rhs       c1110     0
    rhs       c1111     0
    rhs       c1112     0
    rhs       c1113     0
    rhs       c1114     0
    rhs       c1115     0
    rhs       c1116     0
    rhs       c1117     0
    rhs       c1118     0
    rhs       c1119     0
    rhs       c1120     0
    rhs       c1121     0
    rhs       c1122     0
    rhs       c1123     0
    rhs       c1124     0
    rhs       c1125     0
    rhs       c1126     0
    rhs       c1127     0
    rhs       c1128     0
    rhs       c1129     0
    rhs       c1130     0
    rhs       c1131     0
    rhs       c1132     0
    rhs       c1133     0
    rhs       c1134     0
    rhs       c1135     0
    rhs       c1136     0
    rhs       c1137     0
    rhs       c1138     0
    rhs       c1139     0
    rhs       c1140     0
    rhs       c1141     0
    rhs       c1142     0
    rhs       c1143     0
    rhs       c1144     0
    rhs       c1145     0
    rhs       c1146     0
    rhs       c1147     0
    rhs       c1148     0
    rhs       c1149     0
    rhs       c1150     0
    rhs       c1151     0
    rhs       c1152     0
    rhs       c1153     0
    rhs       c1154     0
    rhs       c1155     0
    rhs       c1156     0
    rhs       c1157     0
    rhs       c1158     0
    rhs       c1159     0
    rhs       c1160     0
    rhs       c1161     0
    rhs       c1162     0
    rhs       c1163     0
    rhs       c1164     0
    rhs       c1165     0
    rhs       c1166     0
    rhs       c1167     0
    rhs       c1168     0
    rhs       c1169     0
    rhs       c1170     0
    rhs       c1171     0
    rhs       c1172     0
    rhs       c1173     0
    rhs       c1174     0
    rhs       c1175     0
    rhs       c1176     0
    rhs       c1177     0
    rhs       c1178     0
    rhs       c1179     0
    rhs       c1180     0
    rhs       c1181     0
    rhs       c1182     0
    rhs       c1183     0
    rhs       c1184     0
    rhs       c1185     0
    rhs       c1186     0
    rhs       c1187     0
    rhs       c1188     0
    rhs       c1189     0
    rhs       c1190     0
    rhs       c1191     0
    rhs       c1192     0
    rhs       c1193     0
    rhs       c1194     0
    rhs       c1195     0
    rhs       c1196     0
    rhs       c1197     0
    rhs       c1198     0
    rhs       c1199     0
    rhs       c1200     0
    rhs       c1201     0
    rhs       c1202     0
    rhs       c1203     0
    rhs       c1204     0
    rhs       c1205     0
    rhs       c1206     0
    rhs       c1207     0
    rhs       c1208     0
    rhs       c1209     0
    rhs       c1210     0
    rhs       c1211     0
    rhs       c1212     0
    rhs       c1213     0
    rhs       c1214     0
    rhs       c1215     0
    rhs       c1216     0
    rhs       c1217     0
    rhs       c1218     0
    rhs       c1219     0
    rhs       c1220     0
    rhs       c1221     0
    rhs       c1222     0
    rhs       c1223     0
    rhs       c1224     0
    rhs       c1225     0
    rhs       c1226     0
    rhs       c1227     0
    rhs       c1228     0
    rhs       c1229     0
    rhs       c1230     0
    rhs       c1231     0
    rhs       c1232     0
    rhs       c1233     0
    rhs       c1234     0
    rhs       c1235     0
    rhs       c1236     0
    rhs       c1237     0
    rhs       c1238     0
    rhs       c1239     0
    rhs       c1240     0
    rhs       c1241     0
    rhs       c1242     0
    rhs       c1243     0
    rhs       c1244     0
    rhs       c1245     0
    rhs       c1246     0
    rhs       c1247     0
    rhs       c1248     0
    rhs       c1249     0
    rhs       c1250     0
    rhs       c1251     0
    rhs       c1252     0
    rhs       c1253     0
    rhs       c1254     0
    rhs       c1255     0
    rhs       c1256     0
    rhs       c1257     0
    rhs       c1258     0
    rhs       c1259     0
    rhs       c1260     0
    rhs       c1261     0
    rhs       c1262     0
    rhs       c1263     0
    rhs       c1264     0
    rhs       c1265     0
    rhs       c1266     0
    rhs       c1267     0
    rhs       c1268     0
    rhs       c1269     0
    rhs       c1270     0
    rhs       c1271     0
    rhs       c1272     0
    rhs       c1273     0
    rhs       c1274     0
    rhs       c1275     0
    rhs       c1276     0
    rhs       c1277     0
    rhs       c1278     0
    rhs       c1279     0
    rhs       c1280     0
    rhs       c1281     0
    rhs       c1282     0
    rhs       c1283     0
    rhs       c1284     0
    rhs       c1285     0
    rhs       c1286     0
    rhs       c1287     0
    rhs       c1288     0
    rhs       c1289     0
    rhs       c1290     0
    rhs       c1291     0
    rhs       c1292     0
    rhs       c1293     0
    rhs       c1294     0
    rhs       c1295     0
    rhs       c1296     0
    rhs       c1297     0
    rhs       c1298     0
    rhs       c1299     0
    rhs       c1300     0
    rhs       c1301     0
    rhs       c1302     0
    rhs       c1303     0
    rhs       c1304     0
    rhs       c1305     0
    rhs       c1306     0
    rhs       c1307     0
    rhs       c1308     0
    rhs       c1309     0
    rhs       c1310     0
    rhs       c1311     0
    rhs       c1312     0
    rhs       c1313     0
    rhs       c1314     0
    rhs       c1315     0
    rhs       c1316     0
    rhs       c1317     0
    rhs       c1318     0
    rhs       c1319     0
    rhs       c1320     0
    rhs       c1321     0
    rhs       c1322     0
    rhs       c1323     0
    rhs       c1324     0
    rhs       c1325     0
    rhs       c1326     0
    rhs       c1327     0
    rhs       c1328     0
    rhs       c1329     0
    rhs       c1330     0
    rhs       c1331     0
    rhs       c1332     0
    rhs       c1333     0
    rhs       c1334     0
    rhs       c1335     0
    rhs       c1336     0
    rhs       c1337     0
    rhs       c1338     0
    rhs       c1339     0
    rhs       c1340     0
    rhs       c1341     0
    rhs       c1342     0
    rhs       c1343     0
    rhs       c1344     0
    rhs       c1345     0
    rhs       c1346     0
    rhs       c1347     0
    rhs       c1348     0
    rhs       c1349     0
    rhs       c1350     0
    rhs       c1351     0
    rhs       c1352     0
    rhs       c1353     0
    rhs       c1354     0
    rhs       c1355     0
    rhs       c1356     0
    rhs       c1357     0
    rhs       c1358     0
    rhs       c1359     0
    rhs       c1360     0
    rhs       c1361     0
    rhs       c1362     0
    rhs       c1363     0
    rhs       c1364     0
    rhs       c1365     0
    rhs       c1366     0
    rhs       c1367     0
    rhs       c1368     0
    rhs       c1369     0
    rhs       c1370     0
    rhs       c1371     0
    rhs       c1372     0
    rhs       c1373     0
    rhs       c1374     0
    rhs       c1375     0
    rhs       c1376     0
    rhs       c1377     0
    rhs       c1378     0
    rhs       c1379     0
    rhs       c1380     0
    rhs       c1381     0
    rhs       c1382     0
    rhs       c1383     0
    rhs       c1384     0
    rhs       c1385     0
    rhs       c1386     0
    rhs       c1387     0
    rhs       c1388     0
    rhs       c1389     0
    rhs       c1390     0
    rhs       c1391     0
    rhs       c1392     0
    rhs       c1393     0
    rhs       c1394     0
    rhs       c1395     0
    rhs       c1396     0
    rhs       c1397     0
    rhs       c1398     0
    rhs       c1399     0
    rhs       c1400     0
    rhs       c1401     0
    rhs       c1402     0
    rhs       c1403     0
    rhs       c1404     0
    rhs       c1405     0
    rhs       c1406     0
    rhs       c1407     0
    rhs       c1408     0
    rhs       c1409     0
    rhs       c1410     0
    rhs       c1411     0
    rhs       c1412     0
    rhs       c1413     0
    rhs       c1414     0
    rhs       c1415     0
    rhs       c1416     0
    rhs       c1417     0
    rhs       c1418     0
    rhs       c1419     0
    rhs       c1420     0
    rhs       c1421     0
    rhs       c1422     0
    rhs       c1423     0
    rhs       c1424     0
    rhs       c1425     0
    rhs       c1426     0
    rhs       c1427     0
    rhs       c1428     0
    rhs       c1429     0
    rhs       c1430     0
    rhs       c1431     0
    rhs       c1432     0
    rhs       c1433     0
    rhs       c1434     0
    rhs       c1435     0
    rhs       c1436     0
    rhs       c1437     0
    rhs       c1438     0
    rhs       c1439     0
    rhs       c1440     0
    rhs       c1441     0
    rhs       c1442     0
    rhs       c1443     0
    rhs       c1444     0
    rhs       c1445     0
    rhs       c1446     0
    rhs       c1447     0
    rhs       c1448     0
    rhs       c1449     0
    rhs       c1450     0
    rhs       c1451     0
    rhs       c1452     0
    rhs       c1453     0
    rhs       c1454     0
    rhs       c1455     0
    rhs       c1456     0
    rhs       c1457     0
    rhs       c1458     0
    rhs       c1459     0
    rhs       c1460     0
    rhs       c1461     0
    rhs       c1462     0
    rhs       c1463     0
    rhs       c1464     0
    rhs       c1465     0
    rhs       c1466     0
    rhs       c1467     0
    rhs       c1468     0
    rhs       c1469     0
    rhs       c1470     0
    rhs       c1471     0
    rhs       c1472     0
    rhs       c1473     0
    rhs       c1474     0
    rhs       c1475     0
    rhs       c1476     0
    rhs       c1477     0
    rhs       c1478     0
    rhs       c1479     0
    rhs       c1480     0
    rhs       c1481     0
    rhs       c1482     0
    rhs       c1483     0
    rhs       c1484     0
    rhs       c1485     0
    rhs       c1486     0
    rhs       c1487     0
    rhs       c1488     0
    rhs       c1489     0
    rhs       c1490     0
    rhs       c1491     0
    rhs       c1492     0
    rhs       c1493     0
    rhs       c1494     0
    rhs       c1495     0
    rhs       c1496     0
    rhs       c1497     0
    rhs       c1498     0
    rhs       c1499     0
    rhs       c1500     0
    rhs       c1501     0
    rhs       c1502     0
    rhs       c1503     0
    rhs       c1504     0
    rhs       c1505     0
    rhs       c1506     0
    rhs       c1507     0
    rhs       c1508     0
    rhs       c1509     0
    rhs       c1510     0
    rhs       c1511     0
    rhs       c1512     0
    rhs       c1513     0
    rhs       c1514     0
    rhs       c1515     0
    rhs       c1516     0
    rhs       c1517     0
    rhs       c1518     0
    rhs       c1519     0
    rhs       c1520     0
    rhs       c1521     0
    rhs       c1522     0
    rhs       c1523     0
    rhs       c1524     0
    rhs       c1525     0
    rhs       c1526     0
    rhs       c1527     0
    rhs       c1528     0
    rhs       c1529     0
    rhs       c1530     0
    rhs       c1531     0
    rhs       c1532     0
    rhs       c1533     0
    rhs       c1534     0
    rhs       c1535     0
    rhs       c1536     0
    rhs       c1537     0
    rhs       c1538     0
    rhs       c1539     0
    rhs       c1540     0
    rhs       c1541     0
    rhs       c1542     0
    rhs       c1543     0
    rhs       c1544     0
    rhs       c1545     0
    rhs       c1546     0
    rhs       c1547     0
    rhs       c1548     0
    rhs       c1549     0
    rhs       c1550     0
    rhs       c1551     0
    rhs       c1552     0
    rhs       c1553     0
    rhs       c1554     0
    rhs       c1555     0
    rhs       c1556     0
    rhs       c1557     0
    rhs       c1558     0
    rhs       c1559     0
    rhs       c1560     0
    rhs       c1561     0
    rhs       c1562     0
    rhs       c1563     0
    rhs       c1564     0
    rhs       c1565     0
    rhs       c1566     0
    rhs       c1567     0
    rhs       c1568     0
    rhs       c1569     0
    rhs       c1570     0
    rhs       c1571     0
    rhs       c1572     0
    rhs       c1573     0
    rhs       c1574     0
    rhs       c1575     0
    rhs       c1576     0
    rhs       c1577     0
    rhs       c1578     0
    rhs       c1579     0
    rhs       c1580     0
    rhs       c1581     0
    rhs       c1582     0
    rhs       c1583     0
    rhs       c1584     0
    rhs       c1585     0
    rhs       c1586     0
    rhs       c1587     0
    rhs       c1588     0
    rhs       c1589     0
    rhs       c1590     0
    rhs       c1591     0
    rhs       c1592     0
    rhs       c1593     0
    rhs       c1594     0
    rhs       c1595     0
    rhs       c1596     0
    rhs       c1597     0
    rhs       c1598     0
    rhs       c1599     0
    rhs       c1600     0
    rhs       c1601     0
    rhs       c1602     0
    rhs       c1603     0
    rhs       c1604     0
    rhs       c1605     0
    rhs       c1606     0
    rhs       c1607     0
    rhs       c1608     0
    rhs       c1609     0
    rhs       c1610     0
    rhs       c1611     0
    rhs       c1612     0
    rhs       c1613     0
    rhs       c1614     0
    rhs       c1615     0
    rhs       c1616     0
    rhs       c1617     0
    rhs       c1618     0
    rhs       c1619     0
    rhs       c1620     0
    rhs       c1621     0
    rhs       c1622     0
    rhs       c1623     0
    rhs       c1624     0
    rhs       c1625     0
    rhs       c1626     0
    rhs       c1627     0
    rhs       c1628     0
    rhs       c1629     0
    rhs       c1630     0
    rhs       c1631     0
    rhs       c1632     0
    rhs       c1633     0
    rhs       c1634     0
    rhs       c1635     0
    rhs       c1636     0
    rhs       c1637     0
    rhs       c1638     0
    rhs       c1639     0
    rhs       c1640     0
    rhs       c1641     0
    rhs       c1642     0
    rhs       c1643     0
    rhs       c1644     0
    rhs       c1645     0
    rhs       c1646     0
    rhs       c1647     0
    rhs       c1648     0
    rhs       c1649     0
    rhs       c1650     0
    rhs       c1651     0
    rhs       c1652     0
    rhs       c1653     0
    rhs       c1654     0
    rhs       c1655     0
    rhs       c1656     0
    rhs       c1657     0
    rhs       c1658     0
    rhs       c1659     0
    rhs       c1660     0
    rhs       c1661     0
    rhs       c1662     0
    rhs       c1663     0
    rhs       c1664     0
    rhs       c1665     0
    rhs       c1666     0
    rhs       c1667     0
    rhs       c1668     0
    rhs       c1669     0
    rhs       c1670     0
    rhs       c1671     0
    rhs       c1672     0
    rhs       c1673     0
    rhs       c1674     0
    rhs       c1675     0
    rhs       c1676     0
    rhs       c1677     0
    rhs       c1678     0
    rhs       c1679     0
    rhs       c1680     0
    rhs       c1681     0
    rhs       c1682     0
    rhs       c1683     0
    rhs       c1684     0
    rhs       c1685     0
    rhs       c1686     0
    rhs       c1687     0
    rhs       c1688     0
    rhs       c1689     0
    rhs       c1690     0
    rhs       c1691     0
    rhs       c1692     0
    rhs       c1693     0
    rhs       c1694     0
    rhs       c1695     0
    rhs       c1696     0
    rhs       c1697     0
    rhs       c1698     0
    rhs       c1699     0
    rhs       c1700     0
    rhs       c1701     0
    rhs       c1702     0
    rhs       c1703     0
    rhs       c1704     0
    rhs       c1705     0
    rhs       c1706     0
    rhs       c1707     0
    rhs       c1708     0
    rhs       c1709     0
    rhs       c1710     0
    rhs       c1711     0
    rhs       c1712     0
    rhs       c1713     0
    rhs       c1714     0
    rhs       c1715     0
    rhs       c1716     0
    rhs       c1717     0
    rhs       c1718     0
    rhs       c1719     0
    rhs       c1720     0
    rhs       c1721     0
    rhs       c1722     0
    rhs       c1723     0
    rhs       c1724     0
    rhs       c1725     0
    rhs       c1726     0
    rhs       c1727     0
    rhs       c1728     0
    rhs       c1729     0
    rhs       c1730     0
    rhs       c1731     0
    rhs       c1732     0
    rhs       c1733     0
    rhs       c1734     0
    rhs       c1735     0
    rhs       c1736     0
    rhs       c1737     0
    rhs       c1738     0
    rhs       c1739     0
    rhs       c1740     0
    rhs       c1741     0
    rhs       c1742     0
    rhs       c1743     0
    rhs       c1744     0
    rhs       c1745     0
    rhs       c1746     0
    rhs       c1747     0
    rhs       c1748     0
    rhs       c1749     0
    rhs       c1750     0
    rhs       c1751     0
    rhs       c1752     0
    rhs       c1753     0
    rhs       c1754     0
    rhs       c1755     0
    rhs       c1756     0
    rhs       c1757     0
    rhs       c1758     0
    rhs       c1759     0
    rhs       c1760     0
    rhs       c1761     0
    rhs       c1762     0
    rhs       c1763     0
    rhs       c1764     0
    rhs       c1765     0
    rhs       c1766     0
    rhs       c1767     0
    rhs       c1768     0
    rhs       c1769     0
    rhs       c1770     0
    rhs       c1771     0
    rhs       c1772     0
    rhs       c1773     0
    rhs       c1774     0
    rhs       c1775     0
    rhs       c1776     0
    rhs       c1777     0
    rhs       c1778     0
    rhs       c1779     0
    rhs       c1780     0
    rhs       c1781     0
    rhs       c1782     0
    rhs       c1783     0
    rhs       c1784     0
    rhs       c1785     0
    rhs       c1786     0
    rhs       c1787     0
    rhs       c1788     0
    rhs       c1789     0
    rhs       c1790     0
    rhs       c1791     0
    rhs       c1792     0
    rhs       c1793     0
    rhs       c1794     0
    rhs       c1795     0
    rhs       c1796     0
    rhs       c1797     0
    rhs       c1798     0
    rhs       c1799     0
    rhs       c1800     0
    rhs       c1801     0
    rhs       c1802     0
    rhs       c1803     0
    rhs       c1804     0
    rhs       c1805     0
    rhs       c1806     0
    rhs       c1807     0
    rhs       c1808     0
    rhs       c1809     0
    rhs       c1810     0
    rhs       c1811     0
    rhs       c1812     0
    rhs       c1813     0
    rhs       c1814     0
    rhs       c1815     0
    rhs       c1816     0
    rhs       c1817     0
    rhs       c1818     0
    rhs       c1819     0
    rhs       c1820     0
    rhs       c1821     0
    rhs       c1822     0
    rhs       c1823     0
    rhs       c1824     0
    rhs       c1825     0
    rhs       c1826     0
    rhs       c1827     0
    rhs       c1828     0
    rhs       c1829     0
    rhs       c1830     0
    rhs       c1831     0
    rhs       c1832     0
    rhs       c1833     0
    rhs       c1834     0
    rhs       c1835     0
    rhs       c1836     0
    rhs       c1837     0
    rhs       c1838     0
    rhs       c1839     0
    rhs       c1840     0
    rhs       c1841     0
    rhs       c1842     0
    rhs       c1843     0
    rhs       c1844     0
    rhs       c1845     0
    rhs       c1846     0
    rhs       c1847     0
    rhs       c1848     0
    rhs       c1849     0
    rhs       c1850     0
    rhs       c1851     0
    rhs       c1852     0
    rhs       c1853     0
    rhs       c1854     0
    rhs       c1855     0
    rhs       c1856     0
    rhs       c1857     0
    rhs       c1858     0
    rhs       c1859     0
    rhs       c1860     0
    rhs       c1861     0
    rhs       c1862     0
    rhs       c1863     0
    rhs       c1864     0
    rhs       c1865     0
    rhs       c1866     0
    rhs       c1867     0
    rhs       c1868     0
    rhs       c1869     0
    rhs       c1870     0
    rhs       c1871     0
    rhs       c1872     0
    rhs       c1873     0
    rhs       c1874     0
    rhs       c1875     0
    rhs       c1876     0
    rhs       c1877     0
    rhs       c1878     0
    rhs       c1879     0
    rhs       c1880     0
    rhs       c1881     0
    rhs       c1882     0
    rhs       c1883     0
    rhs       c1884     0
    rhs       c1885     0
    rhs       c1886     0
    rhs       c1887     0
    rhs       c1888     0
    rhs       c1889     0
    rhs       c1890     0
    rhs       c1891     0
    rhs       c1892     0
    rhs       c1893     0
    rhs       c1894     0
    rhs       c1895     0
    rhs       c1896     0
    rhs       c1897     0
    rhs       c1898     0
    rhs       c1899     0
    rhs       c1900     0
    rhs       c1901     0
    rhs       c1902     0
    rhs       c1903     0
    rhs       c1904     0
    rhs       c1905     0
    rhs       c1906     0
    rhs       c1907     0
    rhs       c1908     0
    rhs       c1909     0
    rhs       c1910     0
    rhs       c1911     0
    rhs       c1912     0
    rhs       c1913     0
    rhs       c1914     0
    rhs       c1915     0
    rhs       c1916     0
    rhs       c1917     0
    rhs       c1918     0
    rhs       c1919     0
    rhs       c1920     0
    rhs       c1921     0
    rhs       c1922     0
    rhs       c1923     0
    rhs       c1924     0
    rhs       c1925     0
    rhs       c1926     0
    rhs       c1927     0
    rhs       c1928     0
    rhs       c1929     0
    rhs       c1930     0
    rhs       c1931     0
    rhs       c1932     0
    rhs       c1933     0
    rhs       c1934     0
    rhs       c1935     0
    rhs       c1936     0
    rhs       c1937     0
    rhs       c1938     0
    rhs       c1939     0
    rhs       c1940     0
    rhs       c1941     0
    rhs       c1942     0
    rhs       c1943     0
    rhs       c1944     0
    rhs       c1945     0
    rhs       c1946     0
    rhs       c1947     0
    rhs       c1948     0
    rhs       c1949     0
    rhs       c1950     0
    rhs       c1951     0
    rhs       c1952     0
    rhs       c1953     0
    rhs       c1954     0
    rhs       c1955     0
    rhs       c1956     0
    rhs       c1957     0
    rhs       c1958     0
    rhs       c1959     0
    rhs       c1960     0
    rhs       c1961     0
    rhs       c1962     0
    rhs       c1963     0
    rhs       c1964     0
    rhs       c1965     0
    rhs       c1966     0
    rhs       c1967     0
    rhs       c1968     0
    rhs       c1969     0
    rhs       c1970     0
    rhs       c1971     0
    rhs       c1972     0
    rhs       c1973     0
    rhs       c1974     0
    rhs       c1975     0
    rhs       c1976     0
    rhs       c1977     0
    rhs       c1978     0
    rhs       c1979     0
    rhs       c1980     0
    rhs       c1981     0
    rhs       c1982     0
    rhs       c1983     0
    rhs       c1984     0
    rhs       c1985     0
    rhs       c1986     0
    rhs       c1987     0
    rhs       c1988     0
    rhs       c1989     0
    rhs       c1990     0
    rhs       c1991     0
    rhs       c1992     0
    rhs       c1993     0
    rhs       c1994     0
    rhs       c1995     0
    rhs       c1996     0
    rhs       c1997     0
    rhs       c1998     0
    rhs       c1999     0
    rhs       c2000     0
    rhs       c2001     0
    rhs       c2002     0
    rhs       c2003     0
    rhs       c2004     0
    rhs       c2005     0
    rhs       c2006     0
    rhs       c2007     0
    rhs       c2008     0
    rhs       c2009     0
    rhs       c2010     0
    rhs       c2011     0
    rhs       c2012     0
    rhs       c2013     0
    rhs       c2014     0
    rhs       c2015     0
    rhs       c2016     0
    rhs       c2017     0
    rhs       c2018     0
    rhs       c2019     0
    rhs       c2020     0
    rhs       c2021     0
    rhs       c2022     0
    rhs       c2023     0
    rhs       c2024     0
    rhs       c2025     0
    rhs       c2026     0
    rhs       c2027     0
    rhs       c2028     0
    rhs       c2029     0
    rhs       c2030     0
    rhs       c2031     0
    rhs       c2032     0
    rhs       c2033     0
    rhs       c2034     0
    rhs       c2035     0
    rhs       c2036     0
    rhs       c2037     0
    rhs       c2038     0
    rhs       c2039     0
    rhs       c2040     0
    rhs       c2041     0
    rhs       c2042     0
    rhs       c2043     0
    rhs       c2044     0
    rhs       c2045     0
    rhs       c2046     0
    rhs       c2047     0
    rhs       c2048     0
    rhs       c2049     0
    rhs       c2050     0
    rhs       c2051     0
    rhs       c2052     0
    rhs       c2053     0
    rhs       c2054     0
    rhs       c2055     0
    rhs       c2056     0
    rhs       c2057     0
    rhs       c2058     0
    rhs       c2059     0
    rhs       c2060     0
    rhs       c2061     0
    rhs       c2062     0
    rhs       c2063     0
    rhs       c2064     0
    rhs       c2065     0
    rhs       c2066     0
    rhs       c2067     0
    rhs       c2068     0
    rhs       c2069     0
    rhs       c2070     0
    rhs       c2071     0
    rhs       c2072     0
    rhs       c2073     0
    rhs       c2074     0
    rhs       c2075     0
    rhs       c2076     0
    rhs       c2077     0
    rhs       c2078     0
    rhs       c2079     0
    rhs       c2080     0
    rhs       c2081     0
    rhs       c2082     0
    rhs       c2083     0
    rhs       c2084     0
    rhs       c2085     0
    rhs       c2086     0
    rhs       c2087     0
    rhs       c2088     0
    rhs       c2089     0
    rhs       c2090     0
    rhs       c2091     0
    rhs       c2092     0
    rhs       c2093     0
    rhs       c2094     0
    rhs       c2095     0
    rhs       c2096     0
    rhs       c2097     0
    rhs       c2098     0
    rhs       c2099     0
    rhs       c2100     0
    rhs       c2101     0
    rhs       c2102     0
    rhs       c2103     0
    rhs       c2104     0
    rhs       c2105     0
    rhs       c2106     0
    rhs       c2107     0
    rhs       c2108     0
    rhs       c2109     0
    rhs       c2110     0
    rhs       c2111     0
    rhs       c2112     0
    rhs       c2113     0
    rhs       c2114     0
    rhs       c2115     0
    rhs       c2116     0
    rhs       c2117     0
    rhs       c2118     0
    rhs       c2119     0
    rhs       c2120     0
    rhs       c2121     0
    rhs       c2122     0
    rhs       c2123     0
    rhs       c2124     0
    rhs       c2125     0
    rhs       c2126     0
    rhs       c2127     0
    rhs       c2128     0
    rhs       c2129     0
    rhs       c2130     0
    rhs       c2131     0
    rhs       c2132     0
    rhs       c2133     0
    rhs       c2134     0
    rhs       c2135     0
    rhs       c2136     0
    rhs       c2137     0
    rhs       c2138     0
    rhs       c2139     0
    rhs       c2140     0
    rhs       c2141     0
    rhs       c2142     0
    rhs       c2143     0
    rhs       c2144     0
    rhs       c2145     0
    rhs       c2146     0
    rhs       c2147     0
    rhs       c2148     0
    rhs       c2149     0
    rhs       c2150     0
    rhs       c2151     0
    rhs       c2152     0
    rhs       c2153     0
    rhs       c2154     0
    rhs       c2155     0
    rhs       c2156     0
    rhs       c2157     0
    rhs       c2158     0
    rhs       c2159     0
    rhs       c2160     0
    rhs       c2161     0
    rhs       c2162     0
    rhs       c2163     0
    rhs       c2164     0
    rhs       c2165     0
    rhs       c2166     0
    rhs       c2167     0
    rhs       c2168     0
    rhs       c2169     0
    rhs       c2170     0
    rhs       c2171     0
    rhs       c2172     0
    rhs       c2173     0
    rhs       c2174     0
    rhs       c2175     0
    rhs       c2176     0
    rhs       c2177     0
    rhs       c2178     0
    rhs       c2179     0
    rhs       c2180     0
    rhs       c2181     0
    rhs       c2182     0
    rhs       c2183     0
    rhs       c2184     0
    rhs       c2185     0
    rhs       c2186     0
    rhs       c2187     0
    rhs       c2188     0
    rhs       c2189     0
    rhs       c2190     0
    rhs       c2191     0
    rhs       c2192     0
    rhs       c2193     0
    rhs       c2194     0
    rhs       c2195     0
    rhs       c2196     0
    rhs       c2197     0
    rhs       c2198     0
    rhs       c2199     0
    rhs       c2200     0
    rhs       c2201     0
    rhs       c2202     0
    rhs       c2203     0
    rhs       c2204     0
    rhs       c2205     0
    rhs       c2206     0
    rhs       c2207     0
    rhs       c2208     0
    rhs       c2209     0
    rhs       c2210     0
    rhs       c2211     0
    rhs       c2212     0
    rhs       c2213     0
    rhs       c2214     0
    rhs       c2215     0
    rhs       c2216     0
    rhs       c2217     0
    rhs       c2218     0
    rhs       c2219     0
    rhs       c2220     0
    rhs       c2221     0
    rhs       c2222     0
    rhs       c2223     0
    rhs       c2224     0
    rhs       c2225     0
    rhs       c2226     0
    rhs       c2227     0
    rhs       c2228     0
    rhs       c2229     0
    rhs       c2230     0
    rhs       c2231     0
    rhs       c2232     0
    rhs       c2233     0
    rhs       c2234     0
    rhs       c2235     0
    rhs       c2236     0
    rhs       c2237     0
    rhs       c2238     0
    rhs       c2239     0
    rhs       c2240     0
    rhs       c2241     0
    rhs       c2242     0
    rhs       c2243     0
    rhs       c2244     0
    rhs       c2245     0
    rhs       c2246     0
    rhs       c2247     0
    rhs       c2248     0
    rhs       c2249     0
    rhs       c2250     0
    rhs       c2251     0
    rhs       c2252     0
    rhs       c2253     0
    rhs       c2254     0
    rhs       c2255     0
    rhs       c2256     0
    rhs       c2257     0
    rhs       c2258     0
    rhs       c2259     0
    rhs       c2260     0
    rhs       c2261     0
    rhs       c2262     0
    rhs       c2263     0
    rhs       c2264     0
    rhs       c2265     0
    rhs       c2266     0
    rhs       c2267     0
    rhs       c2268     0
    rhs       c2269     0
    rhs       c2270     0
    rhs       c2271     0
    rhs       c2272     0
    rhs       c2273     0
    rhs       c2274     0
    rhs       c2275     0
    rhs       c2276     0
    rhs       c2277     0
    rhs       c2278     0
    rhs       c2279     0
    rhs       c2280     0
    rhs       c2281     0
    rhs       c2282     0
    rhs       c2283     0
    rhs       c2284     0
    rhs       c2285     0
    rhs       c2286     0
    rhs       c2287     0
    rhs       c2288     0
    rhs       c2289     0
    rhs       c2290     0
    rhs       c2291     0
    rhs       c2292     0
    rhs       c2293     0
    rhs       c2294     0
    rhs       c2295     0
    rhs       c2296     0
    rhs       c2297     0
    rhs       c2298     0
    rhs       c2299     0
    rhs       c2300     0
    rhs       c2301     0
    rhs       c2302     0
    rhs       c2303     0
    rhs       c2304     0
    rhs       c2305     0
    rhs       c2306     0
    rhs       c2307     0
    rhs       c2308     0
    rhs       c2309     0
    rhs       c2310     0
    rhs       c2311     0
    rhs       c2312     0
    rhs       c2313     0
    rhs       c2314     0
    rhs       c2315     0
    rhs       c2316     0
    rhs       c2317     0
    rhs       c2318     0
    rhs       c2319     0
    rhs       c2320     0
    rhs       c2321     0
    rhs       c2322     0
    rhs       c2323     0
    rhs       c2324     0
    rhs       c2325     0
    rhs       c2326     0
    rhs       c2327     0
    rhs       c2328     0
    rhs       c2329     0
    rhs       c2330     0
    rhs       c2331     0
    rhs       c2332     0
    rhs       c2333     0
    rhs       c2334     0
    rhs       c2335     0
    rhs       c2336     0
    rhs       c2337     0
    rhs       c2338     0
    rhs       c2339     0
    rhs       c2340     0
    rhs       c2341     0
    rhs       c2342     0
    rhs       c2343     0
    rhs       c2344     0
    rhs       c2345     0
    rhs       c2346     0
    rhs       c2347     0
    rhs       c2348     0
    rhs       c2349     0
    rhs       c2350     0
    rhs       c2351     0
    rhs       c2352     0
    rhs       c2353     0
    rhs       c2354     0
    rhs       c2355     0
    rhs       c2356     0
    rhs       c2357     0
    rhs       c2358     0
    rhs       c2359     0
    rhs       c2360     0
    rhs       c2361     0
    rhs       c2362     0
    rhs       c2363     0
    rhs       c2364     0
    rhs       c2365     0
    rhs       c2366     0
    rhs       c2367     0
    rhs       c2368     0
    rhs       c2369     0
    rhs       c2370     0
    rhs       c2371     0
    rhs       c2372     0
    rhs       c2373     0
    rhs       c2374     0
    rhs       c2375     0
    rhs       c2376     0
    rhs       c2377     0
    rhs       c2378     0
    rhs       c2379     0
    rhs       c2380     0
    rhs       c2381     0
    rhs       c2382     0
    rhs       c2383     0
    rhs       c2384     0
    rhs       c2385     0
    rhs       c2386     0
    rhs       c2387     0
    rhs       c2388     0
    rhs       c2389     0
    rhs       c2390     0
    rhs       c2391     0
    rhs       c2392     0
    rhs       c2393     0
    rhs       c2394     0
    rhs       c2395     0
    rhs       c2396     0
    rhs       c2397     0
    rhs       c2398     0
    rhs       c2399     0
    rhs       c2400     0
    rhs       c2401     0
    rhs       c2402     0
    rhs       c2403     0
    rhs       c2404     0
    rhs       c2405     0
    rhs       c2406     0
    rhs       c2407     0
    rhs       c2408     0
    rhs       c2409     0
    rhs       c2410     0
    rhs       c2411     0
    rhs       c2412     0
    rhs       c2413     0
    rhs       c2414     0
    rhs       c2415     0
    rhs       c2416     0
    rhs       c2417     0
    rhs       c2418     0
    rhs       c2419     0
    rhs       c2420     0
    rhs       c2421     0
    rhs       c2422     0
    rhs       c2423     0
    rhs       c2424     0
    rhs       c2425     0
    rhs       c2426     0
    rhs       c2427     0
    rhs       c2428     0
    rhs       c2429     0
    rhs       c2430     0
    rhs       c2431     0
    rhs       c2432     0
    rhs       c2433     0
    rhs       c2434     0
    rhs       c2435     0
    rhs       c2436     0
    rhs       c2437     0
    rhs       c2438     0
    rhs       c2439     0
    rhs       c2440     0
    rhs       c2441     0
    rhs       c2442     0
    rhs       c2443     0
    rhs       c2444     0
    rhs       c2445     0
    rhs       c2446     0
    rhs       c2447     0
    rhs       c2448     0
    rhs       c2449     0
    rhs       c2450     0
    rhs       c2451     0
    rhs       c2452     0
    rhs       c2453     0
    rhs       c2454     0
    rhs       c2455     0
    rhs       c2456     0
    rhs       c2457     0
    rhs       c2458     0
    rhs       c2459     0
    rhs       c2460     0
    rhs       c2461     0
    rhs       c2462     0
    rhs       c2463     0
    rhs       c2464     0
    rhs       c2465     0
    rhs       c2466     0
    rhs       c2467     0
    rhs       c2468     0
    rhs       c2469     0
    rhs       c2470     0
    rhs       c2471     0
    rhs       c2472     0
    rhs       c2473     0
    rhs       c2474     0
    rhs       c2475     0
    rhs       c2476     0
    rhs       c2477     0
    rhs       c2478     0
    rhs       c2479     0
    rhs       c2480     0
    rhs       c2481     0
    rhs       c2482     0
    rhs       c2483     0
    rhs       c2484     0
    rhs       c2485     0
    rhs       c2486     0
    rhs       c2487     0
    rhs       c2488     0
    rhs       c2489     0
    rhs       c2490     0
    rhs       c2491     0
    rhs       c2492     0
    rhs       c2493     0
    rhs       c2494     0
    rhs       c2495     0
    rhs       c2496     0
    rhs       c2497     0
    rhs       c2498     0
    rhs       c2499     0
    rhs       c2500     0
    rhs       c2501     0
    rhs       c2502     0
    rhs       c2503     0
    rhs       c2504     0
    rhs       c2505     0
    rhs       c2506     0
    rhs       c2507     0
    rhs       c2508     0
    rhs       c2509     0
    rhs       c2510     0
    rhs       c2511     0
    rhs       c2512     0
    rhs       c2513     0
    rhs       c2514     0
    rhs       c2515     0
    rhs       c2516     0
    rhs       c2517     0
    rhs       c2518     0
    rhs       c2519     0
    rhs       c2520     0
    rhs       c2521     0
    rhs       c2522     0
    rhs       c2523     0
    rhs       c2524     0
    rhs       c2525     0
    rhs       c2526     0
    rhs       c2527     0
    rhs       c2528     0
    rhs       c2529     0
    rhs       c2530     0
    rhs       c2531     0
    rhs       c2532     0
    rhs       c2533     0
    rhs       c2534     0
    rhs       c2535     0
    rhs       c2536     0
    rhs       c2537     0
    rhs       c2538     0
    rhs       c2539     0
    rhs       c2540     0
    rhs       c2541     0
    rhs       c2542     0
    rhs       c2543     0
    rhs       c2544     0
    rhs       c2545     0
    rhs       c2546     0
    rhs       c2547     0
    rhs       c2548     0
    rhs       c2549     0
    rhs       c2550     0
    rhs       c2551     0
    rhs       c2552     0
    rhs       c2553     0
    rhs       c2554     0
    rhs       c2555     0
    rhs       c2556     0
    rhs       c2557     0
    rhs       c2558     0
    rhs       c2559     0
    rhs       c2560     0
    rhs       c2561     0
    rhs       c2562     0
    rhs       c2563     0
    rhs       c2564     0
    rhs       c2565     0
    rhs       c2566     0
    rhs       c2567     0
    rhs       c2568     0
    rhs       c2569     0
    rhs       c2570     0
    rhs       c2571     0
    rhs       c2572     0
    rhs       c2573     0
    rhs       c2574     0
    rhs       c2575     0
    rhs       c2576     0
    rhs       c2577     0
    rhs       c2578     0
    rhs       c2579     0
    rhs       c2580     0
    rhs       c2581     0
    rhs       c2582     0
    rhs       c2583     0
    rhs       c2584     0
    rhs       c2585     0
    rhs       c2586     0
    rhs       c2587     0
    rhs       c2588     0
    rhs       c2589     0
    rhs       c2590     0
    rhs       c2591     0
    rhs       c2592     0
    rhs       c2593     0
    rhs       c2594     0
    rhs       c2595     0
    rhs       c2596     0
    rhs       c2597     0
    rhs       c2598     0
    rhs       c2599     0
    rhs       c2600     0
    rhs       c2601     0
    rhs       c2602     0
    rhs       c2603     0
    rhs       c2604     0
    rhs       c2605     0
    rhs       c2606     0
    rhs       c2607     0
    rhs       c2608     0
    rhs       c2609     0
    rhs       c2610     0
    rhs       c2611     0
    rhs       c2612     0
    rhs       c2613     0
    rhs       c2614     0
    rhs       c2615     0
    rhs       c2616     0
    rhs       c2617     0
    rhs       c2618     0
    rhs       c2619     0
    rhs       c2620     0
    rhs       c2621     0
    rhs       c2622     0
    rhs       c2623     0
    rhs       c2624     0
    rhs       c2625     0
    rhs       c2626     0
    rhs       c2627     0
    rhs       c2628     0
    rhs       c2629     0
    rhs       c2630     0
    rhs       c2631     0
    rhs       c2632     0
    rhs       c2633     0
    rhs       c2634     0
    rhs       c2635     0
    rhs       c2636     0
    rhs       c2637     0
    rhs       c2638     0
    rhs       c2639     0
    rhs       c2640     0
    rhs       c2641     0
    rhs       c2642     0
    rhs       c2643     0
    rhs       c2644     0
    rhs       c2645     0
    rhs       c2646     0
    rhs       c2647     0
    rhs       c2648     0
    rhs       c2649     0
    rhs       c2650     0
    rhs       c2651     0
    rhs       c2652     0
    rhs       c2653     0
    rhs       c2654     0
    rhs       c2655     0
    rhs       c2656     0
    rhs       c2657     0
    rhs       c2658     0
    rhs       c2659     0
    rhs       c2660     0
    rhs       c2661     0
    rhs       c2662     0
    rhs       c2663     0
    rhs       c2664     0
    rhs       c2665     0
    rhs       c2666     0
    rhs       c2667     0
    rhs       c2668     0
    rhs       c2669     0
    rhs       c2670     0
    rhs       c2671     0
    rhs       c2672     0
    rhs       c2673     0
    rhs       c2674     0
    rhs       c2675     0
    rhs       c2676     0
    rhs       c2677     0
    rhs       c2678     0
    rhs       c2679     0
    rhs       c2680     0
    rhs       c2681     0
    rhs       c2682     0
    rhs       c2683     0
    rhs       c2684     0
    rhs       c2685     0
    rhs       c2686     0
    rhs       c2687     0
    rhs       c2688     0
    rhs       c2689     0
    rhs       c2690     0
    rhs       c2691     0
    rhs       c2692     0
    rhs       c2693     0
    rhs       c2694     0
    rhs       c2695     0
    rhs       c2696     0
    rhs       c2697     0
    rhs       c2698     0
    rhs       c2699     0
    rhs       c2700     0
    rhs       c2701     0
    rhs       c2702     0
    rhs       c2703     0
    rhs       c2704     0
    rhs       c2705     0
    rhs       c2706     0
    rhs       c2707     0
    rhs       c2708     0
    rhs       c2709     0
    rhs       c2710     0
    rhs       c2711     0
    rhs       c2712     0
    rhs       c2713     0
    rhs       c2714     0
    rhs       c2715     0
    rhs       c2716     0
    rhs       c2717     0
    rhs       c2718     0
    rhs       c2719     0
    rhs       c2720     0
    rhs       c2721     0
    rhs       c2722     0
    rhs       c2723     0
    rhs       c2724     0
    rhs       c2725     0
    rhs       c2726     0
    rhs       c2727     0
    rhs       c2728     0
    rhs       c2729     0
    rhs       c2730     0
    rhs       c2731     0
    rhs       c2732     0
    rhs       c2733     0
    rhs       c2734     0
    rhs       c2735     0
    rhs       c2736     0
    rhs       c2737     0
    rhs       c2738     0
    rhs       c2739     0
    rhs       c2740     0
    rhs       c2741     0
    rhs       c2742     0
    rhs       c2743     0
    rhs       c2744     0
    rhs       c2745     0
    rhs       c2746     0
    rhs       c2747     0
    rhs       c2748     0
    rhs       c2749     0
    rhs       c2750     0
    rhs       c2751     0
    rhs       c2752     0
    rhs       c2753     0
    rhs       c2754     0
    rhs       c2755     0
    rhs       c2756     0
    rhs       c2757     0
    rhs       c2758     0
    rhs       c2759     0
    rhs       c2760     0
    rhs       c2761     0
    rhs       c2762     0
    rhs       c2763     0
    rhs       c2764     0
    rhs       c2765     0
    rhs       c2766     0
    rhs       c2767     0
    rhs       c2768     0
    rhs       c2769     0
    rhs       c2770     0
    rhs       c2771     0
    rhs       c2772     0
    rhs       c2773     0
    rhs       c2774     0
    rhs       c2775     0
    rhs       c2776     0
    rhs       c2777     0
    rhs       c2778     0
    rhs       c2779     0
    rhs       c2780     0
    rhs       c2781     0
    rhs       c2782     0
    rhs       c2783     0
    rhs       c2784     0
    rhs       c2785     0
    rhs       c2786     0
    rhs       c2787     0
    rhs       c2788     0
    rhs       c2789     0
    rhs       c2790     0
    rhs       c2791     0
    rhs       c2792     0
    rhs       c2793     0
    rhs       c2794     0
    rhs       c2795     0
    rhs       c2796     0
    rhs       c2797     0
    rhs       c2798     0
    rhs       c2799     0
    rhs       c2800     0
    rhs       c2801     0
    rhs       c2802     0
    rhs       c2803     0
    rhs       c2804     0
    rhs       c2805     0
    rhs       c2806     0
    rhs       c2807     0
    rhs       c2808     0
    rhs       c2809     0
    rhs       c2810     0
    rhs       c2811     0
    rhs       c2812     0
    rhs       c2813     0
    rhs       c2814     0
    rhs       c2815     0
    rhs       c2816     0
    rhs       c2817     0
    rhs       c2818     0
    rhs       c2819     0
    rhs       c2820     0
    rhs       c2821     0
    rhs       c2822     0
    rhs       c2823     0
    rhs       c2824     0
    rhs       c2825     0
    rhs       c2826     0
    rhs       c2827     0
    rhs       c2828     0
    rhs       c2829     0
    rhs       c2830     0
    rhs       c2831     0
    rhs       c2832     0
    rhs       c2833     0
    rhs       c2834     0
    rhs       c2835     0
    rhs       c2836     0
    rhs       c2837     0
    rhs       c2838     0
    rhs       c2839     0
    rhs       c2840     0
    rhs       c2841     0
    rhs       c2842     0
    rhs       c2843     0
    rhs       c2844     0
    rhs       c2845     0
    rhs       c2846     0
    rhs       c2847     0
    rhs       c2848     0
    rhs       c2849     0
    rhs       c2850     0
    rhs       c2851     0
    rhs       c2852     0
    rhs       c2853     0
    rhs       c2854     0
    rhs       c2855     0
    rhs       c2856     0
    rhs       c2857     0
    rhs       c2858     0
    rhs       c2859     0
    rhs       c2860     0
    rhs       c2861     0
    rhs       c2862     0
    rhs       c2863     0
    rhs       c2864     0
    rhs       c2865     0
    rhs       c2866     0
    rhs       c2867     0
    rhs       c2868     0
    rhs       c2869     0
    rhs       c2870     0
    rhs       c2871     0
    rhs       c2872     0
    rhs       c2873     0
    rhs       c2874     0
    rhs       c2875     0
    rhs       c2876     0
    rhs       c2877     0
    rhs       c2878     0
    rhs       c2879     0
    rhs       c2880     0
    rhs       c2881     0
    rhs       c2882     0
    rhs       c2883     0
    rhs       c2884     0
    rhs       c2885     0
    rhs       c2886     0
    rhs       c2887     0
    rhs       c2888     0
    rhs       c2889     0
    rhs       c2890     0
    rhs       c2891     0
    rhs       c2892     0
    rhs       c2893     0
    rhs       c2894     0
    rhs       c2895     0
    rhs       c2896     0
    rhs       c2897     0
    rhs       c2898     0
    rhs       c2899     0
    rhs       c2900     0
    rhs       c2901     0
    rhs       c2902     0
    rhs       c2903     0
    rhs       c2904     0
    rhs       c2905     0
    rhs       c2906     0
    rhs       c2907     0
    rhs       c2908     0
    rhs       c2909     0
    rhs       c2910     0
    rhs       c2911     0
    rhs       c2912     0
    rhs       c2913     0
    rhs       c2914     0
    rhs       c2915     0
    rhs       c2916     0
    rhs       c2917     0
    rhs       c2918     0
    rhs       c2919     0
    rhs       c2920     0
    rhs       c2921     0
    rhs       c2922     0
    rhs       c2923     0
    rhs       c2924     0
    rhs       c2925     0
    rhs       c2926     0
    rhs       c2927     0
    rhs       c2928     0
    rhs       c2929     0
    rhs       c2930     0
    rhs       c2931     0
    rhs       c2932     0
    rhs       c2933     0
    rhs       c2934     0
    rhs       c2935     0
    rhs       c2936     0
    rhs       c2937     0
    rhs       c2938     0
    rhs       c2939     0
    rhs       c2940     0
    rhs       c2941     0
    rhs       c2942     0
    rhs       c2943     0
    rhs       c2944     0
    rhs       c2945     0
    rhs       c2946     0
    rhs       c2947     0
    rhs       c2948     0
    rhs       c2949     0
    rhs       c2950     0
    rhs       c2951     0
    rhs       c2952     0
    rhs       c2953     0
    rhs       c2954     0
    rhs       c2955     0
    rhs       c2956     0
    rhs       c2957     0
    rhs       c2958     0
    rhs       c2959     0
    rhs       c2960     0
    rhs       c2961     0
    rhs       c2962     0
    rhs       c2963     0
    rhs       c2964     0
    rhs       c2965     0
    rhs       c2966     0
    rhs       c2967     0
    rhs       c2968     0
    rhs       c2969     0
    rhs       c2970     0
    rhs       c2971     0
    rhs       c2972     0
    rhs       c2973     0
    rhs       c2974     0
    rhs       c2975     0
    rhs       c2976     0
    rhs       c2977     0
    rhs       c2978     0
    rhs       c2979     0
    rhs       c2980     0
    rhs       c2981     0
    rhs       c2982     0
    rhs       c2983     0
    rhs       c2984     0
    rhs       c2985     0
    rhs       c2986     0
    rhs       c2987     0
    rhs       c2988     0
    rhs       c2989     0
    rhs       c2990     0
    rhs       c2991     0
    rhs       c2992     0
    rhs       c2993     0
    rhs       c2994     0
    rhs       c2995     0
    rhs       c2996     0
    rhs       c2997     0
    rhs       c2998     0
    rhs       c2999     0
    rhs       c3000     0
    rhs       c3001     0
    rhs       c3002     0
    rhs       c3003     0
    rhs       c3004     0
    rhs       c3005     0
    rhs       c3006     0
    rhs       c3007     0
    rhs       c3008     0
    rhs       c3009     0
    rhs       c3010     0
    rhs       c3011     0
    rhs       c3012     0
    rhs       c3013     0
    rhs       c3014     0
    rhs       c3015     0
    rhs       c3016     0
    rhs       c3017     0
    rhs       c3018     0
    rhs       c3019     0
    rhs       c3020     0
    rhs       c3021     0
    rhs       c3022     0
    rhs       c3023     0
    rhs       c3024     0
    rhs       c3025     0
    rhs       c3026     0
    rhs       c3027     0
    rhs       c3028     0
    rhs       c3029     0
    rhs       c3030     0
    rhs       c3031     0
    rhs       c3032     0
    rhs       c3033     0
    rhs       c3034     0
    rhs       c3035     0
    rhs       c3036     0
    rhs       c3037     0
    rhs       c3038     0
    rhs       c3039     0
    rhs       c3040     0
    rhs       c3041     0
    rhs       c3042     0
    rhs       c3043     0
    rhs       c3044     0
    rhs       c3045     0
    rhs       c3046     0
    rhs       c3047     0
    rhs       c3048     0
    rhs       c3049     0
    rhs       c3050     0
    rhs       c3051     0
    rhs       c3052     0
    rhs       c3053     0
    rhs       c3054     0
    rhs       c3055     0
    rhs       c3056     0
    rhs       c3057     0
    rhs       c3058     0
    rhs       c3059     0
    rhs       c3060     0
    rhs       c3061     0
    rhs       c3062     0
    rhs       c3063     0
    rhs       c3064     0
    rhs       c3065     0
    rhs       c3066     0
    rhs       c3067     0
    rhs       c3068     0
    rhs       c3069     0
    rhs       c3070     0
    rhs       c3071     0
    rhs       c3072     0
    rhs       c3073     0
    rhs       c3074     0
    rhs       c3075     0
    rhs       c3076     0
    rhs       c3077     0
    rhs       c3078     0
    rhs       c3079     0
    rhs       c3080     0
    rhs       c3081     0
    rhs       c3082     0
    rhs       c3083     0
    rhs       c3084     0
    rhs       c3085     0
    rhs       c3086     0
    rhs       c3087     0
    rhs       c3088     0
    rhs       c3089     0
    rhs       c3090     0
    rhs       c3091     0
    rhs       c3092     0
    rhs       c3093     0
    rhs       c3094     0
    rhs       c3095     0
    rhs       c3096     0
    rhs       c3097     0
    rhs       c3098     0
    rhs       c3099     0
    rhs       c3100     0
    rhs       c3101     0
    rhs       c3102     0
    rhs       c3103     0
    rhs       c3104     0
    rhs       c3105     0
    rhs       c3106     0
    rhs       c3107     0
    rhs       c3108     0
    rhs       c3109     0
    rhs       c3110     0
    rhs       c3111     0
    rhs       c3112     0
    rhs       c3113     0
    rhs       c3114     0
    rhs       c3115     0
    rhs       c3116     0
    rhs       c3117     0
    rhs       c3118     0
    rhs       c3119     0
    rhs       c3120     0
    rhs       c3121     0
    rhs       c3122     0
    rhs       c3123     0
    rhs       c3124     0
    rhs       c3125     0
    rhs       c3126     0
    rhs       c3127     0
    rhs       c3128     0
    rhs       c3129     0
    rhs       c3130     0
    rhs       c3131     0
    rhs       c3132     0
    rhs       c3133     0
    rhs       c3134     0
    rhs       c3135     0
    rhs       c3136     0
    rhs       c3137     0
    rhs       c3138     0
    rhs       c3139     0
    rhs       c3140     0
    rhs       c3141     0
    rhs       c3142     0
    rhs       c3143     0
    rhs       c3144     0
    rhs       c3145     0
    rhs       c3146     0
    rhs       c3147     0
    rhs       c3148     0
    rhs       c3149     0
    rhs       c3150     0
    rhs       c3151     0
    rhs       c3152     0
    rhs       c3153     0
    rhs       c3154     0
    rhs       c3155     0
    rhs       c3156     0
    rhs       c3157     0
    rhs       c3158     0
    rhs       c3159     0
    rhs       c3160     0
    rhs       c3161     0
    rhs       c3162     0
    rhs       c3163     0
    rhs       c3164     0
    rhs       c3165     0
    rhs       c3166     0
    rhs       c3167     0
    rhs       c3168     0
    rhs       c3169     0
    rhs       c3170     0
    rhs       c3171     0
    rhs       c3172     0
    rhs       c3173     0
    rhs       c3174     0
    rhs       c3175     0
    rhs       c3176     0
    rhs       c3177     0
    rhs       c3178     0
    rhs       c3179     0
    rhs       c3180     0
    rhs       c3181     0
    rhs       c3182     0
    rhs       c3183     0
    rhs       c3184     0
    rhs       c3185     0
    rhs       c3186     0
    rhs       c3187     0
    rhs       c3188     0
    rhs       c3189     0
    rhs       c3190     0
    rhs       c3191     0
    rhs       c3192     0
    rhs       c3193     0
    rhs       c3194     0
    rhs       c3195     0
    rhs       c3196     0
    rhs       c3197     0
    rhs       c3198     0
    rhs       c3199     0
    rhs       c3200     0
    rhs       c3201     0
    rhs       c3202     0
    rhs       c3203     0
    rhs       c3204     0
    rhs       c3205     0
    rhs       c3206     0
    rhs       c3207     0
    rhs       c3208     0
    rhs       c3209     0
    rhs       c3210     0
    rhs       c3211     0
    rhs       c3212     0
    rhs       c3213     0
    rhs       c3214     0
    rhs       c3215     0
    rhs       c3216     0
    rhs       c3217     0
    rhs       c3218     0
    rhs       c3219     0
    rhs       c3220     0
    rhs       c3221     0
    rhs       c3222     0
    rhs       c3223     0
    rhs       c3224     0
    rhs       c3225     0
    rhs       c3226     0
    rhs       c3227     0
    rhs       c3228     0
    rhs       c3229     0
    rhs       c3230     0
    rhs       c3231     0
    rhs       c3232     0
    rhs       c3233     0
    rhs       c3234     0
    rhs       c3235     0
    rhs       c3236     0
    rhs       c3237     0
    rhs       c3238     0
    rhs       c3239     0
    rhs       c3240     0
    rhs       c3241     0
    rhs       c3242     0
    rhs       c3243     0
    rhs       c3244     0
    rhs       c3245     0
    rhs       c3246     0
    rhs       c3247     0
    rhs       c3248     0
    rhs       c3249     0
    rhs       c3250     0
    rhs       c3251     0
    rhs       c3252     0
    rhs       c3253     0
    rhs       c3254     0
    rhs       c3255     0
    rhs       c3256     0
    rhs       c3257     0
    rhs       c3258     0
    rhs       c3259     0
    rhs       c3260     0
    rhs       c3261     0
    rhs       c3262     0
    rhs       c3263     0
    rhs       c3264     0
    rhs       c3265     0
    rhs       c3266     0
    rhs       c3267     0
    rhs       c3268     0
    rhs       c3269     0
    rhs       c3270     0
    rhs       c3271     0
    rhs       c3272     0
    rhs       c3273     0
    rhs       c3274     0
    rhs       c3275     0
    rhs       c3276     0
    rhs       c3277     0
    rhs       c3278     0
    rhs       c3279     0
    rhs       c3280     0
    rhs       c3281     0
    rhs       c3282     0
    rhs       c3283     0
    rhs       c3284     0
    rhs       c3285     0
    rhs       c3286     0
    rhs       c3287     0
    rhs       c3288     0
    rhs       c3289     0
    rhs       c3290     0
    rhs       c3291     0
    rhs       c3292     0
    rhs       c3293     0
    rhs       c3294     0
    rhs       c3295     0
    rhs       c3296     0
    rhs       c3297     0
    rhs       c3298     0
    rhs       c3299     0
    rhs       c3300     0
    rhs       c3301     0
    rhs       c3302     0
    rhs       c3303     0
    rhs       c3304     0
    rhs       c3305     0
    rhs       c3306     0
    rhs       c3307     0
    rhs       c3308     0
    rhs       c3309     0
    rhs       c3310     0
    rhs       c3311     0
    rhs       c3312     0
    rhs       c3313     0
    rhs       c3314     0
    rhs       c3315     0
    rhs       c3316     0
    rhs       c3317     0
    rhs       c3318     0
    rhs       c3319     0
    rhs       c3320     0
    rhs       c3321     0
    rhs       c3322     0
    rhs       c3323     0
    rhs       c3324     0
    rhs       c3325     0
    rhs       c3326     0
    rhs       c3327     0
    rhs       c3328     0
    rhs       c3329     0
    rhs       c3330     0
    rhs       c3331     0
    rhs       c3332     0
    rhs       c3333     0
    rhs       c3334     0
    rhs       c3335     0
    rhs       c3336     0
    rhs       c3337     0
    rhs       c3338     0
    rhs       c3339     0
    rhs       c3340     0
    rhs       c3341     0
    rhs       c3342     0
    rhs       c3343     0
    rhs       c3344     0
    rhs       c3345     0
    rhs       c3346     0
    rhs       c3347     0
    rhs       c3348     0
    rhs       c3349     0
    rhs       c3350     0
    rhs       c3351     0
    rhs       c3352     0
    rhs       c3353     0
    rhs       c3354     0
    rhs       c3355     0
    rhs       c3356     0
    rhs       c3357     0
    rhs       c3358     0
    rhs       c3359     0
    rhs       c3360     0
    rhs       c3361     0
    rhs       c3362     0
    rhs       c3363     0
    rhs       c3364     0
    rhs       c3365     0
    rhs       c3366     0
    rhs       c3367     0
    rhs       c3368     0
    rhs       c3369     0
    rhs       c3370     0
    rhs       c3371     0
    rhs       c3372     0
    rhs       c3373     0
    rhs       c3374     0
    rhs       c3375     0
    rhs       c3376     0
    rhs       c3377     0
    rhs       c3378     0
    rhs       c3379     0
    rhs       c3380     0
    rhs       c3381     0
    rhs       c3382     0
    rhs       c3383     0
    rhs       c3384     0
    rhs       c3385     0
    rhs       c3386     0
    rhs       c3387     0
    rhs       c3388     0
    rhs       c3389     0
    rhs       c3390     0
    rhs       c3391     0
    rhs       c3392     0
    rhs       c3393     0
    rhs       c3394     0
    rhs       c3395     0
    rhs       c3396     0
    rhs       c3397     0
    rhs       c3398     0
    rhs       c3399     0
    rhs       c3400     0
    rhs       c3401     0
    rhs       c3402     0
    rhs       c3403     0
    rhs       c3404     0
    rhs       c3405     0
    rhs       c3406     0
    rhs       c3407     0
    rhs       c3408     0
    rhs       c3409     0
    rhs       c3410     0
    rhs       c3411     0
    rhs       c3412     0
    rhs       c3413     0
    rhs       c3414     0
    rhs       c3415     0
    rhs       c3416     0
    rhs       c3417     0
    rhs       c3418     0
    rhs       c3419     0
    rhs       c3420     0
    rhs       c3421     0
    rhs       c3422     0
    rhs       c3423     0
    rhs       c3424     0
    rhs       c3425     0
    rhs       c3426     0
    rhs       c3427     0
    rhs       c3428     0
    rhs       c3429     0
    rhs       c3430     0
    rhs       c3431     0
    rhs       c3432     0
    rhs       c3433     0
    rhs       c3434     0
    rhs       c3435     0
    rhs       c3436     0
    rhs       c3437     0
    rhs       c3438     0
    rhs       c3439     0
    rhs       c3440     0
    rhs       c3441     0
    rhs       c3442     0
    rhs       c3443     0
    rhs       c3444     0
    rhs       c3445     0
    rhs       c3446     0
    rhs       c3447     0
    rhs       c3448     0
    rhs       c3449     0
    rhs       c3450     0
    rhs       c3451     0
    rhs       c3452     0
    rhs       c3453     0
    rhs       c3454     0
    rhs       c3455     0
    rhs       c3456     0
    rhs       c3457     0
    rhs       c3458     0
    rhs       c3459     0
    rhs       c3460     0
    rhs       c3461     0
    rhs       c3462     0
    rhs       c3463     0
    rhs       c3464     0
    rhs       c3465     0
    rhs       c3466     0
    rhs       c3467     0
    rhs       c3468     0
    rhs       c3469     0
    rhs       c3470     0
    rhs       c3471     0
    rhs       c3472     0
    rhs       c3473     0
    rhs       c3474     0
    rhs       c3475     0
    rhs       c3476     0
    rhs       c3477     0
    rhs       c3478     0
    rhs       c3479     0
    rhs       c3480     0
    rhs       c3481     0
    rhs       c3482     0
    rhs       c3483     0
    rhs       c3484     0
    rhs       c3485     0
    rhs       c3486     0
    rhs       c3487     0
    rhs       c3488     0
    rhs       c3489     0
    rhs       c3490     0
    rhs       c3491     0
    rhs       c3492     0
    rhs       c3493     0
    rhs       c3494     0
    rhs       c3495     0
    rhs       c3496     0
    rhs       c3497     0
    rhs       c3498     0
    rhs       c3499     0
    rhs       c3500     0
    rhs       c3501     0
    rhs       c3502     0
    rhs       c3503     0
    rhs       c3504     0
    rhs       c3505     0
    rhs       c3506     0
    rhs       c3507     0
    rhs       c3508     0
    rhs       c3509     0
    rhs       c3510     0
    rhs       c3511     0
    rhs       c3512     0
    rhs       c3513     0
    rhs       c3514     0
    rhs       c3515     0
    rhs       c3516     0
    rhs       c3517     0
    rhs       c3518     0
    rhs       c3519     0
    rhs       c3520     0
    rhs       c3521     0
    rhs       c3522     0
    rhs       c3523     0
    rhs       c3524     0
    rhs       c3525     0
    rhs       c3526     0
    rhs       c3527     0
    rhs       c3528     0
    rhs       c3529     0
    rhs       c3530     0
    rhs       c3531     0
    rhs       c3532     0
    rhs       c3533     0
    rhs       c3534     0
    rhs       c3535     0
    rhs       c3536     0
    rhs       c3537     0
    rhs       c3538     0
    rhs       c3539     0
    rhs       c3540     0
    rhs       c3541     0
    rhs       c3542     0
    rhs       c3543     0
    rhs       c3544     0
    rhs       c3545     0
    rhs       c3546     0
    rhs       c3547     0
    rhs       c3548     0
    rhs       c3549     0
    rhs       c3550     0
    rhs       c3551     0
    rhs       c3552     0
    rhs       c3553     0
    rhs       c3554     0
    rhs       c3555     0
    rhs       c3556     0
    rhs       c3557     0
    rhs       c3558     0
    rhs       c3559     0
    rhs       c3560     0
    rhs       c3561     0
    rhs       c3562     0
    rhs       c3563     0
    rhs       c3564     0
    rhs       c3565     0
    rhs       c3566     0
    rhs       c3567     0
    rhs       c3568     0
    rhs       c3569     0
    rhs       c3570     0
    rhs       c3571     0
    rhs       c3572     0
    rhs       c3573     0
    rhs       c3574     0
    rhs       c3575     0
    rhs       c3576     0
    rhs       c3577     0
    rhs       c3578     0
    rhs       c3579     0
    rhs       c3580     0
    rhs       c3581     0
    rhs       c3582     0
    rhs       c3583     0
    rhs       c3584     0
    rhs       c3585     0
    rhs       c3586     0
    rhs       c3587     0
    rhs       c3588     0
    rhs       c3589     0
    rhs       c3590     0
    rhs       c3591     0
    rhs       c3592     0
    rhs       c3593     0
    rhs       c3594     0
    rhs       c3595     0
    rhs       c3596     0
    rhs       c3597     0
    rhs       c3598     0
    rhs       c3599     0
    rhs       c3600     0
    rhs       c3601     0
    rhs       c3602     0
    rhs       c3603     0
    rhs       c3604     0
    rhs       c3605     0
    rhs       c3606     0
    rhs       c3607     0
    rhs       c3608     0
    rhs       c3609     0
    rhs       c3610     0
    rhs       c3611     0
    rhs       c3612     0
    rhs       c3613     0
    rhs       c3614     0
    rhs       c3615     0
    rhs       c3616     0
    rhs       c3617     0
    rhs       c3618     0
    rhs       c3619     0
    rhs       c3620     0
    rhs       c3621     0
    rhs       c3622     0
    rhs       c3623     0
    rhs       c3624     0
    rhs       c3625     0
    rhs       c3626     0
    rhs       c3627     0
    rhs       c3628     0
    rhs       c3629     0
    rhs       c3630     0
    rhs       c3631     0
    rhs       c3632     0
    rhs       c3633     0
    rhs       c3634     0
    rhs       c3635     0
    rhs       c3636     0
    rhs       c3637     0
    rhs       c3638     0
    rhs       c3639     0
    rhs       c3640     0
    rhs       c3641     0
    rhs       c3642     0
    rhs       c3643     0
    rhs       c3644     0
    rhs       c3645     0
    rhs       c3646     0
    rhs       c3647     0
    rhs       c3648     0
    rhs       c3649     0
    rhs       c3650     0
    rhs       c3651     0
    rhs       c3652     0
    rhs       c3653     0
    rhs       c3654     0
    rhs       c3655     0
    rhs       c3656     0
    rhs       c3657     0
    rhs       c3658     0
    rhs       c3659     0
    rhs       c3660     0
    rhs       c3661     0
    rhs       c3662     0
    rhs       c3663     0
    rhs       c3664     0
    rhs       c3665     0
    rhs       c3666     0
    rhs       c3667     0
    rhs       c3668     0
    rhs       c3669     0
    rhs       c3670     0
    rhs       c3671     0
    rhs       c3672     0
    rhs       c3673     0
    rhs       c3674     0
    rhs       c3675     0
    rhs       c3676     0
    rhs       c3677     0
    rhs       c3678     0
    rhs       c3679     0
    rhs       c3680     0
    rhs       c3681     0
    rhs       c3682     0
    rhs       c3683     0
    rhs       c3684     0
    rhs       c3685     0
    rhs       c3686     0
    rhs       c3687     0
    rhs       c3688     0
    rhs       c3689     0
    rhs       c3690     0
    rhs       c3691     0
    rhs       c3692     0
    rhs       c3693     0
    rhs       c3694     0
    rhs       c3695     0
    rhs       c3696     0
    rhs       c3697     0
    rhs       c3698     0
    rhs       c3699     0
    rhs       c3700     0
    rhs       c3701     0
    rhs       c3702     0
    rhs       c3703     0
    rhs       c3704     0
    rhs       c3705     0
    rhs       c3706     0
    rhs       c3707     0
    rhs       c3708     0
    rhs       c3709     0
    rhs       c3710     0
    rhs       c3711     0
    rhs       c3712     0
    rhs       c3713     0
    rhs       c3714     0
    rhs       c3715     0
    rhs       c3716     0
    rhs       c3717     0
    rhs       c3718     0
    rhs       c3719     0
    rhs       c3720     0
    rhs       c3721     0
    rhs       c3722     0
    rhs       c3723     0
    rhs       c3724     0
    rhs       c3725     0
    rhs       c3726     0
    rhs       c3727     0
    rhs       c3728     0
    rhs       c3729     0
    rhs       c3730     0
    rhs       c3731     0
    rhs       c3732     0
    rhs       c3733     0
    rhs       c3734     0
    rhs       c3735     0
    rhs       c3736     0
    rhs       c3737     0
    rhs       c3738     0
    rhs       c3739     0
    rhs       c3740     0
    rhs       c3741     0
    rhs       c3742     0
    rhs       c3743     0
    rhs       c3744     0
    rhs       c3745     0
    rhs       c3746     0
    rhs       c3747     0
    rhs       c3748     0
    rhs       c3749     0
    rhs       c3750     0
    rhs       c3751     0
    rhs       c3752     0
    rhs       c3753     0
    rhs       c3754     0
    rhs       c3755     0
    rhs       c3756     0
    rhs       c3757     0
    rhs       c3758     0
    rhs       c3759     0
    rhs       c3760     0
    rhs       c3761     0
    rhs       c3762     0
    rhs       c3763     0
    rhs       c3764     0
    rhs       c3765     0
    rhs       c3766     0
    rhs       c3767     0
    rhs       c3768     0
    rhs       c3769     0
    rhs       c3770     0
    rhs       c3771     0
    rhs       c3772     0
    rhs       c3773     0
    rhs       c3774     0
    rhs       c3775     0
    rhs       c3776     0
    rhs       c3777     0
    rhs       c3778     0
    rhs       c3779     0
    rhs       c3780     0
    rhs       c3781     0
    rhs       c3782     0
    rhs       c3783     0
    rhs       c3784     0
    rhs       c3785     0
    rhs       c3786     0
    rhs       c3787     0
    rhs       c3788     0
    rhs       c3789     0
    rhs       c3790     0
    rhs       c3791     0
    rhs       c3792     0
    rhs       c3793     0
    rhs       c3794     0
    rhs       c3795     0
    rhs       c3796     0
    rhs       c3797     0
    rhs       c3798     0
    rhs       c3799     0
    rhs       c3800     0
    rhs       c3801     0
    rhs       c3802     0
    rhs       c3803     0
    rhs       c3804     0
    rhs       c3805     0
    rhs       c3806     0
    rhs       c3807     0
    rhs       c3808     0
    rhs       c3809     0
    rhs       c3810     0
    rhs       c3811     0
    rhs       c3812     0
    rhs       c3813     0
    rhs       c3814     0
    rhs       c3815     0
    rhs       c3816     0
    rhs       c3817     0
    rhs       c3818     0
    rhs       c3819     0
    rhs       c3820     0
    rhs       c3821     0
    rhs       c3822     0
    rhs       c3823     0
    rhs       c3824     0
    rhs       c3825     0
    rhs       c3826     0
    rhs       c3827     0
    rhs       c3828     0
    rhs       c3829     0
    rhs       c3830     0
    rhs       c3831     0
    rhs       c3832     0
    rhs       c3833     0
    rhs       c3834     0
    rhs       c3835     0
    rhs       c3836     0
    rhs       c3837     0
    rhs       c3838     0
    rhs       c3839     0
    rhs       c3840     0
    rhs       c3841     0
    rhs       c3842     0
    rhs       c3843     0
    rhs       c3844     0
    rhs       c3845     0
    rhs       c3846     0
    rhs       c3847     0
    rhs       c3848     0
    rhs       c3849     0
    rhs       c3850     0
    rhs       c3851     0
    rhs       c3852     0
    rhs       c3853     0
    rhs       c3854     0
    rhs       c3855     0
    rhs       c3856     0
    rhs       c3857     0
    rhs       c3858     0
    rhs       c3859     0
    rhs       c3860     0
    rhs       c3861     0
    rhs       c3862     0
    rhs       c3863     0
    rhs       c3864     0
    rhs       c3865     0
    rhs       c3866     0
    rhs       c3867     0
    rhs       c3868     0
    rhs       c3869     0
    rhs       c3870     0
    rhs       c3871     0
    rhs       c3872     0
    rhs       c3873     0
    rhs       c3874     0
    rhs       c3875     0
    rhs       c3876     0
    rhs       c3877     0
    rhs       c3878     0
    rhs       c3879     0
    rhs       c3880     0
    rhs       c3881     0
    rhs       c3882     0
    rhs       c3883     0
    rhs       c3884     0
    rhs       c3885     0
    rhs       c3886     0
    rhs       c3887     0
    rhs       c3888     0
    rhs       c3889     0
    rhs       c3890     0
    rhs       c3891     0
    rhs       c3892     0
    rhs       c3893     0
    rhs       c3894     0
    rhs       c3895     0
    rhs       c3896     0
    rhs       c3897     0
    rhs       c3898     0
    rhs       c3899     0
    rhs       c3900     0
    rhs       c3901     0
    rhs       c3902     0
    rhs       c3903     0
    rhs       c3904     0
    rhs       c3905     0
    rhs       c3906     0
    rhs       c3907     0
    rhs       c3908     0
    rhs       c3909     0
    rhs       c3910     0
    rhs       c3911     0
    rhs       c3912     0
    rhs       c3913     0
    rhs       c3914     0
    rhs       c3915     0
    rhs       c3916     0
    rhs       c3917     0
    rhs       c3918     0
    rhs       c3919     0
    rhs       c3920     0
    rhs       c3921     0
    rhs       c3922     0
    rhs       c3923     0
    rhs       c3924     0
    rhs       c3925     0
    rhs       c3926     0
    rhs       c3927     0
    rhs       c3928     0
    rhs       c3929     0
    rhs       c3930     0
    rhs       c3931     0
    rhs       c3932     0
    rhs       c3933     0
    rhs       c3934     0
    rhs       c3935     0
    rhs       c3936     0
    rhs       c3937     0
    rhs       c3938     0
    rhs       c3939     0
    rhs       c3940     0
    rhs       c3941     0
    rhs       c3942     0
    rhs       c3943     0
    rhs       c3944     0
    rhs       c3945     0
    rhs       c3946     0
    rhs       c3947     0
    rhs       c3948     0
    rhs       c3949     0
    rhs       c3950     0
    rhs       c3951     0
    rhs       c3952     0
    rhs       c3953     0
    rhs       c3954     0
    rhs       c3955     0
    rhs       c3956     0
    rhs       c3957     0
    rhs       c3958     0
    rhs       c3959     0
    rhs       c3960     0
    rhs       c3961     0
    rhs       c3962     0
    rhs       c3963     0
    rhs       c3964     0
    rhs       c3965     0
    rhs       c3966     0
    rhs       c3967     0
    rhs       c3968     0
    rhs       c3969     0
    rhs       c3970     0
    rhs       c3971     0
    rhs       c3972     0
    rhs       c3973     0
    rhs       c3974     0
    rhs       c3975     0
    rhs       c3976     0
    rhs       c3977     0
    rhs       c3978     0
    rhs       c3979     0
    rhs       c3980     0
    rhs       c3981     0
    rhs       c3982     0
    rhs       c3983     0
    rhs       c3984     0
    rhs       c3985     0
    rhs       c3986     0
    rhs       c3987     0
    rhs       c3988     0
    rhs       c3989     0
    rhs       c3990     0
    rhs       c3991     0
    rhs       c3992     0
    rhs       c3993     0
    rhs       c3994     0
    rhs       c3995     0
    rhs       c3996     0
    rhs       c3997     0
    rhs       c3998     0
    rhs       c3999     0
    rhs       c4000     0
    rhs       c4001     0
    rhs       c4002     0
    rhs       c4003     0
    rhs       c4004     0
    rhs       c4005     0
    rhs       c4006     0
    rhs       c4007     0
    rhs       c4008     0
    rhs       c4009     0
    rhs       c4010     0
    rhs       c4011     0
    rhs       c4012     0
    rhs       c4013     0
    rhs       c4014     0
    rhs       c4015     0
    rhs       c4016     0
    rhs       c4017     0
    rhs       c4018     0
    rhs       c4019     0
    rhs       c4020     0
    rhs       c4021     0
    rhs       c4022     0
    rhs       c4023     0
    rhs       c4024     0
    rhs       c4025     0
    rhs       c4026     0
    rhs       c4027     0
    rhs       c4028     0
    rhs       c4029     0
    rhs       c4030     0
    rhs       c4031     0
    rhs       c4032     0
    rhs       c4033     0
    rhs       c4034     0
    rhs       c4035     0
    rhs       c4036     0
    rhs       c4037     0
    rhs       c4038     0
    rhs       c4039     0
    rhs       c4040     0
    rhs       c4041     0
    rhs       c4042     0
    rhs       c4043     0
    rhs       c4044     0
    rhs       c4045     0
    rhs       c4046     0
    rhs       c4047     0
    rhs       c4048     0
    rhs       c4049     0
    rhs       c4050     0
    rhs       c4051     0
    rhs       c4052     0
    rhs       c4053     0
    rhs       c4054     0
    rhs       c4055     0
    rhs       c4056     0
    rhs       c4057     0
    rhs       c4058     0
    rhs       c4059     0
    rhs       c4060     0
    rhs       c4061     0
    rhs       c4062     0
    rhs       c4063     0
    rhs       c4064     0
    rhs       c4065     0
    rhs       c4066     0
    rhs       c4067     0
    rhs       c4068     0
    rhs       c4069     0
    rhs       c4070     0
    rhs       c4071     0
    rhs       c4072     0
    rhs       c4073     0
    rhs       c4074     0
    rhs       c4075     0
    rhs       c4076     0
    rhs       c4077     0
    rhs       c4078     0
    rhs       c4079     0
    rhs       c4080     0
    rhs       c4081     0
    rhs       c4082     0
    rhs       c4083     0
    rhs       c4084     0
    rhs       c4085     0
    rhs       c4086     0
    rhs       c4087     0
    rhs       c4088     0
    rhs       c4089     0
    rhs       c4090     0
    rhs       c4091     0
    rhs       c4092     0
    rhs       c4093     0
    rhs       c4094     0
    rhs       c4095     0
    rhs       c4096     0
    rhs       c4097     0
    rhs       c4098     0
    rhs       c4099     0
    rhs       c4100     0
    rhs       c4101     0
    rhs       c4102     0
    rhs       c4103     0
    rhs       c4104     0
    rhs       c4105     0
    rhs       c4106     0
    rhs       c4107     0
    rhs       c4108     0
    rhs       c4109     0
    rhs       c4110     0
    rhs       c4111     0
    rhs       c4112     0
    rhs       c4113     0
    rhs       c4114     0
    rhs       c4115     0
    rhs       c4116     0
    rhs       c4117     0
    rhs       c4118     0
    rhs       c4119     0
    rhs       c4120     0
    rhs       c4121     0
    rhs       c4122     0
    rhs       c4123     0
    rhs       c4124     0
    rhs       c4125     0
    rhs       c4126     0
    rhs       c4127     0
    rhs       c4128     0
    rhs       c4129     0
    rhs       c4130     0
    rhs       c4131     0
    rhs       c4132     0
    rhs       c4133     0
    rhs       c4134     0
    rhs       c4135     0
    rhs       c4136     0
    rhs       c4137     0
    rhs       c4138     0
    rhs       c4139     0
    rhs       c4140     0
    rhs       c4141     0
    rhs       c4142     0
    rhs       c4143     0
    rhs       c4144     0
    rhs       c4145     0
    rhs       c4146     0
    rhs       c4147     0
    rhs       c4148     0
    rhs       c4149     0
    rhs       c4150     0
    rhs       c4151     0
    rhs       c4152     0
    rhs       c4153     0
    rhs       c4154     0
    rhs       c4155     0
    rhs       c4156     0
    rhs       c4157     0
    rhs       c4158     0
    rhs       c4159     0
    rhs       c4160     0
    rhs       c4161     0
    rhs       c4162     0
    rhs       c4163     0
    rhs       c4164     0
    rhs       c4165     0
    rhs       c4166     0
    rhs       c4167     0
    rhs       c4168     0
    rhs       c4169     0
    rhs       c4170     0
    rhs       c4171     0
    rhs       c4172     0
    rhs       c4173     0
    rhs       c4174     0
    rhs       c4175     0
    rhs       c4176     0
    rhs       c4177     0
    rhs       c4178     0
    rhs       c4179     0
    rhs       c4180     0
    rhs       c4181     0
    rhs       c4182     0
    rhs       c4183     0
    rhs       c4184     0
    rhs       c4185     0
    rhs       c4186     0
    rhs       c4187     0
    rhs       c4188     0
    rhs       c4189     0
    rhs       c4190     0
    rhs       c4191     0
    rhs       c4192     0
    rhs       c4193     0
    rhs       c4194     0
    rhs       c4195     0
    rhs       c4196     0
    rhs       c4197     0
    rhs       c4198     0
    rhs       c4199     0
    rhs       c4200     0
    rhs       c4201     0
    rhs       c4202     0
    rhs       c4203     0
    rhs       c4204     0
    rhs       c4205     0
    rhs       c4206     0
    rhs       c4207     0
    rhs       c4208     0
    rhs       c4209     0
    rhs       c4210     0
    rhs       c4211     0
    rhs       c4212     0
    rhs       c4213     0
    rhs       c4214     0
    rhs       c4215     0
    rhs       c4216     0
    rhs       c4217     0
    rhs       c4218     0
    rhs       c4219     0
    rhs       c4220     0
    rhs       c4221     0
    rhs       c4222     0
    rhs       c4223     0
    rhs       c4224     0
    rhs       c4225     0
    rhs       c4226     0
    rhs       c4227     0
    rhs       c4228     0
    rhs       c4229     0
    rhs       c4230     0
    rhs       c4231     0
    rhs       c4232     0
    rhs       c4233     0
    rhs       c4234     0
    rhs       c4235     0
    rhs       c4236     0
    rhs       c4237     0
    rhs       c4238     0
    rhs       c4239     0
    rhs       c4240     0
    rhs       c4241     0
    rhs       c4242     0
    rhs       c4243     0
    rhs       c4244     0
    rhs       c4245     0
    rhs       c4246     0
    rhs       c4247     0
    rhs       c4248     0
    rhs       c4249     0
    rhs       c4250     0
    rhs       c4251     0
    rhs       c4252     0
    rhs       c4253     0
    rhs       c4254     0
    rhs       c4255     0
    rhs       c4256     0
    rhs       c4257     0
    rhs       c4258     0
    rhs       c4259     0
    rhs       c4260     0
    rhs       c4261     0
    rhs       c4262     0
    rhs       c4263     0
    rhs       c4264     0
    rhs       c4265     0
    rhs       c4266     0
    rhs       c4267     0
    rhs       c4268     0
    rhs       c4269     0
    rhs       c4270     0
    rhs       c4271     0
    rhs       c4272     0
    rhs       c4273     0
    rhs       c4274     0
    rhs       c4275     0
    rhs       c4276     0
    rhs       c4277     0
    rhs       c4278     0
    rhs       c4279     0
    rhs       c4280     0
    rhs       c4281     0
    rhs       c4282     0
    rhs       c4283     0
    rhs       c4284     0
    rhs       c4285     0
    rhs       c4286     0
    rhs       c4287     0
    rhs       c4288     0
    rhs       c4289     0
    rhs       c4290     0
    rhs       c4291     0
    rhs       c4292     0
    rhs       c4293     0
    rhs       c4294     0
    rhs       c4295     0
    rhs       c4296     0
    rhs       c4297     0
    rhs       c4298     0
    rhs       c4299     0
    rhs       c4300     0
    rhs       c4301     0
    rhs       c4302     0
    rhs       c4303     0
    rhs       c4304     0
    rhs       c4305     0
    rhs       c4306     0
    rhs       c4307     0
    rhs       c4308     0
    rhs       c4309     0
    rhs       c4310     0
    rhs       c4311     0
    rhs       c4312     0
    rhs       c4313     0
    rhs       c4314     0
    rhs       c4315     0
    rhs       c4316     0
    rhs       c4317     0
    rhs       c4318     0
    rhs       c4319     0
    rhs       c4320     0
    rhs       c4321     0
    rhs       c4322     0
    rhs       c4323     0
    rhs       c4324     0
    rhs       c4325     0
    rhs       c4326     0
    rhs       c4327     0
    rhs       c4328     0
    rhs       c4329     0
    rhs       c4330     0
    rhs       c4331     0
    rhs       c4332     0
    rhs       c4333     0
    rhs       c4334     0
    rhs       c4335     0
    rhs       c4336     0
    rhs       c4337     0
    rhs       c4338     0
    rhs       c4339     0
    rhs       c4340     0
    rhs       c4341     0
    rhs       c4342     0
    rhs       c4343     0
    rhs       c4344     0
    rhs       c4345     0
    rhs       c4346     0
    rhs       c4347     0
    rhs       c4348     0
    rhs       c4349     0
    rhs       c4350     0
    rhs       c4351     0
    rhs       c4352     0
    rhs       c4353     0
    rhs       c4354     0
    rhs       c4355     0
    rhs       c4356     0
    rhs       c4357     0
    rhs       c4358     0
    rhs       c4359     0
    rhs       c4360     0
    rhs       c4361     0
    rhs       c4362     0
    rhs       c4363     0
    rhs       c4364     0
    rhs       c4365     0
    rhs       c4366     0
    rhs       c4367     0
    rhs       c4368     0
    rhs       c4369     0
    rhs       c4370     0
    rhs       c4371     0
    rhs       c4372     0
    rhs       c4373     0
    rhs       c4374     0
    rhs       c4375     0
    rhs       c4376     0
    rhs       c4377     0
    rhs       c4378     0
    rhs       c4379     0
    rhs       c4380     0
    rhs       c4381     0
    rhs       c4382     0
    rhs       c4383     0
    rhs       c4384     0
    rhs       c4385     0
    rhs       c4386     0
    rhs       c4387     0
    rhs       c4388     0
    rhs       c4389     0
    rhs       c4390     0
    rhs       c4391     0
    rhs       c4392     0
    rhs       c4393     0
    rhs       c4394     0
    rhs       c4395     0
    rhs       c4396     0
    rhs       c4397     0
    rhs       c4398     0
    rhs       c4399     0
    rhs       c4400     0
    rhs       c4401     0
    rhs       c4402     0
    rhs       c4403     0
    rhs       c4404     0
    rhs       c4405     0
    rhs       c4406     0
    rhs       c4407     0
    rhs       c4408     0
    rhs       c4409     0
    rhs       c4410     0
    rhs       c4411     0
    rhs       c4412     0
    rhs       c4413     0
    rhs       c4414     0
    rhs       c4415     0
    rhs       c4416     0
    rhs       c4417     0
    rhs       c4418     0
    rhs       c4419     0
    rhs       c4420     0
    rhs       c4421     0
    rhs       c4422     0
    rhs       c4423     0
    rhs       c4424     0
    rhs       c4425     0
    rhs       c4426     0
    rhs       c4427     0
    rhs       c4428     0
    rhs       c4429     0
    rhs       c4430     0
    rhs       c4431     0
    rhs       c4432     0
    rhs       c4433     0
    rhs       c4434     0
    rhs       c4435     0
    rhs       c4436     0
    rhs       c4437     0
    rhs       c4438     0
    rhs       c4439     0
    rhs       c4440     0
    rhs       c4441     0
    rhs       c4442     0
    rhs       c4443     0
    rhs       c4444     0
    rhs       c4445     0
    rhs       c4446     0
    rhs       c4447     0
    rhs       c4448     0
    rhs       c4449     0
    rhs       c4450     0
    rhs       c4451     0
    rhs       c4452     0
    rhs       c4453     0
    rhs       c4454     0
    rhs       c4455     0
    rhs       c4456     0
    rhs       c4457     0
    rhs       c4458     0
    rhs       c4459     0
    rhs       c4460     0
    rhs       c4461     0
    rhs       c4462     0
    rhs       c4463     0
    rhs       c4464     0
    rhs       c4465     0
    rhs       c4466     0
    rhs       c4467     0
    rhs       c4468     0
    rhs       c4469     0
    rhs       c4470     0
    rhs       c4471     0
    rhs       c4472     0
    rhs       c4473     0
    rhs       c4474     0
    rhs       c4475     0
    rhs       c4476     0
    rhs       c4477     0
    rhs       c4478     0
    rhs       c4479     0
    rhs       c4480     0
    rhs       c4481     0
    rhs       c4482     0
    rhs       c4483     0
    rhs       c4484     0
    rhs       c4485     0
    rhs       c4486     0
    rhs       c4487     0
    rhs       c4488     0
    rhs       c4489     0
    rhs       c4490     0
    rhs       c4491     0
    rhs       c4492     0
    rhs       c4493     0
    rhs       c4494     0
    rhs       c4495     0
    rhs       c4496     0
    rhs       c4497     0
    rhs       c4498     0
    rhs       c4499     0
    rhs       c4500     0
    rhs       c4501     0
    rhs       c4502     0
    rhs       c4503     0
    rhs       c4504     0
    rhs       c4505     0
    rhs       c4506     0
    rhs       c4507     0
    rhs       c4508     0
    rhs       c4509     0
    rhs       c4510     0
    rhs       c4511     0
    rhs       c4512     0
    rhs       c4513     0
    rhs       c4514     0
    rhs       c4515     0
    rhs       c4516     0
    rhs       c4517     0
    rhs       c4518     0
    rhs       c4519     0
    rhs       c4520     0
    rhs       c4521     0
    rhs       c4522     0
    rhs       c4523     0
    rhs       c4524     0
    rhs       c4525     0
    rhs       c4526     0
    rhs       c4527     0
    rhs       c4528     0
    rhs       c4529     0
    rhs       c4530     0
    rhs       c4531     0
    rhs       c4532     0
    rhs       c4533     0
    rhs       c4534     0
    rhs       c4535     0
    rhs       c4536     0
    rhs       c4537     0
    rhs       c4538     0
    rhs       c4539     0
    rhs       c4540     0
    rhs       c4541     0
    rhs       c4542     0
    rhs       c4543     0
    rhs       c4544     0
    rhs       c4545     0
    rhs       c4546     0
    rhs       c4547     0
    rhs       c4548     0
    rhs       c4549     0
    rhs       c4550     0
    rhs       c4551     0
    rhs       c4552     0
    rhs       c4553     0
    rhs       c4554     0
    rhs       c4555     0
    rhs       c4556     0
    rhs       c4557     0
    rhs       c4558     0
    rhs       c4559     0
    rhs       c4560     0
    rhs       c4561     0
    rhs       c4562     0
    rhs       c4563     0
    rhs       c4564     0
    rhs       c4565     0
    rhs       c4566     0
    rhs       c4567     0
    rhs       c4568     0
    rhs       c4569     0
    rhs       c4570     0
    rhs       c4571     0
    rhs       c4572     0
    rhs       c4573     0
    rhs       c4574     0
    rhs       c4575     0
    rhs       c4576     0
    rhs       c4577     0
    rhs       c4578     0
    rhs       c4579     0
    rhs       c4580     0
    rhs       c4581     0
    rhs       c4582     0
    rhs       c4583     0
    rhs       c4584     0
    rhs       c4585     0
    rhs       c4586     0
    rhs       c4587     0
    rhs       c4588     0
    rhs       c4589     0
    rhs       c4590     0
    rhs       c4591     0
    rhs       c4592     0
    rhs       c4593     0
    rhs       c4594     0
    rhs       c4595     0
    rhs       c4596     0
    rhs       c4597     0
    rhs       c4598     0
    rhs       c4599     0
    rhs       c4600     0
    rhs       c4601     0
    rhs       c4602     0
    rhs       c4603     0
    rhs       c4604     0
    rhs       c4605     0
    rhs       c4606     0
    rhs       c4607     0
    rhs       c4608     0
    rhs       c4609     0
    rhs       c4610     0
    rhs       c4611     0
    rhs       c4612     0
    rhs       c4613     0
    rhs       c4614     0
    rhs       c4615     0
    rhs       c4616     0
    rhs       c4617     0
    rhs       c4618     0
    rhs       c4619     0
    rhs       c4620     0
    rhs       c4621     0
    rhs       c4622     0
    rhs       c4623     0
    rhs       c4624     0
    rhs       c4625     0
    rhs       c4626     0
    rhs       c4627     0
    rhs       c4628     0
    rhs       c4629     0
    rhs       c4630     0
    rhs       c4631     0
    rhs       c4632     0
    rhs       c4633     0
RANGES
BOUNDS
 BV bounds    x[1]
 BV bounds    x[2]
 BV bounds    x[3]
 BV bounds    x[4]
 BV bounds    x[5]
 BV bounds    x[6]
 BV bounds    x[7]
 BV bounds    x[8]
 BV bounds    x[9]
 BV bounds    x[10]
 BV bounds    x[11]
 BV bounds    x[12]
 BV bounds    x[13]
 BV bounds    x[14]
 BV bounds    x[15]
 BV bounds    x[16]
 BV bounds    x[17]
 BV bounds    x[18]
 BV bounds    x[19]
 BV bounds    x[20]
 BV bounds    x[21]
 BV bounds    x[22]
 BV bounds    x[23]
 BV bounds    x[24]
 BV bounds    x[25]
 BV bounds    x[26]
 BV bounds    x[27]
 BV bounds    x[28]
 BV bounds    x[29]
 BV bounds    x[30]
 BV bounds    x[31]
 BV bounds    x[32]
 BV bounds    x[33]
 BV bounds    x[34]
 BV bounds    x[35]
 BV bounds    x[36]
 BV bounds    x[37]
 BV bounds    x[38]
 BV bounds    x[39]
 BV bounds    x[40]
 BV bounds    x[41]
 BV bounds    x[42]
 BV bounds    x[43]
 BV bounds    x[44]
 BV bounds    x[45]
 BV bounds    x[46]
 BV bounds    x[47]
 BV bounds    x[48]
 BV bounds    x[49]
 BV bounds    x[50]
 BV bounds    x[51]
 BV bounds    x[52]
 BV bounds    x[53]
 BV bounds    x[54]
 BV bounds    x[55]
 BV bounds    x[56]
 BV bounds    x[57]
 BV bounds    x[58]
 BV bounds    x[59]
 BV bounds    x[60]
 BV bounds    x[61]
 BV bounds    x[62]
 BV bounds    x[63]
 BV bounds    x[64]
 BV bounds    x[65]
 BV bounds    x[66]
 BV bounds    x[67]
 BV bounds    x[68]
 BV bounds    x[69]
 BV bounds    x[70]
 BV bounds    x[71]
 BV bounds    x[72]
 BV bounds    x[73]
 BV bounds    x[74]
 BV bounds    x[75]
 BV bounds    x[76]
 BV bounds    x[77]
 BV bounds    x[78]
 BV bounds    x[79]
 BV bounds    x[80]
 BV bounds    x[81]
 BV bounds    x[82]
 BV bounds    x[83]
 BV bounds    x[84]
 BV bounds    x[85]
 BV bounds    x[86]
 BV bounds    x[87]
 BV bounds    x[88]
 BV bounds    x[89]
 BV bounds    x[90]
 BV bounds    x[91]
 BV bounds    x[92]
 BV bounds    x[93]
 BV bounds    x[94]
 BV bounds    x[95]
 BV bounds    x[96]
 BV bounds    x[97]
 BV bounds    x[98]
 BV bounds    x[99]
 BV bounds    x[100]
 BV bounds    x[101]
 BV bounds    x[102]
 BV bounds    x[103]
 BV bounds    x[104]
 BV bounds    x[105]
 BV bounds    x[106]
 BV bounds    x[107]
 BV bounds    x[108]
 BV bounds    x[109]
 BV bounds    x[110]
 BV bounds    x[111]
 BV bounds    x[112]
 BV bounds    x[113]
 BV bounds    x[114]
 BV bounds    x[115]
 BV bounds    x[116]
 BV bounds    x[117]
 BV bounds    x[118]
 BV bounds    x[119]
 BV bounds    x[120]
 BV bounds    x[121]
 BV bounds    x[122]
 BV bounds    x[123]
 BV bounds    x[124]
 BV bounds    x[125]
 BV bounds    x[126]
 BV bounds    x[127]
 BV bounds    x[128]
 BV bounds    x[129]
 BV bounds    x[130]
 BV bounds    x[131]
 BV bounds    x[132]
 BV bounds    x[133]
 BV bounds    x[134]
 BV bounds    x[135]
 BV bounds    x[136]
 BV bounds    x[137]
 BV bounds    x[138]
 BV bounds    x[139]
 BV bounds    x[140]
 BV bounds    x[141]
 BV bounds    x[142]
 BV bounds    x[143]
 BV bounds    x[144]
 BV bounds    x[145]
 BV bounds    x[146]
 BV bounds    x[147]
 BV bounds    x[148]
 BV bounds    x[149]
 BV bounds    x[150]
 BV bounds    x[151]
 BV bounds    x[152]
 BV bounds    x[153]
 BV bounds    x[154]
 BV bounds    x[155]
 BV bounds    x[156]
 BV bounds    x[157]
 BV bounds    x[158]
 BV bounds    x[159]
 BV bounds    x[160]
 BV bounds    x[161]
 BV bounds    x[162]
 BV bounds    x[163]
 BV bounds    x[164]
 BV bounds    x[165]
 BV bounds    x[166]
 BV bounds    x[167]
 BV bounds    x[168]
 BV bounds    x[169]
 BV bounds    x[170]
 BV bounds    x[171]
 BV bounds    x[172]
 BV bounds    x[173]
 BV bounds    x[174]
 BV bounds    x[175]
 BV bounds    x[176]
 BV bounds    x[177]
 BV bounds    x[178]
 BV bounds    x[179]
 BV bounds    x[180]
 BV bounds    x[181]
 BV bounds    x[182]
 BV bounds    x[183]
 BV bounds    x[184]
 BV bounds    x[185]
 BV bounds    x[186]
 BV bounds    x[187]
 BV bounds    x[188]
 BV bounds    x[189]
 BV bounds    x[190]
 BV bounds    x[191]
 BV bounds    x[192]
 BV bounds    x[193]
 BV bounds    x[194]
 BV bounds    x[195]
 BV bounds    x[196]
 BV bounds    x[197]
 BV bounds    x[198]
 BV bounds    x[199]
 BV bounds    x[200]
 BV bounds    x[201]
 BV bounds    x[202]
 BV bounds    x[203]
 BV bounds    x[204]
 BV bounds    x[205]
 BV bounds    x[206]
 BV bounds    x[207]
 BV bounds    x[208]
 BV bounds    x[209]
 BV bounds    x[210]
 BV bounds    x[211]
 BV bounds    x[212]
 BV bounds    x[213]
 BV bounds    x[214]
 BV bounds    x[215]
 BV bounds    x[216]
 BV bounds    x[217]
 BV bounds    x[218]
 BV bounds    x[219]
 BV bounds    x[220]
 BV bounds    x[221]
 BV bounds    x[222]
 BV bounds    x[223]
 BV bounds    x[224]
 BV bounds    x[225]
 BV bounds    x[226]
 BV bounds    x[227]
 BV bounds    x[228]
 BV bounds    x[229]
 BV bounds    x[230]
 BV bounds    x[231]
 BV bounds    x[232]
 BV bounds    x[233]
 BV bounds    x[234]
 BV bounds    x[235]
 BV bounds    x[236]
 BV bounds    x[237]
 BV bounds    x[238]
 BV bounds    x[239]
 BV bounds    x[240]
 BV bounds    x[241]
 BV bounds    x[242]
 BV bounds    x[243]
 BV bounds    x[244]
 BV bounds    x[245]
 BV bounds    x[246]
 BV bounds    x[247]
 BV bounds    x[248]
 BV bounds    x[249]
 BV bounds    x[250]
 BV bounds    x[251]
 BV bounds    x[252]
 BV bounds    x[253]
 BV bounds    x[254]
 BV bounds    x[255]
 BV bounds    x[256]
 BV bounds    x[257]
 BV bounds    x[258]
 BV bounds    x[259]
 BV bounds    x[260]
 BV bounds    x[261]
 BV bounds    x[262]
 BV bounds    x[263]
 BV bounds    x[264]
 BV bounds    x[265]
 BV bounds    x[266]
 BV bounds    x[267]
 BV bounds    x[268]
 BV bounds    x[269]
 BV bounds    x[270]
 BV bounds    x[271]
 BV bounds    x[272]
 BV bounds    x[273]
 BV bounds    x[274]
 BV bounds    x[275]
 BV bounds    x[276]
 BV bounds    x[277]
 BV bounds    x[278]
 BV bounds    x[279]
 BV bounds    x[280]
 BV bounds    x[281]
 BV bounds    x[282]
 BV bounds    x[283]
 BV bounds    x[284]
 BV bounds    x[285]
 BV bounds    x[286]
 BV bounds    x[287]
 BV bounds    x[288]
 BV bounds    x[289]
 BV bounds    x[290]
 BV bounds    x[291]
 BV bounds    x[292]
 BV bounds    x[293]
 BV bounds    x[294]
 BV bounds    x[295]
 BV bounds    x[296]
 BV bounds    x[297]
 BV bounds    x[298]
 BV bounds    x[299]
 BV bounds    x[300]
 BV bounds    x[301]
 BV bounds    x[302]
 BV bounds    x[303]
 BV bounds    x[304]
 BV bounds    x[305]
 BV bounds    x[306]
 BV bounds    x[307]
 BV bounds    x[308]
 BV bounds    x[309]
 BV bounds    x[310]
 BV bounds    x[311]
 BV bounds    x[312]
 BV bounds    x[313]
 BV bounds    x[314]
 BV bounds    x[315]
 BV bounds    x[316]
 BV bounds    x[317]
 BV bounds    x[318]
 BV bounds    x[319]
 BV bounds    x[320]
 BV bounds    x[321]
 BV bounds    x[322]
 BV bounds    x[323]
 BV bounds    x[324]
 BV bounds    x[325]
 BV bounds    x[326]
 BV bounds    x[327]
 BV bounds    x[328]
 BV bounds    x[329]
 BV bounds    x[330]
 BV bounds    x[331]
 BV bounds    x[332]
 BV bounds    x[333]
 BV bounds    x[334]
 BV bounds    x[335]
 BV bounds    x[336]
 BV bounds    x[337]
 BV bounds    x[338]
 BV bounds    x[339]
 BV bounds    x[340]
 BV bounds    x[341]
 BV bounds    x[342]
 BV bounds    x[343]
 BV bounds    x[344]
 BV bounds    x[345]
 BV bounds    x[346]
 BV bounds    x[347]
 BV bounds    x[348]
 BV bounds    x[349]
 BV bounds    x[350]
 BV bounds    x[351]
 BV bounds    x[352]
 BV bounds    x[353]
 BV bounds    x[354]
 BV bounds    x[355]
 BV bounds    x[356]
 BV bounds    x[357]
 BV bounds    x[358]
 BV bounds    x[359]
 BV bounds    x[360]
 BV bounds    x[361]
 BV bounds    x[362]
 BV bounds    x[363]
 BV bounds    x[364]
 BV bounds    x[365]
 BV bounds    x[366]
 BV bounds    x[367]
 BV bounds    x[368]
 BV bounds    x[369]
 BV bounds    x[370]
 BV bounds    x[371]
 BV bounds    x[372]
 BV bounds    x[373]
 BV bounds    x[374]
 BV bounds    x[375]
 BV bounds    x[376]
 BV bounds    x[377]
 BV bounds    x[378]
 BV bounds    x[379]
 BV bounds    x[380]
 BV bounds    x[381]
 BV bounds    x[382]
 BV bounds    x[383]
 BV bounds    x[384]
 BV bounds    x[385]
 BV bounds    x[386]
 BV bounds    x[387]
 BV bounds    x[388]
 BV bounds    x[389]
 BV bounds    x[390]
 BV bounds    x[391]
 BV bounds    x[392]
 BV bounds    x[393]
 BV bounds    x[394]
 BV bounds    x[395]
 BV bounds    x[396]
 BV bounds    x[397]
 BV bounds    x[398]
 BV bounds    x[399]
 BV bounds    x[400]
 BV bounds    x[401]
 BV bounds    x[402]
 BV bounds    x[403]
 BV bounds    x[404]
 BV bounds    x[405]
 BV bounds    x[406]
 BV bounds    x[407]
 BV bounds    x[408]
 BV bounds    x[409]
 BV bounds    x[410]
 BV bounds    x[411]
 BV bounds    x[412]
 BV bounds    x[413]
 BV bounds    x[414]
 BV bounds    x[415]
 BV bounds    x[416]
 BV bounds    x[417]
 BV bounds    x[418]
 BV bounds    x[419]
 BV bounds    x[420]
 BV bounds    x[421]
 BV bounds    x[422]
 BV bounds    x[423]
 BV bounds    x[424]
 BV bounds    x[425]
 BV bounds    x[426]
 BV bounds    x[427]
 BV bounds    x[428]
 BV bounds    x[429]
 BV bounds    x[430]
 BV bounds    x[431]
 BV bounds    x[432]
 BV bounds    x[433]
 BV bounds    x[434]
 BV bounds    x[435]
 BV bounds    x[436]
 BV bounds    x[437]
 BV bounds    x[438]
 BV bounds    x[439]
 BV bounds    x[440]
 BV bounds    x[441]
 BV bounds    x[442]
 BV bounds    x[443]
 BV bounds    x[444]
 BV bounds    x[445]
 BV bounds    x[446]
 BV bounds    x[447]
 BV bounds    x[448]
 BV bounds    x[449]
 BV bounds    x[450]
 BV bounds    x[451]
 BV bounds    x[452]
 BV bounds    x[453]
 BV bounds    x[454]
 BV bounds    x[455]
 BV bounds    x[456]
 BV bounds    x[457]
 BV bounds    x[458]
 BV bounds    x[459]
 BV bounds    x[460]
 BV bounds    x[461]
 BV bounds    x[462]
 BV bounds    x[463]
 BV bounds    x[464]
 BV bounds    x[465]
 BV bounds    x[466]
 BV bounds    x[467]
 BV bounds    x[468]
 BV bounds    x[469]
 BV bounds    x[470]
 BV bounds    x[471]
 BV bounds    x[472]
 BV bounds    x[473]
 BV bounds    x[474]
 BV bounds    x[475]
 BV bounds    x[476]
 BV bounds    x[477]
 BV bounds    x[478]
 BV bounds    x[479]
 BV bounds    x[480]
 BV bounds    x[481]
 BV bounds    x[482]
 BV bounds    x[483]
 BV bounds    x[484]
 BV bounds    x[485]
 BV bounds    x[486]
 BV bounds    x[487]
 BV bounds    x[488]
 BV bounds    x[489]
 BV bounds    x[490]
 BV bounds    x[491]
 BV bounds    x[492]
 BV bounds    x[493]
 BV bounds    x[494]
 BV bounds    x[495]
 BV bounds    x[496]
 BV bounds    x[497]
 BV bounds    x[498]
 BV bounds    x[499]
 BV bounds    x[500]
 BV bounds    x[501]
 BV bounds    x[502]
 BV bounds    x[503]
 BV bounds    x[504]
 BV bounds    x[505]
 BV bounds    x[506]
 BV bounds    x[507]
 BV bounds    x[508]
 BV bounds    x[509]
 BV bounds    x[510]
 BV bounds    x[511]
 BV bounds    x[512]
 BV bounds    x[513]
 BV bounds    x[514]
 BV bounds    x[515]
 BV bounds    x[516]
 BV bounds    x[517]
 BV bounds    x[518]
 BV bounds    x[519]
 BV bounds    x[520]
 BV bounds    x[521]
 BV bounds    x[522]
 BV bounds    x[523]
 BV bounds    x[524]
 BV bounds    x[525]
 BV bounds    x[526]
 BV bounds    x[527]
 BV bounds    x[528]
 BV bounds    x[529]
 BV bounds    x[530]
 BV bounds    x[531]
 BV bounds    x[532]
 BV bounds    x[533]
 BV bounds    x[534]
 BV bounds    x[535]
 BV bounds    x[536]
 BV bounds    x[537]
 BV bounds    x[538]
 BV bounds    x[539]
 BV bounds    x[540]
 BV bounds    x[541]
 BV bounds    x[542]
 BV bounds    x[543]
 BV bounds    x[544]
 BV bounds    x[545]
 BV bounds    x[546]
 BV bounds    x[547]
 BV bounds    x[548]
 BV bounds    x[549]
 BV bounds    x[550]
 BV bounds    x[551]
 BV bounds    x[552]
 BV bounds    x[553]
 BV bounds    x[554]
 BV bounds    x[555]
 BV bounds    x[556]
 BV bounds    x[557]
 BV bounds    x[558]
 BV bounds    x[559]
 BV bounds    x[560]
 BV bounds    x[561]
 BV bounds    x[562]
 BV bounds    x[563]
 BV bounds    x[564]
 BV bounds    x[565]
 BV bounds    x[566]
 BV bounds    x[567]
 BV bounds    x[568]
 BV bounds    x[569]
 BV bounds    x[570]
 BV bounds    x[571]
 BV bounds    x[572]
 BV bounds    x[573]
 BV bounds    x[574]
 BV bounds    x[575]
 BV bounds    x[576]
 BV bounds    x[577]
 BV bounds    x[578]
 BV bounds    x[579]
 BV bounds    x[580]
 BV bounds    x[581]
 BV bounds    x[582]
 BV bounds    x[583]
 BV bounds    x[584]
 BV bounds    x[585]
 BV bounds    x[586]
 BV bounds    x[587]
 BV bounds    x[588]
 BV bounds    x[589]
 BV bounds    x[590]
 BV bounds    x[591]
 BV bounds    x[592]
 BV bounds    x[593]
 BV bounds    x[594]
 BV bounds    x[595]
 BV bounds    x[596]
 BV bounds    x[597]
 BV bounds    x[598]
 BV bounds    x[599]
 BV bounds    x[600]
 BV bounds    x[601]
 BV bounds    x[602]
 BV bounds    x[603]
 BV bounds    x[604]
 BV bounds    x[605]
 BV bounds    x[606]
 BV bounds    x[607]
 BV bounds    x[608]
 BV bounds    x[609]
 BV bounds    x[610]
 BV bounds    x[611]
 BV bounds    x[612]
 BV bounds    x[613]
 BV bounds    x[614]
 BV bounds    x[615]
 BV bounds    x[616]
 BV bounds    x[617]
 BV bounds    x[618]
 BV bounds    x[619]
 BV bounds    x[620]
 BV bounds    x[621]
 BV bounds    x[622]
 BV bounds    x[623]
 BV bounds    x[624]
 BV bounds    x[625]
 BV bounds    x[626]
 BV bounds    x[627]
 BV bounds    x[628]
 BV bounds    x[629]
 BV bounds    x[630]
 BV bounds    x[631]
 BV bounds    x[632]
 BV bounds    x[633]
 BV bounds    x[634]
 BV bounds    x[635]
 BV bounds    x[636]
 BV bounds    x[637]
 BV bounds    x[638]
 BV bounds    x[639]
 BV bounds    x[640]
 BV bounds    x[641]
 BV bounds    x[642]
 BV bounds    x[643]
 BV bounds    x[644]
 BV bounds    x[645]
 BV bounds    x[646]
 BV bounds    x[647]
 BV bounds    x[648]
 BV bounds    x[649]
 BV bounds    x[650]
 BV bounds    x[651]
 BV bounds    x[652]
 BV bounds    x[653]
 BV bounds    x[654]
 BV bounds    x[655]
 BV bounds    x[656]
 BV bounds    x[657]
 BV bounds    x[658]
 BV bounds    x[659]
 BV bounds    x[660]
 BV bounds    x[661]
 BV bounds    x[662]
 BV bounds    x[663]
 BV bounds    x[664]
 BV bounds    x[665]
 BV bounds    x[666]
 BV bounds    x[667]
 BV bounds    x[668]
 BV bounds    x[669]
 BV bounds    x[670]
 BV bounds    x[671]
 BV bounds    x[672]
 BV bounds    x[673]
 BV bounds    x[674]
 BV bounds    x[675]
 BV bounds    x[676]
 BV bounds    x[677]
 BV bounds    x[678]
 BV bounds    x[679]
 BV bounds    x[680]
 BV bounds    x[681]
 BV bounds    x[682]
 BV bounds    x[683]
 BV bounds    x[684]
 BV bounds    x[685]
 BV bounds    x[686]
 BV bounds    x[687]
 BV bounds    x[688]
 BV bounds    x[689]
 BV bounds    x[690]
 BV bounds    x[691]
 BV bounds    x[692]
 BV bounds    x[693]
 BV bounds    x[694]
 BV bounds    x[695]
 BV bounds    x[696]
 BV bounds    x[697]
 BV bounds    x[698]
 BV bounds    x[699]
 BV bounds    x[700]
 BV bounds    x[701]
 BV bounds    x[702]
 BV bounds    x[703]
 BV bounds    x[704]
 BV bounds    x[705]
 BV bounds    x[706]
 BV bounds    x[707]
 BV bounds    x[708]
 BV bounds    x[709]
 BV bounds    x[710]
 BV bounds    x[711]
 BV bounds    x[712]
 BV bounds    x[713]
 BV bounds    x[714]
 BV bounds    x[715]
 BV bounds    x[716]
 BV bounds    x[717]
 BV bounds    x[718]
 BV bounds    x[719]
 BV bounds    x[720]
 BV bounds    x[721]
 BV bounds    x[722]
 BV bounds    x[723]
 BV bounds    x[724]
 BV bounds    x[725]
 BV bounds    x[726]
 BV bounds    x[727]
 BV bounds    x[728]
 BV bounds    x[729]
 BV bounds    x[730]
 BV bounds    x[731]
 BV bounds    x[732]
 BV bounds    x[733]
 BV bounds    x[734]
 BV bounds    x[735]
 BV bounds    x[736]
 BV bounds    x[737]
 BV bounds    x[738]
 BV bounds    x[739]
 BV bounds    x[740]
 BV bounds    x[741]
 BV bounds    x[742]
 BV bounds    x[743]
 BV bounds    x[744]
 BV bounds    x[745]
 BV bounds    x[746]
 BV bounds    x[747]
 BV bounds    x[748]
 BV bounds    x[749]
 BV bounds    x[750]
 BV bounds    x[751]
 BV bounds    x[752]
 BV bounds    x[753]
 BV bounds    x[754]
 BV bounds    x[755]
 BV bounds    x[756]
 BV bounds    x[757]
 BV bounds    x[758]
 BV bounds    x[759]
 BV bounds    x[760]
 BV bounds    x[761]
 BV bounds    x[762]
 BV bounds    x[763]
 BV bounds    x[764]
 BV bounds    x[765]
 BV bounds    x[766]
 BV bounds    x[767]
 BV bounds    x[768]
 BV bounds    x[769]
 BV bounds    x[770]
 BV bounds    x[771]
 BV bounds    x[772]
 BV bounds    x[773]
 BV bounds    x[774]
 BV bounds    x[775]
 BV bounds    x[776]
 BV bounds    x[777]
 BV bounds    x[778]
 BV bounds    x[779]
 BV bounds    x[780]
 BV bounds    x[781]
 BV bounds    x[782]
 BV bounds    x[783]
 BV bounds    x[784]
 BV bounds    x[785]
 BV bounds    x[786]
 BV bounds    x[787]
 BV bounds    x[788]
 BV bounds    x[789]
 BV bounds    x[790]
 BV bounds    x[791]
 BV bounds    x[792]
 BV bounds    x[793]
 BV bounds    x[794]
 BV bounds    x[795]
 BV bounds    x[796]
 BV bounds    x[797]
 BV bounds    x[798]
 BV bounds    x[799]
 BV bounds    x[800]
 BV bounds    x[801]
 BV bounds    x[802]
 BV bounds    x[803]
 BV bounds    x[804]
 BV bounds    x[805]
 BV bounds    x[806]
 BV bounds    x[807]
 BV bounds    x[808]
 BV bounds    x[809]
 BV bounds    x[810]
 BV bounds    x[811]
 BV bounds    x[812]
 BV bounds    x[813]
 BV bounds    x[814]
 BV bounds    x[815]
 BV bounds    x[816]
 BV bounds    x[817]
 BV bounds    x[818]
 BV bounds    x[819]
 BV bounds    x[820]
 BV bounds    x[821]
 BV bounds    x[822]
 BV bounds    x[823]
 BV bounds    x[824]
 BV bounds    x[825]
 BV bounds    x[826]
 BV bounds    x[827]
 BV bounds    x[828]
 BV bounds    x[829]
 BV bounds    x[830]
 BV bounds    x[831]
 BV bounds    x[832]
 BV bounds    x[833]
 BV bounds    x[834]
 BV bounds    x[835]
 BV bounds    x[836]
 BV bounds    x[837]
 BV bounds    x[838]
 BV bounds    x[839]
 BV bounds    x[840]
 BV bounds    x[841]
 BV bounds    x[842]
 BV bounds    x[843]
 BV bounds    x[844]
 BV bounds    x[845]
 BV bounds    x[846]
 BV bounds    x[847]
 BV bounds    x[848]
 BV bounds    x[849]
 BV bounds    x[850]
 BV bounds    x[851]
 BV bounds    x[852]
 BV bounds    x[853]
 BV bounds    x[854]
 BV bounds    x[855]
 BV bounds    x[856]
 BV bounds    x[857]
 BV bounds    x[858]
 BV bounds    x[859]
 BV bounds    x[860]
 BV bounds    x[861]
 BV bounds    x[862]
 BV bounds    x[863]
 BV bounds    x[864]
 BV bounds    x[865]
 BV bounds    x[866]
 BV bounds    x[867]
 BV bounds    x[868]
 BV bounds    x[869]
 BV bounds    x[870]
 BV bounds    x[871]
 BV bounds    x[872]
 BV bounds    x[873]
 BV bounds    x[874]
 BV bounds    x[875]
 BV bounds    x[876]
 BV bounds    x[877]
 BV bounds    x[878]
 BV bounds    x[879]
 BV bounds    x[880]
 BV bounds    x[881]
 BV bounds    x[882]
 BV bounds    x[883]
 BV bounds    x[884]
 BV bounds    x[885]
 BV bounds    x[886]
 BV bounds    x[887]
 BV bounds    x[888]
 BV bounds    x[889]
 BV bounds    x[890]
 BV bounds    x[891]
 BV bounds    x[892]
 BV bounds    x[893]
 BV bounds    x[894]
 BV bounds    x[895]
 BV bounds    x[896]
 BV bounds    x[897]
 BV bounds    x[898]
 BV bounds    x[899]
 BV bounds    x[900]
 BV bounds    x[901]
 BV bounds    x[902]
 BV bounds    x[903]
 BV bounds    x[904]
 BV bounds    x[905]
 BV bounds    x[906]
 BV bounds    x[907]
 BV bounds    x[908]
 BV bounds    x[909]
 BV bounds    x[910]
 BV bounds    x[911]
 BV bounds    x[912]
 BV bounds    x[913]
 BV bounds    x[914]
 BV bounds    x[915]
 BV bounds    x[916]
 BV bounds    x[917]
 BV bounds    x[918]
 BV bounds    x[919]
 BV bounds    x[920]
 BV bounds    x[921]
 BV bounds    x[922]
 BV bounds    x[923]
 BV bounds    x[924]
 BV bounds    x[925]
 BV bounds    x[926]
 BV bounds    x[927]
 BV bounds    x[928]
 BV bounds    x[929]
 BV bounds    x[930]
 BV bounds    x[931]
 BV bounds    x[932]
 BV bounds    x[933]
 BV bounds    x[934]
 BV bounds    x[935]
 BV bounds    x[936]
 BV bounds    x[937]
 BV bounds    x[938]
 BV bounds    x[939]
 BV bounds    x[940]
 BV bounds    x[941]
 BV bounds    x[942]
 BV bounds    x[943]
 BV bounds    x[944]
 BV bounds    x[945]
 BV bounds    x[946]
 BV bounds    x[947]
 BV bounds    x[948]
 BV bounds    x[949]
 BV bounds    x[950]
 BV bounds    x[951]
 BV bounds    x[952]
 BV bounds    x[953]
 BV bounds    x[954]
 BV bounds    x[955]
 BV bounds    x[956]
 BV bounds    x[957]
 BV bounds    x[958]
 BV bounds    x[959]
 BV bounds    x[960]
 BV bounds    x[961]
 BV bounds    x[962]
 BV bounds    x[963]
 BV bounds    x[964]
 BV bounds    x[965]
 BV bounds    x[966]
 BV bounds    x[967]
 BV bounds    x[968]
 BV bounds    x[969]
 BV bounds    x[970]
 BV bounds    x[971]
 BV bounds    x[972]
 BV bounds    x[973]
 BV bounds    x[974]
 BV bounds    x[975]
 BV bounds    x[976]
 BV bounds    x[977]
 BV bounds    x[978]
 BV bounds    x[979]
 BV bounds    x[980]
 BV bounds    x[981]
 BV bounds    x[982]
 BV bounds    x[983]
 BV bounds    x[984]
 BV bounds    x[985]
 BV bounds    x[986]
 BV bounds    x[987]
 BV bounds    x[988]
 BV bounds    x[989]
 BV bounds    x[990]
 BV bounds    x[991]
 BV bounds    x[992]
 BV bounds    x[993]
 BV bounds    x[994]
 BV bounds    x[995]
 BV bounds    x[996]
 BV bounds    x[997]
 BV bounds    x[998]
 BV bounds    x[999]
 BV bounds    x[1000]
 BV bounds    x[1001]
 BV bounds    x[1002]
 BV bounds    x[1003]
 BV bounds    x[1004]
 BV bounds    x[1005]
 BV bounds    x[1006]
 BV bounds    x[1007]
 BV bounds    x[1008]
 BV bounds    x[1009]
 BV bounds    x[1010]
 BV bounds    x[1011]
 BV bounds    x[1012]
 BV bounds    x[1013]
 BV bounds    x[1014]
 BV bounds    x[1015]
 BV bounds    x[1016]
 BV bounds    x[1017]
 BV bounds    x[1018]
 BV bounds    x[1019]
 BV bounds    x[1020]
 BV bounds    x[1021]
 BV bounds    x[1022]
 BV bounds    x[1023]
 BV bounds    x[1024]
 BV bounds    x[1025]
 BV bounds    x[1026]
 BV bounds    x[1027]
 BV bounds    x[1028]
 BV bounds    x[1029]
 BV bounds    x[1030]
 BV bounds    x[1031]
 BV bounds    x[1032]
 BV bounds    x[1033]
 BV bounds    x[1034]
 BV bounds    x[1035]
 BV bounds    x[1036]
 BV bounds    x[1037]
 BV bounds    x[1038]
 BV bounds    x[1039]
 BV bounds    x[1040]
 BV bounds    x[1041]
 BV bounds    x[1042]
 BV bounds    x[1043]
 BV bounds    x[1044]
 BV bounds    x[1045]
 BV bounds    x[1046]
 BV bounds    x[1047]
 BV bounds    x[1048]
 BV bounds    x[1049]
 BV bounds    x[1050]
 BV bounds    x[1051]
 BV bounds    x[1052]
 BV bounds    x[1053]
 BV bounds    x[1054]
 BV bounds    x[1055]
 BV bounds    x[1056]
 BV bounds    x[1057]
 BV bounds    x[1058]
 BV bounds    x[1059]
 BV bounds    x[1060]
 BV bounds    x[1061]
 BV bounds    x[1062]
 BV bounds    x[1063]
 BV bounds    x[1064]
 BV bounds    x[1065]
 BV bounds    x[1066]
 BV bounds    x[1067]
 BV bounds    x[1068]
 BV bounds    x[1069]
 BV bounds    x[1070]
 BV bounds    x[1071]
 BV bounds    x[1072]
 BV bounds    x[1073]
 BV bounds    x[1074]
 BV bounds    x[1075]
 BV bounds    x[1076]
 BV bounds    x[1077]
 BV bounds    x[1078]
 BV bounds    x[1079]
 BV bounds    x[1080]
 BV bounds    x[1081]
 BV bounds    x[1082]
 BV bounds    x[1083]
 BV bounds    x[1084]
 BV bounds    x[1085]
 BV bounds    x[1086]
 BV bounds    x[1087]
 BV bounds    x[1088]
 BV bounds    x[1089]
 BV bounds    x[1090]
 BV bounds    x[1091]
 BV bounds    x[1092]
 BV bounds    x[1093]
 BV bounds    x[1094]
 BV bounds    x[1095]
 BV bounds    x[1096]
 BV bounds    x[1097]
 BV bounds    x[1098]
 BV bounds    x[1099]
 BV bounds    x[1100]
 BV bounds    x[1101]
 BV bounds    x[1102]
 BV bounds    x[1103]
 BV bounds    x[1104]
 BV bounds    x[1105]
 BV bounds    x[1106]
 BV bounds    x[1107]
 BV bounds    x[1108]
 BV bounds    x[1109]
 BV bounds    x[1110]
 BV bounds    x[1111]
 BV bounds    x[1112]
 BV bounds    x[1113]
 BV bounds    x[1114]
 BV bounds    x[1115]
 BV bounds    x[1116]
 BV bounds    x[1117]
 BV bounds    x[1118]
 BV bounds    x[1119]
 BV bounds    x[1120]
 BV bounds    x[1121]
 BV bounds    x[1122]
 BV bounds    x[1123]
 BV bounds    x[1124]
 BV bounds    x[1125]
 BV bounds    x[1126]
 BV bounds    x[1127]
 BV bounds    x[1128]
 BV bounds    x[1129]
 BV bounds    x[1130]
 BV bounds    x[1131]
 BV bounds    x[1132]
 BV bounds    x[1133]
 BV bounds    x[1134]
 BV bounds    x[1135]
 BV bounds    x[1136]
 BV bounds    x[1137]
 BV bounds    x[1138]
 BV bounds    x[1139]
 BV bounds    x[1140]
 BV bounds    x[1141]
 BV bounds    x[1142]
 BV bounds    x[1143]
 BV bounds    x[1144]
 BV bounds    x[1145]
 BV bounds    x[1146]
 BV bounds    x[1147]
 BV bounds    x[1148]
 BV bounds    x[1149]
 BV bounds    x[1150]
 BV bounds    x[1151]
 BV bounds    x[1152]
 BV bounds    x[1153]
 BV bounds    x[1154]
 BV bounds    x[1155]
 BV bounds    x[1156]
 BV bounds    x[1157]
 BV bounds    x[1158]
 BV bounds    x[1159]
 BV bounds    x[1160]
 BV bounds    x[1161]
 BV bounds    x[1162]
 BV bounds    x[1163]
 BV bounds    x[1164]
 BV bounds    x[1165]
 BV bounds    x[1166]
 BV bounds    x[1167]
 BV bounds    x[1168]
 BV bounds    x[1169]
 BV bounds    x[1170]
 BV bounds    x[1171]
 BV bounds    x[1172]
 BV bounds    x[1173]
 BV bounds    x[1174]
 BV bounds    x[1175]
 BV bounds    x[1176]
 BV bounds    x[1177]
 BV bounds    x[1178]
 BV bounds    x[1179]
 BV bounds    x[1180]
 BV bounds    x[1181]
 BV bounds    x[1182]
 BV bounds    x[1183]
 BV bounds    x[1184]
 BV bounds    x[1185]
 BV bounds    x[1186]
 BV bounds    x[1187]
 BV bounds    x[1188]
 BV bounds    x[1189]
 BV bounds    x[1190]
 BV bounds    x[1191]
 BV bounds    x[1192]
 BV bounds    x[1193]
 BV bounds    x[1194]
 BV bounds    x[1195]
 BV bounds    x[1196]
 BV bounds    x[1197]
 BV bounds    x[1198]
 BV bounds    x[1199]
 BV bounds    x[1200]
 BV bounds    x[1201]
 BV bounds    x[1202]
 BV bounds    x[1203]
 BV bounds    x[1204]
 BV bounds    x[1205]
 BV bounds    x[1206]
 BV bounds    x[1207]
 BV bounds    x[1208]
 BV bounds    x[1209]
 BV bounds    x[1210]
 BV bounds    x[1211]
 BV bounds    x[1212]
 BV bounds    x[1213]
 BV bounds    x[1214]
 BV bounds    x[1215]
 BV bounds    x[1216]
 BV bounds    x[1217]
 BV bounds    x[1218]
 BV bounds    x[1219]
 BV bounds    x[1220]
 BV bounds    x[1221]
 BV bounds    x[1222]
 BV bounds    x[1223]
 BV bounds    x[1224]
 BV bounds    x[1225]
 BV bounds    x[1226]
 BV bounds    x[1227]
 BV bounds    x[1228]
 BV bounds    x[1229]
 BV bounds    x[1230]
 BV bounds    x[1231]
 BV bounds    x[1232]
 BV bounds    x[1233]
 BV bounds    x[1234]
 BV bounds    x[1235]
 BV bounds    x[1236]
 BV bounds    x[1237]
 BV bounds    x[1238]
 BV bounds    x[1239]
 BV bounds    x[1240]
 BV bounds    x[1241]
 BV bounds    x[1242]
 BV bounds    x[1243]
 BV bounds    x[1244]
 BV bounds    x[1245]
 BV bounds    x[1246]
 BV bounds    x[1247]
 BV bounds    x[1248]
 BV bounds    x[1249]
 BV bounds    x[1250]
 BV bounds    x[1251]
 BV bounds    x[1252]
 BV bounds    x[1253]
 BV bounds    x[1254]
 BV bounds    x[1255]
 BV bounds    x[1256]
 BV bounds    x[1257]
 BV bounds    x[1258]
 BV bounds    x[1259]
 BV bounds    x[1260]
 BV bounds    x[1261]
 BV bounds    x[1262]
 BV bounds    x[1263]
 BV bounds    x[1264]
 BV bounds    x[1265]
 BV bounds    x[1266]
 BV bounds    x[1267]
 BV bounds    x[1268]
 BV bounds    x[1269]
 BV bounds    x[1270]
 BV bounds    x[1271]
 BV bounds    x[1272]
 BV bounds    x[1273]
 BV bounds    x[1274]
 BV bounds    x[1275]
 BV bounds    x[1276]
 BV bounds    x[1277]
 BV bounds    x[1278]
 BV bounds    x[1279]
 BV bounds    x[1280]
 BV bounds    x[1281]
 BV bounds    x[1282]
 BV bounds    x[1283]
 BV bounds    x[1284]
 BV bounds    x[1285]
 BV bounds    x[1286]
 BV bounds    x[1287]
 BV bounds    x[1288]
 BV bounds    x[1289]
 BV bounds    x[1290]
 BV bounds    x[1291]
 BV bounds    x[1292]
 BV bounds    x[1293]
 BV bounds    x[1294]
 BV bounds    x[1295]
 BV bounds    x[1296]
 BV bounds    x[1297]
 BV bounds    x[1298]
 BV bounds    x[1299]
 BV bounds    x[1300]
 BV bounds    x[1301]
 BV bounds    x[1302]
 BV bounds    x[1303]
 BV bounds    x[1304]
 BV bounds    x[1305]
 BV bounds    x[1306]
 BV bounds    x[1307]
 BV bounds    x[1308]
 BV bounds    x[1309]
 BV bounds    x[1310]
 BV bounds    x[1311]
 BV bounds    x[1312]
 BV bounds    x[1313]
 BV bounds    x[1314]
 BV bounds    x[1315]
 BV bounds    x[1316]
 BV bounds    x[1317]
 BV bounds    x[1318]
 BV bounds    x[1319]
 BV bounds    x[1320]
 BV bounds    x[1321]
 BV bounds    x[1322]
 BV bounds    x[1323]
 BV bounds    x[1324]
 BV bounds    x[1325]
 BV bounds    x[1326]
 BV bounds    x[1327]
 BV bounds    x[1328]
 BV bounds    x[1329]
 BV bounds    x[1330]
 BV bounds    x[1331]
 BV bounds    x[1332]
 BV bounds    x[1333]
 BV bounds    x[1334]
 BV bounds    x[1335]
 BV bounds    x[1336]
 BV bounds    x[1337]
 BV bounds    x[1338]
 BV bounds    x[1339]
 BV bounds    x[1340]
 BV bounds    x[1341]
 BV bounds    x[1342]
 BV bounds    x[1343]
 BV bounds    x[1344]
 BV bounds    x[1345]
 BV bounds    x[1346]
 BV bounds    x[1347]
 BV bounds    x[1348]
 BV bounds    x[1349]
 BV bounds    x[1350]
 BV bounds    x[1351]
 BV bounds    x[1352]
 BV bounds    x[1353]
 BV bounds    x[1354]
 BV bounds    x[1355]
 BV bounds    x[1356]
 BV bounds    x[1357]
 BV bounds    x[1358]
 BV bounds    x[1359]
 BV bounds    x[1360]
 BV bounds    x[1361]
 BV bounds    x[1362]
 BV bounds    x[1363]
 BV bounds    x[1364]
 BV bounds    x[1365]
 BV bounds    x[1366]
 BV bounds    x[1367]
 BV bounds    x[1368]
 BV bounds    x[1369]
 BV bounds    x[1370]
 BV bounds    x[1371]
 BV bounds    x[1372]
 BV bounds    x[1373]
 BV bounds    x[1374]
 BV bounds    x[1375]
 BV bounds    x[1376]
 BV bounds    x[1377]
 BV bounds    x[1378]
 BV bounds    x[1379]
 BV bounds    x[1380]
 BV bounds    x[1381]
 BV bounds    x[1382]
 BV bounds    x[1383]
 BV bounds    x[1384]
 BV bounds    x[1385]
 BV bounds    x[1386]
 BV bounds    x[1387]
 BV bounds    x[1388]
 BV bounds    x[1389]
 BV bounds    x[1390]
 BV bounds    x[1391]
 BV bounds    x[1392]
 BV bounds    x[1393]
 BV bounds    x[1394]
 BV bounds    x[1395]
 BV bounds    x[1396]
 BV bounds    x[1397]
 BV bounds    x[1398]
 BV bounds    x[1399]
 BV bounds    x[1400]
 BV bounds    x[1401]
 BV bounds    x[1402]
 BV bounds    x[1403]
 BV bounds    x[1404]
 BV bounds    x[1405]
 BV bounds    x[1406]
 BV bounds    x[1407]
 BV bounds    x[1408]
 BV bounds    x[1409]
 BV bounds    x[1410]
 BV bounds    x[1411]
 BV bounds    x[1412]
 BV bounds    x[1413]
 BV bounds    x[1414]
 BV bounds    x[1415]
 BV bounds    x[1416]
 BV bounds    x[1417]
 BV bounds    x[1418]
 BV bounds    x[1419]
 BV bounds    x[1420]
 BV bounds    x[1421]
 BV bounds    x[1422]
 BV bounds    x[1423]
 BV bounds    x[1424]
 BV bounds    x[1425]
 BV bounds    x[1426]
 BV bounds    x[1427]
 BV bounds    x[1428]
 BV bounds    x[1429]
 BV bounds    x[1430]
 BV bounds    x[1431]
 BV bounds    x[1432]
 BV bounds    x[1433]
 BV bounds    x[1434]
 BV bounds    x[1435]
 BV bounds    x[1436]
 BV bounds    x[1437]
 BV bounds    x[1438]
 BV bounds    x[1439]
 BV bounds    x[1440]
 BV bounds    x[1441]
 BV bounds    x[1442]
 BV bounds    x[1443]
 BV bounds    x[1444]
 BV bounds    x[1445]
 BV bounds    x[1446]
 BV bounds    x[1447]
 BV bounds    x[1448]
 BV bounds    x[1449]
 BV bounds    x[1450]
 BV bounds    x[1451]
 BV bounds    x[1452]
 BV bounds    x[1453]
 BV bounds    x[1454]
 BV bounds    x[1455]
 BV bounds    x[1456]
 BV bounds    x[1457]
 BV bounds    x[1458]
 BV bounds    x[1459]
 BV bounds    x[1460]
 BV bounds    x[1461]
 BV bounds    x[1462]
 BV bounds    x[1463]
 BV bounds    x[1464]
 BV bounds    x[1465]
 BV bounds    x[1466]
 BV bounds    x[1467]
 BV bounds    x[1468]
 BV bounds    x[1469]
 BV bounds    x[1470]
 BV bounds    x[1471]
 BV bounds    x[1472]
 BV bounds    x[1473]
 BV bounds    x[1474]
 BV bounds    x[1475]
 BV bounds    x[1476]
 BV bounds    x[1477]
 BV bounds    x[1478]
 BV bounds    x[1479]
 BV bounds    x[1480]
 BV bounds    x[1481]
 BV bounds    x[1482]
 BV bounds    x[1483]
 BV bounds    x[1484]
 BV bounds    x[1485]
 BV bounds    x[1486]
 BV bounds    x[1487]
 BV bounds    x[1488]
 BV bounds    x[1489]
 BV bounds    x[1490]
 BV bounds    x[1491]
 BV bounds    x[1492]
 BV bounds    x[1493]
 BV bounds    x[1494]
 BV bounds    x[1495]
 BV bounds    x[1496]
 BV bounds    x[1497]
 BV bounds    x[1498]
 BV bounds    x[1499]
 BV bounds    x[1500]
 BV bounds    x[1501]
 BV bounds    x[1502]
 BV bounds    x[1503]
 BV bounds    x[1504]
 BV bounds    x[1505]
 BV bounds    x[1506]
 BV bounds    x[1507]
 BV bounds    x[1508]
 BV bounds    x[1509]
 BV bounds    x[1510]
 BV bounds    x[1511]
 BV bounds    x[1512]
 BV bounds    x[1513]
 BV bounds    x[1514]
 BV bounds    x[1515]
 BV bounds    x[1516]
 BV bounds    x[1517]
 BV bounds    x[1518]
 BV bounds    x[1519]
 BV bounds    x[1520]
 BV bounds    x[1521]
 BV bounds    x[1522]
 BV bounds    x[1523]
 BV bounds    x[1524]
 BV bounds    x[1525]
 BV bounds    x[1526]
 BV bounds    x[1527]
 BV bounds    x[1528]
 BV bounds    x[1529]
 BV bounds    x[1530]
 BV bounds    x[1531]
 BV bounds    x[1532]
 BV bounds    x[1533]
 BV bounds    x[1534]
 BV bounds    x[1535]
 BV bounds    x[1536]
 BV bounds    x[1537]
 BV bounds    x[1538]
 BV bounds    x[1539]
 BV bounds    x[1540]
 BV bounds    x[1541]
 BV bounds    x[1542]
 BV bounds    x[1543]
 BV bounds    x[1544]
 BV bounds    x[1545]
 BV bounds    x[1546]
 BV bounds    x[1547]
 BV bounds    x[1548]
 BV bounds    x[1549]
 BV bounds    x[1550]
 BV bounds    x[1551]
 BV bounds    x[1552]
 BV bounds    x[1553]
 BV bounds    x[1554]
 BV bounds    x[1555]
 BV bounds    x[1556]
 BV bounds    x[1557]
 BV bounds    x[1558]
 BV bounds    x[1559]
 BV bounds    x[1560]
 BV bounds    x[1561]
 BV bounds    x[1562]
 BV bounds    x[1563]
 BV bounds    x[1564]
 BV bounds    x[1565]
 BV bounds    x[1566]
 BV bounds    x[1567]
 BV bounds    x[1568]
 BV bounds    x[1569]
 BV bounds    x[1570]
 BV bounds    x[1571]
 BV bounds    x[1572]
 BV bounds    x[1573]
 BV bounds    x[1574]
 BV bounds    x[1575]
 BV bounds    x[1576]
 BV bounds    x[1577]
 BV bounds    x[1578]
 BV bounds    x[1579]
 BV bounds    x[1580]
 BV bounds    x[1581]
 BV bounds    x[1582]
 BV bounds    x[1583]
 BV bounds    x[1584]
 BV bounds    x[1585]
 BV bounds    x[1586]
 BV bounds    x[1587]
 BV bounds    x[1588]
 BV bounds    x[1589]
 BV bounds    x[1590]
 BV bounds    x[1591]
 BV bounds    x[1592]
 BV bounds    x[1593]
 BV bounds    x[1594]
 BV bounds    x[1595]
 BV bounds    x[1596]
 BV bounds    x[1597]
 BV bounds    x[1598]
 BV bounds    x[1599]
 BV bounds    x[1600]
 BV bounds    x[1601]
 BV bounds    x[1602]
 BV bounds    x[1603]
 BV bounds    x[1604]
 BV bounds    x[1605]
 BV bounds    x[1606]
 BV bounds    x[1607]
 BV bounds    x[1608]
 BV bounds    x[1609]
 BV bounds    x[1610]
 BV bounds    x[1611]
 BV bounds    x[1612]
 BV bounds    x[1613]
 BV bounds    x[1614]
 BV bounds    x[1615]
 BV bounds    x[1616]
 BV bounds    x[1617]
 BV bounds    x[1618]
 BV bounds    x[1619]
 BV bounds    x[1620]
 BV bounds    x[1621]
 BV bounds    x[1622]
 BV bounds    x[1623]
 BV bounds    x[1624]
 BV bounds    x[1625]
 BV bounds    x[1626]
 BV bounds    x[1627]
 BV bounds    x[1628]
 BV bounds    x[1629]
 BV bounds    x[1630]
 BV bounds    x[1631]
 BV bounds    x[1632]
 BV bounds    x[1633]
 BV bounds    x[1634]
 BV bounds    x[1635]
 BV bounds    x[1636]
 BV bounds    x[1637]
 BV bounds    x[1638]
 BV bounds    x[1639]
 BV bounds    x[1640]
 BV bounds    x[1641]
 BV bounds    x[1642]
 BV bounds    x[1643]
 BV bounds    x[1644]
 BV bounds    x[1645]
 BV bounds    x[1646]
 BV bounds    x[1647]
 BV bounds    x[1648]
 BV bounds    x[1649]
 BV bounds    x[1650]
 BV bounds    x[1651]
 BV bounds    x[1652]
 BV bounds    x[1653]
 BV bounds    x[1654]
 BV bounds    x[1655]
 BV bounds    x[1656]
 BV bounds    x[1657]
 BV bounds    x[1658]
 BV bounds    x[1659]
 BV bounds    x[1660]
 BV bounds    x[1661]
 BV bounds    x[1662]
 BV bounds    x[1663]
 BV bounds    x[1664]
 BV bounds    x[1665]
 BV bounds    x[1666]
 BV bounds    x[1667]
 BV bounds    x[1668]
 BV bounds    x[1669]
 BV bounds    x[1670]
 BV bounds    x[1671]
 BV bounds    x[1672]
 BV bounds    x[1673]
 BV bounds    x[1674]
 BV bounds    x[1675]
 BV bounds    x[1676]
 BV bounds    x[1677]
 BV bounds    x[1678]
 BV bounds    x[1679]
 BV bounds    x[1680]
 BV bounds    x[1681]
 BV bounds    x[1682]
 BV bounds    x[1683]
 BV bounds    x[1684]
 BV bounds    x[1685]
 BV bounds    x[1686]
 BV bounds    x[1687]
 BV bounds    x[1688]
 BV bounds    x[1689]
 BV bounds    x[1690]
 BV bounds    x[1691]
 BV bounds    x[1692]
 BV bounds    x[1693]
 BV bounds    x[1694]
 BV bounds    x[1695]
 BV bounds    x[1696]
 BV bounds    x[1697]
 BV bounds    x[1698]
 BV bounds    x[1699]
 BV bounds    x[1700]
 BV bounds    x[1701]
 BV bounds    x[1702]
 BV bounds    x[1703]
 BV bounds    x[1704]
 BV bounds    x[1705]
 BV bounds    x[1706]
 BV bounds    x[1707]
 BV bounds    x[1708]
 BV bounds    x[1709]
 BV bounds    x[1710]
 BV bounds    x[1711]
 BV bounds    x[1712]
 BV bounds    x[1713]
 BV bounds    x[1714]
 BV bounds    x[1715]
 BV bounds    x[1716]
 BV bounds    x[1717]
 BV bounds    x[1718]
 BV bounds    x[1719]
 BV bounds    x[1720]
 BV bounds    x[1721]
 BV bounds    x[1722]
 BV bounds    x[1723]
 BV bounds    x[1724]
 BV bounds    x[1725]
 BV bounds    x[1726]
 BV bounds    x[1727]
 BV bounds    x[1728]
 BV bounds    x[1729]
 BV bounds    x[1730]
 BV bounds    x[1731]
 BV bounds    x[1732]
 BV bounds    x[1733]
 BV bounds    x[1734]
 BV bounds    x[1735]
 BV bounds    x[1736]
 BV bounds    x[1737]
 BV bounds    x[1738]
 BV bounds    x[1739]
 BV bounds    x[1740]
 BV bounds    x[1741]
 BV bounds    x[1742]
 BV bounds    x[1743]
 BV bounds    x[1744]
 BV bounds    x[1745]
 BV bounds    x[1746]
 BV bounds    x[1747]
 BV bounds    x[1748]
 BV bounds    x[1749]
 BV bounds    x[1750]
 BV bounds    x[1751]
 BV bounds    x[1752]
 BV bounds    x[1753]
 BV bounds    x[1754]
 BV bounds    x[1755]
 BV bounds    x[1756]
 BV bounds    x[1757]
 BV bounds    x[1758]
 BV bounds    x[1759]
 BV bounds    x[1760]
 BV bounds    x[1761]
 BV bounds    x[1762]
 BV bounds    x[1763]
 BV bounds    x[1764]
 BV bounds    x[1765]
 BV bounds    x[1766]
 BV bounds    x[1767]
 BV bounds    x[1768]
 BV bounds    x[1769]
 BV bounds    x[1770]
 BV bounds    x[1771]
 BV bounds    x[1772]
 BV bounds    x[1773]
 BV bounds    x[1774]
 BV bounds    x[1775]
 BV bounds    x[1776]
 BV bounds    x[1777]
 BV bounds    x[1778]
 BV bounds    x[1779]
 BV bounds    x[1780]
 BV bounds    x[1781]
 BV bounds    x[1782]
 BV bounds    x[1783]
 BV bounds    x[1784]
 BV bounds    x[1785]
 BV bounds    x[1786]
 BV bounds    x[1787]
 BV bounds    x[1788]
 BV bounds    x[1789]
 BV bounds    x[1790]
 BV bounds    x[1791]
 BV bounds    x[1792]
 BV bounds    x[1793]
 BV bounds    x[1794]
 BV bounds    x[1795]
 BV bounds    x[1796]
 BV bounds    x[1797]
 BV bounds    x[1798]
 BV bounds    x[1799]
 BV bounds    x[1800]
 BV bounds    x[1801]
 BV bounds    x[1802]
 BV bounds    x[1803]
 BV bounds    x[1804]
 BV bounds    x[1805]
 BV bounds    x[1806]
 BV bounds    x[1807]
 BV bounds    x[1808]
 BV bounds    x[1809]
 BV bounds    x[1810]
 BV bounds    x[1811]
 BV bounds    x[1812]
 BV bounds    x[1813]
 BV bounds    x[1814]
 BV bounds    x[1815]
 BV bounds    x[1816]
 BV bounds    x[1817]
 BV bounds    x[1818]
 BV bounds    x[1819]
 BV bounds    x[1820]
 BV bounds    x[1821]
 BV bounds    x[1822]
 BV bounds    x[1823]
 BV bounds    x[1824]
 BV bounds    x[1825]
 BV bounds    x[1826]
 BV bounds    x[1827]
 BV bounds    x[1828]
 BV bounds    x[1829]
 BV bounds    x[1830]
 BV bounds    x[1831]
 BV bounds    x[1832]
 BV bounds    x[1833]
 BV bounds    x[1834]
 BV bounds    x[1835]
 BV bounds    x[1836]
 BV bounds    x[1837]
 BV bounds    x[1838]
 BV bounds    x[1839]
 BV bounds    x[1840]
 BV bounds    x[1841]
 BV bounds    x[1842]
 BV bounds    x[1843]
 BV bounds    x[1844]
 BV bounds    x[1845]
 BV bounds    x[1846]
 BV bounds    x[1847]
 BV bounds    x[1848]
 BV bounds    x[1849]
 BV bounds    x[1850]
 BV bounds    x[1851]
 BV bounds    x[1852]
 BV bounds    x[1853]
 BV bounds    x[1854]
 BV bounds    x[1855]
 BV bounds    x[1856]
 BV bounds    x[1857]
 BV bounds    x[1858]
 BV bounds    x[1859]
 BV bounds    x[1860]
 BV bounds    x[1861]
 BV bounds    x[1862]
 BV bounds    x[1863]
 BV bounds    x[1864]
 BV bounds    x[1865]
 BV bounds    x[1866]
 BV bounds    x[1867]
 BV bounds    x[1868]
 BV bounds    x[1869]
 BV bounds    x[1870]
 BV bounds    x[1871]
 BV bounds    x[1872]
 BV bounds    x[1873]
 BV bounds    x[1874]
 BV bounds    x[1875]
 BV bounds    x[1876]
 BV bounds    x[1877]
 BV bounds    x[1878]
 BV bounds    x[1879]
 BV bounds    x[1880]
 BV bounds    x[1881]
 BV bounds    x[1882]
 BV bounds    x[1883]
 BV bounds    x[1884]
 BV bounds    x[1885]
 BV bounds    x[1886]
 BV bounds    x[1887]
 BV bounds    x[1888]
 BV bounds    x[1889]
 BV bounds    x[1890]
 BV bounds    x[1891]
 BV bounds    x[1892]
 BV bounds    x[1893]
 BV bounds    x[1894]
 BV bounds    x[1895]
 BV bounds    x[1896]
 BV bounds    x[1897]
 BV bounds    x[1898]
 BV bounds    x[1899]
 BV bounds    x[1900]
 BV bounds    x[1901]
 BV bounds    x[1902]
 BV bounds    x[1903]
 BV bounds    x[1904]
 BV bounds    x[1905]
 BV bounds    x[1906]
 BV bounds    x[1907]
 BV bounds    x[1908]
 BV bounds    x[1909]
 BV bounds    x[1910]
 BV bounds    x[1911]
 BV bounds    x[1912]
 BV bounds    x[1913]
 BV bounds    x[1914]
 BV bounds    x[1915]
 BV bounds    x[1916]
 BV bounds    x[1917]
 BV bounds    x[1918]
 BV bounds    x[1919]
 BV bounds    x[1920]
 BV bounds    x[1921]
 BV bounds    x[1922]
 BV bounds    x[1923]
 BV bounds    x[1924]
 BV bounds    x[1925]
 BV bounds    x[1926]
 BV bounds    x[1927]
 BV bounds    x[1928]
 BV bounds    x[1929]
 BV bounds    x[1930]
 BV bounds    x[1931]
 BV bounds    x[1932]
 BV bounds    x[1933]
 BV bounds    x[1934]
 BV bounds    x[1935]
 BV bounds    x[1936]
 BV bounds    x[1937]
 BV bounds    x[1938]
 BV bounds    x[1939]
 BV bounds    x[1940]
 BV bounds    x[1941]
 BV bounds    x[1942]
 BV bounds    x[1943]
 BV bounds    x[1944]
 BV bounds    x[1945]
 BV bounds    x[1946]
 BV bounds    x[1947]
 BV bounds    x[1948]
 BV bounds    x[1949]
 BV bounds    x[1950]
 BV bounds    x[1951]
 BV bounds    x[1952]
 BV bounds    x[1953]
 BV bounds    x[1954]
 BV bounds    x[1955]
 BV bounds    x[1956]
 BV bounds    x[1957]
 BV bounds    x[1958]
 BV bounds    x[1959]
 BV bounds    x[1960]
 BV bounds    x[1961]
 BV bounds    x[1962]
 BV bounds    x[1963]
 BV bounds    x[1964]
 BV bounds    x[1965]
 BV bounds    x[1966]
 BV bounds    x[1967]
 BV bounds    x[1968]
 BV bounds    x[1969]
 BV bounds    x[1970]
 BV bounds    x[1971]
 BV bounds    x[1972]
 BV bounds    x[1973]
 BV bounds    x[1974]
 BV bounds    x[1975]
 BV bounds    x[1976]
 BV bounds    x[1977]
 BV bounds    x[1978]
 BV bounds    x[1979]
 BV bounds    x[1980]
 BV bounds    x[1981]
 BV bounds    x[1982]
 BV bounds    x[1983]
 BV bounds    x[1984]
 BV bounds    x[1985]
 BV bounds    x[1986]
 BV bounds    x[1987]
 BV bounds    x[1988]
 BV bounds    x[1989]
 BV bounds    x[1990]
 BV bounds    x[1991]
 BV bounds    x[1992]
 BV bounds    x[1993]
 BV bounds    x[1994]
 BV bounds    x[1995]
 BV bounds    x[1996]
 BV bounds    x[1997]
 BV bounds    x[1998]
 BV bounds    x[1999]
 BV bounds    x[2000]
 BV bounds    x[2001]
 BV bounds    x[2002]
 BV bounds    x[2003]
 BV bounds    x[2004]
 BV bounds    x[2005]
 BV bounds    x[2006]
 BV bounds    x[2007]
 BV bounds    x[2008]
 BV bounds    x[2009]
 BV bounds    x[2010]
 BV bounds    x[2011]
 BV bounds    x[2012]
 BV bounds    x[2013]
 BV bounds    x[2014]
 BV bounds    x[2015]
 BV bounds    x[2016]
 BV bounds    x[2017]
 BV bounds    x[2018]
 BV bounds    x[2019]
 BV bounds    x[2020]
 BV bounds    x[2021]
 BV bounds    x[2022]
 BV bounds    x[2023]
 BV bounds    x[2024]
 BV bounds    x[2025]
 BV bounds    x[2026]
 BV bounds    x[2027]
 BV bounds    x[2028]
 BV bounds    x[2029]
 BV bounds    x[2030]
 BV bounds    x[2031]
 BV bounds    x[2032]
 BV bounds    x[2033]
 BV bounds    x[2034]
 BV bounds    x[2035]
 BV bounds    x[2036]
 BV bounds    x[2037]
 BV bounds    x[2038]
 BV bounds    x[2039]
 BV bounds    x[2040]
 BV bounds    x[2041]
 BV bounds    x[2042]
 BV bounds    x[2043]
 BV bounds    x[2044]
 BV bounds    x[2045]
 BV bounds    x[2046]
 BV bounds    x[2047]
 BV bounds    x[2048]
 BV bounds    x[2049]
 BV bounds    x[2050]
 BV bounds    x[2051]
 BV bounds    x[2052]
 BV bounds    x[2053]
 BV bounds    x[2054]
 BV bounds    x[2055]
 BV bounds    x[2056]
 BV bounds    x[2057]
 BV bounds    x[2058]
 BV bounds    x[2059]
 BV bounds    x[2060]
 BV bounds    x[2061]
 BV bounds    x[2062]
 BV bounds    x[2063]
 BV bounds    x[2064]
 BV bounds    x[2065]
 BV bounds    x[2066]
 BV bounds    x[2067]
 BV bounds    x[2068]
 BV bounds    x[2069]
 BV bounds    x[2070]
 BV bounds    x[2071]
 BV bounds    x[2072]
 BV bounds    x[2073]
 BV bounds    x[2074]
 BV bounds    x[2075]
 BV bounds    x[2076]
 BV bounds    x[2077]
 BV bounds    x[2078]
 BV bounds    x[2079]
 BV bounds    x[2080]
 BV bounds    x[2081]
 BV bounds    x[2082]
 BV bounds    x[2083]
 BV bounds    x[2084]
 BV bounds    x[2085]
 BV bounds    x[2086]
 BV bounds    x[2087]
 BV bounds    x[2088]
 BV bounds    x[2089]
 BV bounds    x[2090]
 BV bounds    x[2091]
 BV bounds    x[2092]
 BV bounds    x[2093]
 BV bounds    x[2094]
 BV bounds    x[2095]
 BV bounds    x[2096]
 BV bounds    x[2097]
 BV bounds    x[2098]
 BV bounds    x[2099]
 BV bounds    x[2100]
 BV bounds    x[2101]
 BV bounds    x[2102]
 BV bounds    x[2103]
 BV bounds    x[2104]
 BV bounds    x[2105]
 BV bounds    x[2106]
 BV bounds    x[2107]
 BV bounds    x[2108]
 BV bounds    x[2109]
 BV bounds    x[2110]
 BV bounds    x[2111]
 BV bounds    x[2112]
 BV bounds    x[2113]
 BV bounds    x[2114]
 BV bounds    x[2115]
 BV bounds    x[2116]
 BV bounds    x[2117]
 BV bounds    x[2118]
 BV bounds    x[2119]
 BV bounds    x[2120]
 BV bounds    x[2121]
 BV bounds    x[2122]
 BV bounds    x[2123]
 BV bounds    x[2124]
 BV bounds    x[2125]
 BV bounds    x[2126]
 BV bounds    x[2127]
 BV bounds    x[2128]
 BV bounds    x[2129]
 BV bounds    x[2130]
 BV bounds    x[2131]
 BV bounds    x[2132]
 BV bounds    x[2133]
 BV bounds    x[2134]
 BV bounds    x[2135]
 BV bounds    x[2136]
 BV bounds    x[2137]
 BV bounds    x[2138]
 BV bounds    x[2139]
 BV bounds    x[2140]
 BV bounds    x[2141]
 BV bounds    x[2142]
 BV bounds    x[2143]
 BV bounds    x[2144]
 BV bounds    x[2145]
 BV bounds    x[2146]
 BV bounds    x[2147]
 BV bounds    x[2148]
 BV bounds    x[2149]
 BV bounds    x[2150]
 BV bounds    x[2151]
 BV bounds    x[2152]
 BV bounds    x[2153]
 BV bounds    x[2154]
 BV bounds    x[2155]
 BV bounds    x[2156]
 BV bounds    x[2157]
 BV bounds    x[2158]
 BV bounds    x[2159]
 BV bounds    x[2160]
 BV bounds    x[2161]
 BV bounds    x[2162]
 BV bounds    x[2163]
 BV bounds    x[2164]
 BV bounds    x[2165]
 BV bounds    x[2166]
 BV bounds    x[2167]
 BV bounds    x[2168]
 BV bounds    x[2169]
 BV bounds    x[2170]
 BV bounds    x[2171]
 BV bounds    x[2172]
 BV bounds    x[2173]
 BV bounds    x[2174]
 BV bounds    x[2175]
 BV bounds    x[2176]
 BV bounds    x[2177]
 BV bounds    x[2178]
 BV bounds    x[2179]
 BV bounds    x[2180]
 BV bounds    x[2181]
 BV bounds    x[2182]
 BV bounds    x[2183]
 BV bounds    x[2184]
 BV bounds    x[2185]
 BV bounds    x[2186]
 BV bounds    x[2187]
 BV bounds    x[2188]
 BV bounds    x[2189]
 BV bounds    x[2190]
 BV bounds    x[2191]
 BV bounds    x[2192]
 BV bounds    x[2193]
 BV bounds    x[2194]
 BV bounds    x[2195]
 BV bounds    x[2196]
 BV bounds    x[2197]
 BV bounds    x[2198]
 BV bounds    x[2199]
 BV bounds    x[2200]
 BV bounds    x[2201]
 BV bounds    x[2202]
 BV bounds    x[2203]
 BV bounds    x[2204]
 BV bounds    x[2205]
 BV bounds    x[2206]
 BV bounds    x[2207]
 BV bounds    x[2208]
 BV bounds    x[2209]
 BV bounds    x[2210]
 BV bounds    x[2211]
 BV bounds    x[2212]
 BV bounds    x[2213]
 BV bounds    x[2214]
 BV bounds    x[2215]
 BV bounds    x[2216]
 BV bounds    x[2217]
 BV bounds    x[2218]
 BV bounds    x[2219]
 BV bounds    x[2220]
 BV bounds    x[2221]
 BV bounds    x[2222]
 BV bounds    x[2223]
 BV bounds    x[2224]
 BV bounds    x[2225]
 BV bounds    x[2226]
 BV bounds    x[2227]
 BV bounds    x[2228]
 BV bounds    x[2229]
 BV bounds    x[2230]
 BV bounds    x[2231]
 BV bounds    x[2232]
 BV bounds    x[2233]
 BV bounds    x[2234]
 BV bounds    x[2235]
 BV bounds    x[2236]
 BV bounds    x[2237]
 BV bounds    x[2238]
 BV bounds    x[2239]
 BV bounds    x[2240]
 BV bounds    x[2241]
 BV bounds    x[2242]
 BV bounds    x[2243]
 BV bounds    x[2244]
 BV bounds    x[2245]
 BV bounds    x[2246]
 BV bounds    x[2247]
 BV bounds    x[2248]
 BV bounds    x[2249]
 BV bounds    x[2250]
 BV bounds    x[2251]
 BV bounds    x[2252]
 BV bounds    x[2253]
 BV bounds    x[2254]
 BV bounds    x[2255]
 BV bounds    x[2256]
 BV bounds    x[2257]
 BV bounds    x[2258]
 BV bounds    x[2259]
 BV bounds    x[2260]
 BV bounds    x[2261]
 BV bounds    x[2262]
 BV bounds    x[2263]
 BV bounds    x[2264]
 BV bounds    x[2265]
 BV bounds    x[2266]
 BV bounds    x[2267]
 BV bounds    x[2268]
 BV bounds    x[2269]
 BV bounds    x[2270]
 BV bounds    x[2271]
 BV bounds    x[2272]
 BV bounds    x[2273]
 BV bounds    x[2274]
 BV bounds    x[2275]
 BV bounds    x[2276]
 BV bounds    x[2277]
 BV bounds    x[2278]
 BV bounds    x[2279]
 BV bounds    x[2280]
 BV bounds    x[2281]
 BV bounds    x[2282]
 BV bounds    x[2283]
 BV bounds    x[2284]
 BV bounds    x[2285]
 BV bounds    x[2286]
 BV bounds    x[2287]
 BV bounds    x[2288]
 BV bounds    x[2289]
 BV bounds    x[2290]
 BV bounds    x[2291]
 BV bounds    x[2292]
 BV bounds    x[2293]
 BV bounds    x[2294]
 BV bounds    x[2295]
 BV bounds    x[2296]
 BV bounds    x[2297]
 BV bounds    x[2298]
 BV bounds    x[2299]
 BV bounds    x[2300]
 BV bounds    x[2301]
 BV bounds    x[2302]
 BV bounds    x[2303]
 BV bounds    x[2304]
 BV bounds    x[2305]
 BV bounds    x[2306]
 BV bounds    x[2307]
 BV bounds    x[2308]
 BV bounds    x[2309]
 BV bounds    x[2310]
 BV bounds    x[2311]
 BV bounds    x[2312]
 BV bounds    x[2313]
 BV bounds    x[2314]
 BV bounds    x[2315]
 BV bounds    x[2316]
 BV bounds    x[2317]
 BV bounds    x[2318]
 BV bounds    x[2319]
 BV bounds    x[2320]
 BV bounds    x[2321]
 BV bounds    x[2322]
 BV bounds    x[2323]
 BV bounds    x[2324]
 BV bounds    x[2325]
 BV bounds    x[2326]
 BV bounds    x[2327]
 BV bounds    x[2328]
 BV bounds    x[2329]
 BV bounds    x[2330]
 BV bounds    x[2331]
 BV bounds    x[2332]
 BV bounds    x[2333]
 BV bounds    x[2334]
 BV bounds    x[2335]
 BV bounds    x[2336]
 BV bounds    x[2337]
 BV bounds    x[2338]
 BV bounds    x[2339]
 BV bounds    x[2340]
 BV bounds    x[2341]
 BV bounds    x[2342]
 BV bounds    x[2343]
 BV bounds    x[2344]
 BV bounds    x[2345]
 BV bounds    x[2346]
 BV bounds    x[2347]
 BV bounds    x[2348]
 BV bounds    x[2349]
 BV bounds    x[2350]
 BV bounds    x[2351]
 BV bounds    x[2352]
 BV bounds    x[2353]
 BV bounds    x[2354]
 BV bounds    x[2355]
 BV bounds    x[2356]
 BV bounds    x[2357]
 BV bounds    x[2358]
 BV bounds    x[2359]
 BV bounds    x[2360]
 BV bounds    x[2361]
 BV bounds    x[2362]
 BV bounds    x[2363]
 BV bounds    x[2364]
 BV bounds    x[2365]
 BV bounds    x[2366]
 BV bounds    x[2367]
 BV bounds    x[2368]
 BV bounds    x[2369]
 BV bounds    x[2370]
 BV bounds    x[2371]
 BV bounds    x[2372]
 BV bounds    x[2373]
 BV bounds    x[2374]
 BV bounds    x[2375]
 BV bounds    x[2376]
 BV bounds    x[2377]
 BV bounds    x[2378]
 BV bounds    x[2379]
 BV bounds    x[2380]
 BV bounds    x[2381]
 BV bounds    x[2382]
 BV bounds    x[2383]
 BV bounds    x[2384]
 BV bounds    x[2385]
 BV bounds    x[2386]
 BV bounds    x[2387]
 BV bounds    x[2388]
 BV bounds    x[2389]
 BV bounds    x[2390]
 BV bounds    x[2391]
 BV bounds    x[2392]
 BV bounds    x[2393]
 BV bounds    x[2394]
 BV bounds    x[2395]
 BV bounds    x[2396]
 BV bounds    x[2397]
 BV bounds    x[2398]
 BV bounds    x[2399]
 BV bounds    x[2400]
 BV bounds    x[2401]
 BV bounds    x[2402]
 BV bounds    x[2403]
 BV bounds    x[2404]
 BV bounds    x[2405]
 BV bounds    x[2406]
 BV bounds    x[2407]
 BV bounds    x[2408]
 BV bounds    x[2409]
 BV bounds    x[2410]
 BV bounds    x[2411]
 BV bounds    x[2412]
 BV bounds    x[2413]
 BV bounds    x[2414]
 BV bounds    x[2415]
 BV bounds    x[2416]
 BV bounds    x[2417]
 BV bounds    x[2418]
 BV bounds    x[2419]
 BV bounds    x[2420]
 BV bounds    x[2421]
 BV bounds    x[2422]
 BV bounds    x[2423]
 BV bounds    x[2424]
 BV bounds    x[2425]
 BV bounds    x[2426]
 BV bounds    x[2427]
 BV bounds    x[2428]
 BV bounds    x[2429]
 BV bounds    x[2430]
 BV bounds    x[2431]
 BV bounds    x[2432]
 BV bounds    x[2433]
 BV bounds    x[2434]
 BV bounds    x[2435]
 BV bounds    x[2436]
 BV bounds    x[2437]
 BV bounds    x[2438]
 BV bounds    x[2439]
 BV bounds    x[2440]
 BV bounds    x[2441]
 BV bounds    x[2442]
 BV bounds    x[2443]
 BV bounds    x[2444]
 BV bounds    x[2445]
 BV bounds    x[2446]
 BV bounds    x[2447]
 BV bounds    x[2448]
 BV bounds    x[2449]
 BV bounds    x[2450]
 BV bounds    x[2451]
 BV bounds    x[2452]
 BV bounds    x[2453]
 BV bounds    x[2454]
 BV bounds    x[2455]
 BV bounds    x[2456]
 BV bounds    x[2457]
 BV bounds    x[2458]
 BV bounds    x[2459]
 BV bounds    x[2460]
 BV bounds    x[2461]
 BV bounds    x[2462]
 BV bounds    x[2463]
 BV bounds    x[2464]
 BV bounds    x[2465]
 BV bounds    x[2466]
 BV bounds    x[2467]
 BV bounds    x[2468]
 BV bounds    x[2469]
 BV bounds    x[2470]
 BV bounds    x[2471]
 BV bounds    x[2472]
 BV bounds    x[2473]
 BV bounds    x[2474]
 BV bounds    x[2475]
 BV bounds    x[2476]
 BV bounds    x[2477]
 BV bounds    x[2478]
 BV bounds    x[2479]
 BV bounds    x[2480]
 BV bounds    x[2481]
 BV bounds    x[2482]
 BV bounds    x[2483]
 BV bounds    x[2484]
 BV bounds    x[2485]
 BV bounds    x[2486]
 BV bounds    x[2487]
 BV bounds    x[2488]
 BV bounds    x[2489]
 BV bounds    x[2490]
 BV bounds    x[2491]
 BV bounds    x[2492]
 BV bounds    x[2493]
 BV bounds    x[2494]
 BV bounds    x[2495]
 BV bounds    x[2496]
 BV bounds    x[2497]
 BV bounds    x[2498]
 BV bounds    x[2499]
 BV bounds    x[2500]
 BV bounds    x[2501]
 BV bounds    x[2502]
 BV bounds    x[2503]
 BV bounds    x[2504]
 BV bounds    x[2505]
 BV bounds    x[2506]
 BV bounds    x[2507]
 BV bounds    x[2508]
 BV bounds    x[2509]
 BV bounds    x[2510]
 BV bounds    x[2511]
 BV bounds    x[2512]
 BV bounds    x[2513]
 BV bounds    x[2514]
 BV bounds    x[2515]
 BV bounds    x[2516]
 BV bounds    x[2517]
 BV bounds    x[2518]
 BV bounds    x[2519]
 BV bounds    x[2520]
 BV bounds    x[2521]
 BV bounds    x[2522]
 BV bounds    x[2523]
 BV bounds    x[2524]
 BV bounds    x[2525]
 BV bounds    x[2526]
 BV bounds    x[2527]
 BV bounds    x[2528]
 BV bounds    x[2529]
 BV bounds    x[2530]
 BV bounds    x[2531]
 BV bounds    x[2532]
 BV bounds    x[2533]
 BV bounds    x[2534]
 BV bounds    x[2535]
 BV bounds    x[2536]
 BV bounds    x[2537]
 BV bounds    x[2538]
 BV bounds    x[2539]
 BV bounds    x[2540]
 BV bounds    x[2541]
 BV bounds    x[2542]
 BV bounds    x[2543]
 BV bounds    x[2544]
 BV bounds    x[2545]
 BV bounds    x[2546]
 BV bounds    x[2547]
 BV bounds    x[2548]
 BV bounds    x[2549]
 BV bounds    x[2550]
 BV bounds    x[2551]
 BV bounds    x[2552]
 BV bounds    x[2553]
 BV bounds    x[2554]
 BV bounds    x[2555]
 BV bounds    x[2556]
 BV bounds    x[2557]
 BV bounds    x[2558]
 BV bounds    x[2559]
 BV bounds    x[2560]
 BV bounds    x[2561]
 BV bounds    x[2562]
 BV bounds    x[2563]
 BV bounds    x[2564]
 BV bounds    x[2565]
 BV bounds    x[2566]
 BV bounds    x[2567]
 BV bounds    x[2568]
 BV bounds    x[2569]
 BV bounds    x[2570]
 BV bounds    x[2571]
 BV bounds    x[2572]
 BV bounds    x[2573]
 BV bounds    x[2574]
 BV bounds    x[2575]
 BV bounds    x[2576]
 BV bounds    x[2577]
 BV bounds    x[2578]
 BV bounds    x[2579]
 BV bounds    x[2580]
 BV bounds    x[2581]
 BV bounds    x[2582]
 BV bounds    x[2583]
 BV bounds    x[2584]
 BV bounds    x[2585]
 BV bounds    x[2586]
 BV bounds    x[2587]
 BV bounds    x[2588]
 BV bounds    x[2589]
 BV bounds    x[2590]
 BV bounds    x[2591]
 BV bounds    x[2592]
 BV bounds    x[2593]
 BV bounds    x[2594]
 BV bounds    x[2595]
 BV bounds    x[2596]
 BV bounds    x[2597]
 BV bounds    x[2598]
 BV bounds    x[2599]
 BV bounds    x[2600]
 BV bounds    x[2601]
 BV bounds    x[2602]
 BV bounds    x[2603]
 BV bounds    x[2604]
 BV bounds    x[2605]
 BV bounds    x[2606]
 BV bounds    x[2607]
 BV bounds    x[2608]
 BV bounds    x[2609]
 BV bounds    x[2610]
 BV bounds    x[2611]
 BV bounds    x[2612]
 BV bounds    x[2613]
 BV bounds    x[2614]
 BV bounds    x[2615]
 BV bounds    x[2616]
 BV bounds    x[2617]
 BV bounds    x[2618]
 BV bounds    x[2619]
 BV bounds    x[2620]
 BV bounds    x[2621]
 BV bounds    x[2622]
 BV bounds    x[2623]
 BV bounds    x[2624]
 BV bounds    x[2625]
 BV bounds    x[2626]
 BV bounds    x[2627]
 BV bounds    x[2628]
 BV bounds    x[2629]
 BV bounds    x[2630]
 BV bounds    x[2631]
 BV bounds    x[2632]
 BV bounds    x[2633]
 BV bounds    x[2634]
 BV bounds    x[2635]
 BV bounds    x[2636]
 BV bounds    x[2637]
 BV bounds    x[2638]
 BV bounds    x[2639]
 BV bounds    x[2640]
 BV bounds    x[2641]
 BV bounds    x[2642]
 BV bounds    x[2643]
 BV bounds    x[2644]
 BV bounds    x[2645]
 BV bounds    x[2646]
 BV bounds    x[2647]
 BV bounds    x[2648]
 BV bounds    x[2649]
 BV bounds    x[2650]
 BV bounds    x[2651]
 BV bounds    x[2652]
 BV bounds    x[2653]
 BV bounds    x[2654]
 BV bounds    x[2655]
 BV bounds    x[2656]
 BV bounds    x[2657]
 BV bounds    x[2658]
 BV bounds    x[2659]
 BV bounds    x[2660]
 BV bounds    x[2661]
 BV bounds    x[2662]
 BV bounds    x[2663]
 BV bounds    x[2664]
 BV bounds    x[2665]
 BV bounds    x[2666]
 BV bounds    x[2667]
 BV bounds    x[2668]
 BV bounds    x[2669]
 BV bounds    x[2670]
 BV bounds    x[2671]
 BV bounds    x[2672]
 BV bounds    x[2673]
 BV bounds    x[2674]
 BV bounds    x[2675]
 BV bounds    x[2676]
 BV bounds    x[2677]
 BV bounds    x[2678]
 BV bounds    x[2679]
 BV bounds    x[2680]
 BV bounds    x[2681]
 BV bounds    x[2682]
 BV bounds    x[2683]
 BV bounds    x[2684]
 BV bounds    x[2685]
 BV bounds    x[2686]
 BV bounds    x[2687]
 BV bounds    x[2688]
 BV bounds    x[2689]
 BV bounds    x[2690]
 BV bounds    x[2691]
 BV bounds    x[2692]
 BV bounds    x[2693]
 BV bounds    x[2694]
 BV bounds    x[2695]
 BV bounds    x[2696]
 BV bounds    x[2697]
 BV bounds    x[2698]
 BV bounds    x[2699]
 BV bounds    x[2700]
 BV bounds    x[2701]
 BV bounds    x[2702]
 BV bounds    x[2703]
 BV bounds    x[2704]
 BV bounds    x[2705]
 BV bounds    x[2706]
 BV bounds    x[2707]
 BV bounds    x[2708]
 BV bounds    x[2709]
 BV bounds    x[2710]
 BV bounds    x[2711]
 BV bounds    x[2712]
 BV bounds    x[2713]
 BV bounds    x[2714]
 BV bounds    x[2715]
 BV bounds    x[2716]
 BV bounds    x[2717]
 BV bounds    x[2718]
 BV bounds    x[2719]
 BV bounds    x[2720]
 BV bounds    x[2721]
 BV bounds    x[2722]
 BV bounds    x[2723]
 BV bounds    x[2724]
 BV bounds    x[2725]
 BV bounds    x[2726]
 BV bounds    x[2727]
 BV bounds    x[2728]
 BV bounds    x[2729]
 BV bounds    x[2730]
 BV bounds    x[2731]
 BV bounds    x[2732]
 BV bounds    x[2733]
 BV bounds    x[2734]
 BV bounds    x[2735]
 BV bounds    x[2736]
 BV bounds    x[2737]
 BV bounds    x[2738]
 BV bounds    x[2739]
 BV bounds    x[2740]
 BV bounds    x[2741]
 BV bounds    x[2742]
 BV bounds    x[2743]
 BV bounds    x[2744]
 BV bounds    x[2745]
 BV bounds    x[2746]
 BV bounds    x[2747]
 BV bounds    x[2748]
 BV bounds    x[2749]
 BV bounds    x[2750]
 BV bounds    x[2751]
 BV bounds    x[2752]
 BV bounds    x[2753]
 BV bounds    x[2754]
 BV bounds    x[2755]
 BV bounds    x[2756]
 BV bounds    x[2757]
 BV bounds    x[2758]
 BV bounds    x[2759]
 BV bounds    x[2760]
 BV bounds    x[2761]
 BV bounds    x[2762]
 BV bounds    x[2763]
 BV bounds    x[2764]
 BV bounds    x[2765]
 BV bounds    x[2766]
 BV bounds    x[2767]
 BV bounds    x[2768]
 BV bounds    x[2769]
 BV bounds    x[2770]
 BV bounds    x[2771]
 BV bounds    x[2772]
 BV bounds    x[2773]
 BV bounds    x[2774]
 BV bounds    x[2775]
 BV bounds    x[2776]
 BV bounds    x[2777]
 BV bounds    x[2778]
 BV bounds    x[2779]
 BV bounds    x[2780]
 BV bounds    x[2781]
 BV bounds    x[2782]
 BV bounds    x[2783]
 BV bounds    x[2784]
 BV bounds    x[2785]
 BV bounds    x[2786]
 BV bounds    x[2787]
 BV bounds    x[2788]
 BV bounds    x[2789]
 BV bounds    x[2790]
 BV bounds    x[2791]
 BV bounds    x[2792]
 BV bounds    x[2793]
 BV bounds    x[2794]
 BV bounds    x[2795]
 BV bounds    x[2796]
 BV bounds    x[2797]
 BV bounds    x[2798]
 BV bounds    x[2799]
 BV bounds    x[2800]
 BV bounds    x[2801]
 BV bounds    x[2802]
 BV bounds    x[2803]
 BV bounds    x[2804]
 BV bounds    x[2805]
 BV bounds    x[2806]
 BV bounds    x[2807]
 BV bounds    x[2808]
 BV bounds    x[2809]
 BV bounds    x[2810]
 BV bounds    x[2811]
 BV bounds    x[2812]
 BV bounds    x[2813]
 BV bounds    x[2814]
 BV bounds    x[2815]
 BV bounds    x[2816]
 BV bounds    x[2817]
 BV bounds    x[2818]
 BV bounds    x[2819]
 BV bounds    x[2820]
 BV bounds    x[2821]
 BV bounds    x[2822]
 BV bounds    x[2823]
 BV bounds    x[2824]
 BV bounds    x[2825]
 BV bounds    x[2826]
 BV bounds    x[2827]
 BV bounds    x[2828]
 BV bounds    x[2829]
 BV bounds    x[2830]
 BV bounds    x[2831]
 BV bounds    x[2832]
 BV bounds    x[2833]
 BV bounds    x[2834]
 BV bounds    x[2835]
 BV bounds    x[2836]
 BV bounds    x[2837]
 BV bounds    x[2838]
 BV bounds    x[2839]
 BV bounds    x[2840]
 BV bounds    x[2841]
 BV bounds    x[2842]
 BV bounds    x[2843]
 BV bounds    x[2844]
 BV bounds    x[2845]
 BV bounds    x[2846]
 BV bounds    x[2847]
 BV bounds    x[2848]
 BV bounds    x[2849]
 BV bounds    x[2850]
 BV bounds    x[2851]
 BV bounds    x[2852]
 BV bounds    x[2853]
 BV bounds    x[2854]
 BV bounds    x[2855]
 BV bounds    x[2856]
 BV bounds    x[2857]
 BV bounds    x[2858]
 BV bounds    x[2859]
 BV bounds    x[2860]
 BV bounds    x[2861]
 BV bounds    x[2862]
 BV bounds    x[2863]
 BV bounds    x[2864]
 BV bounds    x[2865]
 BV bounds    x[2866]
 BV bounds    x[2867]
 BV bounds    x[2868]
 BV bounds    x[2869]
 BV bounds    x[2870]
 BV bounds    x[2871]
 BV bounds    x[2872]
 BV bounds    x[2873]
 BV bounds    x[2874]
 BV bounds    x[2875]
 BV bounds    x[2876]
 BV bounds    x[2877]
 BV bounds    x[2878]
 BV bounds    x[2879]
 BV bounds    x[2880]
 BV bounds    x[2881]
 BV bounds    x[2882]
 BV bounds    x[2883]
 BV bounds    x[2884]
 BV bounds    x[2885]
 BV bounds    x[2886]
 BV bounds    x[2887]
 BV bounds    x[2888]
 BV bounds    x[2889]
 BV bounds    x[2890]
 BV bounds    x[2891]
 BV bounds    x[2892]
 BV bounds    x[2893]
 BV bounds    x[2894]
 BV bounds    x[2895]
 BV bounds    x[2896]
 BV bounds    x[2897]
 BV bounds    x[2898]
 BV bounds    x[2899]
 BV bounds    x[2900]
 BV bounds    x[2901]
 BV bounds    x[2902]
 BV bounds    x[2903]
 BV bounds    x[2904]
 BV bounds    x[2905]
 BV bounds    x[2906]
 BV bounds    x[2907]
 BV bounds    x[2908]
 BV bounds    x[2909]
 BV bounds    x[2910]
 BV bounds    x[2911]
 BV bounds    x[2912]
 BV bounds    x[2913]
 BV bounds    x[2914]
 BV bounds    x[2915]
 BV bounds    x[2916]
 BV bounds    x[2917]
 BV bounds    x[2918]
 BV bounds    x[2919]
 BV bounds    x[2920]
 BV bounds    x[2921]
 BV bounds    x[2922]
 BV bounds    x[2923]
 BV bounds    x[2924]
 BV bounds    x[2925]
 BV bounds    x[2926]
 BV bounds    x[2927]
 BV bounds    x[2928]
 BV bounds    x[2929]
 BV bounds    x[2930]
 BV bounds    x[2931]
 BV bounds    x[2932]
 BV bounds    x[2933]
 BV bounds    x[2934]
 BV bounds    x[2935]
 BV bounds    x[2936]
 BV bounds    x[2937]
 BV bounds    x[2938]
 BV bounds    x[2939]
 BV bounds    x[2940]
 BV bounds    x[2941]
 BV bounds    x[2942]
 BV bounds    x[2943]
 BV bounds    x[2944]
 BV bounds    x[2945]
 BV bounds    x[2946]
 BV bounds    x[2947]
 BV bounds    x[2948]
 BV bounds    x[2949]
 BV bounds    x[2950]
 BV bounds    x[2951]
 BV bounds    x[2952]
 BV bounds    x[2953]
 BV bounds    x[2954]
 BV bounds    x[2955]
 BV bounds    x[2956]
 BV bounds    x[2957]
 BV bounds    x[2958]
 BV bounds    x[2959]
 BV bounds    x[2960]
 BV bounds    x[2961]
 BV bounds    x[2962]
 BV bounds    x[2963]
 BV bounds    x[2964]
 BV bounds    x[2965]
 BV bounds    x[2966]
 BV bounds    x[2967]
 BV bounds    x[2968]
 BV bounds    x[2969]
 BV bounds    x[2970]
 BV bounds    x[2971]
 BV bounds    x[2972]
 BV bounds    x[2973]
 BV bounds    x[2974]
 BV bounds    x[2975]
 BV bounds    x[2976]
 BV bounds    x[2977]
 BV bounds    x[2978]
 BV bounds    x[2979]
 BV bounds    x[2980]
 BV bounds    x[2981]
 BV bounds    x[2982]
 BV bounds    x[2983]
 BV bounds    x[2984]
 BV bounds    x[2985]
 BV bounds    x[2986]
 BV bounds    x[2987]
 BV bounds    x[2988]
 BV bounds    x[2989]
 BV bounds    x[2990]
 BV bounds    x[2991]
 BV bounds    x[2992]
 BV bounds    x[2993]
 BV bounds    x[2994]
 BV bounds    x[2995]
 BV bounds    x[2996]
 BV bounds    x[2997]
 BV bounds    x[2998]
 BV bounds    x[2999]
 BV bounds    x[3000]
 BV bounds    x[3001]
 BV bounds    x[3002]
 BV bounds    x[3003]
 BV bounds    x[3004]
 BV bounds    x[3005]
 BV bounds    x[3006]
 BV bounds    x[3007]
 BV bounds    x[3008]
 BV bounds    x[3009]
 BV bounds    x[3010]
 BV bounds    x[3011]
 BV bounds    x[3012]
 BV bounds    x[3013]
 BV bounds    x[3014]
 BV bounds    x[3015]
 BV bounds    x[3016]
 BV bounds    x[3017]
 BV bounds    x[3018]
 BV bounds    x[3019]
 BV bounds    x[3020]
 BV bounds    x[3021]
 BV bounds    x[3022]
 BV bounds    x[3023]
 BV bounds    x[3024]
 BV bounds    x[3025]
 BV bounds    x[3026]
 BV bounds    x[3027]
 BV bounds    x[3028]
 BV bounds    x[3029]
 BV bounds    x[3030]
 BV bounds    x[3031]
 BV bounds    x[3032]
 BV bounds    x[3033]
 BV bounds    x[3034]
 BV bounds    x[3035]
 BV bounds    x[3036]
 BV bounds    x[3037]
 BV bounds    x[3038]
 BV bounds    x[3039]
 BV bounds    x[3040]
 BV bounds    x[3041]
 BV bounds    x[3042]
 BV bounds    x[3043]
 BV bounds    x[3044]
 BV bounds    x[3045]
 BV bounds    x[3046]
 BV bounds    x[3047]
 BV bounds    x[3048]
 BV bounds    x[3049]
 BV bounds    x[3050]
 BV bounds    x[3051]
 BV bounds    x[3052]
 BV bounds    x[3053]
 BV bounds    x[3054]
 BV bounds    x[3055]
 BV bounds    x[3056]
 BV bounds    x[3057]
 BV bounds    x[3058]
 BV bounds    x[3059]
 BV bounds    x[3060]
 BV bounds    x[3061]
 BV bounds    x[3062]
 BV bounds    x[3063]
 BV bounds    x[3064]
 BV bounds    x[3065]
 BV bounds    x[3066]
 BV bounds    x[3067]
 BV bounds    x[3068]
 BV bounds    x[3069]
 BV bounds    x[3070]
 BV bounds    x[3071]
 BV bounds    x[3072]
 BV bounds    x[3073]
 BV bounds    x[3074]
 BV bounds    x[3075]
 BV bounds    x[3076]
 BV bounds    x[3077]
 BV bounds    x[3078]
 BV bounds    x[3079]
 BV bounds    x[3080]
 BV bounds    x[3081]
 BV bounds    x[3082]
 BV bounds    x[3083]
 BV bounds    x[3084]
 BV bounds    x[3085]
 BV bounds    x[3086]
 BV bounds    x[3087]
 BV bounds    x[3088]
 BV bounds    x[3089]
 BV bounds    x[3090]
 BV bounds    x[3091]
 BV bounds    x[3092]
 BV bounds    x[3093]
 BV bounds    x[3094]
 BV bounds    x[3095]
 BV bounds    x[3096]
 BV bounds    x[3097]
 BV bounds    x[3098]
 BV bounds    x[3099]
 BV bounds    x[3100]
 BV bounds    x[3101]
 BV bounds    x[3102]
 BV bounds    x[3103]
 BV bounds    x[3104]
 BV bounds    x[3105]
 BV bounds    x[3106]
 BV bounds    x[3107]
 BV bounds    x[3108]
 BV bounds    x[3109]
 BV bounds    x[3110]
 BV bounds    x[3111]
 BV bounds    x[3112]
 BV bounds    x[3113]
 BV bounds    x[3114]
 BV bounds    x[3115]
 BV bounds    x[3116]
 BV bounds    x[3117]
 BV bounds    x[3118]
 BV bounds    x[3119]
 BV bounds    x[3120]
 BV bounds    x[3121]
 BV bounds    x[3122]
 BV bounds    x[3123]
 BV bounds    x[3124]
 BV bounds    x[3125]
 BV bounds    x[3126]
 BV bounds    x[3127]
 BV bounds    x[3128]
 BV bounds    x[3129]
 BV bounds    x[3130]
 BV bounds    x[3131]
 BV bounds    x[3132]
 BV bounds    x[3133]
 BV bounds    x[3134]
 BV bounds    x[3135]
 BV bounds    x[3136]
 BV bounds    x[3137]
 BV bounds    x[3138]
 BV bounds    x[3139]
 BV bounds    x[3140]
 BV bounds    x[3141]
 BV bounds    x[3142]
 BV bounds    x[3143]
 BV bounds    x[3144]
 BV bounds    x[3145]
 BV bounds    x[3146]
 BV bounds    x[3147]
 BV bounds    x[3148]
 BV bounds    x[3149]
 BV bounds    x[3150]
 BV bounds    x[3151]
 BV bounds    x[3152]
 BV bounds    x[3153]
 BV bounds    x[3154]
 BV bounds    x[3155]
 BV bounds    x[3156]
 BV bounds    x[3157]
 BV bounds    x[3158]
 BV bounds    x[3159]
 BV bounds    x[3160]
 BV bounds    x[3161]
 BV bounds    x[3162]
 BV bounds    x[3163]
 BV bounds    x[3164]
 BV bounds    x[3165]
 BV bounds    x[3166]
 BV bounds    x[3167]
 BV bounds    x[3168]
 BV bounds    x[3169]
 BV bounds    x[3170]
 BV bounds    x[3171]
 BV bounds    x[3172]
 BV bounds    x[3173]
 BV bounds    x[3174]
 BV bounds    x[3175]
 BV bounds    x[3176]
 BV bounds    x[3177]
 BV bounds    x[3178]
 BV bounds    x[3179]
 BV bounds    x[3180]
 BV bounds    x[3181]
 BV bounds    x[3182]
 BV bounds    x[3183]
 BV bounds    x[3184]
 BV bounds    x[3185]
 BV bounds    x[3186]
 BV bounds    x[3187]
 BV bounds    x[3188]
 BV bounds    x[3189]
 BV bounds    x[3190]
 BV bounds    x[3191]
 BV bounds    x[3192]
 BV bounds    x[3193]
 BV bounds    x[3194]
 BV bounds    x[3195]
 BV bounds    x[3196]
 BV bounds    x[3197]
 BV bounds    x[3198]
 BV bounds    x[3199]
 BV bounds    x[3200]
 BV bounds    x[3201]
 BV bounds    x[3202]
 BV bounds    x[3203]
 BV bounds    x[3204]
 BV bounds    x[3205]
 BV bounds    x[3206]
 BV bounds    x[3207]
 BV bounds    x[3208]
 BV bounds    x[3209]
 BV bounds    x[3210]
 BV bounds    x[3211]
 BV bounds    x[3212]
 BV bounds    x[3213]
 BV bounds    x[3214]
 BV bounds    x[3215]
 BV bounds    x[3216]
 BV bounds    x[3217]
 BV bounds    x[3218]
 BV bounds    x[3219]
 BV bounds    x[3220]
 BV bounds    x[3221]
 BV bounds    x[3222]
 BV bounds    x[3223]
 BV bounds    x[3224]
 BV bounds    x[3225]
 BV bounds    x[3226]
 BV bounds    x[3227]
 BV bounds    x[3228]
 BV bounds    x[3229]
 BV bounds    x[3230]
 BV bounds    x[3231]
 BV bounds    x[3232]
 BV bounds    x[3233]
 BV bounds    x[3234]
 BV bounds    x[3235]
 BV bounds    x[3236]
 BV bounds    x[3237]
 BV bounds    x[3238]
 BV bounds    x[3239]
 BV bounds    x[3240]
 BV bounds    x[3241]
 BV bounds    x[3242]
 BV bounds    x[3243]
 BV bounds    x[3244]
 BV bounds    x[3245]
 BV bounds    x[3246]
 BV bounds    x[3247]
 BV bounds    x[3248]
 BV bounds    x[3249]
 BV bounds    x[3250]
 BV bounds    x[3251]
 BV bounds    x[3252]
 BV bounds    x[3253]
 BV bounds    x[3254]
 BV bounds    x[3255]
 BV bounds    x[3256]
 BV bounds    x[3257]
 BV bounds    x[3258]
 BV bounds    x[3259]
 BV bounds    x[3260]
 BV bounds    x[3261]
 BV bounds    x[3262]
 BV bounds    x[3263]
 BV bounds    x[3264]
 BV bounds    x[3265]
 BV bounds    x[3266]
 BV bounds    x[3267]
 BV bounds    x[3268]
 BV bounds    x[3269]
 BV bounds    x[3270]
 BV bounds    x[3271]
 BV bounds    x[3272]
 BV bounds    x[3273]
 BV bounds    x[3274]
 BV bounds    x[3275]
 BV bounds    x[3276]
 BV bounds    x[3277]
 BV bounds    x[3278]
 BV bounds    x[3279]
 BV bounds    x[3280]
 BV bounds    x[3281]
 BV bounds    x[3282]
 BV bounds    x[3283]
 BV bounds    x[3284]
 BV bounds    x[3285]
 BV bounds    x[3286]
 BV bounds    x[3287]
 BV bounds    x[3288]
 BV bounds    x[3289]
 BV bounds    x[3290]
 BV bounds    x[3291]
 BV bounds    x[3292]
 BV bounds    x[3293]
 BV bounds    x[3294]
 BV bounds    x[3295]
 BV bounds    x[3296]
 BV bounds    x[3297]
 BV bounds    x[3298]
 BV bounds    x[3299]
 BV bounds    x[3300]
 BV bounds    x[3301]
 BV bounds    x[3302]
 BV bounds    x[3303]
 BV bounds    x[3304]
 BV bounds    x[3305]
 BV bounds    x[3306]
 BV bounds    x[3307]
 BV bounds    x[3308]
 BV bounds    x[3309]
 BV bounds    x[3310]
 BV bounds    x[3311]
 BV bounds    x[3312]
 BV bounds    x[3313]
 BV bounds    x[3314]
 BV bounds    x[3315]
 BV bounds    x[3316]
 BV bounds    x[3317]
 BV bounds    x[3318]
 BV bounds    x[3319]
 BV bounds    x[3320]
 BV bounds    x[3321]
 BV bounds    x[3322]
 BV bounds    x[3323]
 BV bounds    x[3324]
 BV bounds    x[3325]
 BV bounds    x[3326]
 BV bounds    x[3327]
 BV bounds    x[3328]
 BV bounds    x[3329]
 BV bounds    x[3330]
 BV bounds    x[3331]
 BV bounds    x[3332]
 BV bounds    x[3333]
 BV bounds    x[3334]
 BV bounds    x[3335]
 BV bounds    x[3336]
 BV bounds    x[3337]
 BV bounds    x[3338]
 BV bounds    x[3339]
 BV bounds    x[3340]
 BV bounds    x[3341]
 BV bounds    x[3342]
 BV bounds    x[3343]
 BV bounds    x[3344]
 BV bounds    x[3345]
 BV bounds    x[3346]
 BV bounds    x[3347]
 BV bounds    x[3348]
 BV bounds    x[3349]
 BV bounds    x[3350]
 BV bounds    x[3351]
 BV bounds    x[3352]
 BV bounds    x[3353]
 BV bounds    x[3354]
 BV bounds    x[3355]
 BV bounds    x[3356]
 BV bounds    x[3357]
 BV bounds    x[3358]
 BV bounds    x[3359]
 BV bounds    x[3360]
 BV bounds    x[3361]
 BV bounds    x[3362]
 BV bounds    x[3363]
 BV bounds    x[3364]
 BV bounds    x[3365]
 BV bounds    x[3366]
 BV bounds    x[3367]
 BV bounds    x[3368]
 BV bounds    x[3369]
 BV bounds    x[3370]
 BV bounds    x[3371]
 BV bounds    x[3372]
 BV bounds    x[3373]
 BV bounds    x[3374]
 BV bounds    x[3375]
 BV bounds    x[3376]
 BV bounds    x[3377]
 BV bounds    x[3378]
 BV bounds    x[3379]
 BV bounds    x[3380]
 BV bounds    x[3381]
 BV bounds    x[3382]
 BV bounds    x[3383]
 BV bounds    x[3384]
 BV bounds    x[3385]
 BV bounds    x[3386]
 BV bounds    x[3387]
 BV bounds    x[3388]
 BV bounds    x[3389]
 BV bounds    x[3390]
 BV bounds    x[3391]
 BV bounds    x[3392]
 BV bounds    x[3393]
 BV bounds    x[3394]
 BV bounds    x[3395]
 BV bounds    x[3396]
 BV bounds    x[3397]
 BV bounds    x[3398]
 BV bounds    x[3399]
 BV bounds    x[3400]
 BV bounds    x[3401]
 BV bounds    x[3402]
 BV bounds    x[3403]
 BV bounds    x[3404]
 BV bounds    x[3405]
 BV bounds    x[3406]
 BV bounds    x[3407]
 BV bounds    x[3408]
 BV bounds    x[3409]
 BV bounds    x[3410]
 BV bounds    x[3411]
 BV bounds    x[3412]
 BV bounds    x[3413]
 BV bounds    x[3414]
 BV bounds    x[3415]
 BV bounds    x[3416]
 BV bounds    x[3417]
 BV bounds    x[3418]
 BV bounds    x[3419]
 BV bounds    x[3420]
 BV bounds    x[3421]
 BV bounds    x[3422]
 BV bounds    x[3423]
 BV bounds    x[3424]
 BV bounds    x[3425]
 BV bounds    x[3426]
 BV bounds    x[3427]
 BV bounds    x[3428]
 BV bounds    x[3429]
 BV bounds    x[3430]
 BV bounds    x[3431]
 BV bounds    x[3432]
 BV bounds    x[3433]
 BV bounds    x[3434]
 BV bounds    x[3435]
 BV bounds    x[3436]
 BV bounds    x[3437]
 BV bounds    x[3438]
 BV bounds    x[3439]
 BV bounds    x[3440]
 BV bounds    x[3441]
 BV bounds    x[3442]
 BV bounds    x[3443]
 BV bounds    x[3444]
 BV bounds    x[3445]
 BV bounds    x[3446]
 BV bounds    x[3447]
 BV bounds    x[3448]
 BV bounds    x[3449]
 BV bounds    x[3450]
 BV bounds    x[3451]
 BV bounds    x[3452]
 BV bounds    x[3453]
 BV bounds    x[3454]
 BV bounds    x[3455]
 BV bounds    x[3456]
 BV bounds    x[3457]
 BV bounds    x[3458]
 BV bounds    x[3459]
 BV bounds    x[3460]
 BV bounds    x[3461]
 BV bounds    x[3462]
 BV bounds    x[3463]
 BV bounds    x[3464]
 BV bounds    x[3465]
 BV bounds    x[3466]
 BV bounds    x[3467]
 BV bounds    x[3468]
 BV bounds    x[3469]
 BV bounds    x[3470]
 BV bounds    x[3471]
 BV bounds    x[3472]
ENDATA
